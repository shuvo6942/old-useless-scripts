<?php
// Your Site Name - Will Be Use In Copyright Name
$_PHPLOFT['name'] = "CodeChecker.PHPLoft.Net";

// Your Site URL With Backslash (/)
$_PHPLOFT['url'] = "http://codechecker.phploft.net/";

// Your Site Name - Will Be Use In Site Title
$_PHPLOFT['title'] = "PHPLOFT.NET - PHP CODE CHECKER";

// Your Site Favicon URL / Directory
$_PHPLOFT['favicon'] = "assets/images/favicon.png";

// Your Site CSS File URL / Directory
$_PHPLOFT['css'] = "assets/css/style.phploft.css";

// Your Site Logo File URL / Directory
$_PHPLOFT['logo'] = "assets/images/logo.png";

?>
