<?php
include 'config.phploft.php';
include 'check.phploft.php';

$phploft = new PHPLOFT_CODE_CHECK();
echo '
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xml:lang="en" lang="en" xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
		<link rel="stylesheet" type="text/css" href="' . $_PHPLOFT['css'] . '">
		<link type="text/css" rel="stylesheet" href="' . $_PHPLOFT['url'] . 'assets/css/SyntaxHighlighter.css">
		</link>
		<link rel="icon" href="' . $_PHPLOFT['favicon'] . '" type="image/x-icon">
		<title>' . $_PHPLOFT['title'] . '</title>
	</head>
	<!-----HEAD_END-&-BODY_START----->
	<script type="text/javascript">
		$(document).ready(function() {
		    $("#clear").click(function() {
		        $(".normal").val("");
		        $(".normal").focus();
		
		    });
		
		});
	</script>
';
echo '<div class="logo"><a href="' . $_PHPLOFT['url'] . '"><img src="' . $_PHPLOFT['logo'] . '"/></a></div>
<!-----SITE_LOGO_END-&-CHECKER_STARTED-----><br/>';

echo '<div style="text-align:center;">
	<big>
		Paste Your 
		<php><a href="http://php.net" target="_blank">PHP</a></php>
		Code Below:
	</big>
	<br/>
	<form method="post">
		<textarea class="normal" name="code" required="required">' . htmlentities($_POST['code']) . '</textarea>
		<br/><input type="button" id="clear" value="Clear The Form"/>
		<input type="submit" value="Check My PHP"/>
	</form>
</div>';
if (isset($_POST['code'])) {
    if (!empty($_POST['code'])) {
        $checking = $phploft->check($_POST['code']);
        if ($checking) {
            foreach ($checking as $istiak => $tridip) {
                
                if ($istiak == "message") {
                    echo '<div  class="alert alert-error">';
                    echo $tridip . '<br/>';
                } else {
                    echo '<div class="highlight"><code>' . htmlentities($tridip) . '</code></div>';
                    echo '</div>';
                }
                
            }
        } else {
            echo '<div  class="alert alert-success">I Think Your Code Is Okay. It Also Can Be My Fault.</div>';
        }
    } else {
        echo '<div  class="alert alert-error">Please enter at least some PHP code above.</div>';
    }
}
echo '<!-----CHECKER_END-&-FOOTER_STARTED----->';



echo '<hr/>';

echo '<center><php><small>&#169; Copyright ' . date("Y") . ' ' . $_PHPLOFT['name'] . '. All Rights Reserved.</small></php></center>';