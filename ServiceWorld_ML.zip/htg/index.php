<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Head Tag Generator</title><link rel="STYLESHEET" type="text/css" href="http://wtools.gq/styles.css"/><link rel="shortcut icon" href="http://phptunes.com/favicon.ico"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/><style type="text/css">
body { background: ;
color: ;
}
a { color: ;
}
</style>
</head><body>




<div class="Comments"><div><form method="get" action="yht.php"> Your site Title: <br/><input type="text" name="get-a" size="20"/> <br/> favicon url: <br/><input type="text" name="get-b" size="20"/> <br/> CSS Style Url: <br/> <input type="text" name="get-c" size="20"/><br/> Page Keywords: <br/><input type="text" name="get-d" size="20"/> <br/> Page Description: <br/><input type="text" name="get-e" size="20"/><br/>Request Handling Url: <br/><input type="text" name="get-f" size="20"/><br/><input type="submit" value="Genrate"/></form></div>
</div>
</body></html>