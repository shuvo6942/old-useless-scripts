<?php
$geta = $_GET['get-a'];
$getb = $_GET['get-b'];
$getc = $_GET['get-c'];
$getd = $_GET['get-d'];
$gete = $_GET['get-e'];
$getf = $_GET['get-f'];


echo '<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Your Head Tag</title><link rel="STYLESHEET" type="text/css" href="http://wtools.gq/styles.css"/><link rel="shortcut icon" href="http://phptunes.com/favicon.ico"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/><style type="text/css">
body { background: ;
color: ;
}
a { color: ;
}
</style>
</head><body>



<b>Copy Your Head Tag<br/></b>


<textarea><title>'.$geta.'</title><link rel="shortcut icon" href="'.$getd.'"/><link rel="stylesheet" type="text/css" href="'.$getc.'"/><meta name="keywords" content="'.$getd.'"/><meta name="description" content="'.$gete.'"/><meta name="handheld" content="url:'.$getf.' "/></textarea></body></html>';
?>