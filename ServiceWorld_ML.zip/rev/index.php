<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Reverse Text</title><link rel="STYLESHEET" type="text/css" href="http://wtools.gq/styles.css"/><link rel="shortcut icon" href="http://pankajbd24.com/favicon.ico"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/><style type="text/css">
body { background: ;
color: ;
}
a { color: ;
}
</style>
</head><body>


<div class=page style="margin-left:0; margin-right:0;">Reverse Text</div> <div style="border:2px solid green; margin:0; padding:0;"><div class=in><div class=footbanner style="margin:2px; padding:0;"><div class=toptop1><br><div style="padding-left:3px; padding-right:3px;"><span class=shadow><font color=silver>Insert a word, phrase, sentence or paragraph and reverse it's text input from last letter to beginning letter. . !</font><br><br><SCRIPT LANGUAGE="JavaScript">

function reverse(form) {
text = "";
str = form.revtext.value;


for (i = 0; i <= str.length; i++)
text = str.substring(i, i+1) + text;
form.revtext.value = text;
}

</script>


<form>
<textarea type="text" name="revtext" style="color:red" cols="19" rows="7" value="">ServiceWorld.ML&trade;</textarea>
<br>
<input type=button style="background:url(http://greentooth.xtgem.com/b/gradg.png);color:silver"value="Reverse Text" onClick="reverse(this.form)">



<input style="background:url(http://greentooth.xtgem.com/b/gradg.png);color:silver" type="button" value="Clear" onclick="this.form.elements['revtext'].value=''">

</form>
</span>
</div>
</body>
</html>