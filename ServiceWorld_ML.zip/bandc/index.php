<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Bandwidth Calculator</title><link rel="STYLESHEET" type="text/css" href="http://wtools.gq/styles.css"/><link rel="shortcut icon" href="http://phptunes.com/favicon.ico"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/><style type="text/css">
body { background: ;
color: ;
}
a { color: ;
}
</style>
</head><body>



<script type="text/javascript" src="band.js"></script>
<div class=page style="margin-left:0; margin-right:0;">Bandwidth Calculator</div> <div style="border:2px solid green; margin:0; padding:0;"><div class=in><div class=footbanner style="margin:2px; padding:0;"><div class=toptop1><br><span class=shadow><font color=silver>Calculate/convert bandwidth to another equivalent unit. !<br><form name="bandwidth"><p><input type="text" name="original" size="19" value="2147483648" onFocus="this.form.value=''" style="background-color:#003300; color:yellow"><select size="1" name="units" ><option value="Bytes">Bytes</option><option value="Kb">Kb</option><option value="Mb">Mb</option><option value="Gb">Gb</option></select><input type="button" value="Calculate" name="B1" onClick="calculate()" style="background-image:url(http://greentooth.xtgem.com/b/gradg.png); color:silver"></p></form><p><br></span></body></html>