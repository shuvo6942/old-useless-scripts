<?php
echo '<?xml version="1.0" encoding="UTF-8"?><!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>ServiceWorld.ML</title><link rel="STYLESHEET" type="text/css" href="/styles.css"/><script type="text/javascript" src="http://wap4dollar.com/ad/pops/?id=zvc1jd710h"></script><link rel="shortcut icon" href="http://pankajbd24.com/favicon.ico"><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/><style type="text/css">
body { background: ;
color: ;
}
a { color: ;
}
</style>









<style type="text/css">.ad{}.bar4{background-color:#399;color:#ffffff;text-bold:1px 1px #fff;link-color:1px 1px #ffffff;padding:4px;}.bmenu{color:#fff;background-color:#4b4d4d;padding-top:5px;padding-bottom:5px;margin-top:1px;margin-bottom:1px;border-bottom:1px outset #676a6a;}.hidex{}.msgbody{background:#fffafa;padding:5px;display:block;border:dotted 1px #cae1ff;margin:5px;color:black;border-radius:4px;}.msgfoot{color:#333333;border:1px solid #e6b868;background-color:#fff5bc;padding:5px 5px 5px 5px;border-radius:4px;margin:4px 4px 4px 4px;}.msgtitle{color:#ffffff;background-color:#538dc3;background-repeat:no-repeat;background-position:right 50%;text-align:left;padding:3px;font-weight:bold:padding-left:5px;margin:4px 4px 4px 4px;border:1px solid #538dc3;border-radius:4px;}.rana2{padding:5px 5px 5px 8px;background:#000000;border-top:1px solid #ccc;border-bottom:1px solid #ccc;}.rmenu{background:#f5e9eb;border:1px solid #e2c0c7;margin:3px;padding:4px;border-radius:4px;}.xlist{}.xlist2{}</style>



<link rel="STYLESHEET" type="text/css" href="http://tunes420.wapka.mobi/styles.css"/>
<link rel="shortcut icon" href="http://greentooth.xtgem.com/i4/admn.png"/>
</head><body>


<div id="google_translate_element"></div><script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: "en"}, "google_translate_element");
}
</script><script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>




<div class="logo"><a href="/"><center><img src="/logo.png" alt="ServiceWorld.ML" width="180" height="100" style="border:0;margin:0px;"/></a></center></div>




<div class="mainblok" id="update">
<div class="mainblok">
<div class="bmenu"><center><img src="http://createfunnylogo.com/logo/ning/Free Services For All.jpg" height="100%" width="100%"/></center></div>';
include 'demo.php';
















echo '<div class="rmenu">
<center><b>Please help us by clicking this ads.</b><br/>
<a href="http://wap4dollar.com/ad/nonadult/serve.php?id=zvc1jd710h">Best Java, Android Games, Apps</a><br/><a href="http://clickbd.ga/show/html.php?uid=609&sid=633"><img src="http://clickbd.ga/adtools/728 i pic.gif"/></a>
<br/><a href="http://wap4dollar.com/ad/serve.php?id=zvc1jd710h">Hot Downloads of 2015 !</a><br/>
<script type="text/javascript" src="http://wap4dollar.com/ad/code/?id=zvc1jd710h"></script><br/>
<font color="red">';
include 'online.php';
echo '</font>
</center><br/><div align="center">
<script type="text/javascript" src="http://widget.supercounters.com/online_i.js"></script><script type="text/javascript">sc_online_i(1000016,"ffffff","e61c1c");</script>

<div class="phdr">Visitor Rank</div><a href="/"><img src="http://www.quick-counter.net/aip.php?tp=bt&amp;tz=Europe%2FLondon" alt="HTML hit counter - Quick-counter.net" border="0" /></a>
</div>
</div>
</div>





</div><div class="rmenu"><center><b>&copy; 2015 <a href="">ServiceWorld.ML</a></b><br/><b>Powered By <a href="http://fb.com/mehedi.hasan.shuvo7251">Shuvo</a></b></center></div>
</body></html>';
?>