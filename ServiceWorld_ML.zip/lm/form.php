<?php
$gets = $_GET['get-s'];
echo '<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Your Logo</title><link rel="STYLESHEET" type="text/css" href="http://wtools.gq/styles.css"/><link rel="shortcut icon" href="http://phptunes.com/favicon.ico"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/><style type="text/css">
body { background: ;
color: ;
}
a { color: ;
}
</style></head><body><div><p><div align="center"><div align="center">Create Monster text style!<br/><img src="http://logo54.com/movie/monster/logo.php?lo='.$gets.'" alt=""/></div><a href="http://logo54.com/movie/monster/logo.php?lo='.$gets.'"><span class="tst">Download</span></a><p><form action="form.php" method="get">Enter Text<input  type="text" name="get-s" value="" size="10" /><input type="submit" value="submit" /></form></p></div></p></div></body></html>';
?>