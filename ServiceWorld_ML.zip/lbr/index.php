<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Link Break Remover</title><link rel="STYLESHEET" type="text/css" href="http://wtools.gq/styles.css"/><link rel="shortcut icon" href="http://phptunes.com/favicon.ico"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/><style type="text/css">
body { background: ;
color: ;
}
a { color: ;
}
</style>
</head><body>



<div><p>



<script type="text/JavaScript">function removeBreaks(){

var para = document.getElementById("paragraphs").checked;
var nopara = document.getElementById("noparagraphs").checked;
var noBreaksText = document.getElementById("oldText").value;

noBreaksText = noBreaksText.replace(/(\r\n|\n|\r)/gm,"<1br />");

re1 = /<1br \/><1br \/>/gi;
re1a = /<1br \/><1br \/><1br \/>/gi;

if(nopara == 1 || nopara ==  true){
noBreaksText = noBreaksText.replace(re1," ");
}else{
noBreaksText = noBreaksText.replace(re1a,"<1br /><2br />");
noBreaksText = noBreaksText.replace(re1,"<2br />");
}

re2 = /\<1br \/>/gi;
noBreaksText = noBreaksText.replace(re2, " ");

re3 = /\s+/g;
noBreaksText = noBreaksText.replace(re3," ");

re4 = /<2br \/>/gi;
noBreaksText = noBreaksText.replace(re4,"\n\n");
document.getElementById("newText").value = noBreaksText;
}

function clearText(){
$('#oldText').val('');
$('#newText').val('');
$("#oldText").focus()
}</script></p>
<p><div class="mainblok"><div class="nfooter"> Remove Line Breaks</div>

<p>You can remove line breaks from blocks of text but preserve paragraph breaks with this tool.</p>
<p>If you've ever received text that was formatted in a skinny column with line breaks at the end of each line, like text from an email, an XML file or copy and pasted text from a PDF column then this tool is pretty darn handy.</p>
<p>You also have the option of just removing all line breaks from your XML, PDF or whatever text without preserving paragraph breaks.</p>
<p>Use this tool because spending hours manually removing line breaks sucks. Manually removing line breaks really really sucks.</p>







<form method="post" action="" class="online-tools">
<h2>Remove Line Breaks</h2>
<p>Paste your text in the box below and then click the button.</p>
<p>The new text will appear in the box at the bottom of the page.</p>
<p class="flat"><input type="radio" id="noparagraphs" name="paragraphs" value="no" checked="checked" /> Remove line breaks and paragraph breaks</p>
<p class="flat"><input type="radio" id="paragraphs" name="paragraphs" value="yes" /> Remove line breaks only (preserve paragraphs)</p>
<p><textarea id="oldText" name="oldText" rows="6" cols="36"></textarea></p>


<p><input type="button" name="Remove-Line-Breaks" value="Remove Line Breaks" onclick="javascript:removeBreaks()" class="frmbtn" /> <input type="button" name="Clear-Text" id="Clear-Text" value="Reset" onclick="javascript:clearText()" class="frmbtn" style="margin-left:30px;color:#666;" /></p>












<h2>New Text without Line Breaks</h2>
<p class="flat">Copy your new text without line breaks from the box below.</p>
<p><textarea id="newText" name="newText" rows="9" cols="36" onclick="javascript:this.form.newText.focus();this.form.newText.select();"></textarea>
</p></form>
</div></p>
</div>
</body></html>