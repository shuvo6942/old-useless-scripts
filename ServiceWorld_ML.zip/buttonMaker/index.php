<?


header('Content-type: application/xhtml+xml; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate');
print '<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<title>Image Button Maker</title>

</head>
<body>
<div>';

switch($_GET['id'])
{
default:
print '<form action="?" method="get">
<div>
Text:<br/>
<input name="txt" type="text" value="text"/><br/>
Size<br/>
<input name="x" type="text" value="35"/><br/>
Value<br/>
<input name="y" type="text" value="1"/><br/>Template : (<a href="?id=1">Templates</a>)
<select name="sk">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
<option value="13">13</option>

<option value="14">14</option>
<option value="15">15</option>
<option value="16">16</option>
<option value="17">17</option>
<option value="18">18</option>
<option value="19">19</option>
<option value="20">20</option>
</select><br/>The size : <br/>
<input name="size" type="text" value="3"/><br/>
<input type="hidden" name="id" value="2"/>
<input type="submit" value="Make"/>
</div>
</form>';
break;

case 1:
print '1) <img src="img/1.gif" alt="1.gif"/><br/>
2) <img src="img/2.gif" alt="2.gif"/><br/>
3) <img src="img/3.gif" alt="3.gif"/><br/>
4) <img src="img/4.gif" alt="4.gif"/><br/>
5) <img src="img/5.gif" alt="5.gif"/><br/>
6) <img src="img/6.gif" alt="6.gif"/><br/>
7) <img src="img/7.gif" alt="7.gif"/><br/>
8) <img src="img/8.gif" alt="8.gif"/><br/>
9) <img src="img/9.gif" alt="9.gif"/><br/>
10) <img src="img/10.gif" alt="10.gif"/><br/>
11) <img src="img/11.gif" alt="11.gif"/><br/>
12) <img src="img/12.gif" alt="12.gif"/><br/>
13) <img src="img/13.gif" alt="13.gif"/><br/>
14) <img src="img/14.gif" alt="14.gif"/><br/>
15) <img src="img/15.gif" alt="15.gif"/><br/>
16) <img src="img/16.gif" alt="16.gif"/><br/>
17) <img src="img/17.gif" alt="17.gif"/><br/>
18) <img src="img/18.gif" alt="18.gif"/><br/>
19) <img src="img/19.gif" alt="19.gif"/><br/>
20) <img src="img/20.gif" alt="20.gif"/><br/>';
break;

case 2:
print '<center><img src="img.php?txt='.$_GET['txt'].'&amp;x='.$_GET['x'].'&amp;y='.$_GET['y'].'&amp;sk='.$_GET['sk'].'&amp;size='.$_GET['size'].'" alt=""/><br/><a href="http://'.$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']).'/img.php?txt='.$_GET['txt'].'&amp;x='.$_GET['x'].'&amp;y='.$_GET['y'].'&amp;sk='.$_GET['sk'].'&amp;size='.$_GET['size'].'">Download</a><br/>Direct Link :</center><br/>http://'.$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']).'/img.php?txt='.$_GET['txt'].'&amp;x='.$_GET['x'].'&amp;y='.$_GET['y'].'&amp;sk='.$_GET['sk'].'&amp;size='.$_GET['size'];
break;
}

print '</div></body></html>';
?>