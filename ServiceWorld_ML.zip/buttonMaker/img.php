<?

header('Content-type: image/gif');
imagecreate(90,30);
$im= imagecreatefromgif('img/'.$_GET['sk'].'.gif');
imagecolorallocate($im,30,255,0);
$sp = imagecolorallocate($im,0,0,0);
imagestring($im,intval($_GET['size']),intval($_GET['x']),intval($_GET['y']),$_GET['txt'],$sp);
imagegif($im);
?>