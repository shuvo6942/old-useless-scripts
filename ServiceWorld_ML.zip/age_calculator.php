<?php
$birthday = $_POST['birthday'];
function birthday($birthday){
	$age = strtotime($birthday);
	if($age === false){
		return false;
	}
	list($y1,$m1,$d1) = explode("-",date("Y-m-d",$age));
	$now = strtotime("now");
	list($y2,$m2,$d2) = explode("-",date("Y-m-d",$now));
	$age = $y2 - $y1;
	if((int)($m2.$d2) < (int)($m1.$d1))
		$age -= 1;
	return $age;
}
echo '<html><title>Age Calculator</title>
<body><center>Enter Your Birthday (eg:2000-08-09)<br/><form action="" method="post"><input type="text" name="birthday" value="Your Birthday"/><br/><input type="submit" name="submit" value="Submit"/></form></center>
</body>
</html>';
if(isset($_POST['submit'])){
echo '<center>You are ';
echo birthday(''.$birthday.'');
echo ' years old.</center>';
}

?>