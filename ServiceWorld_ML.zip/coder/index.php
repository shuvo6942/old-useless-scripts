<?php

echo '<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">';
echo '<html xmlns="http://www.w3.org/1999/xhtml">';
  echo '<head>';
    echo '<title>Base64 Encoder & Decoder By 4Host.ml</title>';
    echo '<meta name="HandheldFriendly" value="true" />';

echo '</head>';
echo '<body style="width:100%; margin:0;">';
echo '<div id="header" style="text-align:center; background:#000  url(http://persibholic.com/new/wp-content/uploads/bgheader.png)repeat-x; color:#fff; margin:0; padding:8px;"><a href="http://4host.ml">4Host.ML</a></div>';
echo '<div style="background:#000 url(http://persibholic.com/new/wp-content/uploads/bgmenu.png)repeat-x;
 border-bottom:3px solid #000; margin:0; padding:4px; text-align:center; font-weight:bold; color:#fff;">Online Base64 Encoder / Decoder</div>';
echo '<div style="background:#fff; border:1px solid #ddd; padding:8px; margin:0; color:#333; font-weight:bold; text-align:center;">';
if($_GET['act']=="submit"){
if($_POST['encode'] || $_POST['decode']){
$script=$_POST['script'];
if($_POST['encode']){
$res=base64_encode($script);
echo '<form action="?act=submit" method="post">';
echo 'Encoder Result<br /><br />';
echo '<textarea cols="30" rows="15" style="background:#fff; border:2px solid #ddd; font-weight:bold;" name="script">'.$res.'</textarea>';
echo '<input type="submit" name="decode" value="Decode" style="padding:8px; background:#0099ff; border:2px solid #ddd; color:#fff; font-weight:bold;"></form>';

}elseif($_POST['decode']){
$res=base64_decode($script);
echo '<form action="?act=submit" method="post">';
echo 'Decoder Result<br /><br />';
echo '<textarea cols="30" rows="15" style="background:#fff; border:2px solid #ddd; font-weight:bold;" name="script">'.htmlspecialchars($res,ENT_QUOTES).'</textarea>';
echo '<input type="submit" name="encode" value="Encode" style="padding:8px; background:#0099ff; border:2px solid #ddd; color:#fff; font-weight:bold;"></form>';
}

}
}else{

echo '<form action="?act=submit" method="post">';

echo 'Input your text below<br /><br />';
echo '<textarea cols="30" rows="15" style="background:#fff; border:2px solid #ddd; font-weight:bold;" name="script"></textarea>';

echo '<br /><input type="submit" name="encode" value="Encode" style="padding:8px; background:#0099ff; border:2px solid #ddd; color:#fff; font-weight:bold;"><input type="submit" name="decode" value="Decode" style="padding:8px; background:#0099ff; border:2px solid #ddd; color:#fff; font-weight:bold;"></form>';


}
echo '</div>';
echo '<div style="background:#333; padding:8px; margin:0; color:#fff; font-weight:bold; text-align:center;">Copyright &copy; 2015 <a style="color:#0099ff" href="http://4host.ml/">4Host.ML</a></div>';
echo '</body></html>';
?>
