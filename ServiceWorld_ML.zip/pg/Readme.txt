READ ME:
*********

Usage
-----
1) Download and Unzip password-generator.zip to extract the files and folders.

2) Files named "index.php,style.css,ajx-generator.php,jquery.js and Readme.txt" and loader.gif image will be obtained.

3) Create your own password by just entering the length you needed for your password. 


Features
--------
1) It creates random password with symbols, numbers, uppercase, lowercase with a character length of (6-20).  

2) Password has created with multiple combination. So it cannot be braked by password hackers.

3) You can select your own choice of combinations by using check box.

4) Entering the length and choose your choice is enough for the password creation.

5) User friendly script and responsive



How to embed the script in to your webpage?
-------------------------------------------
1) Run index.php in your browser. 

2) The script code is available inside the <body> of the index.php file. 

3) The password is generated through ajx-generator.php file.


Style.CSS:
----------
1) Style.css contains the 'CSS properties' of the script

2) CSS properties like 'Background, padding, margin, height, width, border' etc., can be modified according to your needs.

Note: Before replacing the stylesheet make sure that the classnames and id names are given properly, to avoid duplication.
      




Script provided by:
*******************

This script is developed and owned by Hscripts.com
This is given under The GNU General Public License (GPL).

Downloads:
----------

Kindly visit our site

https://www.hscripts.com/scripts/php/password-generator.php to download the script

For further enquiries and support, mail us to support@hscripts.com.

Thanks & regards,

Hscripts Team 

Visit us at https://www.hscripts.com

 

