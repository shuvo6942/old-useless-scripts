<?php
echo '<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Funny Story Writer</title><link rel="STYLESHEET" type="text/css" href="http://tunes420.tk/styles.css"/><link rel="shortcut icon" href="http://phptunes.com/favicon.ico"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/><style type="text/css">
body { background: ;
color: ;
}
a { color: ;
}
</style></head>
<body>
<div class="phdr">

<center>এই সাইট দিয়ে আপনি হাস্যকর গল্প লিখতে পারবেন৷গল্প লিখতে নিচের ফরমটা পূরণ করুন৷ধন্যবাদ৷<br/>
<form action="magicpen.php?do=create" method="post">আপনার নামঃ <br/><input type="text" name="get-yn" size="13"/><br/> আপনার বয়সঃ <br/><input type="text" name="get-ya" size="13"/><br/> আপনার শহরের নামঃ <br/><input type="text" name="get-yc" size="13"/> <br/> আপনার জেলার নামঃ <br/><input type="text" name="get-yd" size="13"/><br/> একটি মেয়ের নামঃ <br/><input type="text" name="get-gf" size="13"/><br/>আপনার স্যারের নামঃ <input type="text" name="get-ft" size="13"/><br/> একটি পশুর নামঃ <br/><input type="text" name="get-fm" size="13"/><br/>
<input type="submit" name="submit" class="nfooter" value="Write Story"/>
</form></center>';












if(isset($_GET['do'])){
if($_GET['do'] == "create"){
if(isset($_POST['submit'])){
$getfm = $_POST['get-fm'];
$getft = $_POST['get-ft'];
$getyn = $_POST['get-yn'];
$getya = $_POST['get-ya'];
$getgf = $_POST['get-gf'];

$getyd = $_POST['get-yd'];


echo '<center>Copy Your Story </center><textarea>বরাবর
 '.$getft.' স্যার 
 '.$getyc.' ঊচ্চ  বিদ্যালয় 
 '.$getyd.' জেলা 

বিষয়ঃ আপনার মেয়ে বর্তমানে গর্ভবতী টাকা চেয়ে আবেদন পত্র 

জনাব '.$getft.' শ্বশুর , 

বিনীত নিবেদন এই যে আমি আপনার কুলাঙ্গার হবু জামাই !  আপনার গুনধর মেয়ে '.$getgf.' এর সাথে গত '.$getya.' মাস যাবত প্রেম করে আসছি ! হঠাৎ শুনি  আপনার মেয়ে '.$getya.' মাসের গর্ভবতী ! আমি আপনার নাতির নাম ঠিক করে ফেলেছি   ! আপনার নাতির নাম  '.$getfm.' ! কিন্তু টাকার অভাবে ডেলিভারি করাতে পারছি না ! 

অতএব , হবু শ্বশুর হিসেবে '.$getya.' হাজার টাকা দিলে ভাল হতো ! আর আপনি '.$getya.' হাজার টাকা দিলে আপনারে ঊপহার হিসেবে '.$getfm.' কে দিব  ! 

বিনীত
আপনার কুলাঙ্গার জামাই 
 '.$getyn.' 
 '.$getyc.'
 '.$getyd.'</textarea><br/>';






echo ' বরাবর<br/> '.$getft.' স্যার <br/> '.$getyc.' ঊচ্চ  বিদ্যালয় <br/> '.$getyd.' জেলা <br/> <br/> বিষয়ঃ আপনার মেয়ে বর্তমানে গর্ভবতী টাকা চেয়ে আবেদন পত্র <br/> <br/>জনাব '.$getft.' শ্বশুর , <br/> <br/><ul> বিনীত নিবেদন এই যে আমি আপনার কুলাঙ্গার হবু জামাই !  আপনার গুনধর মেয়ে '.$getgf.' এর সাথে গত '.$getya.' মাস যাবত প্রেম করে আসছি ! হঠাৎ শুনি  আপনার মেয়ে '.$getya.' মাসের গর্ভবতী ! আমি আপনার নাতির নাম ঠিক করে ফেলেছি   ! আপনার নাতির নাম  '.$getfm.' ! কিন্তু টাকার অভাবে ডেলিভারি করাতে পারছি না ! </ul><br/> <br/> অতএব , <ul>হবু শ্বশুর হিসেবে '.$getya.' হাজার টাকা দিলে ভাল হতো ! আর আপনি '.$getya.' হাজার টাকা দিলে আপনারে ঊপহার হিসেবে '.$getfm.' কে দিব  ! </ul> <br/><ul>বিনীত</ul> আপনার কুলাঙ্গার জামাই <br/> '.$getyn.' <br/> '.$getyc.' <br/>'.$getyd.'</div></body></html>';
}
}
}
?>