<?php
echo '<?xml version="1.0" encoding="UTF-8"?><!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Internal Server Error</title><link rel="STYLESHEET" type="text/css" href="http://tunes420.wapka.mobi/styles.css"/><link rel="shortcut icon" href="http://phptunes.com/favicon.ico"><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/><style type="text/css">
body { background: ;
color: ;
}
a { color: ;
}
</style>
<head><body>

<div class="rmenu">Internal Server Error</div>



</body></html>';
?>