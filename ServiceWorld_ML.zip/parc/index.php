<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Percantage Calculator</title><link rel="STYLESHEET" type="text/css" href="http://wtools.gq/styles.css"/><link rel="shortcut icon" href="http://phptunes.com/favicon.ico"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/><style type="text/css">
body { background: ;
color: ;
}
a { color: ;
}
</style>
</head><body>


<div class=page style="margin-left:0; margin-right:0;">Percentage Calculator</div>
<div style="border:2px solid green; margin:0; padding:0;">



<div class=in>

<div class=footbanner style="margin:2px; padding:0;"><div class=toptop1><br>
<div style="padding-left:3px; padding-right:3px;"><span class=shadow>
<SCRIPT language=JavaScript>
function perc1() {
a = document.form1.a.value/100;
b = a*document.form1.b.value;
document.form1.total1.value = b
}
function perc2() {
a = document.form1.c.value;
b = document.form1.d.value;
c = a/b;
d = c*100;
document.form1.total2.value = d
}
</SCRIPT>

<font color=silver>Calculate the percent <font color=lime>(%)</font> value of the given number. A versatile percentage calculator to make sure you have the answers 100% of the time!</b>
<br>
<br>
<font color=silver>
<center>
</span>
<FORM name=form1>
<TABLE align="center" style="border:1px solid #444; margin:5px;" cellSpacing=1 cellPadding=1>
<TBODY>
<TR>
<TD align=middle colSpan=3 style="background:url(http://greentooth.xtgem.com/b/gradg.png) repeat-x top; border:1px solid #060; padding:3px;">
<B>
<span class=shadow>
<FONT size=4>Percentage Calculator</FONT>
</span>
</B>
</TD>

<TR>

<TD style="background:#333; border:1px solid #444; padding:2px;">
<font color=silver>What is <INPUT size=4 name=a style="color:yellow">% of <INPUT size=4 name=b  style="color:yellow">?</TD>

<TD style="background:#333; border:1px solid #444; padding:2px;">


<INPUT onclick=perc1() type=button value=Compute style="background-image:url(http://greentooth.xtgem.com/b/gradg.png); color:silver;" >
</TD>




<TD style="background:#333; padding:2px; border:1px solid #444; padding:2px;">
<font color="silver">Answer: <INPUT maxLenth=40 size=5 name=total1 style="color:lime">%</TD>
<TR>
<TD style="background:black url(b/xgr2.png) repeat-x top; border:1px solid #444; padding:2px;">
<input size="4" name=c style="color:lime"> is what percent of <input size="4" name=d style="color:lime">?</TD>
<TD style="background:black url(b/xgr2.png) repeat-x top; border:1px solid #444; padding:2px;">
<INPUT onclick=perc2() type=button value=Compute style="background-image:url(http://greentooth.xtgem.com/b/gradg.png); color:silver;">
</TD>
<TD style="background:black url(b/xgr2.png) repeat-x top; border:1px solid #444; padding:2px;">Answer: <INPUT size=5 name=total2 style="color:lime">%</TD>
<TR>
<TD align=middle
colSpan=3 style="background:#000 url(b/xgr21.png) repeat-x bottom; border:1px solid #444;"><INPUT type=reset value="      Reset      " style="background-image:url(http://greentooth.xtgem.com/b/gradg.png); margin:3px; color:silver;">
</TD>
</TR>
</TBODY>
</TABLE>
</FORM>
<span>
<br>
</span>
</div></body></html>