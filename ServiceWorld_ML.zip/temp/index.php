<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Temperature Convertor</title><link rel="STYLESHEET" type="text/css" href="http://wtools.gq/styles.css"/><link rel="shortcut icon" href="http://phptunes.com/favicon.ico"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/><style type="text/css">
body { background: ;
color: ;
}
a { color: ;
}
</style>
</head><body>





<div class=page style="margin-left:0; margin-right:0;">Temperature Converter</div>
<div style="border:2px solid green; margin:0; padding:0;">
<div class=in>
<div class=footbanner style="margin:2px; padding:0;">
<div class=toptop1>
<br>
<div style="padding-left:4px; padding-right:4px;">
<span class=shadow>
<font color=silver>Converts between the major temperature units <font color=lime>Fahrenheit</font>, <font color=lime>Celsius</font>, and <font color=lime>Kelvin</font>.<br><br><FORM><font color=red>Fahrenheit:</font>
<br>
<INPUT TYPE="text" NAME="F" VALUE="" SIZE="10" MAXLENGTH="6" style="color:red" onChange="eval('C.value = ' + this.form.C_expr.value);eval('K.value = ' + this.form.K_expr.value)">
<INPUT TYPE="hidden" NAME="F_expr" VALUE="(Math.round(((212-32)/100 * C.value + 32)*100))/100;">
<INPUT TYPE="hidden" NAME="F_expr2" VALUE="(Math.round(((212-32)/100 *(K.value - 273) + 32)*100))/100; "><br>
<br>

<font color=red>Celsius:</font>


<br><INPUT TYPE="text" NAME="C" VALUE="" SIZE="10" MAXLENGTH="6" style="color:red" onChange="eval('F.value = ' + this.form.F_expr.value);eval('K.value = ' + this.form.K_expr.value)">
<INPUT TYPE="hidden" NAME="C_expr" VALUE="(Math.round((100/(212-32) * (F.value - 32))*100))/100">
<INPUT TYPE="hidden" NAME="C_expr2" VALUE="(Math.round(K.value - 273))"><br><br>
<font color=red>Kelvin:</font>
<br><INPUT TYPE="text" NAME="K" VALUE="" SIZE="10" MAXLENGTH="6" style="color:red" onChange="eval('F.value = ' + this.form.F_expr2.value);eval('C.value = ' + this.form.C_expr2.value)">
<INPUT TYPE="hidden" NAME="K_expr" VALUE="(Math.round((100/(212-32) * (F.value - 32))*100))/100 + 273">
<br>
<INPUT TYPE="Reset" NAME="Reset" VALUE="Reset" style="background-image:url(http://greentooth.xtgem.com/b/gradg.png); color:silver; margin:2px;">
</FORM>
</span></div></body></html>