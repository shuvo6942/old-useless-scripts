<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http:/www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml">
<html>
<head>



<link rel="STYLESHEET" type="text/css" href="/styles.css"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/><style type="text/css">



body { background: ;



color: ;



}



a { color: ;



}



</style>



<style type="text/css">body {min-width:340px;max- width:pc screen size px;min- height:240px;max-height:pc screen size px;} </style>



<link rel="stylesheet" type="text/css" href="http://sajal20.wapka.mobi/styles.css" media="all,handheld"/>







<link rel="stylesheet" type="text/css" href="http://gpfree.wapka.mobi/styles.css" media="all,handheld"/>



<link rel="icon" href="http://greentooth.xtgem.com/i4/w.png"/>



<link rel="stylesheet" type="text/css" href="http://iboycss.mobie.in/iboy_css/iboy_full_2.CSS" media="all,handheld"/><link rel="stylesheet" type="text/css" href="http://iboycss.mobie.in/iboy_css/iboy_full.css" media="all,handheld"/><link rel="stylesheet" type="text/css" href="http://hibd.mw.lt/raziul/rchat.css"/><style>body { margin : 0; padding : 1; font-family : verdana, "Comic Sans MS", Helvetica, sans-serif; background-color : #fff; min-width:100%; border-width: 0px; border-color: #5588ff; padding: 0px; border-style: solid; margin-left: auto; margin-right: auto; padding: 0px; border-style: solid;}a:link { color: green; text-decoration: bold; font-size: 11;} </style> <link rel="stylesheet" type="text/css" href="http://naimcss.mobie.in/paging+fold.css"/><link rel="stylesheet" href="http://iboycss.mobie.in/iboy_css/defult.css"/>





<style type="text/css"> body:after {content:""; display: block;  background:#006630; background-repeat: x; z-index: 1; position: relative; text-align: center; font-weight: bold; padding: 10px; color: #FFFFFF; border-bottom: 1px solid #006633; box-shadow: inset 0px 1px 0px rgba(255,255,255,0.4); -moz-box-shadow: inset 0px 1px 0px rgba(255,255,255,0.4); -webkit-box-shadow: inset 0px 1px 0px rgba(255,255,255,0.4); } </style>



</head><title>Demo Site | Create Website at low Cost.</title><body>



<div align="center"><div align="center"><div align="center"><div><div class="nfooter"> <table width="100%" border="0"><tbody><tr><td  align="left"><font size="70">Demo Site</font></td></tr></tbody></table></div></div></div>








<div class="nfooter"><table width="100%"><tr><td align="center"></td><td align="center" width="auto"><font size="0"><font color="white"></font></font><font color="#ffffff;"><b>আপনার নিজের নামে পছন্দ মতো সাইট বানিয়ে টাকা আয় করুন</b></font></td><td width=" %"></td></tr></table></div>


</div></div>



<div><div class="xlist" align="center"><table width="100%" border="0"><tbody><tr><td  align="left">



<b><a href="#download">Contract</a>


</b></td><td  align="right">








</td></tr></tbody></table></div></div>

<div class="mainblok"><div class="nfooter"> Payment</div><div class="d">আপনি যদি আমাদের কাছ থেকে ওয়াপ সাইট নেন তা হলে টাকা Payment করতে হবে



বিকাশ 



এর মাধ্যমে<br />Bkash <b>+8801947388706 (Personal)<br/><b>Note : This Number is only for BKash.Not for Call.</b></b></div></div>

<div><div align="center"><div class="mainblok">



<div align="center"><div class="d">আপনাকে ওয়াপসাইট বিক্রির দুনিয়ায় স্বাগতম। ওয়েবসাইট নেই।এখনই আমাদের কাছ থেকে যেকোন ধরনের একটি ওয়েবসাইট কিনুন আর ঘরে বসেই আয় করুন এবং হয়ে যান একটি ওয়েবসাইটের মালিক</div></div>



<div class="d" align="center">





<b>এখানে সব চেয়ে  ভাল মানের সাইট তৈরি করে দেওয়া হয়।। <br/><br/></b>আমরা যে কোনো ধরনের সাইট তরী করি | যত তাড়াতাড়ি অর্ডার করবেন, তত দ্রুত আপনার সাইট পাবেন | অর্ডার দিতে যোগাযোগ করুনঃ</div></div><div><div><div><div class="mainblok"><div align="center"><div class=""><div class="c"><table width="100%"><tr><td width="50%"><div class="gmenu"><div class="c"><div class=""><a href="http://facebook.com/MEHEDI.HASAN.SHUVO7251"><span style="color:  #FF00FF;"><center>Facebook a যোগাযোগ করুন</center></span></a></div></div></div></td><td width="50%"><div class="d"><div class="c"><div class=""><a href="wtai://wp/mc; +8801624172388"><span style="color: red;"><center>Phone a যোগাযোগ করুন</center></span></a></div></div></div></td></tr></table></div></div></div>



</div></div></div></div></div></div></div>






<div><div><div class="mainblok" align="center">

<div class="omenu" align="center">নিচে বিভিন্ন সাইটের ডিজাইন প্রাইস ও ডেমো প্রদান করা হলো |</div>



<div class="d" align="center">আপনার পছন্দের ডিজাইন বাছাই করুন এবং তারপর আমাদের সাথে যোগাযোগ করে সাইটের অর্ডার করুন |</div></div></div>




<div><div class="mainblok"><div class="nfooter" align="center"><b>Auto Upload download site php </b></div>
<div class="d">



<table width="100%" border="0"><tbody><tr><td  align="left"><b>→</b><a href="http://bdsong24.ml" ><font color="#FF00FF"><b>Bdsong24.ml</b></font></a></td><td align="right">150 Taka</td></tr></tbody></table></div>
<div class="gmenu"><table width="100%" border="0"><tbody><tr><td  align="left"><b>→</b><a href="http://downloads24.cf"><font color="#FF00FF"><b>Sumirbd.mobi</b></font></a></td><td align="right">150 Taka</td></tr></tbody></table></div>










<div class="d"><table width="100%" border="0"><tbody><tr><td  align="left"><b>→</b><a href="http://allscripts.ml"><font color="#FF00FF"><b>AllScripts.ML</b></font></a></td><td align="right">120 Taka</td></tr></tbody></table></div>


<div class="d"><table width="100%" border="0"><tbody><tr><td  align="left"><b>→</b><a href="http://dj.songmela.cf"><font color="#FF00FF"><b>DJBoss.in</b></font></a></td><td align="right">150 Taka</td></tr></tbody></table></div>

<div class="gmenu"><table width="100%" border="0"><tbody><tr><td  align="left"><b>→</b>
<a href="http://n.songmela.cf"><font color="#FF00FF"><b>n.Songmela.cf</b></font></a></td><td align="right">150 Taka</td></tr></tbody></table></div>

<div><div class="mainblok"><div class="nfooter" align="center"><b>Some Demo of Download Site</b></div>
<div class="d">










<table width="100%" border="0"><tbody><tr><td  align="left"><b>★</b><a href="http://amarwap.com" ><font color="#FF00FF"><b>Amarwap.Com</b></font></a></td><td align="right">180 Taka</td></tr></tbody></table></div>



<div class="gmenu"><table width="100%" border="0"><tbody><tr><td  align="left"><b>★</b>



<a href="http://a.songmela.cf" ><font color="#FF00FF"><b>A.Songmela.cf</b></font></a>



</td><td align="right">



150 Taka</td></tr></tbody></table>



</div>







<div class="gmenu">



<table width="100%" border="0"><tbody><tr><td  align="left">



<b>★</b>



<a href="http://djhungama.net/" ><font color="#FF00FF"><b>DJhungama.Net</b></font></a>



</td><td align="right">200 Taka</td></tr></tbody></table>



</div>



<div class="d">



<table width="100%" border="0"><tbody><tr><td  align="left">


<b>★</b>



<a href="http://DidarBD24.Com" ><font color="#FF00FF"><b>DidarBD24.Com</b></font></a>










</td><td align="right">180 Taka</td></tr></tbody></table>



</div>



<div class="gmenu">



<table width="100%" border="0"><tbody><tr><td  align="left">



<b>★</b>



<a href="http://Wapking.In" ><font color="#FF00FF"><b>Wapking.In</b></font></a>



</td><td align="right">



150 Taka</td></tr></tbody></table>



</div>



<div class="d">



<table width="100%" border="0"><tbody><tr><td  align="left">



<b>★</b> <a href="http://Cutbd.com" ><font color="#FF00FF"><b>CutBD.com</b></font></a>



</td><td align="right">



250 Taka</td></tr></tbody></table>



</div>



<div class="gmenu">



<table width="100%" border="0"><tbody><tr><td  align="left">



<b>★</b>



<a href="http://DJpremik.Com" ><font color="#FF00FF"><b>DJpremik.Com</b></font></a>



</td><td align="right">



200 Taka</td></tr></tbody></table>



</div><div class="omenu" align="center"><a href="wtai://wp/mc;+8801624172388"><b>CALL ME</b></a><b> +8801624172388</b></div></div></div>














<div><div class="mainblok"><div class="nfooter" align="center"><b> Some Demo Of Forum SiTe </b></div><div class="d">



<table width="100%" border="0"><tbody><tr><td  align="left">



<b>♥</b>



<a href="http://Trickbd.com"><font color="#FF00FF"><b>TrickBD.Com



</b></font></a>



</td><td align="right">



250 Taka</td></tr></tbody></table></div><div class="gmenu">



<table width="100%" border="0"><tbody><tr><td  align="left">



<b>♥</b>



<a href="http://TipsView24.com"><font color="#FF00FF"><b>TipsView24.Com

</b></font></a></td><td align="right">220 Taka</td></tr></tbody></table></div>



<div class="d">



<table width="100%" border="0"><tbody><tr><td  align="left">



<b>♥</b>



<a href="http://tipstune24.com"><font color="#FF00FF"><b>TipsTune24.Com

</b></font></a>










</td><td align="right">



240 Taka</td></tr></tbody></table></div><div class="gmenu">



<table width="100%" border="0"><tbody><tr><td  align="left">



<b>♥</b>












<a href="http://code4bd.Tk"><font color="#FF00FF"><b>Code4BD.Tk



</b></font></a>



</td><td align="right">



260 Taka</td></tr></tbody></table></div>



<div class="d">



<table width="100%" border="0"><tbody><tr><td  align="left">



<b>♥</b>



<a href="http://SymbianModz.TK"><font color="#FF00FF"><b>SymbianModz.TK



</b></font></a>



</td><td align="right">



200 Taka</td></tr></tbody></table></div><div class="gmenu">



<table width="100%" border="0"><tbody><tr><td  align="left">



<b>♥</b>



<a href="http://trickload.com"><font color="#FF00FF"><b>Trickload.com



</b></font></a>



</td><td align="right">



250 Taka</td></tr></tbody></table></div>



<div class="d">



<table width="100%" border="0"><tbody><tr><td  align="left"><b>♥</b>



<a href="http://trickarn.wapka.mobi"><font color="#FF00FF"><b>Trickarn.Net



</b></font></a>



</td><td align="right">











240 Taka</td></tr></tbody></table></div><div class="gmenu">



<table width="100%" border="0"><tbody><tr><td  align="left">



<b>♥</b>



<a href="http://hackerteambd.com"><font color="#FF00FF"><b>MatricxBD.Com



</b></font></a>



</td><td align="right">



200 Taka</td></tr></tbody></table></div>



<div class="d">



<table width="100%" border="0"><tbody><tr><td  align="left">



<b>♥</b>



<a href="http://tipsround.com"><font color="#FF00FF"><b>tipsround.com



</b></font></a>



</td><td align="right">



280 Taka</td></tr></tbody></table></div>



<div class="gmenu">



<table width="100%" border="0"><tbody><tr><td  align="left">



<b>♥</b>



<a href="http://sitesell3.wapka.mobi/site_29.xhtml"><font color="#FF00FF"><b>bdtrick4.tk



</b></font></a>



</td><td align="right">



150 Taka</td></tr></tbody></table></div>

<div class="d">



<table width="100%" border="0"><tbody><tr><td  align="left">













<b>♥</b>



<a href="http://TipsAdiLBD.Tk"><font color="#FF00FF"><b>TipsAdiLBD. Tk



</b></font></a>



</td><td align="right">



120 Taka</td></tr></tbody></table></div><div class="d">



<table width="100%" border="0"><tbody><tr><td  align="left">



<b>♥</b>



<a href="http://fbbook.ml"><font color="#FF00FF"><b>Facebook.com PHP



</b></font></a>



</td><td align="right">



100 Taka</td></tr></tbody></table></div>

<div class="omenu" align="center">



<a href="wtai://wp/mc;+8801624172388"><b>CALL ME</b></a><b> +8801624172388</b></div></div></div>



<div><div class="mainblok"><div class="nfooter" align="center"><b> Phising site </b></div><div class="gmenu">



<table width="100%" border="0"><tbody><tr><td  align="left">



<b>→</b>



<a href="http://facebook.com"><font color="#FF00FF"><b>Facebook Phising



</b></font></a>



</td><td align="right">



30 Taka</td></tr></tbody></table></div>












<div class="d"><table width="100%" border="0"><tbody><tr><td  align="left">



<b>→</b>



<a href="http://gmail.com"><font color="#FF00FF"><b>Gmail Phising



</b></font></a>



</td><td align="right">



30 Taka</td></tr></tbody></table></div>



<div class="gmenu"><table width="100%" border="0"><tbody><tr><td  align="left">



<b>→</b>



<a href="http://yahoo.com"><font color="#FF00FF"><b>yahoo Phising



</b></font></a>



</td><td align="right">



30 Taka</td></tr></tbody></table></div><div class="d"><table width="100%" border="0"><tbody><tr><td  align="left">



<b>→</b>



<a href="http://bdsell.ml/site_200.xhtml"><font color="#FF00FF"><b>Auto like fb Phising



</b></font></a>



</td><td align="right">



30 Taka</td></tr></tbody></table></div>



<div class="gmenu">



<table width="100%" border="0"><tbody><tr><td  align="left">



<b>→</b>



<a href="http://wapka.mobi"><font color="#FF00FF"><b>Wapka Mobile

</b></font></a>



</td><td align="right">

















30 Taka</td></tr></tbody></table></div>



<div class="omenu" align="center">



<a href="wtai://wp/mc;+8801624172388"><b>CALL ME</b></a><b> +8801624172388</b></div></div></div>



<div><div class="mainblok"><div class="nfooter"><b>Domain List</b></div>



<div class="d"><font color="#FF00FF">



<table width="100%" border="0"><tbody><tr><td  align="left">



<b>♠</b>



<b>



.Tk</b></td><td align="right">



10 Taka</td></tr></tbody></table></font></div>



<div class="gmenu"><font color="#FF00FF"><table width="100%" border="0"><tbody><tr><td  align="left">

<b>♠</b>
<b>
.Ml</b></td><td align="right">
10 Taka</td></tr></tbody></table></font></div>







<div class="d"><font color="#FF00FF">
<table width="100%" border="0"><tbody><tr><td  align="left">
<b>♠</b>
<b>



.Cf</b></td><td align="right">

30 Taka</td></tr></tbody></table></font></div>


<div class="gmenu"><font color="#FF00FF">













<table width="100%" border="0"><tbody><tr><td  align="left">



<b>♠</b>



<b>



.Ga</b></td><td align="right">


30 Taka</td></tr></tbody></table></font></div>



<div class="d"><font color="#FF00FF">


<table width="100%" border="0"><tbody><tr><td  align="left">


<b>♠</b>


<b>

.Com</b></td><td align="right">

420 Taka</td></tr></tbody></table></font></div>


<div class="gmenu"><font color="#FF00FF">
<table width="100%" border="0"><tbody><tr><td  align="left">
<b>♠</b>
<b>
.Net</b></td><td align="right">

420 Taka</td></tr></tbody></table></font></div>
<div class="d"><font color="#FF00FF">
<table width="100%" border="0"><tbody><tr><td  align="left">
<b>♠</b>
<b>
.In</b></td><td align="right">
420 Taka</td></tr></tbody></table></font></div>










<div class="omenu" align="center"><a href="wtai://wp/mc;+8801624172388"><b>CALL ME</b></a><b> +8801624172388</b></div>
</div></div>
<div><div class="mainblok"><div class="nfooter" align="center">  আমাদের থেকে সাইট নিলে আপনারা যা যা সুবিধা পেয়ে থাকবেন </div>
<style>#master-tn_fold{-o-mini-fold:folded}</style><div><a href="fold:;master-tn_fold" title="fold"><div class="list2"><font color="#ff00ff"><center><b><div class="ss">বিস্তারিত দেখুন এখানে</div></b></center></font></div></a>











</div>
<div id="master-tn_fold">
<div class="d" align="center">
সহজেই ইনটেরনেট থেকে হাজার হাজার টাকা ইনকামের শু ব্যবস্তা।</div>



<div class="omenu" align="center">


সাইট কে টপে নিয়ার জন্য অনেক ব্যবস্তা করে দেয়া হবে।</div>


<div class="d" align="center">আপনারা যদি আমাদের থেকে সাইট তৈরী করেন তাহলে ঐ সাইট এ আপনি আপনার পছন্দের গান,ছবি,ফাইল,গেম ইত্যাদি পছন্দের File রাখোতে পারবেন এবং এই সাইট থেকে সবাই Download করতে পারবে.
</div>

<div class="omenu" align="center">টাঁকা Payment করার ২ ঘন্টার মধেই আপনাকে আপনার ওয়াপ সাইট বুজিয়ে দেওয়া হবে।</div>
<div class="d" align="center">আমার কাছ থেকে ওয়েপ সাইট বানিয়ে নিলে সেও ওয়েপ সাইট বানাতে পারবে |তাকে শিখানো হবে </div>
<div><div><div class="omenu" align="center">আমাদের থেকে ওয়াপ-সাইট নিলে সম্পুন কাজ মোবাইল দিয়ে করতে পারবেন</div></div></div><div class="mainblok"><center><a href="fold:master-tn_fold" title="#ff00ff"><b> Cancel</b></a></center></div></div>









</div></div>
<div><div class="mainblok"><div class="nfooter"> ওয়াপসাইট বানাতে আপনার যা যা লাগবে</div>
<div id="download"/>
<font color="#ff00ff"><b><div class="gmenu">1.Gmail id </div>











<div class="gmenu">2.Gmail-er password </div>
<div class="gmenu">3.One new password </div>
<div class="gmenu">4.Site name</div>
</b></font>
<div class="omenu"><a href="sms:+8801624172388">আমাকে মেসেজ দিন।</a> </div>
</div></div>
<div><div class="mainblok"><div class="nfooter"><b>Contact Zone</b></div>
<div class="gmenu"><b><font color="red">Mobile: +8801624172388</font></b> <font color="#FF00FF">- 24/7 Support</font></div>
<div class="gmenu"><b><font color="red">BKash Mobile: +8801947388706</font></b>- Not for Call.Only for BKash<font color="#FF00FF"></font></div>
<div class="gmenu"><b><font color="red">Email: </font></b> <font color="#FF00FF"><b>shuvo6942@gmail.com</b></font></div></div></div>
<div><div align="center"><div class="mainblok"><div class="nfooter"><div align="center"><b><center>©<a href="/"> Demo Site</a></center><br/><center>Powered by - <a href="http://fb.me/MEHEDI.HASAN.SHUVO7251"><font colour="red">Shuvo</font></a></center></b><br/></div></div></div></div></div>
</body></html>
