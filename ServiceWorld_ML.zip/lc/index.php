<?php
/* This calculator is your for free by Calendarscripts.info. You have no obligations for anything - you can modify, redistribute, sell it or whatever you want to do.
We will appreciate if you don't remove the link at the bottom, but that's not required. */

/* Feel free to modify the CSS and the texts below. */

?>
<title>Loan Calculator</title>
<style type="text/css">
.calculator_table
{
	font-size:11px;
	font-family:verdana, arial, sans-serif;
	border:2pt solid #4444FF;
	padding:25px;
	width:380px;	
}

calculator_table label
{
	display:block;
	width:150px;
	float:left;
}
</style>

	<div class="calculator_table">
	<form method="post" onsubmit="return validateDebtCalculator(this);">
	<fieldset>
	<legend>Debt Details:</legend>
   <p><label>Debt Balance:</label> $<input type="text" name="debt" value="<?php echo @$_POST['debt']?>"></p>
   <p><label>Annual Interest Rate:</label> <input type="text" name="interest" size="5" value="<?php echo @$_POST['interest']?>">%</p>
   <p><label>Current Monthly Payment:</label> $<input type="text" size="5" name="payment" value="<?php echo @$_POST['payment']?>"></p>
   </fieldset>
   
   <fieldset>
	<legend>I want to know:</legend>
	<p><input type="radio" id="extraMode" name="mode" value="extra" <?php if(!isset($_POST['mode']) or $_POST['mode']=='extra') echo 'checked'?>> What will happen if I pay extra $<input type="text" name="extra_payment" size="5" value="<?php if(@$_POST['mode']=='extra') echo @$_POST['extra_payment']?>"> monthly</p>
	<p><input type="radio" id="targetMode" name="mode" value="target" <?php if(@$_POST['mode']=='target') echo 'checked'?>> How to be debt-free after <input type="text" name="target_years" size="3" value="<?php if(@$_POST['mode']=='target') echo @$_POST['target_years']?>"> years &amp; <input type="text" name="target_months" size="2" value="<?php if(@$_POST['mode']=='target') echo @$_POST['target_months']?>"> months</p>
	</fieldset>

	<p align="center"><input type="submit" name="calculator_ok" value="Calculate"></p>
	</form>
	
	<?php
	if(!empty($_POST['calculator_ok']))
	{
	   // first let's calculate how much the user is going to pay
	   // with the current payment plan
	   $monthly_interest=round($_POST['interest']/12,2)/100;
	   $num_months=0;
	   $total_interest=0;
	   $principal=$_POST['debt'];
	   
	   // make sure monthly payment is not < of the first interest payment
	   $minimum_payment=$principal*$monthly_interest;
	   
	   if($minimum_payment>=$_POST['payment'])
	   {
	      die("Your monthly payment is too low, you can never pay this debt!");
	   }
	   
	   while($principal>0)
	   {
	      $this_month_interest=$principal*$monthly_interest;
	      $total_interest+=$this_month_interest;
	      $num_months++;
	      
	      $current_total=$principal+$this_month_interest;
	      
	      // reduce principal with the difference
	      $principal=$current_total-$_POST['payment'];
	   }	   
	   
	   // months and years text
	   if($num_months>12)
	   {
	      $left=$num_months%12;
	      $num_years=($num_months-$left)/12;
	      
	      if($left>0) $current_debt_free_text="$num_years years and $left months";
	      else $current_debt_free_text="$num_years years";
	   }
	   else
	   {
	      $current_debt_free_text="$num_months months";
	   }
	
	   // start reduction calculations
		if($_POST['mode']=='extra')
		{
		   // we need the same loop as above but using the new amount
		   $num_months_extra=0;
	      $total_interest_extra=0;
	      $principal=$_POST['debt'];		   
	      
	      while($principal>0)
	      {
	         $this_month_interest=$principal*$monthly_interest;
	         $total_interest_extra+=$this_month_interest;
	         $num_months_extra++;
	         
	         $current_total=$principal+$this_month_interest;
	         
	         // reduce principal with the difference
	         $principal=$current_total-$_POST['payment']-$_POST['extra_payment'];
	      }
	      
	      // months and years text
	      if($num_months_extra>12)
	      {
	         $left_extra=$num_months_extra%12;
	         $num_years_extra=($num_months_extra-$left_extra)/12;
	         
	         if($left_extra>0) $debt_free_text_extra="$num_years_extra years and $left_extra months";
	         else $debt_free_text_extra="$num_years_extra years";
	      }
	      else
	      {
	         $debt_free_text_extra="$num_months_extra months";
	      }
		}
		else // $_POST[mode]==target
		{
		   // number of months
		   $target_months=$_POST['target_years']*12 + $_POST['target_months'];
		   
		   // calculate the monthly payment using this formula
		   // http://www.vertex42.com/ExcelArticles/amortization-calculation.html
		   $monthly_payment=$_POST['debt'] *
		                     $monthly_interest * pow(1+$monthly_interest, $target_months)    
		                         / 
		                         (pow(1+$monthly_interest, $target_months) - 1);
		}
		?>
		<h2>Calculation Results</h2>
		<p>Following your current payment plan you will be debt free after <b><?php echo $current_debt_free_text?></b>. For this period you will pay total interest of <b>$<?php echo number_format($total_interest)?></b> to the bank.</p>	
		<?php if($_POST['mode']=='extra'):?>
		<p>By paying extra $<?php echo $_POST['extra_payment']?> monthly you will be debt free <b><?php echo $debt_free_text_extra?></b>. 
		The interest paid to the bank in this case will be <b>$<?php echo number_format($total_interest_extra)?></b>.</p>
		<?php else:?>
		<p>If you want to be debt free after <b><?php echo $_POST['target_years']?> years and <?php echo number_format($_POST['target_months'])?> months</b> you need to pay <b>$<?php echo number_format($monthly_payment)?> monthly</b>.</p>
		<?php endif;
	}
	?>
	</div>

<script language="javascript">
function validateDebtCalculator(frm)
{
   if(isNaN(frm.debt.value) || frm.debt.value=="")
   {
      alert("Please enter your debt balance, numbers only");
      frm.debt.focus();
      return false;
   }
   
   if(isNaN(frm.interest.value) || frm.interest.value=="")
   {
      alert("Please enter your debt annual interest rate, numberic");
      frm.interest.focus();
      return false;
   }
   
   if(isNaN(frm.payment.value))
   {
      alert("Please enter only numbers for your current monthly payment");
      frm.payment.focus();
      return false;
   }
   
   if(document.getElementById('extraMode').checked)
   {
       if(isNaN(frm.extra_payment.value) || frm.extra_payment.value=="")
      {
         alert("Please enter your debt extra monthly payment, numbers only");
         frm.extra_payment.focus();
         return false;
      }
   }
   
   if(document.getElementById('targetMode').checked)
   {
       if(isNaN(frm.target_years.value) || frm.target_years.value=="")
      {
         alert("Please enter target years, numbers only");
         frm.target_years.focus();
         return false;
      }
      
       if(isNaN(frm.target_months.value) || frm.target_months.value=="")
      {
         alert("Please enter target months, numbers only");
         frm.target_months.focus();
         return false;
      }
   }
}
</script>
