<?
require 'header.php';
require 'config.php';
print $top;
if(!$_GET['s']){
print '<div class="input">
Bắt Đầu
<form action="main.php" method="get">
<div>
<input name="url" type="hidden" value="'.$url.'"/>
<input name="adr" type="text" value="http://"/><br/>
<input type="submit" value="Xem"/>
</div>
</form>
</div>
<div class="border">
<a href="faq.php?url='.$url.'">FAQ</a><br/>
</div>
<div class="border">
<a href="?s=1">Service</a><br/>
</div>
<div class="border">
<a href="http://bentrewap.com">Tạo wap chat</a><br/></div>
'.$foot;
}else{
print '<div class="foot">Xem code Wap/Web:<br/>
<div style="text-decoration:underline; font-weight:bold">http://'.$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']).'/?url=địa chỉ url phải có http://<br/>
</div>
</div>
</body></html>';
}
?>
