<?
require 'header.php';
require 'config.php';
print $top.'
<div>
-Dịch vụ này cho phép bạn xem mã của tập tin bất kỳ trên Internet.<br/>
-Tất nhiên, dịch vụ này
rất hữu ích để xem mã WML, HTML và các trang khác.<br/>
</div>
'.$foot;
?>
