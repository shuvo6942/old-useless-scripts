<?

$banner = '<div class="banner">
<a href="http://bentrewap.com">WwW.BenTreWap.Com</a><br/>
</div>';

if(!isset($_GET['url'])){
$url = 'bentrewap.com';
}else{
$url = htmlspecialchars(stripslashes($_GET['url']));
}

if(!isset($title))
{ $title = 'Xem Code Wap'; }
$top = '<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru">
<head>
<title>'.$title.'</title>
<link rel="stylesheet" type="text/css" href="style.css"/>
</head>
<body>
<div class="w">'.$url.'<br/>
</div>';
$foot = '<div class="w">
<a href="http://'.$url.'">'.$url.'</a>
</div><img src="http://u-on.eu/c.php?u=8722"></body></html>';

?>
