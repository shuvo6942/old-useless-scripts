<?php
$style = $_GET['style'];
$text = $_GET['text'];
include 'header.php';

echo '<div align="center"> <img src="http://createfunnylogo.com/logo/'.$style.'/'.$text.'.jpg" width="150px" height="50px" alt="Your Logo" /></div><br/>';
echo '<div align="center"><div class="mainblok"><div class="mainblok"><div class="nfooter"><div class="phdr"><a href="http://createfunnylogo.com/logo/'.$style.'/'.$text.'.jpg"><div align="center">Download</div></a></div></div></div></div></div>';
include 'style.php';
include 'preview.php';
include 'footer.php';
?>