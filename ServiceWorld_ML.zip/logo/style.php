<?php
$site = $_SERVER['HTTP_HOST'];
echo '<div class="mainblok"><div class="mainblok"><div class="nfooter"><div align="center">';






echo '<form method="get" action="logo.php">Enter Your Text:<br/><input type="text" name="text" value="'.$site.'" /><br/>Select Style:<br/><select name="style">
<option value="google">Google Style</option>
<option value="yahoo">Yahoo Style</option>
<option value="yahoo">Yahoo Style</option>
<option value="yahoo">Yahoo Style</option>
<option value="digg">Digg Style</option>
<option value="facebook">Facebook Style</option>
<option value="twitter">Twitter Style</option>
<option value="cnn">CNN Style</option>
<option value="ferrari">Ferrari Style</option>
<option value="flockr">Flickr Style</option>
<option value="JurassicPark">JurassicPark Style</option>
<option value="startwars">StarWars Style</option>
<option value="adidas">Adidas Style</option>
<option value="batman">Batman Style</option>
<option value="cococola">CocaCola Style</option>
<option value="xfiles">xFiles Style</option>
<option value="techcrunch">TechCrunch Style</option>
<option value="43things">43Things Style</option>
<option value="bloglines">Bloglines Style</option>
<option value="harrypotter">Harrypotter Style</option>
<option value="Matrix">Matrix Style</option>
<option value="ning">Ning Style</option>
<option value="scoobydoo">ScoobyDoo Style</option>
<option value="spiderman">Spiderman Style</option>
<option value="blazed">Blazed Style</option>
<option value="blade">Blade Style</option>
<option value="dead">Dead Style</option>
<option value="mickymouse">Mickymouse Style</option>
<option value="shrek">Shrek Style</option>
<option value="101puppies">101Puppies Style</option>
<option value="aladdin">Aladdin Style</option>
<option value="army">Army Style</option>
<option value="casper">Casper Style</option>
<option value="friday23">Friday23 Style</option>
<option value="irreversible">Irreversible Style</option>
<option value="lordoftherings">Lord of The Rings Style</option></select>';








echo '<br/><input type="submit" value="Make Logo" class="phdr"></form></div></div></div></div>';


?>