<?php
echo '<div align="center"><div class="phdr"><a href=http://'.$site.'>Logo Maker</a><br/>Powered By <a href=http://fb.com/mehedi.hasan.shuvo7251>Shuvo</a></div></div>
</body></html>';
?>