<?php
echo '<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Logo maker</title><link rel="STYLESHEET" type="text/css" href="http://tunes420.wapka.mobi/styles.css"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/><style type="text/css">
body { background-color: white;
color: black;
}
a { color: #0645AD;
</style>
<link rel="shortcut icon" href="http://pankajbd24.com/favicon.ico" />
</head></body>';
?>