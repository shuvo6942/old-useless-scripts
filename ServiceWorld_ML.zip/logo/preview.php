<?php
echo '<img src="http://createfunnylogo.com/images/preview/google.jpg" alt="google" width="158" height="30"/><br/>

<img src="http://createfunnylogo.com/images/preview/yahoo.jpg" alt="yahoo" width="158" height="30"/><br/>

<img src="http://createfunnylogo.com/images/preview/facebook.jpg" alt="facebook" width="158" height="30"/><br/>

<img src="http://createfunnylogo.com/images/preview/digg.jpg" alt="digg" width="158" height="30"/><br/>

<img src="http://createfunnylogo.com/images/preview/twitter.jpg" alt="twitter" width="158" height="30"/><br/>










<img src="http://createfunnylogo.com/images/preview/cnn.jpg" width="158" alt="cnn" height="30"/><br/>

<img src="http://createfunnylogo.com/images/preview/ferrari.jpg" alt="ferrari" width="158" height="30" /><br/>

<img src="http://createfunnylogo.com/images/preview/flockr.jpg" alt="flockr" width="158" height="30" /><br/>
<img src="http://createfunnylogo.com/images/preview/JurassicPark.jpg" alt="JurassicPark logo" width="158" height="30"/>
<img src="http://createfunnylogo.com/images/preview/starWars.jpg" alt="STARWARS" width="158" height="30" /><br/>
<img src="http://createfunnylogo.com/images/preview/adidas.jpg" alt="adidas" width="158" height="30" /><br/>
<img src="http://createfunnylogo.com/images/preview/cococola.jpg" alt="cococola" width="158" height="30" /><br/>
<img src="http://createfunnylogo.com/images/preview/xfiles.jpg" alt="xfiles" width="158" height="30" /><br/>



<img src="http://createfunnylogo.com/images/preview/batman.jpg" alt="BATMAN" width="158" height="30" /><br/>
<img src="http://createfunnylogo.com/images/preview/techcrunch.jpg" alt="TECHCRUNCH" width="158" height="30" /><br/>
<img src="http://createfunnylogo.com/images/preview/bloglines.jpg" alt="BLOGLINES" width="158" height="30" /><br/>
<img src="http://createfunnylogo.com/images/preview/43things.jpg" alt="43THINGS" width="158" height="30" /><br/>
<img src="http://createfunnylogo.com/images/preview/harrypotter.jpg" alt="harrypotter" width="158" height="30" /><br/>
<img src="http://createfunnylogo.com/images/preview/matrix.jpg" alt="matrix" width="158" height="30" /><br/>


<img src="http://createfunnylogo.com/images/preview/ning.jpg" alt="ning" width="158" height="30" /><br/>


<img src="http://createfunnylogo.com/images/preview/SpiderMan.jpg" alt="spiderman" width="158" height="30" /><br/>


<img src="http://createfunnylogo.com/images/preview/blazed.jpg" alt="blazed" width="158" height="30" /><br/>

<img src="http://createfunnylogo.com/images/preview/blade.jpg" alt="blade" width="158" height="30" /><br/>


<img src="http://createfunnylogo.com/images/preview/scoobydoo.jpg" alt="scoobydo" width="158" height="30" /><br/>



<img src="http://createfunnylogo.com/images/preview/shrek.jpg" alt="SHREK" width="158" height="30" /><br/>

<img src="http://createfunnylogo.com/images/preview/dead.jpg" alt="dead" width="158" height="30" /><br/>

<img src="http://createfunnylogo.com/images/preview/mickymouse.jpg" alt="mickymouse" width="158" height="30" /><br/>

<img src="http://createfunnylogo.com/images/preview/casper.jpg" alt="casper" width="158" height="30" /><br/>

<img src="http://createfunnylogo.com/images/preview/army.jpg" alt="army" width="158" height="30" /><br/>

<img src="http://createfunnylogo.com/images/preview/aladdin.jpg" alt="aladdin" width="158" height="30" /><br/>
<img src="http://createfunnylogo.com/images/preview/101puppies.jpg" alt="101puppies" width="158" height="30" /><br/>

<img src="http://createfunnylogo.com/images/preview/friday23.jpg" alt="friday23" width="158" height="30" /><br/>

<img src="http://createfunnylogo.com/images/preview/irreversible.jpg" alt="irreversible" width="158" height="30" /><br/>

<img src="http://createfunnylogo.com/images/preview/LordOfTheRings.jpg" alt="LordOfTheRings" width="158" height="30" /><br/>




';
?>