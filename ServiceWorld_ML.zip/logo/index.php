<?php


$site = $_SERVER['HTTP_HOST'];


include 'header.php';



echo '<div align="center"><div align="center"> <img src="http://createfunnylogo.com/logo/facebook/Mehedi Hasan Shuvo.jpg" width="150px" height="50px" alt="Mehedi Hasan Shuvo" /></div><br/></div>';
echo '<div align="center"><div class="mainblok"><div class="mainblok"><div class="nfooter"><div class="phdr"><a href="http://createfunnylogo.com/logo/yahoo/Mehedi Hasan Shuvo.jpg"><div align="center">Download</div></a></div></div></div></div></div>';
include 'style.php';
include 'preview.php';
include 'footer.php';
?>