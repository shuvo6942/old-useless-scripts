//Favicon Generator script//
//Version: 1.0//
//Author: MiraZ Mac//

Features:
======================
[] Not Bug at all
[] New eye catching look
[] Max image size increased to 175kb
[] Supports all image format
[] faster loading speed

How to Install?
=====================
Anyone can install this script even a kid. If you can't then read this.
First of all upload and unzip this script to root directory or subdirectory(if you want)
and then......................done!!!

// http://facebook.com/miraz.mac //