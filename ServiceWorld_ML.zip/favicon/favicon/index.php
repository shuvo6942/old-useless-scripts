<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html><head>
<title>Secret Directory</title>
</head><body>
<h1>It's a secret directory</h1>
<p>So You can't go further. So just go to hell.</p>
</body></html>
