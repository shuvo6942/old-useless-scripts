<title>Free favicon Generator</title> <?php
$set['title']='Free Favicon Generator';
// fully scripted by miraz mac and you fool trying to edit it? go back you fool
// favicon Generator Script beta release

if(!function_exists("generate_favicon")){
function generate_favicon(){
	// Create favicon.
	$postvars = array(
	"image" 			=> trim($_FILES["image"]["name"]),
	"image_tmp"			=> $_FILES["image"]["tmp_name"],
	"image_size"		=> (int)$_FILES["image"]["size"],
	"image_dimensions"	=> (int)$_POST["image_dimensions"]);
	$valid_exts = array("jpg","jpeg","gif","png");
	$ext = end(explode(".",strtolower(trim($_FILES["image"]["name"]))));
	$directory = "./favicon/"; // Directory to save favicons. Include trailing slash. If there is no directory script will crash. mind it
	$rand = rand(1000,9999);
	$filename = $rand.$postvars["image"];

	// Checks if the file is larger than 175kb.
	if($postvars["image_size"] <= 179200){
		// Checks if the file has a valid extension.
		if(in_array($ext,$valid_exts)){
			if($ext == "jpg" || $ext == "jpeg"){
				$image = imagecreatefromjpeg($postvars["image_tmp"]);
			}
			else if($ext == "gif"){
				$image = imagecreatefromgif($postvars["image_tmp"]);
			}
			else if($ext == "png"){
				$image = imagecreatefrompng($postvars["image_tmp"]);
			}
			if($image){
				list($width,$height) = getimagesize($postvars["image_tmp"]);
				$newwidth = $postvars["image_dimensions"];
				$newheight = $postvars["image_dimensions"];
				$tmp = imagecreatetruecolor($newwidth,$newheight);
					
				// Copy the image to one with the new width and height.
				imagecopyresampled($tmp,$image,0,0,0,0,$newwidth,$newheight,$width,$height);
			
				// Create image file with 100% quality.
				if(is_dir($directory)){
					if(is_writable($directory)){
						imagejpeg($tmp,$directory.$filename,100) or die('Could not make image file');
						if(file_exists($directory.$filename)){	
							// Image created, now renaming it to its
							$ext_pos = strpos($rand.$postvars["image"],"." . $ext);
							$strip_ext = substr($rand.$postvars["image"],0,$ext_pos);
							// Rename image to .ico file
							rename($directory.$filename,$directory.$strip_ext.".ico");
							return '<div class="nb"><strong>Preview Favicon:</strong><br/>
							<img src="'.$directory.$strip_ext.'.ico" border="0" title="Favicon  Image Preview" style="padding: 4px 0px 4px 0px;background-color:transparent" /><br/>
							Favicon Created. <a href="'.$directory.$strip_ext.'.ico" target="_blank" name="Download favicon.ico now!"><b>Click to Download Favicon</b></a></div>';
						} else {
							"File was not created.";
						}
					} else {
						return 'The directory: "'.$directory.'" is not writable.';
					}
				} else {
					return 'The directory: "'.$directory.'" is not valid.';
				}
			
				imagedestroy($image);
				imagedestroy($tmp);
			} else {
				return "Could not create image file.";
			}
		} else {
			return "File size too large. Max allowed file size is 175kb.";	
		}
	} else {
		return "Invalid file type. You must upload an image file. (jpg, jpeg, gif, png).";	
	}
}
}

?>

<?php

error_reporting (0);

include'header.php';



?>


<div class="t" align="center">Favicon Generator - WapMasTer Tool</div>
<div style="background: none repeat scroll 0% 0% rgba(255, 252, 182, 0.97);
padding: 3px;
border: 1px solid #DDD;
margin: 2px;" align="center"><a href="http://fb.com/miraz.mac">Download Favicon Generator Script</a></div>
<div class="lb"><form action="index.php?do=create"  enctype="multipart/form-data" method="post">
<p><strong>Resize Image To:</strong></p>
<select style="width: 170px;" name="image_dimensions">
<option selected="selected" value="16">16px &nbsp;x&nbsp; 16px</option>
<option value="32">32px &nbsp;x&nbsp; 32px</option>
</select>
<p><strong>Select Image:</strong></p>
<input name="image" size="10" type="file" /><br>
<input class="gmenu" style="font-weight: bold;" name="submit" type="submit" value="Get Favicon" />
</form></div>

<?php

if(isset($_GET['do'])){
	if($_GET['do'] == "create"){
		if(isset($_POST['submit'])){
			$generate_favicon = "<p>".generate_favicon()."</p>";
			$generate_favicon .= "
            ";
			$generate_favicon .= '<div class="t">Setup Guide</div>
           <div class="nb">Download your generated favicon and upload it anywhere, then copy your favicon url and replace this HTML Code. Then put this code in your site.Download it fast becuase it will be automaticaly deleted from this site in 24 hours.<br/>
            <b></b><br><textarea class="gmenu" cols="10" rows="2">&lt;link rel=&quot;shortcut icon&quot; type=&quot;image/x-icon&quot; href=&quot;URL OF YOUR FAVICON&quot;/&gt;</textarea>
            </div>';
		} else {
			$generate_favicon = "";	
		}
	}
}

?>

            <p>
            <?=$generate_favicon;?>
            </p>
<div align="center" class="t">Copyright To Shuvo.</div>
<style>a:link{color: red;}
input[type=submit]{background: rgba(148, 221, 28, 1); border: 1px solid rgba(148, 221, 28, 1); color: #fff; padding: 5px; margin: 3px;}

input[type=file], textarea, input[type=text], select{background: white; padding: 5px; border: 1px solid rgba(148, 221, 28, 1);}


.nb{    padding: 5px;
    border: 1px solid #8CDD28;
    margin: 5px;
    background: rgba(210, 255, 169, 0.82);} body{background: #f9f9f9; color: #000; padding: 0px; margin: 0px auto; max-width: 650px; border: 1px solid #F58100; font-family: Tahoma, Arial}.lb{border-bottom: 1px solid #ddd; padding: 5px;}
	.t{background: none repeat scroll 0% 0% rgba(245, 129, 0, 1);
padding: 5px;
color: #FFF;
font-family: Tahoma,Arial;
font-weight: bold;}
	</style>
