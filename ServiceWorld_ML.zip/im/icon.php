<?php
$gets = $_GET['get-s'];
$getr = $_GET['get-r'];
echo '<div><img src="http://2wap.org/usf/smshild/sm_gen.php?act=smsh&amp;text='.$gets.'&amp;sm='.$getr.'" /><br />
<a href="http://2wap.org/usf/smshild/sm_gen.php?act=smsh&amp;text='.$gets.'&amp;sm='.$getr.'"><span class="tst">Download </span></a>
</div><br/>';
?>
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Your Icon</title><link rel="STYLESHEET" type="text/css" href="http://wtools.gq/styles.css"/><link rel="shortcut icon" href="http://phptunes.com/favicon.ico"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/>
</head><body>


<?php
include 'form.php';
?>
</body></html>