<?php
echo '<div>
<form action="icon.php" method="get">Enter text: <input  type="text" name="get-s" value="" size="7" />
<select name="get-r" value="" ><option value="sm1">sm1</option>
<option value="sm10">sm10</option>
<option value="sm11">sm11</option>
<option value="sm12">sm12</option>
<option value="sm13">sm13</option>
<option value="sm14">sm14</option>
<option value="sm15">sm15</option>
<option value="sm16">sm16</option>
<option value="sm17">sm17</option>
<option value="sm18">sm18</option>
<option value="sm19">sm19</option>
<option value="sm2">sm2</option>
<option value="sm20">sm20</option>
<option value="sm21">sm21</option>
<option value="sm22">sm22</option>
<option value="sm23">sm23</option>
<option value="sm24">sm24</option>
<option value="sm25">sm25</option>
<option value="sm26">sm26</option>
<option value="sm27">sm27</option>
<option value="sm28">sm28</option>
<option value="sm29">sm29</option>
<option value="sm3">sm3</option>
<option value="sm30">sm30</option>
<option value="sm31">sm31</option>
<option value="sm32">sm32</option>
<option value="sm33">sm33</option>
<option value="sm34">sm34</option>
<option value="sm35">sm35</option>
<option value="sm36">sm36</option>
<option value="sm37">sm37</option>
<option value="sm38">sm38</option>
<option value="sm39">sm39</option>
<option value="sm4">sm4</option>
<option value="sm40">sm40</option>
<option value="sm41">sm41</option>
<option value="sm42">sm42</option>
<option value="sm43">sm43</option>
<option value="sm44">sm44</option>
<option value="sm">sm5</option>
<option value="sm6">sm6</option>
<option value="sm7">sm7</option>
<option value="sm8">sm8</option>
<option value="sm9">sm9</option>
</select><br/><input type="submit" value="Get Icon" name="submit"/></form></div>';
?>