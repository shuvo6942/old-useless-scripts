<?php
echo '<div><img src="http://2wap.org/usf/smshild/sm_gen.php?act=smsh&amp;text=shuvo&sm=sm1" /><br />
<a href="http://2wap.org/usf/smshild/sm_gen.php?act=smsh&amp;text=shuvo&amp;sm=sm1"><span class="tst">Download </span></a>
</div><br/>';
?><html>
<title>Icon Maker</title><link rel="STYLESHEET" type="text/css" href="http://wtools.gq/styles.css"/><link rel="shortcut icon" href="http://phptunes.com/favicon.ico"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/>
<body>
<?php
include 'form.php';
?>
</body></html>