<?php
echo '<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Google Map Viewer</title><link rel="STYLESHEET" type="text/css" href="http://wtools.gq/styles.css"/><link rel="shortcut icon" href="http://phptunes.com/favicon.ico"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/><style type="text/css">
body { background: ;
color: ;
}
a { color: ;
}
</style>
</head><body>







<form method="post" action="index.php?do=create"><br />Location:<br/><br /><input type="text" name="get-loc" value="" /><br/>Zoom:<br/><input type="text" name="get-zoom" value=""/><br/>Map type:<br/><select name="get-mapt"><br /><option value="satellite">Satellite</option><br /><option value="roadmap">Road Map</option></select><br/>Width:<br/><br /><input type="text" name="get-width" value=""/><br/>Height:<br/><br /><input type="text" name="get-height" value=""/><br /><input type="submit" name="submit" value="view"/></form>';

$getloc = $_POST['get-loc'];
$geth = $_POST['get-height'];
$getw = $_POST['get-width'];
$getz = $_POST['get-zoom'];
$getm = $_POST['get-mapt'];

if(isset($_GET['do'])){
if($_GET['do'] == "create"){
if(isset($_POST['submit'])){
echo '<img src="http://maps.google.com/maps/api/staticmap?center='.$getloc.'&zoom='.$getz.'&maptype='.$getm.'&size='.$geth.'x'.$getw.'&mobile=true&sensor=false" alt="google maps"/>';
}
}
}
echo '</body></html>';
x?>