<?php
include "config.php";
?>
<?php
include "header.php";
?>
<?php
if(isset($_SESSION['log']))
{ echo "<meta http-equiv='refresh' content='0; index.php'/>";}

else{
if(x==($_GET['u']))
{ $notice="<div class='warning'>Your Account Has Been Blocked By Admin</div>"; }

if(isset($_POST['submit']))
{
$name=($_POST['name']);
$pass=($_POST['pass']);

if( empty($name) || empty($pass))
{ $notice="<div class='error'>Required All Fields</div>"; }

else{ 
$nc2=(mysql_query("SELECT * FROM User WHERE Name='{$name}'"));
if(mysql_num_rows($nc2)==0)
{ $notice="<div class='error'>Name Wrong</div>"; }

else{ 
while($nc=mysql_fetch_array($nc2))
{
$mpass=$nc['Pass'];
if(!$mpass== $pass)
{ $notice="<div class='error'>Pass Wrong</div>"; }
else{
$_SESSION['log']=$name;

echo "<meta http-equiv='refresh' content='0; clogin.php'/>";

}}}}}
echo "<div class='border'><div class='title'>Login</div> $notice <form action='' method='post'><div class='bottom'>Name: <br/><input type='text' name='name'/> Pass: <br/><input type='password' name='pass'/><center><input type='submit' name='submit' value='Login'/><center></div></form><div class='bottom'><a href='singup.php'>Registration</a> </div><div class='bottom'><a href='lpass.php'>Lost Password</a></div></div>";
}
?>
<?php
include "footer.php";
?>
<?php
echo "<head><title> Login  </title>
<meta property='og:title' content='Login'/>
<meta property='og:image' content='http://$domain/photo/sfb.png'/>
</head>";
?>