<?php
include "config.php";
?>
<?php
include "header.php";
?>
<?php
if(!isset($_SESSION['log']))
{ echo "<meta http-equiv='refresh' content='0; index.php'/>"; }

else{
$name=$_SESSION['log'];

if(isset($_POST['submit']))
{
$date=date("d F Y");
$title=($_POST['title']);
$photo=($_POST['photo']);
$post=($_POST['post']);
$count='0';
if( empty($title) || empty($photo) || empty($post))
{ $notice="<div class='error'>Required All Fields</div>"; }

else{
if(strlen($title)<20)
{ $notice="<div class='error'>Title Must Be Between 20 to 250 Characters</div>"; }

else{
$ul=(mysql_query("INSERT INTO Post(Title,Photo,Post,Name,Date,Count) VALUES('{$title}','{$photo}','{$post}','{$name}','{$date}','{$count}')"));
if(!$ul)
{
 $notice="<div class='error'>Failed To Add Post Try Again</div>"; 
}
else{
echo "<meta http-equiv='refresh' content='0; uindex.php'/>";
 $notice="<div class='error'>Post Successfully Added</div>";
}
}
}
}
echo "<div class='border'><div class='title'>Add Post</div> $notice <form action='' method='post'><div class='bottom'> Post Title: <br/><input type='text' name='title' value=''/></div><div class='bottom'> Photo Url: <br/><input type='text' name='photo' value='http://$domain/hd/photo/pna.jpeg'/></div><div class='bottom'> Your Post: <br/><input type='text' name='post' value=''/></div><div class='bottom' align='center'> <input type='submit' name='submit' value='Submit'/></div></form></div>";

} ?>
<?php
include "footer.php";
?>
<?php
echo "<head><title> Add Post </title>
<meta property='og:title' content='Add Post'/>
<meta property='og:image' content='http://$domain/hd/photo/sfb.png'/>
</head>";
?>