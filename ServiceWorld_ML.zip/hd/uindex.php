<?php 
include "config.php"; 
?>
<?php 
include "header.php"; 
?>
<?php
if(!isset($_SESSION['log']))
{ echo "<meta http-equiv='refresh' content='0; index.php'/>"; }

else{
$name=$_SESSION['log'];

$cku2=(mysql_query("SELECT * FROM User WHERE Name='{$name}'"));
while($cku=mysql_fetch_array($cku2))
{
$photo=$cku['Photo'];
$website=$cku['Website'];

$type=$cku['Type'];
if($type==block)
{
echo "<meta http-equiv='refresh' content='0; login.php?u=x'/>";
session_destroy();
}

echo "<div class='border'><div class='title'>Cpanel</div>
<table width='100%' class='bottom'><tr><td width='25%'><img src='$photo' class='frame' width='50px' height='50px' alt='$name'/></td><td width='75%'> $name <br/> $website </td></tr></table> 
<div class='bottom'><a href='add_post.php'><font color='black'> Add Post  </font></a></div> 
<div class='bottom'><a href='profile.php?u=$name'><font color='black'> View Profile </font></a></div>
<div class='bottom'><a href='chs.php'><font color='black'> Change Security </font></a></div></div>"; }

echo "<div class='border'><div class='title'>Posts</div>";
$page=($_GET['page']);
if(empty($page))
{ $page='1'; }
$pv=floor($page-1);
$p1=floor($pv*10);
$p2=floor($pv*10+10);

$ck2=(mysql_query("SELECT * FROM Post WHERE Name='{$name}' ORDER BY Id DESC LIMIT $p1,$p2"));
while($ck=mysql_fetch_array($ck2))
{
$title=$ck['Title'];
$photo=$ck['Photo'];
$post=$ck['post'];
$date=$ck['Date'];
$count=$ck['Count'];
$id=$ck['Id'];

echo "<div class='bottom'> Post Added By <a href='profile.php?u=$name'><font color='black'>$name</font></a> on $date Total view $count <a href='view.php?id=$id'><table width='100%' class='frame'><tr>
<td width='25%'> <img src='$photo' height='50px' width='50px' class='frame'/></td><td width='75%'><b><font color='black'> $title </font></b></td></tr></table></a>
<div><input type='text' value='http://$domain/hd/view.php?id=$id'/></div>
<table width='100%'><td width='33%' class='frame'><a href='http://facebook.com/share.php?u=http://$domain/hd/view.php?id=$id'><div align='center'><font color='black'> Share </font></div></a></td><td width='33%' class='frame'><a href='edit_post.php?id=$id'><div align='center'><font color='black'> Edit </font></div></a></td><td width='33%' class='frame'><a href='delete_post.php?id=$id'><div align='center'><font color='black'> Delete </font></div></a></td></table></div>";

}
$page2=floor($page+1);
echo "<div class='bottom' align='center'><a href='?page=$page2'>See More Posts</a></div></div>";

}
?>
<?php 
include "footer.php"; 
?>
<?php
echo "<head><title> Uindex $name </title>
<meta property='og:title' content='Uindex $name'/>
<meta property='og:image' content='http://$domain/hd/photo/sfb.png'/>
</head>";
?>