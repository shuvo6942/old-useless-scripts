<?php 
include "config.php"; ?> 
<?php 
include "header.php"; ?> 
<?php if(!isset($_SESSION['log'])) 
{ echo "<meta http-equiv='refresh' content='0; index.php'/>"; }  

else{ if(!isset($_GET['id'])) 
{ echo "<meta http-equiv='refresh' content='0; index.php'/>"; }  

else{ 
echo "<div class='border'><div class='title'>Edit Reply</div>";   

$id=($_GET['id']);  

$ck2=(mysql_query("SELECT * FROM Reply WHERE Id='{$id}'")); 
if(mysql_num_rows($ck2)==0) 
{ $notice="<div class='error'>Reply Id Invalid.</div>"; }  

else{ 
while($ck=mysql_fetch_array($ck2)) 
{ $name=$ck['Name']; 
 if(!$name==$_SESSION['log']) 
{ $notice="<div class='error'>You Cannot Edit This Reply.</div>"; } 

else{ $text=$ck['Text'];  

if(isset($_POST['submit'])) 
{
$ntext=($_POST['ntext']);
if( empty($ntext))
{ $notice="<div class='error'>Required All Field</div>"; }

else{
$ul2=(mysql_query("UPDATE Reply SET Text='{$ntext}' WHERE Id='{$id}'"));

if(!$ul2)
{ $notice="<div class='error'>Reply Edit Failed</div>"; } 

else{
echo "Reply Succesfully Edited.";
}}}}}} 

echo "<form action='' method='post'> $notice <div class='bottom'> Type Your Text: <br/> <input type='text' name='ntext' value='$text'/></div>  <div class='bottom' align='center'> <input type='submit' name='submit' value='Edit'/></div></form>";  

echo "</div>"; 
}} ?>
<?php
include "footer.php"; ?>  
<?php
echo "<head><title> Edit Reply </title>
<meta property='og:title' content='Edit Reply'/>
<meta property='og:image' content='http://$domain/hd/photo/sfb.png'/>
</head>";
?>