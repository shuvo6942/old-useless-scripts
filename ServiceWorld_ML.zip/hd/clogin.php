<?php
include "config.php";
?>
<?php
include "header.php";
?>
<?php
if(!isset($_SESSION['log']))
{ echo "<meta http-equiv='refresh' content='0; index.php'/>"; }

else{
$name=$_SESSION['log'];

$ck2=(mysql_query("SELECT* FROM Active5 WHERE  Name='{$name}'"));
if(mysql_num_rows($ck2)==0)
{
$su2=(mysql_query("SELECT* FROM User WHERE Name='{$name}'"));
while($su=mysql_fetch_array($su2))
{
$photo=$su['Photo'];
$website=$su['Website'];
$count='1';

 mysql_query("INSERT INTO Active5(Name,Photo,Website,Count) VALUES ('{$name}','{$photo}','{$website}','{$count}')");  
 mysql_query("INSERT INTO Login5(Name,Photo,Website) VALUES ('{$name}','{$photo}','{$website}')");  
 echo "<meta http-equiv='refresh' content='0; uindex.php'/>"; 
}
}

else{ 
$su4=(mysql_query("SELECT* FROM Active5 WHERE Name='{$name}'"));
while($su3=mysql_fetch_array($su4))
{
$photo=$su3['Photo'];
$website=$su3['Website'];
$count2=$su3['Count'];
$count=floor($count2+1);

 mysql_query("UPDATE Active5 SET Count='{$count}' WHERE Name='{$name}'");  
 mysql_query("INSERT INTO Login5(Name,Photo,Website) VALUES ('{$name}','{$photo}','{$website}')");  
 echo "<meta http-equiv='refresh' content='0; uindex.php'/>"; 
}
}

}
?>
<?php
include "footer.php";
?>