<?php
include "config.php";
?>
<?php
include "header.php";
?>
<?php
echo "<meta http-equiv='refresh' content='0;url=index.php' />"; 
session_destroy();
?>
<?php
include "footer.php";
?>