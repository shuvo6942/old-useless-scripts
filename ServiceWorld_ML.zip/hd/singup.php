<?php
include "config.php";
?>
<?php
include "header.php";
?>
<?php 
if(isset($_SESSION['log']))
{ echo "<meta http-equiv='refresh' content='0; index.php'/>";}

else{ if(isset($_POST['submit']))
{
$name=($_POST['name']);
$email=($_POST['email']);
$website=($_POST['website']);
$phone=($_POST['phone']);
$pin=($_POST['pin']);
$pass=($_POST['pass']);
$pass2=($_POST['pass2']);

if( empty($name) || empty($email) || empty($website) || empty($phone) || empty($pin) || empty($pass) || empty($pass2))
{
$notice="<div class='error'>Required All Filed</div>";}
else{

if(strlen($name)>20||strlen($name)<5)
{ $notice="<div class='error'>Name Must Be Between 5 to 20 Characters</div>"; }
else{

if(strlen($pass)>20||strlen($pass)<5)
{ $notice="<div class='error'>Pass Must Be Between 5 to 20 Characters</div>"; }
else{
if(!filter_var($email, FILTER_VALIDATE_EMAIL))
{ 
$notice="<div class='error'>Invalid Email Address</div>"; }
else{
if(!$pass==pass2)
{ 
$notice="<div class='error'>Pass Does Not Match</div>"; }

else{
$ckn=(mysql_query("SELECT * FROM User WHERE Name='{$name}'"));
if(mysql_num_rows($ckn)==1)
{ 
$notice="<div class='error'>$name Already Exit</div>"; }

else{
$ckn=(mysql_query("SELECT * FROM User WHERE Email='{$email}'"));
if(mysql_num_rows($ckn)==1)
{ 
$notice="<div class='error'>$email Already Exit</div>"; }

else{
$date=date("d F Y");
$photo="http://$domain/photo/up.jpg";
$au=(mysql_query("INSERT INTO User(Name,Email,Pass,Website,Date,Photo,Phone,Pin) VALUES('{$name}','{$email}','{$pass}','{$website}','{$date}','{$photo}','{$phone}','{$pin}')"));
if($au)
{
mysql_query("INSERT INTO Reg5(Name,Photo,Date) VALUES ('{$name}','{$photo}','{$date}')");

$from="From: $domain<$admin_email>\r\nReturn-path:$admin_email";
$subject="Successfully Registration";
$message="Dear $name,

Welcome to our website. Thank you for joining. 

Your Cpanel: 
Name: $name
Pass: $pass 
Your Detail: 
Website: $website 
Email: $email 
Phone: $phone 
Pin: $pin 

Thank you.
$domain";
mail($email, $subject, $message, $from);

 echo "<meta http-equiv='refresh' content='0; csingup.php'/>";
$notice="<div class='success'>$name Successfully Registration</div>";
$_SESSION['log']=$name; 
}}}}}
}}}}
echo "<div class='border'><div class='title'>Registration</div> $notice 
<form action='' method='post'>
<div class='bottom'> Name: <br/><input type='text' name='name'/></div>
<div class='bottom'> Email: <br/><input type='text' name='email' value='@'/></div>
<div class='bottom'> Website: <br/><input type='text' name='website'/></div>
<div class='bottom'> Phone: <br/><input type='text' name='phone'/></div>
<div class='bottom'> Pin: <br/><input type='text' name='pin'/></div>
<div class='bottom'> Pass: <br/><input type='password' name='pass'/></div>
<div class='bottom'> Pass Verify: <br/><input type='password' name='pass2'/></div><div class='bottom'>* First Read Please Policy, Terms and Conditions. <center><input type='submit' name='submit' value='Singup'/></center></div></form></div>";
}
?>
<?php
include "footer.php";
?>
<?php
echo "<head><title> Registration </title>
<meta property='og:title' content='Registration'/>
<meta property='og:image' content='http://$domain/photo/sfb.png'/>
</head>";
?>