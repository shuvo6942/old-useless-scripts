<?php 

$db='a9284034_ftp';
$dbuser='a9284034_ftp';
$dbhost='mysql17.000webhost.com';
$dbpass='shuvo2';
$admin_name='shuvo';
$admin_pass='566258';
$admin_email='shuvo6942@gmail.com';
$site_name='Php Help Desk';

$sql=@mysql_connect("$dbhost","$dbuser","$dbpass");
if(!$sql)
{echo "Mysql connect failed";}
$dbc=mysql_select_db("$db");
if(!$dbc)
{echo "Database connect failed";}
session_start();
$domain=($_SERVER['HTTP_HOST']); 
?>
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<link rel="shortcut icon" href="photo/fb.png"/> <link rel="stylesheet" href="/style.css" type="text/css"/>