<?php

if(isset($_SESSION['admin']))
{ echo "<div class='bottom' align='right'>$admin_name(<a href='logout.php'>Log out</a>)</div>"; }  

if(isset($_SESSION['log']))
{
$name=$_SESSION['log'];
 echo "<table width='100%' class='bottom'><td width='20%'><a href='uindex.php'>Uindex</a></td><td width='80%' align='right'> $name(<a href='logout.php'>Log out</a>)</td></table>"; }  ?>

<div><div class="footer"><a href="contact.php"> Contact</a> || <a href="policy.php">Policy</a> || <a href="tc.php">Terms And Conditions</a> <br/><br/>
 All Rights
Reserved <br/> Copyright <?php
$d=date("Y");
 echo "$site_name $d"; ?>
</div></div>