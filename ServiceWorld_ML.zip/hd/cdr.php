<?php
include "config.php";
?>
<?php
include "header.php";
?>
<?php
echo "<div class='border'><div class='title'>Confirm to Delete a Reply</div>";
$id=($_GET['id']);

if(!isset($_GET['id']))
{ echo "<meta http-equiv='refresh' content='0; index.php'/>"; }
else{
if(!isset($_SESSION['log']))
{ echo "<meta http-equiv='refresh' content='0; index.php'/>"; }

else{
$ckl2=(mysql_query("SELECT * FROM Reply WHERE Id='{$id}'"));
if(mysql_num_rows($ckl2)==0)
{ echo "<div class='error'>Reply id invalid</div>"; }
else{
while($ckl=mysql_fetch_array($ckl2))
{
$name=$ckl['Name'];
$text=$ckl['Text'];
if(!$name==$_SESSION['log'])
{ echo "<div class='error'>You cannot delete this reply.</div>"; }

else { echo "<form action='dr.php' method='get'><div class='title'>Are you sure that you want to delete the reply: $text</div><br/><input type='submit' value='Yes' class='title'><input type='hidden' name='id' value='$id'></form>";
}
}}}}
?>
<?php
include "footer.php";
?>
<?php
echo "<head><title>Confirm to Delete Reply </title>
<meta property='og:title' content='Confirm to Delete Reply'/>
<meta property='og:image' content='http://$domain/hd/photo/sfb.png'/>
</head>";
?>