<?php
include "config.php";
?>
<?php
include "header.php";
?>
<?php
if(!isset($_SESSION['log']))
{ echo "<meta http-equiv='refresh' content='0; index.php'/>"; }

else{
$name=$_SESSION['log'];

$se=(mysql_query("SELECT * FROM User WHERE Name='{$name}'"));
while($se2=mysql_fetch_array($se))
{
$email=$se2['Email'];
$pass=$se2['Pass'];
$pin=$se2['Pin']; 

if(send==($_POST['pin']))
{ 

$from="From: $domain<$admin_email>\r\nReturn-path:$admin_email";
$subject="Your Pin Code";
$message="Dear $name,

Thank you for using $domain. 

Your pin code is $pin . 

Note: It is important sucurity for your account so be carefull.

Thank you.
$domain";
mail($email, $subject, $message, $from);
 $notice="<div class='success'>We send your pin in your email please check your email inbox or spam folder</div>"; }


if(isset($_POST['submit']))
{
$nemail=($_POST['nemail']);
$npass=($_POST['npass']);
$npin=($_POST['npin']);
$cpin=($_POST['cpin']);

if( empty($nemail) || empty($npass) || empty($npin) || empty($cpin))
{ $notice="<div class='error'>All Field Required</div>"; }

else{
if($cpin!==$pin)
{ $notice="<div class='error'>Your Pin Is Wrong</div>"; }

else{


if(!filter_var($nemail, FILTER_VALIDATE_EMAIL))
{ $notice="<div class='error'>New Email Is Invalid</div>"; }

else{
if( strlen($npass)<5 || strlen($npass)>20)
{ $notice="<div class='error'>Password Must Be Between 5 to 20 Characters</div>"; }

else{

$us=(mysql_query("UPDATE User SET Email='{$nemail}',Pass='{$npass}',Pin='{$npin}' WHERE Name='{$name}'"));

if(!$us)
{ $notice="<div class='error'>Security Change Failed</div>"; }

else{ $notice="<div class='success'>Security Success Fully Change</div>"; 
$email=$nemail;
$pass=$npass;
$pin=$npin;
}


}}}}}}


echo "<div class='border'><div class='title'>Change Security</div> $notice 
<form action='' method='post'>
<div class='bottom'>
New Email: <br/>
<input type='text' name='nemail' value='$email'/>
New Pass: <br/>
<input type='password' name='npass' value='$pass'/>
New Pin: <br/>
<input type='password' name='npin' value='$pin'/>
</div>
<div class='bottom'>
Your Pin: <br/>
<input type='text' name='cpin'/></div>
<div class='bottom' align='center'><input type='submit' name='submit' value='Edit'/></div></form>
<form action='' method='post'>
<div class='bottom' align='center'><input type='submit' name='pin' value='Lost Pin'/></div></form>
</div>";
}
?>
<?php
include "footer.php";
?>
<?php
echo "<head><title> Change Security </title>
<meta property='og:title' content='Change Security'/>
<meta property='og:image' content='http://$domain/hd/photo/sfb.png'/>
</head>";
?>