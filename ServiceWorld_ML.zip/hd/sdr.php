<?php
include "config.php";
?>
<?php
include "header.php";
?>
<?php
echo "<div class='border'><div class='title'>Delete a Reply</div>";

if(!isset($_SESSION['log']))
{ echo "<meta http-equiv='refresh' content='0; index.php'/>"; }
else{ echo "<div class='title'>Reply deleted succesfully.</div>";
}
?>
<?php
include "footer.php";
?>
<?php
echo "<head><title> Delete Reply </title>
<meta property='og:title' content='Delete Reply'/>
<meta property='og:image' content='http://$domain/hd/photo/sfb.png'/>
</head>";
?>