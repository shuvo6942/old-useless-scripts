<?php
include "config.php";
?>
<?php
include "header.php";
?>
<?php

if(!isset($_SESSION['log']))
{ echo "<meta http-equiv='refresh' content='0; singup.php'/>";}

else{
$name=$_SESSION['log'];

if(isset($_POST['submit']))
{
$photo=($_POST['photo']);
if(empty($photo))
{ $notice="<div class='error'>Photo Url Empty</div>"; }

else{
$up=(mysql_query("UPDATE User SET Photo='{$photo}' WHERE Name='{$name}'"));
if(!$up)
{ $notice="<div class='error'>Profile Picture Set Up Failed</div>"; }

else{
mysql_query("UPDATE Reg5 SET Photo='{$photo}' WHERE Name='{$name}'");
 echo "<meta http-equiv='refresh' content='0; profile.php?u=$name'/>";

}
}
}
echo "<div class='border'><div class='title'>Set Up Profile Picture</div>
<div class='info'> 
$name Thank You For Registration Please Setup Your Profile Picture</div> $notice </div> <div class='bottom'> <img src='photo/up.jpg' height='80px' width='80px' class='frame'/><form action='' method='post'> Photo Url: <br/> <input type='text' name='photo' value='http://$domain/hd/photo/up.jpg'/>
<center><input type='submit' name='submit' value='Submit'></center></form></div></div>";

} ?>
<?php
include "footer.php";
?>
<?php
echo "<head><title> Registration Continue </title>
<meta property='og:title' content='Registration Continue'/>
<meta property='og:image' content='http://$domain/hd/photo/sfb.png'/>
</head>";
?>