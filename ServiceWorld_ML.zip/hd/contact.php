<?php
include "config.php";
?>
<?php
include "header.php";
?>
<?php
if(isset($_POST['submit']))
{
$name=($_POST['name']);
$email=($_POST['email']);
$subject=($_POST['subject']);
$text=($_POST['text']);

if( empty($name) || empty($email) || empty($subject) || empty($text))
{ $notice="<div class='error'>All Fields Required</div>"; }

else{


$from="From: $name<$email>\r\nReturn-path:$email";

mail($admin_email, $subject, $text, $from);

 $notice="<div class='success'>Email Successfully Send Thank You $name</div>"; 
}}

echo "<div class='border'><div class='title'>Contact</div>
$notice
<form action='' method='post'>
<div class='bottom'>
Name: <br/>
<input type='text' name='name'/></div>
<div class='bottom'>
Email: <br/>
<input type='text' name='email'/></div>
<div class='bottom'>
Subject: <br/>
<input type='text' name='subject'/></div>
<div class='bottom'>
Text: <br/>
<textarea type='text' name='text'></textarea></div>
<div class='bottom' align='center'>
<input type='submit' name='submit' value='Submit'/></div>
</form>
</div>";

?>
<?php
include "footer.php";
?>
<?php
echo "<head><title> Contact </title>
<meta property='og:title' content='Contact'/>
<meta property='og:image' content='http://$domain/photo/sfb.png'/>
</head>";
?>