<?php 
include "config.php"; ?> 
<?php 
include "header.php"; ?> 
<?php if(!isset($_SESSION['log'])) 
{ echo "<meta http-equiv='refresh' content='0; index.php'/>"; }  

else{ if(!isset($_GET['id'])) 
{ echo "<meta http-equiv='refresh' content='0; index.php'/>"; }  

else{ 
echo "<div class='border'><div class='title'>Edit Post</div>";   

$id=($_GET['id']);  

$ck2=(mysql_query("SELECT * FROM Post WHERE Id='{$id}'")); 
if(mysql_num_rows($ck2)==0) 
{ $notice="<div class='error'>Post Id Invalid</div>"; }  

else{ 
while($ck=mysql_fetch_array($ck2)) 
{ $name=$ck['Name']; 
 if(!$name==$_SESSION['log']) 
{ $notice="<div class='error'>You Cannot Edit This Post.</div>"; } 

else{ $title=$ck['Title']; $photo=$ck['Photo']; $post=$ck['Post'];  

if(isset($_POST['submit'])) 
{
$ntitle=($_POST['ntitle']);
$nphoto=($_POST['nphoto']);
$npost=($_POST['npost']);

if( empty($ntitle) || empty($nphoto) || empty($npost))
{ $notice="<div class='error'>Required All Field</div>"; }

else{
$ul2=(mysql_query("UPDATE Post SET Title='{$ntitle}',Photo='{$nphoto}',Post='{$npost}' WHERE Title='{$title}' AND Post='{$post}'"));

if(!$ul2)
{ $notice="<div class='error'>Post Edit Failed</div>"; } 

else{
echo "<meta http-equiv='refresh' content='0; uindex.php'/>";
}}}}}} 

echo "<form action='' method='post'> $notice  <div class='bottom'> Title: <br/> <input type='text' name='ntitle' value='$title'/></div>  <div class='bottom'> Photo url: <br/> <input type='text' name='nphoto' value='$photo'/></div>  <div class='bottom'> Text: <br/> <input type='text' name='npost' value='$post'/></div>  <div class='bottom' align='center'> <input type='submit' name='submit' value='Edit'/></div></form>";  

echo "</div>"; 
}} ?>
<?php
include "footer.php"; ?>  
<?php
echo "<head><title> Edit Post </title>
<meta property='og:title' content='Edit Post'/>
<meta property='og:image' content='http://$domain/hd/photo/sfb.png'/>
</head>";
?>