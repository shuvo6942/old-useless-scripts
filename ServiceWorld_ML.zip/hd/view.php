<?php
include "config.php";
?>
<?php
include "header.php";
?>
<?php
if(!isset($_GET['id']))
{ echo "<meta http-equiv='refresh' content='0; index.php'/>"; }
else{
$id=($_GET['id']);
$cki=(mysql_query("SELECT * FROM Post WHERE Id='{$id}'"));
if(mysql_num_rows($cki)==0)
{ echo "<meta http-equiv='refresh' content='0; index.php'/>"; }

else{
while($ck=mysql_fetch_array($cki))
{
$post=$ck['Post'];
$name=$ck['Name'];
$date=$ck['Date'];
$id=$ck['Id'];
$count2=$ck['Count'];
$count=floor($count2+1);
$title=$ck['Title'];
$image=$ck['Photo'];

echo "<head>";
echo "<meta property='og:image' content='$image'/>";
echo  "<meta property='og:title' content='$title'/>";
echo "<title> $title </title>";
echo "</head>";
mysql_query("UPDATE Post SET Count='{$count}' WHERE Post='{$post}'");


echo "<div class='title' align='left'>Post Title: $title<br/>Posted By: $name On: $date Total Views: $count
</div><br/><div class='bottom' align='left'>$post
</div>";
if($name==$_SESSION['log'])
{ echo "<div class='title'><a href='/hd/edit_post.php?id=$id'> Edit Post </a></div><div class='title'><a href='/hd/delete_post.php?id=$id'> Delete Post </a></div><br/>"; }
}
$id = $_GET['id'];
$reply=(mysql_query("SELECT * FROM Reply WHERE Pid='{$id}'"));
while($ck=mysql_fetch_array($reply))
{ $post=$ck['Text'];
$name=$ck['Name'];
$date=$ck['Date'];
$id=$ck['Id'];
echo "<div class='border'><div class='title'>Replys of This Post: </div><br/>
<div class='bottom'> Reply By: $name On: $date<br/></div><div class='bottom' align='left'>$post</div></div><br/>";
if($name==$_SESSION['log'])
{ echo "<div class='title'><a href='/hd/er.php?id=$id'> Edit Reply </a></div><div class='title'><a href='/hd/cdr.php?id=$id'> Delete Reply </a></div>"; }
}

$name=$_SESSION['log'];
if(isset($_POST['submit']))
{
$date=date("d F Y");
$pid=($_GET['id']);
$text=($_POST['text']);
$count='0';
if( empty($text))
{ $notice="<div class='error'>Please enter text to reply.</div>"; }


else{
$ul=(mysql_query("INSERT INTO Reply(Text,Name,Pid,Date) VALUES('{$text}','{$name}','{$pid}','{$date}')"));
if(!$ul)
{
 $notice="<div class='error'>Failed To Add Reply Try Again</div>"; 
}
else{
echo "<meta http-equiv='refresh' content='0; '/>";
 $notice="<div class='error'>Reply Successfully Added</div>";
}
}
}
}
if(isset($_SESSION['log']))
{
echo "<br/><div class='border'><div class='title'>$notice<br/>Quick Reply</div> $notice <form action='' method='post'><div class='bottom'> Reply To This Post: <br/><input type='text' name='text' value=''/></div><div class='bottom' align='center'> <input type='submit' name='submit' value='Submit'/></div></form></div>";
}
else {
echo "<br/><div class='error' align='center'>You can't add a Reply.Please <a href='/hd/login.php'>Login</a> or <a href='/hd/singup.php'>Register</a> to add a reply.Thank You.</div>";
}
}
?>
<?php
include "footer.php";
?>