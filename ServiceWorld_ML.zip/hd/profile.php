<?php
include "config.php";
?>
<?php
include "header.php";
?>
<?php
if(!isset($_GET['u']))
{ echo "<meta http-equiv='refresh' content='0; index.php'/>"; }

else{
$name=($_GET['u']);
$cku=(mysql_query("SELECT * FROM User WHERE Name='{$name}'"));
if(mysql_num_rows($cku)==0)
{ echo "<meta http-equiv='refresh' content='0; index.php'/>"; }

else{
while($su=mysql_fetch_array($cku))
{
$photo=$su['Photo'];
$website=$su['Website'];
$email=$su['Email'];
$phone=$su['Phone'];
$date=$su['Date'];


$lc2=(mysql_query("SELECT * FROM Active5 WHERE Name='{$name}'"));
while($lc=mysql_fetch_array($lc2))
{ $count=$lc['Count']; }

echo "<div class='border'><div class='title'>Profile of $name</div><table width='100%' class='bottom'><tr><td width='25%'><img src='$photo' width='50px' height='50px' alt='$name'/></td><td><b> $name <br/> $website </b></td></tr></table>
<div class='bottom'> Email: $email </div>
<div class='bottom'> Phone: $phone </div>
<div class='bottom'> Registration: $date </div>
<div class='bottom'> Total Login: $count </div></div>";
if($name==$_SESSION['log'])
{ echo "<div class='bottom' align='right'><a href='eprofile.php'>Edit Profile</a></div>"; }
 
if(isset($_SESSION['admin']))
{ echo "<div class='bottom' align='right'><a href='profile.php?u=$name&block=$name'>Block User</a></div><div class='bottom' align='right'><a href='profile.php?u=$name&delete=$name'>Delete User</a></div>"; 

if(isset($_GET['block']))
{ $name=($_GET['block']);
$bl=(mysql_query("UPDATE User SET Type='block' WHERE Name='{$name}'"));
if($bl)
{ echo "<div class='error'>$name Successfully Blocked</div>"; }}

if(isset($_GET['delete']))
{ $name=($_GET['delete']);
$dl=(mysql_query("DELETE FROM User WHERE Name='{$name}'"));
if($dl)
{

mysql_query("DELETE FROM Reg5 WHERE Name='{$name}'");
mysql_query("DELETE FROM Login5 WHERE Name='{$name}'");
mysql_query("DELETE FROM Active5 WHERE Name='{$name}'"); 
echo "<div class='error'>$name Successfully delete</div>"; 
}}}}}}
?>
<?php
include "footer.php";
?>
<?php
echo "<head><title> $name </title>
<meta property='og:title' content='$name'/>
<meta property='og:image' content='http://$domain/photo/sfb.png'/>
</head>";
?>