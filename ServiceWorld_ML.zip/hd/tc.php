<?php
include "config.php";
?>
<?php
include "header.php";
?>
<?php

echo "<div class='border'><div class='title'>Terms And Conditions Of $site_name</div>
<div style='padding:8px; color: red; font-size: large;'>
১. আমরা স্পাম সমর্থন করিনা কোন অশ্লীন ফটো বা টাইটেল দিয়ে পোস্ট অথবা কোন ব্যক্তি, ধর্ম বা দল এর বিরুদ্ধে অবৈধ কোন পোস্ট তৈরি করলে তা ডিলিট করা হবে।<br/> 
২. একই সদস্য একাধিক বার স্পাম পোস্ট তৈরি করলে ঐ সদস্যকে ব্লক করা হবে।<br/> 
৩. ব্লক করা কোন সদস্যকে প্রয়োজনে ডিলিট করা হবে কিন্তু একটিভ করা হবেনা।<br/> 
৪. ব্লক এর কবলে না পরতে চাইলে স্পাম এড়িয়ে চলুন এবং প্রোফাইলে সঠিক তথ্য সংরক্ষণ করুন।
</div></div>";

?>
<?php
include "footer.php";
?>
<?php
echo "<head><title> Terms And Conditions </title>
<meta property='og:title' content='Terms And Conditions'/>
<meta property='og:image' content='http://$domain/photo/sfb.png'/>
</head>";
?>