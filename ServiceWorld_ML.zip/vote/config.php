<?php




$top = '<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<title>ServiceWorld.ML Voting Poll</title>
<link rel="stylesheet" type="text/css" href="style.css"/>
</head>
<body>
<div class="w">
VOTING POLL<br/>
</div>';

//
$foot = '</body>
</html>';

// Votting Poll 1
$vote[0] = 'How do you think About us ?';
//  1
$answer[0][0] = 'Bad';
$answer[0][1] = 'Not Bad';
$answer[0][2] = 'Medium';
$answer[0][3] = 'Good';
$answer[0][4] = 'Very Good';



?>
