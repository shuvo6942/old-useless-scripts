<?php



require 'config.php';

if(substr_count($_SERVER['HTTP_USER_AGENT'], 'MSIE'))
{header('Content-type: text/html; charset=utf-8');}
else
{header('Content-type: application/xhtml+xml; charset=utf-8');}
header('Cache-control: no-cache');


print $top;

if($_POST)
{
$v = array_keys($_POST);
$v = intval($v[0]);
$i = intval($_POST[$v]);
$a = file('vote_'.$v.'.dat');

if(!$a)
{
for($t=0; $t<sizeof($answer[$v]); ++$t)
{$a[$t] = "0\n";}// string!
}

$a[$i] += 1;
$a[$i] .= "\n";
if(file_put_contents('vote_'.$v.'.dat',$a))
{exit('<div class="red">Thanks For Vote!<br/>

<a href="/vote">Back</a><br/>
</div>'.$foot);}
else
{exit('<div class="red">Sorry<br/></div>'.$foot);}
}

for($i=0; $i<sizeof($vote); ++$i)
{
$v = file('vote_'.$i.'.dat');

print '<fieldset>
<legend><b> '.$vote[$i].'  </b></legend>
<form action="?" method ="post">
<div>';
for($a=0; $a<sizeof($answer[$i]); ++$a)
{print '<input type="radio" name="'.$i.'" value="'.$a.'"/>'.$answer[$i][$a].' ('.intval($v[$a]).')<br/>';}

print '<br/><input type="submit" value="VOTE"/>
</div>
</form>
 Total Votes Caste: ('.array_sum($v).')
</fieldset>';
}


print $foot;
?>
