/****************************************************************
* This Is A Open Source Script by SERVICEWORLD Server            	*
*																*
* Script Created By: SHUVO AHMED           					*
*																*
* Mail to: shuvo6942@gmail.com									*
*																*
* http://www.serviceworld.ml				            		*
*****************************************************************/
function makeFrame() {
   ifrm = document.createElement("IFRAME"); 
   ifrm.setAttribute("src", "http://www.vaincode.com/widget");
   ifrm.setAttribute("frameborder", "0");
   ifrm.style.width = 225+"px";
   ifrm.style.height = 190+"px";
   document.body.appendChild(ifrm);
}
//document.write("<html><head></head><body onLoad=makeFrame()> </body></html>")
document.write("<iframe src=http://www.vaincode.com/widget/converter/index.php width=250 height=350 frameborder=0 scrolling=no></iframe>")