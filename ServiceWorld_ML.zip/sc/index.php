<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Scientific Calculator</title><link rel="STYLESHEET" type="text/css" href="http://wtools.gq/styles.css"/><link rel="shortcut icon" href="http://phptunes.com/favicon.ico"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/><style type="text/css">
body { background: ;
color: ;
}
a { color: ;
}
</style>
</head><body>







<script src="scicalc.js">
</script>
<font color=red>
<font color="red">Hint: </font>You can also type value in text input for easy use, eg. <font color="lime">250+70-120*5/15</font> then click <font color="red">"total"</font> to get result. !<br><br>
<center>

<FORM NAME="sci-calc" width="150">
<TABLE CELLSPACING="0" CELLPADDING="2">
<TR>
<TD COLSPAN="5" ALIGN="center">
<INPUT NAME="display" VALUE="0" SIZE="28" MAXLENGTH="25" style="background-color:#003300; color:red">
</TD>
</TR>
<TR>
<TD ALIGN="center">
<INPUT style="background:#000 url(b/gradg.png) repeat-x top; color:silver;" TYPE="button" VALUE="  sin  &nbsp;" ONCLICK="if (checkNum(this.form.display.value)) { sin(this.form) }" >
</TD>

<TD ALIGN="center">
<INPUT style="background:#000 url(b/gradg.png) repeat-x top; color:silver;" TYPE="button" VALUE="   1   " ONCLICK="addChar(this.form.display, '1')">
</TD>
<TD ALIGN="center">
<INPUT style="background:#000 url(b/gradg.png) repeat-x top; color:silver;" TYPE="button" VALUE="   2   " ONCLICK="addChar(this.form.display, '2')">
</TD>








<TD ALIGN="center">
<INPUT style="background:#000 url(b/gradg.png) repeat-x top; color:silver;" TYPE="button" VALUE="   3   " ONCLICK="addChar(this.form.display, '3')">
</TD>
<TD ALIGN="center">
<INPUT style="background:#000 url(b/gradg.png) repeat-x top; color:silver;" TYPE="button" VALUE=" &nbsp; + &nbsp; " ONCLICK="addChar(this.form.display, '+')">
</TD>
</tr>
<tr>
<TD ALIGN="center">
<INPUT style="background:#000 url(b/gradg.png) repeat-x top; color:silver;" TYPE="button" VALUE="  cos  " ONCLICK="if (checkNum(this.form.display.value)) { cos(this.form) }">
</TD>
<TD ALIGN="center">
<INPUT style="background:#000 url(b/gradg.png) repeat-x top; color:silver;" TYPE="button" VALUE="   4   " ONCLICK="addChar(this.form.display, '4')" >
</TD>
<TD ALIGN="center">
<INPUT style="background:#000 url(b/gradg.png) repeat-x top; color:silver;" TYPE="button" VALUE="   5   " ONCLICK="addChar(this.form.display, '5')" >
</TD>
<TD ALIGN="center">
<INPUT style="background:#000 url(b/gradg.png) repeat-x top; color:silver;" TYPE="button" VALUE="   6   " ONCLICK="addChar(this.form.display, '6')" >
</TD>
<TD ALIGN="center">
<INPUT style="background:#000 url(b/gradg.png) repeat-x top; color:silver;" TYPE="button" VALUE="   -   " ONCLICK="addChar(this.form.display, '-')" >
</TD>


<tr><TD ALIGN="center">
<INPUT style="background:#000 url(b/gradg.png) repeat-x top; color:silver;" TYPE="button" VALUE="  tan  " ONCLICK="if (checkNum(this.form.display.value)) { tan(this.form) }">
</TD>
<TD ALIGN="center">
<INPUT style="background:#000 url(b/gradg.png) repeat-x top; color:silver;" TYPE="button" VALUE="   7   " ONCLICK="addChar(this.form.display, '7')" >
</TD>
<TD ALIGN="center">
<INPUT style="background:#000 url(b/gradg.png) repeat-x top; color:silver;" TYPE="button" VALUE="   8   " ONCLICK="addChar(this.form.display, '8')">
</TD>
<TD ALIGN="center">
<INPUT style="background:#000 url(b/gradg.png) repeat-x top; color:silver;" TYPE="button" VALUE="   9   " ONCLICK="addChar(this.form.display, '9')" >
</TD>
<TD ALIGN="center">
<INPUT style="background:#000 url(b/gradg.png) repeat-x top; color:silver;" TYPE="button" VALUE="   x   " ONCLICK="addChar(this.form.display, '*')"></TD>
</tr>
<tr>
<TD ALIGN="center">
<INPUT style="background:#000 url(b/gradg.png) repeat-x top; color:silver;" TYPE="button" VALUE="sqrt " ONCLICK="if (checkNum(this.form.display.value)) { sqrt(this.form) }">
</TD>
<TD ALIGN="center">
<INPUT style="background:#000 url(b/gradg.png) repeat-x top; color:silver;" TYPE="button" VALUE="   &#177;   " ONCLICK="changeSign(this.form.display)" >
</TD>
</TD>
<TD ALIGN="center">
<INPUT style="background:#000 url(b/gradg.png) repeat-x top; color:silver;" TYPE="button" VALUE="   0   " ONCLICK="addChar(this.form.display, '0')">
</TD>
<TD ALIGN="center">
<INPUT style="background:#000 url(b/gradg.png) repeat-x top; color:silver;" TYPE="button" VALUE="    .    " ONCLICK="addChar(this.form.display, '.')">
</TD>



<TD ALIGN="center">
<INPUT style="background:#000 url(b/gradg.png) repeat-x top; color:silver;" TYPE="button" VALUE="   :   " ONCLICK="addChar(this.form.display, '/')" >
</TD>
</TR>
<TR>
<TD ALIGN="center">
<INPUT style="background:#000 url(b/gradg.png) repeat-x top; color:silver;" TYPE="button" VALUE="  sq2  " ONCLICK="if (checkNum(this.form.display.value)) { square(this.form) }">
</TD>
<TD ALIGN="center">







<INPUT style="background:#000 url(b/gradg.png) repeat-x top; color:silver;" TYPE="button" VALUE="   ln   " ONCLICK="if (checkNum(this.form.display.value)) { ln(this.form) }" >
</TD>

<TD ALIGN="center">


<INPUT style="background:#000 url(b/gradg.png) repeat-x top; color:silver;" TYPE="button" VALUE=" exp " ONCLICK="if (checkNum(this.form.display.value)) { exp(this.form) }">
</TD>
<TD ALIGN="center">
<INPUT style="background:#000 url(b/gradg.png) repeat-x top; color:silver;" TYPE="button" VALUE="   (   " ONCLICK="addChar(this.form.display, '(')">
</TD>
<TD ALIGN="center">
<INPUT style="background:#000 url(b/gradg.png) repeat-x top; color:silver;" TYPE="button" VALUE="   )   " ONCLICK="addChar(this.form.display, ')')">
</TD>
</TR>
<TR>
<TD ALIGN="center">
<INPUT style="background:#000 url(b/gradg.png) repeat-x top; color:silver;" TYPE="button" VALUE="clear" ONCLICK="this.form.display.value = 0 ">
</TD>
<TD ALIGN="center" COLSPAN="3">
<INPUT style="background:#000 url(b/gradg.png) repeat-x top; color:silver;" TYPE="button" VALUE="delete" ONCLICK="deleteChar(this.form.display)">
</TD>
<TD ALIGN="center"><INPUT  style="background:#000 url(b/gradg.png) repeat-x top; color:silver;" TYPE="button" VALUE="total" NAME="enter" ONCLICK="if (checkNum(this.form.display.value)) { compute(this.form) }"></TD></TR></TABLE></FORM><style>
body { width:330px; }
</style>
</span></div></body></html>