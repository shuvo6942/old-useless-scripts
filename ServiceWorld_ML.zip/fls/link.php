<?php
include "config.php";
?>
<?php
include "header.php";
?>
<?php

if(!isset($_GET['id']))
{ echo "<meta http-equiv='refresh' content='0; index.php'/>"; }

else{
$id=($_GET['id']);
$cki=(mysql_query("SELECT * FROM Link WHERE Id='{$id}'"));
if(mysql_num_rows($cki)==0)
{ echo "<meta http-equiv='refresh' content='0; index.php'/>"; }

else{
while($ck=mysql_fetch_array($cki))
{ $url=$ck['Url'];
$count2=$ck['Count'];
$count=floor($count2+1);
$title=$ck['Title'];
$image=$ck['Photo'];

echo "<head>";
echo "<meta property='og:image' content='$image'/>";
echo  "<meta property='og:title' content='$title'/>";
echo "<title> $title </title>";
echo "</head>";
mysql_query("UPDATE Link SET Count='{$count}' WHERE Url='{$url}'");

 echo "<meta http-equiv='refresh' content='0; $url'/>"; 
echo "<a href='$url'><div class='frame' align='center'>
You are auto redirect in soon if page hang please refresh or click here </div></a>";

}}}
?>
<?php
include "footer.php";
?>