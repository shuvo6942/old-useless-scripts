<?php 
include "config.php"; ?> 
<?php 
include "header.php"; ?> 
<?php 

if(!isset($_SESSION['log'])) 
{ echo "<meta http-equiv='refresh' content='0; index.php'/>"; }  

else{ 
$name=$_SESSION['log'];  

$sl2=(mysql_query("SELECT * FROM User WHERE Name='{$name}'")); 

while($sl=mysql_fetch_array($sl2)) 
{ 
$photo=$sl['Photo']; 
$website=$sl['Website']; 
$phone=$sl['Phone']; 
}  

if(isset($_POST['submit'])) 
{ 
$nphoto=($_POST['nphoto']); 
$nwebsite=($_POST['nwebsite']); 
$nphone=($_POST['nphone']);  

if( empty($nphoto) || empty($nwebsite) || empty($nphone)) 
{ $notice="<div class='error'>Required All Fields</div>"; }  

else{ 
mysql_query("UPDATE Reg5 SET Photo='{$nphoto}' WHERE Name='{$name}'");
mysql_query("UPDATE Login5 SET Photo='{$nphoto}',Website='{$nwebsite}' WHERE Name='{$name}'");
mysql_query("UPDATE Active5 SET Photo='{$nphoto}' WHERE Name='{$name}'");


$upu=(mysql_query("UPDATE User SET Photo='{$nphoto}',Website='{$nwebsite}',Phone='{$nphone}' WHERE Name='{$name}'")); 

if(!$upu) 
{ $notice="<div class='error'>Profile Edit Failed</div>"; }  

else{

echo "<meta http-equiv='refresh' content='0; profile.php?u=$name'/>";

}}}


echo "<div class='border'><div class='title'>Edit Profile</div><form action='' method='post'> $notice <div class='bottom'> Photo Url: <br/> <input type='text' name='nphoto' value='$photo'/></div> <div class='bottom'> Website: <br/> <input type='text' name='nwebsite' value='$website'/></div> <div class='bottom'> Phone: <br/> <input type='text' name='nphone' value='$phone'/></div> <div class='bottom' align='center'><input type='Submit' name='submit' value='Edit'/></div></form></div>";  
} ?>
<?php 
include "footer.php"; ?>
<?php
echo "<head><title> Edit Profile </title>
<meta property='og:title' content='Edit Profile'/>
<meta property='og:image' content='http://$domain/photo/sfb.png'/>
</head>";
?>