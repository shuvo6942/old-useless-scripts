<?php
include "config.php";
?>
<?php
include "header.php";
?>
<?php
if(isset($_SESSION['log']))
{ echo "<meta http-equiv='refresh' content='0; index.php'/>"; }

else{
if(isset($_POST['submit']))
{
$name=($_POST['name']);

$slu=(mysql_query("SELECT * FROM User WHERE Name='{$name}'"));
if(mysql_num_rows($slu)==0)
{ $notice="<div class='error'>User Name Wrong</div>"; }

else{
while($se=mysql_fetch_array($slu))
{
$email=$se['Email'];
$pass=$se['Pass'];

$from="From: $domain<$admin_email>\r\nReturn-path:$admin_email";
$subject="Your Password";
$message="Dear $name,

Thank you for using $domain .

Your Password Is $pass .

Login Link:
http://$domain/login.php

Note: It is important security for your account so be carefull. 

Thank you.
$domain";
mail($email, $subject, $message, $from);

$notice="<div class='success'>We send your password in your email please check your email inbox or spam folder.</div>";

}}}

echo "<div class='border'><div class='title'>Lost Password</div> $notice <form action='' method='post'><div class='bottom'>Name:<br/><input type='text' name='name'/></div><div class='bottom' align='center'><input type='submit' name='submit' value='Submit'/></div></form></div>";
}
?>
<?php
include "footer.php";
?>
<?php
echo "<head><title> Lost Password </title>
<meta property='og:title' content='Lost Password'/>
<meta property='og:image' content='http://$domain/photo/sfb.png'/>
</head>";
?>