<?php
include "config.php";
?>
<?php
include "header.php";
?>
<?php
if(!isset($_SESSION['log']))
{ echo "<meta http-equiv='refresh' content='0; index.php'/>"; }

else{
$name=$_SESSION['log'];

if(isset($_POST['submit']))
{
$date=date("d F Y");
$title=($_POST['title']);
$photo=($_POST['photo']);
$url=($_POST['url']);
$count='0';

if( empty($title) || empty($photo) || empty($url))
{ $notice="<div class='error'>Required All Fields</div>"; }

else{
if(strlen($title)<20)
{ $notice="<div class='error'>Title Must Be Between 20 to 250 Characters</div>"; }

else{
$ul=(mysql_query("INSERT INTO Link(Title,Photo,Url,Name,Date,Count) VALUES('{$title}','{$photo}','{$url}','{$name}','{$date}','{$count}')"));
if(!$ul)
{
 $notice="<div class='error'>Link Add Failed Try Again</div>"; 
}
else{
echo "<meta http-equiv='refresh' content='0; uindex.php'/>";
 $notice="<div class='error'>Link Successfully Add</div>";
}
}
}
}
echo "<div class='border'><div class='title'>Link Add</div> $notice <form action='' method='post'><div class='bottom'> Title: <br/><input type='text' name='title' value=''/></div><div class='bottom'> Photo Url: <br/><input type='text' name='photo' value='http://$domain/fls/photo/pna.jpeg'/></div><div class='bottom'> Link Url: <br/><input type='text' name='url' value=''/></div><div class='bottom' align='center'> <input type='submit' name='submit' value='Submit'/></div></form></div>";

} ?>
<?php
include "footer.php";
?>
<?php
echo "<head><title> Add Link </title>
<meta property='og:title' content='Add Link'/>
<meta property='og:image' content='http://$domain/fls/photo/sfb.png'/>
</head>";
?>