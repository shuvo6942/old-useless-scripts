<div><div
class="logo"><table
width="100%"><tbody><tr><td><a
href="index.php"> <?php echo "$site_name"; ?></a><span style="float:right"><img
src="http://ftariful.mobie.in/icon/menu.png" alt="="
width="22px"
height="15px"></span></td></tr></tbody></table></div></div>

<?php
if(!isset($_SESSION['log']))
{ echo "<r><table width='100%' class=''><td width='50%' class='frame'><a href='login.php'><div align='center'> Login </div></a></td><td width='50%' class='frame'><a href='singup.php'><div align='center'> Registration </div></a></td></table></r>"; }

else{
 echo "<r><div class='frame'><a href='uindex.php'><div align='center'> Uindex </div></a></div></r>";
}
?>


<div><div style="text-
align:center; padding:20px;"><div
style="color:#333333;
background-color:#ffffff; border:1px solid #cccccc; display:inline-block; text-shadow:0px 1px #ffffff; padding:3px;" align="center"> This Concept For Facebook Smart Link Share.</div></div></div>