<?php 
include "config.php"; ?> 
<?php 
include "header.php"; ?> 
<?php if(!isset($_SESSION['log'])) 
{ echo "<meta http-equiv='refresh' content='0; index.php'/>"; }  

else{ if(!isset($_GET['id'])) 
{ echo "<meta http-equiv='refresh' content='0; index.php'/>"; }  

else{ 
echo "<div class='border'><div class='title'>Edit Link</div>";   

$id=($_GET['id']);  

$ck2=(mysql_query("SELECT * FROM Link WHERE Id='{$id}'")); 
if(mysql_num_rows($ck2)==0) 
{ $notice="<div class='error'>Link Id Invalid</div>"; }  

else{ 
while($ck=mysql_fetch_array($ck2)) 
{ $name=$ck['Name']; 
 if(!$name==$_SESSION['log']) 
{ $notice="<div class='error'>You Cannot Edit This Link</div>"; } 

else{ $title=$ck['Title']; $photo=$ck['Photo']; $url=$ck['Url'];  

if(isset($_POST['submit'])) 
{
$ntitle=($_POST['ntitle']);
$nphoto=($_POST['nphoto']);
$nurl=($_POST['nurl']);

if( empty($ntitle) || empty($nphoto) || empty($nurl))
{ $notice="<div class='error'>Required All Field</div>"; }

else{
$ul2=(mysql_query("UPDATE Link SET Title='{$ntitle}',Photo='{$nphoto}',Url='{$nurl}' WHERE Title='{$title}' AND Url='{$url}'"));

if(!$ul2)
{ $notice="<div class='error'>Link Edit Failed</div>"; } 

else{
echo "<meta http-equiv='refresh' content='0; uindex.php'/>";
}}}}}} 

echo "<form action='' method='post'> $notice  <div class='bottom'> Title: <br/> <input type='text' name='ntitle' value='$title'/></div>  <div class='bottom'> Photo url: <br/> <input type='text' name='nphoto' value='$photo'/></div>  <div class='bottom'> Link url: <br/> <input type='text' name='nurl' value='$url'/></div>  <div class='bottom' align='center'> <input type='submit' name='submit' value='Edit'/></div></form>";  

echo "</div>"; 
}} ?>
<?php
include "footer.php"; ?>  
<?php
echo "<head><title> Edit Link </title>
<meta property='og:title' content='Edit Link'/>
<meta property='og:image' content='http://$domain/photo/sfb.png'/>
</head>";
?>