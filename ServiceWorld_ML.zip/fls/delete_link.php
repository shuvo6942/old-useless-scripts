<?php
include "config.php";
?>
<?php
include "header.php";
?>
<?php
echo "<div class='border'><div class='title'>Link Delete</div>";

if(!isset($_GET['id']))
{ echo "<meta http-equiv='refresh' content='0; index.php'/>"; }
else{
$id=($_GET['id']);

if(isset($_SESSION['admin']))
{
$dla=(mysql_query("DELETE FROM Link WHERE Id='{$id}'"));
if($dla)
{ echo "<meta http-equiv='refresh' content='0; index.php'/>"; }
else{ echo "<div class='error'>Link Delete Failed</div>"; }
}

else{
if(!isset($_SESSION['log']))
{ echo "<meta http-equiv='refresh' content='0; index.php'/>"; }

else{
$ckl2=(mysql_query("SELECT * FROM Link WHERE Id='{$id}'"));
if(mysql_num_rows($ckl2)==0)
{ echo "<div class='error'>Link id invalid</div>"; }

else{
while($ckl=mysql_fetch_array($ckl2))
{
$name=$ckl['Name'];

if(!$name==$_SESSION['log'])
{ echo "<div class='error'>You cannot delete this link</div>"; }

else{
$ldu=(mysql_query("DELETE FROM Link WHERE Id='{$id}'"));
if($ldu)
{ echo "<meta http-equiv='refresh' content='0; uindex.php'/>"; }

else{ echo "<div class='error'>Link delete failed</div>"; }
}}}}}}
echo "</div>"; ?>
<?php
include "footer.php";
?>
<?php
echo "<head><title> Delete Link </title>
<meta property='og:title' content='Delete Link'/>
<meta property='og:image' content='http://$domain/photo/sfb.png'/>
</head>";
?>