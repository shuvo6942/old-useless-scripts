<?php 
include "config.php"; 
?>
<?php 
include "header.php"; 
?>


<?php

echo "<div class='border'><div class='title'>Links</div>";

$page=($_GET['page']);
if(empty($page))
{ $page='1'; }
$pv=floor($page-1);
$p1=floor($pv*15);
$p2=floor($pv*15+15);

$ck2=(mysql_query("SELECT * FROM Link ORDER BY Id DESC LIMIT $p1,$p2"));
while($ck=mysql_fetch_array($ck2))
{
$name=$ck['Name'];
$title=$ck['Title'];
$photo=$ck['Photo'];
$url=$ck['Url'];
$date=$ck['Date'];
$count=$ck['Count'];
$id=$ck['Id'];

echo "<div class='bottom'> Link add by <a href='profile.php?u=$name'><font color='black'>$name</font></a> on $date Total view $count <a href='link.php?id=$id'><table width='100%' class='frame'><tr>
<td width='25%'> <img src='$photo' height='50px' width='50px' class='frame'/></td><td width='75%'><b><font color='black'> $title </font></b></td></tr></table></a>
<div><input type='text' value='http://$domain/fls/link.php?id=$id'/></div>
<table width='100%'><td width='50%' class='frame'><a href='http://facebook.com/share.php?u=http://$domain/fls/link.php?id=$id'><div align='center'><font color='black'> Share </font></div></a></td><td width='50%' class='frame'><a href='http://$domain/fls/link.php?id=$id'><div align='center'><font color='black'> View </font></div></a></td></table></div>";

if(isset($_SESSION['admin']))
{ echo "<div class='bottom' align='center'><a href='delete_link.php?id=$id'>Delete Link</a></div>";
}}

$page2=floor($page+1);
echo "<div class='bottom' align='center'><a href='?page=$page2'>See More Link</a></div></div>";


?>
<?php

echo "<div class='border'><div class='title'>Most 5 Active User</div>";
$ac1=(mysql_query("SELECT * FROM Active5 ORDER BY Count DESC LIMIT 0,5"));
while($ac=mysql_fetch_array($ac1))
{
$name=$ac['Name'];
$photo=$ac['Photo'];
$count=$ac['Count'];
echo "<table width='100%' class='bottom'><tr><td width='25%'><img src='$photo' height='40px' width='40px' alt='$name' class='frame'/></td><td width='75%'><a href='profile.php?u=$name'><font color='black'> $name </font></a><br/>Login $count Time</td></tr></table>";
}
echo "</div>";
?>

<?php

echo "<div class='border'><div class='title'>Last 5 Loged User</div>";
$log6=(mysql_query("SELECT * FROM Login5 ORDER BY Id DESC LIMIT 0,5"));
while($log5=mysql_fetch_array($log6))
{
$name=$log5['Name'];
$photo=$log5['Photo'];
$website=$log5['Website'];
echo "<table width='100%' class='bottom'><tr><td width='25%'><img src='$photo' height='40px' width='40px' alt='$name' class='frame'/></td><td width='75%'><a href='profile.php?u=$name'><font color='black'> $name </font></a><br/> $website </td></tr></table>";
}
echo "</div>";
?>
<?php

echo "<div class='border'><div class='title'>Last 5 Registered User</div>";
$l5r=(mysql_query("SELECT * FROM Reg5 ORDER BY Id DESC LIMIT 0,5"));
while($l5=mysql_fetch_array($l5r))
{
$name=$l5['Name'];
$photo=$l5['Photo'];
$date=$l5['Date'];
echo "<table width='100%' class='bottom'><tr><td width='25%'><img src='$photo' height='40px' width='40px' alt='$name' class='frame'/></td><td width='75%'><a href='profile.php?u=$name'><font color='black'> $name </font></a><br/> $date </td></tr></table>";
}
echo "</div>";
?>
<?php

$cu2=(mysql_query("SELECT * FROM User"));
$cu=(mysql_num_rows($cu2));


$bu2=(mysql_query("SELECT * FROM User WHERE Type='block'"));
$bu=(mysql_num_rows($bu2));


$li2=(mysql_query("SELECT * FROM Link"));
$li=(mysql_num_rows($li2));

echo "<div class='border'><div class='title'>Info</div>
<div class='bottom'> Total user: $cu </div>
<div class='bottom'>
Block user: $bu </div>
<div class='bottom'> Total link: $li </div></div>";

?>
<?php 
include "footer.php"; 
?><?php
echo "<head><title>  $site_name - This concept for fb smart link share </title>
<meta property='og:title' content='$site_name - This concept for fb smart link share'/>
<meta property='og:image' content='http://$domain/photo/sfb.png'/>
</head>";
?>