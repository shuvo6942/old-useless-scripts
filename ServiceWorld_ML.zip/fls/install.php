<?php 
include "config.php"; ?>
<?php 
include "header.php"; ?>
<?php

if(isset($_POST['submit']))
{

$u="CREATE TABLE User( Id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, 
Name TEXT NOT NULL,
Email TEXT NOT NULL,
Pass TEXT NOT NULL,
Date TEXT NOT NULL,
Photo TEXT NOT NULL,
Website TEXT NOT NULL, 
Phone TEXT NOT NULL, 
Pin TEXT NOT NULL, 
Type TEXT NOT NULL)";
if(mysql_query($u))
{ $us='User Table Successfully Create'; }
else{ $uf=''. mysql_error() . ''; }


$l="CREATE TABLE Link ( Id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
Title TEXT NOT NULL,
Photo TEXT NOT NULL,
Url TEXT NOT NULL,
Name TEXT NOT NULL,
Date TEXT NOT NULL,
Count INT NOT NULL)";
if(mysql_query($l))
{ $ls='Link Table Successfully Create'; }
else{ $lf=''. mysql_error() . ''; }


$l5="CREATE TABLE Login5 ( Id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,  
Name TEXT NOT NULL, 
Photo TEXT NOT NULL, 
Website TEXT NOT NULL)";
if(mysql_query($l5))
{ $l5s='Login5 Table Successfully Create'; }
else{ $l5f=''. mysql_error() . ''; }


$r5="CREATE TABLE Reg5 ( Id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,  
Name TEXT NOT NULL, 
Photo TEXT NOT NULL, 
Date TEXT NOT NULL)";
if(mysql_query($r5))
{ $r5s='Reg5 Table Successfully Create'; }
else{ $r5f=''. mysql_error() . ''; }


$a5="CREATE TABLE Active5 ( Id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,  
Name TEXT NOT NULL, 
Photo TEXT NOT NULL, 
Website TEXT NOT NULL,
Count INT NOT NULL)";
if(mysql_query($a5))
{ $a5s='Active5 Table Successfully Create'; }
else{ $a5f=''. mysql_error() . ''; }


echo "<div class='border'><div class='title'>Install</div>
<div class='bottom'> 1. <font color='green'>$us</font> <font color='red'>$uf</font></div>
<div class='bottom'> 2. <font color='green'>$ls</font> <font color='red'>$lf</font></div>
<div class='bottom'> 3. <font color='green'>$l5s</font> <font color='red'>$l5f</font></div>
<div class='bottom'> 4. <font color='green'>$r5s</font> <font color='red'>$r5f</font></div>
<div class='bottom'> 5. <font color='green'>$a5s</font> <font color='red'>$a5f</font></div>
<div class='bottom' align='center'> <a href='admin.php'>Click Here For Admin Panel</a> </div></div>";
}
if(!isset($_POST['submit']))
{

echo "<div class='border'><div class='title'>Install</div><div class='bottom'> Click Here For Install</div><div class='bottom' align='center'><form action='' method='post'><input type='submit' value='submit' name='submit'/></form></div></div>"; 


} ?>
<?php 
include "footer.php"; ?>