<?php
include "config.php";
?>
<?php
include "header.php";
?>
<?php

echo "<div class='border'><div class='title'>Policy Of $site_name</div>
<div style='padding:8px; color: green; font-size: large;'>
১. আপনার ওয়েব সাইটের সুন্দর পাবলিশিং এ সহায়তা করাই আমাদের একমাত্র উদ্দেশ্য। <br/> 
২. সুবিধা সমূহ ভোগ করতে আপনার অবশ্যই আমাদের ওয়েব সাইটে একাউন্ট থাকতে হবে।<br/> 
৩. কোন সমস্যার সম্মুখীন হলে সরাসরি <a href='contact.php'>Contact</a> এ জানাবেন।<br/> 
৪. অবাধ সুবিধা ভোগ করতে আমাদের <a href='tc.php'>Terms And Contions</a> পড়ে নিন। </div></div>";

?>
<?php
include "footer.php";
?>
<?php
echo "<head><title> Policy </title>
<meta property='og:title' content='Policy'/>
<meta property='og:image' content='http://$domain/photo/sfb.png'/>
</head>";
?>