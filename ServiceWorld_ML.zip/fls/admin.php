<?php
include "config.php";
?>
<?php
include "header.php";
?>
<?php
if(isset($_SESSION['admin']))
{ echo "<meta http-equiv='refresh' content='0; index.php'/>";}

else{
if(isset($_POST['submit']))
{
$name=($_POST['name']);
$pass=($_POST['pass']);

if( empty($name) || empty($pass))
{ $notice="<div class='error'>Required All Fields</div>"; }

else{ 
if(!$admin_name==$name)
{ $notice="<div class='error'>Name Wrong</div>"; }

else{ 
if(!$admin_pass== $pass)
{ $notice="<div class='error'>Pass Wrong</div>"; }
else{
$_SESSION['admin']=$name;

echo "<meta http-equiv='refresh' content='0; index.php'/>";

}}}}
echo "<div class='border'><div class='title'>Admin Panel</div> $notice <form action='' method='post'><div class='bottom'>Name: <br/><input type='text' name='name'/> Pass: <br/><input type='password' name='pass'/><center><input type='submit' name='submit' value='Login'/><center></div></form></div>";
}
?>
<?php
include "footer.php";
?>
<?php
echo "<head><title> Admin Panel </title>
<meta property='og:title' content='Admin Panel'/>
<meta property='og:image' content='http://$domain/photo/sfb.png'/>
</head>";
?>