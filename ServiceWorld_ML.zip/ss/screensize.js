<!--
if(self.screen){width=screen.width
height=screen.height}
else if(self.java){var javakit=java.awt.Toolkit.getDefaultToolkit();var scrsize=javakit.getScreenSize();width=scrsize.width;height=scrsize.height;}
else{width=height='?'}
document.write(" "+ width+"x"+ height)