<?php

//====================================================================================================//
//                         PHP GRABBER SCRIPT GENERATOR v1.2                                          //
//  Scripted By:                                                                                      //
//          _________                      __  .__    .__                                             //
//         /   _____/ ____   _____   _____/  |_|  |__ |__| ____    ____                               //
//         \_____  \ /  _ \ /     \_/ __ \   __\  |  \|  |/    \  / ___\                              //
//         /        (  <_> )  Y Y  \  ___/|  | |   Y  \  |   |  \/ /_/  >                             //
//        /_______  /\____/|__|_|  /\___  >__| |___|  /__|___|  /\___  /                              //
//                \/             \/     \/          \/        \//_____/                               //
//                        ___________.__                                                              //
//                        \_   _____/|  |   ______ ____                                               //
//                         |    __)_ |  |  /  ___// __ \                                              //
//                         |        \|  |__\___ \\  ___/                                              //
//                        /_______  /|____/____  >\___  >                                             //
//                                \/           \/     \/    (Something Else @ http://coding-talk.com) //
//                                                                                                    //
//                                                                                                    //
//====================================================================================================//

//error_reporting  (E_ALL);
//ini_set ('display_errors', true);

///////////////////////////////////iframes preview
if($_GET['something_else']||$_GET['se']){
if($_GET['method']=='curl'){
$url = $_GET['url'];
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);  
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 3_0 like Mac OS X; en-us) AppleWebKit/528.18 (KHTML, like Gecko) Version/4.0 Mobile/7A341 Safari/528.16'); 
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Accept-Language: en-us,en;q=0.7,de-de;q=0.3','Accept: text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5'));
$page = curl_exec($ch);
curl_close($ch); 
}else{
$page = file_get_contents($_GET['url']);
}
for ($i = 1; $i <= $_GET['File_Fields']; $i++) {
if($_GET['end'.$i]==''){ 
$page = str_replace($_GET['start'.$i],$_GET['replace'.$i],$page);
}else{
$_GET['start'.$i] =  str_replace('/','\/',$_GET['start'.$i]);
$_GET['end'.$i] =  str_replace('/','\/',$_GET['end'.$i]);
$page = preg_replace('/'.$_GET['start'.$i].'(.*?)'.$_GET['end'.$i].'/',$_GET['replace'.$i],$page);
}
}
if($_GET['se'])
echo htmlspecialchars($page);
else
echo $page;
exit;
}

////////////////////////////////////////no back space 
function nbsp($amount){
for ($i = 1; $i <= $amount; $i++)
    echo "&nbsp;";
}
?>
<html>
<head>
<title>Grabber Script Generator</title>
<script type="text/javascript">
//////////////////////reload both iframes ;)
function reloadiframes()
{
var url = document.getElementById('url').value;
var method = document.getElementById('method').value;

var ff = document.getElementById('ff').value;
var a;
var replaces = '';
for(a=1; a<=ff; a++)
{
    replaces += "&start"+a+"="+ document.getElementById('start'+a).value;
    replaces += "&end"+a+"="+ document.getElementById('end'+a).value;
    replaces += "&replace"+a+"="+ document.getElementById('replace'+a).value;
}
var sPath = window.location.pathname;
//var sPage = sPath.substring(sPath.lastIndexOf('\\') + 1); //local url
var sPage = sPath.substring(sPath.lastIndexOf('/') + 1);

var frameurl = sPage+"?url="+url+"&File_Fields="+ff+"&method="+method+replaces;
document.getElementById('f1').src = frameurl+"&something_else=1";
document.getElementById('f2').src = frameurl+"&se=1";
generatephp();
}

////////////////////////////////////////generate php
function generatephp()
{
var html = "?php \n";

if(document.getElementById('method').value=='curl'){
html += "$ch = curl_init(); \n";
html += "curl_setopt($ch, CURLOPT_URL, '"+document.getElementById('url').value+"'); \n";
html += "curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  \n";
html += "curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 3_0 like Mac OS X; en-us) AppleWebKit/528.18 (KHTML, like Gecko) Version/4.0 Mobile/7A341 Safari/528.16'); \n";
html += "curl_setopt($ch, CURLOPT_HTTPHEADER, array('Accept-Language: en-us,en;q=0.7,de-de;q=0.3','Accept: text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5')); \n";
html += "$page = curl_exec($ch); \n";
html += "curl_close($ch); \n";
}else{
html += "$page = file_get_contents('"+document.getElementById('url').value+"'); \n";
}
var i;
for (i = 1; i <= document.getElementById('ff').value; i++) {
var sstart = document.getElementById('start'+i).value;
var eend = document.getElementById('end'+i).value;
var rreplace = document.getElementById('replace'+i).value;

if(eend==''){
if(sstart!='')
 html += "$page = str_replace('"+sstart+"','"+rreplace+"',$page); \n";
}else{
/*
$_GET['start'.$i] =  str_replace('/','\/',$_GET['start'.$i]);
$_GET['end'.$i] =  str_replace('/','\/',$_GET['end'.$i]);
*/
if(sstart!='')
 html += "$page = preg_replace('/"+sstart+"(.*?)"+eend+"/is','"+rreplace+"',$page); \n";
}
}
html += "echo $page; \n";
html += "?>";
document.getElementById('txtarea').value = "<"+html;
}

function iframesize(sw)
{
var ifr = document.getElementById('f'+sw);
ifr.height=document.getElementById('hf'+sw).value;
ifr.width=document.getElementById('wf'+sw).value;
}
///////////////////////////////////////add new coloums

var FileFieldCount = 1;
function addNewInput(btn) {
var obj = document.createElement('BR');
btn.parentNode.insertBefore(obj,btn);
btn.form.File_Fields.value = ++FileFieldCount;
var s = document.createElement('INPUT');
s.type = 'text';
s.name = 'start'+FileFieldCount;
s.id = 'start'+FileFieldCount;
s.onblur = function () {return reloadiframes();};
var e = document.createElement('INPUT');
e.type = 'text';
e.name = 'end'+FileFieldCount;
e.id = 'end'+FileFieldCount;
e.onblur = function () {return reloadiframes();};
var r = document.createElement('INPUT');
r.type = 'text';
r.name = 'replace'+FileFieldCount;
r.id = 'replace'+FileFieldCount;
r.onblur = function () {return reloadiframes();};
btn.parentNode.insertBefore(s, btn);
btn.parentNode.insertBefore(e, btn);
btn.parentNode.insertBefore(r, btn);
btn.parentNode.insertBefore(obj, btn);
return true;
}
//////////////////////////////////////highlight code
function SelectAll(id)
{
    document.getElementById(id).focus();
    document.getElementById(id).select();
}
</script>
</head>
<body>
<div align="center" style="background-color: #003399; color:FFFFFF;"><br/>
<b>Grabber Script Generator v1.2 <br/>By ServiceWorld.ML</b><br/><br/>
</div>

<div align="center">
<form>
<p>
Url To Grab: <input id="url" type="text" value="http://" onblur="reloadiframes();"><br/>
Grabber Method: <select id="method" value="fc" onchange="reloadiframes();">
<option value="fc">File Get Contents</option>
<option value="curl">Curl</option>
</select><br/>
REPLACEMENTS: (End and Replace Fields Can Be Empty)<br/>
<input id="ff" name="File_Fields" type="hidden" value="1">
<?=nbsp(3);?>Start:<?=nbsp(32);?>End:<?=nbsp(33);?>Replace:<br/>
<input id="start1" name="start1" type="text" onblur="reloadiframes();"><input id="end1" name="end1" type="text" onblur="reloadiframes();"><input id="replace1" name="replace1" type="text" onblur="reloadiframes();"><br/>

<input type="button" value="Add Replacement" onClick="return addNewInput(this)"><br/>
<!--<input type="submit" value="Create">-->
</p>
</form>
</div>


<div align="center">

<table>
<th>
<b>Preview Site</b><br/>
Width: <input size="3" value="600" type="text" id="wf1" onchange="iframesize(1);"/> Height: <input size="3" value="400" type="text" id="hf1" onchange="iframesize(1);"/>
</th>
<th>
<b>Source</b><br/>
Width: <input size="3" size="3" value="600" type="text" id="wf2" onchange="iframesize(2);"/> Height: <input size="3" value="400" type="text" id="hf2" onchange="iframesize(2);"/>
</th>
<tr>
<td>
<iframe id="f1" src="<?=$_SERVER['REQUEST_URI'];?>&something_else=1" width="600" height="400">
</iframe>
</td>
<td>
<iframe id="f2" src="<?=$_SERVER['REQUEST_URI'];?>&se=1" width="600" height="400">
</iframe>
</td>
</tr>
</table>
</div><div align="center">
<br/>
<b>Your Code:</b><br/>
<textarea rows="10" cols="100" id="txtarea" onClick="SelectAll('txtarea');">
</textarea>
</div>
</body>
</html>