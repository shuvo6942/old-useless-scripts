<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Random Space Remover</title><link rel="STYLESHEET" type="text/css" href="http://wtools.gq/styles.css"/><link rel="STYLESHEET" type="text/css" href="http://phptunes.com/favicon.ico"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/><style type="text/css">
body { background: ;
color: ;
}
a { color: ;
}
</style>
</head><body>




<div><script type="text/javascript" src="rsr.js"></script>
<div class="mainblok"><div class="nfooter">Remove Extra Space</div>
<p>You can get rid of extra whitespace and remove tab spaces from text with this tool.</p>
<p>This tool finds multiple whitespaces and replaces them with a single whitespace.</p>
<p>It can also delete all tab spaces if you need that option or it'll replace them with a single space.</p>
<h2>Whitespace Characters</h2>
<p>That's about it, this tool is pretty straightforward to use - you can remove multiple whitespace characters and preserve a single whitespace in text. And pretty handy when trying to transform some badly formatted text into a nice clean web page.</p>
<form method="post" action="" class="online-tools">
<h2>Remove Extra Whitespace or Tabs</h2>
<p>Paste your text in the box below and then click the button to <strong>trim whitespace</strong> characters.</p>
<p>The new text will appear in the box at the bottom of the page.</p>











<p class="flat"><input type="radio" id="nospaces" name="nospaces" value="no" checked="checked" /> Replace whitespaces with a single space but delete all tabs</p>
<p class="flat"><input type="radio" id="notabs" name="nospaces" value="no" /> Replace both multiple whitespaces and tabs with a single space</p>
<p><textarea id="oldText" name="oldText" rows="6" cols="36"></textarea></p>
<p><input type="button" name="Remove-White-Spaces" value="Replace Whitespaces" onclick="javascript:removeSpaces()" class="frmbtn" /></p>
<h2>New Text without Extra Whitespace</h2>
<p class="flat">Copy your new text from the box below.</p>
<p><textarea id="newText" name="newText" rows="9" cols="36" onclick="javascript:this.form.newText.focus();this.form.newText.select();"></textarea></p>
</form></div></div>
</body></html>