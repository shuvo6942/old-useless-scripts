<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>HTML Encoder</title><link rel="STYLESHEET" type="text/css" href="http://wtools.gq/styles.css"/><link rel="shortcut icon" href="http://phptunes.com/favicon.ico"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/><style type="text/css">
body { background: ;
color: ;
}
a { color: ;
}
</style>
</head><body>




<div class="full"><div class="name">HTML Encoder</div></div></center>
</div><div class="xt_container" data-xtcontainer="default" style=""><script type="text/javascript" src="http://weezywap.xtgem.com/Javascript/Js/encoder.js"></script>
<div class="zxfourborder" align="justify"><center><img src="/Pic/encoder.png" alt="encoder"/></center>
Sometimes webmasters need to hide some text from search engines.
This online html encoder converts your text into Unicode or HexHTML string
which will be executed by browser on page load.</div>
<div class="zxfourborder" align="center">
<script type="text/javascript">
function encode() {
var source = $("#source").val();
if(source.length == 0)
return false;
var unicode = Encoder.toUnicode(source);
var hex = Encoder.toHexHTML(source);
$("#unicode").val(
"<script type=\"text/javascript\">//<![CDATA[\n" +
"document.write(unescape('"+ unicode +"'));\n" +
"//]]></script\>"
);
$("#hex").val(
"<script type=\"text/javascript\">//<![CDATA[\n" +
"document.write(unescape('"+ hex +"'));\n" +
"//]]></script\>"
);
$("#result").slideDown();
}
</script>

Your Text<br/>
<textarea id="source" name="text" rows="5" class="input-block-level"></textarea>
<br/>
<button onclick="encode()" class="btn btn-large btn-primary">Encode</button>

</div>
<div class="zxfourborder" align="center">Unicode<br/>
<textarea id="unicode" name="text" rows="5" class="input-block-level" onclick="this.focus();this.select()">
</textarea>

</div>
<div class="zxfourborder" align="center">Hex<br/>
<textarea id="hex" name="text" rows="5" class="input-block-level" onclick="this.focus();this.select()">
</textarea>
</form>
</div></div></body></html>