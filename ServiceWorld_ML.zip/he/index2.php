<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<title>Encoding html using javascript's escape &amp; unescape</title>
<meta name="keywords" content="encode html, javescript escape unescape, urlencode, urldecode, protect html source" />
<meta name="description" content="Encoding html using javascript's escape &amp; unescape to aid security and help protect from spam." />
<meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
<meta name="robots" content="index,follow" />
<link href="../resources/site.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="http://www.yuki-onna.co.uk/resources/scripts/encodeHtml.js"></script>
</head>
<body>
<h2 align="center">Encoding html using javascript's escape &amp; unescape</h2>







<p>
There are a couple of reasons that you may want to encode some (or all) of your source html, these include:
</p>
<ul>
<li>Slightly increased security - by protecting your source from being easily read you are making it more difficult for anyone trying to find a workaround to your site (includes spoofing payments and gaining access to members areas)</li>
<li>Protection for automated non-javascript enabled crawlers - many of these are used to harvest email addresses from websites to add to spam mailing lists, and encoded email address will not be recognised as they cannot process the javascript.</li>
</ul>
<p>
There is also a downside however. Users of your website may well be viewing it on a non-javascript enabled browser or have javascript turned off (usually done to avoid malicious scripts and auto-popups), if the site user is unable to process the javascript then they too will be unable to read the information that has been encoded and it will appear missing from the page.
</p>









<form name="encodeHtml" action="">
Enter the text to encode here:
&nbsp;<textarea name="htmlToEncode" cols="50" rows="3"></textarea>
<input type="button" name="action" value="Encode HTML" onclick="encodeMyHtml()" />

Encoded html:
&nbsp;&lt;script type=&quot;text/javascript&quot;&gt;document.write(unescape(&quot;
<textarea name="htmlEncoded" cols="50" rows="3"></textarea>
&quot;));&lt;/script&gt;

<input type="button" name="action" value="Test Encoded HTML" onclick="testEncodedHtml()" />
<div id="testEncodedHtmlArea"></div>
</form>



<h3>How it's done</h3>
It's encoded by using the escape() function and then further special characters are encoded using the following routine:
<code>
&nbsp;&nbsp;				function encodeMyHtml() {
&nbsp;&nbsp;&nbsp;&nbsp;		encodedHtml = escape(encodeHtml.htmlToEncode.value);

&nbsp;&nbsp;&nbsp;&nbsp;		encodedHtml = encodedHtml.replace(/\//g,&quot;%2F&quot;);
&nbsp;&nbsp;&nbsp;&nbsp;		encodedHtml = encodedHtml.replace(/\?/g,&quot;%3F&quot;);
&nbsp;&nbsp;&nbsp;&nbsp;		encodedHtml = encodedHtml.replace(/=/g,&quot;%3D&quot;);
&nbsp;&nbsp;&nbsp;&nbsp;		encodedHtml = encodedHtml.replace(/&amp;/g,&quot;%26&quot;);<br />
&nbsp;&nbsp;&nbsp;&nbsp;		encodedHtml = encodedHtml.replace(/@/g,&quot;%40&quot;);<br />
&nbsp;&nbsp;&nbsp;&nbsp;		encodeHtml.htmlEncoded.value = encodedHtml;<br />
&nbsp;&nbsp;				}
</code><br />
It is then displayed by utilising the unescape() fuction which will turn it all back into html:<br />
&lt;script type=&quot;text/javascript&quot;&gt;document.write(unescape(&quot; my encoded html &quot;));&lt;/script&gt;<br /><br />
<a href="http://validator.w3.org/check/referer"><img src="http://www.w3.org/Icons/valid-xhtml10" alt="Valid XHTML 1.0!" border="0" height="31" width="88" /></a>
</body>
</html>