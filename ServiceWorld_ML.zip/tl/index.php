<?php
/*
:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
Google Translator
:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::          nhonha @ tHoNtHao.xtGEm.coM
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
*/
class gtranslate{
private $ab = '">';
private $ac = '</d';
private $host = 'http://translate.google.com';
function cc(){
$cc = array(
'auto'=>'Auto detect',
'af'=>'Afrikaans',
'sq'=>'Albanian',
'ar'=>'Arabic',
'hy'=>'Armenian',
'az'=>'Azerbaijani',
'eu'=>'Basque',
'be'=>'Belarusian',
'bn'=>'Bengali',
'bg'=>'Bulgarian',
'ca'=>'Catalan',
'zh-CN'=>'Chinese (Simplified)',
'zh-TW'=>'Chinese (Traditional)',
'hr'=>'Croatian',
'cs'=>'Czech',
'da'=>'Danish',
'nl'=>'Dutch',
'en'=>'English',
'et'=>'Estonian',
'tl'=>'Filipino',
'fi'=>'Finnish',
'fr'=>'French',
'gl'=>'Galician',
'ka'=>'Georgian',
'de'=>'German',
'el'=>'Greek',
'gu'=>'Gujarati',
'ht'=>'Haitian Creole',
'iw'=>'Hebrew',
'hi'=>'Hindi',
'hu'=>'Hungarian',
'is'=>'Icelandic',
'id'=>'Indonesian',
'ga'=>'Irish',
'it'=>'Italian',
'ja'=>'Japanese',
'kn'=>'Kannada',
'ko'=>'Korean',
'la'=>'Latin',
'lv'=>'Latvian',
'lt'=>'Lithuanian',
'mk'=>'Macedonian',
'ms'=>'Malay',
'mt'=>'Maltese',
'no'=>'Norwegian',
'fa'=>'Persian',
'pl'=>'Polish',
'pt'=>'Portuguese',
'ro'=>'Romanian',
'ru'=>'Russian',
'sr'=>'Serbian',
'sk'=>'Slovak',
'sl'=>'Slovenian',
'es'=>'Spanish',
'sw'=>'Swahili',
'sv'=>'Swedish',
'ta'=>'Tamil',
'te'=>'Telugu',
'th'=>'Thai',
'tr'=>'Turkish',
'uk'=>'Ukrainian',
'ur'=>'Urdu',
'vi'=>'Vietnamese',
'cy'=>'Welsh',
'yi'=>'Yiddish');
$q = $_GET['q'];
$from = $_GET['from'];
$to = $_GET['to'];
$q = str_replace(' ', '+', $q);
$qi = str_replace('+', ' ', $q);

echo "</div><div class=info align=center><center><form method='get' action=''><b>Type Your Text:</b><br><input name='q' type='text' value='$qi'>
</center></div><div class=list2 align=center><center>From: <select name='form'>";
if ($from){
echo "<option value='$from'>$cc[$from]</option>";
}
foreach($cc as $key => $val){
echo "<option value='$key'>$val</option>";
}
echo "</select></center>
</div><div class=list1 align=center><center>To: <select name='to'>";
if ($to){
echo "<option value='$to'>$cc[$to]</option>";
}
foreach($cc as $key => $val){
$key = str_replace('auto', '', $key);
$val = str_replace('Auto detect', '', $val);
echo"<option value='$key'>$val</option>";
}
echo"</select></center>
</div><center>
<input type='submit' value='Translate'>
</form></center>";
}
function urle(){
$q = $_GET['q'];
$q = str_replace(' ', '+', $q);
if ($_GET['from'])
$from = $_GET['from']; else $from = 'auto';
$to = $_GET['to'];
$url = file_get_contents("$this->host/m?hl=en&sl=$from&tl=$to&ie=UTF-8&prev=_m&q=$q");
return $url;
}
function ex1(){
$exp = explode('<div dir="ltr"', $this->urle());
return $exp[1];
}
function ex2(){
$exp = explode('<div dir="ltr"', $this->urle());
return $exp[2];
}
function trans(){
$trans1 = cut($this->ex1(),$this->ab,$this->ac);
$trans2 = cut($this->ex2(),$this->ab,$this->ac);
if ($trans1 !="") {
echo "<div align=center class=list2><center>$trans1</center></div><div align=center class=list1><center><textarea>$trans1</textarea></center></div>";
}
if ($trans2 !="") {
echo "<div align=center class=list2><center><textarea>$trans2</textarea></center></div>";
}
}
}

function cut($content,$start,$end){
if($content && $start && $end) {
$r = explode($start, $content);
if (isset($r[1])){
$r = explode($end, $r[1]);
return $r[0];
}
return '';
}
}
ini_set("default_charset", "UTF-8");
Ini_set("user_agent", "Mozilla/5.0 (Symbian/3; Series60/5.2 NokiaE7-00/012.002; Profile/MIDP-2.1 Configuration/CLDC-1.1) AppleWebKit/525 (KHTML, like Gecko) Version/3.0BrowserNG/7.2.7.3 3gpp-gba");
if ($_GET['q'])
$title = str_replace('+', ' ', $_GET['q']);          else $title = 'Translator';
include'header.php';
$gtranslate = new gtranslate;
$gtranslate->urle();
$gtranslate->ex1();
$gtranslate->ex2();
$gtranslate->cc();
$gtranslate->trans();
include'footer.php';
?>
