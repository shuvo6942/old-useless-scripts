<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Calculater V2</title><link rel="STYLESHEET" type="text/css" href="http://wtools.gq/styles.css"/><link rel="shortcut icon" href="http://phptunes.com/favicon.ico"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/><style type="text/css">
body { background: ;
color: ;
}
a { color: ;
}
</style>
</head><body>







<div><p align="center"><style>#cal input[type="button"]{width: 50px; padding: 10px; border: 1px solid #333}</style><div class="m-c"><div class="m-h">Calcuator</div>
<div class="l1"><center><form id="cal" name="Calc"><table width="100%" border="0"><tr><td>
<input type="text" name="Input" Size="16"/><br/><br/></td></tr><tr><td>
<input type="button" name="one" value=" 1 " OnClick="Calc.Input.value += '1'"/>
<input type="button" name="two" value=" 2 " OnCLick="Calc.Input.value += '2'"/>
<input type="button" name="three" value=" 3 " OnClick="Calc.Input.value += '3'"/>
<input type="button" name="plus" value=" + " OnClick="Calc.Input.value += ' + '"/>
<br/>
<input type="button" name="four" value=" 4 " OnClick="Calc.Input.value += '4'"/>
<input type="button" name="five" value=" 5 " OnCLick="Calc.Input.value += '5'"/>
<input type="button" name="six" value=" 6 " OnClick="Calc.Input.value += '6'"/>
<input type="button" name="minus" value=" - " OnClick="Calc.Input.value += ' - '"/>
<br/>
<input type="button" name="seven" value=" 7 " OnClick="Calc.Input.value += '7'"/>
<input type="button" name="eight" value=" 8 " OnClick="Calc.Input.value += '8'"/>
<input type="button" name="nine" value=" 9 " OnClick="Calc.Input.value += '9'"/>
<input type="button" name="times" value=" x " OnClick="Calc.Input.value += ' * '"/>
<br/>
<input type="button" name="clear" value=" c " OnClick="Calc.Input.value += ""/>
<input type="button" name="zero" value=" 0 " OnClick="Calc.Input.value += '0'"/>
<input type="button" name="DotIt" value=" = " OnClick="Calc.Input.value =  eval(Calc.Input.value)"/>
<input type="button" name="div" value=" / " OnClick="Calc.Input.value += ' / '"/><br/></td></tr></table></form></center></div></p></div></body></html>