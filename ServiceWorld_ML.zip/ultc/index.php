<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Upercase/Lowercase Text Converter</title><link rel="STYLESHEET" type="text/css" href="http://wtools.gq/styles.css"/><link rel="shortcut icon" href="http://phptunes.com/favicon.ico"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/><style type="text/css">
body { background: ;
color: ;
}
a { color: ;
}
</style>
</head><body>



<div><div><script type="text/javascript" src="uppercase-lowercase-text.js"></script><div class="mainblok"><div class="nfooter">Uppercase-Lowercase Text</div>
<form method="post" action="uppercase-lowercase-text.php" class="online-tools">
<h2>Uppercase or Lowercase Letters</h2>
<p>Paste your text in the box below and then click the button.</p>
<p class="flat"><input type="radio" id="upperCase" name="theCase" value="yes" checked="checked" /> Uppercase all characters</p>
<p class="flat"><input type="radio" id="lowerCase" name="theCase" value="no" /> Lowercase all characters</p>
<p><textarea id="oldText" name="oldText" rows="6" cols="36"></textarea></p>
<p><input type="button" name="change-the-case" value="Change the Case" onclick="javascript:removeBreaks()" class="frmbtn" /></p>




<h2>New Text with Case Change</h2>
<p class="flat">Copy your new text from the box below.</p>
<p><textarea id="newText" name="newText" rows="9" cols="36" onclick="javascript:this.form.newText.focus();this.form.newText.select();"></textarea></p>
</form>
</div></div>
</div>
</body></html>