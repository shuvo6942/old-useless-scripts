<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Capitalized Sentences</title><link rel="STYLESHEET" type="text/css" href="http://wtools.gq/styles.css"/><link rel="shortcut icon" href="http://phptunes.com/favicon.ico"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/><style type="text/css">
body { background: ;
color: ;
}
a { color: ;
}
</style>
</head><body>




<div><script type="text/javascript" src="http://www.textfixer.com/js/capitalize-sentences.js"></script>


<div class="mainblok"><div class="nfooter">Capitalize Sentences</div>
<p><strong>This tool capitalizes sentences</strong> - makes the first letter of a sentence a capital letter. If you have some paragraphs where the sentances are not capitalized then you can quickly use this tool to get the proper capitalization.</p>
<p>It also can correct text where the caps lock key has made every letter capitalized. You've accidentally pressed the key and when you look up all your words are capitalized. It can be fixed easily by using the online tool below.</p>
<p>You can also use it to change the first letter of every word to uppercase - for a headline style capitalization. Though probably not as handy as the other <em>capital letter</em> changing functions</p>





<p>And who doesn't hate when you accidentally caps lock a whole bunch of text... fear not your capitalization woes are over ;)</p>
<p>This online text tool requires a javascript enabled browser to work.</p>
<form method="post" action="" class="online-tools">
<h2>Capitalize Sentences</h2>
<p>Paste your text in the box below and then click the button.</p>





<p>The newly capitalized text will appear in the box at the bottom of the page.</p>
<p class="flat"><input type="radio" id="firstCap" name="Capitals" value="yes" checked="checked" /> Capitalize sentences</p>
<p class="flat"><input type="radio" id="allCaps" name="Capitals" value="no" /> Capitalize every word</p>
<p><input type="checkbox" id="capLock" name="capLock" value="yes" /> Correct Accidental Caps Lock (gOOD fOR tEXT lIKE tHIS)</p>
<p><textarea id="oldText" name="oldText" rows="6" cols="36"></textarea></p>
<p><input type="button" name="capitalize-sentences" value="Capitalize Sentences" onclick="javascript:capitalizeSentences()" class="frmbtn" /></p>

<h2>Revised Sentences with Capital Letters</h2>
<p class="flat">Copy your new text from the box below.</p>




<p><textarea id="newText" name="newText" rows="9" cols="36" onclick="javascript:this.form.newText.focus();this.form.newText.select();"></textarea> </p>
</form>
</div></div>
</body></html>