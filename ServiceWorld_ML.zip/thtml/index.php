<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<meta http-equiv="content-type" content="application/xhtml+xml; charset=utf-8"/>
<meta http-equiv="Content-Style-Type" content="text/css" />
<link rel="stylesheet" href="http://pankajbd24.com/theme/default/style.css" type="text/css" />
<link rel="shortcut icon" href="http://pankajbd24.com/favicon.ico" />
<title>Html Code Tester</title>
</head><body>

<div class="phdr">
<center><b>HTML TESTER VIEWER</b></center></div><br/><center>Put Your HTML Code Here:<br/><br/></center><script language="JavaScript">function preview() {var odiv=document.getElementById("outputdiv"); var idiv=document.getElementById("inputcode");

odiv.innerHTML=idiv.value;}</script><form align="center"><textarea id="inputcode"><a href="http://facebook.com/MEHEDI.HASAN.SHUVO7251"><font color="red">Contact Me</font></a></textarea><br /><input type="button" onclick="preview()" value="Test This Code"></form><br /><div id="outputdiv" align="center"></div></center></script><br/></div>
</body></html>