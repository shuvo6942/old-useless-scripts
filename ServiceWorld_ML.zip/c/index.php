<html>
<head>
<title>
Online Calculator | Services.4Host.ML
</title>
</head>
<body><link rel="stylesheet" type="text/css" href="http://tunes420.wapka.mobi/styles.css"/>
<form action="#" method="post"><div class="mainblok"><div class="gmenu">
Write your first function number:<br/>
<input type="text" name="f1" value="" /><br/>
Relatiom between two functions:<br/>
<input type="radio" name="rel" value="jog" checked="yes">+</input>
<input type="radio" name="rel" value="biog">-</input>
<input type="radio" name="rel" value="gun">X</input>
<input type="radio" name="rel" value="bhag" >/</input> <input type="radio" name="rel" value="sotkora" >%</input><br/>
write your second function number:<br/>
<input type="text" name="f2" value="" /><br/>
<input type="submit" value="calculate" /></div></div>
</form>
<?php
error_reporting(0);
if (isset($_POST['f1']) && isset($_POST['rel']) &&isset($_POST['f2']) ) {
$fv1=$_POST['f1'];
$fv2=$_POST['f2'];
$rv=$_POST['rel'];
if ($rv=="jog")
{$val=$fv1+$fv2;
echo "The calculation is:<br/>";
echo "$fv1 + $fv2 = $val";} /* script by Efat. fb.me/efatbd */
elseif ($rv=="biog")
{$val=$fv1-$fv2;
echo "The calculation is:<br/>";
echo "$fv1 - $fv2 = $val";}
elseif ($rv=="gun")
{$val=$fv1*$fv2;
echo "The calculation is:<br/>";
echo "$fv1 X $fv2 = $val";}
elseif ($rv=="bhag")
{$val=$fv1/$fv2;
echo "The calculation is:<br/>";
echo "$fv1 / $fv2 = $val";}
elseif ($rv=="sotkora")
{$val=$fv1%$fv2;
echo "The calculation is:<br/>";
echo "$fv1 % $fv2 = $val%";}
else { echo "somthing error occured";}
}
else {echo "Fill up the Form";}
?>
</body></html>
