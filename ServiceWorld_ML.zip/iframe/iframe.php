<?php
$geturl = $_GET['get-url'];
$getsc = $_GET['get-sc'];
$getmh = $_GET['get-mh'];
$getmw = $_GET['get-mw'];
$getih = $_GET['get-ih'];
$getiw = $_GET['get-iw'];
echo '<head><title>Your Iframe</title><link rel="shortcut icon" href="http://pankajbd24.com/favicon.ico"/><link rel="stylesheet" type="text/css" href="http://www.tunes420.wapka.mobi/styles.css"/></head><div class="nfooter">Copy Your Iframe Code</div><textarea><iframe src="'.$geturl.'" scrolling="'.$getsc.'" marginheight="'.$getmh.'" marginwidth="'.$getmw.'" height="'.$getih.'" width="'.$getiw.'"></iframe></textarea>';
?>