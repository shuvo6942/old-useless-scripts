<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>MPS To MPH Convertor</title><link rel="STYLESHEET" type="text/css" href="http://wtools.gq/styles.css"/><link rel="shortcut icon" href="http://phptunes.com/favicon.ico"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/><style type="text/css">
body { background: ;
color: ;
}
a { color: ;
}
</style>
</head><body>








<div class=page style="margin-left:0; margin-right:0;">MPS-MPH Converter</div>
<div style="border:2px solid green; margin:0; padding:0;">
<div class=in>
<div class=footbanner style="margin:2px; padding:0;">
<div class=toptop1>
<br>
<div style="padding-left:3px; padding-right:3px;">
<span class=shadow>
<font color=silver>Convert speed unit value of Meter Per Second <font color=lime>(MPS) </font>to Miles Per Hour <font color=lime>(MPH)</font>. !<br>
<br>
<center>
<form name="converter">


<input type="text" OnFocus="this.value="" value="0.0" size="15" style="color:silver" name="mps">

<br> Meters Per Second
<font color="lime"> (MPS)</font><br /><br /><input type="button" style="background-image:url(http://greentooth.xtgem.com/b/gradg.png); color:silver" value="Convert" onclick="javascript:calc()">&nbsp;<input type="reset" value="Reset" style="background-image:url(http://greentooth.xtgem.com/b/gradg.png); color:silver" onclick="javascript:calc()"><br><br/><font color=orange>Result:</font><br/><input type="text" OnFocus="this.value="" value="0.0" size="15" style="color:red" name="mph"><br> Miles Per Hour
<font color="lime">(MPH)</font></form><script language="javascript">

//calculate function
function calc(){

//variables
var meterspersecond = document.converter.mps.value
var calculated = Math.round(meterspersecond * 3600 / 1610.3*1000)/1000

//write in text box
document.converter.mph.value=calculated
}
</script></span></div></body></html>