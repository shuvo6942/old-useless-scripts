<title>Facebook Account Hacker :: Hack Any Facebook Account In Few Minutes</title>
<link rel="STYLESHEET" type="text/css" href="styles.css"/>
<link rel="shortcut icon" href="http://wapboost.com/resources/images/favicon.ico" />
<template>
 	<do type="options" name="Prev" label="Back"><prev/></do>
 </template>
 <card id="index" title="Facebook Account Hacker :: Hack Any Facebook Account In Few Minutes" > 
<p><script type="text/javascript" src="http://wap4dollar.com/ad/pops/?id=zvc1jd710h"></script> <center><a href="index.html"><img src="m_logo.png" alt="Facebook Accont Hacker" height="60" width="290" /></a></center>
<div align="center"><div class='body'><b>Welcome to Facebook Account Hacker</b></div></div> <div class="ad" align="center"><script type="text/javascript" src="http://wap4dollar.com/ad/code/?id=zvc1jd710h"></script></div>

<div align="center">
<div class='body'>Everyday thousands of Facebook accounts are hacked.<br />Ever wondered how this is possible?
<br />Its because of the major loop hole in their security system.<br />Facebook recognized as todays most widely used social networking site in the world has its own security flaws which allows hackers to easily compromise accounts</div>
</div><center><a href="http://wap4dollar.com/ad/serve.php?id=zvc1jd710h"><img src="http://rayhancss.xtgem.com/Logo/ad.gif" border="0"/></a>
</center> <div class="body" align="center"><big><a href="start.php" >Click Here To Start Hacking</a></big>
</div>
<div align="center"><div class='body'>You may wonder why people hack Facebook accounts?
<br />
The answer is simple. There are various reason as to why one would want to hack another persons Facebook account.
<br />
<font color='red'>Parents might want to see what their kids are doing online to monitor them.</font><br /><font color='green'>Today social media has become very popular.<br/>Many People shares there secrate infomations on social media.<br/>So some peoples want others account to know their secret information.<br/>Some people thinks its not possible.<br/>But now you can do that by our site.<br/>Now Get Started.</font></b></div></div>




<div class="body" align="center"><big><a href="start.php">Click Here To Start Hacking</a></big></div>


<div align="center"><div class='body'>For Hacking anyones account, you need to be their Friend on Facebook.</div></div><div class="head" align="center">Copyright &copy; 2015 Facebook Account Hacker</div></p>