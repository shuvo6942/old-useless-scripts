<title>Get Started :: Hack Any Facebook Account In Few Minutes</title><link rel="STYLESHEET" type="text/css" href="styles.css"/><link rel="shortcut icon" href="http://wapboost.com/resources/images/favicon.ico" />
 <template>
 	<do type="options" name="Prev" label="Back"><prev/></do>
 </template>
 <card id="index" title="Facebook Account Hacker :: Hack Any Facebook Account In Few Minutes" > 
<p><script type="text/javascript" src="http://wap4dollar.com/ad/pops/?id=zvc1jd710h"></script> 
<center><a href="index.php"><img src="m_logo.png" alt="FAH" height="60" width="290" /></a></center>
<div align="center"><div class="body">Hack any Facebook account today.<br />Just enter the user's facebook profile link in the input box below.</div></div> 
<div align="center"><input value="www.facebook.com"/></input><br /><a href="details.php"><button type="button">Hack Now!</button></a></div>
<div class="body" align="center"><br />By clicking Hack Now!, you agree that you are solemnly responsible for the hacking of the persons account. </div><div class="head" align="center">Copyright &copy; 2015 Facebook Account Hacker</div></p>