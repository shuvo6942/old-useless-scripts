<title>Online Users</title>
&#187;  Online Users Status
<?php
$data = file('/home/a9284034/public_html/online.dat');
echo '';
echo '';
foreach($data as $val)
{
$ex = explode('::', $val);
$ex2 = explode(' ', $ex[0]);
$i++;
echo "<div style='border-bottom:1px dashed #858585;padding:5px;font-weight:normal;'>$i. $ex2[0]<br/>IP: $ex[1]<br/>Current Page: <a href=\"$ex[2]\">http://serviceworld.ml$ex[2]</a><br/>Since Time: ".date('h:i A', (int)(trim($ex[3])))."</div>";
}
?>
<a href='index.php'>&#187; Back To Home </a>