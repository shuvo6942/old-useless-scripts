<?php
if($fr = @file('/love/fact.txt'))
 {
    for($i=0;$i<1;$i++) 
     {
	 $max = sizeof($fr) - 1;
	 $r = rand(0,$max);
       echo '<small>'.htmlspecialchars(trim($fr[$r])).'</small>';
     }
 } 
?>