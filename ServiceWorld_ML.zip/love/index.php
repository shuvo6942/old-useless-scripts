<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link rel="stylesheet" href="/love/style.css" type="text/css" />
        <title>Love Calculator - Services.4Host.ML/Love</title>
    </head>
    <body>
<div class="konon"> <b>Love Calculator</b></div>
<div class="head">Love Calculator</div>
<div class="mainbox">
<?php include_once '/love/fact.php'; ?>
</div>
<div class="info">
<b>Please Your name an your Pratners name:</b><br/>
<div class="mainbox">
        <form action="/love/result.php" method="post">
            Your Name: <br/><input type="text" name="yn"/><br/>
            Partners Name: <br/><input type="text" name="pn"/><br/>
            <input type="submit" value="ok"/>
        </form>
		<?php
		if(strlen($_POST["yn"])==0&& strlen($_POST["pn"])==0)
		echo 'Fields cant be empty';
		else
		/*echo '<a href=/love/result.php?yn='.$_POST["yn"].'&pn='.$_POST["pn"].'">Result</a>';*/
		include '/love/result.php';
		?>
		
</div><br/><br/>
<small><b>Note:</b>It's not possible to get a hundred per cent probabilty, therefore there's no guarantee of any kind that the relationship will work out between these two people. No record is being kept of any information entered by the user of this program.</small>
        </div>
<div class="konon"><center><a href="/">Back to Home</a><br/>(c)<a href="http://services.4host.ml/">Services.4Host.ML</a></div></div>
    </body>
</html>
