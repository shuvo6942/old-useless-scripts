<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Love Result - Services.4Host.ML</title>
        <link rel="stylesheet" href="/love/style.css" type="text/css" />
    </head>
    <body>
        
	<div class="head">Love Result</div>
<div class="info">

        <?php 
            
            $random=rand(40,100); 
        ?>
       <div class="mainbox">  
            <b><?php
        echo $_POST["yn"]; ?> <img src="/love/heart.png"/> <?php echo $_POST["pn"]; ?></b> <center><big><?php echo $random; ?> %</big></center>
        
        <?php

 if($random<60)
     echo 'Do Better Than That!';
 else if($random<80&&$random>61)
     echo 'WOW Thats Cool Keep It Up!';
 else 
     echo 'Obviously I Dont Know What To Say!';
    ?>
</div>
        <br/><br/>



    </body>
</html>
