<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Facebook Fake Status Uploader </title><link rel="stylesheet" type="text/css" href="http://wtools.gq/styles.css"/><link rel="shortcut icon" href="http://phptunes.com/favicon.ico"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/>
</head><body>












<style type="text/css">.ad{}.bar4{background-color:#399;color:#ffffff;text-bold:1px 1px #fff;link-color:1px 1px #ffffff;padding:4px;}.bmenu{color:#fff;background-color:#4b4d4d;padding-top:5px;padding-bottom:5px;margin-top:1px;margin-bottom:1px;border-bottom:1px outset #676a6a;}.hidex{}.msgbody{background:#fffafa;padding:5px;display:block;border:dotted 1px #cae1ff;margin:5px;color:black;border-radius:4px;}.msgfoot{color:#333333;border:1px solid #e6b868;background-color:#fff5bc;padding:5px 5px 5px 5px;border-radius:4px;margin:4px 4px 4px 4px;}.msgtitle{color:#ffffff;background-color:#538dc3;background-repeat:no-repeat;background-position:right 50%;text-align:left;padding:3px;font-weight:bold:padding-left:5px;margin:4px 4px 4px 4px;border:1px solid #538dc3;border-radius:4px;}.rana2{padding:5px 5px 5px 8px;background:#000000;border-top:1px solid #ccc;border-bottom:1px solid #ccc;}.page{background:#f5e9eb;border:1px solid #e2c0c7;margin:3px;padding:4px;border-radius:4px;}.xlist{}.xlist2{}</style>







<center><div><div class="page">Via Which App Do You Want To Post On Facebook ?</div><br/>
</div>
<div><div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=214428491932960&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Microwave</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=192959324047861&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Last Fm</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=10979261223&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Mafia Wars</a></div>


<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=111485502232882&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Macbook pro</a></div>




<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=273799389309255&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Kinect sports</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=25662012709&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Kfc</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=533073936723882&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Jeep in the jungle</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=240597869302110&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Jedi mind controll</a></div>














<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=336811996748&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Hippo Blast</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=357426145125&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Hamesters</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=141155486000031&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Grapevine</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=119320461541075&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Glade</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=180700501993189&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Gameboy colour</a></div>












<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=191168117625803&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Galaxy Nexus</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=347494961968242&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">FUUUU</a></div> <div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=135990976466064&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Fbi</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=262082710485448&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">DVD</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=322406287780196&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Dr Peeper</a></div>












<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=275075955907423&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Dominos pizza</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=161618784012673&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Starwars</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=42160825601&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Daleks</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=624292344271378&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Crayola</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=382702368429886&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Coffe</a></div>















<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=48176660688&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Cigarets</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=209278969141716&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Calculator</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=195555003790380&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Birthday Cake</a></div>

</div>
<div><div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=105386699540688&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Steam</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=260273468396&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Skype</a></div>









<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=153695394688665&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Skynet</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=9279253524&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Redbull</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=117538128331046&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Pokemon</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=156624467787740&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Pokdext</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=1388414008054653&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Petsmart Monstar</a></div>











<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=201123586595554&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Nokia 808</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=58605689949&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Ouija table</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=185103391549701&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Pogo Stick</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=243870508973644&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Nintendo wii</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=236264753062118&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Nintendo 64</a></div>













<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=269274950555&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Moonlight</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=22574474581&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Monkeys</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=1dc633368924b3b0b4d08e3f83230760&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Mind controll</a></div>
</div>
<div><div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=533758440033399&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Nokia 2700</a></div> <div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=511556268913376&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Nokia 1100</a></div>












<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=534194159993734&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Windows Phone</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=541153599281635&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">IOS</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=567416876644816&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Xperia Z1</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=568250089902084&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Apple Laptop</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=574350082603259&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Android Smartphone App</a></div>















<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=577063848994029&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Sony Xperia Z</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=485283374879349&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">New delhi India</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=484655168278547&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Lovehurts</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=489435827760505&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Delhi</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=491740814245679&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Mtv Splisvilla</a></div>











<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=492559870837918&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">My Father</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=501051209990240&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Nokia Lumia 1020</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=506078906127510&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Sony Xperia Smartphone</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=252661741439201&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Burger king</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=627605760584501&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Whatsapp</a></div>















<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=655352187811766&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">My Dad is My Hero</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=707358202625730&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com&amp;display=touch&amp;to&amp;from_login=1&amp;m_sess=1dKlqw-dgO4-smF">Samsung Galaxy Note 3</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=2231777543&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Twitter</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=43111037130&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Cow</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=8884393482&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Gta 4</a></div>











<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=214137962102430&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Ipad Air</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=124024574287414&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Instagram</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=87741124305&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">YouTube</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=349306109061&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Windows Live</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=eb4c6d1a60e19a7795da501e1f468035&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Vibrator</a></div>












<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=55452170199&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Turtles</a></div>









<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=48119224995&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Tumblr</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=355807217828854&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Transformers</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=203192803063920&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Toaster</a></div> <div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=286434821408742&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Titanic</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=144647118961553&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">The sun</a></div>











<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=1458053044483719&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Samsung Galazy Note Edge</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=603639456419367&amp;client_id=603639456419367&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com&amp;display=touch&amp;from_login=1&amp;refsrc=http%3A%2F%2Fwww.beingtech.net%2F2013%2F03%2Fupdate-facebook-status-via-iphone5.html&amp;refid=9&amp;_rdr#_=_">Samsung Galaxy Note 4</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=181777111905561&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Kindle</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?app_id=644292652310017&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com&amp;to&amp;display=touch">Samsung Galaxy S5</a></div>














<div class="page"><a href="http://m.facebook.com/dialog/feed?app_id=618284788215687&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com&amp;to&amp;display=touch">Blackberry Z10</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?app_id=408326819270521&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com&amp;to&amp;display=touch">Samsung Galaxy Note 10.1</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?app_id=1399151873654426&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com&amp;to&amp;display=touch">Ipad 3</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?app_id=202273559959875 &amp;redirect_uri=https%3A%2F%2Fwww.facebook.com&amp;to&amp;display=touch">HTC One Max</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=b6612b53e91e3f2cd7aa7aa1fec17213&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com&amp;display=touch&amp;to&amp;from_login=1&amp;m_sess=1dKlqw-dgO4-smF&amp;_rdr">Nokia 3310</a></div>














<div class="page"><a href="http://m.facebook.com/dialog/feed?app_id=43769862066&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com&amp;to&amp;display=touch">SonyEricson</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?app_id=250828364944350&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com&amp;to&amp;display=touch">Refrigarator</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?app_id=704617482937611&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com&amp;to&amp;display=touch">Beingtect</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?app_id=162085207147118&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com&amp;to&amp;display=touch">Pizza Hut</a></div></div><div><div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=613958298724111&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Post Card</a></div>















<div class="page"><a href="http://m.facebook.com/dialog/feed?app_id=822685281105032&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com&amp;to&amp;display=touch">Hell</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?app_id=540597282740070&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com&amp;to&amp;display=touch">Heaven</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=301994739934317&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com&amp;display=touch&amp;to&amp;from_login=1&amp;m_sess=1dKlqw-dgO4-smF">Nokia Lumia 928</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?app_id=109477639172494&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com&amp;to">My toilate seat</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?app_id=86734274142+++++&amp;redirect_uri=http%3A%2F%2Fwww.facebook.com%2F&amp;to&amp;message&amp;link&amp;picture&amp;name&amp;caption&amp;description">Foursquare</a></div>

















<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=b8ebeb983f45eaa0bd5f4f66cad97654&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Harry potter</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?app_id=5747726667&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com&amp;to&amp;display=touch">Xbox LIVE Social Experience</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=402753553173934&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com&amp;display=touch&amp;to&amp;from_login=1&amp;m_sess=1dKlqw-dgO4-smF">Google Nexus7</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=31d608d30292175bf7703149699ccb39&amp;client_id=234413959913847&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com&amp;display=touch&amp;to&amp;from_login=1&amp;refsrc=http%3A%2F%2Fwww.techanger.com%2Fupdate-facebook-from-different-devices%2F&amp;refid=9&amp;_rdr#_=_">Nasa</a></div>














<div class="page"><a href="http://m.facebook.com/dialog/feed?app_id=eb2bbd22d2bccd0ee6bfc5123034e442&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com&amp;to&amp;display=touch">Nokia</a></div><div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=1415188755375690&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Devi Mata Rani</a></div><div class="page"><a href="http://m.facebook.com/dialog/feed?app_id=139163326199678&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com&amp;to">Love</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?app_id=197938993630946&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com&amp;to">I Love You</a></div><div class="page"><a href="http://m.facebook.com/dialog/feed?app_id=266315686756783&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com&amp;to">Samsung Galaxy Tab</a></div>









<div class="page"><a href="http://m.facebook.com/dialog/feed?app_id=41158896424&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com&amp;to&amp;display=touch">HTC SENSE</a></div>










<div class="page"><a href="http://m.facebook.com/dialog/feed?app_id=7933375107&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com&amp;to&amp;display=touch">Windows phone</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=166006500134086&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">The Sims 3</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=515781968437901&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">The past</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=134791669882998&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Toilate paper</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=103315030790&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Moon</a></div>














<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=108372819220732&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">The Future</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=ea01a57edb26cf1de143f09d45cfa913&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Telephaty</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=1466824503542939&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Assassing Creed 4 Black Flag</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=177519289048720&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Android 4.1 Jelly Bean</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=e9bb60e84041c1d9af040571984facaa&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com&amp;display=touch&amp;to&amp;from_login=1&amp;m_sess=1dKlqw-dgO4-smF">Camera</a></div>









<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=618165164893633&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com&amp;display=touch&amp;to&amp;from_login=1&amp;m_sess=1dKlqw-dgO4-smF">Iphone 5S</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=1417396398491564&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Iphone 5 Black Diamond</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=1396735610544470&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Hospital</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=153408854848221&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Collage</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=154842758044739&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Near Paris</a></div>











<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=160012437540580&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Nokia Asha 311</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=160167200831887&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Samsung Galaxy Mega</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=166134373479622&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com&amp;display=touch&amp;to&amp;from_login=1&amp;m_sess=1dKlqw-dgO4-smF">Facebook premium account</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=172387106267280&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Micromax Canvas 4</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=175179605992060&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Gold Flake Cigaraete</a></div>















<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=175462039309624&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Jai Mata Di</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=183163795183494&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Nokia Lumia 800</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=186033284829408&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com&amp;display=touch&amp;to&amp;from_login=1&amp;m_sess=1dKlqw-dgO4-smF&amp;_rdr">Akash Tablet</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=193852054112603&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Nokia 1200</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=198575483635750&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Playboy</a></div>










<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=217124265101869&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">WeChat</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=309386465824881&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Nokia Lumia920</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=332212146880268&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Google</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=342894689146278&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Samsung Galaxy Grand</a></div>

<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=345001415621885&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">My Mom Is My Angel</a></div>


















<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=372801646175748&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">My Gf Cell</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=393625914090739&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">My Broken Heart</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=398202563623412&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Mandwa</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=405846029523228&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Htc One</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=412912448824915&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Lumia 1020</a></div>















<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=431462963628288&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Samsung Galaxy Camera</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=262941033719955&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Tamagotchi</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=170590589625633&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Southpack</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=224139600960217&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Telekinesis</a></div>




<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=104906932915522&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Taxi</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=434618839942344&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Lumia 510</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=458712100890769&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Blackberry -Q5</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=459233290851362&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Iphone 6</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=462117467229439&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Samsung Smartphone</a></div> <div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=475084232583458&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Google </a></div>









<div class="page"><a href="http://m.facebook.com/dialog/feed?_path=feed&amp;app_id=480459145371803&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">My Phone</a></div>
<div class="page"><i><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=178222352279634&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Angry Birds</a></i></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?app_id=504269783011779&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com&amp;to&amp;display=touch">Sony Xperia Z2</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?app_id=698333780196700&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com&amp;to&amp;display=touch">Sony Xperia Z Ultra</a></div>
<div class="page"><a href="http://m.facebook.com/dialog/feed?app_id=381185385318555&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com&amp;to&amp;display=touch">Iphone 5C</a></div>



















<div class="page"><a href="http://m.facebook.com/dialog/feed?app_id=514976028587611&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com&amp;to&amp;display=touch">Blackberry Q10</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=375715519123796&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Big Tasty Hamburger</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=273076253447&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Battlefield Heros</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=248598571849006&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Battlefield 3</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=366520706756689&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Basketball Manazer</a></div>















<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=8993418156&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Bananas</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=455640977808871&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Audi Qattro Drive</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=409998775694331&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Alcohol</a></div>
<div class="page"><a href="https://m.facebook.com/dialog/feed?_path=feed&amp;app_id=264604713681043&amp;redirect_uri=https%3A%2F%2Fwww.facebook.com">Snickerr</a></div>

</div></center>
</body></hyml>