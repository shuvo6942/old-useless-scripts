<?php
if(isset($_GET['do'])){
if($_GET['do'] == "create"){
if(isset($_POST['submit'])){
$comment = $_POST['comment'];
echo '<center>Your Blue Comment<br/><input type="text" value="@@[1:[0:1:'.$comment.']]"/>';
}
}
}






echo '<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Your Facebook Comment </title><link rel="stylesheet" type="text/css" href="http://tunes420.wapka.mobi/styles.css"/><link rel="shortcut icon" href="http://phptunes.com/favicon.ico"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/>
</head><body><center>Facebook Blue Comment Generator<br/><form action="index.php?do=create" method="post" enctype="multipart/form-data"><input type="text" name="comment" value="Enter Your Comment Here"/><br/><input type="submit" value="submit" name="submit"/></form></center></body></html>';
?>