<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Newspaper's Website</title><link rel="STYLESHEET" type="text/css" href="http://itpagla.com/styles.css"/><link rel="shortcut icon" href="http://phptunes.com/favicon.ico"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/><style type="text/css">
body { background: ;
color: ;
}
a { color: ;
}
</style>
</head><body>



body


<div><div style="margin-top: 3px; margin-bottom: 0px; " class="zone" align="center">Newspapers</div>

<div style="border:2.5px solid#006600">
<center> <a href="http://www.prothom-alo.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Daily Prothom Alo </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.samakal.com.bd/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Shamokal </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.dailyjanakantha.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Daily Janakantha </div>










</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.amadermedia.com.bd/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Aamader Media </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.suprobhat.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Suprobhat </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.banglanewsupdate.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Banglanews Update </div>














</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://new.ittefaq.com.bd/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Daily Ittefaq </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.bd-pratidin.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Bangladesh Protidin </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.dailykalerkantho.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Daily Kaler Kantho </div>










</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.mzamin.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Daily Manob Jamin </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.amadershomoy1.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Amader Shomoy </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.dailysangram.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Daily Naya Diganta </div>





</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="Amar Desh" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Amar Desh </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.bartamanpatrika.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Daily Bartamaan </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.bhorerkagoj.net/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Bhorer Kagoj </div>





</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.dailyinqilab.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Daily Inqilab </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://jugantor.us/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Daily Jugantor </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.aajkaal.net/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Daily AajKaal </div>







</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.dailysangram.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Daily Sangram </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.suprovat.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Century Sangbad </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://bangla.ganashakti.co.in/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> GanaShakti</div>






</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.deenersheshey.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Deener Sheshey </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.sangbadpratidin.in/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Sanbad Protidin </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.dailydesherkatha.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Daily Desher Katha </div>














</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.dainikagradoot.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Dainik Agradoot </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.dainikazadi.org/index.php" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Dainik Azadi </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.asomiyapratidin.co.in/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Asomiya Pratidin </div>








</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.karatoa.com.bd/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> The Daily Karatoa </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.dainikdestiny.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Daily Destiny </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.suprobhatbangladesh.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Suprovat Bangladesh </div>










</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.al-ihsan.net/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> The Daily Al Ihsan </div>
</a> </center>
</div>


<div style="border:2.5px solid#006600">
<center> <a href="http://purbanchal.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Daily Purbanchol </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">





<center> <a href="http://www.comillarkagoj.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Comillar Kagoj </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.jjdin.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Daily Jai Jai Din </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.comillarbarta.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Comillar Barta </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">

















<center> <a href="http://www.shokalerkhabor.com" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Shokaler Khabor </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.dailydinkal.net" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> The Daily Dinkal </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.dailyjanatabd.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> The Daily Janata </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">









<center> <a href="http://www.dainiksambad.net/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Dainik Sambad </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.dailyshomoy.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Bangladesh Shomoy </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.amaderorthoneeti.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Amader Orthoneeti </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">














<center> <a href="http://www.dailyjoybangla.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Daily Joy Bangla </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.amaderprotidin.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Amader Protidin </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.gramerkagoj.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Gramer Kagoj </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">











<center> <a href="http://www.shahnamabd.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> The Daily Shahnama </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.probashaprotidin.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Probasha Protidi </div>
</a> </center>
</div>
<div style="margin-top: 3px; margin-bottom: 0px; " class="zone" align="center">English Newspapers</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.thedailystar.net/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> The Daily Star </div>
</a> </center>
</div>








<div style="border:2.5px solid#006600">
<center> <a href="http://www.telegraphindia.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> The Telegraphindia </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.independent-bangladesh.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Bangladesh News</div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.thenewnationbd.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> The New Nation </div>
</a> </center>
</div>








<div style="border:2.5px solid#006600">
<center> <a href="http://www.daily-sun.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Daily Sun </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://newagebd.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> NEW AGE </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="The Statesman" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> The Statesman </div>
</a> </center>
</div>












<div style="border:2.5px solid#006600">
<center> <a href="http://www.thebangladeshtoday.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> The Bangladesh Today </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.thefinancialexpress-bd.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> The Financial Express </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.unbnews.org/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> UNB News </div>
</a> </center>
</div>












<div style="border:2.5px solid#006600">
<center> <a href="http://www.bssnews.net/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> B S S </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.guardian.co.uk/world/bangladesh" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Guardian </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.theindependentbd.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> The Independent </div>
</a> </center>
</div>









<div style="border:2.5px solid#006600">
<center> <a href="http://www.e-bangladesh.org/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> E-Bangladesh </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.bdwebnews.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Bangladesh Web News </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.energybangla.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Energy Bangla </div>
</a> </center>
</div>










<div style="border:2.5px solid#006600">
<center> <a href="http://www.bangladeshnews.net/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Bangladesh News.Net </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.bangladeshinfo.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Bangladesh Info </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://ganashakti.com/index.php" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> GanaShakt </div>
</a> </center>
</div>










<div style="border:2.5px solid#006600">
<center> <a href="http://www.the-editor.net/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> The Editor </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.24dhakanews.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Dhaka News </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.hawker.com.bd/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Hawker </div>
</a> </center>
</div>












<div style="border:2.5px solid#006600">
<center> <a href="http://www.newsbnn.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> News BNN </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.bdcomcn.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> china Bangla community </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.edailystar.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> eDaily Star </div>
</a> </center>
</div>









<div style="margin-top: 3px; margin-bottom: 0px; " class="zone" align="center">International Bengali Newspapers</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.bbc.co.uk/bengali/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> BBC Bangla </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www2.dw-world.de/bengali/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> German Bangla Radio </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.voanews.com/bangla/news/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> VOA News </div>
</a> </center>










</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://bengali.ruvr.ru/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Radio Russia </div>
</a> </center>
</div>

<div style="border:2.5px solid#006600">
<center> <a href="http://www3.nhk.or.jp/nhkworld/bengali/top/index.html" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> NHK World Bangla </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.anandabazar.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Anandabazar Potrika </div>









</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://bangla.irib.ir/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Tehran Bangla Radio </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://bengali.cri.cn/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> CRI online </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://bengali.ruvr.ru/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Radio Rashia </div>











</a> </center>
</div>
<div style="margin-top: 3px; margin-bottom: 0px; " class="zone" align="center">
Regional Bengali Newspapers </div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.khulnanews.com" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Khulna News </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.barisalnews.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Barisal News </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">








<center> <a href="http://www.karatoa.com.bd/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Daily Karatoa </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.amaderbarisal.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Amader Barisal </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.chalomannoakhali.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Cchaloman Noakhali </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">











<center> <a href="http://patradoot.net/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Patradoot </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.noakhaliweb.com.bd/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Nakhali Web </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.golapganj.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Golapganj </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">








<center> <a href="http://www.purbanchal.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Purbanchal</div>
</a> </center>
</div>
<div style="margin-top: 3px; margin-bottom: 0px; " class="zone" align="center">Bengali Online Newspapers</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://bangla.bdnews24.com" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Bdnews24 </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.banglamail24.com" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> bangla mail </div>
</a> </center>
</div>










<div style="border:2.5px solid#006600">
<center> <a href="http://www.banglanews24.com" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> banglanews24 </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.banglaexpress.com.bd/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Bangla Express </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.bartabangla.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> BartaBangla </div>
</a> </center>
</div>









<div style="border:2.5px solid#006600">
<center> <a href="http://banglatimes24.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> BanglaTimes24 </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.bdnationalnews.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> BDnationalnews</div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://bangla.bdnews.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> bdnews </div>
</a> </center>
</div>









<div style="border:2.5px solid#006600">
<center> <a href="http://www.bdtoday24.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> bdtoday24 </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.bdtodaynews.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> BDtodaynews.com </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.cdnews24.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> cdnews24 </div>
</a> </center>
</div>








<div style="border:2.5px solid#006600">
<center> <a href="http://www.amaderprotidin.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Amader Protidin </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.dhakanews24.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Dhakanews24 </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.dhakatimes24.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Dhakatimes24. </div>
</a> </center>
</div>











<div style="border:2.5px solid#006600">
<center> <a href="http://www.inbworld.net/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> InbworlD </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.justnewsbd.com" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Justnewsbd</div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.livepress24.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> livepress24 </div>
</a> </center>
</div>










<div style="border:2.5px solid#006600">
<center> <a href="http://www.natunbarta.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> NatunBarta</div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.newsbnn.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> NewsbnN</div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.newsnetbd.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> NewsnetBD </div>
</a> </center>
</div>











<div style="border:2.5px solid#006600">
<center> <a href="http://www.notunkhobor.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Ntun Khobor </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.poriborton.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Poriborton</div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.primekhobor.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Prime Khobor </div>
</a> </center>
</div>









<div style="border:2.5px solid#006600">
<center> <a href="http://www.primenewsbd.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> PrimeNewsBD </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.rtnn.net/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Rtnn.net </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.sangbad24.net/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Sangbad24 </div>
</a> </center>
</div>









<div style="border:2.5px solid#006600">
<center> <a href="http://www.sheershanews.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Sheersha News </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.valokhabor.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Valo Khabor </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.dhakapost24.net" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> DhakaPost24 </div>
</a> </center>
</div>





<div style="border:2.5px solid#006600">
<center> <a href="http://www.the-editor.net/bangla/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> The-Editor </div>
</a> </center>
</div>
<div style="margin-top: 3px; margin-bottom: 0px; " class="zone" align="center">
Bengali E-newspapers</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.esamakal.net" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> eSamakaL</div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.dailykalerkantho.com/epaper" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> eKalerkantho </div>












</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.eprothomalo.com" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> eProthomalo</div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.ebonikbarta.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> eBonikbarta </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.ejanakantha.com" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> eJanakantha</div>














</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://egonokantho.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> eGonokantha </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.daily-sun.com/epaper/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> eDaily-Sun </div>
</a> </center>
</div>
<div style="margin-top: 3px; margin-bottom: 0px; " class="zone" align="center">
Famous Newspapers Of The World</div>
<div style="border:2.5px solid#006600">










<center> <a href="http://www.nytimes.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> New York Times </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.guardian.co.uk/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> The Guardian </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.dailymail.co.uk/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> The Daily Mail </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">

















<center> <a href="http://www.wsj.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Wall Street Journal </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.washingtonpost.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Washington Post </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.usatoday.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> USA Today </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">










<center> <a href="http://www.telegraph.co.uk/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> The Daily Telegraph </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://timesofindia.indiatimes.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Times of India </div>
</a> </center>
</div>



<div style="border:2.5px solid#006600">
<center> <a href="http://www.independent.co.uk/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> The Independent </div>















</a> </center>
</div>
<div style="border:/diva href= 2.5px solid#006600">
<center> <a href="http://www.asahi.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Asahi Shimbun </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.yomiuri.co.jp/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Yomiuri (Japan) </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.sichuandaily.com.cn/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Sichuan Daily </div>








</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.jagran.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Daily Jagran </div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.time.com/time/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Time</div>
</a> </center>
</div>
<div style="border:2.5px solid#006600">
<center> <a href="http://www.economist.com/" >
<div class="Mainoption"><img src="http://wapkaimage.com/400760/400760360_bf411885f8.gif" alt="" /> Economist </div>

</a> </center>
</div>
</div>
</body></html>