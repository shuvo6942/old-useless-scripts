<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Email Validatision Checker</title><link rel="STYLESHEET" type="text/css" href="http://tunes420.tk/styles.css"/><link rel="shortcut icon" href="http://phptunes.com/favicon.ico"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/><style type="text/css">
body { background: ;
color: ;
}
a { color: ;
}
</style>
</head><body>




<?php
if(isset($_POST['submit'])){
$email = $_POST['email'];
 if(eregi("^([_a-z0-9-]+)(\.[_a-z0-9-]+)*@([a-z0-9-]+)(\.[a-z0-9-]+)*(\.[a-z]{2,4})$", $email)) 
 {
	echo "Valid Email Address";
 }
 else
 {
	echo "Invalid email address";
 }
}
echo '<center><div class="rmenu"><form action="" method="post">Your Email :<br/><input type="text" name="email" value="Put Your Email Address Here"/><br/><input type="submit" name="submit" value="Submit"/></form></div></center>';
?>
</body></html>