<?php
echo '<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Colourcode Tester</title><link rel="STYLESHEET" type="text/css" href="http://tunes420.wapka.mobi/styles.css"/><link rel="shortcut icon" href="http://phptunes.com/favicon.ico"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/><style type="text/css">
body { background: ;
color: ;
}
a { color: ;
}
</style>
</head><body>



<div class="rmenu"><form action="" method="post"><center>Enter Your Colour Code Without #<br/><input type="text" name="colour" placeholder="Your Colour Code"><br/><input type="submit" name="submit" value="Test Colour"></center></form></div>';
$getc = $_POST['colour'];
if(isset($_POST['submit'])){
echo '<center><br/><p align="left" style="background-color:#'.$getc.'">The Colour of Your Colour Code That You Have Entered</p></center></body></html>';
}
?>

