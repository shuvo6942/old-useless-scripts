<?php
         error_reporting(0);

function getCom(){
$array=array(
         'Thanks likenya brow (y)',
         'Makasih likenya Gan (y)',
         '(y) Like back success',
         'SALKOMSEL (y)',
         'Mksh y udh like sttsku (y)',
         'Thanks udh ngelike stts ku (y)',
);
$ran=$array[rand(0,count($array)-1)];

         return $ran;
}

function getLikes($id,$ms,$fr,$tok,$nn,$cc){
         if($nn=='on'){
getUrl('/'.$id.'/likes',$tok,array(
         'method' => 'post',
));
$success='Success Like Back';
         }else{
getUrl('/'.$id.'/likes',$tok,array(
         'method' => 'post',
));
getUrl('/'.$id.'/comments',$tok,array(
         'method' => 'post',
         'message' => urlencode(getCom()),
));
$success='Success Like & Komen';
}
$en=explode('_',$id);
$ct=fopen('log.txt','a');
         fwrite($ct,'*'.$en[0]);
         fclose($ct);

echo'<center>
         Name :<br>
<b>'.$fr.'</b><p>';
if(preg_match('/http/',$ms)){
echo'
         Status Foto :<br>
<img src="'.$ms.'" style="width:50px; height:50px;"/><hr>';
}else{
echo'
         Status :<br>
         '.$ms.'<p>';
}
echo'
<a href="https://m.facebook.com/'.$en[0].'">
         '.$success.'</a>
<hr>';
         if($cc[0]){
getTs($cc,$tok,$nn,'main','mulai');}
}

function getJm($d,$t,$r){
$get=getUrl('/'.$d[0].'/feed',$t,array(
         'fields' => 'id,message,from,type,picture',
         'limit' => '1000',
));
for($i=0;$i<=count($get);$i++){
         $sv=$get[$i][id];
         $sx=$get[$i][message];
$fm=$get[$i][from][name];
$type=$get[$i][type];
$pic=$get[$i][picture];
if($type=='photo'){
         $uh=$sv;
         $ih=$pic;
         $ah=$fm;
break;
}
if($sx){
         $uh=$sv;
         $ih=$sx;
         $ah=$fm;
break;}
}
         unset($d[0]);
foreach($d as $wm){
         $wp[]=$wm;
}

return getLikes($uh,$ih,$ah,$t,$r,$wp);
}

function getTs($id,$tok,$ys,$yf,$ro=null){
         if($ro){
getJm($id,$tok,$ys);
}else{
$get=getUrl('/'.$id.'/likes',$tok,array(
         'fields' => 'id,name',
         'limit' => '5000',
));
$cek=file_get_contents('log.txt');
for($i=0;$i<=count($get);$i++){
if(preg_match('/'.$get[$i][id].'/',$cek)){}else{
         $mm[]=$get[$i][id];}
}
$cs=file_get_contents('data.txt');
         if($yf=='on'){
foreach($mm as $zz){
if(preg_match('/'.$zz.'/',$cs)){
         $hard[]=$zz;}}
}else{
         $hard=$mm;
}
         if($hard[0]){
getJm($hard,$tok,$ys);
}else{
echo'<center>
         Clear Like
</center>';}
}
}

function maiN($tk,$op,$ip,$in=null){
$get=getUrl('/me/feed',$tk,array(
         'fields' => 'message,from,type,picture',
         'limit' => '1000',
));
for($i=0;$i<=count($get);$i++){
$mess=$get[$i][message];
         $id=$get[$i][id];
         $type=$get[$i][type];
$pic=$get[$i][picture];
if($type=='photo'){
         $as=$id;
         $is=$pic;
break;
}
if($mess){
         $as=$id;
         $is=$mess;
break;}
}
         if($in){
return getH($as,$is,$tk);
         }else{
return getTs($as,$tk,$op,$ip);}
}

function getH($id,$ms,$t){
if(file_exists('cek.txt')){
         }else{
$ar=fopen('cek.txt','w');
         fwrite($ar,$id);
         fclose($ar);
}
$cek=file_get_contents('cek.txt');
if(preg_match('/'.$id.'/',$cek)){}else{
         unlink('log.txt');
         unlink('cek.txt');
}
$get=getUrl('/'.$id.'/likes',$t,array(
         'fields' => 'id',
         'limit' => '5000',
));
for($i=0;$i<=count($get);$i++){
         $mm[]=$get[$i][id];
}
$xx=file_get_contents('log.txt');
foreach($mm as $k){
if(preg_match('/'.$k.'/',$xx)){
         $ok[]=1;
}else{
         $no[]=1;}
}
if(preg_match('/http/',$ms)){
echo'
         New status Foto :<br>
<img src="'.$ms.'" style="width:50px; height:50px;"/><hr>';
         }else{
echo'
         New Status :<br>
'.$ms.'<hr>';
}
if($get[0][id]){
         echo'
         Total like status :<br>
         '.count($mm).'<hr>';
}else{
         echo'
         Total like status :<br>
         0<hr>';
}
echo'
         New Like :<br>
         <font color="blue">
         '.count($no).'</font><hr>';
$ej=explode('*',$xx);
if($ej[1]){
         echo'
         Total Like Back :<br>
         <font color="red">
         '.count($ok).'</font><hr>
';
}else{
         echo'
         Total Like Back :<br>
         <font color="red">
         0</font><hr>';}
}

function getNes($tk){
         unlink('data.txt');
$get=getUrl('/me/friends',$tk,array(
         'fields' => 'id',
         'limit' => '5000',
));
for($i=0;$i<=count($get);$i++){
         $id=$get[$i][id];
$x=fopen('data.txt','a');
fwrite($x,'*'.$id);
         fclose($x);
         $ok[]=1;
}
$b=fopen('np.txt','w');
         fwrite($b,count($ok));
         fclose($b);
echo'<center>
         Success<p>
         <a href="?home=Back">
         Back Home</a>
</center>';
}

function getFb($x,$uh){
$array=array(
         'graph',
         'fb',
         'me'
);
$im='https://'.implode('.',$array);

return $im.$x.$uh;
}

function getUrl($s,$tok,$in=null){
$array=array(
         'access_token' => $tok
);
if($in){
$mer=array_merge($array,$in);
}else{
         $mer=$array;
}
foreach($mer as $u => $z){
         $im[]=$u.'='.$z;
}
$pl='?'.implode('&',$im);
$get=getFb($s,$pl);
$get=json_decode(to($get),true);
if($get[data]){
         return $get[data];
}else{
         return $get;}
}

function to($url){
         $ch=curl_init();
curl_setopt_array($ch,array(
CURLOPT_URL => $url,
CURLOPT_RETURNTRANSFER => true,
CURLOPT_CONNECTTIMOUT => 5,
));
$cx=curl_exec($ch);
         curl_close($ch);
         return ($cx);
}

function home($id,$tok){
$ii=file_get_contents('np.txt');
$ex=explode('*',$id);
echo'<center>
ROBOT RESPON LIKE & KOMEN
<p>
<a href="http://m.facebook.com/'.$ex[0].'"><img src="https://graph.facebook.com/'.$ex[0].'/picture" style="width:50px; height:50px;" alt="'.$ex[1].'"/></a>
         <p>
Data Friend : '.$ii.'
         <br>
<form action="index.php" method="post">
<input type="hidden" name="teman" value="'.$tok.'">
<input type="submit" value="Perbarui Data Teman"></form>
         <br>
<form action="index.php" method="post">
<input type="hidden" name="reset" value="ulang">
<input type="submit" value="Reset Data">
</form>
         <p>';
maiN($tok,'cek','uh','ah');
echo'
<form action="index.php" method="post">
<input type="hidden" name="start" value="'.$tok.'"><br>
<input type="radio" name="opsi" value="on">
Like saja<br>
<input type="radio" name="opsi" value="off">
Like & Komen<br>
<input type="radio" name="bb" value="on">
Teman saja<br>
<input type="radio" name="bb" value="off">
Semua Public<br>
<input type="submit" value="STARTER">
</form>';
}

function toXen($h){
header('Location: https://m.facebook.com/dialog/oauth?client_id='.$h.'&redirect_uri=https://www.facebook.com/connect/login_success.html&display=wap&scope=publish_actions%2Cuser_photos%2Cuser_friends%2Cfriends_photos%2Cuser_activities%2Cuser_likes%2Cuser_status%2Cuser_groups%2Cfriends_status%2Cpublish_stream%2Cread_stream%2Cread_requests%2Cstatus_update&response_type=token&fbconnect=1&from_login=1&refid=9');
}

function getD(){
echo'<center>
ROBOT RESPON LIKE & KOMEN
<p>
[ <a href="?token=get">
Get Token</a> ]
<p>
Masukan Token<br>
<form action="index.php" method="post">
<input type="text" name="buat"><br>
<input type="submit" value="Submit">
</form>';
}

function invaLid(){
echo'<center>
         Invalid Token !
         <p>';
getD();
}

if($_POST[buat]){
         $a=$_POST[buat];
$get=getUrl('/me',$a,array(
         'fields' => 'id,name',
));
if($get[id]){
$b=fopen('tkn.txt','w');
         fwrite($b,$a);
         fclose($b);
home($get[id].'*'.$get[name],$a);
}else{
         invaLid();}
}else{
if($_POST[start]){
         $a=$_POST[start];
         $b=$_POST[opsi];
         $c=$_POST[bb];
if($a && !empty($b) && !empty($c)){
         maiN($a,$b,$c);
}else{
         echo'<center>
         Failed<br>
         Pilih Opsi Like !
</center>';}
}else{
if($_GET[token]){
toXen('200758583311692');
}else{
if($_POST[teman]){
         $a=$_POST[teman];
         getNes($a);
}else{
if($_POST[reset]){
         unlink('tkn.txt');
         getD();
}else{
$ck=file_get_contents('tkn.txt');
$get=getUrl('/me',$ck,array(
         'fields' => 'id,name',
));
if($get[id]){
home($get[id].'*'.$get[name],$ck);
}else{
         getD();
         }}}}
         }}
?>