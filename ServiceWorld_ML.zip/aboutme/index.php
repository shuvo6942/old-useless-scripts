<?php
$name = 'Mehedi Hasan Shuvo'; // YOUR NAME
$title = 'Welcome To The Personal Life Of '.$name.''; // YOUR SITES TITLE
$fbidname = 'মেহেদী হাসান শুভ'; // YOUR FBID NAME
$fbidurl = 'http://fb.com/mehedi.hasan.shuvo7251'; // YOUR FBID URL
$age = '14'; // YOUR AGE
$birthday = '8/9/2002'; // YOUR BIRTHDAY D/M/YYYY
$ccity = 'Gazipur,Dhaka,Bangladesh'; // YOUR CURRENT CITY
$hometown = 'Munshiganj,Dhaka,Bangladesh'; // YOUR HOMETOWN
$work = 'Student'; // YOUR WORK
$schoolname = 'Mohammad Ali Memorial Academy'; // YOUR SCHOOL NAME
$iloves = 'মা - বাবা,ভাই - বোন কে তো অবশ্যই ভালোবাসি .<br />
<br />
তবুও একজন কে খুঁজতেছি<br />
<br />
যে আমার সাথে সারা জীবন থাকবে .<br />

<br />
অবশ্য একজন কে ভালোবাসি নাম I Donot Know,<br />'; // the peoples that you love
$aboutme = 'আমি কেমন মানুষ আমি জানি না,<br />কারণ আমি কেমন মানুষ সেটা আপনার উপর নিভর করে
<br />
রাগ অনেক তাড়াতাড়ি উঠে যায়<br />
আবার তাড়াতাড়ি নেমেও যায়,<br />
<br />
মেয়ে মানুষ রে দুই চোখে দেখতে পাই পাই না,<br />

<br />
<br />
আমার একটা অনুরোধ আপনাদের : ভালা হয়া জান ভালা হইতে পয়সা লাগে না<br />বুজলেন'; // ABOUT YOU
$websites = '* http://4hoster.ml<br />
* http://serviceworld.ml<br />
* http://sitemela.xtgem.com<br />
* http://tunes420.tk<br />
* http://phptipser.ml/<br />
* http://serviceworld.ml/aboutme<br />
* http://serviceworld.ml/order<br />
* http://filehoster.ml/<br />
* http://tutorialsbd.cf<br />'; // your websites
$fnames = 'নিশাত ( ওরফে নিশু )<br />
নিশান ( ওরফে বিড়ি )<br />
ফাহাদ ( ওরফে ফালতু )<br />
রিপন ( ওরফে রইপ্পা )<br />
মাহিম (ওরফে মদন )<br />
ছাব্বির ( ওরফে পাগল )<br />
রাব্বি  ( ওরফে রাবেয়া )<br />
সাজ্জাদ  ( ওরফে শান্তশিষ্ট )<br />
নাফিজ ( ওরফে জামাইবাবু )<br />
আলামিন ( ওরফে চিপস্ )<br />
আরিফ  ( ওরফে মডা )<br />
হাসান ( ওরফে হেচ্চ )<br />
<br /><br />'; // your friends name
$nationality = 'Bangladeshi'; // YOUR NATIONALITY
$rship = 'Single'; // ABOUT YOUR RELATIONSHIP
$movie = 'Transformers, Dhoom, Iron Man, Race, Golmal, X-man, Kick, RA-One'; // THE MOVIES NAME THAT YOU LIKE
$phonenumber = '+8801624172388 , +8801757199378'; // YOUR PHONE OR MOBILE NUMBER
$sport = 'Not Interested'; // HOW DO YOU THINK ABOUT SPORTS
$sports = 'Football[Brasil] , Cricket[BanglaDesh]'; //WHAT TEAMS YOU SUPPORT ON SPORTS AND WHICH SPORT
$lang = 'Bangla'; // YOUR LANGUAGE
$wantto = 'Web Devoloper'; //THE THING YOU WANT TO BE
$email = 'shuvo6942@gmail.com'; // YOUR EMAIL ADDRESS
$fc = 'Donot Know'; // YOUR FAVOURITE COLOUR
$hobby = 'Web Devoloping'; // YOUR HOBBY
$fq = 'লা ইলাহা ইল্লাল্লাহু মুহাম্মাদুর রাসুলুল্লাহ (সাঃ)'; // YOUR FAVOURITE QUOTES
$pv = 'I donot like this'; // HOW DO YOU THINK ABOUT POLITICS
$ps = 'Php,Javascript,Html,Css'; // YOUR PROFESSIONAL SKILLS
$gender = 'Male'; // YOUR GENDER
$inin = 'Women'; // IN WHO YOU ARE INTERESTED MEN/WOMEN
$religion = 'Islam'; // YOUR RELIGION
$hc = 'Black'; // YOUR HAIR COLOUR





echo '<?xml version="1.0" encoding="UTF-8"?><!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>'.$title.'</title><link rel="STYLESHEET" type="text/css" href="/styles.css"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/><style type="text/css">
body { background: #32b6ce;

color: ;

}

a { color: ;

}
</style>

<link rel="shortcut icon" href="http://pankajbd24.com/favicon.ico" />

<link rel="stylesheet" type="text/css" href="http://mobile.web.tr/assets/mobile-css/mobileStyle.css" media="all,handheld"/>

</head><body>
<div align="center"><div style="color: #fff; background: url(http://mycsszone.mobie.in/img/leftbox.gif) no-repeat top left #6d6d6d; font-size: 10px; margin-top: 4px; margin-left: 4px; margin-right: 4px;"><div style="background:url(http://mycsszone.mobie.in/img/rightbox.gif) no-repeat top right; padding: 8px; text-align: center;"><center>Date & Time : <br/><iframe src="http://serviceworld.ml/time/index.php" scrolling="yes" marginheight="0" marginwidth="0" height="200px" width="200px"></iframe></center></div></div></div>
<div><div id="wrapper">
<div id="header">
<div id="logo"><center><img src="me.jpg" alt="image" hight="100%" width="100%" /></center></div></div></div></div>
<div><div id="topnav"></div>
<div id="main">
<div class="section">




<div align="center"><div style="color: #fff; background: url(http://mycsszone.mobie.in/img/leftbox.gif) no-repeat top left #6d6d6d; font-size: 10px; margin-top: 4px; margin-left: 4px; margin-right: 4px;"><div style="background:url(http://mycsszone.mobie.in/img/rightbox.gif) no-repeat top right; padding: 8px; text-align: center;">'.$title.'</div></div></div>
<div class="subsection">
<div class="center">
<div class="gap"></div>
<div class="gap"></div></div><center><div class="big" style=" color: #14538b;"><br/><div class="section"><div class="title">Details</div><div class="subsection">

<div id="topsitediv">
<ul class="hreful">
<li>Name: '.$name.'<br />





<br />
FB ID Name: <a href="'.$fbidurl.'">'.$fbidname.'</a><br />
<br />
Gender: '.$gender.'<br />
<br />Birth Date: '.$birthday.'<br />
<br />
Age: '.$age.'<br /><br />
Hair Colour: '.$hc.'<br />
<br />
Home Town: '.$hometown.'<br /><br />
Current City: '.$ccity.'<br />
Work: '.$work.'<br />
<br />
Religion: '.$religion.'<br />
<br />
Interested In: '.$inin.'<br />
<br />
Political Views: '.$pv.'<br />
<br />
Favourite Quotes: '.$fq.'<br />
<br />Nationality: '.$nationality.'<br /><br />
Professional Skills: '.$ps.'<br /><br />
Hobby: '.$hobby.'<br />
<br />
Favourite Colour: '.$fc.'<br />
<br />Movie: '.$movie.'<br />
<br />
Mobile No: '.$phonenumber.'<br />
<br />
Email: '.$email.'<br />
<br />
Sport: '.$sport.'<br /><br />
Sport Support:  '.$sports.'<br />
<br />
Language: '.$lang.'<br />
<br />
Want To: '.$wantto.'<br />
<br />
Relationship: '.$rship.'</li>
</ul></div><div><div></div></div></div></div></div></div></div></div></div></div></div>
<div><div id="main">
<div class="section">
<div align="center"><div style="color: #fff; background: url(http://mycsszone.mobie.in/img/leftbox.gif) no-repeat top left #6d6d6d; font-size: 10px; margin-top: 4px; margin-left: 4px; margin-right: 4px;"><div style="background:url(http://mycsszone.mobie.in/img/rightbox.gif) no-repeat top right; padding: 8px; text-align: center;">আমি যাদেরকে ভালোবাসি</div></div></div>



<div class="subsection">
<div class="center">
<div class="gap"></div>
</div>
<div class="big" style=" color: #14538b;"><div class="section"><div class="subsection">
<div id="topsitediv">
<ul class="hreful">
<li>'.$iloves.'
</li>
</ul></div><div><div></div></div></div></div></div></div></div></div></div>
<div><div id="main">
<div class="section">
<div align="center"><div style="color: #fff; background: url(http://mycsszone.mobie.in/img/leftbox.gif) no-repeat top left #6d6d6d; font-size: 10px; margin-top: 4px; margin-left: 4px; margin-right: 4px;"><div style="background:url(http://mycsszone.mobie.in/img/rightbox.gif) no-repeat top right; padding: 8px; text-align: center;">আমার সম্পর্কে</div></div></div>
<div class="subsection">
<div class="center">
<div class="gap"></div>





</div>
<div class="big" style=" color: #14538b;"><div class="section"><div class="subsection">
<div id="topsitediv">
<ul class="hreful">
<li>'.$aboutme.'</li>
</ul></div><div><div></div></div></div></div></div></div></div></div></div>
<div align="center"><div style="color: #fff; background: url(http://mycsszone.mobie.in/img/leftbox.gif) no-repeat top left #6d6d6d; font-size: 10px; margin-top: 4px; margin-left: 4px; margin-right: 4px;"><div style="background:url(http://mycsszone.mobie.in/img/rightbox.gif) no-repeat top right; padding: 8px; text-align: center;">বন্ধুদের নাম</div></div></div>
<div><div id="main">
<div class="section">
<div class="subsection">
<div class="center">
<div class="gap"></div>


</div>
<div class="big" style=" color: #14538b;">
<div class="section"><div class="subsection">
<div id="topsitediv">
<ul class="hreful">
<li>'.$fnames.'
[ অচেনা কেউ কষ্ট দিলে গায়ে লাগে না কিন্তু বন্ধুরা কষ্ট দিলে গায়ে শয়না শুধু ব্যাথা বারে ]</li>
</ul></div><div><div></div></div></div></div></div></div></div></div></div>
<div><div id="main">
<div class="section">
<div align="center"><div style="color: #fff; background: url(http://mycsszone.mobie.in/img/leftbox.gif) no-repeat top left #6d6d6d; font-size: 10px; margin-top: 4px; margin-left: 4px; margin-right: 4px;"><div style="background:url(http://mycsszone.mobie.in/img/rightbox.gif) no-repeat top right; padding: 8px; text-align: center;">My Web Sites List</div></div></div>

<div class="subsection">
<div class="center">

<div class="gap"></div>
</div><div class="big" style=" color: #14538b;"><div id="topsitediv">
<ul class="hreful">
<li>I Have Many Web Site In My Small Life<br/ >'.$websites.'</li></ul></div><div><div></div></div></div></div></div></div></div></div></div></div>

<div align="center"><div class="title"><div class="topnav"><center><div align="center"><div style="color: #fff; background: url(http://mycsszone.mobie.in/img/leftbox.gif) no-repeat top left #6d6d6d; font-size: 10px; margin-top: 4px; margin-left: 4px; margin-right: 4px;"><div style="background:url(http://mycsszone.mobie.in/img/rightbox.gif) no-repeat top right; padding: 8px; text-align: center;">© Made By <a href="'.$fbidurl.'">'.$name.'</a> 2015</div></div></div></center></div></div></div>
</body></html>';
?>