<?php

$ip=$_SERVER['REMOTE_ADDR'];
$proxy=$_SERVER['HTTP_X_FORWARDED_FOR'];
$ip2=$_SERVER['HTTP_CLIENT_IP'];
$port=$_SERVER['REMOTE_PORT'];
$browser=$_SERVER['HTTP_USER_AGENT'];


echo'<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<HTML>
<HEAD>
<TITLE>IP Checker - 4Host.ML</TITLE>
<META NAME="Keywords" CONTENT="IP, address, address translation, proxy, firewall, dhcp, network, games, voice chat, tutorials, find ip address, ip addres, whats ip, ip find, ipconfig, ipaddress, 4host.ml, shuvo, ahmed">
<META NAME="Description" CONTENT="WhatIsMyIP Clone - The #1 Way To Find Your IP Address!">
<META HTTP-EQUIV="access_page" CONTENT="no-cache">
<LINK TITLE="" HREF="http://m.mp3craft.cf/css/blue.css?2.7" TYPE="text/css" REL="stylesheet">
</HEAD>
<body>
<h3>IP Checker - 4Host.ml</h3>
<div id="content"><div class="post-single">
<p>
<b>IP:</b><br/> '.$ip.'<br/><b>Browser:</b><br/>'.$browser.'
</p>
</div>
</div>

<div id="footer">
<font color="red">4Host.ML</font> Check your IP Address more faster.
<h6 id="powered-by">Powered By <a href="http://www.fb.me/mehedi.hasan.shuvo7251/">Shuvo</a><br/>Hosted on<a href="4host.ml">4Host.ML</a{</h6></div>
</BODY>
</HTML>';

?>