<?php

$msg="";
if(isset($_POST['submit']))
{


	$from_add = $_POST['yourmail']; 

	$to_add = $_POST['tomail']; //<-- put your yahoo/gmail email address here

	$subject = $_POST['subject'];
	$message = $_POST['massage'];
	
	$headers = "From: $from_add \r\n";
	$headers .= "Reply-To: $from_add \r\n";
	$headers .= "Return-Path: $from_add\r\n";
	$headers .= "X-Mailer: PHP \r\n";
	
	
	if(mail($to_add,$subject,$message,$headers)) 
	{
		$msg = "<center>Mail Sent!</center>";
	} 
	else 
	{
 	   $msg = "<center>Error Sending Email!</center>";
	}
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"> 
<html>	<head>
<link rel="shortcut icon" href="http://pankajbd24.com/favicon.ico" />
<title>Fake Email Sender</title>
</head>

<body bgcolor="#32b6ce">
<?php echo $msg ?>
<p>
<form action='<?php echo htmlentities($_SERVER['PHP_SELF']); ?>' method='post'><center>From Email : <br/>
<input type='text' name='yourmail'><br/>To Email : <br/>
<input type='text' name='tomail'><br/>
Subject : <br/><input type='text' name='subject'><br/>
Message : <br/><input type='text' name='massage'><br/>

<input type='submit' name='submit' value='Submit'>
</center></form>
</p>


</body>
</html>