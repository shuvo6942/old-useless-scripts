<?php 
if(isset($_GET['txt']))
{
$txt=$_GET['txt'];
}
?><!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Text to Image</title>
	<meta name="description" content="Text to Image" >
	<meta name="author" content="Md. Shuvo Ahmed">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
<header><h1 class="txt-center">Text to Image</h1></header>
<div class="project-form">
	<form>
	<h4 class="txt-center"><label for="get-text">Put Any Text Below</label></h4>
	<input type="text" name="txt" id="get-text" value="" required>
	<input type="submit" value="View Output">
	</form>
</div>
<p class="txt-center"> 
Put any text on the field above and hit to View Output, it will show up the out text as Image! 
<br>This script is developed by php language. Basically I use this to show up email id on site as 
<br>Email are stored on database as text. but if we show email as text, spammer will get easily that 
<br>email ID by searching @ and the start spamming! I really Dislike to get spam mail.
<br>Hope this will help you also. 


<?php if($txt) {
?><div class="image-container">Opuput as Image<br><img src="image.php?img=<?php echo convATandDot($txt); ?>" border="0"></div>
<?php }
?>


<footer class="txt-center">
	Designed and Developed by <a href="http://fb.com/mehedi.hasan.shuvo7251" > Shuvo </a>
</footer>
</body>
</html>

<?php
function convATandDot($currenttext){
$old = array('@','.');
$new = array('__shariar__','__dot__');
$convTEXT= str_replace($old, $new, $currenttext);
return $convTEXT;
}
?>