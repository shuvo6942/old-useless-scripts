<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Length Converter</title><link rel="STYLESHEET" type="text/css" href="http://wtools.gq/styles.css"/><link rel="shortcut icon" href="http://phptunes.com/favicon.ico"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/><style type="text/css">
body { background: ;
color: ;
}
a { color: ;
}
</style>
</head><body>



<script src="length.js"></script>
<div class=page style="margin-left:0; margin-right:0;">Length Converter</div>
<div style="border:2px solid green; margin:0; padding:0;">
<div class=in>
<div class=footbanner style="margin:2px; padding:0;">
<div class=toptop1>
<br>
<div style="padding-left:3px; padding-right:3px;">
<span class=shadow>
<font color=silver>Convert value of defined length unit to another unit. !<br><br><center>
<form name="length_con">
<table><tr><td size=14 style="background-image:url(http://greentooth.xtgem.com/b/gradg.png)">From:</td>
<td size=14 style="background-image:url(http://greentooth.xtgem.com/b/gradg.png)">To:</td>
</tr><tr><td size=14>
<select name=from_unit onChange="convert_unit()";>			<option> centimeters
<option> meters
<option> kilometers
<option> miles
<option> inches
<option> feet
<option> yards
</select></td><td size=14><select name=to_unit onChange="convert_unit()";>			<option> centimeters
<option> meters
<option> kilometers
<option> miles
<option> inches
<option> feet
<option> yards
</select></td></tr></table><br><font color=lime>Unit-to-Unit Equiva-Length:</font><br><div id="formula">centimeters = 1 centimeters</div><br><!-- enter --!><input type="text" name="from_value" value="1" style="color:red" size="9" maxlength="12"> <input type=button value="Convert" style="background-image:url(http://greentooth.xtgem.com/b/gradg.png); color:red" onClick="convert_unit()";><br><center><br><font color=lime>Converted Equiva-Length:</font><br><div id="to_value">1</div></form><br></span></div></body></html>