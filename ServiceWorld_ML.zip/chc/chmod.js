/* http://greentooth.xtgem.com 

// 4-digit Chmod calculator
Based on code by Peter Crouch 2000. All rights reserved.

// Modified 2001 to 4-digit by William E. Landfair-Owens
http://welo.ikemail.com

// Visit http://javascriptkit.com for this script and more
 */

function calculator(user, number){
// Superuser
if (user == "superuser" && number == "4"){var box = eval("document.chmod.superuser4")}
if (user == "superuser" && number == "2"){var box = eval("document.chmod.superuser2")}
if (user == "superuser" && number == "1"){var box = eval("document.chmod.superuser1")}
// Owner
if (user == "owner" && number == "4"){var box = eval("document.chmod.owner4")}
if (user == "owner" && number == "2"){var box = eval("document.chmod.owner2")}
if (user == "owner" && number == "1"){var box = eval("document.chmod.owner1")}
// Group
if (user == "group" && number == "4"){var box = eval("document.chmod.group4")}
if (user == "group" && number == "2"){var box = eval("document.chmod.group2")}
if (user == "group" && number == "1"){var box = eval("document.chmod.group1")}
// Other
if (user == "other" && number == "4"){var box = eval("document.chmod.other4")}
if (user == "other" && number == "2"){var box = eval("document.chmod.other2")}
if (user == "other" && number == "1"){var box = eval("document.chmod.other1")}
if (box.checked == true){
if (user == "superuser"){
document.chmod.h_superuser.value += ("+number")
var a= (document.chmod.h_superuser.value)
var b= eval(a)
document.chmod.h_superuser.value=b
document.chmod.t_superuser.value=b
}if (user == "owner"){
document.chmod.h_owner.value += ("+number")
var a= (document.chmod.h_owner.value)
var b= eval(a)
document.chmod.h_owner.value=b
document.chmod.t_owner.value=b
}if (user == "group"){
document.chmod.h_group.value += ("+number")
var a= (document.chmod.h_group.value)
var b= eval(a)
document.chmod.h_group.value=b
document.chmod.t_group.value=b
}if (user == "other"){
document.chmod.h_other.value += ("+number")
var a= (document.chmod.h_other.value)
var b= eval(a)
document.chmod.h_other.value=b
document.chmod.t_other.value=b
}
}
if (box.checked == false){
if (user == "superuser"){
if (document.chmod.h_superuser.value == ""){
document.chmod.t_superuser.value=""
}else {
var a=(document.chmod.h_superuser.value);
b=a-(number);
c=eval(b);
document.chmod.h_superuser.value=c
document.chmod.t_superuser.value=c
}}if (user == "owner"){
if (document.chmod.h_owner.value == ""){
document.chmod.t_owner.value=""
}else {
var a=(document.chmod.h_owner.value);
b=a-(number);
c=eval(b);
document.chmod.h_owner.value=c
document.chmod.t_owner.value=c
}}if (user == "group"){
if (document.chmod.h_group.value == ""){
document.chmod.t_group.value=""
}else {
var a=(document.chmod.h_group.value);
b=a-(number);
c=eval(b);
document.chmod.h_group.value=c
document.chmod.t_group.value=c
}}if (user == "other"){
if (document.chmod.h_other.value == ""){
document.chmod.t_other.value=""
}else {
var a=(document.chmod.h_other.value);
b=a-(number);
c=eval(b);
document.chmod.h_other.value=c
document.chmod.t_other.value=c
}}
}}
