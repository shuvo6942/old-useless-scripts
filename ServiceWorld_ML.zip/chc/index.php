<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Chmod Calculator</title><link rel="STYLESHEET" type="text/css" href="http://wtools.gq/styles.css"/><link rel="shortcut icon" href="http://phptunes.com/favicon.ico"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/><style type="text/css">
body { background: ;
color: ;
}
a { color: ;
}
</style>
</head><body>


<script language="JavaScript" src="chmod.js"></script>













<div class=page style="margin-left:0; margin-right:0;">Chmod Calculator</div>
<div style="border:2px solid green; margin:0; padding:0;">
<div class=in>
<div class=footbanner style="margin:2px; padding:0;">
<div class=toptop1><br>
<span class=shadow><style> body { width:345px; } </style><center>
<form name="chmod">
<input name="h_superuser" type="hidden">
<input name="h_owner" type="hidden">
<input name="h_group" type="hidden">
<input name="h_other" type="hidden">
<table bgcolor="black" cellpadding="5" cellspacing="1" style="border:1px solid #444; margin:5px;" align="center" >
<tr style="background:url(http://greentooth.xtgem.com/b/gradg.png) repeat-x top;">
<td colspan="6">
<center>
<font face="Verdana" size="3" color="silver"><b>4-digit Chmod</b>
</font>
</center>
</td>
</tr>
<tr bgcolor="#003300" align="center">
<td colspan="2">
<font face="Verdana" size="2" color="red">SuperUser</font></td>
<td>
<font face="Verdana" size="2" color="lime">Permission</font></td>
<td>
<font face="Verdana" size="2" color="red">Owner</font>
</td>
<td>
<font face="Verdana" size="2" color="lime">Group</font>
</td>
<td>
<font face="Verdana" size="2" color="red">Other</font>
</td></tr>
<tr bgcolor="#06600" align="center"><td>
<font face="Verdana" size="2" color="red">setuid</font>

</td>
<td>
<input type="checkbox" name="superuser4" value="4" style="bg-color:silver" onclick="calculator('superuser', 4)">
</td>
<td>
<font face="Verdana" size="2" color="lime">Read</font>
</td>
<td>
<input type="checkbox" name="owner4" value="4" style="bg-color:silver" onclick="calculator('owner', 4)">
</td>
<td>
<input type="checkbox" name="group4" value="4" style="bg-color:silver" onclick="calculator('group', 4)">
</td>
<td>
<input type="checkbox" name="other4" value="4" style="bg-color:silver" onclick="calculator('other', 4)">
</td>
</tr>
<tr bgcolor="#003300" align="center"><td>
<font face="Verdana" size="2" color="red">setgid</font>
</td>
<td>
<input type="checkbox" name="superuser2" value="2" style="color:silver" onclick="calculator('superuser', 2)">
</td>
<td>
<font face="Verdana" size="2" color="lime">Write</font>
</td>
<td>
<input type="checkbox" name="owner2" value="2" style="color:silver" onclick="calculator('owner', 2)">
</td>
<td>
<input type="checkbox" name="group2" value="2" style="color:silver" onclick="calculator('group', 2)">
</td>
<td>
<input type="checkbox" name="other2" value="2" style="color:silver" onclick="calculator('other', 2)">
</td>
</tr>
<tr bgcolor="#006600" align="center">
<td>
<font face="Verdana" size="2" color="yellow">stickybit</font>

</td>
<td>
<input type="checkbox" name="superuser1" value="1" style="color:silver" onclick="calculator('superuser', 1)">
</td>
<td>
<font face="Verdana" size="2" color="lime">Execute</font>
</td>
<td>
<input type="checkbox" name="owner1" value="1" style="color:silver" onclick="calculator('owner', 1)"></td>
<td>
<input type="checkbox" name="group1" value="1" style="color:silver" onclick="calculator('group', 1)"></td>
<td>
<input type="checkbox" name="other1" value="1" style="color:silver" onclick="calculator('other', 1)"></td>
</tr>
<tr bgcolor="#003300" align="center">
<td>
<font face="Verdana" size="2" color="yellow">Value</font>
</td><td>
<input type="text" name="t_superuser" size="1" font style="color:red"></td><td font color="lime">+</td><td><input type="text" name="t_owner" size="1" font style="color:red"></td><td><input type="text" name="t_group" size="1" font style="color:red"></td><td><input type="text" name="t_other" size="1" font style="color:red"></td></tr></table></form><br><br></span>
</body></html>