<?php
defined('PAGEDISPLAY') or die('Access Forbidden..!!');
if ($client_id == 0) {
header("Location: index.php");
exit;
}
$dir = rawurldecode(trim($_GET['dir']));
if ($dir == "") {
header("Location: index.php?ftp=list");
exit;
}
if (isset($_POST['create'])) {
$name = $_POST['name'];
$type = $_POST['type'];
if ($dir == "/")
$directory = "";
else
$directory = $dir;
if ($name == "") {
$error = $_lng['emptyname'];
}
else {
if ($type == "file") {
createDir();
$local = $dir_dataftp."/".$_ftp['id']."/".$name;
file_put_contents($local,"");
if (ftp_put($conn_id,$directory."/".$name,$local,FTP_BINARY)) {
ftp_site($conn_id,"CHMOD 0644 ".$directory."/".$name);
deleteDir($dir_dataftp."/".$_ftp['id']);
header("Location: index.php?ftp=list&dir=".rawurlencode($dir));
exit;
}
else {
$error = $_lng['cantcreatefile'];
}
}
else {
if (ftp_mkdir($conn_id,$directory."/".$name)) {
ftp_site($conn_id,"CHMOD 0755 ".$directory."/".$name);
header("Location: index.php?ftp=list&dir=".rawurlencode($dir));
exit;
}
else {
$error = $_lng['cantcreatedirectory'];
}
}
}
}
ftp_close($conn_id);
$title = "Create: ".htmlspecialchars($dir);
require_once("includes/header.php");
echo '<div class="content">';
showDirNav($dir);
if ($_ftp['help'] == "yes") {
echo '<div class="info">'.$_lng['help_create'].'</div><br />';
}
if ($error)
echo '<div class="error">'.$error.'</div>';
echo '<form method="post" action="index.php?ftp=create&amp;dir='.rawurlencode($dir).'">'.$_lng['name'].':<br /><input type="text" name="name" value=""><br />'.$_lng['type'].':<br /><select name="type"><option value="file">'.$_lng['filetitle'].'</option><option value="directory">'.$_lng['directory'].'</option></select><br /><input type="submit" name="create" value="   '.$_lng['createbutton'].'   "/></form></div>';
require_once("includes/footer.php");
?>