<?php
defined('PAGEDISPLAY') or die('Access Forbidden..!!');
if ($client_id == 0) {
header("Location: index.php");
exit;
}
deleteDir($dir_dataftp."/".$_ftp['id']);
$tm = time() - 10;
setcookie('rootid','',$tm,'/',$_SERVER['HTTP_HOST']);
setcookie('rootkey','',$tm,'/',$_SERVER['HTTP_HOST']);
session_destroy();
header("Location: index.php?log=".$_lng['log']."");
?>