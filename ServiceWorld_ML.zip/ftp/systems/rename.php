<?php
defined('PAGEDISPLAY') or die('Access Forbidden..!!');
if ($client_id == 0) {
header("Location: index.php");
exit;
}
$target = isset($_GET['dir']) ? rawurldecode($_GET['dir']) : rawurldecode($_GET['file']);
if ($target == "") {
header("Location: index.php?ftp=list");
exit;
}
$dir = explode("/",$target, -1);
$dir = implode("/",$dir);
if (isset($_POST['save'])) {
if ($dir == "/")
$dir = "";
$newname = $_POST['newname'];
if ($newname != "") {
if (ftp_rename($conn_id,$target,$dir."/".$newname)) {
header("Location: index.php?ftp=list&dir=".rawurlencode($dir));
exit;
}
else {
$error = '<div class="error">'.$_lng['renameerror'].'</div>';
}
}
else {
$error = '<div class="error">'.$_lng['emptynewname'].'</div>';
}
}
$title = $_lng['renametitle'].': '.htmlspecialchars($target);
require_once('includes/header.php');
echo '<div class="content">';
if ($error)
echo $error;
if (isset($_GET['file'])) {
showDirNav(str_replace('/'.basename($target),'',$target));
$value = htmlentities(basename($target));
echo '<form action="index.php?ftp=rename&amp;file='.rawurlencode($target).'" method="post">'.$_lng['oldname'].':<br /><b>'.$value.'</b><br />';
}
else {
showDirNav($target);
$value = htmlentities(str_replace($dir.'/','',$target));
echo '<form action="index.php?ftp=rename&amp;dir='.rawurlencode($target).'" method="post">'.$_lng['oldname'].':<br /><b>'.$value.'</b><br />';
}
echo ''.$_lng['newname'].':<br /><input name="newname" type="text" value="'.$value.'" size="6"/><br /><input type="submit" name="save" value="   '.$_lng['renamebutton'].'   "/></form></div>';
ftp_close($conn_id);
require_once('includes/footer.php');
?>