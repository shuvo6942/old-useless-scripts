<?php
defined('PAGEDISPLAY') or die('Access Forbidden..!!');
if ($client_id == 0) {
header("Location: index.php");
exit;
}
$file = rawurldecode(trim($_GET['file']));
$ext = getExtension($file);
if ($ext != "jpg" AND $ext != "jpeg" AND $ext != "gif" AND $ext != "png") {
header("Location: index.php?ftp=list");
exit;
}

$local = $dir_dataftp."/".$_ftp['id'];
$filename = basename($file);
$dir = substr($file,0,"-".(strlen($filename) + 1));

$title = $_lng['resizeimage'].": ".htmlspecialchars($file);
require_once("includes/header.php");
echo '<div class="content">';
showDirNav($dir);
if (isset($_POST['submit'])) {
createDir();
$width = $_POST['width'];
$height = $_POST['height'];
$save = $_POST['save'];
if (!ctype_digit($width) || !ctype_digit($height) || $width < 5 || $width > 999 || $height < 5 || $height > 999 || $save == "") {
echo '<div class="error">'.$_lng['error'].'</div>';
}
else {
if (!ftp_get($conn_id,$local."/".$filename,$file,FTP_BINARY)) {
echo '<div class="error">Can\'t get the file '.htmlentities($file).'</div>';
}
else {
$imagefile = $local."/".basename($file);

if ($ext == "jpg" || $ext == "jpeg" )
{
$src = imagecreatefromjpeg($imagefile);
}
elseif ($ext == "png") {
$src = imagecreatefrompng($imagefile);
}
else  {
$src = imagecreatefromgif($imagefile);
}

list($xwidth,$xheight) =getimagesize($imagefile);
$tmp = imagecreatetruecolor($width,$height);
if (imagecopyresampled($tmp,$src,0,0,0,0,$width,$height,$xwidth,$xheight) !== false) {
imagejpeg($tmp,$imagefile,100);
imagedestroy($src);
imagedestroy($tmp);
if (ftp_put($conn_id,$save,$imagefile,FTP_BINARY) !== false)
echo '<div class="success">'.str_replace('%image',htmlentities($save),str_replace('%h',$height,str_replace('%w',$width,$_lng['resizeimagesuccess']))).'</div>';
else
echo '<div class="error">'.$_lng['cantsavefile'].'</div>';
}
else {
echo '<div class="error">'.$_lng['resizeimageerror'].'</div>';
}
}
}

deleteDir($local);
}
else {
echo ''.showIcon('<img src="images/gif.png" alt=""/>','Image:').' <a href="index.php?ftp=file&amp;file='.rawurlencode($file).'">'.htmlentities($file).'</a><br /><form method="post" action="index.php?ftp=resize_image&amp;file='.rawurlencode($file).'"><b>'.$_lng['width'].'</b><br /><input type="text" name="width" size="3" maxlength="3" format="*N" value="240"><br /><b>'.$_lng['height'].'</b><br /><input type="text" name="height" size="3" maxlength="3" format="*N" value="320"><br /><b>'.$_lng['saveas'].'</b><br /><input type="text" name="save" value="'.htmlentities($dir).'/Resize_'.htmlentities($filename).'"><br /><input type="submit" name="submit" value="   '.$_lng['savebutton'].'   "/></form>';
}
echo '</div>';
ftp_close($conn_id);
require_once("includes/footer.php");
?>