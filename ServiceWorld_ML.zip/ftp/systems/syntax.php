<?php
defined('PAGEDISPLAY') or die('Access Forbidden..!!');
if ($client_id == 0) {
header("Location: index.php");
exit;
}
$file = rawurldecode(trim($_GET['file']));
if ($file == "" || substr($file,-4) != ".php") {
header("Location: index.php?ftp=list");
exit;
}
$size = ftp_size($conn_id,$file);
if ($size >= 222880) {
header("Location: index.php?ftp=list");
exit;
}

createDir();
if (ftp_get($conn_id,$dir_dataftp."/".$_ftp['id']."/".basename($file),$file,FTP_BINARY)) {
$syntax = file_get_contents($dir_dataftp."/".$_ftp['id']."/".basename($file));
$result = phpSyntax($syntax);
}
else {
$result = '<div class="error">'.$_lng['filenotfound'].'</div>';
}
deleteDir($dir_dataftp."/".$_ftp['id']);

ftp_close($conn_id);
$title = $_lng['syntaxtitle'].": ".htmlspecialchars($file);
require_once("includes/header.php");
echo '<div class="content">';
showDirNav(str_replace("/".basename($file),"",$file));
echo $_lng['filetitle'].': <a href="index.php?ftp=file&amp;file='.rawurlencode($file).'">'.htmlentities($file).'</a><br />';
echo $result;
echo '</div>';
require_once("includes/footer.php");
?>