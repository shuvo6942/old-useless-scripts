<?php
defined('PAGEDISPLAY') or die('Access Forbidden..!!');
if ($client_id == 0) {
header("Location: index.php");
exit;
}
$file = rawurldecode(trim($_GET['file']));
if (substr(strtolower($file),-4) != ".zip" && substr(strtolower($file),-4) != ".jar") {
header("Location: index.php");
exit;
}
$title = $_lng['unziptitle'].": ".htmlspecialchars($file);
require_once("includes/header.php");
echo '<div class="content">';
$dir = implode("/",explode("/",$file,-1));
if (!$dir || $dir == "")
$dir = "/";
showDirNav($dir);
if ($_ftp['help'] == "yes") {
echo '<div class="info">'.$_lng['help_unzip'].'</div><br />';
}
$local = $dir_dataftp."/".$_ftp['id'];
$zipname = "ZIP.zip";
if (isset($_POST['unzip'])) {
if (ftp_get($conn_id,$local."/".$zipname,$file,FTP_BINARY)) {
$directory = $_POST['directory'];
if ($directory == "")
$directory = $dir;
if (substr($directory,-1) == "/")
$directory = substr($directory,0,-1);
require_once('includes/pclzip.lib.php');
$zip = new PclZip($local."/".$zipname);
if ($zip->extract(PCLZIP_OPT_PATH, $local."/")!=0)
{
unlink($local."/".$zipname);
ftpMkDirRecusive($directory);
$files = localGlob($local);
$count = count($files);
foreach ($files as $file) {
$ftp_dir = str_replace("#REPLACE#".$local,$directory,str_replace(basename($file)."#REPLACE#","","#REPLACE#".$file."#REPLACE#"));
ftpMkDirRecusive($ftp_dir);
if (ftp_put($conn_id,$ftp_dir.basename($file),$file,FTP_BINARY)) {
echo '<div class="success">'.$ftp_dir.basename($file).' '.$_lng['unzipsuccess'].'</div>';
}
else {
echo '<div class="error">'.$ftp_dir.basename($file).' '.$_lng['unziperror'].'</div>';
}
}
echo ''.$_lng['totalfile'].' <b>'.$count.'</b>';
}
else {
echo '<div class="error">'.$_lng['unableextract'].' <b>'.htmlentities($file).'</b></div>';
}
}
else {
echo '<div class="error">'.$_lng['cantgetfile'].'</div>';
}
deleteDir($local);
}
else {
deleteDir($local);
createDir();
echo ''.$_lng['filetitle'].': <a href="index.php?ftp=file&amp;file='.htmlentities(rawurlencode($file)).'">'.htmlentities($file).'</a><br /><form method="post" action="index.php?ftp=unzip&amp;file='.rawurlencode($file).'">'.$_lng['unzipdir'].':<br /><input type="text" name="directory" value="'.htmlentities($dir).'"/><br /><input type="submit" name="unzip" value="   '.$_lng['unzipbutton'].'   "/></form>';
}
ftp_close($conn_id);
echo '</div>';
require_once("includes/footer.php");
?>