<?php
defined('PAGEDISPLAY') or die('Access Forbidden..!!');
if ($client_id == 0) {
header("Location: index.php");
exit;
}
$file=rawurldecode(trim($_GET['file']));
if ($file == NULL) {
header("Location: index.php?ftp=list");
}
$file=str_replace(".|htaccess",".htaccess",$file);
$size = ftp_size($conn_id,$file);

if (!is_dir($dir_dataftp)) {
mkdir($dir_dataftp, 0755, true);
file_put_contents($dir_dataftp."/.htaccess","deny from all
AddDefaultCharset UTF-8");
}
if (!is_dir($dir_dataftp."/".$_ftp['id'])) {
mkdir($dir_dataftp."/".$_ftp['id'], 0755, true);
file_put_contents($dir_dataftp."/".$_ftp['id']."/.htaccess","deny from all
AddDefaultCharset UTF-8");
}

$local = $dir_dataftp."/".$_ftp['id']."/".basename($file);

$download = ftp_get($conn_id,$local,$file,FTP_BINARY);
if ($download) {
if (file_exists($local)) {
header('Content-Description: File Transfer');
header('Content-Type: application/octet-stream');    header('Content-Disposition: attachment; filename='.basename($file));
header('Content-Transfer-Encoding: binary');
header('Expires: 0');
header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
header('Pragma: public');
header('Content-Length: ' .$size);
readfile($local);
unlink($local);
exit;
}
}
else {
header("Location: index.php?ftp=list");
}
?>