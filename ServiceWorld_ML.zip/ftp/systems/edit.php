<?php
defined('PAGEDISPLAY') or die('Access Forbidden..!!');
$file = rawurldecode(trim($_GET['file']));
$line = isset($_GET['line']) ? trim($_GET['line']) : '10';
$page = isset($_GET['page']) ? trim($_GET['page']) : '1';
if (empty($page) || !ctype_digit($page))
$page = 1;
$_start = trim($_GET['start']);
$_end = trim($_GET['end']);
if ($client_id == 0 || $file == "") {
header("Location: index.php");
exit;
}
$size = ftp_size($conn_id,$file);
if ($size >= 222880) {
header("Location: index.php?ftp=list");
exit;
}
createDir();
$localfile = $dir_dataftp."/".$_ftp['id']."/".basename($file);

if (!ftp_get($conn_id,$localfile,$file,FTP_BINARY)) {
header("Location: index.php?ftp=list");
exit;
}

if (isset($_POST['save'])) {
$body = $_POST['body'];
$read2 = file($localfile);
$k = count($read2) - 1;
if ($k >= 1) {
for ($s = 0; $s <= $k; $s++) {
if ($s >= $_start && $s <= $_end) {
if ($s == $_start)
$save .= $body;
else
$save .= "";
}
else {
$save .= $read2[$s];
}
}
}
else {
$save = $body;
}

if (file_put_contents($localfile,$save)) {
if (ftp_put($conn_id,$file,$localfile,FTP_BINARY)) {
$result .= "<div class=\"success\">".$_lng['editsuccess']."</div>";
}
else {
$result .= "<div class=\"error\">".$_lng['editerror']."</div>";
}
}
else {
$result .= "<div class=\"error\">".$_lng['editerror']."</div>";
}
}

$read = file($localfile);
$count = count($read) - 1;
if (!ctype_digit($line) || empty($line) || $line > 200)
$line = 20;
if (!ctype_digit($page) || empty($page) || $page == 0 || $page > (ceil($count / $line)))
$page =1;
$page--;
$start = $page * $line;
$page++;
$end = $start + $line;
for ($i = 0; $i <= $count; $i++) {
if ($i >= $start && $i <= $end) {
$area .= $read[$i];
}
else {
}
}

ftp_close($conn_id);
$title = $_lng['editfile'].": ".htmlspecialchars($file);
require_once("includes/header.php");
echo '<div class="content">';
$dir = substr($file,0,"-".(strlen(basename($file)) + 1));
showDirNav($dir);
echo '<div class="alt"><b>File:</b> <a href="index.php?ftp=file&amp;file='.rawurlencode($file).'">'.htmlspecialchars($file).'</a></div>';
if ($result)
echo $result;
echo '<div class="pagination">Line: '.$start.' - '.$end.' / '.($count - 1).'<br />';
showPagination($page,$line,$count,'index.php?ftp=edit&amp;file='.rawurlencode($file).'&amp;line='.htmlentities($line).'&amp;page=');
echo '</div>';
echo '<form action="index.php?ftp=edit&amp;file='.rawurlencode($file).'&amp;start='.htmlentities($start).'&amp;end='.htmlentities($end).'&amp;line='.htmlentities($line).'&amp;page='.htmlentities($page).'" method="post">
<textarea name="body" rows="5" cols="20">';
echo htmlentities($area,ENT_QUOTES);
echo '</textarea>';
echo '<br /><input type="submit" name="save" value="   '.$_lng['savebutton'].'   ">
</form><br />';
echo '<div class="pagination">Line: '.$start.' - '.$end.' / '.($count - 1).'<br />';
showPagination($page,$line,$count,'index.php?ftp=edit&amp;file='.rawurlencode($file).'&amp;line='.htmlentities($line).'&amp;page=');
echo '</div>';
echo '</div><div class="menu"><ul>';
echo '<li><a href="index.php?ftp=source&amp;file='.rawurlencode($file).'">'.showIcon('<img src="images/txt.png" alt=""/>','&raquo;').' '.$_lng['sourcetitle'].'</a></li>';
$ext = getExtension(basename($file));
if ($ext == "php") {
echo '<li><a href="index.php?ftp=syntax&amp;file='.rawurlencode($file).'">'.showIcon('<img src="images/syntax.png" alt=""/>','&raquo;').' '.$_lng['checksyntax'].'</a></li>';
}
echo '</ul></div>';
unlink($localfile);
require_once("includes/footer.php");
?>