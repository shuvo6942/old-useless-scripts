<?php
defined('PAGEDISPLAY') or die('Access Forbidden..!!');
if ($client_id == 0) {
header("Location: index.php");
exit;
}
$file = rawurldecode(trim($_GET['file']));
if(!$tm = ftp_mdtm($conn_id,$file)){
header("Location: index.php?ftp=list");
exit;
}
$size = ftp_size($conn_id,$file);
$title = $_lng['filetitle'].": ".htmlspecialchars($file);
require_once("includes/header.php");
echo '<div class="content">';

$zn = 7 * 60 * 60;
@ftp_close($conn_id);
$filesize = $size;
if ($size < 1024) {
$size = "$size bytes";
}
elseif ($size >= "1024" && $size < "1048576") {
$size = strtr(round($size/1024,2),".",",")." kb";
}
elseif ($size >= 1048576) {
$size = strtr(round($size/1024/1024,2),".",",")." mb";
}
if ($tm <> NULL) {
$tmv = gmdate("d-m-Y, H:i:s",$tm+$zn)." GMT";
} else {
$tmv="-";
}
$dir = explode("/", $file, -1);
$dir = implode("/",$dir);
showDirNav($dir);
echo '<div class="clear"></div><div class="alt"><h2>'.$_lng['fileinfo'].'</h2>'.$_lng['filename'].': <font color="red">'.basename($file).'</font><br />'.$_lng['filesize'].': '.$size.'<br />
'.$_lng['lastmodified'].': '.$tmv;
$ext = getExtension(basename($file));

$archiveExt = array('zip','jar','tar','tgz','tgz2','gz','gz2','bz','bz2','tbz','tbz2');

$ext1 = array("jpg","jpeg","jpe","png","gif","bmp","dll","wav","mid","midi","mp3","mmf","psd","doc","pdf","zip","rar","jar","3gp","avi","mp4","class","tgz","gz","bz","gz2","bz2","tbz","tbz2","tgz2","tar");
if (!in_array($ext,$ext1) AND $filesize <= 222880) {
echo '<br /><h2>'.$_lng['editfile'].'</h2><form method="get" action="index.php?"><input type="hidden" name="ftp" value="edit"><input type="hidden" name="file" value="'.$file.'"/><input name="line" type="text" value="10" size="2" format="*N" maxlenght="2"/><input type="submit" value="'.$_lng['editfile'].'"/></form>';
}
echo '</div>';
$ext2 = array("zip","jar","rar","tgz","gz","bz","gz2","bz2","tbz","tbz2","tgz2","tar");
$ext3 = array("zip","jar","rar","tgz","gz","bz","gz2","bz2","tbz","tbz2","tgz2","tar");
echo '</div><div class="menu"><ul>';
if (in_array($ext,$archiveExt) && $filesize <= 12716800 && $filesize > 0) {
if ($ext == "zip" || $ext == "jar") {
echo '<li><a href="index.php?ftp=open_zip&amp;file='.rawurlencode($file).'">'.showIcon('<img src="images/ofile.png" alt=""/>','&raquo;').' '.$_lng['openarchive'].'</a></li><li><a href="index.php?ftp=unzip&amp;file='.rawurlencode($file).'">'.showIcon('<img src="images/efile.png" alt=""/>','&raquo;').' '.$_lng['extractarchive'].'</a></li>';
}
elseif ($ext == "tar" || $ext == "tgz" || $ext == "gz" || $ext =="gz2" || $ext == "bz" || $ext == "bz2" || $ext == "tbz" || $ext == "tbz2" || $ext == "tgz2") {
echo '<li><a href="index.php?ftp=open_tar&amp;file='.rawurlencode($file).'">'.showIcon('<img src="images/ofile.png" alt=""/>','&raquo;').' '.$_lng['openarchive'].'</a></li><li><a href="index.php?ftp=untar&amp;file='.rawurlencode($file).'">'.showIcon('<img src="images/efile.png" alt=""/>','&raquo;').' '.$_lng['extractarchive'].'</a></li>';
}
}
else {
echo '<li><a href="index.php?ftp=source&amp;file='.rawurlencode($file).'">'.showIcon('<img src="images/txt.png" alt=""/>','&raquo;').' '.$_lng['sourcetitle'].'</a></li>';
}
if ($ext == "sql" && $filesize <= 204800) {
echo '<li><a href="index.php?ftp=sql_installer&amp;file='.rawurlencode($file).'">'.showIcon('<img src="images/inst.gif" alt=""/>','&raquo;').' '.$_lng['createinstaller'].'</a></li>';
}
if ($ext == "php") {
echo '<li><a href="index.php?ftp=syntax&amp;file='.rawurlencode($file).'">'.showIcon('<img src="images/syntax.png" alt=""/>','&raquo;').' '.$_lng['checksyntax'].'</a></li>';
}
if ($ext == "jpg" OR $ext == "jpeg" OR $ext == "gif" OR $ext == "png") {
echo '<li><a href="index.php?ftp=resize_image&amp;file='.rawurlencode($file).'">'.showIcon('<img src="images/gif.png" alt=""/>','&raquo;').' '.$_lng['resizeimage'].'</a></li>';
}
echo '<li><a href="index.php?ftp=download&amp;file='.rawurlencode($file).'">'.showIcon('<img src="images/dnld.gif" alt=""/>','&raquo;').' '.$_lng['download'].'</a></li><li><a href="index.php?ftp=copy&amp;file='.rawurlencode($file).'">'.showIcon('<img src="images/copy.gif" alt=""/>','&raquo;').' '.$_lng['copytitle'].'</a></li><li><a href="index.php?ftp=move&amp;file='.rawurlencode($file).'">'.showIcon('<img src="images/move.gif" alt=""/>','&raquo;').' '.$_lng['movetitle'].'</a></li><li><a href="index.php?ftp=rename&amp;file='.rawurlencode($file).'">'.showIcon('<img src="images/rename.gif" alt=""/>','&raquo;').' '.$_lng['renametitle'].'</a></li><li><a href="index.php?ftp=delete&amp;file='.rawurlencode($file).'" onclick="return confirm(\''.$_lng['deleteconfirm'].'\')">'.showIcon('<img src="images/delete.gif" alt=""/>','&raquo;').' '.$_lng['deletetitle'].'</a></li></ul></div>';
require_once("includes/footer.php");
?>