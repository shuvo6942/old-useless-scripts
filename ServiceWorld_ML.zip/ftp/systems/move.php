<?php
defined('PAGEDISPLAY') or die('Access Forbidden..!!');
if ($client_id == 0) {
header("Location: index.php");
exit;
}
$target = isset($_GET['file']) ? rawurldecode(trim($_GET['file'])) : rawurldecode(trim($_GET['dir']));
if ($target == "") {
header("Location: index.php?ftp=list");
exit;
}
if (isset($_GET['file'])) {
$dir = str_replace("/".basename($target),"",$target);
}
else {
$dir = implode("/",explode("/",$target,-1));
}
if (isset($_POST['submit'])) {
$move = $_POST['move'];
$chmod = $_POST['chmod'];
if ($move == "")
$error .= $_lng['error'];
if (strlen($chmod) != 3 || !ctype_digit($chmod)) 
$error .= $_lng['chmodterms'];
if (empty($error)) {
if (ftp_rename($conn_id,$target,$move)) {
ftp_site($conn_id,"CHMOD 0".$chmod." ".$move);
header("Location: index.php?ftp=list&dir=".rawurlencode($dir));
exit;
}
else {
$notice = '<div class="error">'.$_lng['error'].'</div>';
}
}
else {
$notice = '<div class="error">'.$error.'</div>';
}
}

$title = $_lng['movetitle'].": ".htmlspecialchars($target);
require_once("includes/header.php");
echo '<div class="content">';
showDirNav($dir);
if ($_ftp['help'] == "yes") {
echo '<div class="info">'.$_lng['help_move'].'</div><br />';
}
if ($notice)
echo $notice;
if (isset($_GET['file'])) {
echo ''.$_lng['filetitle'].': <a href="index.php?ftp=file&amp;file='.htmlentities(rawurlencode($target)).'">'.htmlentities($target).'</a><br /><form method="post" action="index.php?ftp=move&amp;file='.rawurlencode($target).'">';
$cmd = 644;
}
else {
echo ''.$_lng['directory'].': <a href="index.php?ftp=list&amp;dir='.htmlentities(rawurlencode($target)).'">'.htmlentities($target).'</a><br /><form method="post" action="index.php?ftp=move&amp;dir='.rawurlencode($target).'">';
$cmd = 755;
}
echo ''.$_lng['moveto'].':<br /><input type="text" name="move" value="'.htmlspecialchars($target).'"><br />'.$_lng['chmod'].':<br /><input type="text" name="chmod" value="'.$cmd.'" size="3" maxlength="3" format="*N"/><br /><input type="submit" name="submit" value="   '.$_lng['movebutton'].'   "/></form></div>';
require_once("includes/footer.php");
ftp_close($conn_id);
?>