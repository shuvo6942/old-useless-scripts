<?php
defined('PAGEDISPLAY') or die('Access Forbidden..!!');
if ($client_id == 0) {
header("Location: index.php");
exit;
}
$file = rawurldecode($_GET['file']);
if ($file == "") {
header("Location: index.php?ftp=list");
exit;
}
$local = $dir_dataftp."/".$_ftp['id'];
$filename = basename($file);
$dir = substr($file,"0","-".(strlen($filename) + 1));
if (isset($_POST['submit'])) {
$host = $_POST['host'];
$user = $_POST['user'];
$pass = $_POST['pass'];
$db = $_POST['db'];
$save = $_POST['save'];
if (empty($save) || empty($host) || empty($user) || empty($pass) || empty($db)) {
$error = $_lng['formerror'];
}
else {
createDir();

$php = '<!-- installer by http://7ko.in --><html><head><title>Install</title></head><body>'."\r\n".'<?php'."\r\n".'if (!file_exists("'.$filename.'")) {'."\r\n".'die("'.$filename.' Dosnt Exists!");'."\r\n".'}'."\r\n".'$handle = fopen("'.$filename.'", "r");'."\r\n".'$contents = fread($handle, filesize("'.$filename.'"));'."\r\n".'fclose($handle);'."\r\n".'$contents=preg_replace("~(--|##)[^\r]*\r~","\r",$contents);'."\r\n".'$contents = explode(";",$contents);'."\r\n".'mysql_connect("'.$host.'","'.$user.'","'.$pass.'") or exit(mysql_error());'."\r\n".'mysql_select_db("'.$db.'") or exit(mysql_error());'."\r\n".'foreach ($contents as $query) {'."\r\n".'if (!empty($query)) {'."\r\n".'mysql_query($query) or die(mysql_error());'."\r\n".'echo "Successfully execute Query ".htmlentities(substr($query,0,20))."...<br />";'."\r\n".'}}'."\r\n".'?>'."\r\n".'</body><html>';
file_put_contents($local."/install.php",$php);
ftp_put($conn_id,$dir."/".$save,$local."/install.php",FTP_BINARY);
ftp_close($conn_id);
deleteDir($local);
header("Location: index.php?ftp=list&dir=".rawurlencode($dir));
exit;
}
}
else {
$title = $_lng['createinstaller'].": ".htmlspecialchars($file);
require_once("includes/header.php");
echo '<div class="content">';
showDirNav($dir);
if ($error)
echo '<div class="error">'.$error.'</div>';
echo '<b>'.$_lng['filetitle'].':</b> <a href="index.php?ftp=file&amp;file='.rawurlencode($file).'">'.htmlentities($file).'</a><br /><form method="post" action="index.php?ftp=sql_installer&amp;file='.rawurlencode($file).'"><b>'.$_lng['filename'].':</b><br /><input type="text" name="save" value="install.php"><br /><b>'.$_lng['sqlhost'].':</b><br /><input type="text" name="host" value="localhost"><br /><b>'.$_lng['sqluser'].':</b><br /><input type="text" name="user" value=""><br /><b>'.$_lng['sqlpassword'].':</b><br /><input type="password" name="pass" value=""><br /><b>'.$_lng['sqldatabase'].':</b><br /><input type="text" name="db" value=""><br /><br /><input type="submit" name="submit" value="   '.$_lng['createsqlbutton'].'   "/></form>';
echo '</div>';
require_once("includes/footer.php");
}
ftp_close($conn_id);
?>