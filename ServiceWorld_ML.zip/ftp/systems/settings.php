<?php
defined('PAGEDISPLAY') or die('Access Forbidden..!!');
if ($client_id == 0) {
header("Location: index.php");
exit;
}
$dir = isset($_GET['dir']) ? rawurldecode($_GET['dir']) : '';
if ($dir == "")
$dir = "/public_html";
if (!ftp_chdir($conn_id,$dir)) {
header("Location: index.php?ftp=list");
exit;
}
if ($dir != "/" AND substr($dir,-1) == "/")
$dir = substr($dir,0,-1);
$timeout = ftp_get_option($conn_id,FTP_TIMEOUT_SEC);
ftp_close($conn_id);
if (isset($_POST['save'])) {
$size = $_POST['size'];
$icon = $_POST['icon'];
$view = $_POST['view'];
$help = $_POST['help'];
mysql_query("UPDATE `".$db_prefix."ftp` SET `size` = '".mysql_real_escape_string($size)."', `icon` = '".mysql_real_escape_string($icon)."', `view` = '".mysql_real_escape_string($view)."', `help` = '".mysql_real_escape_string($help)."' WHERE `id` = '".$_ftp['id']."'");
$notice = $_lng['settingssuccessfullysaved'];
}
$title = $_lng['settings'];
require_once("includes/header.php");
echo '<div class="content">';
showDirNav($dir);
if ($notice)
header("Location: index.php?ftp=list&dir=".rawurlencode($dir)."&msg=".$_lng['settingssuccessfullysaved']."");
echo '<form method="post" action="index.php?ftp=settings">&raquo; '.$_lng['ftpserver'].': '.htmlentities($_ftp['server']).'<br />&raquo; '.$_lng['ftpport'].': '.htmlentities($_ftp['port']).'<br />&raquo; '.$_lng['ftpusername'].': '.htmlspecialchars($_ftp['username']).'<br />&raquo; '.$_lng['ftppassword'].': ****<br />&raquo; Time out: '.$timeout.'<br />&raquo; '.$_lng['showsize'].': <select name="size" size="3"><option value="yes"'.(($_ftp['size'] == 'yes') ? ' selected="selected"' : '').'>'.$_lng['yes'].'</option><option value="no"'.(($_ftp['size'] == 'no') ? ' selected="selected"' : '').'>'.$_lng['no'].'</option></select><br />&raquo; '.$_lng['showicon'].': <select name="icon" size="3"><option value="yes"'.(($_ftp['icon'] == 'yes') ? ' selected="selected"' : '').'>'.$_lng['yes'].'</option><option value="no"'.(($_ftp['icon'] == 'no') ? ' selected="selected"' : '').'>'.$_lng['no'].'</option></select><br />&raquo; '.$_lng['elementsperpage'].': <select name="view" size="3">';
function __sel($num) {
if ($GLOBALS['_ftp']['view'] == $num)
$return = ' selected="selected"';
else
$return = "";
return $return;
}
echo '<option value="10"'.__sel('10').'>10</option><option value="20"'.__sel('20').'>20</option><option value="30"'.__sel('30').'>30</option><option value="40"'.__sel('40').'>40</option><option value="50"'.__sel('50').'>50</option><option value="60"'.__sel('60').'>60</option><option value="70"'.__sel('70').'>70</option><option value="80"'.__sel('80').'>80</option><option value="90"'.__sel('90').'>90</option><option value="100"'.__sel('100').'>100</option>
</select><br /><br />&raquo; '.$_lng['showhelptext'].': <select name="help" size="3"><option value="yes"'.(($_ftp['help'] == 'yes') ? ' selected="selected"' : '').'>'.$_lng['yes'].'</option><option value="no"'.(($_ftp['help'] == 'no') ? ' selected="selected"' : '').'>'.$_lng['no'].'</option></select><br /><input type="submit" name="save" value="'.$_lng['savebutton'].'"/></form></div>';
require_once("includes/footer.php");
?>