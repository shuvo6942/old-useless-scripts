<?php
defined('PAGEDISPLAY') or die('Access Forbidden..!!');
if ($client_id == 0) {
header("Location: index.php");
exit;
}
$target = isset($_GET['dir']) ? rawurldecode($_GET['dir']) : rawurldecode($_GET['file']);
$value=trim($_GET['value']);
if ($target == "") {
header("Location: index.php?ftp=list");
exit;
}
if (isset($_POST['save'])) {
$back = implode("/",explode("/",$target,-1));
$chmod = $_POST['chmod'];
if (strlen($chmod) == 3 AND ctype_digit($chmod)) {
if (ftp_site($conn_id,"CHMOD 0".$chmod." ".$target) !== false) {
header("Location: index.php?ftp=list&dir=".rawurlencode($back));
exit;
}
else {
$error = '<div class="error">'.$_lng['chmoderror'].'</div>';
}
}
else {
$error = '<div class="error">'.$_lng['chmodterms'].'</div>';
}
}
$title = $_lng['chmodtitle'].": ".htmlspecialchars($target);
require_once('includes/header.php');
echo '<div class="content">';
if (isset($_GET['file'])) {
showDirNav(str_replace(basename($target),'',$target));
if ($_ftp['help'] == "yes") {
echo '<div class="info">'.$_lng['help_chmod'].'</div><br />';
}
if ($error)
echo $error;
echo '<form action="index.php?ftp=chmod&amp;file='.rawurlencode($target).'&amp;value='.htmlentities($value).'" method="post">'.$_lng['filetitle'].': <a href="index.php?ftp=file&amp;file='.htmlentities(rawurlencode($target)).'">'.htmlentities($target).'</a><br />';
}
else {
showDirNav($target);
if ($_ftp['help'] == "yes") {
echo '<div class="info">'.$_lng['help_chmod'].'</div><br />';
}
if ($error)
echo $error;
echo '<form action="index.php?ftp=chmod&amp;dir='.rawurlencode($target).'&amp;value='.htmlentities($value).'" method="post">'.$_lng['directory'].': <a href="index.php?ftp=list&amp;dir='.htmlentities(rawurlencode($target)).'">'.htmlentities($target).'</a><br />';
}
echo ''.$_lng['chmod'].'<br /><input name="chmod" type="text" value="'.htmlentities($value).'" size="3" maxlength="3" format="*N"/><br /><input type="submit" name="save" value="   '.$_lng['chmodbutton'].'   "/></form></div>';
ftp_close($conn_id);
require_once('includes/footer.php');
?>