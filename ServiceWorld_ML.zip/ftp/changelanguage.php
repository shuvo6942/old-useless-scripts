<?php
session_start();
$lng = isset($_GET['language']) ? $_GET['language'] : 'english';
$lng = strtolower(preg_replace('#([\W_]+)#','-',$lng));
if (file_exists("lang/".$lng.".php")) {
$lang = $lng;
} else {
$lang = "english";
}
$_SESSION['language'] = $lang;
$r = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : 'index.php';
header("Location: ".str_replace('&amp;','&',htmlentities($r)));
?>