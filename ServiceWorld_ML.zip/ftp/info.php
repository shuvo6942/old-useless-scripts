<?php
define('PAGEDISPLAY', true);
if (!file_exists("includes/config.php")) {
echo "Please install before..!!";
exit;
}
ignore_user_abort(true);
error_reporting(0);
mb_internal_encoding('UTF-8');
ini_set('default_charset','UTF-8');
date_default_timezone_set('UTC');
ini_set('session.cookie_domain', $_SERVER['HTTP_HOST']);
/*
set_time_limit(0);
*/
ob_start();
session_start();
include("language.php");
require("includes/config.php");
$sql_connect = mysql_connect($db_host,$db_user,$db_pass);
if (!$sql_connect) {
die("Connecting Error..!!");
exit;
}
mysql_select_db($db_name) or die('Database Error..!!');
function deleteDir($path) {
$directory = $path;
if(is_dir($directory)) {
$directoryHandle = scandir($directory);
foreach ($directoryHandle as $contents) {
if($contents != '.' && $contents != '..') {
$path = $directory . "/" . $contents;
if(is_dir($path)) {
deleteDir($path);
} else {
unlink($path);
}
}
}
reset($directoryHandle);
rmdir($directory);
}
}
// Start
$__tm = time() - 3600;
$__q = mysql_query("SELECT * FROM `".$db_prefix."ftp` WHERE `lastlogin` < '".$__tm."' AND `delete` > '1' LIMIT 1");
if (mysql_num_rows($__q) > 0) {
$__f = mysql_fetch_array($__q);
deleteDir($dir_dataftp."/".$__f['id']);
mysql_query("UPDATE `".$db_prefix."ftp` SET `delete` = '1' WHERE `id` = '".$__f['id']."'");
}
// End
$conn_id = 0;
$login = 0;
$title = $_lng['about'];
require_once("includes/header.php");
echo '<div class="content">'.$_lng['aboutftp'].'</div>';
require_once("includes/footer.php");
?>