<?php
define('PAGEDISPLAY', true);
if (!file_exists("includes/config.php")) {
echo "Please install before..!!";
exit;
}
ignore_user_abort(true);
error_reporting(0);
mb_internal_encoding('UTF-8');
ini_set('default_charset','UTF-8');
date_default_timezone_set('UTC');
ini_set('session.cookie_domain', $_SERVER['HTTP_HOST']);
/*
set_time_limit(0);
*/
ob_start();
session_start();
include("language.php");
require("includes/config.php");
$sql_connect = mysql_connect($db_host,$db_user,$db_pass);
if (!$sql_connect) {
die("Connecting Error..!!");
exit;
}
mysql_select_db($db_name) or die('Database Error..!!');
function deleteDir($path) {
$directory = $path;
if(is_dir($directory)) {
$directoryHandle = scandir($directory);
foreach ($directoryHandle as $contents) {
if($contents != '.' && $contents != '..') {
$path = $directory . "/" . $contents;
if(is_dir($path)) {
deleteDir($path);
} else {
unlink($path);
}
}
}
reset($directoryHandle);
rmdir($directory);
}
}
// Start
$__tm = time() - 3600;
$__q = mysql_query("SELECT * FROM `".$db_prefix."ftp` WHERE `lastlogin` < '".$__tm."' AND `delete` > '1' LIMIT 1");
if (mysql_num_rows($__q) > 0) {
$__f = mysql_fetch_array($__q);
deleteDir($dir_dataftp."/".$__f['id']);
mysql_query("UPDATE `".$db_prefix."ftp` SET `delete` = '1' WHERE `id` = '".$__f['id']."'");
}
// End
$conn_id = 0;
$login = 0;
$title = $_lng['contact'];
require_once("includes/header.php");
echo '<div class="content">';
if (isset($_GET['msg'])) {
echo "<div class='success'>$_GET[msg]</div>";
}
echo('<div align="left"><form name="contact" method="post" action="contmail.php"><font color="silver">Your name:</font><br>
<input type="text" name="Full_Name" id="Full_Name" class="inputlogin" maxlength="20" size="20"><br/>
<font color="silver">Your email:</font><br>
<input type="text" name="Email_Address" id="Email_Address" class="inputlogin" maxlength="35" size="20"><br/>
<font color="silver">Phone number:</font><br>
<input type="text" name="Telephone_Number" id="Telephone_Number" class="inputlogin" maxlength="25" size="20"><br/>
<font color="silver">Priority</font><br>
<select name="priority" size="1"><option value="General Support">General Support</option>
<option value="Technical Support">Technical Support</option>
<option value="Wapmaster">WapFtp Support</option>
</select><br/>
<font color="silver">Message:</font><br>
<textarea  rows="6" cols="20" name="Your_Message" id="Your_Message" maxlength="2000"></textarea><br/>
<font color="silver">Using only numbers, what is 10 plus 15..??</font>&nbsp;<input type="text" name="AntiSpam" id="AntiSpam" class="inputlogin" maxlength="100" style="width:30px"><br>');
$ipi = (getenv('HTTP_X_FORWARDED_FOR') != '') ? getenv('HTTP_X_FORWARDED_FOR') : $_SERVER['REMOTE_ADDR'];
$httpagenti = (getenv('HTTP_USER_AGENT') != '') ? getenv('HTTP_USER_AGENT') : $_SERVER['HTTP_X_OPERAMINI_PHONE_UA'];
echo('<input type="hidden" name="ip" value="' . htmlspecialchars($ipi) . '"/>
<input type="hidden" name="httpagent" value="' . htmlspecialchars($httpagenti) . '"/>
<input type="submit" class="button" style="font-weight:bold;" value="Send"><input type="reset" class="button" style="font-weight:bold;" value="Clear">
</form></div>');
echo '</div>';
require_once("includes/footer.php");
?>