<?php
define('PAGEDISPLAY', true);
if (!file_exists("includes/config.php")) {
echo "Please install before..!!";
exit;
}
ignore_user_abort(true);
error_reporting(0);
mb_internal_encoding('UTF-8');
ini_set('default_charset','UTF-8');
date_default_timezone_set('UTC');
ini_set('session.cookie_domain', $_SERVER['HTTP_HOST']);
/*
set_time_limit(0);
*/
ob_start();
session_start();
include("language.php");
require("includes/config.php");
$sql_connect = mysql_connect($db_host,$db_user,$db_pass);
if (!$sql_connect) {
die("Connecting Error..!!");
exit;
}
mysql_select_db($db_name) or die('Database Error..!!');
function deleteDir($path) {
$directory = $path;
if(is_dir($directory)) {
$directoryHandle = scandir($directory);
foreach ($directoryHandle as $contents) {
if($contents != '.' && $contents != '..') {
$path = $directory . "/" . $contents;
if(is_dir($path)) {
deleteDir($path);
} else {
unlink($path);
}
}
}
reset($directoryHandle);
rmdir($directory);
}
}
// Start
$__tm = time() - 3600;
$__q = mysql_query("SELECT * FROM `".$db_prefix."ftp` WHERE `lastlogin` < '".$__tm."' AND `delete` > '1' LIMIT 1");
if (mysql_num_rows($__q) > 0) {
$__f = mysql_fetch_array($__q);
deleteDir($dir_dataftp."/".$__f['id']);
mysql_query("UPDATE `".$db_prefix."ftp` SET `delete` = '1' WHERE `id` = '".$__f['id']."'");
}
// End
$conn_id = 0;
$login = 0;
if(isset($_POST['Email_Address'])) {
$fmail = "server@gmail.com";
$email_to = $fmail;
$email_subject = "WapFtp Support";
$thankyou = "contact.php?msg=Your message successfully Sent..!!";
// if you update the question on the feedback form
// you need to update the questions answer below
$antispam_answer = "25";
function died ($error) {
$title = $_lng['contact'];
require_once("includes/header.php");
echo ('<div class="content"><center><font color="silver"><b>Contact Errors</b></font></center>');
echo('<div align="left">');
echo "Sorry, but there were error(s) found with the form you submitted..!!<br/>";
echo "These errors appear below..<br/>";
echo("$error");
echo('Please go back and fix these errors..!!<br><a href="' . htmlspecialchars($_SERVER['HTTP_REFERER']) . '"><font color="#3399ff">Back</font></a></div>');
echo '</div>';
require_once("includes/footer.php");
die();
}
if(!isset($_POST['Full_Name']) || !isset($_POST['Email_Address']) || !isset($_POST['Telephone_Number']) || !isset($_POST['priority']) || !isset($_POST['Your_Message']) || !isset($_POST['AntiSpam']) || !isset($_POST['ip']) || !isset($_POST['httpagent'])) {
died('Sorry, there appears to be a problem with your form submission..!!');
}
$full_name = $_POST['Full_Name']; // required
$email_from = $_POST['Email_Address']; // required
$telephone = $_POST['Telephone_Number']; // not required
$priority = $_POST['priority']; // required
$comments = $_POST['Your_Message']; // required
$antispam = $_POST['AntiSpam']; // required
$ip = $_POST['ip']; // required
$httpagent = $_POST['httpagent']; // required
$error_message = "";
$email_exp = '/^[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$/';
if (preg_match($email_exp,$email_from)==0) {
$error_message .= 'The Email Address you entered does not appear to be valid..!!<br/>';
}
if (strlen($full_name) < 2) {
$error_message .= 'Your Name does not appear to be valid..!!<br/>Name must be over 3 letters..!!<br/>';
}
if (strlen($telephone) < 1) {
$error_message .= 'Your Phone number does not appear to be valid..!!<br/>Write (-) if u dont have it..!!<br/>';
}
if (strlen($comments) < 2) {
$error_message .= 'The Comments you entered do not appear to be valid..!!<br/>';
}
if ($antispam <> $antispam_answer) {
$error_message .= 'The Anti-Spam answer you entered is not correct..!!<br/>';
}
if (strlen($error_message) > 0) {
died($error_message);
}
$email_message = "Form details below..\r\n";
function clean_string ($string) {
$bad = array("content-type","bcc:","to:","cc:","http:","shit","fuck");
return str_replace($bad,"",$string);
}
$email_message .= "Full Name: ".clean_string($full_name)."\r\n";
$email_message .= "Email: ".clean_string($email_from)."\r\n";
$email_message .= "Telephone: ".clean_string($telephone)."\r\n";
$email_message .= "Priority: ".$_POST['priority']."\r\n";
$email_message .= "Message: ".clean_string($comments)."\r\n";
$email_message .= "IP: ".clean_string($ip)."\r\n";
$email_message .= "Browser: ".clean_string($httpagent)."\r\n";
$email_message .= "Date: ".gmdate("d-m-Y h:i:s a",time()+3600*($timezone))." GMT\r\n";
$headers = 'From: '.$email_from."\r\n".
'Reply-To: '.$email_from."\r\n" .
'X-Mailer: PHP/' . phpversion();
mail($email_to, $email_subject, $email_message, $headers);
header("Location: $thankyou");
}
?>