<?php
defined('PAGEDISPLAY') or die('OK');
$title = isset($title) ? $title : $_SERVER['HTTP_HOST'];
echo '<?xml version="1.0" encoding="utf-8"?><!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN"
"http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head><title>'.$title.'</title>
<meta http-equiv="expires" content="0"/>
<meta http-equiv="Content-Language" content="en-us"/>
<meta http-equiv="content-type" content="Text/html;
charset=UTF-8"/>
<meta name="description" content="Wap FTP Client Service. This Free, Fast, Easy and Secure."/>
<meta name="keywords" content="Wap,ftp,client,secure wapftp,wap ftp,ftp,online,free,ftp client,unzip,php"/>
<meta name="copyright" content="Copyright (c) 2011 WAP-FTP"/>
<meta name="author" content="Comrade79"/>
<meta name="google-site-verification" content="EXXtOeA-u2xae7-bBLPSwNh8Aw9ZAK2BPmtapjJoef4"/>
<meta name="charset" content="UTF-8"/>
<meta name="distribution" content="Global"/>
<meta name="rating" content="General"/>
<meta name="robots" content="Index,follow"/>
<meta name="revisit-after" content="3 Day"/>
<link rel="shortcut icon" href="favicon.ico"/>
<link rel="stylesheet" href="css.php" type="text/css"/>
</head><body>';
echo '<div id="header"><h1>';
if ($conn_id && $login)
echo '<a href="./"><b>'.strtoupper(htmlentities($_ftp['username'])).'</b></a>';
else
echo '<a href="./"><b>'.strtoupper(htmlentities($_SERVER['HTTP_HOST'])).'</b></a>';
echo '</h1></div>';
if ($conn_id && $login)
echo '<div class="cm"><table width="100%" cellspacing="0px" cellpading="0px" border="0px"><tr><td align="center" width="auto"><a href="index.php?ftp=settings">'.$_lng['settings'].'</a></td><td align="center" width="8px"><img src="/images/ver.png" alt=""/></td><td align="center" width="auto"><a href="index.php?ftp=logout">'.$_lng['logout'].'</a></td><td align="center" width="auto"> </td></tr></table></div>';
else
echo '<div class="cm"><table width="100%" cellspacing="0px" cellpading="0px" border="0px"><tr><td align="center" width="auto"><a href="http://creators.tk">Forum</a></td><td align="center" width="8px"><img src="/images/ver.png" alt=""/></td><td align="center" width="auto"><a href="/info.php">'.$_lng['about'].'</a></td><td align="center" width="8px"><img src="/images/ver.png" alt=""/></td><td align="center" width="auto"><a href="/contact.php">'.$_lng['contact'].'</a></td><td align="center" width="auto"> </td></tr></table></div>';
echo '<div id="wrapper">';
?>