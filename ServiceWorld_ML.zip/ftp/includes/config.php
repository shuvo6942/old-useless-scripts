<?php

defined('PAGEDISPLAY') or die ('Access Forbidden!');

$db_host = 'mysql17.000webhost.com';
$db_name = 'a9284034_ftp';
$db_user = 'a9284034_ftp';
$db_pass = 'shuvo2';
$db_prefix = 'myftp_shuvo';
$dir_dataftp = './myftp_tmp';
$admin_pass = 'f798924301f107c2fdb9cab4df7e6d2c';

?>