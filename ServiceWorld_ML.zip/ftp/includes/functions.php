<?php
defined('PAGEDISPLAY') or die('Access Forbidden..!!');
function showPagination($page,$max_view,$total,$link) {
$total_pages = $total;
if (empty($page) || ($page == 0)) $page = 1;
$prev = $page - 1;       
$next = $page + 1;      
$lastpage = ceil($total_pages/$max_view);
$lpm1 = $lastpage - 1;  if($lastpage > 1) { 
echo 'Page: ';
if ($page > 1) 
echo '<a href="'.$link.$prev.'">&laquo;</a>';
else
echo '';
if ($lastpage < 7 + (3 * 2)) {
for ($counter = 1; $counter <= $lastpage; $counter++) {
if ($counter == $page)
echo '<span>'.$counter.'</span>';
else
echo '<a href="'.$link.$counter.'">'.$counter.'</a>';
}
}
elseif($lastpage > 5 + (3 * 2)) {
  
if($page < 1 + (3 * 2)) {
for ($counter = 1; $counter < 4 + (3 * 2); $counter++) {
if ($counter == $page)
echo '<span>'.$counter.'</span>';
else
echo '<a href="'.$link.$counter.'">'.$counter.'</a>';     
}
echo '<span>...</span>';
echo '<a href="'.$link.$lpm1.'">'.$lpm1.'</a>';
echo '<a href="'.$link.$lastpage.'">'.$lastpage.'</a>';  
}
elseif($lastpage - (3 * 2) > $page && $page > (3 * 2)) {
echo '<a href="'.$link.'1">1</a>';
echo '<a href="'.$link.'2">2</a>';
echo '<span>...</span>';
for ($counter = $page - 3; $counter <= $page + 3; $counter++) {
if ($counter == $page)
echo '<span>'.$counter.'</span>';
else
echo '<a href="'.$link.$counter.'">'.$counter.'</a>';     
}
echo '<span>...</span>';
echo '<a href="'.$link.$lpm1.'">'.$lpm1.'</a>';
echo '<a href="'.$link.$lastpage.'">'.$lastpage.'</a>';  
} else {
echo '<a href="'.$link.'1">1</a>';
echo '<a href="'.$link.'2">2</a>';
echo '<span>...</span>';
for ($counter = $lastpage - (2 + (3 * 2)); $counter <= $lastpage; $counter++) {
if ($counter == $page)
echo '<span>'.$counter.'</span>';
else
echo '<a href="'.$link.$counter.'">'.$counter.'</a>';     
}
}
}
if (($page < $counter - 1) || ($page < $lastpage))
echo '<a href="'.$link.$next.'">&raquo;</a>';
else
echo '';
}
}

function phpSyntax($content='',$charset='UTF-8') {
$fp = fsockopen('wapinet.ru', 80, $er1, $er2, 10);
if (!$fp) {
return false;
}
$content = rawurlencode(trim($content));
fputs($fp, 'POST /syntax2/index.php HTTP/1.0' . "\r\n" . 'Content-type: application/x-www-form-urlencoded; charset=' . $charset . "\r\n" . 'Content-length: ' .(mb_strlen($content) + 2) . "\r\n" . 'Host: wapinet.ru' . "\r\n" . 'Connection: close' . "\r\n" .  'User-Agent: Gmanager 0.8' . "\r\n\r\n" . 'f=' . $content . "\r\n\r\n");        $r = '';
while ($r != "\r\n") {
$r = fgets($fp);
}
$r = '';
$i = 1;
while (!feof($fp)) {
$r .= fread($fp, 1024);
}
fclose($fp);
$r = trim($r);
$r = str_replace("<span class=\"fail_code\">","<span id=\"fail_code\">",$r);
$r = str_replace(base64_decode("0KDQsNC30LzQtdGA"),"Size",$r);$r = str_replace(base64_decode("0KHQuNC90YLQsNC60YHQuNGH0LXRgdC60LjRhSDQntGI0LjQsdC+0Log0L3QtSDQndCw0LnQtNC10L3Qvg=="),"No syntax error detected in code",$r);
$r = str_replace(base64_decode("0JrQvtC00LjRgNC+0LLQutCw"),"Encoding",$r);

$r = str_replace(base64_decode("0KTQsNC50LvQsA=="),"",$r);
$r = str_replace(base64_decode("0J/RgNC10LLRi9GI0LDQtdGCIDEwMjQga2I="),"Maximum size 1 Mb",$r);
$r = str_replace(base64_decode("0J7RiNC40LHQutCwINCy"),"Error on <a href=\"#fail_code\">line",$r);
$r = str_replace(base64_decode("LdC+0Lkg0YHRgtGA0L7QutC1"),"</a>",$r);
return $r;
}

function localMkDirRecusive($dir) {
if ($dir != "/" || $dir != "") {
if (substr($dir,-1) == "/")
$dir = substr($dir,0,-1);
$exp_dir = explode("/",$dir);
$cou_dir = count($exp_dir);
$val_dir = "";
for ($d = 0; $d <= $cou_dir; $d++) {
if ($exp_dir[$d] != "") {
if (is_dir($val_dir.$exp_dir[$d])) {
$val_dir = $val_dir.$exp_dir[$d]."/";
} else {
mkdir($val_dir.$exp_dir[$d]);
chmod($val_dir.$exp_dir[$d],0777);
$val_dir = $val_dir.$exp_dir[$d]."/";
}
}
}
}
}

function ftpMkDirRecusive($dir) {
global $conn_id;
if ($dir != "/" || $dir != "") {
if (substr($dir,-1) == "/")
$dir = substr($dir,0,-1);
$exp_dir = explode("/",$dir);
$cou_dir = count($exp_dir);
$val_dir = "/";
for ($d = 0; $d <= $cou_dir; $d++) {
if ($exp_dir[$d] != "") {
if (ftp_chdir($conn_id,$val_dir.$exp_dir[$d])) {
$val_dir = $val_dir.$exp_dir[$d]."/";
} else {
ftp_mkdir($conn_id,$val_dir.$exp_dir[$d]);
$val_dir = $val_dir.$exp_dir[$d]."/";
}
}
}
}
}

function localGlob($dir) {
global $glob_local_file;
if (substr($dir,-1) == "/")
$dir = substr($dir,0,-1);
$scan = scandir($dir);
foreach ($scan as $result) {
if ($result != "." AND $result != "..") {
if (is_dir($dir."/".$result)) {
localGlob($dir."/".$result);
} else {
$glob_local_file[] = $dir."/".$result;
}
}
}
return $glob_local_file;
}

function ftpFileList($dir) {
global $conn_id, $ftp_file_list;

if (strpos($dir," ") === false) {
$al = "-al ";
} else {
$al = "";
}
$lines = ftp_rawlist($conn_id,$al.$dir);
foreach ($lines as $line) {
$name = preg_replace("~([^\s]*[\s]*){8}\s{1}(.*)~m","\\2",$line);

if ($name != "." && $name != "..") {
$chm = preg_replace("~([^\s]*).*~m","\\1",$line);
if ($chm[0] == "-") {
$ftp_file_list[] = $dir."/".$name;
} else {
ftpFileList($dir."/".$name);
}}}return $ftp_file_list;
}

function createDir() {
if (!is_dir($GLOBALS['dir_dataftp'])) {
mkdir($GLOBALS['dir_dataftp']);
chmod($GLOBALS['dir_dataftp'],0777);
file_put_contents($GLOBALS['dir_dataftp']."/.htaccess","deny from all
AddDefaultCharset UTF-8");
file_put_contents($GLOBALS['dir_dataftp']."/index.php","OK");
} else {
}
if (!is_dir($GLOBALS['dir_dataftp']."/".$GLOBALS['_ftp']['id'])) {
mkdir($GLOBALS['dir_dataftp']."/".$GLOBALS['_ftp']['id']);
chmod($GLOBALS['dir_dataftp']."/".$GLOBALS['_ftp']['id'],0777);
} else {
}
}

function deleteDir($path) {$directory = $path;
if(is_dir($directory)) {
$directoryHandle = scandir($directory);

foreach ($directoryHandle as $contents) {
if($contents != '.' && $contents != '..') {
$path = $directory . "/" . $contents;

if(is_dir($path)) {
deleteDir($path);
} else {
unlink($path);
}
}
}

reset($directoryHandle);
rmdir($directory);
}
}

function showIcon($img,$alt) {
global $_ftp;
if ($_ftp['icon'] == "yes")
return $img;
else
return $alt;
}

function showDirNav($dir) {
echo '<div align="center"><form method="get" action="index.php"><input type="hidden" name="ftp" value="list" ><input type="text" name="dir" value="'.htmlentities($dir).'" size="19"><input type="submit" value="GO" size="2"></form></div>';

echo '<div class="alt">'.showIcon('<img src="images/back.png" width="16" height="16" alt=""/>','&laquo;').'&nbsp;';
if ($dir == "/" || $dir == "") {
echo '<a href="index.php?ftp=list&amp;dir=%2F">../</a>';
} else {
echo '<a href="index.php?ftp=list&amp;dir=%2F">../</a>';

$dirs = explode("/",$dir);
$linkDir = "";
for ($l = 0; $l < count($dirs); $l++) {
if ($dirs[$l] == "")
continue;
echo '<a href="index.php?ftp=list&amp;dir='.$linkDir.rawurlencode("/".$dirs[$l]).'">'.htmlentities($dirs[$l]).'/</a>';
$linkDir = $linkDir . rawurlencode("/".$dirs[$l]);
}
}
echo '</div>';
}

function ftpDeleteDirectory($conn_id,$dir) {
ftp_chdir($conn_id,$dir);
$arr = ftp_nlist($conn_id,"."); $counts = count($arr);
if ($counts > 700) {
$counts = 700;
}
for ($i = 0; $i < $counts; $i++) {
$file = $dir."/".$arr[$i];
if ((ftp_size($conn_id,$file)==-1) && (preg_replace("~.*/([^/]*)~m","\\1",$file)<>".") && (preg_replace("~.*/([^/]*)~m","\\1",$file)<>"..")) {
ftpDeleteDirectory($conn_id,$file);
} else {
ftp_delete($conn_id,$file);
}
}
ftp_chdir($conn_id,"/");
ftp_delete($conn_id,$dir."/".".htaccess");
if (ftp_rmdir($conn_id,$dir)) {
return true;
} else {
return false;
}
}

function getExtension($str) {
$i = strrpos($str,".");
if (!$i) { return ""; }
$l = strlen($str) - $i;
$ext = substr($str,$i+1,$l);
return strtolower($ext);
}

function ftpSize($var) {
$n1=0;
$n2=0;
$n3=0;
$ar = array(4,2,1);
for ($i = 1; $i <=3; $i++) {
if ($var[$i] <> "-") {
$n1 = $n1 + $ar[$i-1];
}
}
for ($i = 4; $i <=6; $i++) {
if ($var[$i] <> "-") {
$n2 = $n2 + $ar[$i-4];
}
}
for ($i = 7; $i <=9; $i++) {
if ($var[$i] <> "-") {
$n3 = $n3 + $ar[$i-7];
}
}
return $n1.$n2.$n3;
}

function ftpList($res,$dr) {
global $_ftp;
if (strpos($dr," ") === false) {
$al = "-al ";
} else {
$al = "";
}
$lines = ftp_rawlist($res,$al.$dr);
$fnm = NULL;
$dnm = NULL;
for ($i = 0; $i < count($lines); $i++) {
$name = preg_replace("~([^\s]*[\s]*){8}\s{1}(.*)~m","\\2",$lines[$i]);
$size = preg_replace("~([^\s]*[\s]*){4}\s{1}([^\s]*)(.*)~m","\\2",$lines[$i]);
if (($name <> ".") && ($name <> "..")) {
$rname = $name;

$chm = preg_replace("~([^\s]*).*~m","\\1",$lines[$i]);
$nchm = ftpSize($chm);
if ($chm[0] == "-") {
if ($_ftp['size'] == "yes") {
if ($size < 1000) {
$sz = "[".$size." bytes]";
}
elseif ($size < 10240) {
$sz = "[".str_replace(".", ",", round($size / 1024, 1))." kb]";
}
elseif ($size < 1024000) {
$sz = "[".round($size / 1024)." kb]";
} else {
$sz = "[".str_replace(".", ",", round($size / 1024 / 1024, 1))." mb]";
}
} else {
$sz = "";
}
if ($_ftp['icon'] == "yes") {
$ext = getExtension(str_replace(".htaccess","dot.htaccess",str_replace("error_log","dot.error_log",$name)));

$arr_ext = array(
"3gp" => "3gp.png",
"avi" => "avi.png",
"bmp" => "bmp.png",
"doc" => "doc.png",
"error_log" => "error_log.png",
"exe" => "exe.png",
"gif" => "gif.png",
"htm" => "htm.png",
"html" => "htm.png",
"jpg" => "jpg.png",
"jpe" => "jpg.png",
"jpeg" => "jpg.png",
"mdb" => "mdb.png",
"mid" => "mid.png",
"midi" => "mid.png",
"mp3" => "mp3.png",
"php" => "php.png",
"png" => "png.png",
"ppt" => "ppt.png",
"psd" => "psd.png",
"rar" => "rar.png",
"rtf" => "rtf.png",
"ttf" => "ttf.png",
"wav" => "wav.png",
"wml" => "wml.png",
"xls" => "xls.png",
"xml" => "xml.png",
"wmv" => "wmv.png",
"txt" => "txt.png",
"zip" => "zip.png",
"tar" => "rar.png",
"tgz" => "rar.png",
"tbz" => "rar.png",
"bz2" => "rar.png",
"tgz2" => "rar.png",
"tbz2" => "rar.png",
"fla" => "fla.png",
"swf" => "swf.png",
"htaccess" => "htaccess.png",
"css" => "css.png",
"py" => "py.png",
"log" => "log.png",
"ini" => "css.png",
"jar" => "jar.png",
"jad" => "jad.png",
"sql" => "sql.png",
"dat" => "dat.png",
"vim" => "vim.png",
"ico" => "ico.png",
"thm" => "thm.png",
"sys" => "sys.png",
"sysx" => "sysx.png",
"url" => "url.png",
"flv" => "flv.png",
"tar" => "tar.png",
"gz" => "tar.png",
"xhtml" => "xhtml.png",
"db" => "db.png"
);
if (in_array($ext,array_keys($arr_ext))) {
$icon = '<img src="images/'.$arr_ext[$ext].'" width="16" height="16" alt=""/>';
} else {
$icon = '<img src="images/unkn.png" width="16" height="16" alt=""/>';
}
} else {
$icon = "&raquo;";
}
if ($dr == "/")
$dr = "";
$fnm[] = '<div id="files">'.$icon.'<input type="checkbox" name="file[]" value="'.htmlspecialchars($rname).'"/> <a href="index.php?ftp=file&amp;file='.rawurlencode($dr."/".$name).'">'.htmlspecialchars($rname).'</a>&nbsp;[<span><a href="index.php?ftp=chmod&amp;file='.rawurlencode($dr.'/'.$name).'&amp;value='.$nchm.'">'.$nchm.'</a></span>]&nbsp;'.$sz.'</div>';
} else {
if ($_ftp['icon'] == "yes")
$icon = '<img src="images/cldir.png" width="16" height="16" alt=""/>';
else
$icon = "&raquo;";

if ($dr == "/")
$dr = "";
$dnm[] = '<div id="directories">'.$icon.'<input type="checkbox" name="dir[]" value="'.htmlspecialchars($rname).'"/> <a href="index.php?ftp=list&amp;dir='.rawurlencode($dr.'/'.$name).'">'.htmlspecialchars($rname).'</a>&nbsp;[<span><a href="index.php?ftp=chmod&amp;dir='.rawurlencode($dr.'/'.$name).'&amp;value='.$nchm.'">'.$nchm.'</a></span>]&nbsp;'.$sz.'</div>';
}
}
}if ($fnm == NULL) {
return $dnm;
}
elseif ($dnm == NULL) {
return $fnm;
} else {
return array_merge($dnm,$fnm);
}
}
?>