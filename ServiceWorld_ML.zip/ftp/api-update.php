<?php
define('PAGEDISPLAY', true);
if (!file_exists("includes/config.php")) {
echo "Please install before..!!";
exit;
}
ignore_user_abort(true);
error_reporting(0);
mb_internal_encoding('UTF-8');
ini_set('default_charset','UTF-8');
date_default_timezone_set('UTC');
ini_set('session.cookie_domain', $_SERVER['HTTP_HOST']);
/*
set_time_limit(0);
*/
ob_start();
session_start();
$ftp = isset($_GET['ftp']) ? trim($_GET['ftp']) : '';
$ftp = strtolower(preg_replace('#([\W_]+)#','_',$ftp));
include("language.php");
require("includes/config.php");
require("includes/connect.php");
require("includes/functions.php");
defined('PAGEDISPLAY') or die('Access Forbidden..!!');
$rootid = isset($_GET['rootid']) ? stripslashes($_GET['rootid']) : '';
$rootkey = isset($_GET['rootkey']) ? stripslashes($_GET['rootkey']) : '';
$sql_connect = mysql_connect($db_host,$db_user,$db_pass);
if (!$sql_connect) {
die("Connecting Error..!!");
exit;
}
mysql_select_db($db_name) or die('Database Error!');
$req = mysql_query("SELECT * FROM `".$db_prefix."ftp` WHERE `id` = '".mysql_real_escape_string($rootid)."' AND `cookie` = '".mysql_real_escape_string($rootkey)."'");
$client_id = mysql_num_rows($req);
if ($client_id != 0) {
$size = $_POST['size'];
$view = $_POST['view'];
$icon = $_POST['icon'];
$help = $_POST['help'];
mysql_query("UPDATE `".$db_prefix."ftp` SET `size` = '".mysql_real_escape_string($size)."', `icon` = '".mysql_real_escape_string($icon)."', `view` = '".mysql_real_escape_string($view)."', `help` = '".mysql_real_escape_string($help)."' WHERE `id` = '".mysql_real_escape_string($rootid)."' AND `cookie` = '".mysql_real_escape_string($rootkey)."'");
?>
$notice = '<div class="success">'.$_lng['settingssuccessfullysaved'].'</div>';
<?
}
mysql_close($sql_connect);
?>