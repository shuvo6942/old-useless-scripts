<?php
header('Content-type: text/css');
ob_start("compress");
function compress($buffer) {
/* deleted comment */
$buffer = preg_replace('!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $buffer);
/* erase tabs, spaces, newlines, dll. */
$buffer = str_replace(array("\r\n", "\r", "\n", "\t", '  ', '  ', '  '), '', $buffer);
return $buffer;
}
/* include css want to compress */
require('ftp_style.css');
ob_end_flush();
?>