<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Word Case Changer</title><link rel="STYLESHEET" type="text/css" href="http://wtools.gq/styles.css"/><link rel="shortcut icon" href="http://phptunes.com/favicon.ico"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/><style type="text/css">
body { background: ;
color: ;
}
a { color: ;
}
</style>
</head><body>






<script type="text/javascript">
function zig(x)
{
b='';
for (a=0;a<x.length;a++)
{
if (a%2==0)
b=b+x.charAt(a).toLowerCase();
else
b=b+x.charAt(a).toUpperCase();
}
return b;
}
function rand(x)
{
b='';
for (a=0;a<x.length;a++)
{
if (Math.floor(Math.random()*2)==0)
b=b+x.charAt(a).toLowerCase();
else
b=b+x.charAt(a).toUpperCase();
}
return b;
}
</script><div>
<textarea id="t"></textarea><br/><br/><button onclick="document.getElementById('t').value=document.getElementById('t').value.toLowerCase();">small</button><button onclick="document.getElementById('t').value=document.getElementById('t').value.toUpperCase();">CAPITAL</button><button onclick="document.getElementById('t').value=zig(document.getElementById('t').value);">ZiGzAg</button><button onclick="document.getElementById('t').value=rand(document.getElementById('t').value);">RanDom</button></div></body></html>