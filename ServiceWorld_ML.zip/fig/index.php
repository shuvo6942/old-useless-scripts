<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Facebook Emoticon Generator</title><link rel="STYLESHEET" type="text/css" href="http://wtools.gq/styles.css"/><link rel="STYLESHEET" type="text/css" href="http://phptunes.com/favicon.ico"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/><style type="text/css">
body { background: ;
color: ;
}
a { color: ;
}
</style>
</head><body>






<div><div><div class="next"><div class="nfooter"><font size="2px" color="white"><b> Facebook Emotion Creator</b></font></div><div style="background-color:#D2D2D2; padding-top:5px; padding-bottom:5px; margin-bottom:2px;" align="center">
<script language="javascript" type="text/javascript">
function  generate()
{
var charCode =new Array();
charCode["a"]="[[f9.cha]]";
charCode["b"]="[[f9.chb]]";
charCode["c"]="[[f9.chc]]";
charCode["d"]="[[f9.chd]]";
charCode["e"]="[[f9.che]]";
charCode["f"]="[[f9.chf]]";
charCode["g"]="[[f9.chg]]";
charCode["h"]="[[f9.chh]]";
charCode["i"]="[[f9.chi]]";
charCode["j"]="[[f9.chj]]";charCode["k"]="[[f9.chk]]";
charCode["l"]="[[f9.chl]]";
charCode["m"]="[[f9.chm]]";
charCode["n"]="[[f9.chn]]";
charCode["o"]="[[f9.cho]]";
charCode["p"]="[[f9.chp]]";
charCode["q"]="[[f9.chq]]";
charCode["r"]="[[f9.chr]]";
charCode["s"]="[[f9.chs]]";
charCode["t"]="[[f9.cht]]";
charCode["u"]="[[f9.chu]]";
charCode["v"]="[[f9.chv]]";
charCode["w"]="[[f9.chw]]";


charCode["x"]="[[f9.chx]]";
charCode["y"]="[[f9.chy]]";charCode["z"]="[[f9.chz]]";
//charCode[""]="[[440403702699053]]";
charCode["-"]="[[f9.dash]]";
charCode["0"]="[[f9.num0]]";
charCode["1"]="[[f9.num1]]";
charCode["2"]="[[f9.num2]]";
charCode["3"]="[[f9.num3]]";
charCode["4"]="[[f9.num4]]";
charCode["5"]="[[f9.num5]]";
charCode["6"]="[[f9.num6]]";
charCode["7"]="[[f9.num7]]";
charCode["8"]="[[f9.num8]]";
charCode["9"]="[[f9.num9]]";
//charCode["!"]="[[355825317764954]]";







charCode["!"]="[[f9.xclam]]";var htmCode =new Array();
htmCode["a"]="<img src='emo/letter2/a.png'>";
htmCode["b"]="<img src='emo/letter2/b.png'>";
htmCode["c"]="<img src='emo/letter2/c.png'>";
htmCode["d"]="<img src='emo/letter2/d.png'>";
htmCode["e"]="<img src='emo/letter2/e.png'>";
htmCode["f"]="<img src='emo/letter2/f.png'>";
htmCode["g"]="<img src='emo/letter2/g.png'>";
htmCode["h"]="<img src='emo/letter2/h.png'>";
htmCode["i"]="<img src='emo/letter2/i.png'>";
htmCode["j"]="<img src='emo/letter2/j.png'>";
htmCode["k"]="<img src='emo/letter2/k.png'>";
htmCode["l"]="<img src='emo/letter2/l.png'>";
htmCode["m"]="<img src='emo/letter2/m.png'>";
htmCode["n"]="<img src='emo/letter2/n.png'>";htmCode["o"]="<img src='emo/letter2/o.png'>";










htmCode["p"]="<img src='emo/letter2/p.png'>";
htmCode["q"]="<img src='emo/letter2/q.png'>";






htmCode["r"]="<img src='emo/letter2/r.png'>";
htmCode["s"]="<img src='emo/letter2/s.png'>";
htmCode["t"]="<img src='emo/letter2/t.png'>";
htmCode["u"]="<img src='emo/letter2/u.png'>";
htmCode["v"]="<img src='emo/letter2/v.png'>";
htmCode["w"]="<img src='emo/letter2/w.png'>";
htmCode["x"]="<img src='emo/letter2/x.png'>";
htmCode["y"]="<img src='emo/letter2/y.png'>";
htmCode["z"]="<img src='emo/letter2/z.png'>";
//htmCode["blank"]="<img src='emo/letter2/blank.png'>";
htmCode["-"]="<img src='emo/letter2/dash.png'>";
htmCode["!"]="<img src='emo/letter2/punc.png'>";htmCode["0"]="<img src='emo/letter2/0.png'>";
htmCode["1"]="<img src='emo/letter2/1.png'>";










htmCode["2"]="<img src='emo/letter2/2.png'>";
htmCode["3"]="<img src='emo/letter2/3.png'>";
htmCode["4"]="<img src='emo/letter2/4.png'>";
htmCode["5"]="<img src='emo/letter2/5.png'>";
htmCode["6"]="<img src='emo/letter2/6.png'>";
htmCode["7"]="<img src='emo/letter2/7.png'>";
htmCode["8"]="<img src='emo/letter2/8.png'>";
htmCode["9"]="<img src='emo/letter2/9.png'>";
var inp = document.getElementById('inp').value.toLowerCase();
var last = inp.length - 1;
var tmpStr="";
var tmpHtml="";
//alert(inp);
for (var i = 0; i <= last; i++) {
if( inp.charAt(i) == "\n")
{
tmpStr += "\n";
tmpHtml += "<br>";
}
else if( inp.charAt(i) == " ")
{
tmpStr += " [[f9.space]] ";
tmpHtml += "<img src='emo/letter2/blank.png'>&nbsp;";
}
else if(tmpStr=="")
{
tmpStr = charCode[inp.charAt(i)];
tmpHtml = tmpHtml + " " + htmCode[inp.charAt(i)];
}
else
{
tmpStr = tmpStr + " " + charCode[inp.charAt(i)];
tmpHtml = tmpHtml + " " + htmCode[inp.charAt(i)];
}
}
document.getElementById('out').value = tmpStr;
document.getElementById('display').innerHTML = "<p id='display'><b>Preview: </b>"+tmpHtml+"</p>";
}
</script>
<form name="f">
<center><font size="2px" color="yellow"><b>Your Text</b></font></center>
<textarea cols="10" rows="2" name="inp" id="inp" ></textarea><br/>
<input type="button" name="convert" value="Get FB Code" onClick="generate()"></input>
<br/>
<div class="sakil" align="center"><b>Copy Here</b></div>
<textarea cols="10" rows="2" name="out" id="out" onFocus="this.select();"></textarea></form></div></div></div>
<div><script type="text/javascript"> if(window.location.href.match(/(get-ok=ok)/ig)){document.write('<meta http-equiv="refresh" content="0;url=forum2_add_.xhtml?tema=&amp;q="/>');}</script></div>
</div>
</body></html>