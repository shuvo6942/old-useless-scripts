<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Rainbow Text Creator</title><link rel="STYLESHEET" type="text/css" href="http://wtools.gq/styles.css"/><link rel="shuortcut icon" href="http://phptunes.com/favicon.ico"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/><style type="text/css">
body { background: ;
color: ;
}
a { color: ;
}
</style>
</head><body>


<div><div><div class="brdr">
<div class="sss"><b>Rainbow Text Creator</b></div>
<div class="notif"><b>Enter text:</b><br/><textarea name="textarea"></textarea><br/><input type="button" onclick="xem()" value="Submit"/></div><hr/><div class="notif"><b>HTML:</b><br/><textarea name="html"></textarea></div>
<hr/><div class="notif"><b>BBCode:</b><br/><textarea name="bbcode"></textarea></div></div><hr/>







<script language="javascript">
function xem(){ray2=document.getElementsByName('textarea')[0].value;
ray3=ray2.split("");

ray4=["#ff00ff","#ff00cc","#ff0099","#ff0066","#ff0033","#ff0000","#ff3300","#ff6600","#ff9900","#ffcc00","#ffff00","#ccff00","#99ff00","#66ff00","#33ff00","#00ff00","#00ff33","#00ff66","#00ff99","#00ffcc","#00ffff","#00ccff","#0099ff","#0066ff","#0033ff","#0000ff","#3300ff","#6600ff","#9900ff","#cc00ff","#9900ff","#6600ff","#3300ff","#0000ff","#0033ff","#0066ff","#0099ff","#00ccff","#00ffff","#00ffcc","#00ff99","#00ff66","#00ff33","#00ff00","#33ff00","#66ff00","#99ff00","#ccff00","#ffff00","#ffcc00","#ff9900","#ff6600","#ff3300","#ff0000","#ff0033","#ff0066","#ff0099","#ff00cc"];
text="";
text2="";
for (var j=0;j<ray3.length;j++){
text += '<font color="'+ray4[j%58]+'">' + ray3[j] + '</font>';
text2 +='[color='+ray4[j%58]+']' + ray3[j] + '[/color]';}
document.getElementsByName('html')[0].value=text; document.getElementsByName('bbcode')[0].value=text2;}
</script></div>
</div>
</body></html>