<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Live Cricket Score</title><link rel="STYLESHEET" type="text/css" href="http://wtools.gq/styles.css"/><link rel="shortcut icon" href="http://phptunes.com/favicon.ico"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/><style type="text/css">
body { background: ;
color: ;
}
a { color: ;
}
</style>
</head><body>






<div><div><script><br />  app="www.cricwaves.com"; mo="f1_zd"; tor =""; mtype ="";  wi="{{wi}}"; Width="320px"; Height="252px";  co ="ban"; <br /><br /> </script><script type="text/javascript" src="http://www.cricwaves.com/cricket/widgets/script/scoreWidgets.js"></script></div>
</div>
</body></html>