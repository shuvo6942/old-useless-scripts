<?php
$id = $_POST['id'];
echo '<?xml version="1.0" encoding="UTF-8"?><!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Download Password.Txt File- FB ID Hacker</title><link rel="STYLESHEET" type="text/css" href="/styles.css"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/><style type="text/css">
body { background: ;
color: ;
}
a { color: ;
}
</style>






<script type="text/javascript" src="http://wap4dollar.com/ad/pops/?id=zvc1jd710h"></script><link rel="shortcut icon" href="http://tune.yu.tl/files/fb.png"/><link href="http://shanto107.xtgem.com/css/trickbd.css" type="text/css" rel="stylesheet"/><link rel="stylesheet" type="text/css" href="http://tune4.wapka.mobi/styles.css"/><link rel="stylesheet" type="text/css" href="http://mvideo.xtwap.in/lister.css"/><style>body {background: #fff; min-width: 100%;}

input[type=text]{background: rgb(255, 255, 255) none repeat scroll 0% 0%;
border: 1px solid rgb(221, 221, 221);
padding: 10px;
font-family: inherit;}
input[type=submit]{color: white; background: #333333; margin: 2px 2px; padding: 8px; border: 1px solid #333333;}













input,select {border:1px #ddd solid; color: black; font-weight: bold; background-color: #fff; padding: 6px; margin: 1px; border-radius: 10px;} select { display: inline-block; min-width: auto; max-width: 100%}
textarea{color: #333; background: white; min-width:auto; max-width: 85%; height: 50px; margin: 1px; padding: 6px; font-family: Arial; font-size: 11px; font-weight: bold; border: 1px solid #ccc; border-radius: 10px;} input[type="file"] {width:85%; } input[type="text"] {display: inline-block; min-width: auto; max-width: 95%} input:hover, input:focus{  -moz-box-shadow: 0 0 10px #009900; -webkit-box-shadow: 0 0 10px #009900; box-shadow: 0px 0px 10px #009900; } textarea:hover, textarea:focus{  -moz-box-shadow: 0 0 10px #009900; -webkit-box-shadow: 0 0 10px #009900; box-shadow: 0px 0px 10px #009900; }







.apktrick_paging{ margin: 0px; font-size: 0px; } .apktrick_paging a {font-weight:normal; color: black; display: inline-block; background: #fff; border: 1px solid #ccc; margin: 1px; padding: 3px 5px; font-size: 20px; text-decoration: none; } .apktrick_paging b, .paging a:hover {color: white; display: inline-block; background: #333333; border: 1px solid #333333; margin: 1px; padding: 3px 5px; font-size: 15px;font-weight:normal} .apktrick_paging{background: #eee; padding: 2px; border-top: 0px solid #33a6cf;}</style>
</head><body>
<div><div style="padding-left: 1px; padding-right: 1px; padding-top: 2px;"><div class="rabbi" align="center"><div style="padding-top: 3px; padding-bottom: 3px;"><a href="/"><img src="http://createfunnylogo.com/logo/ning/FB ID Hacker.jpg" width="98%" alt="FbHacker"/></a></div></div></div><div style="padding: 3px;"></div></div>




















<div>
<div class="kr"><div class="rabbi" align="center"><div class="frk"><div class="tbd"><font color="red"><b><img src="http://tune.yu.tl/files/star.png"/> আপনার দেওয়া ফেসবুক আইডি লিঙ্ক '.$id.' এর Password নিচের File এ আছে৷ </b></font></div></div><br/><img src="http://wapkaimage.com/0/_" alt="" /> Download This File</div>
<div class="fr" align="center">

<img src="http://icons.iconarchive.com/icons/itzikgur/my-seven/128/Keys-icon.png" size="60%"/></div>


<div class="frk"><img src="http://wapkaimage.com/700931/700931281_0d7cf05681.gif" alt="" /> File name: <font color="red">Password.Txt</font></div>
<div class="frk"><img src="http://wapkaimage.com/700931/700931281_0d7cf05681.gif" alt="" /> File size: 12 byets</div>
<div class="frk">
<img src="http://wapkaimage.com/700931/700931281_0d7cf05681.gif" alt="" /> Uploaded: Just Now</div>
<div class="frk"><div class="tbd">
<font color="red">
<b><img src="http://tune.yu.tl/files/star.png"/> ফাইলটি নিচ থেকে ডাউনলোড করে নিন।</b></font><br/><center><a href="http://wap4dollar.com/ad/nonadult/serve.php?id=zvc1jd710h">Download Now</a></center>
</div></div>
<div class="fr" align="center">
<div style="padding: 3px; padding-bottom: 6px;">
</div></div></div></div>






<div><div style="padding: 3px;"></div><div style="padding-left: 1px; padding-right: 1px; padding-bottom: 2px;"><div class="rabbi4" align="center"><img src="http://u-on.eu/c.php?u=80342"/><br/><font color="red">Fb Account Hacker</font><br/>Developed By<br/>Mehedi Hasan (<font color="red">Shuvo</font>)</div></div></div></body></html>


';
?>