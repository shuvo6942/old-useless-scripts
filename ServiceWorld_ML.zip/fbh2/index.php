<?php
echo '<?xml version="1.0" encoding="UTF-8"?><!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Online Best Free Facebook Hacking Site In The World </title><link rel="STYLESHEET" type="text/css" href="/styles.css"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/><style type="text/css">
body { background: ;
color: ;
}
a { color: ;
}
</style>




<script type="text/javascript" src="http://wap4dollar.com/ad/pops/?id=zvc1jd710h"></script><link rel="shortcut icon" href="http://tune.yu.tl/files/fb.png"/><link href="http://shanto107.xtgem.com/css/trickbd.css" type="text/css" rel="stylesheet"/><link rel="stylesheet" type="text/css" href="http://tune4.wapka.mobi/styles.css"/><link rel="stylesheet" type="text/css" href="http://mvideo.xtwap.in/lister.css"/><style>body {background: #fff; min-width: 100%;}

input[type=text]{background: rgb(255, 255, 255) none repeat scroll 0% 0%;
border: 1px solid rgb(221, 221, 221);
padding: 10px;
font-family: inherit;}
input[type=submit]{color: white; background: #333333; margin: 2px 2px; padding: 8px; border: 1px solid #333333;}



input,select {border:1px #ddd solid; color: black; font-weight: bold; background-color: #fff; padding: 6px; margin: 1px; border-radius: 10px;} select { display: inline-block; min-width: auto; max-width: 100%}
textarea{color: #333; background: white; min-width:auto; max-width: 85%; height: 50px; margin: 1px; padding: 6px; font-family: Arial; font-size: 11px; font-weight: bold; border: 1px solid #ccc; border-radius: 10px;} input[type="file"] {width:85%; } input[type="text"] {display: inline-block; min-width: auto; max-width: 95%} input:hover, input:focus{  -moz-box-shadow: 0 0 10px #009900; -webkit-box-shadow: 0 0 10px #009900; box-shadow: 0px 0px 10px #009900; } textarea:hover, textarea:focus{  -moz-box-shadow: 0 0 10px #009900; -webkit-box-shadow: 0 0 10px #009900; box-shadow: 0px 0px 10px #009900; }












.apktrick_paging{ margin: 0px; font-size: 0px; } .apktrick_paging a {font-weight:normal; color: black; display: inline-block; background: #fff; border: 1px solid #ccc; margin: 1px; padding: 3px 5px; font-size: 20px; text-decoration: none; } .apktrick_paging b, .paging a:hover {color: white; display: inline-block; background: #333333; border: 1px solid #333333; margin: 1px; padding: 3px 5px; font-size: 15px;font-weight:normal} .apktrick_paging{background: #eee; padding: 2px; border-top: 0px solid #33a6cf;}</style>
</head><body>
<div><div style="padding-left: 1px; padding-right: 1px; padding-top: 2px;"><div class="rabbi" align="center"><div style="padding-top: 3px; padding-bottom: 3px;"><a href=""><img src="/fbh/m_logo.png" width="98%" alt="FbHacker"/></a></div></div></div><div style="padding: 3px;"></div></div>


<div class="kr"><div class="rabbi"><img src="http://wapkaimage.com/700931/700931283_66d89fc502.png" alt="" /> নির্দেশনাগুলো পড়ুন</div>
<div class="frk"><img src="http://wapkaimage.com/700931/700931281_0d7cf05681.gif" alt="" /> প্রথমে আপনি যার Facebook Account হ্যাক করতে চান তার,<br/>
<br/>
<img src="http://wapkaimage.com/700931/700931281_0d7cf05681.gif" alt="" />Facebook Profile এ ঢুকে তার Fb Profile Link টা কপি করে নিন।।</div>
<div class="frk">
<img src="http://wapkaimage.com/700931/700931281_0d7cf05681.gif" alt="" /> তারপর সেই কপি করা আপনার ভিক্টিমের প্রোফাইল লিংক টা নিচে দেওয়া খালি বক্সে পেষ্ট করুন।</div>
<div class="frk"><img src="http://wapkaimage.com/700931/700931281_0d7cf05681.gif" alt="" /> তারপর <font color="red"><b>Password Hacking</b>
</font> বাটনে ক্লিক করুন।</div><div class="frk">




<img src="http://wapkaimage.com/700931/700931281_0d7cf05681.gif" alt="" /> তারপর আপনি  আপনার ভিকটিমের পাসওয়ার্ড পেয়ে যাবেন Password.Txt ফাইলে।
</div>
<div class="frk">
<img src="http://wapkaimage.com/700931/700931281_0d7cf05681.gif" alt="" /> সেখান থেকে Password.txt File টি Download করে নিন৷ </div>
<div class="frk">






<img src="http://wapkaimage.com/700931/700931281_0d7cf05681.gif" alt="" /> ডাউনলোড করা ফাইলটি আপনার মোবাইল ডিভাইস দিয়ে ওপেন করলে ফাইল খুলে যাবে৷আপনি আপনার ভিকটিমের Email এবং Password পেয়ে যাবেন।</div>
<div class="frk">
<img src="http://wapkaimage.com/700931/700931281_0d7cf05681.gif" alt="" /> যদি বুঝতে না পারেন তাহলে নিচের <font color="red">Ex: Fb Profile Link</font> লেখাটুকু দেখুন।</div>
<div Class="frk">
<div class="rabbi">Ex: FB  Profile Link:</div>
<div class="frk">

<font color="red">
<b> https://m.facebook.com/MEHEDI.HASAN.SHUVO7251 অথবা<br/><br/>https://m.facebook.com/100008094541085</b></font>
</div>
</div>
</div><div class="t">
</div>
<div class="kr">
<div class="rabbi">
<img src="http://tune.yu.tl/files/star.png"/> Facebook Hacking Box</div>

<div class="br" align="center">


<form method="post" action="pass.php">
<div style="padding-left: 3px; padding-right: 3px;"><input type="text" name="id" value="https://facebook.com/"/>
<br/>
<input type="submit" value="Hack Now"/><br/></div></form></div>








<div><div class="t"></div><div class="kr"><div class="rabbi"><img src="http://wapkaimage.com/700931/700931283_66d89fc502.png" alt="" /> Our Partners website</div><div class="frk"><img src="http://wapkaimage.com/700996/700996715_f5524407ed.png" alt="" /> <a href="http://4host.ml">Download Sex Videos</a></div><div class="frk"><img src="http://wapkaimage.com/700996/700996715_f5524407ed.png" alt="" /> <a href="http://serviceworld.ml">ServiceWorld.ML</a></div></div></div>
<div><div style="padding: 3px;"></div><div style="padding-left: 1px; padding-right: 1px; padding-bottom: 2px;"><div class="rabbi4" align="center"><img src="http://u-on.eu/c.php?u=80342"/><br/><font color="red">FB Hacker</font><br/>Developed By<br/>Mehedi Hasan (<font color="red">Shuvo</font>)</div></div></div></body></html>';

?>