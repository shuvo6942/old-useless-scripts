<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Mp3 Tag Editor</title><link rel="STYLESHEET" type="text/css" href="http://itpagla.com/styles.css"/><link rel="shortcut icon" href="http://phptunes.com/favicon.ico"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/><style type="text/css">
body { background: ;
color: ;
}
a { color: ;
}
</style>
</head><body>




<div><div><div style="background-color:#eeeff8" class="brdr"><div class="zone" align="center"><b>Mp3 Tag Editor</b></div><div style="color: #ff0000; " class="Mainoption"><form method="post" action="http://friendslite.com/mp3editor/">MP3 URL<br/><input size="20" type="text" name="mp3_filepath" /><br/>Song name(with .mp3)<br/><input type="text" name="mp3_filename" value="[itpagla.tk].mp3" /><br/>Title<br/><input type="text" name="mp3_songname" value="[itpagla.tk]" /><br/>Comments :<br/><input type="text" name="mp3_comment" value="itpagla.tk" /><br/>Artist(s) <br/><input type="text" name="mp3_artist" value="[itpagla.tk]" /><br/>Album<br/><input type="text" name="mp3_album" value="[itpagla.tk]" /><br/>Year:<br/> <input type="text" name="mp3_year" value="2014" /><br/> Genre:<br/><input type="text" name="mp3_genre" value="itpagla.tk" /> Mp3 Image: <br/> <input type="file" name="mp3_image" /><input type="submit" name="submit" value="Edit Tag" /></form></div></div></div>
</div>
</body></html>