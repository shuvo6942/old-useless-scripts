<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Text To MP3 Converter</title><link rel="STYLESHEET" type="text/css" href="http://wtools.gq/styles.css"/><link rel="shortcut icon" href="http://phptunes.com/favicon.ico"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/><style type="text/css">
body { background: ;
color: ;
}
a { color: ;
}
</style>
</head><body>



<div><div style="display: yes"><div class="signup"><b>Text to Mp3 Maker</b></div><div class="u" align="center">
<form action="http://vozme.com/text2voice.php?lang=en" target="mymp3">
<textarea name="text" rows="5" cols="10" id="box_textarea">ServiceWorld.ML</textarea>
<input type="submit" id="submission" name="submit" value="Create Mp3"/></form>
</div></div>
<div><div class="rakibul"><b>Text To Wav Maker</b></div>
<div class="uu">
<form action="http://www.talkingonline.com/cgi-bin/remspeakit.wav" method="get"><b>Text:</b><br/>
<input name="q1" class="textfield" value="" type="text"/><br/><b>Voice:</b><br/>
<select name="gender" class="textfield">
<option value="0">Male 1</option>
<option value="1">Male 2</option>
<option value="2">Male 3</option>
<option value="3">Female 1</option>
<option value="3">Female 2</option></select><br/><b>Volume:</b><br/>
<select name="volume" class="textfield">
<option value="1">Quiet</option>
<option value="0">Normal</option>
<option value="2">Loud</option>
</select><br/><b></b>Speed:<br/>
<select name="speed" class="textfield">
<option value="1">Slow</option>
<option value="0">Normal</option>
<option value="2">Fast</option></select><br/>
<input type="submit" value="Make Wav" class="button"/>
</form></div></div></div>
</body></html>