<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Online Bangla Writter v2</title><link rel="STYLESHEET" type="text/css" href="http://wtools.gq/styles.css"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/><link rel="shortcut icon" href="http://phptunes.com/favicon.ico"/>
</head><body>






<div><p><div><style>textarea{width:80%;}</style></div>
<div align="center"><div class="nfooter">Write Bangla</div><table border="0" cellpadding="0" cellspacing="0" width="100%"><tbody><tr><td><table border="0" cellpadding="3" cellspacing="4" width="100%"><tbody><tr><td></td></tr></tbody></table></td></tr></tbody></table>
<div class="table2"><form name="Calc"><table border="1" width="100%">
<tr>
<td width="100%">
<div class="rmenu" align="center">
<textarea size="24" rows='3' name="Input"></textarea></div></td></tr></table><div class="rmenu"><table border='1' width="100%"><tr>
<th width="25%" height="60"><input type="button" name="1" value="…" OnClick="Calc.Input.value +=' '"/></th><th width="25%" height="60"><input type="button" name="2" value="+" OnCLick="Calc.Input.value+='্'"/></th><th width="25%" height="60"><input type="button" name="3" value="।" OnClick="Calc.Input.value+='।'"/></th><th width="25%" height="60"><input type="button" name="4" value="া" OnClick="Calc.Input.value+= 'া'"/></th></tr><tr><th height="60">














<input type="button" name="5" value="ি" OnClick="Calc.Input.value+='ি'"/>
</th>
<th>
<input type="button" name="6" value="ী" OnCLick="Calc.Input.value+='ী'"/>
</th>
<th>
<input type="button" name="7" value="উ কার" OnClick="Calc.Input.value+='ু'"/>
</th>
<th>
<input type="button" name="8" value="ঊ কার" OnClick="Calc.Input.value+='ূ'"/>

</th>
</tr>
<tr>
<th height="60">
<input type="button" name="9" value="ঋ কার" OnClick="Calc.Input.value +='ৃ'"/>
</th>
<th>
<input type="button" name="10" value="ে" OnCLick="Calc.Input.value +='ে'"/>
</th>
<th>
<input type="button" name="12" value="ও কার" OnClick="Calc.Input.value +='ো'"/>
</th>
<th height="60">
<input type="button" name="13" value="ৌ" OnClick="Calc.Input.value +='ৌ'"/>
</th>
</tr>
<tr>
<th height="60">
<input type="button" name="13" value="হসন্ত" OnClick="Calc.Input.value +='্'"/>
</th>








<th>
<input type="button" name="14" value="চন্দ্র বিন্দু" OnClick="Calc.Input.value +='ঁ'"/>
</th>
<th>
<input type="button" name="15" value="ঃ" OnClick="Calc.Input.value +='ঃ'"/>
</th>
<th>
<input type="button" name="16" value="ং" OnClick="Calc.Input.value +='ং'"/>
</th>
</tr>
<tr>
<th height="60">
<input type="button" name="17" value="অ" OnClick="Calc.Input.value +='অ'"/>
</th>
<th>
<input type="button" name="18" value="আ" OnClick="Calc.Input.value +='আ'"/>
</th>
<th>
<input type="button" name="19" value="ই" OnClick="Calc.Input.value +='ই'"/>
</th>
<th>
<input type="button" name="20" value="ঈ" OnClick="Calc.Input.value +='ঈ'"/>
</th>
</tr>
<tr>
<th height="60">
<input type="button" name="21" value="উ" OnClick="Calc.Input.value +='উ'"/>
</th>
<th>
<input type="button" name="22" value="ঊ" OnCLick="Calc.Input.value +='ঊ'"/>












</th>
<th>
<input type="button" name="23" value="ঋ" OnClick="Calc.Input.value +='ঋ'"/>
</th>
<th>
<input type="button" name="24" value="এ" OnClick="Calc.Input.value += 'এ'"/>
</th>
</tr>
<tr>
<th height="60">
<input type="button" name="25" value="ঐ" OnClick="Calc.Input.value +='ঐ'"/>
</th>
<th>
<input type="button" name="26" value="ও" OnCLick="Calc.Input.value +='ও'"/>
</th>
<th>
<input type="button" name="27" value="ঔ" OnClick="Calc.Input.value +='ঔ'"/>
</th>
<th>
<input type="button" name="28" value="ক" OnClick="Calc.Input.value +='ক'"/>
</th>
</tr>
<tr>
<th height="60">
<input type="button" name="29" value="খ" OnClick="Calc.Input.value +='খ'"/>
</th>
<th>
<input type="button" name="30" value="গ" OnCLick="Calc.Input.value +='গ'"/>
</th>
















<th>
<input type="button" name="31" value="ঘ" OnClick="Calc.Input.value +='ঘ'"/>
</th>
<th>
<input type="button" name="32" value="ঙ" OnClick="Calc.Input.value +='ঙ'"/>
</th>
</tr>
<tr>
<th height="60">
<input type="button" name="33" value="চ" OnClick="Calc.Input.value +='চ'"/>
</th>
<th>
<input type="button" name="34" value="ছ" OnClick="Calc.Input.value +='ছ'"/>
</th>
<th>
<input type="button" name="35" value="জ" OnClick="Calc.Input.value +='জ'"/>
</th>
<th>
<input type="button" name="36" value="ঝ" OnClick="Calc.Input.value +='ঝ'"/>
</th>
</tr>
<tr>
<th height="60">
<input type="button" name="37" value="ঞ" OnClick="Calc.Input.value += 'ঞ'"/>
</th>
<th>
<input type="button" name="38" value="ট" OnClick="Calc.Input.value +='ট'"/>
</th>
<th>
<input type="button" name="39" value="ঠ" OnClick="Calc.Input.value +='ঠ'"/>













</th>
<th>
<input type="button" name="40" value="ড" OnClick="Calc.Input.value +='ড'"/>
</th>
</tr>
<tr>
<th height="60">
<input type="button" name="41" value="ঢ" OnClick="Calc.Input.value+='ঢ'"/>
</th>
<th>
<input type="button" name="42" value="ণ" OnCLick="Calc.Input.value+='ণ'"/>
</th>
<th>
<input type="button" name="43" value="ত" OnClick="Calc.Input.value+='ত'"/>
</th>
<th>
<input type="button" name="44" value="থ" OnClick="Calc.Input.value+= 'থ'"/>
</th>
</tr>
<tr>
<th height="60">
<input type="button" name="45" value="দ" OnClick="Calc.Input.value+='দ'"/>
</th>
<th>
<input type="button" name="46" value="ধ" OnCLick="Calc.Input.value+='ধ'"/>
</th>
<th>
<input type="button" name="47" value="ন" OnClick="Calc.Input.value+='ন'"/>
</th>
<th>











<input type="button" name="48" value="প" OnClick="Calc.Input.value+='প'"/>
</th>
</tr>
<tr>
<th height="60">
<input type="button" name="49" value="ফ" OnClick="Calc.Input.value +='ফ'"/>
</th>
<th>
<input type="button" name="50" value="ব" OnCLick="Calc.Input.value +='ব'"/>
</th>
<th>
<input type="button" name="51" value="ভ" OnClick="Calc.Input.value +='ভ'"/>
</th>
<th>
<input type="button" name="52" value="ম" OnClick="Calc.Input.value +='ম'"/>
</th>
</tr>
<tr>
<th height="60">
<input type="button" name="53" value="য" OnClick="Calc.Input.value +='য'"/>
</th>
<th>
<input type="button" name="54" value="র" OnClick="Calc.Input.value +='র'"/>
</th>
<th>
<input type="button" name="55" value="ল" OnClick="Calc.Input.value +='ল'"/>
</th>
<th>
<input type="button" name="56" value="শ" OnClick="Calc.Input.value +='শ'"/>
</th>













</tr>
<tr>
<th height="60">
<input type="button" name="57" value="ষ" OnClick="Calc.Input.value +='ষ'"/>
</th>
<th>
<input type="button" name="58" value="স" OnClick="Calc.Input.value +='স'"/>
</th>
<th>
<input type="button" name="59" value="হ" OnClick="Calc.Input.value +='হ'"/>
</th>
<th>
<input type="button" name="60" value="ড়" OnClick="Calc.Input.value +='ড়'"/>
</th>
</tr>
<tr>
<th height="60">
<input type="button" name="61" value="ঢ়" OnClick="Calc.Input.value +='ঢ়'"/>
</th>
<th>
<input type="button" name="62" value="য়" OnCLick="Calc.Input.value +='য়'"/>
</th>
<th>
<input type="button" name="63" value="ৎ" OnClick="Calc.Input.value +='ৎ'"/>
</th>
<th>
<input type="button" name="64" value="০" OnClick="Calc.Input.value += '০'"/>
</th>
</tr>
<tr>













<th height="60">
<input type="button" name="65" value="১" OnClick="Calc.Input.value +='১'"/>
</th>
<th>
<input type="button" name="66" value="২" OnCLick="Calc.Input.value +='২'"/>
</th>
<th>
<input type="button" name="67" value="৩" OnClick="Calc.Input.value +='৩'"/>
</th>
<th>
<input type="button" name="68" value="৪" OnClick="Calc.Input.value +='৪'"/>
</th>
</tr>
<tr>
<th height="60">
<input type="button" name="69" value="৫" OnClick="Calc.Input.value +='৫'"/>
</th>
<th>
<input type="button" name="70" value="৬" OnCLick="Calc.Input.value +='৬'"/>
</th>
<th>
<input type="button" name="71" value="৭" OnClick="Calc.Input.value +='৭'"/>
</th>
<th>
<input type="button" name="72" value="৮" OnClick="Calc.Input.value +='৮'"/>
</th>
</tr>
<tr>
<th height="60">
<input type="button" name="73" value="৯" OnClick="Calc.Input.value +='৯'"/>











</th>
<th>
<input type="button" name="74" value="," OnClick="Calc.Input.value +=','"/>
</th>
<th>
<input type="button" name="75" value="_" OnClick="Calc.Input.value +='_'"/>
</th>
<th>
<input type="button" name="76" value="sms" OnClick="mailto:123?body='+Calc.Input.value'"/>
</th>
</tr>
</table></div>
</form></div></div>
<div align="center"></div>
</p> </div>

</body></html>