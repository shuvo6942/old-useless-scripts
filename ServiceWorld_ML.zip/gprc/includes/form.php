<form name="pr" action="<?php $_SERVER['PHP_SELF'] ?>" method="post">
    <input type="text" value="<?php echo $_POST["www"]; ?>"  name="www" />
    <input type="submit" value="Check PageRank" />
</form>