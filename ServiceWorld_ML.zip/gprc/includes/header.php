<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Google PageRank Checker</title>
<link rel="shortcut icon" href="favicon.ico"/>
<meta name="description" content="Use our Google PageRank checker to quickly and easily find the PageRank of any web page. Our service is captcha-free and will always be free to to use and is good looking." />
<meta name="keywords" content="pagerank, page rank, prchecker, pagerank checker, pagerank lookup, pagerank tool, google pagerank, google pr, google rank, google rank checker, page rank tool, check page rank, check pagerank, website rankings" />
<link href="assets/style.css" type="text/css" rel="stylesheet" />
<link href="assets/reveal.css" rel="stylesheet" />
<script src="assets/jquery.min.js" type="text/javascript"></script>
<script src="assets/jquery.reveal.js" type="text/javascript"></script>
</head>