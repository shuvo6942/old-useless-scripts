<!DOCTYPE html>
<html lang="en">

<?php include 'includes/header.php'; ?>
<?php include 'includes/validation.php'; ?>

<body>

<div class="main">

<?php include 'includes/logo.php'; ?>
<?php include 'includes/form.php'; ?>
<?php include 'includes/response.php'; ?>
<?php include 'includes/footer.php'; ?>

<h5>By <a href="http://www.hardeepasrani.com" rel="nofollow" target="_blank">Hardeep Asrani</a></h5>
<h5>~ Made In India ~</h5>

</div>

<?php include 'includes/analyticstracking.php'; ?>

</body>
</html>