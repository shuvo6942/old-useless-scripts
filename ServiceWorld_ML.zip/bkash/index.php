<link rel="shortcut icon" href="http://phptunes.com/favicon.ico"/>
<link rel="stylesheet" type="text/css" href="http://bdmaruf.mobie.in/Css_Styles/BTSBD/Styles.css" media="all,handheld"/>





<title>Magic Call Resellar Website</title><meta name="description" content=" Make Your Own magic call Number in a Some Times"/>


<div><div align="center"><div class="h2" align="center">
<font face="Times New Roman" size="8" color="White"> Reseller BD</font>
<br/>
<font face="Segoe Script" size="4" color="White">Magic Call ID Sell Center</font>
</div>
</div></div>
<table class="c" width='100%' align="center" style="margin-center: 3px; margin-right: 4px;">
<td width="40%" align="center">

<a href="wtai://wp/mc;+8801860888278"> <div class="h2">Mobile</div>
</a> </td>
<td width="40%" align="center">
<a target="_blink" href="http://facebook.com/100010219905863">
<div class="h2">Facebook</div>
</a>
</td></table>
<div><div class="blok"><div class="h2">Welcome to Magic Call</div><div class="c" align="center"><img src="hotline.jpg" width="300"
height="100"/></div></div></div>
<div class="h2">আসুন মেজিক কল সম্পর্কে আমরা
জেনে নিই।</div>
<br/>
<div class="h2"> ১. মেজিক কল কি?</div>
<div class="x2"><div class="arrow"> <font color="red">
মেজিক কল মানে হচ্ছে
বাংলাদেশের একটি
প্রোভাইডার কোম্পানি।</font> </div> </div>
<div class="h2"> ২. এই সার্ভিসটির সুবিধা কি
কি?</div>
<div class="x2"><div class="arrow"> <font color="red">
এই সার্ভিসটি নিলে আপনি খুব
কম খরচে দেশ-বিদেশে কথা
বলতে পারবেন, এবং দেশি-
বিদেশি নাম্বার ব্যাবহার করতে
পাবেন।</font> </div> </div>
<div class="h2"> ৩. এই সার্ভিসটির মূল্য কত?</div>
<div class="x2"><div class="arrow"> <font color="red">
এই সার্ভিসটির মূল্য মাএ ২০০
টাকা, সাথে থাকবে ১০ মিনিট
ফ্রি টকটাইম।</font> </div> </div>
<div class="h2"> ৪. টাকা কিভাবে প্রদান করতে
হবে?</div>
<div class="x2"><div class="arrow"> <font color="red">
টাকা বিকাশ করে প্রদান করতে
টাকা বিকাশ করে প্রদান করতে
হবে, আমাদের বিকাশ নাম্বার- +8801793287801</font> </div> </div>
<div class="c" align="center"><img src="bkash.jpg" width="300"
height="100"/></div>
<div><div class="blok"><div class="h2">৫. আমি কি রকম নাম্বার তৈরি
করতে পারব?</div>
<div class="x2"><img src="http://bdmaruf.mobie.in/Image/Arrow/ok_nice.png" alt="" width="15px" height="15px"/> আপনি যে রকম নাম্বার বানাতে
চাইবেন সে রকম নাম্বার তৈরি
করে দেয়া হবে, সেটা বিদেশি
হোক বা বাংলাদেশি হোক।
আসল মজার ব্যাপার হচ্ছে এই
মেজিক নাম্বারটা দিয়ে শুধু
আপনিই ফোন করতে পাবেন,
আপনাকে কেউ ফোন করে বিরক্ত
করতে পারবে না।</div></div></div>
<div><div class="blok"><div class="h2">৬. কি কি মোবাইল দিয়ে
ব্যাবহার করা যাবে?</div>

<div class="x2"><img src="http://bdmaruf.mobie.in/Image/Arrow/ok_nice.png" alt="" width="15px" height="15px"/> যে যে মোবাইল দিয়ে ব্যাবহার
করা যাবে। Android, Windows,
Symbian, iPhone, Tab, Laptop. Not
java set support.</div>
</div></div>
<div><div class="blok">
<div class="h2">৭. আমি কিভাবে রিচার্জ করব?</div>

<div class="x2">
<img src="http://bdmaruf.mobie.in/Image/Arrow/ok_nice.png" alt="" width="15px" height="15px"/> রিচার্জ করা এখন আপনার হাতের
মুঠোই, আপনি বাংলাদেশের যে
প্রান্তে থাকেন না কেন ঘরে
বসে আপনি রিচার্জ করতে
পারবেন। কথা বলার জন্য আপনার
থেকে আমাদের কাছ থেকে
ডলার কিনতে হবে, ১ডলার মানে
বাংলাদেশের ৬৬ মিনিট, ১ডলার
এর দাম মাএ ৭৫ টাকা।
বাংলাদেশের ৬৬ মিনিট, ১ডলার






এর দাম মাএ ৭৫ টাকা।
---------------------------------------
♣♣♣♣♣♣♣♣♣♣♣♣♣♣♣♣ </div></div></div>
<div><div class="blok"><div class="h2">Payment Methods</div>



<div class="x2">
<font color="red">
<b>
<img src="http://bdmaruf.mobie.in/Image/icon/bkash.png" width="10" height="10"/>+8801793287801</b>
</font>
<font color="blue">
<b>bKash BD</b>
</font>


</div>


<div><div class="blok">
<div class="h2">আমাদের সাথে যোগাযোগ করুন</div><div class="x2">
<img src="http://bdmaruf.mobie.in/Image/icon/call.png" width="15" height="15"/> <b>
<font color="red">+8801860888278</font></b>
<font color="blue"> 24/7 Support</font>
</div>
</div>
</div>
<div class="x2">
<img src="http://bdmaruf.mobie.in/Image/icon/call.png" width="15" height="15"/> <b>
<font color="red">+8801735062959</font></b>
<font color="blue"> 24/7 Support</font>
</div>
</div>
</div>
<div class="brdr" align="center">
<div align="center">
<div align="center">
<div class="brdr">
<div class="header">Visitor Rank</div>
<a href="">
<img src="http://www.quick-counter.net/aip.php?tp=bt&amp;tz=Europe%2FLondon" alt="HTML hit counter - Quick-counter.net" border="0" /></a>
</div>
</div>
</div>
</div>
<div align="center" class="h2">2015-16 © <a href="index.php">
<font color="white"><b>Magic Caller ID Selling Site</b>
</font></a><br/> Reserved by ® [ServiceWorld.ML] </div>