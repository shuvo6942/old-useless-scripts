function brCheck(data)
{
  var ns4 = document.layers;
  var ns6 = document.getElementById && !document.all;
  var ie4 = document.all;
  
  if(ns4) br = "%0A";
  else if(ns6) br = "%0A";
  else if(ie4) br = "%0D%0A";
  else br = "%0D%0A";
	 
  data.value=data.value.replace(/"/gi,'\\"'); 
  dataArr=escape(data.value).split(br);
  data.value="";
	 
}
function scriptPHP(data){
brCheck(data);
for (i=0; i<dataArr.length; i++){
data.value+= (i==0) ? "<?php\necho " : "echo "
data.value+= "\"" + unescape(dataArr[i]); 
data.value+= (i!=dataArr.length-1) ? "\\n\"; \n" : "\\n\";\n"
}
data.value+="\?>"
}
function scriptJS(data){
brCheck(data);
for (i=0; i<dataArr.length; i++){
data.value+= (i==0) ? "<script type=\"text/javascript\">\n<!-- \ndocument.writeln(\" " : "document.writeln(\" "
data.value+= "" + unescape(dataArr[i])
data.value+= (i!=dataArr.length-1) ? " \"); \n" : " \");\n" 
}
data.value+=" \// \-->\n<\/script>"
}
function scriptASP(data){
brCheck(data);
for (i=0; i<dataArr.length; i++){
data.value+= (i==0) ? "#!/usr/bin/perl\nprint \"Content-type: text/html\\n\\n\";\n$code[0] = " : "$code["+i+"] = "
data.value+= "\"" + unescape(dataArr[i])
data.value+= (i!=dataArr.length-1) ? "\"; \n" : "\";\n" 
}
data.value+="for ($i=0;$i<scalar(@code);$i++) {print($code[$i].\"\\n\");}" 
}
function copyF(txx) {
with(txx){
focus(); select() 
}
if(document.all){
txt=txx.createTextRange()
txt.execCommand("Copy") 
}}
document.write('<div class="hdr"><b>HTML Converter</b></div><form name="doc" action=""><br/><textarea style="border:2px solid #ddd;margin:2px" name="tx" cols="15" rows="7"></textarea><br/><input style="background:#0084ff;color:#ddd;border:2px solid;border-color: #d3d3d3 #c3c3c3 #c8c8c8 #f3f3f3;margin:2px;padding:2px" name="button" type="button" onClick="scriptPHP(document.doc.tx)" value="HTML -> PHP"><br/><input style="background:#0084ff;color:#ddd;border:2px solid;border-color: #d3d3d3 #c3c3c3 #c8c8c8 #f3f3f3;margin:2px;padding:2px" name="button2" type="button" onClick="scriptJS(document.doc.tx)" value="HTML -> JavaScript"><br/><input style="background:#0084ff;color:#ddd;border:2px solid;border-color: #d3d3d3 #c3c3c3 #c8c8c8 #f3f3f3;margin:2px;padding:2px" name="button2" type="button" onClick="scriptASP(document.doc.tx)" value="HTML -> ASP"><br/>');


document.write('<input style="background:#0084ff;color:#ddd;border:2px solid;border-color: #d3d3d3 #c3c3c3 #c8c8c8 #f3f3f3;margin:2px;padding:2px" name="reset" type="reset" value="Reset" onClick="document.doc.tx.focus()"><br/><input style="background:#0084ff;color:#ddd;border:2px solid;border-color: #d3d3d3 #c3c3c3 #c8c8c8 #f3f3f3;margin:2px;padding:2px" name="button2" type="reset" value="Select All" onClick="copyF(document.doc.tx)"></form><br/>');