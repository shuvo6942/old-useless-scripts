<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>Text Fixer - Free Online HTML Tools</title>
<meta name="description" content="Online HTML tools for converting, changing and modifying text and html code." />
<meta name="keywords" content="online,text,tools,change,convert,modify,replace,remove,fix,html,conversion" />
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<meta name="robots" content="index,follow" />
<link type="text/css" href="/css/thestyle-2015.css" rel="stylesheet" media="all" />
<link rel="alternate" type="application/rss+xml" title="TextFixer RSS" href="http://www.textfixer.com/rss.xml" />
