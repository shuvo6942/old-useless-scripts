function removeSpaces(){


var nospaces = document.getElementById("nospaces").checked;
var notabs = document.getElementById("notabs").checked;
var nsText = document.getElementById("oldText").value;

nsText = nsText.replace(/(\n\r|\n|\r)/gm,"<1br />");

if(nospaces == 1 || nospaces ==  true){
nsText = nsText.replace(/\t/g,"");
}else{
nsText = nsText.replace(/\t/g," ");
}

re1 = /\s+/g;
nsText = nsText.replace(re1," ");

re2 = /\<1br \/>/gi;
nsText = nsText.replace(re2, "\n");


document.getElementById("newText").value = nsText;
}