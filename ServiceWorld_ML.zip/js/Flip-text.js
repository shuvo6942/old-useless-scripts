<!--
/* * * * * * * * * * * * * * * *
             *
Author : Sakib
URL : http://wTools.gq
* * * * * * * * * * * * * * * *
             */
function flip() {
var hasil = flipString(document.KisniWenRu.kisnisite.value.toLowerCase());
document.KisniWenRu.kisnilover.value = hasil;
}
function flipString(aString) {
var Kisni = aString.length - 1;
var hasil = new Array(aString.length)
for (var lucky = Kisni; lucky >= 0; --lucky) {
var ganteng = aString.charAt(lucky)
var r = flipTable[ganteng]
hasil[Kisni - lucky] = r != undefined ? r : ganteng
}
return hasil.join('')
}
var flipTable = {
a : '\u0250',
b : 'q',
c : '\u0254',
d : 'p',
e : '\u01DD',
f : '\u025F',
g : '\u0183',
h : '\u0265',
i : '\u0131',
j : '\u027E',
k : '\u029E',
l : 'l',
m : '\u026F',
n : 'u',
o : 'o',
p : 'd',
q : 'b',
r : '\u0279',
s : 's',
t : '\u0287',
u : 'n',
v : '\u028C',
w : '\u028D',
y : '\u028E',
z : 'z',
1 : '\u21C2',
2 : '\u1105',
3 : '\u1110',
4 : '\u3123',
5 : '\u078E',
6 : '9',
7 : '\u3125',
8 : '8',
9 : '6',
0 : '0',
'.' : '\u02D9',
',' : "\'",
"\'" : ',',
"\"" : ',,',
"?" : ',',
"`" : ',',
';' : '\u061B',
'!' : '\u00A1',
'\u00A1' : '!',
'?' : '\u00BF',
'\u00BF' : '?',
'[' : ']',
']' : '[',
'(' : ')',
')' : '(',
'{' : '}',
'}' : '{',
'<' : '>',
'>' : '<',
'_' : '\u203E',
'\r' : '\n' 
}
for (lucky in flipTable) {
flipTable[flipTable[lucky]] = lucky
}
document.write("<form name=\"KisniWenRu\" id=\"KisniWenRu\"><div align=\"center\">Your Text :<br><textarea rows=\"5\" cols=\"14\" name=\"kisnisite\"> </textarea><br><input type=\"button\" value=\"Generate\" onclick=\"flip()\"><br>Flip Text :<br><textarea rows=\"5\" cols=\"14\" name=\"kisnilover\"></textarea></div></form>");

document.writeln("  <div align=\"right\"> <a href=\"http://sisakib007.wapka.mobi/site_service.php\"> →More  </a></div> ");

//-->