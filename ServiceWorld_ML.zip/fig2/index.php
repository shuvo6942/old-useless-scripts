<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Facebook Chat Codes Generator</title><link rel="STYLESHEET" type="text/css" href="http://wtools.gq/styles.css"/><link rel="STYLESHEET" type="text/css" href="http://phptunes.com/favicon.ico"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/><style type="text/css">
body { background: ;
color: ;
}
a { color: ;
}
</style>
</head><body>








<div>
<p><div><script>
function generate()
{
var c=new Array();
c["a"]="[[lv.pinka]]";
c["b"]="[[lv.pinkb]]";
c["c"]="[[lv.pinkc1]]";
c["d"]="[[lv.pinkd]]";
c["e"]="[[lv.pinke]]";
c["f"]="[[lv.pinkf1]]";
c["g"]="[[lv.pinkg]]";
c["h"]="[[lv.pinkh]]";
c["i"]="[[lv.pinki]]";
c["j"]="[[lv.pinkj]]";
c["k"]="[[lv.pinkk]]";
c["l"]="[[lv.pinkl]]";
c["m"]="[[lv.pinkm]]";
c["n"]="[[lv.pinkn]]";
c["o"]="[[lv.pinko]]";
c["p"]="[[lv.pinkp]]";
c["q"]="[[lv.pinkq]]"; c["r"]="[[lv.pinkr]]";
c["s"]="[[lv.pinks]]";
c["t"]="[[lv.pinkt]]";
c["u"]="[[lv.pinku]]";
c["v"]="[[lv.pinkv]]";
c["w"]="[[lv.pinkw]]";
c["x"]="[[lv.pinkx]]";
c["y"]="[[lv.pinky]]";
c["z"]="[[lv.pinkz1]]";
c[""]="[[f9.blank]]";
c["-"]="[[f9.dash]]";
c["0"]="[[lv.pink0]]";
c["1"]="[[lv.pink1a]]";
c["2"]="[[lv.pink2]]";
c["3"]="[[lv.pinkc3]]";
c["4"]="[[lv.pink4]]";
c["5"]="[[lv.pink5]]";
c["6"]="[[lv.pink6]]";
c["7"]="[[lv.pink7]]";
c["8"]="[[lv.pink8]]";
c["9"]="[[lv.pinkc9]]";
c["."]=".";
c["?"]="?";
c["'"]="'";
c[","]=",";
c["!"]="[[355825317764954]]";
c["!"]="[[lv.exclm]]";
c["*"]="[[lv.starp]]";
var h =new Array();
h["a"]="<img src='http://fbchatemo.tk/lovetext/pink/a.jpg'/>";
h["b"]="<img src='http://fbchatemo.tk/lovetext/pink/b.jpg'/>";
h["c"]="<img src='http://fbchatemo.tk/lovetext/pink/c.jpg'/>";
h["d"]="<img src='http://fbchatemo.tk/lovetext/pink/d.jpg'/>";
h["e"]="<img src='http://fbchatemo.tk/lovetext/pink/e.jpg'/>";
h["f"]="<img src='http://fbchatemo.tk/lovetext/pink/f.jpg'/>";
h["g"]="<img src='http://fbchatemo.tk/lovetext/pink/g.jpg'/> ";














h["h"]="<img src='http://fbchatemo.tk/lovetext/pink/h.jpg'/> ";
h["i"]="<img src='http://fbchatemo.tk/lovetext/pink/i.jpg'/>";
h["j"]="<img src='http://fbchatemo.tk/lovetext/pink/j.jpg'/>";
h["k"]="<img src='http://fbchatemo.tk/lovetext/pink/k.jpg'/>";
h["l"]="<img src='http://fbchatemo.tk/lovetext/pink/l.jpg'/>";
h["m"]="<img src='http://fbchatemo.tk/lovetext/pink/m.jpg'/>";
h["n"]="<img src='http://fbchatemo.tk/lovetext/pink/n.jpg'/> ";
h["o"]="<img src='http://fbchatemo.tk/lovetext/pink/o.jpg'/> ";
h["p"]="<img src='http://fbchatemo.tk/lovetext/pink/p.jpg'/> ";
h["q"]="<img src='http://fbchatemo.tk/lovetext/pink/q.jpg'/> ";
h["r"]="<img src='http://fbchatemo.tk/lovetext/pink/r.jpg'/>";
h["s"]="<img src='http://fbchatemo.tk/lovetext/pink/s.jpg'/>";
h["t"]="<img src='http://fbchatemo.tk/lovetext/pink/t.jpg'/>";
h["u"]="<img src='http://fbchatemo.tk/lovetext/pink/u.jpg'/> ";
h["v"]="<img src='http://fbchatemo.tk/lovetext/pink/v.jpg'/>";














h["w"]="<img src='http://fbchatemo.tk/lovetext/pink/w.jpg'/>";
h["x"]="<img src='http://fbchatemo.tk/lovetext/pink/x.jpg'/>";
h["y"]="<img src='http://fbchatemo.tk/lovetext/pink/y.jpg'/>";
h["z"]="<img src='http://fbchatemo.tk/lovetext/pink/z.jpg'/>";
h["!"]="<img src='http://fbchatemo.tk/lovetext/pink/!.jpg'/>";
h["0"]="<img src='http://fbchatemo.tk/lovetext/pink/0.jpg'/> ";
h["0"]="<img src='http://fbchatemo.tk/lovetext/pink/0.jpg'/> ";
h["1"]="<img src='http://fbchatemo.tk/lovetext/pink/1.jpg'/> ";
h["2"]="<img src='http://fbchatemo.tk/lovetext/pink/2.jpg'/> ";
h["3"]="<img src='http://fbchatemo.tk/lovetext/pink/3.jpg'/> ";
h["4"]="<img src='http://fbchatemo.tk/lovetext/pink/4.jpg'/> ";
h["5"]="<img src='http://fbchatemo.tk/lovetext/pink/5.jpg'/> ";
h["6"]="<img src='http://fbchatemo.tk/lovetext/pink/6.jpg'/> ";
h["7"]="<img src='http://fbchatemo.tk/lovetext/pink/7.jpg'/> ";
h["8"]="<img src='http://fbchatemo.tk/lovetext/pink/8.jpg'/> ";















h["9"]="<img src='http://fbchatemo.tk/lovetext/pink/9.jpg'/> ";
h["*"]="<img src='http://fbchatemo.tk/lovetext/pink/star.jpg'/>";
var inp=document.getElementById('inp').value.toLowerCase();
var last = inp.length-1;
var tmpStr="";
var tmpHtml="";
alert(inp);
for (var i = 0; i <= last; i++)
{
if( inp.charAt(i) == "\n")
{
tmpStr += "\n";
tmpHtml += "<br/>";
}
else if( inp.charAt(i) == " ")
{
tmpStr += " [[f9.space]] ";
tmpHtml += " ";
}
else if(tmpStr== " ")
{
tmpStr = c[inp.charAt(i)];
tmpHtml = tmpHtml +
h[inp.charAt(i)];
}
else
{
tmpStr = tmpStr + " "+
c[inp.charAt(i)];
tmpHtml = tmpHtml +
" "+h[inp.charAt(i)];
}
}
document.getElementById('out').value = tmpStr;
document.getElementById('display').innerHTML =
"<p id='display'><b>Preview:</b><br/>"+tmpHtml+"</p>";
}
</script></div>
<div align="center"><div style="border: 1px solid red; margin: 2px; padding: 2px"><div class="lblue">Facebook chat code Generator (luv.pink)</div><hr class="rhr1"/>
<center>
<b>Enter Text:</b><br/>
<textarea cols="20"
rows="3" name="inp" id="inp"></textarea>
<input type="button"
name="convert" value="Generate Codes" onclick="generate()"/><br/>
<b>Result</b><br/><textarea cols="20"
rows="3" name="out"
id="out" onfocus="this.select();"></textarea>
<p id="display"></p></center></div></div></p>
</div>
</body></html>