<body bgcolor="#FFFFFF" text="#000000" link="#000000" vlink="#000000" alink="#FFCC00">
<font face=" verdana, tahoma" font size="-2">
<center>
<?php

if (!$HTTP_POST_VARS["value"] || 
!$HTTP_POST_VARS["value"]) 
{ 
echo "Please fill in TEXT field.";
echo '<a href="javascript:history.go(-1)">Go Back</a>'; 
exit; 
}
?>
</center>
</body>
</font>
<?php
include('config.php');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<meta name="title" content="PHP Form.net">
<head>
<style>
.highlighttext{
background-color:white;

font-weight:bold;
}
</style>

<script language="Javascript">
<!--

/*
Select and Copy form element script- By Dynamicdrive.com
For full source, Terms of service, and 100s DTHML scripts
Visit http://www.dynamicdrive.com
*/

//specify whether contents should be auto copied to clipboard (memory)
//Applies only to IE 4+
//0=no, 1=yes
var copytoclip=1

function HighlightAll(theField) {
var tempval=eval("document."+theField)
tempval.focus()
tempval.select()
if (document.all&&copytoclip==1){
therange=tempval.createTextRange()
therange.execCommand("Copy")
window.status="Contents highlighted and copied to clipboard!"
setTimeout("window.status=''",1800)
}
}
//-->
</script>
</head>
<body bgcolor="#FFFFFF" text="#000000" link="#FF6600" vlink="#FF3300" alink="#FFCC00">
<font face=" verdana, tahoma" font size="2">
<title><?php echo $title; ?></title>
<center>


<br>
<br>
<h2><?php echo $title; ?></h2><br>

<br>
Button Code
<br>
<br>
</center>
<br>
<?php
$value = $_POST['value'];
$family = $_POST['family'];
$size = $_POST['size'];
$style = $_POST['style'];
$color = $_POST['color'];
$ats = $_POST['ats'];
$weight = $_POST['weight'];
$background = $_POST['background'];
$weigh = $_POST['weigh'];
$borderc = $_POST['borderc'];
$borderw = $_POST['borderw'];
$borders = $_POST['borders'];
$zigi = $_POST['zigi'];
$ats = 'php form.net';
?>
<html>
<head>
<body bgcolor="#FFFFFF" text="#000000" link="#FF6600" vlink="#FF3300" alink="#FFCC00">
<br>
<br>
<a href="javascript:history.go(-1)">Go Back</a>
<form name="test">
<a class="highlighttext" href="javascript:HighlightAll('test.select1')">Select All</a><br>
<textarea name="select1" rows=1 cols=55 >
&lt;INPUT TYPE="<? echo $zigi; ?>" VALUE="<? echo $value; ?>"
STYLE="font-family:<? echo $family;  ?>;
font-size:<? echo $size; ?>; font-weight:<? echo $weight; ?>; font-style:<? echo $style; ?>; border-style:<? echo $borders; ?>; 
 border-color:#<? echo $borderc; ?>; border-width:<? echo $borderw; ?>; background:#<? echo $background; ?>; color:#<? echo $color; ?>; width:<? echo $weigh; ?>"&gt; 
</textarea>
</form>
<center>
<INPUT TYPE="<? echo $zigi; ?>" VALUE="<? echo $value; ?>"
STYLE="font-family:<? echo $family; ?>; font-size:<? echo $size; ?>; font-weight:<? echo $weight; ?>;
font-style:<? echo $style; ?>; border-style:<? echo $borders; ?>; border-color:#<? echo $borderc; ?>; border-width:<? echo $borderw; ?>; background:#<? echo $background; ?>; color:#<? echo $color; ?>; width:<? echo $weigh; ?>"></font><br><hr></br> 

<font face=" verdana, tahoma" font size="-2"><b>
<?php $urlv = "http://phpform.net"; ?>
copyright <a target='_BLANK' href=<?php echo $siteurl; ?>><?php echo $powered; ?></a><br>
powered by <a target='_BLANK' href=<?php echo $urlv; ?>><?php echo $ats; ?></a><br>
</b>
</font>
</center>
