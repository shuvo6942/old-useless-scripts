<?php
$powered = 'mysitename.tr';
$title = 'HTML Button Generator';
#############################
# DO NOT EDIT BELOW THIS LINE
#############################
$urlz = getenv(HTTP_HOST);
$siteurl = "http://$urlz";
$powereds = 'phpform.net'
?>