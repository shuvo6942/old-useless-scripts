<?php
include('config.php');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<title><?php echo $title; ?></title>
<meta name="title" content="PHP Form.net">
<html>
<center>
<font face=" verdana, tahoma">
<h3><?php echo $title; ?></h3>
</font>
</center>
    <TABLE cellSpacing=0 cellPadding=0 width="45%" align=right 
bgColor=#ffffff border=0>
  <TBODY>
   <TR>
    <TD>

Change This. Right Block. index.php. line 15.
     <br>
   </TD>
  </TR>
  <TD align=middle height=25></TD></TR></TBODY></TABLE>
<head>
<script type="text/javascript">
/*
Form field Limiter script- By Dynamic Drive
For full source code and more DHTML scripts, visit http://www.dynamicdrive.com
This credit MUST stay intact for use
*/

var ns6=document.getElementById&&!document.all

function restrictinput(maxlength,e,placeholder){
if (window.event&&event.srcElement.value.length>=maxlength)
return false
else if (e.target&&e.target==eval(placeholder)&&e.target.value.length>=maxlength){
var pressedkey=/[a-zA-Z0-9\.\,\/]/ //detect alphanumeric keys
if (pressedkey.test(String.fromCharCode(e.which)))
e.stopPropagation()
}
}

function countlimit(maxlength,e,placeholder){
var theform=eval(placeholder)
var lengthleft=maxlength-theform.value.length
var placeholderobj=document.all? document.all[placeholder] : document.getElementById(placeholder)
if (window.event||e.target&&e.target==eval(placeholder)){
if (lengthleft<0)
theform.value=theform.value.substring(0,maxlength)
placeholderobj.innerHTML=lengthleft
}
}


function displaylimit(thename, theid, thelimit){
var theform=theid!=""? document.getElementById(theid) : thename
var limit_text='<b><span id="'+theform.toString()+'">'+thelimit+'</span></b> characters remaining on your input limit'
if (document.all||ns6)
document.write(limit_text)
if (document.all){
eval(theform).onkeypress=function(){ return restrictinput(thelimit,event,theform)}
eval(theform).onkeyup=function(){ countlimit(thelimit,event,theform)}
}
else if (ns6){
document.body.addEventListener('keypress', function(event) { restrictinput(thelimit,event,theform) }, true); 
document.body.addEventListener('keyup', function(event) { countlimit(thelimit,event,theform) }, true); 
}
}

</script>
<link rel="stylesheet" type="text/css" href="css/screen.css">
<script type="text/javascript" src="js/ddcolorposter.js"></script>
<script type="text/javascript" src="js/YAHOO.js" ></script>
<script type="text/javascript2" src="js/log.js" ></script>
<script type="text/javascript" src="js/color.js" ></script>

<script type="text/javascript" src="js/event.js" ></script>
<script type="text/javascript" src="js/dom.js" ></script>
<script type="text/javascript" src="js/animation.js" ></script>
<script type="text/javascript" src="js/dragdrop.js" ></script>

<script type="text/javascript" src="js/slider.js" ></script>
<script type="text/javascript">

	var hue;
	var picker;
	//var gLogger;
	var dd1, dd2;
	var r, g, b;

	function init() {
		if (typeof(ygLogger) != "undefined")
			ygLogger.init(document.getElementById("logDiv"));
		pickerInit();
		ddcolorposter.fillcolorbox("colorfield1", "colorbox1") //PREFILL "colorbox1" with hex value from "colorfield1"
		ddcolorposter.fillcolorbox("colorfield2", "colorbox2") //PREFILL "colorbox1" with hex value from "colorfield1"
                ddcolorposter.fillcolorbox("colorfield3", "colorbox3") //PREFILL "colorbox1" with hex value from "colorfield1"
    
 }

    // Picker ---------------------------------------------------------

    function pickerInit() {
		hue = YAHOO.widget.Slider.getVertSlider("hueBg", "hueThumb", 0, 180);
		hue.onChange = function(newVal) { hueUpdate(newVal); };

		picker = YAHOO.widget.Slider.getSliderRegion("pickerDiv", "selector",
				0, 180, 0, 180);
		picker.onChange = function(newX, newY) { pickerUpdate(newX, newY); };

		hueUpdate();

		dd1 = new YAHOO.util.DD("pickerPanel");
		dd1.setHandleElId("pickerHandle");
		dd1.endDrag = function(e) {
			// picker.thumb.resetConstraints();
			// hue.thumb.resetConstraints();
        };
	}

	executeonload(init);

	function pickerUpdate(newX, newY) {
		pickerSwatchUpdate();
	}


	function hueUpdate(newVal) {

		var h = (180 - hue.getValue()) / 180;
		if (h == 1) { h = 0; }

		var a = YAHOO.util.Color.hsv2rgb( h, 1, 1);

		document.getElementById("pickerDiv").style.backgroundColor =
			"rgb(" + a[0] + ", " + a[1] + ", " + a[2] + ")";

		pickerSwatchUpdate();
	}

	function pickerSwatchUpdate() {
		var h = (180 - hue.getValue());
		if (h == 180) { h = 0; }
		document.getElementById("pickerhval").value = (h*2);

		h = h / 180;

		var s = picker.getXValue() / 180;
		document.getElementById("pickersval").value = Math.round(s * 100);

		var v = (180 - picker.getYValue()) / 180;
		document.getElementById("pickervval").value = Math.round(v * 100);

		var a = YAHOO.util.Color.hsv2rgb( h, s, v );

		document.getElementById("pickerSwatch").style.backgroundColor =
			"rgb(" + a[0] + ", " + a[1] + ", " + a[2] + ")";

		document.getElementById("pickerrval").value = a[0];
		document.getElementById("pickergval").value = a[1];
		document.getElementById("pickerbval").value = a[2];
		var hexvalue = document.getElementById("pickerhexval").value =
			YAHOO.util.Color.rgb2hex(a[0], a[1], a[2]);
			ddcolorposter.initialize(a[0], a[1], a[2], hexvalue)
	}

</script>


<!--[if gte IE 5.5000]>
<script type="text/javascript">

function correctPNG() // correctly handle PNG transparency in Win IE 5.5 or higher.
   {
   for(var i=0; i<document.images.length; i++)
      {
	  var img = document.images[i]
	  var imgName = img.src.toUpperCase()
	  if (imgName.substring(imgName.length-3, imgName.length) == "PNG")
	     {
		 var imgID = (img.id) ? "id='" + img.id + "' " : ""
		 var imgClass = (img.className) ? "class='" + img.className + "' " : ""
		 var imgTitle = (img.title) ? "title='" + img.title + "' " : "title='" + img.alt + "' "
		 var imgStyle = "display:inline-block;" + img.style.cssText
		 if (img.align == "left") imgStyle = "float:left;" + imgStyle
		 if (img.align == "right") imgStyle = "float:right;" + imgStyle
		 if (img.parentElement.href) imgStyle = "cursor:hand;" + imgStyle
		 var strNewHTML = "<span " + imgID + imgClass + imgTitle
		 + " style=\"" + "width:" + img.width + "px; height:" + img.height + "px;" + imgStyle + ";"
	     + "filter:progid:DXImageTransform.Microsoft.AlphaImageLoader"
		 + "(src=\'" + img.src + "\', sizingMethod='scale');\"></span>"
		 img.outerHTML = strNewHTML
		 i = i-1
	     }
      }
   }

YAHOO.util.Event.addListener(window, "load", correctPNG);

</script>
<![endif]-->
</head>
<body bgcolor="#FFFFFF" text="#000000" link="#000000" vlink="#000000" alink="#FFCC00">
   <div id="pickerPanel" class="dragPanel">
            <h4 id="pickerHandle">&nbsp;</h4>
            <div id="pickerDiv">
              <img id="pickerbg" src="img/pickerbg.png" alt="">
              <div id="selector"><img src="img/select.gif"></div>
            </div>

             <div id="hueBg">
              <div id="hueThumb"><img src="img/hline.png"></div>
            </div>

            <div id="pickervaldiv">
                <form name="pickerform" onsubmit="return pickerUpdate()">
                <br />
                R <input name="pickerrval" id="pickerrval" type="text" value="0" size="3" maxlength="3" />
                H <input name="pickerhval" id="pickerhval" type="text" value="0" size="3" maxlength="3" />
                <br />
                G <input name="pickergval" id="pickergval" type="text" value="0" size="3" maxlength="3" />
                S <input name="pickergsal" id="pickersval" type="text" value="0" size="3" maxlength="3" />
                <br />
                B <input name="pickerbval" id="pickerbval" type="text" value="0" size="3" maxlength="3" />
                V <input name="pickervval" id="pickervval" type="text" value="0" size="3" maxlength="3" />
                <br />
                <br />
                # <input name="pickerhexval" id="pickerhexval" type="text" value="0" size="6" maxlength="6" />
                <br />

                </form>
            </div>
         <div id="pickerSwatch">&nbsp;</div>
        </div>
       </div>
     </div>
  </div>
</font>

<div id="Zanel">
<b><font face=" verdana, tahoma" font size="1">
<form name="myform" action="meta.php" method="POST">
<table width="100%" border="0">
<tr>
TYPE
<select name="zigi">
<option value="SUBMIT">SUBMIT
</option><option value="TEXT">TEXT
</option><option value="FILE">FILE
</option><option value="HIDDEN">HIDDEN
</option><option value="BUTTON">BUTTON
</option>
<option value="RESET">RESET
</option>
</select>
TEXT
<input type=text style="font-size: 13px; font-family: tahoma,arial; font-weight: bold; color: #FF6600; BORDER: #000000 1px line ; BACKGROUND-COLOR: #F8F8F8" input name="value"  size="20">
<script>
displaylimit("document.myform.value","",16)
</script>
<br>
Font Family
<select name="family">
<option value="tahoma">Tahoma</option>
<option value="verdana">Verdana</option>
<option value="arial">Arial</option>
<option value="sans serif">Sans Serif</option>
<option value="comic sans MS">Comic Sans</option>

</select>

Font Size
<select name="size">
<option value="12px">12px</option>
<option value="13px">13px</option>
<option value="14px">14px</option>
<option value="15px">15px</option>
<option value="16px">16px</option>
<option value="17px">17px</option>
<option value="18px">18px</option>
<option value="19px">19px</option>
<option value="20px">20px</option>
<option value="21px">21px</option>
<option value="22px">22px</option>
<option value="23px">23px</option>
</select>
Font Style
<select name="style">
<option value="none">Normal
</option>
<option value="italic">Italic
</option>
</select><br>
Font Weight
<select name="weight">
<option value="none">Normal
</option>
<option value="bold">Bold
</option>
</select>
Border Style
<select name="borders">
<option value="normal">Normal
</option>
<option value="inset">Inset
</option>
<option value="outset">Outset
</option>
<option value="solid">Solid
</option>
<option value="dashed">Dashed
</option>
<option value="dotted">Dotted
</option>
<option value="double">Double
</option>
<option value="groove">Groove
</option>
<option value="ridge">Ridge
</option>
</select>
Border Width
<select name="borderw">
<option value="1px">1px
</option>
<option value="2px">2px
</option>
<option value="3px">3px
</option>
<option value="4px">4px
</option>
<option value="5px">5px
</option>
<option value="6px">6px
</option>
</select>
Weight
<select name="weigh">
<option value="8em">8em
</option>
<option value="9em">9em
<option value="10em">10em
</option>
<option value="11em">11em
<option value="12em">12em
</option>
<option value="13em">13em
<option value="14em">14em
</option>
<option value="15em">15em
<option value="16em">16em
</option>
<option value="17em">17em
<option value="18em">18em
</option>
<option value="19em">19em
</option>
<option value="20em">20em
</option>
<option value="21em">21em
<option value="25em">25em
</option>
<option value="30em">30em
</option>
</select>
<br>
Font Color <input type="text" name="color" id="colorfield1" onFocus="ddcolorposter.echocolor(this, 'colorbox1')"> <span id="colorbox1" class="colorbox">____</span> 
Background <input type="text" name="background" id="colorfield2" onFocus="ddcolorposter.echocolor(this, 'colorbox2')"> <span id="colorbox2" class="colorbox">____</span>
Border Color <input type="text" name="borderc" id="colorfield3" onFocus="ddcolorposter.echocolor(this, 'colorbox3')"> <span id="colorbox3" class="colorbox">____</span>

<td>
<INPUT TYPE="SUBMIT" VALUE=" Submit"
STYLE="font-family:verdana;
font-size:12px; font-weight:bold; font-style:none; border-style:solid; 
 border-color:#0C0D0C; border-width:1px; background:#3AC23A; color:#FFFFFF; width:8em"> 
<INPUT TYPE="RESET" VALUE=" Reset"
STYLE="font-family:verdana;
font-size:12px; font-weight:bold; font-style:none; border-style:solid; 
 border-color:#0C0D0C; border-width:1px; background:#3AC23A; color:#FFFFFF; width:8em"> 
</td></tr></table>
</form>
</body>
<!-- Form ends -->
<br>
<center>
<?php $urlv = "http://phpform.net"; ?>
copyright <a target='_BLANK' href=<?php echo $siteurl; ?>><?php echo $powered; ?></a><br>
powered by <a target='_BLANK' href=<?php echo $urlv; ?>><?php echo $powereds; ?></a><br>
</font>
</body>
</center>
