Edit config.php

'mysitename.tr' ////site name
'HTML Button Generator' /////generator name

