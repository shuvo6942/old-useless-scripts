<!DOCTYPE html>
<html>
<head>
<title>Image Uploader</title>
</head>
<body>
<form action="uploads.php" method="post" enctype="multipart/form-data">
<h1>Select image to upload:</h1>
<input type="file" name="fileToUpload" id="fileToUpload"><br/>
<input type="submit" value="Upload Image" name="submit">
</form><br/>
<?php
$url = $_SERVER['HTTP_HOST'];
$path = "uploads/";
$files = scandir($path);
foreach ($files as &$value) {
echo "<img src='uploads/$value' width='90px' height='90px' /><input type='text' value='http://".$url."/uploads/$value' /> <br/>";
}
?>
</body>
</html>
<style>body{width:500px"}</style>