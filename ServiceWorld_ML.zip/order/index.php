<?php
echo '<?xml version="1.0" encoding="UTF-8"?><!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>This Site Is A Truster Web/Wap Site Making Companie</title><link rel="STYLESHEET" type="text/css" href="/styles.css"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/><meta http-equiv="refresh" content="10;URL=www.facebook.com"/><style type="text/css">
body { background: ;
color: ;
}
a { color: ;
}
</style>
<head><style type="text/css">

a:link, a:visited {
color : #fe8f17;


text-decoration : none;
}
a:hover {
color : #ff4e00;
text-decoration : none;
}
input, textarea, select {
color : #6d6d6d;
background-color : #101010;
border : 1px solid #363636;
}
input:hover, textarea:hover, select:hover {
color : #8f8f8f;
background-color : #212121;
border : 1px solid #434343;
}
input:focus, textarea:focus, select:focus {
color : #78b100;
background-color : #1c2900;
border : 1px solid #385400;
}
body {
color: #CCCCCC;
font-size : 11px;
background-color : #000;
font-family : Tahoma;
margin : 0;
padding : 0;
border : 1px solid #3b3b3b;
margin: auto; max-width: 650px;
}
form {
font-size : small;
margin : 0;
padding : 0;
}
h3 {
margin : 0;
padding : 0;
padding-bottom : 2px;
}
hr {
margin-top : 2px;
margin-bottom : 2px;
border-top : 1px solid #434343;
border-right-style : none;
border-right-width : 0;
border-bottom-style : none;
border-bottom-width : 0;
border-left-style : none;
border-left-width : 0;
}
p {
margin-top : 6px;
margin-bottom : 6px;
}
ul {
margin : 0;
padding-left : 20px;
}
.bmenu, .birumuda, .phdr, .hdr {
color : #0084b5;
text-shadow : #000000 1px 1px 2px;
background-color : #000406;
background-image : url(http://zeroclan.wapka.mobi/img/4829/4829904_25765fda10.gif);
background-repeat : repeat-x;
background-position : 50% top;
margin-top : 1px;
margin-bottom : 1px;
padding : 2px;
border : 1px solid #005064;
}
.bmenu a {
color : #0084b5;
border-bottom : 1px dotted #004354;
}
.bmenu a:hover {
color : #25c5ff;
border-bottom : 1px dotted #006882;
}
.clip {
color : #459bb1;
border : 1px solid #3f3f3f;
font-size : x-small;
background-color : #292929;
padding : 4px 4px 8px;
}
.end {
text-align : center;
}
.func {
border-left : 4px solid #659300;
color : #757575;
font-size : x-small;
margin-top : 4px;
margin-left : 2px;
padding-left : 4px;
border-top : 1px dotted #4f4f4f;
}
.gmenu {
color : #75bf00;
background-color : #030500;
background-image : url(http://zeroclan.wapka.mobi/img/4829/4829911_baa56730df.gif);
background-repeat : repeat-x;
background-position : 50% top;
margin-top : 1px;
margin-bottom : 1px;
padding : 2px;
border : 1px solid #415f00;
}
.gmenu a {
color : #75bf00;
border-bottom : 1px dotted #223200;
}
.gmenu a:hover {
color : #96f400;
border-bottom : 1px dotted #395400;
}
.gray {
color : #586776;
}
.a, .coklat, .logo {
margin: 1px;
padding: 1px;
color : #b94201;
text-align : center;
background-color : #020100;
background-image : url(http://zeroclan.wapka.mobi/img/4829/4829917_1b73b8c9eb.gif);
background-repeat : repeat-x;
background-position : 50% bottom;
margin-top : 1px;
margin-bottom : 1px;
padding : 2px;
border-top : 1px solid #5c2901;
border-bottom : 1px solid #5c2901;
border-left : 1px solid #5c2901;
border-right : 1px solid #5c2901;
}
.header, .footer {
margin: 1px;
padding: 1px;
background-image : url(http://zeroclan.wapka.mobi/img/4829/4829927_3c6be0c784.gif);
color : #a9a9a9;
text-shadow : #000000 1px 1px 2px;
background-color : #0a0a0a;
background-repeat : repeat-x;
background-position : 50% top;
margin-bottom : 1px;
padding : 2px;
border : 1px solid #333333;
}
.footer a:link {
color : #a9a9a9;
text-decoration : none;
border-bottom : 1px dotted #3f3f3f;
}
.footer a:hover {
color : #d2d2d2;
text-decoration : none;
border-bottom : 1px dotted #696969;
}
.left {
float : left;
}
.list1 {
background-color : #101010;
margin-top : 1px;
margin-bottom : 1px;
padding : 2px;
border : 1px solid #323232;
}
.list2 {
background-color : #212121;
margin-top : 1px;
margin-bottom : 1px;
padding : 2px;
border : 1px solid #323232;
}
.maintxt {
padding-right : 1px;
padding-left : 1px;
border : 1px solid #3b3b3b;
}
.b, .c, .d, .menu, .news {
background-color : #040404;
background-image : url(http://zeroclan.wapka.mobi/img/4829/4829931_07ac8fd0aa.gif);
background-repeat : repeat-x;
background-position : 50% bottom;
margin-top : 1px;
margin-bottom : 1px;
padding : 2px;
border : 1px solid #353535;
}
.bb {
background-color : #CCCCCC;
background-image : url(http://zeroclan.wapka.mobi/img/4829/4829931_07ac8fd0aa.gif);
background-repeat : repeat-y;
background-position : 50% bottom;
margin-top : 1px;
margin-bottom : 1px;
padding : 2px;
border : 1px solid #353535;
}
.phpcode {
color : #00798f;
background-color : #001114;
border : 1px dotted #00272e;
margin-top : 4px;
padding : 0 2px;
}
.quote {
border-left : 4px solid #5c5c5c;
color : #b5b4b4;
text-shadow : #000000 1px 1px 2px;





font-size : x-small;
padding : 2px 0 2px 4px;
margin-left : 2px;
}
.red a:link, .red a:visited {
color : #d20000;
}
.reply {
border-left : 4px solid #ca0000;
color : #db0000;
padding : 2px 0 2px 4px;
}
.rmenu, .alarm {
color : #bd0000;
background-color : #050000;
background-image : url(http://zeroclan.wapka.mobi/img/4830/4830970_b021b898cb.gif);
background-repeat : repeat-x;
background-position : 50% top;
margin-top : 1px;
margin-bottom : 1px;
padding : 2px;
border : 1px solid #590000;
}
.status {
color : #3fa400;
text-shadow : #000000 3px 3px 4px;
font-weight : bold;
font-size : x-small;
padding-left : 0;
}
.sub {
border-top : 1px dotted #4b4b4b;
font-size : x-small;
margin-top : 4px;
}
.sub a:link, .sub a:visited {
text-decoration : none;
}
.tmn, .tmenu, .fmenu {
margin: 1px;
padding: 1px;
color : #b94201;
text-shadow : #000000 1px 1px 2px;
background-color : #020100;
background-image : url(http://zeroclan.wapka.mobi/img/4830/4830989_fff3216dc7.gif);



background-repeat : repeat-x;
background-position : 50% bottom;
margin-top : 1px;
margin-bottom : 1px;
padding : 2px;
border : 1px solid #5c2901;
}
.tmn a:link, .tmn a:visited, .fmenu a:link, .fmenu a:visited {
color : #b94201;
text-decoration : none;
border-bottom : 1px dotted #602200;
}
.tmn a:hover, .fmenu a:hover {
color : #ff5a00;
border-bottom : 1px dotted #933400;
}
.merah {
color : #bd0000;
background-color : #050000;
background-image : url(http://zeroclan.wapka.mobi/img/4830/4830970_b021b898cb.gif);
background-repeat : repeat-x;
background-position : 50% top;
margin-top : 1px;
margin-bottom : 1px;
padding : 2px;
border : 1px solid #590000;
}
.hijau {
color : #75bf00;
background-color : #030500;
background-image : url(http://zeroclan.wapka.mobi/img/4829/4829911_baa56730df.gif);
background-repeat : repeat-x;
background-position : 50% top;
margin-top : 1px;
margin-bottom : 1px;
padding : 2px;
border : 1px solid #415f00;
}
.hijau a {
color : #75bf00;
border-bottom : 1px dotted #223200;
}
.hijau a:hover {
color : #96f400;
border-bottom : 1px dotted #395400;
}

</style></head>
</head><body>
<div><link rel="shortcut icon" href="http://pankajbd24.com/favicon.ico" /></div>
<div><meta name="description" content="Order any site here Instrumental"/> <meta name="author" content="Owner: Shuvo"/></div>
<div><head><title>Make Your Own Web Site Low Rate. এখানে কম দামে সকল প্রকার ওয়েবসাইট তৈরী করা হয় !!!! আমরা আপনার Order - এর অপেক্ষায় আছি। 01624172388 </title></head></div>
<div align="center"><div class="hdr"  align="center"><span><b><img src="http://createfunnylogo.com/logo/ning/Demo Site.jpg" alt="image" hight="240" width="320" /></b></span></div></div>
<div align="center"><div class="hdr"><span style="color: #00ffff;">নিজের নামে সাইট বানান কম দামে <br/></span></div></div>









<div><div><div align="center"><div align="center"><div class="birumuda" align="left"><div class="list1"><b></b><span style="color: green;">আপনি হয়ত ভাবছেন নিজের নাম এ আমার একটি সাইট হতো। কিন্তু আপনি সাইট বানাতে পারেন না বা সাইট সাজাতে পারেন না। তায় আমরা আপনার কথা ভেবে সব তে কে কম দাম এ সাইট বানিয়ে দেয়ার উদ্যোগ নিয়েছি l যা আপনার ক্রয় মুল্যের নাগালে। </span></div></div></div></div></div></div>
<div><div><div align="center"><div align="center"><div class="birumuda" align="center"><div class="list1"><b></b><b>এখানে কম দামে সকল প্রকার ওয়েবসাইট তৈরী করা হয় !!!! আমরা আপনার Order - এর অপেক্ষায় আছি।</b><br/>
<font color="Pink"><small><a href="http://facebook.com/mehedi.hasan.shuvo7251"><img src="http://mastersitebd.ml/img/400716/400716920_6105b59570.png" alt="image" /></a></small></font></div></div></div></div></div></div>





<div><div class="header"><img src="http://greentooth.xtgem.com/i1/grph.png"/>Site Or Domain Update</div><div><div align="center"><div align="center"><div class="birumuda" align="left">







<div class="list1">
Currently There is No Site or Domain Update For Our Users.Thanks.<br/><br/><br/>Note : Niche site gulor jei dam deoa ace.Sei Dam et Theke Kom neoa Amader Pokhe Somvhob Na <br/> <p align="right">By: MH Shuvo</p></div></div></div></div></div></div>
<div align="center"><div class="hdr"  align="center"><span><b><br/>DOWNLOAD SITE</b></span></div></div>
<div><div class="header"><span style="color: green;">এই সাইট এ আপনি আপনার পছন্দের গান ছবি ফাইল গেম ইত্তাদি পছন্দের File রাখোতে পারবেন এবং এই সাইট তে কে সবাই Download করতে পারবে. </span></div></div>
<div align="center"><div class="hdr"><span style="color: whit;">Demo Sites</span></div></div>







<div><div class="header"><table width="100%"><tr><td width="50%"><div class="header"><a href="http://wapking.in">Wapking.In</a></div></td><td width="50%"><div class="header"><a>100TK</a></div></td></tr></table><table width="100%"><tr><td width="50%"><div class="header"><a href="http://bossmobi.com">BossMobi.Com</a></div></td><td width="50%"><div class="header"><a>100TK</a></div></td></tr></table></div></div>
<div><div class="header"><table width="100%"><tr><td width="50%"><div class="header"><a href="http://bdfuns.com">BdFuns.Com</a></div></td><td width="50%"><div class="header"><a>100TK</a></div></td></tr></table><table width="100%"><tr><td width="50%"><div class="header"><a href="http://dailymaza.com">DailyMaza.Com</a></div></td><td width="50%"><div class="header"><a>100TK</a></div></td></tr></table></div></div>
<div align="center"><div class="hdr"  align="center"><span><b><br/><bold>FORUM SITE</bold></b></span></div></div>












<div><div class="header"><span style="color: green;">এই সাইট এ আপনি FB,LOVE ETC TIPS &amp; TRICK দিতে পারবেন এবং পছন্দের জিনিস share করতে পারবেন </span></div></div>
<div align="center"><div class="hdr"><span style="color: whit;">Demo Sites</span></div></div>
<div><div class="header"><table width="100%"><tr><td width="50%"><div class="header"><a href="http://phpmycode.tk">PHPMYCODE.TK</a></div></td><td width="50%"><div class="header"><a>150TK</a></div></td></tr></table><table width="100%"><tr><td width="50%"><div class="header"><a href="http://susukan.us">Susukan.Us English V</a></div></td><td width="50%"><div class="header"><a>100TK</a></div></td></tr></table></div></div>










<div><div class="header"><table width="100%"><tr><td width="50%"><div class="header"><a href="http://mtunesbd.com">MtunesBD.Com</a></div></td><td width="50%"><div class="header"><a>150TK</a></div></td></tr></table><table width="100%"><tr><td width="50%"><div class="header"><a href="http://johncms.com">JohnCMS.Com</a></div></td><td width="50%"><div class="header"><a>100TK</a></div></td></tr></table></div></div>
<div><div class="header"><table width="100%"><tr><td width="50%"><div class="header"><a href="http://phpbdtrick.tk">PHPBDTRICK</a></div></td><td width="50%"><div class="header"><a>170TK</a></div></td></tr></table></div></div>
<div align="center"><div class="hdr"  align="center"><span><b><br/><bold>TOPLIST SITE</bold></b></span></div></div>
<div><div class="header"><span style="color: green;">এই সাইট ধারা অন্ন সাইট এর Rank বা ওয়ার্ল্ড এর টপ সাইট কোনটা এটা বুঝা যায় </span></div></div>









<div align="center"><div class="hdr"><span style="color: whit;">Demo Sites</span></div></div>
<div align="center"><div class="header"><table width="100%"><tr><td width="50%"><div class="header"><a href="http://hotwapi.com">HotWapi.Com</a></div></td><td width="50%"><div class="header"><a>100TK</a></div></td></tr></table><table width="100%"><tr><td width="50%"><div class="header"><a href="http://bd-polash25.tk">BD-Polash25.TK</a></div></td><td width="50%"><div class="header"><a>100TK</a></div></td></tr></table></div></div>
<div><div class="header"><table width="100%"><tr><td width="50%"><div class="header"><a href="http://pbest.tk">PBES.TK</a></div></td><td width="50%"><div class="header"><a>170TK</a></div></td></tr></table></div></div>
<div><div class="hdr"  align="center"><span><b><br/><bold>HACKING SITE</bold></b></span></div></div>



<div><div class="header"><span style="color: green;">এই সাইট ধারা আপনি আপনার শত্রুর Facebook/Wapka/Gmail/Yahoo আইডি Password পায়া যাবেন</span></div></div>
<div align="center"><div class="hdr">Demo Sites</div></div>
<div align="center"><div class="header"><table width="100%"><tr><td width="50%"><div class="header"><a href="http://is.gd/cybernetra">Mobile Vr LogIn Style</a></div></td><td width="50%"><div class="header"><a>60TK</a></div></td></tr></table><table width="100%"><tr><td width="50%"><div class="header"><a href="http://wapka.mobi">Wapka Phising</a></div></td><td width="50%"><div class="header"><a>100TK</a></div></td></tr></table></div></div>
<div><div><div align="center"><div class="phdr" align="center"> SEO = Search Engine Optimization  </div></div>
</div>
</div>




<div><div><div class="list2"><b>SEO হচ্ছে সাইট Google.com এ এড দেয়ার একটা প্রোগ্রাম। । আমাদের অনেকের সপ্ন থাকে নিজের সাইট টপ ১০ এর মাঝে দেখতে।।কিন্তু অনেক এ পারি অনেক এ পারি না।।।আমরা ১০০% গ্যারান্টি সহকারে ১৫ দিনের মধ্যে google.com এ টপ করে দিব।।।</b></div>
</div>
</div>
<div><div><div><div><div><div class="phdr"><div class="list2"><div class="a"><img src="http://wapkaimage.com/0/_" alt="" /> Top Add Pay List</div><div class="list2"><img src="http://masterbd.ml/icon/93.gif" alt="-" /> Google search 1ST Page.... 600  Taka</div><div class="list2"><img src="http://masterbd.ml/icon/93.gif" alt="-" /> Google Seach 2nd page..... 400 Taka</div><div class="list2"><img src="http://masterbd.ml/icon/93.gif" alt="-" /> আমাদের কাছ থেকে যারা সাইট করবে তাদের জন্য ফ্রি। ।।</div></div></div></div></div></div></div></div>







<div align="center"><div class="omenu"><div align="center"><div class="phdr" align="center"> আপনি কি Wap Site Design শিখতে চান </div></div><div>
<div align="center"><div align="center"><div class=""><table width="100%"><td width="34%" align="center"> <a><div class="bmenu">Site</div></a></td><td width="34%" align="center"><a><div class="bmenu">Cors End Time</div></a></td><td width="32%" align="center"><a><div class="bmenu">Cors Fe</div></a></td></table></div></div>
</div></div></div></div>
<div><div>
<div align="center"><div align="center"><div class=""><table width="100%"><td width="34%" align="center"> <a><div class="header">Download</div></a></td><td width="34%" align="center"><a><div class="header">15 Day</div></a></td><td width="32%" align="center"><a><div class="header">250TK</div></a></td></table></div></div>
</div></div></div>
<div><div>




<div align="center"><div align="center"><div class=""><table width="100%"><td width="34%" align="center"> <a><div class="header">Toplist</div></a></td><td width="34%" align="center"><a><div class="header">7 Day</div></a></td><td width="32%" align="center"><a><div class="header">150TK</div></a></td></table></div></div>
</div></div></div>
<div><div>
<div align="center"><div align="center"><div class=""><table width="100%"><td width="34%" align="center"> <a><div class="header">Forum</div></a></td><td width="34%" align="center"><a><div class="header">15 Day</div></a></td><td width="32%" align="center"><a><div class="header">200TK</div></a></td></table></div></div>
</div></div></div>
<div><div>






<div align="center"><div align="center"><div class=""><table width="100%"><td width="34%" align="center"> <a><div class="header">All Site</div></a></td><td width="34%" align="center"><a><div class="header">30 Day</div></a></td><td width="32%" align="center"><a><div class="header">550TK</div></a></td></table></div></div>
</div></div></div>
<div><div>
<div align="center"><div align="center"><div class=""><table width="100%"><td width="34%" align="center"> <a><div class="header">PHP</div></a></td><td width="34%" align="center"><a><div class="header">45 Day</div></a></td><td width="32%" align="center"><a><div class="header">1000TK</div></a></td></table></div></div>
</div></div></div>







<div align="center"><div class="menu"><div class="hdr">: : Our Domain Offer Only BD : :</div><div class="header"><table width="100%"><tr><td width="50%"><div class="header"><a>.Com<br/> .Net<br/> .Biz<br/> .Org<br/> .In<br/> .Info<br/> .Mobi<br/> .Us<br/> .Me<br/> .Ca<br/>  .Asia<br/> .Ml<br/> .Cf</a></div></td><td width="50%"><div class="header"><a>520TK<br/> 560TK<br/>  550TK<br/> 580TK<br/> 350TK<br/> 560TK<br/> 820TK<br/> 560TK<br/> 550TK<br/> 570TK<br/> 540TK<br/> 150TK<br/> 110TK</a></div></td></tr></table></div></div>
</div>
<div align="center"><div class="menu"><div class="hdr">Order Your Site By SMS</div><table width="100%"><tr><td width="50%"><div class="header"><a href="sms:01624172388?body=Your Ordar">SMS Us On Airtel</a></div></td><td width="50%"><div class="header"><a href="sms:01757199378?body=Your Ordar">SMS Us On GP</a></div></td></tr></table></div></div>









<div><div class="hdr"><a href="email.php">Email Us And Make Your Order</a></div></div>
<div align="center"><div><div align="center"><div align="center"><div class="birumuda" align="center"><div class="list1"><b></b><b><span style="color: green;">এই Design ছাড়া আপনার পছন্দ অনুযায়ী সাইট বানিয়ে দিব। তাই দেরি না করে আজি আমাদের সাথে যোগাযোগ করুন <br/><a href="http://facebook.com/mehedi.hasan.shuvo7251">MY FB ID</a><br/>Note : DOT.TK DOMAIN FREE. <br/>Call Me : <br/>
<a href="wtai://wp/mc;+8801757199378">+8801757199378</a><br/>
<a href="wtai://wp/mc;+8801624172388">+8801624172388</a></span></b></div></div></div></div></div></div>
<div><div><div align="center"><div align="center"><div class="birumuda" align="center"><div class="list1"><b></b><b>বিঃ দ্রঃ টাকা পেইড করার আগে কোনো প্রকার সাইট এর কাজ করার অনুরোধ করবেন না ।</b></div></div>












</div></div></div></div><div align="center"><div class="menu"><span style="color:blue">Powered By <a href="http://fb.com/mehedi.hasan.shuvo">Shuvo</a></span></div></div></body></html>';
?>