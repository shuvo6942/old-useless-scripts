<?php

/*
 * Two-way Encryption
 */

/*
 * XOR Encryption and Decryption
 */

function xorEncrypt($Input, $Key) {
    $Input = xorHelper($Input, $Key);
    $Input = base64_encode($Input);
    return $Input;
}

function xorDecrypt($Input, $Key) {
    $Input = base64_decode($Input);
    $Input = xorHelper($Input, $Key);
    return $Input;
}

function xorHelper($Input, $Key) {

    $KeyPhraseLength = strlen($Key);

    // Loop trough input string
    for ($i = 0; $i < strlen($Input); $i++) {

    //Get key phrase character position
        $rPos = $i % $KeyPhraseLength;

        //Magic happens here:
        $r = ord($Input[$i]) ^ ord($Key[$rPos]);

        //Replace characters
        $Input[$i] = chr($r);
    }
    return $Input;
}

/*
 * Base64 Encryption and Decryption
 */

function base64Encrypt($Input) {
    return base64_encode($Input);
}

function base64Decrypt($Input) {
    return base64_decode($Input);
}

/*
 * Rot13 Encryption and Decryption
 */

function rot13Encrypt($Input) {
    return str_rot13(base64_encode($Input));
}

function rot13Decrypt($Input) {
    return base64_decode(str_rot13($Input));
}

/*
 * TripleDES Encryption and Decryption
 */

function tripledesEncrypt($Input, $Key) {
    $Input = mcrypt_ecb(MCRYPT_3DES, $Key, base64_encode($Input), MCRYPT_ENCRYPT);
    return $Input;
}

function tripledesDecrypt($Input, $Key) {
    $Input = mcrypt_ecb(MCRYPT_3DES, $Key, $Input, MCRYPT_DECRYPT);
    return base64_decode($Input);
}

/*
 * Modulus Encryption and Decryption
 */

function modEncrypt($Input, $Key) {
    base64_encode($Input);
    for($i=0; $i < strlen($Input); $i++) {
        $char = substr($Input, $i, 1);
        $keychar = substr($Key, ($i % strlen($Key))-1, 1);
        $char = chr(ord($char)+ord($keychar));
        $result .= $char;
    }
    return $result;
}


function modDecrypt($Input, $Key) {
    $str = base64_decode($Input);
    $result = '';
    for($i=0; $i < strlen($Input); $i++) {
        $char = substr($Input, $i, 1);
        $keychar = substr($Key, ($i % strlen($Key))-1, 1);
        $char = chr(ord($char)-ord($keychar));
        $result .= $char;
    }
    return $result;
}


?>
