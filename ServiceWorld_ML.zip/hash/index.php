<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Encryption Demo</title>
    </head>
    <body>

        <?php

        include 'example.php';

        $encrypt = $_GET['encrypt'];
        $key = $_GET['key'];
        ?>

        <h1>Encrypt Me</h1>

        <form action="index.php" method="get">
            <label for="encrypt">String to encrypt/hash: </label>
            <input type="text" id="encrypt" name="encrypt" value="<?php $encrypt ?>">
            <label for="key">Key to encrypt/hash with (Will cause errors if blank!): </label>
            <input type="text" id="key" name="key" maxlength="8" value="<?php $key ?>">
            <input type="submit" value="Encrypt Me">
        </form>


        <?php

        if ($encrypt != '') {
            example($encrypt, $key);
        }
        
        ?>
    </body>
</html>
