EncryptMe

 * 	� Luke Browning

----------------------------------------------------------
About

 * 	Description: 	EncryptMe is a couple php scripts 
					designed to help developers and website
					administrators protect their data. 
					Using the built in functions, you can 
					encrypt and decrypt data using the 
					encryption and decryption algorithms 
					as well as hash your data with over 
					40 different hashing algorithms!
					
 * 	Author: 		Luke Browning
 
 * 	Version: 		1.0
 
 * 	Compatability:	Any server with php

----------------------------------------------------------
Install Guide

 * 	Copy encryptdecrypt.php and hash.php to wherever you 
	want to use them. (public_html maybe?)
	
 *	At the top of the files you want to use the functions,
	add the lines:
	
	include 'hash.php';
	include 'encryptdecrypt.php';
	
 *	Then just call the functions from you want from within
	your code!
 
 * 	All done!
	
----------------------------------------------------------
Support

 * 	Visit www.lukebrowning.com for support