<?php

/*
 * One-way Encryption/Hashing
 */

//crc16
function crc16Encrypt($Input) {
    $return = 0xFFFF;
    for ($i = 0; $i < strlen($Input); $i++) {
        $x = (($return >> 8) ^ ord($Input[$i])) & 0xFF;
        $x ^= $x >> 4;
        $return = (($crc << 8) ^ ($x << 12) ^ ($x << 5) ^ $x) & 0xFFFF;
    }
    return $return;
}

//crc32
function crc32Encrypt($Input) {
    $Input = crc32($Input);
    return $Input;
}

//crc32b
function crc32bEncrypt($Input) {
    if ( @ hash("crcb32", $Input)) {
        return hash("crcb32", $Input);
    } else {
        return 'This hash isn\'t supported on this server!';
    }
}

//sha1
function sha1Encrypt($Input) {
    $Input = sha1($Input);
    return $Input;
}

//md2
function md2Encrypt($Input) {
    if ( @ hash("md2", $Input)) {
        return hash("md2", $Input);
    } else {
        return 'This hash isn\'t supported on this server!';
    }
}

//md4
function md4Encrypt($Input) {
    if ( @ hash("md4", $Input)) {
        return hash("md4", $Input);
    } else {
        return 'This hash isn\'t supported on this server!';
    }
}

//md5
function md5Encrypt($Input) {
    $Input = md5($Input);
    return $Input;
}

//sha224
function sha224Encrypt($Input) {
    if ( @ hash("sha224", $Input)) {
        return hash("sha224", $Input);
    } else {
        return 'This hash isn\'t supported on this server!';
    }

}

//sha256
function sha256Encrypt($Input) {
    if ( @ hash("sha256", $Input)) {
        return hash("sha256", $Input);
    } else {
        return 'This hash isn\'t supported on this server!';
    }
}

//sha384
function sha384Encrypt($Input) {
    if ( @ hash("sha384", $Input)) {
        return hash("sha384", $Input);
    } else {
        return 'This hash isn\'t supported on this server!';
    }
}

//sha512
function sha512Encrypt($Input) {
    if ( @ hash("sha512", $Input)) {
        return hash("sha512", $Input);
    } else {
        return 'This hash isn\'t supported on this server!';
    }
}

//ripemd128
function ripemd128Encrypt($Input) {
    if ( @ hash("ripemd128", $Input)) {
        return hash("ripemd128", $Input);
    } else {
        return 'This hash isn\'t supported on this server!';
    }
}

//ripemd160
function ripemd160Encrypt($Input) {
    if ( @ hash("ripemd160", $Input)) {
        return hash("ripemd160", $Input);
    } else {
        return 'This hash isn\'t supported on this server!';
    }
}

//ripemd256
function ripemd256Encrypt($Input) {
    if ( @ hash("ripemd256", $Input)) {
        return hash("ripemd256", $Input);
    } else {
        return 'This hash isn\'t supported on this server!';
    }
}

//ripemd320
function ripemd320Encrypt($Input) {
    if ( @ hash("ripemd320", $Input)) {
        return hash("ripemd320", $Input);
    } else {
        return 'This hash isn\'t supported on this server!';
    }
}

//whirlpool
function whirlpoolEncrypt($Input) {
    if ( @ hash("whirlpool", $Input)) {
        return hash("whirlpool", $Input);
    } else {
        return 'This hash isn\'t supported on this server!';
    }
}

//tiger128,3
function tiger1283Encrypt($Input) {
    if ( @ hash("tiger128,3", $Input)) {
        return hash("tiger128,3", $Input);
    } else {
        return 'This hash isn\'t supported on this server!';
    }
}

//tiger160,3
function tiger1603Encrypt($Input) {
    if ( @ hash("tiger160,3", $Input)) {
        return hash("tiger160,3", $Input);
    } else {
        return 'This hash isn\'t supported on this server!';
    }
}

//tiger192,3
function tiger1923Encrypt($Input) {
    if ( @ hash("tiger192,3", $Input)) {
        return hash("tiger192,3", $Input);
    } else {
        return 'This hash isn\'t supported on this server!';
    }
}

//tiger128,4
function tiger1284Encrypt($Input) {
    if ( @ hash("tiger128,4", $Input)) {
        return hash("tiger128,4", $Input);
    } else {
        return 'This hash isn\'t supported on this server!';
    }
}

//tiger160,4
function tiger1604Encrypt($Input) {
    if ( @ hash("tiger160,4", $Input)) {
        return hash("tiger160,4", $Input);
    } else {
        return 'This hash isn\'t supported on this server!';
    }
}

//tiger192,4
function tiger1924Encrypt($Input) {
    if ( @ hash("tiger192,4", $Input)) {
        return hash("tiger192,4", $Input);
    } else {
        return 'This hash isn\'t supported on this server!';
    }
}

//snefru
function snefruEncrypt($Input) {
    if ( @ hash("snefru", $Input)) {
        return hash("snefru", $Input);
    } else {
        return 'This hash isn\'t supported on this server!';
    }
}

//snefru256
function snefru256Encrypt($Input) {
    if ( @ hash("snefru256", $Input)) {
        return hash("snefru256", $Input);
    } else {
        return 'This hash isn\'t supported on this server!';
    }
}

//gost
function gostEncrypt($Input) {
    if ( @ hash("gost", $Input)) {
        return hash("gost", $Input);
    } else {
        return 'This hash isn\'t supported on this server!';
    }
}

//adler32
function adler32Encrypt($Input) {
    if ( @ hash("adler32", $Input)) {
        return hash("adler32", $Input);
    } else {
        return 'This hash isn\'t supported on this server!';
    }
}

//salsa10
function salsa10Encrypt($Input) {
    if ( @ hash("salsa10", $Input)) {
        return hash("salsa10", $Input);
    } else {
        return 'This hash isn\'t supported on this server!';
    }
}

//salsa20
function salsa20Encrypt($Input) {
    if ( @ hash("salsa20", $Input)) {
        return hash("salsa20", $Input);
    } else {
        return 'This hash isn\'t supported on this server!';
    }
}

//haval128,3
function haval1283Encrypt($Input) {
    if ( @ hash("haval128,3", $Input)) {
        return hash("haval128,3", $Input);
    } else {
        return 'This hash isn\'t supported on this server!';
    }
}

//haval160,3
function haval1603Encrypt($Input) {
    if ( @ hash("haval160,3", $Input)) {
        return hash("haval160,3", $Input);
    } else {
        return 'This hash isn\'t supported on this server!';
    }
}

//haval192,3
function haval1923Encrypt($Input) {
    if ( @ hash("haval192,3", $Input)) {
        return hash("haval192,3", $Input);
    } else {
        return 'This hash isn\'t supported on this server!';
    }
}

//haval224,3
function haval2243Encrypt($Input) {
    if ( @ hash("haval224,3", $Input)) {
        return hash("haval224,3", $Input);
    } else {
        return 'This hash isn\'t supported on this server!';
    }
}

//haval256,3
function haval2563Encrypt($Input) {
    if ( @ hash("haval256,3", $Input)) {
        return hash("haval256,3", $Input);
    } else {
        return 'This hash isn\'t supported on this server!';
    }
}

//haval128,4
function haval1284Encrypt($Input) {
    if ( @ hash("haval128,4", $Input)) {
        return hash("haval128,4", $Input);
    } else {
        return 'This hash isn\'t supported on this server!';
    }
}

//haval160,4
function haval1604Encrypt($Input) {
    if ( @ hash("haval160,4", $Input)) {
        return hash("haval160,4", $Input);
    } else {
        return 'This hash isn\'t supported on this server!';
    }
}

//haval192,4
function haval1924Encrypt($Input) {
    if ( @ hash("haval192,4", $Input)) {
        return hash("haval192,4", $Input);
    } else {
        return 'This hash isn\'t supported on this server!';
    }
}

//haval224,4
function haval2244Encrypt($Input) {
    if ( @ hash("haval224,4", $Input)) {
        return hash("haval224,4", $Input);
    } else {
        return 'This hash isn\'t supported on this server!';
    }
}

//haval256,4
function haval2564Encrypt($Input) {
    if ( @ hash("haval256,4", $Input)) {
        return hash("haval256,4", $Input);
    } else {
        return 'This hash isn\'t supported on this server!';
    }
}

//haval128,5
function haval1285Encrypt($Input) {
    if ( @ hash("haval128,5", $Input)) {
        return hash("haval128,5", $Input);
    } else {
        return 'This hash isn\'t supported on this server!';
    }
}

//haval160,5
function haval1605Encrypt($Input) {
    if ( @ hash("haval160,5", $Input)) {
        return hash("haval160,5", $Input);
    } else {
        return 'This hash isn\'t supported on this server!';
    }
}

//haval192,5
function haval1925Encrypt($Input) {
    if ( @ hash("haval192,5", $Input)) {
        return hash("haval192,5", $Input);
    } else {
        return 'This hash isn\'t supported on this server!';
    }
}

//haval224,5
function haval2245Encrypt($Input) {
    if ( @ hash("haval224,5", $Input)) {
        return hash("haval224,5", $Input);
    } else {
        return 'This hash isn\'t supported on this server!';
    }
}

//haval256,5
function haval2565Encrypt($Input) {
    if ( @ hash("haval256,5", $Input)) {
        return hash("haval256,5", $Input);
    } else {
        return 'This hash isn\'t supported on this server!';
    }
}

?>
