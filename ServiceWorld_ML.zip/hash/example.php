<?php

function example($encrypt,$mykey) {

include 'encryptdecrypt.php';
include 'hash.php';

//***************** Encryption/Decryption *********************

echo '<h2>Encryption/Decryption</h2>';

$x = xorEncrypt($encrypt, $mykey);
$r = rot13Encrypt($encrypt);
$t = tripledesEncrypt($encrypt, $mykey);
$m = modEncrypt($encrypt, $mykey);
$b = base64Encrypt($encrypt);



echo 'XOR Encrypted: ' . $x . '<br />';
echo 'XOR Decrypted: ' . xorDecrypt($x, $mykey) . '<br /><br />';

echo 'Base64 Encrypted: ' . $b . '<br />';
echo 'Base64 Decrypted: ' . base64Decrypt($b) . '<br /><br />';

echo 'Rot13 Encrypted: ' . $r . '<br />';
echo 'Rot13 Decrypted: ' . rot13Decrypt($r) . '<br /><br />';

echo 'TripleDES Encrypted: ' . $t . '<br />';
echo 'TripleDES Decrypted: ' . tripledesDecrypt($t, $mykey) . '<br /><br />';

echo 'Mod Encrypted: ' . $m . '<br />';
echo 'Mod Decrypted: ' . modDecrypt($m, $mykey) . '<br /><br />';


//***************** HASH *********************

$Input = $encrypt;

echo '<h2>Hash</h2>';

//crc16
echo 'crc16: ' . crc16Encrypt($Input) . '<br />';

//crc32
echo 'crc32: ' . crc32Encrypt($Input) . '<br />';

//crc32b
echo 'crc32b: ' . crc32bEncrypt($Input) . '<br />';

//md2
echo 'md2: ' . md2Encrypt($Input) . '<br />';

//md4
echo 'md4: ' . md4Encrypt($Input) . '<br />';

//md5
echo 'md5: ' . md5Encrypt($Input) . '<br />';

//sha1
echo 'sha1: ' . sha1Encrypt($Input) . '<br />';

//sha224
echo 'sha224: ' . sha224Encrypt($Input) . '<br />';

//sha256
echo 'sha256: ' . sha256Encrypt($Input) . '<br />';

//sha384
echo 'sha384: ' . sha384Encrypt($Input) . '<br />';

//sha512
echo 'sha512: ' . sha512Encrypt($Input) . '<br />';

//ripemd128
echo 'ripemd128: ' . ripemd128Encrypt($Input) . '<br />';

//ripemd160
echo 'ripemd160: ' . ripemd160Encrypt($Input) . '<br />';

//ripemd256
echo 'ripemd256: ' . ripemd256Encrypt($Input) . '<br />';

//ripemd320
echo 'ripemd320: ' . ripemd320Encrypt($Input) . '<br />';

//whirlpool
echo 'whirlpool: ' . whirlpoolEncrypt($Input) . '<br />';

//tiger128,3
echo 'tiger128,3: ' . tiger1283Encrypt($Input) . '<br />';

//tiger160,3
echo 'tiger160,3: ' . tiger1603Encrypt($Input) . '<br />';

//tiger192,3
echo 'tiger192,3: ' . tiger1923Encrypt($Input) . '<br />';

//tiger128,4
echo 'tiger128,4: ' . tiger1284Encrypt($Input) . '<br />';

//tiger160,4
echo 'tiger160,4: ' . tiger1604Encrypt($Input) . '<br />';

//tiger192,4
echo 'tiger192,4: ' . tiger1924Encrypt($Input) . '<br />';

//snefru
echo 'snefru: ' . snefruEncrypt($Input) . '<br />';

//snefru256
echo 'snefru256: ' . snefru256Encrypt($Input) . '<br />';

//gost
echo 'gost: ' . gostEncrypt($Input) . '<br />';

//adler32
echo 'adler32: ' . adler32Encrypt($Input) . '<br />';

//salsa10
echo 'salsa10: ' . salsa10Encrypt($Input) . '<br />';

//salsa20
echo 'salsa20: ' . salsa20Encrypt($Input) . '<br />';

//haval128,3
echo 'haval128,3: ' . haval1283Encrypt($Input) . '<br />';

//haval160,3
echo 'haval160,3: ' . haval1603Encrypt($Input) . '<br />';

//haval192,3
echo 'haval192,3: ' . haval1923Encrypt($Input) . '<br />';

//haval224,3
echo 'haval224,3: ' . haval2243Encrypt($Input) . '<br />';

//haval256,3
echo 'haval256,3: ' . haval2563Encrypt($Input) . '<br />';

//haval128,4
echo 'haval128,4: ' . haval1284Encrypt($Input) . '<br />';

//haval160,4
echo 'haval160,4: ' . haval1604Encrypt($Input) . '<br />';

//haval192,4
echo 'haval192,4: ' . haval1924Encrypt($Input) . '<br />';

//haval224,4
echo 'haval224,4: ' . haval2244Encrypt($Input) . '<br />';

//haval256,4
echo 'haval256,4: ' . haval2564Encrypt($Input) . '<br />';

//haval128,5
echo 'haval128,5: ' . haval1285Encrypt($Input) . '<br />';

//haval160,5
echo 'haval160,5: ' . haval1605Encrypt($Input) . '<br />';

//haval192,5
echo 'haval192,5: ' . haval1925Encrypt($Input) . '<br />';

//haval224,5
echo 'haval224,5: ' . haval2245Encrypt($Input) . '<br />';

//haval256,5
echo 'haval256,5: ' . haval2565Encrypt($Input) . '<br />';

}

?>
