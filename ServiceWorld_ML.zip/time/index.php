<?php echo '<html><body>';
function fix_date($format,$timezone){
// Sohel Rana
// $timezone is the difference between your local time and unix time (GMT).
$tm=$timezone * 3600;
$tz= gmdate("U")+$tm;
$get= gmdate($format,$tz);
return $get;
}
echo '<div class="nfooter"><center>';
echo fix_date("h:i:s a - l, jS F Y","6");
echo '</center></div></body></html>';
?>