<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Text Converter</title><link rel="STYLESHEET" type="text/css" href="http://wtools.gq/styles.css"/><link rel="shortcut icon" href="http://phptunes.com/favicon.ico"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/><style type="text/css">
body { background: #32B6CE;
color: ;
}
a { color: ;
}
</style>
<head><body>
<div><div><div class="mainblok"><div class="nfooter">Stylish Text Generator</div><div class="rmenu" align="center"><textarea id="a">Enter your text here...</textarea><br/><br/>
<button onclick="generate()"> Convert Text</button>
<div id="tad_1" style="padding-right: 2px"></div>

<textarea id="b1"></textarea><br/>
<textarea id="b2"></textarea><br/>
<textarea id="b3"></textarea><br/>
<textarea id="b4"></textarea><br/>
<textarea id="b5"></textarea><br/>
<textarea id="b6"></textarea><br/>
<textarea id="b7"></textarea><br/>



<textarea id="b8"></textarea><br/>
<textarea id="b9"></textarea><br/>
<textarea id="b10"></textarea><br/>
<textarea id="b29"></textarea><br/>
<textarea id="b30"></textarea><br/>
<textarea id="b11"></textarea><br/>
<textarea id="b12"></textarea><br/>
<textarea id="b13"></textarea><br/>
<textarea id="b14"></textarea><br/>
<textarea id="b15"></textarea><br/>
<textarea id="b16"></textarea><br/>
<textarea id="b17"></textarea><br/>
<textarea id="b18"></textarea><br/>
<textarea id="b19"></textarea><br/>
<textarea id="b20"></textarea><br/>
<textarea id="b21"></textarea><br/>
<textarea id="b22"></textarea><br/>
<textarea id="b23"></textarea><br/>
<textarea id="b24"></textarea><br/>
<textarea id="b25"></textarea><br/>
<textarea id="b26"></textarea><br/>
<textarea id="b27"></textarea><br/>
<textarea id="b28"></textarea><br/>
<script type="text/javascript">
function araf(x)
{
var1='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ.?!<>';
p='';
q='';
a=document.getElementById('a').value;
n=0;
while(n<a.length)
{
o=0;
s=0;
while (s!=1)
{
if(a.charAt(n)!=var1.charAt(o))
{o++;
if(o==x.length)
{
q=a.charAt(n);
s=1;}}
else
{
q=x.charAt(o);
s=1;}
;
}
p=p+q;
n++;
}
return p;
}
function generate()
{
document.getElementById('b1').value=araf('αв¢đєƒgнιjкĻмησρqяѕтυνωχуzαв¢đєƒgнιjкĻмησρqяѕтυνωχуz.?!«»');
document.getElementById('b2').value=araf('αвcdєfghíjklmnσpqrstuvwхчzαвcdєfghíjklmnσpqrstuvwхчz.?!«»');
document.getElementById('b3').value=araf('ΛBCDΣFGΉIJΚLMПӨPQЯSTЦVЩXΥZΛBCDΣFGΉIJΚLMПӨPQЯSTЦVЩXΥZ๏?!«»');
document.getElementById('b4').value=araf('ค๒ς๔єŦﻮђเןкl๓ภ๏קợгรtยשฬץאzค๒ς๔єŦﻮђเןкl๓ภ๏קợгรtยשฬץאz.؟!«»');
document.getElementById('b5').value=araf('aвcdeғgнιjĸlмnopqrѕтυvwхyzaвcdeғgнιjĸlмnopqrѕтυvwхyz.?!«»');












document.getElementById('b6').value=araf('ábćdéfghíjklmńőpqŕśtúvwxýźábćdéfghíjklmńőpqŕśtúvwxýź.?!«»');
document.getElementById('b7').value=araf('äbćdëfghïjklmnöpqrstüvwxÿżäbćdëfghïjklmnöpqrstüvwxÿż.?!«»');
document.getElementById('b8').value=araf('ⓐⓑⓒⓓⓔⓕⓖⓗⓘⓙⓚⓛⓜⓝⓞⓟⓠⓡⓢⓣⓤⓥⓦⓧⓨⓩⓐⓑⓒⓓⓔⓕⓖⓗⓘⓙⓚⓛⓜⓝⓞⓟⓠⓡⓢⓣⓤⓥⓦⓧⓨⓩ.؟!«»');
document.getElementById('b9').value=araf('ÁßČĎEŦĞHĨJĶĹМŃŐРQŔŚŤÚVWЖYŹÁßČĎEŦĞHĨJĶĹМŃŐРQŔŚŤÚVWЖYŹ.؟!«»');
document.getElementById('b10').value=araf('ɐqɔpǝɟƃɥıɾʞlɯuodbɹsʇnʌʍxʎzɐqɔpǝɟƃɥıɾʞlɯuodbɹsʇnʌʍxʎz˙¿¡«»');
document.getElementById('b11').value=araf('ﾑ乃cd乇ｷgんﾉﾌズﾚﾶ刀oｱq尺丂ｲu√wﾒﾘ乙ﾑ乃cd乇ｷgんﾉﾌズﾚﾶ刀oｱq尺丂ｲu√wﾒﾘ乙.?!«»');
document.getElementById('b12').value=araf('48CD3E9H1JKLMN0PQR57UVWXY248CD3E9H1JKLMN0PQR57UVWXY2.?!«»');










document.getElementById('b13').value=araf('двÇδзfбнijкlмиøрqяsтцvщxчzдвÇδзfбнijкlмиøрqяsтцvщxчz.?!«»');
document.getElementById('b14').value=araf('人日ㄈㄅ王于ㄢ㈠ㄧ了长心从ㄇ口ㄗ可尺与ㄒㄩ以山ㄨㄚ之人日ㄈㄅ王于ㄢ㈠ㄧ了长心从ㄇ口ㄗ可尺与ㄒㄩ以山ㄨㄚ之.?!«»');
document.getElementById('b15').value=araf('ḀḃḉḊḕḟḠḧḭjḲḶṁṆṏṖqṙṠṮṳṼẇẌẏẒḀḃḉḊḕḟḠḧḭjḲḶṁṆṏṖqṙṠṮṳṼẇẌẏẒ.?!«»');
document.getElementById('b16').value=araf('ᗩᗷᑕᗪEᖴGᕼIᒍKᒪᗰᑎOᑭᑫᖇᔕTᑌᐯᗯ᙭YᘔᗩᗷᑕᗪEᖴGᕼIᒍKᒪᗰᑎOᑭᑫᖇᔕTᑌᐯᗯ᙭Yᘔ.?!«»');
document.getElementById('b17').value=araf('₳฿₵ĐɆ₣₲ⱧłJ₭Ⱡ₥₦Ø₱QⱤ₴₮ɄV₩ӾɎⱫ₳฿₵ĐɆ₣₲ⱧłJ₭Ⱡ₥₦Ø₱QⱤ₴₮ɄV₩ӾɎⱫ.?!«»');
document.getElementById('b18').value=araf('ᏗᏰፈᎴᏋᎦᎶᏂᎥᏠᏦᏝᎷᏁᎧᎮᎤᏒᏕᏖᏬᏉᏇጀᎩፚᏗᏰፈᎴᏋᎦᎶᏂᎥᏠᏦᏝᎷᏁᎧᎮᎤᏒᏕᏖᏬᏉᏇጀᎩፚ.?!«»');
document.getElementById('b19').value=araf('ǟɮƈɖɛʄɢɦɨʝӄʟʍռօքզʀֆȶʊʋաӼʏʐǟɮƈɖɛʄɢɦɨʝӄʟʍռօքզʀֆȶʊʋաӼʏʐ.?!«»');
document.getElementById('b20').value=araf('ａｂｃｄｅｆｇｈｉｊｋｌｍｎｏｐｑｒｓｔｕｖｗｘｙｚａｂｃｄｅｆｇｈｉｊｋｌｍｎｏｐｑｒｓｔｕｖｗｘｙｚ.?!«»');













document.getElementById('b21').value=araf('ąβȼď€ƒǥhɨjЌℓʍɲ๏ρǭя$ţµ˅ώж¥ƶąβȼď€ƒǥhɨjЌℓʍɲ๏ρǭя$ţµ˅ώж¥ƶ.?!«»');
document.getElementById('b22').value=araf('åβçď£ƒğȟȋjķȽɱñ¤קǭȑ§țɥ√Ψ×ÿžåβçď£ƒğȟȋjķȽɱñ¤קǭȑ§țɥ√Ψ×ÿž.?!«»');
document.getElementById('b23').value=araf('ąþȼȡƹƒǥɦɨǰƙŁʍɲǿρǭřȿƮµ˅ώж¥ƶąþȼȡƹƒǥɦɨǰƙŁʍɲǿρǭřȿƮµ˅ώж¥ƶ.?!«»');
document.getElementById('b24').value=araf('άвςȡέғģħίјķĻмήόρqŕşţùνώxчžάвςȡέғģħίјķĻмήόρqŕşţùνώxчž.?!«»');
document.getElementById('b25').value=araf('ÃβČĎẸƑĞĤĮĴЌĹϻŇỖƤǪŘŜŤǗϋŴЖЎŻÃβČĎẸƑĞĤĮĴЌĹϻŇỖƤǪŘŜŤǗϋŴЖЎŻ.?!«»');
document.getElementById('b26').value=araf('მჩეძპfცhἶქκlოῆõρგΓჰནυὗwჯყɀმჩეძპfცhἶქκlოῆõρგΓჰནυὗwჯყɀ.?!«»');
document.getElementById('b27').value=araf('ÄBĊĐË₣ĠȞÏĴĶĻMŅÖPǬŖŚȚŮVŴXŸŹÄBĊĐË₣ĠȞÏĴĶĻMŅÖPǬŖŚȚŮVŴXŸŹ.?!«»');
document.getElementById('b28').value=araf('αвc∂εғgнιנкℓмησρqяsтυvωxүzαвc∂εғgнιנкℓмησρqяsтυvωxүz.?!«»');
document.getElementById('b29').value=araf('ąβȼď€ƒǥhɨjЌℓʍɲ๏ρǭя$ţµ˅ώж¥ƶÁßČĎEŦĞHĨJĶĹМŃŐРQŔŚŤÚVWЖYŹ.؟!«»');
document.getElementById('b30').value=araf('ค๒ς๔єŦﻮђเןкl๓ภ๏קợгรtยשฬץאzÁßČĎEŦĞHĨJĶĹМŃŐРQŔŚŤÚVWЖYŹ.؟!«»');
}
</script>
</div></div></div>
</div>
<div align="center"><img src="http://www.bestcounters.com/services/imagedigits/counter.php?aut=90101b06f8be21c20683a6ce0526145553155a36f070f34874096cc780ad5fb2c91761e002860284c03374526e9bdc7b3b250d7527" title="Counter Powered by Bestcounters.com" border="0" /></div>
</body></html>