<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<meta http-equiv="content-type" content="application/xhtml+xml; charset=utf-8"/>
<meta http-equiv="Content-Style-Type" content="text/css" />
<link rel="stylesheet" href="http://pankajbd24.com/theme/default/style.css" type="text/css" />
<link rel="shortcut icon" href="http://pankajbd24.com/favicon.ico" />
<title>Color Code</title>
</head><body>
<a href="http://wap4dollar.com/ad/serve.php?id=zvc1jd710h">Hot Downloads of 2015 !</a><br/><a href="http://wap4dollar.com/ad/nonadult/serve.php?id=zvc1jd710h">Best Java, Android Games, Apps</a><br/><script type="text/javascript" src="http://wap4dollar.com/ad/codex/?id=zvc1jd710h"></script><br/><script type="text/javascript" src="http://wap4dollar.com/ad/code/?id=zvc1jd710h"><br/></script><script type="text/javascript" src="http://wap4dollar.com/ad/pops/?id=zvc1jd710h"></script>


<html><div class="mainblok"><div class="phdr"><center>Color Code</center></div><div class="menu">
<p align="left" style="background-color:aqua">
Aqua (#00FFFF)
</p><p align="left" style="background-color:#7fffd4">
Aquamarine (#7FFFD4)
</p>
<p style="background-color:black"><font color="white">Black (#00000)</font></p>
</p><p align="left" style="background-color:blue">
Blue (#0000ff)
</p><p align="left" style="background-color:cadetblue">
Cadetblue (#5F9EA0)
</p>
<p style="background-color:cyan">Cyan (#00FFFF)</p>
<p style="background-color:#008686">Darkcyan (#008686)</p>







<p style="background-color:#688606">Darkgoldenrod (#688606)</p>
<p style="background-color:#a9a9a9">Darkgray (#A9A9A9)</p>
<p style="background-color:#006400">Darkgreen (#006400)</p>
<p style="background-color:#606766">Darkkhaki (#606766)</p>
<p style="background-color:#860086">Darkmagenta (#860086)</p>
<p style="background-color:#55662f">Darkolivegreen (#55662F)</p>
<p style="background-color:#ff8c00">Darkorange (#FF8C00)</p>
<p style="background-color:#9932cc">Darkorchid (#9932CC)</p>
<p style="background-color:#680000">Darkred (#860000)</p>
<p style="background-color:#e9967a">Darksalmon (#E9967A)</p>
<p style="background-color:#483086">Darkslateblue (#483086)</p>
<p style="background-color:#2f4f4f">Darkslategray (#2F4F4F)</p>
<p style="background-color:#00ced1">Darkturquoise (#00CED1)</p>
<p style="background-color:#940003">Darkviolet (#940003)</p>
<p style="background-color:#ff1493">Deeppink (#FF1493)</p>











<p style="background-color:#00bfff">Deepskyblue (#00BFFF)</p>
<p style="background-color:#696969">Dimgray (#696969)</p>
<p style="background-color:#1e90ff">Dodgerblue (#1E90FF)</p>
<p style="background-color:#622222">Firebrick (#622222)</p>
<p style="background-color:#fffaf0">Floralwhite (#FFFAF0)</p>
<p style="background-color:#228622">Forestgreen (#228622)</p>
<p style="background-color:#dcdcdc">Gainsboro (#DCDCDC)</p>
<p style="background-color:gold">Gold (#FFD700)</p>
<p style="background-color:#daa520">Goldenrod (#DAA520)</p>
<p style="background-color:green">Green (#008000)</p>
<p style="background-color:#adff2f">Greenyellow (#ADFF2F)</p>
<p style="background-color:hotpink">Hotpink (#FF69B4)</p>
<p style="background-color:#cd5c5c">Indianred (#CD5C5C)</p>
<p style="background-color:indigo">Indigo (#460082)</p>
<p style="background-color:khaki">Khaki (#F0E68C)</p>














<p style="background-color:#e6e6fa">Lavender (#E6E6FA)</p>
<p style="background-color:#fff0f5">Lavenderblush (#FFF0F5)</p>
<p style="background-color:#7cfc00">Lawngreen (#7CFC00)</p>
<p style="background-color:#add8e6">Lightblue (#ADD8E6)</p>
<p style="background-color:#f08080">Lightcoral (#F08080)</p>
<p style="background-color:#e0ffff">Lightcyan (#E0FFFF)</p>
<p style="background-color:#90ee90">Lightgreen (#90EE90)</p>
<p style="background-color:#d3d3d3">Lightgrey (#D3D3D3)</p>
<p style="background-color:#ffb6c1">Lightpink (#FFB6C1)</p>
<p style="background-color:#ffa07a">Lightsalmon (#FFA07A)</p>
<p style="background-color:#20b2aa">Lightseagreen (#20B2AA)</p>
<p style="background-color:#87cefa">Lightskyblue (#87CEFA)</p>
<p style="background-color:#778899">Lightslategray (#778899)</p>
<p style="background-color:#b0c4de">Lightsteelblue (#B0C4DE)</p>
<p style="background-color:lime">Lime (#00ff00)</p>

















<p style="background-color:#32cd32">Limegreen (#32CD32)</p>
<p style="background-color:#faf0e6">Linen (#FAF0E6)</p>
<p style="background-color:magenta">Magenta (#FF00FF)</p>
<p style="background-color:#ba55d3">Mediumorchid (#BA55D3)</p>
<p style="background-color:#9370db">Mediumpurple (#9370DB)</p>
<p style="background-color:#3cb371">Mediumseagreen (#3CB371)</p>
<p style="background-color:#7b68ee">Mediumslateblue (#7B68EE)</p>
<p style="background-color:maroon">Maroon (#800000)</p>
<p style="background-color:#4801cc">Mediumturquoise (#4801CC)</p>
<p style="background-color:#071585">Mediumvioletred (#071585)</p>
<p style="background-color:#191970">Midnightblue (#191970)</p>
<p style="background-color:#f5fffa">Mintcream (#F5FFFA)</p>
<p style="background-color:#ffe4e1">Mistyrose (#FFE4E1)</p>
<p style="background-color:#ffe4b5">Moccasin (#FFE4B5)</p>
<p style="background-color:#ffdead">Navajowhite (#FFDEAD)</p>











<p style="background-color:navy">Navy (#000080)</p>
<p style="background-color:#fdf5e6">Old lace (#FDF5E6)</p>
<p style="background-color:olive">Olive (#808000)</p>
<p style="background-color:#6b8e23">Olivedrab (#6B8E23)</p>
<p style="background-color:orange">Orange (#FFA500)</p>
<p style="background-color:#ff4500">Orangered (#FF4500)</p>
<p style="background-color:orchid">Orchid (#DA70D6)</p>
<p style="background-color:#eee8aa">Palegoldenrod (#EEE8AA)</p>
<p style="background-color:#98f698">Palegreen (#98F698)</p>
<p style="background-color:#afeeee">Paleturquoise (#AFEEEE)</p>
<p style="background-color:#db7093">Palevioletred (#DB7093)</p>
<p style="background-color:#ffdab9">Peachpuff (#FFDAB9)</p>
<p style="background-color:peru">Peru (#CD853F)</p>
<p style="background-color:pink">Pink (#FFCOC8)</p>
<p style="background-color:plum">Plum (#DDA0DD)</p>












<p style="background-color:purple">Purple (#800080)</p>
<p style="background-color:#b0e0e6">Powderblue (#B0E0E6)</p>
<p style="background-color:red">Red (#ff0000)</p>
<p style="background-color:#bc8f8f">Rosybrown (#BC8F8F)</p>
<p style="background-color:#4169e1">Royalblue (#4169E1)</p>
<p style="background-color:#864513">Saddlebrown (#864513)</p>
<p style="background-color:salmon">Salmon (#FA8072)</p>
<p style="background-color:#f4a460">Sandybrown (#F4A460)</p>
<p style="background-color:#2e8b57">Seagreen (#2E8B57)</p>
<p style="background-color:sienna">Sienna (#A0522D)</p>
<p style="background-color:#ffc8ff">Silver (#ffc8ff)</p>
<p style="background-color:skyblue">Skyblue (#87CEEB)</p>
<p style="background-color:#6a5acd">Slateblue (#6A5ACD)</p>
<p style="background-color:#708090">Slategray (#708090)</p>
<p style="background-color:#00ff7f">Springgreen (#00FF7F)</p>















<p style="background-color:#468264">Steelblue (#468264)</p>
<p style="background-color:tan">Tan (#D2B48C)</p>
<p style="background-color:teal">teal (#008080)</p>
<p style="background-color:thistle">Thistle (#D8BFD8)</p>
<p style="background-color:tomato">Tomato (#FF6347)</p>
<p style="background-color:#40e0d0">Turquoise (#40E0D0)</p>
<p style="background-color:violet">Violet (#EE82EE)</p>
<p style="background-color:wheat">Wheat (#F5DEB3)</p>
<p style="background-color:white">White (#ffffff)</p>
<p style="background-color:#9acd32">Yellowgreen (#9ACD32)</p>
<p style="background-color:yellow">Yellow (#ffff00)</p>
</div></div>

<div class="gmenu"><a href='javascript:history.back(2)'>Back</a></div></html>
</body></html>