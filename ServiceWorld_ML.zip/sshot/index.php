<?php
echo '<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Screen Shot Taker</title><link rel="STYLESHEET" type="text/css" href="http://wtools.gq/styles.css"/><link rel="shortcut icon" href="http://phptunes.com/favicon.ico"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/><style type="text/css">
body { background: ;
color: ;
}
a { color: ;
}
</style>
</head><body>';

$getu = $_POST['get-url'];
$geth = $_POST['get-h'];
$getw = $_POST['get-w'];
if(isset($_POST['submit'])){


echo '<div class="rmenu" align="center">Screenshot of <a href="http://'.$getu.'">http://'.$getu.'</a> has been successfully taken.<br/><a href="http://mini.s-shot.ru/'.$getw.'x'.$geth.'/240/png/?'.$getu.'">View/Save</a></div>';
}
echo '<div class="wcode"><form method="post" action=""><b>Site URL:</b> <font color="red">http://</font><input type="text" name="get-url" value="'.$getu.'" size="6"/><br/><b>Screen Size:</b><input name="get-w" value="240" type="text" size="4"/>x<input type="text" name="get-h" value="320" size="4"/><div align="center"><input type="submit" name="submit" value="Generate"/></div></form></div></div></body></html>';
?>