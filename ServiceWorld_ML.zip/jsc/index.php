<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Java Script Checker</title><link rel="STYLESHEET" type="text/css" href="http://wtools.gq/styles.css"/><link rel="shortcut icon" href="http://phptunes.com/favicon.ico"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/><style type="text/css">
body { background: ;
color: ;
}
a { color: ;
}
</style>
</head><body>




<div style="text-align: center"><div class="de2ny">JAVASCRIPT CHECKER</div><form
action="http://www.w3schools.com/js/tryit_view.asp" method="post" target="view" onsubmit="test(script)"><br>Your Script :<br><textarea name="code"
width="100%" height="100px"
wrap="logical"><script language="JavaScript" src="http://wap-master.xtgem.com/js/error.js"></script></textarea><br><input name="submit" type="submit" value="VIEW"><br>
Preview :<br><iframe
width="100%" height="100%" name="view" src="http://www.w3schools.com/js/tryit_view.asp"><br /></iframe><br></form></div><br><br>
</body></html>