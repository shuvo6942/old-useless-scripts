<?php
header('Content-Type: text/html; charset=utf-8');
echo '<?xml version="1.0"?>
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Source code viewer</title>
<meta http-equiv="Pragma" content="no-cache" /><link rel="stylesheet" type="text/css" href="http://tunes420.wapka.mobi/styles.css" />
</head>
<body>';
if(isset($_GET['url']) && substr($_GET['url'],0,7) == 'http://')
{
$source = file_get_contents($_GET['url']);
echo '<div class="mainblok"><div class="mainblok"><div class="rmenu">Source code<div><hr/>'.htmlspecialchars($source).'</div><hr/>Source code<div><hr/><textarea>'.htmlspecialchars($source).'</textarea></div></div></div></div><hr/>';
}
echo '<form action="'.$_SERVER['PHP SELF'].'" method="get">
<div class="mainblok"><div class="mainblok"><div class="rmenu">Source URL:
<input type="text" name="url" value="http://" />
<input type="submit" value="Show source" class="nfooter" />
</div></div></div></form></body>
</html>';
?>
