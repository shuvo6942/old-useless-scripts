<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Live TV</title><link rel="STYLESHEET" type="text/css" href="http://wtools.gq/styles.css"/><link rel="shortcut icon" href="http://phptunes.com/favicon.ico"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/><style type="text/css">
body { background: ;
color: ;
}
a { color: ;
}
</style>
</head><body>




<div><div></div>
<div align="center">
<div><a href="rtmp://59.152.97.18/live/ch2" > <table width="100%" border="0"><tr><td width="100%" bgcolor="#3b5988" align="center"><font color="white"> <b>Live FIFA World Cup 2014</b></font></td></tr></table> <img src="http://footballcenter.in/wp-content/uploads/2014/01/MFC_SonySix_Fifa.jpg" alt="" border="0" height="120" width="160" /> <img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="2" /></a></div>
<div><b></b></div></div>
<div><div style="margin-top: 3px; margin-bottom: 0px; " class="zone" align="center">Live TV Page</div>
<div><div><b><a href="rtsp://202.159.213.30:554/ddnational_mobC.sdp" ><img src="http://wapkaimage.com/100084/100084097_a1addc923b.jpg" alt="" border="0" /> <img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /> </a></b></div>











<div><b></b></div>
<div><b><a href="http://motv.nexg.tv/LiveTV/PlayOption.aspx?VIRUWAP=&amp;MenuName=Star%20Plus%20VIRUWAP&amp;qstrChannelID=CH356" ><img src="http://wapkaimage.com/1506/1506755_3681ce7357.jpg" alt="" border="0" /> <img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /></a></b></div>

<div><b><a href="http://wapdollar.in/serve.php?id=va6j8pwj52" ><img src="http://f16.wapkafiles.com/download/0/c/3/1019474_0c3c30e314d02a09652d90a0.jpg/84fad7c0b5c06e88ab94/%26%20pictures" width="120" height="90" /> <img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /> </a></b></div>
<div><b></b></div>














<div><a href="rtsp://202.159.213.30:554/zeetv_mobC.sdp?tokan=923152409036" ><img src="http://wapkaimage.com/100024/100024136_9ae0f75c86.jpg" alt="" border="0" /><img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /></a></div>
<div><b><a href="rtsp://202.159.213.30:554/colors_mobC.sdp?token=923152409036" ><img src="http://wapkaimage.com/1418/1418826_8236bfb2b1.jpg" alt="" border="0" /> <img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /></a></b></div>
<div><a href="http://motv.nexg.tv/LiveTV/PlayOption.aspx?VIRUWAP=&amp;MenuName=Life%20Ok%20VIRUWAP&amp;qstrChannelID=CH357" ><img src="http://wapkaimage.com/4363/4363612_8b57537ed3.jpeg" alt="" border="0" /> <img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /></a></div>













<div><b><a href="rtsp://202.159.213.30:554/sony_mobC.sdp?tokan=923152409036" ><img src="http://wapkaimage.com/1418/1418545_e63744dfc7.jpg" alt="" border="0" /> <img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /></a></b></div>
<div><a href="rtsp://202.159.213.30:554/sab_mobC.sdp?tokan=923152409036" ><img src="http://wapkaimage.com/1418/1418515_9b6144a298.jpg" alt="" border="0" /><img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /></a></div>
<div><b><a href="rtsp://202.159.213.30:554/zeeanmol_mobl_mtnl.sdp?token=923152409036" ><img src="http://wapkaimage.com/100084/100084170_caa4131b5b.jpg" alt="" border="0" /> <img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /></a></b></div>











<div><a href="http://motv.nexg.tv/LiveTV/PlayOption.aspx?VIRUWAP=&amp;MenuName=Star%20Utsav%20VIRUWAP&amp;qstrChannelID=CH358" ><img src="http://wapkaimage.com/3578/3578978_8e8d2c4892.jpg" alt="" border="0" /><img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /></a></div>
<div><b><a href="rtsp://202.159.213.30:554/utvbindass_mobC.sdp?tokan923152409036" ><img src="http://wapkaimage.com/1418/1418511_37d8213e10.jpg" alt="" border="0" /> <img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /></a></b></div>
<div><b><a href="rtsp://202.159.213.30:554/utvstars_mobC.sdp?tokan=923152409036" ><img src="http://wapkaimage.com/3133/3133280_feacdd8d2e.jpg" alt="" border="0" /> <img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /></a></b></div>
<div><b></b></div>












<div><b><a href="rtsp://202.159.213.30:554/utvmovies_mobC.sdp?923152409036" ><img src="http://wapkaimage.com/1418/1418547_c753c3db6f.jpg" alt="" border="0" /> <img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /></a></b></div>
<div><b><a href="rtsp://202.159.213.30:554/zeecinema_mobC.sdp?token=923152409036" ><img src="http://wapkaimage.com/100023/100023701_58e275e732.jpg" alt="" border="0" /> <img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /></a></b></div>
<div><a href="rtsp://202.159.213.30:554/zeeclassic_mobC.sdp?token=923152409036" ><img src="http://wapkaimage.com/100023/100023700_d3de282f3a.jpg" alt="" border="0" /> <img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /></a></div>











<div><a href="rtsp://202.159.213.30:554/b4umovies_mobC.sdp?tokan=923152409036" ><img src="http://wapkaimage.com/3154/3154912_a4a39a4fa8.jpeg" alt="" border="0" /> <img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /></a></div>
<div><b><a href="rtsp://202.159.213.30:554/history_mobC.sdp?tokan=923152409036" ><img src="http://wapkaimage.com/100008/100008459_9d0d659d4e.jpg" alt="" border="0" /> <img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /></a></b></div>
<div><b><a href="rtsp://202.159.213.30:554/cartoonnetwork_mobC.sdp?tokan=923152409036" ><img src="http://wapkaimage.com/1418/1418512_c6c5d70a7a.jpg" alt="" border="0" /> <img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /></a></b></div>














<div><b><a href="http://motv.nexg.tv/LiveTV/PlayOption.aspx?VIRUWAP=&amp;MenuName=Zoomviruwap&amp;qstrChannelID=CH409" ><img src="http://wapkaimage.com/1525/1525210_dc1aa1401b.jpg" alt="" border="0" /> <img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /></a></b></div>
<div><a href="http://motv.nexg.tv/LiveTV/PlayOption.aspx?viruwap=&amp;MenuName=Sony%20Mix%20viruwap&amp;qstrChannelID=CH399" ><img src="http://wapkaimage.com/4363/4363338_9ed25bea46.png" alt="" border="0" /> <img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /></a></div>
<div><b><a href="rtsp://202.159.213.30:554/mtv_mobC.sdp?token=923152409036" ><img src="http://wapkaimage.com/3469/3469277_99ecda903f.jpg" alt="" border="0" /> <img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /></a></b></div>









<div><a href="http://motv.nexg.tv/LiveTV/PlayOption.aspx?VIRUWAP=&amp;MenuName=Channel%20V%20VIRUWAP&amp;qstrChannelID=CH364" ><img src="http://wapkaimage.com/1418/1418434_614c98f90d.jpg" alt="" border="0" /> <img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /></a></div>
<div><u><a href="rtsp://46.249.213.87/broadcast/zing-qcif.3gp?" ><img src="http://wapkaimage.com/1946/1946794_ea627d1d12.png" alt="" border="0" /> <img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /></a></u></div>
<div><b><a href="rtsp://46.249.213.87/broadcast/b4u-qcif.3gp?" ><img src="http://wapkaimage.com/1418/1418420_b8229138a6.jpg" alt="" border="0" /> <img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /></a></b></div>










<div><u><a href="rtsp://217.146.95.166:554/live/ch32yqcif.3gp" ><img src="http://wapkaimage.com/1552/1552005_4f684f1f69.jpg" alt="" border="0" /> <img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /></a></u></div>
<div><u><a href="rtsp://46.249.213.87/broadcast/bollywoodgossip-qcif.3gp?" ><img src="http://wapkaimage.com/4732/4732849_6b82f99f14.jpg" alt="" border="0" /> <img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /></a></u></div>
<div><a href="rtsp://202.159.213.30:554/tencricket_mobC.sdp?tokan=923152409036" ><img src="http://wapkaimage.com/4618/4618636_5c3e1e4f4b.png" alt="" border="0" /> <img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /> </a></div>













<div><a href="rtsp://202.159.213.30:554/tensports_mobC.sdp?tokan=923152409036" ><img src="http://wapkaimage.com/3436/3436254_ea6b942b64.jpg" alt="" border="0" /> <img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /> </a></div>
<div><a href="rtsp://202.159.213.30:554/tenaction_mobC.sdp?tokan=923152409036" ><img src="http://wapkaimage.com/100023/100023680_4fc6883a13.jpg" alt="" border="0" /> <img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /></a></div>
<div align="center"></div>
<div><b></b></div>
<div><a href="rtsp://202.159.213.30:554/aajtak_mobC.sdp?token=923152409036" ><img src="http://wapkaimage.com/1418/1418649_2a0cd7a0a9.jpg" alt="" border="0" /> <img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /></a></div>











<div><a href="rtsp://202.159.213.30:554/starnews_mobC.sdp?tokan=923152409036" ><img src="http://wapkaimage.com/5109/5109506_79beb477d7.jpeg" alt="" border="0" /> <img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /></a></div>
<div><a href="rtsp://202.159.213.30:554/ibn7lokmat_mobC.sdp?tokan=923152409036" ><img src="http://wapkaimage.com/1418/1418710_72ed4a6946.jpg" alt="" border="0" /> <img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /></a></div>
<div><a href="rtsp://202.159.213.30:554/starmajha_mobC.sdp?tokan=923152409036" ><img src="http://wapkaimage.com/5109/5109504_43af140c62.jpeg" alt="" border="0" /> <img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /></a></div>












<div><a href="rtsp://202.159.213.30:554/zeenews_mobC.sdp?token=923152409036" ><img src="http://wapkaimage.com/100023/100023699_bfd74959f3.jpg" alt="" border="0" /> <img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /></a></div>
<div><b><a href="rtsp://202.159.213.30:554/cnbcawaaz_mobC.sdp?token=923152409036" ><img src="http://wapkaimage.com/1422/1422773_8c39ae553e.jpg" alt="" border="0" /> <img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /></a></b></div>
<div><u><a href="rtsp://46.249.213.93/broadcast/indiatv-qcif.3gp?" ><img src="http://wapkaimage.com/1418/1418692_7f0cc03a88.jpg" alt="" border="0" /> <img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /></a></u></div>












<div><a href="rtsp://202.159.213.30:554/zeebusiness_mobC.sdp?token=923152409036" > <img src="http://wapkaimage.com/100023/100023703_8411ca3663.jpg" alt="" border="0" /> <img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /></a></div>
<div><u><a href="rtsp://217.146.95.166:554/live/ch33yqcif.3gp" ><img src="http://wapkaimage.com/1418/1418414_5d3887eaef.jpg" alt="" border="0" /> <img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /></a></u></div>
<div><u><a href="rtsp://217.146.95.166:554/live/ch72yqcif.3gp" ><img src="http://wapkaimage.com/4732/4732860_4f717ea43b.jpg" alt="" border="0" /> <img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /></a></u></div>
<div><b></b></div>

<div align="center"></div>












<div><a href="rtsp://46.249.213.87/broadcast/bollywoodaction2-qcif.3gp?vodawapi.tk" ><img src="http://wapkaimage.com/100012/100012453_7ab07bbb35.jpg" alt="" border="0" /> <img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /></a></div>
<div><u><a href="rtsp://217.146.95.166:554/live/ch49yqcif.3gp" ><img src="http://wapkaimage.com/3013/3013745_da7b6e9792.jpg" alt="" border="0" /> <img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /></a></u></div>
<div><u><a href="rtsp://46.249.213.87/broadcast/fashiontv-qcif.3gp?" ><img src="http://wapkaimage.com/1513/1513339_c24a804708.jpg" alt="" border="0" /> <img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /></a></u></div>
<div><b></b></div>














<div align="center"></div>
<div><b></b></div>
<div><a href="rtsp://202.159.213.30:554/musicindia_mobC.sdp?tokan=923152409036" ><img src="http://wapkaimage.com/3154/3154913_b1b728740b.jpeg" alt="" border="0" /> <img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /></a></div>
<div><a href="http://motv.nexg.tv/LiveTV/PlayOption.aspx?viruwap=&amp;MenuName=9xm%20Music%20viruwap&amp;qstrChannelID=CH393" ><img src="http://wapkaimage.com/5687/5687546_0c7f40acde.jpg" alt="" border="0" /> <img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /></a></div>
<div><a href="rtsp://202.159.213.30:554/cnbctv18_mobC.sdp?token=923152409036" ><img src="http://wapkaimage.com/1422/1422768_c87e42653c.jpg" alt="" border="0" /> <img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="0" /></a></div>
<div></div>
<div align="center"></div>














<div><a href="rtsp://202.159.213.30:554/bbcworld_mobC.sdp?token=923152409036" ><img src="http://wapkaimage.com/3469/3469252_39b2b78787.jpg" alt="" border="0" /> <img src="http://wapkaimage.com/1525/1525276_fe26f7c097.jpg" alt="" border="2" /></a></div>
<div><b></b></div></div>
</div>
</div>
</body></html>