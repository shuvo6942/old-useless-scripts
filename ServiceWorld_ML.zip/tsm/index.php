<?php
echo '<title>TShirt Generator</title><link rel="stylesheet" href="http://wtools.gq/styles.css" /><link rel="shortcut icon" href="http://phptunes.com/favicon.ico" /><div><div><div class="brdr"> <div class="sky">Create Your TShirt</div><div id="wap_form"> <form action="http://kickwap.com/showstrip.jsp" method="get"><p> Country : <select class="select_container" name="type">

<option value="algeria">Algeria</option><option value="argentina">Argentina</option><option value="australia">Australia</option><option value="brazil">Brazil</option><option value="cameroon">Cameroon</option><option value="chile">Chile</option>

<option value="ivory-coast">Cote d Ivoire</option>
<option value="denmark">Denmark</option>
<option value="england">England</option>
<option value="france">France</option>
<option value="germany">Germany</option>
<option value="ghana">Ghana</option>
<option value="greece">Greece</option>
<option value="honduras">Honduras</option>
<option value="india">India</option>
<option value="indonesia">Indonesia</option>
<option value="italy">Italy</option>
<option value="japan">Japan</option>
<option value="mexico">Mexico</option>
<option value="netherlands">Natherlands</option>
<option value="new-zealand">New Zealand</option>
<option value="nigeria">Nigeria</option>
<option value="north-korea">Korea DPR</option>
<option value="paraguay">Paraguay</option>
<option value="portugal">Portugal</option>
<option value="serbia">Serbia</option>
<option value="slovekia">Slovekia</option>
<option value="slovenia">Slovenia</option>
<option value="south-africa">South Africa</option>
<option value="south-korea">Korea Republic</option>
<option value="spain">Spain</option>
<option value="usa">USA</option>
<option value="switzerland">Switzerland</option>
<option value="turkey">Turkey</option>
<option value="uruguay">Uruguay</option>
<option value="vietnam">Vietnam</option></select><br/>Your Name: <input class="search_sect" type="text" name="name" maxlenth="14" value="" size="10"/><br/>Strip No:<input class="search_sect" type="text" name="number" maxlenth="2" value="" size="10"/><br/>Font Size:<select class="select_container" name="size">
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
<option value="13">13</option>
<option value="14">14</option></select>
<input class="sumit" type="submit" value="Create" /></p></form></div></div></div><br /></div>';
?>