<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Graphical Calculator</title><link rel="STYLESHEET" type="text/css" href="http://wtools.gq/styles.css"/><link rel="shortcut icon" href="http://phptunes.com/favicon.ico"/><meta forua="true" http-equiv="Cache-Control" content="max-age=0"/><style type="text/css">
body { background: ;
color: ;
}
a { color: ;
}
</style>
</head><body>




<div class=page style="margin-left:0; margin-right:0;">Graphi-Calculator</div> <div style="border:2px solid green; margin:0; padding:0;"><div class=in><div class=footbanner style="margin:2px; padding:0;"><div class=toptop1><br><script LANGUAGE="JavaScript">

function pad(anystr) {
document.calc.shownum.value += anystr
}

function calcit() {
document.calc.shownum.value = eval(document.calc.shownum.value)
}

function clearit() {
document.calc.shownum.value = ""
}

function backspace() {
curvalue = document.calc.shownum.value
curlength = curvalue.length
curvalue = curvalue.substring(0,curlength-1)
document.calc.shownum.value = curvalue
}

</script>
<center>
<map NAME="calcmap">
<area SHAPE="RECT" COORDS="10,80,40,106" HREF="javascript:pad('7')">
<area SHAPE="RECT" COORDS="49,80,78,106" HREF="javascript:pad('8')">
<area SHAPE="RECT" COORDS="88,79,117,106" HREF="javascript:pad('9')">
<area SHAPE="RECT" COORDS="128,81,158,105" HREF="javascript:pad('+')">
<area SHAPE="RECT" COORDS="11,115,39,141" HREF="javascript:pad('.')">
<area SHAPE="RECT" COORDS="49,115,78,142" HREF="javascript:pad('0')">
<area SHAPE="RECT" COORDS="89,116,119,141" HREF="javascript:calcit()">
<area SHAPE="RECT" COORDS="128,116,158,142" HREF="javascript:pad('-')">
<area SHAPE="RECT" COORDS="167,80,194,105" HREF="javascript:pad('*')">
<area SHAPE="RECT" COORDS="167,116,196,141" HREF="javascript:pad('/')">
<area SHAPE="RECT" COORDS="11,43,39,71" HREF="javascript:pad('4')">
<area SHAPE="RECT" COORDS="50,45,77,69" HREF="javascript:pad('5')">
<area SHAPE="RECT" COORDS="88,44,117,71" HREF="javascript:pad('6')">
<area SHAPE="RECT" COORDS="127,44,158,71" HREF="javascript:pad(')')">


<area SHAPE="RECT" COORDS="165,43,196,70" HREF="javascript:backspace()">
<area SHAPE="RECT" COORDS="10,7,40,33" HREF="javascript:pad('1')">
<area SHAPE="RECT" COORDS="48,7,81,35" HREF="javascript:pad('2')">
<area SHAPE="RECT" COORDS="87,7,117,34" HREF="javascript:pad('3')">
<area SHAPE="RECT" COORDS="127,7,156,34" HREF="javascript:pad('(')">
<area SHAPE="RECT" COORDS="166,7,195,35" HREF="javascript:clearit()"></map><form NAME="calc">
<table BORDER="1" BGCOLOR="#C0C0C0"><tr><td WIDTH="213">
<center>
<input NAME="shownum" VALUE MAXLENGTH="25" width="215px" style="color:red">
</center></td></tr>
<tr><td WIDTH="213"><img USEMAP="#calcmap" SRC="http://greentooth.xtgem.com/images/gcalc.png" BORDER="0" HEIGHT="153" WIDTH="206">
</center></td></tr></table>
</form></body></html>