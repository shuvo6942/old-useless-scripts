<?
set_time_limit(120);
session_start();
$session_icon_path = session_id().".ico";
include("floIcon.php");
if (isset($_GET["pic"])) {
	if (file_exists($session_icon_path)) {
		$icon_file = new floIcon();
		$icon_file->readICO($session_icon_path);
	} else {
		$icon_file = new floIcon();
	}
	ob_start("output_handler");
	imagepng($icon_file->images[$_GET["pic"]]->getImageResource());
	ob_end_flush();
}
function output_handler($img) {
	header('Content-type: image/png');
	header('Content-Length: ' . strlen($img));
	return $img;
}
?>