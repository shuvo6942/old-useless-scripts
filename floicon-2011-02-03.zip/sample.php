<?
/***************************************************************************
 *  Original floIcon copyright (C) 2007 by Joshua Hatfield.                *
 *                                                                         *
 *  In order to use any part of this floIcon Class, you must comply with   *
 *  the license in 'license.doc'.  In particular, you may not remove this  *
 *  copyright notice.                                                      *
 *                                                                         *
 *  Much time and thought has gone into this software and you are          *
 *  benefitting.  We hope that you share your changes too.  What goes      *
 *  around, comes around.                                                  *
 ***************************************************************************/

// Original Location: http://www.flobi.com/test/floIcon/sample.php

// If you on a slow server, you may need a little more time to process some larger images.
set_time_limit(120);

// We're going to save the icon as a session icon so you can see how adding, removing, etc works.
session_start();
$session_icon_path = session_id().".ico";
include("floIcon.php");
if (file_exists($session_icon_path)) {
	$icon_file = new floIcon();
	$icon_file->readICO($session_icon_path);
} else {
	$icon_file = new floIcon();
}

// Did the client upload a file?
if ($_FILES['ico_file']['tmp_name'] && is_uploaded_file($_FILES['ico_file']['tmp_name'])) {
	// Is it an image?
	if (
		$tmp_image = @imagecreatefrompng($_FILES['ico_file']['tmp_name']) or
		$tmp_image = @imagecreatefromgif($_FILES['ico_file']['tmp_name']) or
		$tmp_image = @imagecreatefromjpeg($_FILES['ico_file']['tmp_name'])
	) {
		// If so, add the image.
		$desired_bit_count = $_POST["desired_bit_count"];
		$icon_file->addImage($tmp_image, $desired_bit_count);
	} else {
		// Otherwise, try to parse as an icon file.
		$icon_file->readICO($_FILES['ico_file']['tmp_name']);
	}
}

// Did they specify any images to remove?
if (count($_POST["remove_images"])) {
	foreach ($_POST["remove_images"] as $key) {
		unset($icon_file->images[$key]);
	}
}

// If an uploaded file, or removed images, we need to resave the icon file.
if (
	is_uploaded_file($_FILES['ico_file']['tmp_name']) ||
	count($_POST["remove_images"])
) {
	// First, let's sort smallest to largest.
	$icon_file->sortImagesBySize();
	file_put_contents($session_icon_path, $icon_file->formatICO());

	// We're redirecting so they don't have to worry about accidental resubmission.
	header("location: index.php");
	die();
}


?>
<html>
<head>
	<title>floIcon XP Sample</title>
	<style>
		body, p, td, th {
			font-family: Arial;
			font-size: 10pt;
		}
	</style>
</head>
<body>
<h1>floIcon XP Sample</h1>
<form action="index.php" method="post" ENCTYPE="multipart/form-data">
	<?
	if ($icon_file->countImages()) {
		// These are the generally supported bit counts:
		$supportedBitCounts = array(32, 24, 8, 4, 1);
		// These are the generally supported sizes:
		$standardSizes = array(128, 48, 32, 24, 16);

		// We will use that info to make a table:

		// I'm making an array of all the images called $nonStandard.  This will
		// be cleared out as each image is found to be standard size and bitcount.
		// What's left will be only nonStandard sizes that we can display at the end.
		$nonStandard = array();
		foreach (array_keys($icon_file->images) as $key) {
			$nonStandard[$key] = true;
		}

		?>
		<p>Your <a href='<?=$session_icon_path?>'>session icon</a> currently has <?=count($icon_file->images)?> image<?=(count($icon_file->images)==1?"":"s")?>.  Checking the checkbox next to an icon image before clicking Update at the bottom of the page will remove the image.  See below for more information.</p>
			<table border=1 cellpadding=0 cellspacing=0 align=center>
			<tr>
				<td></td>
				<?
				// Printing labels:
				foreach ($standardSizes as $standardSize) {
					?>
					<th>
						<?=$standardSize?>x<?=$standardSize?>
					</th>
					<?
				}
				?>
			</tr>
			<?
			// Each table row:
			foreach ($supportedBitCounts as $supportedBitCount) {
				?>
				<tr>
					<th>
						<?
						// Printing labels:
						?>
						<?=$supportedBitCount?> bit
					</th>
					<?
					// Each table column:
					foreach ($standardSizes as $standardSize) {
						?>
						<td valign=top align=center>
							<?
							// Check each image to see if it's this size/bitCount.
							foreach($icon_file->images as $key => $image) {
								$bitCount = $image->_entry["BitCount"]?$image->_entry["BitCount"]:$image->_header["BitCount"];
								if (
									$bitCount == $supportedBitCount and
									$image->_entry["Height"] == $standardSize and
									$image->_entry["Width"] == $standardSize
								) {
									// If the image fits here, print it and unset it from $nonStandard.
									echo("<div style='background-color: #FFFFFF' onMouseOver=\"this.style.backgroundColor='#316ac5'\" onMouseOut=\"this.style.backgroundColor='#FFFFFF'\"><input type='checkbox' name='remove_images[]' id='remove_image_$key' value='$key'><a href=\"javascript:void(document.getElementById('remove_image_$key').click());\"><img border=0 src='display_picture.php?pic=$key'></a></div>");
									unset($nonStandard[$key]);
								}
							}
							?>
						</td>
						<?
					}
					?>
				</tr>
				<?
			}
			?>
		</table>
		<?
		// Now, just spit out $nonStandard:
		// I put it in a table for easier viewing.
		if (count($nonStandard)) {
			?>
			<p>Your icon file also includes the following non-standard sizes/bitcount images:</p>
			<table border=0 cellpadding=0 cellspacing=0 align=center>
				<tr>
					<td>
						<?
						foreach ($nonStandard as $key => $true) {
							$image = $icon_file->images[$key];
//							echo("<pre>");
//							print_r($image);
							echo("<div style='background-color: #FFFFFF' onMouseOver=\"this.style.backgroundColor='#316ac5'\" onMouseOut=\"this.style.backgroundColor='#FFFFFF'\"><input type='checkbox' name='remove_images[]' id='remove_image_$key' value='$key'><a href=\"javascript:void(document.getElementById('remove_image_$key').click());\"><img border=0 src='display_picture.php?pic=$key'></a></div>");
						}
						?>
					</td>
				</tr>
			</table>
			<?
		}
	} else {
		// If there are no images, say so.
		echo("<p>Your <a href='$session_icon_path'>session icon</a> currently has no images.  See below for more information.</p>");
	}
	// Here's the form for uploading.
	?>
	<ul>
		<b>Add Images to Icon:</b><br>
		From PNG, ICO, GIF or JPEG file:<br> <input type="file" name="ico_file"><br>
		For Uploading Images Only: <select name="desired_bit_count">
			<option value="1">Select Lowest Possible Bit Count</option>
			<option value="32">Raise Bit Count to 32 Bits</option>
			<option value="24">Raise Bit Count to 24 Bits</option>
			<option value="8">Raise Bit Count to 8 Bits</option>
			<option value="4">Raise Bit Count to 4 Bits</option>
		</select><br>
		<input type="submit" value="Update Icon File">
	</ul>
</form>
<h2>More Information:</h2>
<p>floIcon has been created by <a href="http://www.flobi.com/">Flobi.com</a>.  <a href="license.doc">View floIcon License.</a></p>
</body>
</html>
