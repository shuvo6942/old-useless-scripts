<?php

/*

* Author: Khalequzzaman
* Language: PHP, HTML, CSS
* Project Name: 9Apps Grabber
* URL: http://apk.nextmusics.com/

*/

$sitename = 'Apk.NextMusics.Com';
$author = 'Md. Khalequzzaman Labonno';
$email = 'admin@nextmusics.com';
$logowap = 'http://nextmusics.com/images/logo.png';
$linkiklan = '';
//META TAG
if($_SERVER['PHP_SELF'] == '/detail.php'){
$description = $filename.' is a kind of '.$category.' apps for Android, '.$sitename.' official website provides download and walkthrough for Cewek Brunettes, Play free '.$filename.' online.';
$keyword = $filename;
}
elseif($description == '' && $keyword == ''){
$description = $_SERVER['HTTP_HOST'].' supports free android apps apk download. Thousands of top best android apps at '.$sitename.'! Play free apps for android mobile phone now!';
$keyword = 'android apps,android apps download,free android apps,best android apps,apps for android,'.$sitename.' for mini';
}

?>