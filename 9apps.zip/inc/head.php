<?php

/*

* Author: Khalequzzaman
* Language: PHP, HTML, CSS
* Project Name: 9Apps Grabber
* URL: http://apk.nextmusics.com/

*/

echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="Cache-control" content="max-age=0">
    <meta id="viewport" name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="format-detection" content="telephone=no">
    <link rel="canonical" href="http://'.$_SERVER['HTTP_HOST'].'" />
    <link type="text/css" rel="stylesheet" href="http://www.9apps.com/asset/mini/css/main_39a87bb7.css?a=10"/>
    <link rel="shortcut icon" type="image/x-icon" href="http://www.9apps.com/asset/v2/images/favicon.ico" />
    <title>'.$title.'</title>';


echo '                    <meta name="description" content="'.$description.'">
                <meta name="keywords" content="'.$keyword.'">

        <script type="text/javascript">
        function note_click(target,matchWord){
            if(target.value == \'\') {
                target.value = matchWord;
            }else if (target.value == matchWord) {
                target.value = "";
            }
        }
    </script>
</head>

<body>';

if($_SERVER['PHP_SELF'] != '/detail.php' && empty($_GET['view'])){
echo '    <div class="header">
        <a class="logo" href="/?f=6_0_0_0_0">
            <img src="'.$logowap.'" width="60" height="16" alt="'.$sitename.'"/>
        </a>
        <a class="logo_facebooklink" href="https://www.facebook.com/Khalequzzaman.Labonno" target="_blank">Like Us</a>
        <div class="search-bar">
            <form action="/jump/search/">
                                    <input type="text" class=\'search-input\' value="'.$_GET['q'].'" name="keyword" placeholder="Search Here.."/>
                                <button type="submit" class="search-button"><b></b></button>
            </form>
        </div>
    </div>';



echo '                                    <p class="nav">
        <a href="/?f=6_0_0_0_0"  class="item '.nav('/index.php','active').'" >Home</a>
        <a href="/android-apps-categories/?f=7_0_2_0_0" class="item '.nav('/category.php','active').'" >Categories</a>
        <a href="/top-android-apps-1/?f=9_0_0_0_0" class="item '.nav('/top.php','active').'" >Top</a>
        <a href="/new-android-apps-1/?f=10_0_0_0_0" class="item '.nav('/new.php','active').'"  >New</a>
    </p>';
}
	?>