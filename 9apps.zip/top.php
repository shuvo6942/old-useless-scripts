<?php

/*

* Author: Khalequzzaman
* Language: PHP, HTML, CSS
* Project Name: 9Apps Grabber
* URL: http://apk.nextmusics.com/

*/

include_once 'inc/func.php';
include_once 'inc/data.php';


if(!empty($_GET['type'])){
if(!empty($_GET['page'])){$page = $_GET['page'];}else{$page = 1;}
$grab = xlink('http://www.9apps.com/top-android-'.$_GET['type'].'-'.$page.'/?f='.$_GET['f'].'');
$top = cut($grab,'<div class="tabs">','<div class="footer">');
$top = str_replace('/jump/','http://www.9apps.com/jump/', $top);
$title = 'Top Best Free Android '.ucwords($_GET['type']).' of '.date('Y').' - '.$sitename;
$description = 'Looking for most fun '.$_GET['type'].' to play on your Android device? '.$_SERVER['HTTP_HOST'].' commends the top best Android '.$_GET['type'].' of '.date('Y').' so far.';
$keyword = 'top android '.$_GET['type'].',best android '.$_GET['type'].' for mini';
include_once 'inc/head.php';
echo '<div class="tabs">'.$top;
include_once 'inc/foot.php';
}
else{
include '404.php';
}
?>