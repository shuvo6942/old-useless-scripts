<?php
/********************************
* This Script created by		* 
* Huteri Manza					*
* http://huteri.net				*
* copyright 2009				*
********************************/
?>
<?php
$server="localhost";
$username="root";
$password="";
$database="test";




mysql_connect($server, $username, $password) or die("Error In database setting : ".mysql_error());
mysql_select_db($database) or die("Database Not Found".mysql_error());

mysql_query("set time_zone='+07:00'") or die(mysql_error());

$ar=mysql_query("select * from user where id='1'");
if($ar)
{
$ur=mysql_fetch_array($ar);
if(gmdate("Y-m-d", time()+25200) > $ur["time"])
{
mysql_query("update user set time=now() where id='1'") or die(mysql_error());
mysql_query("update blog set hit=hittoday+hit, hittoday='0'") or die(mysql_error());
}
}
?>