<?php
/********************************
* This Script created by		* 
* Huteri Manza					*
* http://huteri.net				*
* copyright 2009				*
********************************/
?>
<?php
function catname($cat_id)
{
$q=mysql_query("select kategori from kategori where id='$cat_id'") or die(mysql_error());
$w=mysql_fetch_row($q);
return $w[0];
}
function search($ur)
{
if(isset($_SESSION["form"]))
{
echo $_SESSION["form"];
}
echo "<form action=\"index.php?s\" method=\"post\">
<b>Search</b><br/>
<input type=\"text\" name=\"search\" maxlenght=\"{$ur["idx_searchmaxlenght"]}\" size=\"{$ur["idx_searchsize"]}\"><br/><input type=\"submit\" value=\"search\"></form>";
admin();
}

function username($user_id)
{
$huteri=mysql_query("select * from user where id='$user_id'") or die(mysql_error());
$manza=mysql_fetch_array($huteri);
return $manza["name"];
}

function listcat()
{
echo "<br/><br/><div class=\"blog\">";
$huteri=mysql_query("select * from kategori order by id") or die(mysql_error());
$huterim=mysql_query("select count(id) from blog") or die(mysql_error());
$c=mysql_fetch_row($huterim);
echo "Cattegory :<br/>
-&gt; <a href=index.php>All</a> ({$c[0]})<br/>";
while($manza=mysql_fetch_row($huteri))
{
echo "-&gt; <a href=index.php?cat={$manza[0]}>{$manza[1]}</a> (".jmlpercat($manza[0]).")";
if(isset($_SESSION["user"]))
{
echo " [<a href=index.php?edt={$manza[0]}>E</a>][<a href=index.php?del={$manza[0]}>D</a>]<br/>";
}
else
{
echo "<br/>";
}
}
if(isset($_GET["delsave"]))
{
if(!isset($_SESSION["user"]))
{
echo "Forbidden <a href=index.php>refresh</a>";
}
$_GET["deluser"]=trim($_GET["deluser"]);
mysql_query("delete from kategori where id='{$_GET["delsave"]}'") or die(mysql_error());
mysql_query("delete from blog where cat_id='{$_GET["delsave"]}'") or die(mysql_error());
mysql_query("delete from comment where cat_id='{$_GET["delsave"]}'") or die(mysql_error());
echo "Cattegory Deleted <a href=index.php>refresh</a>";
}
elseif(isset($_GET["del"]))
{
if(!isset($_SESSION["user"]))
{
echo "Forbidden <a href=index.php>refresh</a>";
}
else
{
$p=mysql_query("select id from kategori where id='{$_GET["del"]}'") or die(mysql_error());
if(mysql_num_rows($p)=="0")
{
echo "No Data Found <a href=index.php>refresh</a>";
}
else
{
echo "Are you sure want to delete this Cattegory? This'll delete all blog with this cattegory.<br/><a href=index.php?delsave={$_GET["del"]}>Yes</a> | <a href=index.php>No</a>";
}
}
}
elseif(isset($_GET["edtsave"]))
{
if(!isset($_SESSION["user"]))
{
echo "Forbidden <a href=index.php>refresh</a>";
}
else
{
$_POST["edit"]=trim($_POST["edit"]);;
if(empty($_POST["edit"]))
{
echo "Empty Data <a href=index.php>refresh</a>";
}
else
{
mysql_query("update kategori set kategori='{$_POST["edit"]}' where id='{$_POST["id"]}'") or die(mysql_error());
echo "Update berhasil <a href=index.php>refresh</a>";
}
}
}
elseif(isset($_GET["edt"]))
{
if(!isset($_SESSION["user"]))
{
echo "Forbidden <a href=index.php>refresh</a>";
}
else
{
$_GET["edt"]=trim($_GET["edt"]);
$g=mysql_query("select * from kategori where id='{$_GET["edt"]}'") or die(mysql_error());
$h=mysql_fetch_array($g);
if(mysql_num_rows($g)=="0" or mysql_num_rows($g)>"1")
{
echo "Wrong Data <a href=index.php>refresh</a>";
}
else
{
echo "<form action=\"index.php?edtsave\" method=\"post\"> <input type=\"hidden\" name=\"id\" value=\"{$_GET["edt"]}\">Edit <input type=\"text\" name=\"edit\" maxlenght=\"50\" size=\"10\" value=\"{$h["kategori"]}\"><br/><input type=\"submit\" value=\"ok\"></form>";
}
}
}
elseif(isset($_GET["newcatsave"]))
{
if(!isset($_SESSION["user"]))
{
echo "Forbidden <a href=index.php>refresh</a>";
}
else
{
$_POST["newcat"]=trim($_POST["newcat"]);
$u=mysql_query("select id from kategori where kategori='{$_POST["newcat"]}'") or die(mysql_error());
if(empty($_POST["newcat"]))
{
echo "Empty Data <a href=index.php>refresh</a>";
}
elseif(mysql_num_rows($u)!="0")
{
echo "Cattegory already exist <a href=index.php>refresh</a>";;
}
else
{
mysql_query("insert into kategori (kategori) values ('{$_POST["newcat"]}')") or die(mysql_error());
echo "Creating Success!! <a href=index.php>refresh</a>";
}
}
}
elseif(isset($_GET["newcat"]))
{
if(!isset($_SESSION["user"]))
{
echo "Forbidden. ";
}
else
{
echo "<form action=\"index.php?newcatsave\" method=\"post\">
New : <input type=\"text\" name=\"newcat\" maxlenght=\"50\" size=\"10\">
<br/><input type=\"submit\" value=\"ok\"></form>";
}
}
else
{
if(isset($_SESSION["user"]))
{
echo "<a href=index.php?newcat>New Cattegory</a>";
}
}
echo "</div>";
}
function search_result($search, $ur)
{
if(preg_match("/^!login/i", $search))
	{
$pass=substr($search, 7);
$u=preg_replace("#(.*?) ((.*?|\s)+)#", "\\1+\\2", $pass);
$f=explode("+", $u);
$g=mysql_query("select password from user where name='{$f[0]}' and password='{$f[1]}' and id='1'") or die("!".mysql_error());
if(mysql_num_rows($g)!=0)
	{
$_SESSION["user"]="{$f[0]}";
echo "<title>Success</title><div class=\"blog\">Login success<br/><a href=index.php>Click Here To Continue</a></div>";
	}
else
	{
echo "<title>Invalid user</title><div class=\"blog\">Invalid user<br/><a href=index.php>back</a></div>";
	}
	}
else
	{
	$search=str_replace("\"", "", str_replace("'", "", $search)); 
$show=$ur["blogperpage"];
$p = $_GET['p'];
$title=implode("%' OR title LIKE '%", explode(" ",$search));
$text=implode("%' OR text LIKE '%", explode(" ",$search));
$count=mysql_query("SELECT id FROM blog WHERE title LIKE '%$title%' OR text LIKE '%$text%'") or die(mysql_error());
$total=mysql_num_rows($count);
if($total=="0")
{
echo "<div class=\"blog\">No Result found</div>";
}
else
{
$pg=ceil($total/$show);
if($p>$pg && $p!=1)
$p=$pg; 
if($p<1)
$p=1;
$j = ($p-1) * $show;
$huteri=mysql_query("select id, title, text, cat_id, date_format(time, '%d/%m %y') as 'time', hit,hittoday,time as 'timeorder', user_id from blog  WHERE title LIKE '%$title%' OR text LIKE '%$text%' order by timeorder desc limit $j, $show") or die(mysql_error());
while($manza=mysql_fetch_array($huteri))
	{
	echo "<div class=\"blog\">";
$manza["text"]=substr($manza["text"], 0, $ur["idx_textperblog"]);
echo "<a href=index.php?blog={$manza["id"]}>{$manza["title"]}</a>";
if($ur["idx_hitonoff"]=="1")
{
echo " ({$manza["hittoday"]}/".($manza["hittoday"]+$manza["hit"]).")";
}
if($ur["idx_komenonoff"]=="1")
{
echo " [".jmlkomen($manza["id"])."]";
}
echo "<br/>{$manza["time"]} | <a href=index.php?cat={$manza["cat_id"]}>".catname($manza["cat_id"])."</a> | ".username($manza["user_id"])."<br/><i>{$manza["text"]}...</i><a href=index.php?blog={$manza["id"]}>Read More</a>";
if(isset($_SESSION["user"]))
{
$check=strpos($manza["title"], $ur["idx_updatenot"]);
if($check!==false)
{
echo "<br/><a href=index.php?delnot={$manza["id"]}>Del Notify</a>";
}
}
echo "<br/></div>";
}
echo "<div class=\"paging\">";
$sc=$ur["linkperpage"];
$st=floor($p/$sc)*$sc;
$en=$st+$sc;
$g=$st;
if($g<"2") print("");
else
if($g>"0")
print("<a href=index.php?s&p=".($g-1).">[&lt;]</a> ");
else
print("");

for($g;($g<$en);$g++)
	{
if($g==$p)
	{
print(" [<b>".$g."</b>] ");
	}
elseif($g<=$pg)
	{
if($g>"0")
print("<a href=index.php?s&p=".$g.">".$g."</a> ");
	}
else
	{
print(" ");
	}
	}
if($g<=$pg)
print("<a href=index.php?s&p=".$g.">[&gt;]</a>");
else
print("");
	}
echo "</div><br/><br/>";
search($ur);
listcat();
lastcomment($ur);
mosthit($ur);
mosthitall($ur);
}
}

function blog($comment, $id, $ur)
{
mysql_query("update blog set hittoday=hittoday+1 where id='$id'");
$huteri=mysql_query("select id, title, text,  date_format(time, '%d/%m %y %H:%i') as 'time', date_format(uptime, '%d/%m %y %H:%i') as 'uptime', cat_id,hit, hittoday, user_id from blog where id='$id'") or die(mysql_error());
if(mysql_num_rows($huteri)=="0")
die("zero result");
$manza=mysql_fetch_array($huteri);
$manza["title"]=str_replace($ur["idx_updatenot"], "", $manza["title"]);
if($ur["bbcodeonoff"]=="1")
{
$manza["text"]=bbcodes($manza["text"]);
}
if($ur["smileyonoff"]=="1")
{
$manza["text"]=smiley($manza["text"]);
}
echo "<div class=\"title\"><title>{$manza["title"]}</title><center>
{$manza["title"]}</center></div><hr>";
if($manza["uptime"]!="00/00 00 00:00")
{
echo "<div class=\"properties\">Date : {$manza["uptime"]}<br/>->>Last Update : {$manza["time"]}<br/>";
}
else
{
echo "<div class=\"properties\">Date : {$manza["time"]}<br/>";
}

echo "Kategori : ".catname($manza["cat_id"])."<br/>Author : ".username($manza["user_id"])." [Hits : {$manza["hittoday"]}/".($manza["hittoday"]+$manza["hit"])."]</div><hr><br/><div class=\"text\">".nl2br($manza["text"])."<br/></div>";

if($ur["blg_seealsoonoff"]=="1")
{
if($ur["blg_seealsoorder"]=="kategori")
{
$rand=mysql_query("select id, title from blog where id<>'{$manza["id"]}' and cat_id='{$manza["cat_id"]}' order by rand() limit {$ur["blg_seealsojml"]}") or die(mysql_error());
}
else
{
$rand=mysql_query("select id, title from blog where id<>'{$manza["id"]}' order by rand() limit {$ur["blg_seealsojml"]}") or die(mysql_error());
}
echo "<br/><div class=\"blog\"><b>See Also :</b><br/>";
while($randt=mysql_fetch_array($rand))
{
$randt["title"]=str_replace($ur["idx_updatenot"], "", $randt["title"]);
$randt["title"]=substr($randt["title"], 0, 25);
echo "-<a href=index.php?blog={$randt["id"]}>{$randt["title"]}</a><br/>";
}
echo "</div><br/>";
}

echo "<br/><a href=index.php>&lt;-Index</a>";
if(isset($_SESSION["user"]))
{
echo " | <a href=\"index.php?blog={$manza["id"]}&edit\">Edit</a> | <a href=\"index.php?blog={$manza["id"]}&delete\">Delete</a><hr>";
}
else
{
echo "<hr>";
}
echo "<div class=\"blog\"><b>Comment</b> (".jmlkomen($id).")<br/><br/>";
$c=mysql_query("select id, name, message, date_format(time, '%d/%m %y %H:%i') as 'time', blog_id, url from comment where blog_id='{$manza["id"]}' order by id desc limit {$ur["blg_komenperpage"]}") or die(mysql_error());
if(mysql_num_rows($c)=="0")
{
echo "No Comment<br/><br/>";
}
else
{
while($huterim=mysql_fetch_array($c))
{
$huterim["name"]=stripslashes(htmlentities($huterim["name"]));
$huterim["url"]=stripslashes(htmlentities($huterim["url"]));
if($huterim["url"]=="blank")
{
echo "<b><u>{$huterim["name"]}</b></u>";
}
else
{
echo "<a href={$huterim["url"]}><b><u>{$huterim["name"]}</b></u></a>";
}
echo " - {$huterim["time"]}<br/>";
$huterim["message"]=htmlentities(stripslashes($huterim["message"]));
if($ur["bbcodeonoff"]=="1")
{
$huterim["message"]=bbcodes($huterim["message"]);
}
if($ur["smileyonoff"]=="1")
{
$huterim["message"]=smiley($huterim["message"]);
}
echo "{$huterim["message"]}";
if(isset($_SESSION["user"]))
{
echo " [<a href=comment.php?blog={$huterim["blog_id"]}&del={$huterim["id"]}>Delete</a> ]";
}
else
{ echo ""; }
echo "<br/><br/>";
}
echo "<a href=comment.php?blog={$manza["id"]}>View Comment</a><br/><hr>";
}
$_SESSION["angka"]=rand(1,10000);
echo "</div><div class=\"blog\"><b>Leave Comment</b><br/><br/>
<form action=\"comment.php\" method=\"post\">
<input type=\"hidden\" name=\"blog_id\" value=\"{$manza["id"]}\">
<input type=\"hidden\" name=\"cat_id\" value=\"{$manza["cat_id"]}\">
Name : <br/>
<input type=\"text\" name=\"name\" maxlenght=\"{$ur["blg_komennamelenght"]}\" size=\"{$ur["blg_komennamesize"]}\" value=\"{$comment["name"]}\">
<br/>
<br/>
Website : <br/>
<input type=\"text\" name=\"url\" maxlenght=\"{$ur["blg_komenurllenght"]}\" size=\"{$ur["blg_komenurlsize"]}\" value=\"{$comment["url"]}\">
<br/><br/>
Comment :<br/>
<textarea rows=\"{$ur["blg_komenpesanrows"]}\" cols=\"{$ur["blg_komenpesancols"]}\" name=\"comment\" wrap=\"virtual\" maxlenght=\"{$ur["blg_komenpesanlenght"]}\" value=\"{$comment["comment"]}\">{$comment["comment"]}</textarea>
<br/><br/>
Captcha <b>{$_SESSION["angka"]}</b> : <input type=\"text\" name=\"kode\" size=\"4\">
";

echo "<br/><br/><input type=\"submit\" value=\"Submit\" name=\"submit\"><br/><br/>[BBcode ";
if($ur["bbcodeonoff"]=="1")
{
echo "<b>ON</b>]";
}
else
{
echo "<b>OFF</b>]";
}
echo "<br/>[Smiley "; 
if($ur["smileyonoff"]=="1")
{
echo "<b>ON</b>]";
}
else
{
echo "<b>OFF</b>]";
}
echo "</div>
<br/>
<hr>";
}

function userid($username)
{
$z=mysql_query("select id from user where name='$username' limit 1") or die(msyql_error());
$x=mysql_fetch_row($z);
return $x[0];
}

function catid($cat)
{
$v=mysql_query("select id from kategori where kategori='$cat'") or die(mysql_error());
$n=mysql_fetch_row($v);
return $n[0];
}

function jmlkomen($manzalog)
{
$huteri=mysql_query("select count(*) from comment where blog_id='$manzalog'");
$k=mysql_fetch_row($huteri);
return $k[0];
}

function admin()
{
if(isset($_SESSION["user"]))
{
echo "<br/><a href=index.php?lo>Log Out</a><br/><a href=write.php>Write Item</a><br/><a href=admin.php>Admin Room</a><br/>";
}
else
{
echo "";
}
}

function jmlpercat($id)
{
$huteri=mysql_query("select count(id) from blog where cat_id='$id'") or die(mysql_error());
$manza=mysql_fetch_row($huteri);
return $manza[0];
}
function edit_save($_POST, $ur)
{
if(empty($_POST["title"]) or empty($_POST["text"]))
die("data tidak lengkap");
$_POST["title"]=trim(addslashes($_POST["title"]));
$_POST["text"]=trim(addslashes($_POST["text"]));
$cat_id=catid($_POST["kategori"]);
$title=$ur["idx_updatenot"].$_POST["title"];
mysql_query("update blog set title='$title', text='{$_POST["text"]}',cat_id='$cat_id',uptime=time, time=now() where id='{$_POST["blog"]}'") or die(mysql_error());
echo "Update successfully! <br/><a href=index.php?blog=".$_POST["blog"].">next</a><hr>";
}

function form_edit($id, $ur)
{
$fe=mysql_query("select * from blog where id='$id'") or die(mysql_error());
$r=mysql_fetch_array($fe);
if(mysql_num_rows($fe)=="0")
die("Invalid data");
$r["title"]=str_replace($ur["idx_updatenot"], "", stripslashes($r["title"]));
$r["text"]=stripslashes($r["text"]);
echo "<center>Edit Blog</center>
<form action=\"index.php?blog&editsave\" method=\"post\">
<input type=\"hidden\" name=\"blog\" value=\"{$r["id"]}\">

Title : <br/>
<input type=\"text\" name=\"title\" maxlenght=\"100\" size=\"17\" value=\"{$r["title"]}\"><br/><br/>
Text : <br/>
<textarea cols=\"17\" rows=\"8\" name=\"text\" maxlenght=\"5000\" wrap=\"virtual\">{$r["text"]}</textarea><br/><br/>
Cattegory : <br/>
<select name=\"kategori\">";
$ui=mysql_query("select * from kategori order by id") or die(mysql_error());
while($o=mysql_fetch_array($ui))
{
echo "<option value=\"{$o["kategori"]}\"";
if($o["kategori"]==catname($r["cat_id"]))
{
echo "\"selected\"";
}
else
{
echo "";
}

echo ">{$o["kategori"]}";
}
echo "</option></select>";
echo "<input type=\"submit\" value=\"Edit\"></form><br/><a href=index.php?blog=$id>Cancel</a><br/><hr>";
}
function blog_delete($id)
{
$id=str_replace("\"", "", str_replace("\'", "", $id));
$l=mysql_query("select id from blog where id='$id'") or die(mysql_error());
if(mysql_num_rows($l)=="0")
die("Invalid data");

mysql_query("delete from blog where id='$id'") or die(mysql_error());
mysql_query("delete from comment where blog_id='$id'") or die(mysql_error());
echo "Blog Deleted<br/><a href=index.php>next</a><hr>";
}
function bbcodes($pesan)
{
$pesan=preg_replace("#\[url=(.*?)\](.*?)\[/url\]#","<a href=\"\\1\">\\2</a>", $pesan);
$pesan=preg_replace("#\[img\](.*?)\[/img\]#", "<img src=\"\\1\">", $pesan);
$pesan=preg_replace("#\[b\](.*?)\[/b\]#","<b>\\1</b>",$pesan);
$pesan=preg_replace("#\[kode\](.*?)\[/kode\]#",htmlentities("\\1"),$pesan);
$pesan=preg_replace("#\[u\](.*?)\[/u\]#", "<u>\\1</u>", $pesan);
$pesan=preg_replace("#\[i\](.*?)\[/i\]#", "<i>\\1</i>",$pesan);
$pesan=preg_replace("#\[blink\](.*?)\[/blink\]#","<blink>\\1</blink>",$pesan);
$pesan=str_replace("[br/]","<br/>", $pesan);
$pesan=preg_replace("#\[color=(.*?)\](.*?)\[/color\]#","<font color=\\1>\\2</font>",$pesan);
$pesan=preg_replace("#(^|[\n ])([\w]+?://[^ \"\n\r\t<]*)#","\\1<a href=\"\\2\">\\2</a>", $pesan);
return $pesan;
}

function smiley($pesan)
{
$emo = array(":-*",":*","=))",":))",":-)",":)",":((",";-)",":-P",":-p",":P",":p",":b",":-(",":(",":-D",":D",":-d",":d",":-O",":O",":-o",":o",";)");
$images=array("<img src=./smiley/1.gif","<img src=./smiley/1.gif","<img src=./smiley/2.gif","<img src=./smiley/3.gif","<img src=./smiley/4.gif","<img src=./smiley/4.gif","<img src=./smiley/5.gif","<img src=./smiley/6.gif","<img src=./smiley/7.gif","<img src=./smiley/7.gif","<img src=./smiley/7.gif","<img src=./smiley/7.gif","<img src=./smiley/7.gif","<img src=./smiley/8.gif","<img src=./smiley/8.gif","<img src=./smiley/9.gif","<img src=./smiley/9.gif","<img src=./smiley/9.gif","<img src=./smiley/9.gif","<img src=./smiley/10.gif","<img src=./smiley/10.gif","<img src=./smiley/10.gif","<img src=./smiley/10.gif","<img src=./smiley/6.gif");
for($i=0; $i<25; $i++)
{
$pesan=str_replace($emo[$i], $images[$i]." alt={$emo[$i]}>", $pesan);
}
return $pesan;
}

function repost($err, $huterimata)
{
$huterimisplay="$err<br/><form action=\"index.php?blog={$huterimata["blog_id"]}\" method=\"post\">
<input type=\"hidden\" name=\"name\" value=\"{$huterimata["name"]}\">";
if(!empty($huterimata["url"]))
{
$huterimisplay.="<input type=\"hidden\" name=\"url\" value=\"{$huterimata["url"]}\">";
}
$huterimisplay.="<input type=\"hidden\" name=\"comment\" value=\"{$huterimata["comment"]}\">
<input type=\"submit\" value=\"back\">
</form></div>";
return($huterimisplay);
}

function countcomment($id)
{
$count=mysql_query("select count(id) from comment where blog_id='$id' and date(time)=curdate()") or die(mysql_error());
$hasil=mysql_fetch_row($count);
return $hasil[0];
}

function lastcomment($ur)
{
if($ur["idx_lastcmtonoff"]=="1")
{
$huterimata=mysql_query("select * from comment order by id desc limit {$ur["idx_jmllastcmt"]}") or die(mysql_error());
echo "<br/><div class=\"blog\"><b>Last Comment :</b><br/>";
while($holm=mysql_fetch_array($huterimata))
{
$holm["name"]=substr(htmlentities($holm["name"]), 0, $ur["idx_lastcmtname"]);
$holm["message"]=substr(htmlentities($holm["message"]), 0, $ur["idx_lastcmtpesan"]);
echo "->{$holm["name"]} : {$holm["message"]}<a href=index.php?blog={$holm["blog_id"]}>...</a><br/>";
}
echo "</div>";
}
}

function mosthit($ur)
{
if($ur["idx_mosthittodayonoff"]=="1")
{
$huterimata=mysql_query("select * from blog order by hittoday desc limit {$ur["idx_jmlmosthittoday"]}") or die(mysql_error());
echo "<br/><div class=\"blog\"><b>Most Hit Today :</b><br/>";
while($f=mysql_fetch_array($huterimata))
{
$f["title"]=str_replace($ur["idx_updatenot"], "", $f["title"]);
echo "- <a href=index.php?blog={$f["id"]}>{$f["title"]}</a> ({$f["hittoday"]} Hits)<br/>";
}
echo "</div>";
}
}
function mosthitall($ur)
{
if($ur["idx_mosthitonoff"]=="1")
{
$huterimata=mysql_query("select * from blog order by hit desc limit {$ur["idx_jmlmosthit"]}") or die(mysql_error());
echo "<br/><div class=\"blog\"><b>Most Hit :</b><br/>";
while($f=mysql_fetch_array($huterimata))
{
$f["title"]=str_replace($ur["idx_updatenot"], "", $f["title"]);
echo "- <a href=index.php?log={$f["id"]}>{$f["title"]}</a> ({$f["hit"]} Hits)<br/>";
}
echo "</div>";
}
}
?>