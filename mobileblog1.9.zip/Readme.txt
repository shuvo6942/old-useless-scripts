Mobile Blog
v1.9

/********************************
* This Script created by		* 
* Huteri Manza					*
* http://huteri.net				*
* copyright 2009				*
********************************/


Installation Procedure :
1. Edit config.php for your database.
2. Upload all data to your server.
3. run install.php from your browser.
4. Insert your admin data when installation.
5. When The success notification opened. Run index.php and enjoy the mobile blog.

How To Login Admin 
- In Index you'll see The search box.
- Just type to the box like this 
	!Login adminname password
- For example, if your adminname is huteri and the password is 123, so to login
	!Login huteri 123
-Click The search button


This script made for perfect and more perfect so if you found bug or other error. Please report me in
http://huteri.net
mail@huteri.net
hut3ri@gmail.com

I'm Waiting Your Support :D

Created By Huteri Manza
2009


UPDATE STATUS
V1.2
-Bbcode and smiley added in blog and comment

V1.8
-Comment & Hit Today notification added
-Most Hit today added
-Last comment added
-Most hit added
-See also added
-Mind in comment post
-Update Notifications

V1.9 (Light Update)
-View and comment move to bottom
-Fix changed id when edit post
-Capctha Code in Comment added
-Translate to english

