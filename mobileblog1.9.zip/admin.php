<?php
/********************************
* This Script created by		* 
* Huteri Manza					*
* http://huteri.net				*
* copyright 2009				*
********************************/
?>
<?php
session_start();
require("header.php");
if(!isset($_SESSION["user"]))
die("Forbidden access Error");


if(isset($_GET["general"]))
{
$_POST["header"]=trim($_POST["header"]);
$_POST["footer"]=trim($_POST["footer"]);
$_POST["background"]=trim($_POST["background"]);
if(empty($_POST["header"]) or empty($_POST["header"]) or empty($_POST["background"]))
{
echo "<title>Error</title><div class=\"blog\">Data Not Complete<br/><a href=admin.php>back</a></div>";
}
else
{
mysql_query("update user set header='{$_POST["header"]}', footer='{$_POST["footer"]}', backcolor='{$_POST["background"]}', cssonoff='{$_POST["cssonoff"]}', bbcodeonoff='{$_POST["bbcodeonoff"]}', smileyonoff='{$_POST["smileyonoff"]}'  where id='1'") or die(mysql_error());
echo "General Config Update Succesfully<br/><a href=admin.php>next</a>";
}
}
elseif(isset($_GET["cnwritesave"]))
{
if(empty($_POST["titlesize"]) or empty($_POST["titlelenght"]) or empty($_POST["textcols"]) or empty($_POST["textrows"]) or empty($_POST["textlenght"]))
{
echo "<title>Error</title><div class=\"blog\">Data Not Complete<br/><a href=admin.php?cnwrite>back</a></div><hr>";
}
elseif(!is_numeric($_POST["titlesize"]) or !is_numeric($_POST["titlelenght"]) or !is_numeric($_POST["textcols"]) or !is_numeric($_POST["textrows"]) or !is_numeric($_POST["textlenght"]))
{
echo "Wrong in Insert Data. Data must be numeric<br/><a href=admin.php?cnwrite>back</a>";
}
else
{
mysql_query("update user set wr_titlesize='{$_POST["titlesize"]}', wr_titlelenght='{$_POST["titlelenght"]}', wr_textcols='{$_POST["textcols"]}', wr_textrows='{$_POST["textrows"]}', wr_textlenght='{$_POST["textlenght"]}'") or die(mysql_error());
echo "Write Config Update successfully<br/><a href=admin.php>next</a><hr>";
}
}
elseif(isset($_GET["cnwrite"]))
{
echo "<title>Write Page config</title><center><div class=\"title\">Write Page config</div></center><br/><br/>";
echo "<div class=\"blog\"><form action=\"admin.php?cnwritesave\" method=\"post\">
<b>Write Page Options :</b><br/>
<p>Form Title size : <input type=\"text\" name=\"titlesize\" value=\"{$ur["wr_titlesize"]}\" size=\"4\"></p>
<p>Form Title Max Char : <input type=\"text\" name=\"titlelenght\" value=\"{$ur["wr_titlelenght"]}\" size=\"4\"></p>
<p>Form Text Cols : <input type=\"text\" name=\"textcols\" value=\"{$ur["wr_textcols"]}\" size=\"4\"></p>
<p>Form Text Rows : <input type=\"text\" name=\"textrows\" value=\"{$ur["wr_textrows"]}\" size=\"4\"></p>
<p>Form Text Max Char : <input type=\"text\" name=\"textlenght\" value=\"{$ur["wr_textlenght"]}\" size=\"4\"></p>
<input type=\"submit\" value=\"Save Config\"><br/><a href=admin.php>Cancel</a></div><hr>";
}

elseif(isset($_GET["cncommentsave"]))
{
if(empty($_POST["komenperpage"]) or empty($_POST["linkperpage"]))
{
echo "<title>Error</title><div class=\"blog\">Data Not Complete<br/><a href=admin.php?cncomment>back</a></div>";
}
elseif(!is_numeric($_POST["komenperpage"]) or !is_numeric($_POST["linkperpage"]))
{
echo "Wrong in Insert Data. Data must be numeric<br/><a href=admin.php?cncomment>back</a>";
}
else
{
mysql_query("update user set cmt_komenperpage='{$_POST["komenperpage"]}', cmt_linkperpage='{$_POST["linkperpage"]}' where id='1'") or die(mysql_error());
echo "Comment Config Update Successfully<br/><a href=admin.php>next</a>";
}
}
elseif(isset($_GET["cncomment"]))
{
echo "<title>Comment Page config</title><center><div class=\"title\">comment Page Config</div></center><br/><br/>";
echo "<div class=\"blog\"><form action=\"admin.php?cncommentsave\" method=\"post\">
<b>Comment Page Options :</b><br/>
<p>Comment Per Page : <input type=\"text\" name=\"komenperpage\" value=\"{$ur["cmt_komenperpage"]}\" size=\"4\"></p>
<p>Link Per Page : <input type=\"text\" name=\"linkperpage\" value=\"{$ur["cmt_linkperpage"]}\" size=\"4\".</p>
<input type=\"submit\" value=\"Save Config\"><br/><a href=\"admin.php\">Cancel</a></div><hr>";
}
elseif(isset($_GET["cnblogsave"]))
{
if(empty($_POST["komenperpage"]) or empty($_POST["komennamesize"]) or empty($_POST["komennamelenght"]) or empty($_POST["komenurlsize"]) or empty($_POST["komenurllenght"]) or empty($_POST["komenpesancols"]) or empty($_POST["komenpesanrows"]) or empty($_POST["komenpesanlenght"]) or empty($_POST["seealsojml"]))
{
echo "<title>Error</title><div class=\"blog\">Data Not Complete<br/><a href=admin.php?cnblog>back</a></div><hr>";
}
elseif(!is_numeric($_POST["komenperpage"]) or !is_numeric($_POST["komennamesize"]) or !is_numeric($_POST["komennamelenght"]) or !is_numeric($_POST["komenurlsize"]) or !is_numeric($_POST["komenurllenght"]) or !is_numeric($_POST["komenpesancols"]) or !is_numeric($_POST["komenpesanrows"]) or !is_numeric($_POST["komenpesanlenght"]) or !is_numeric($_POST["seealsojml"]))
{
echo "Wrong in Insert Data. Data must be numeric<br/><a href=admin.php?cnblog>back</a>";
}
else
{
mysql_query("update user set blg_komenperpage='{$_POST["komenperpage"]}', blg_komennamesize='{$_POST["komennamesize"]}', blg_komennamelenght='{$_POST["komennamelenght"]}', blg_komenurlsize='{$_POST["komenurlsize"]}', blg_komenurllenght='{$_POST["komenurllenght"]}', blg_komenpesancols='{$_POST["komenpesancols"]}', blg_komenpesanrows='{$_POST["komenpesanrows"]}', blg_komenpesanlenght='{$_POST["komenpesanlenght"]}', blg_seealsoonoff='{$_POST["seealsoonoff"]}', blg_seealsoorder='{$_POST["seealsoorder"]}', blg_seealsojml='{$_POST["seealsojml"]}' where id='1'") or die(mysql_error());
echo "<title>Successfully</title><div class=\"blog\">Blog Config Save Successfully<br/><a href=admin.php>next</a></div>";
}
}
elseif(isset($_GET["cnblog"]))
{
echo "<title>Blog Page Config</title><center><div class=\"title\">Blog Page Config</div></center><br/><br/>";
echo "<div class=\"blog\"><form action=\"admin.php?cnblogsave\" method=\"post\">
<b>Comment In Blog Page Options :</b><br/>
<p>Comment in Page : <input type=\"text\" name=\"komenperpage\" value=\"{$ur["blg_komenperpage"]}\" size=\"4\"></p>
<p>Form Name Size : <input type=\"text\" name=\"komennamesize\" value=\"{$ur["blg_komennamesize"]}\" size=\"4\"></p>
<p>Form Name Max Char : <input type=\"text\" name=\"komennamelenght\" value=\"{$ur["blg_komennamelenght"]}\" size=\"4\"></p>
<p>Form Website Size : <input type=\"text\" name=\"komenurlsize\" value=\"{$ur["blg_komenurlsize"]}\" size=\"4\"></p>
<p>Form Website Max Char : <input type=\"text\" name=\"komenurllenght\" value=\"{$ur["blg_komenurllenght"]}\" size=\"4\"></p>
<p>Form Comment Cols : <input type=\"text\" name=\"komenpesancols\" value=\"{$ur["blg_komenpesancols"]}\" size=\"4\"></p>
<p>Form Comment Rows : <input type=\"text\" name=\"komenpesanrows\" value=\"{$ur["blg_komenpesanrows"]}\" size=\"4\"></p>
<p>Form Comment Max Char : <input type=\"text\" name=\"komenpesanlenght\" value=\"{$ur["blg_komenpesanlenght"]}\" size=\"4\"></p>
<br/><br/>
<b>See Also Options :</b><br/>
<p><input type=\"radio\" name=\"seealsoonoff\" value=\"1\"";
if($ur["blg_seealsoonoff"]=="1")
{
echo " checked";
}
echo ">Enable | <input type=\"radio\" name=\"seealsoonoff\" value=\"2\"";
if($ur["blg_seealsoonoff"]=="2")
{
echo " checked";
}
echo ">Disable </p>
<p>---- See Also Count : <input type=\"text\" name=\"seealsojml\" value=\"{$ur["blg_seealsojml"]}\" size=\"4\"></p>
<p>---- Order by : <input type=\"radio\" name=\"seealsoorder\" value=\"random\"";
if($ur["blg_seealsoorder"]=="random")
{
echo " checked";
}
echo ">Random <input type=\"radio\" name=\"seealsoorder\" value=\"kategori\"";
if($ur["blg_seealsoorder"]=="kategori")
{
echo " checked";
}
echo ">Cattegory</p><br/><br/>
<input type=\"submit\" value=\"Save config\"></form><br/><a href=admin.php>Cancel</a></div><hr>";
}
elseif(isset($_GET["cnhomesave"]))
{
if(empty($_POST["blogperpage"]) or empty($_POST["linkperpage"]) or empty($_POST["textperblog"]) or empty($_POST["hitonoff"]) or empty($_POST["komenonoff"]) or empty($_POST["searchsize"]) or empty($_POST["searchmaxlenght"]) or empty($_POST["jmllastcmt"]) or empty($_POST["jmlmosthit"]) or empty($_POST["jmlmosthittoday"]) or empty($_POST["lastcmtname"]) or empty($_POST["lastcmtpesan"]))
{
echo "<title>Error</title><div class=\"blog\">Data Not Complete<br/><a href=admin.php?cnhome>back</a></div><hr>";
}
elseif(!is_numeric($_POST["blogperpage"]) or !is_numeric($_POST["linkperpage"]) or !is_numeric($_POST["textperblog"]) or !is_numeric($_POST["hitonoff"]) or !is_numeric($_POST["searchsize"]) or !is_numeric($_POST["searchmaxlenght"]) or !is_numeric($_POST["jmllastcmt"]) or !is_numeric($_POST["jmlmosthit"]) or !is_numeric($_POST["jmlmosthittoday"]) or !is_numeric($_POST["lastcmtname"]) or !is_numeric($_POST["lastcmtpesan"]))
{
echo "Wrong in Insert Data. Data must be numeric<br/><a href=admin.php?cnhome>back</a><hr>";
}
else
{
mysql_query("update user set blogperpage='{$_POST["blogperpage"]}', linkperpage='{$_POST["linkperpage"]}', idx_textperblog='{$_POST["textperblog"]}', idx_hitonoff='{$_POST["hitonoff"]}', idx_komenonoff='{$_POST["komenonoff"]}', idx_searchsize='{$_POST["searchsize"]}', idx_searchmaxlenght='{$_POST["searchmaxlenght"]}', idx_lastcmtonoff='{$_POST["lastcmtonoff"]}', idx_jmllastcmt='{$_POST["jmllastcmt"]}', idx_mosthitonoff='{$_POST["mosthit"]}', idx_jmlmosthit='{$_POST["jmlmosthit"]}', idx_mosthittodayonoff='{$_POST["mosthittoday"]}', idx_jmlmosthittoday='{$_POST["jmlmosthittoday"]}', idx_lastcmtname='{$_POST["lastcmtname"]}', idx_lastcmtpesan='{$_POST["lastcmtpesan"]}', idx_hittodayonoff='{$_POST["hittodayonoff"]}', idx_cmttodayonoff='{$_POST["cmttodayonoff"]}' where id='1'") or die(mysql_error());
echo "<title>Config Update Successfully><div class=\"blog\">Config Update Successfully<br/><a href=admin.php>Next</a></div><hr>";
}
}
elseif(isset($_GET["cnhome"]))
{
echo "<title>Home Page Config</title><center><div class=\"title\">Home Page Config</div></center><br/><br/>";
echo "<div class=\"blog\"><form action=\"admin.php?cnhomesave\" method=\"post\">
<b>Main Index Options :</b><br/>
<p>Blog Per Page : <input type=\"text\" name=\"blogperpage\" value=\"{$ur["blogperpage"]}\" size=\"4\"></p>
<p>Link Per Page : <input type=\"text\" name=\"linkperpage\" value=\"{$ur["linkperpage"]}\" size=\"4\"></p>
<p>Text Per Blog : <input type=\"text\" name=\"textperblog\" value=\"{$ur["idx_textperblog"]}\" size=\"4\"></p>
<p>Hits Per Blog : <input type=\"radio\" name=\"hitonoff\" value=\"1\"";
if($ur["idx_hitonoff"]=="1")
{
echo " checked";
}
echo ">Yes <input type=\"radio\" name=\"hitonoff\" value=\"2\"";
if($ur["idx_hitonoff"]=="2")
{
echo " checked";
}
echo ">No (<i>Symbol : ()</i> )</p>
<p>---- Hit Today : <input type=\"radio\" name=\"hittodayonoff\" value=\"1\"";
if($ur["idx_hittodayonoff"]=="1")
{
echo " checked";
}
echo ">Yes <input type=\"radio\" name=\"hittodayonoff\" value=\"2\"";
if($ur["idx_hittodayonoff"]=="2")
{
echo "checked";
}
echo ">No</p>
<p>Comment Per Blog : <input type=\"radio\" name=\"komenonoff\" value=\"1\"";
if($ur["idx_komenonoff"]=="1")
{
echo " checked";
}
echo ">Yes <input type=\"radio\" name=\"komenonoff\" value=\"2\"";
if($ur["idx_komenonoff"]=="2")
{
echo " checked";
}
echo ">No (<i>Symbol : []</i> )</p>
<p>---- Comment Today : <input type=\"radio\" name=\"cmttodayonoff\" value=\"1\"";
if($ur["idx_cmttodayonoff"]=="1")
{
echo " checked";
}
echo ">Yes <input type=\"radio\" name=\"cmttodayonoff\" value=\"2\"";
if($ur["idx_cmttodayonoff"]=="2")
{
echo " checked";
}
echo ">No </p>
<br/>
<br/>
<b>Search Box Options</b> :
<p>Box Size : <input type=\"text\" name=\"searchsize\" value=\"{$ur["idx_searchsize"]}\" size=\"4\"></p>
<p>Search Max Character : <input type=\"text\" name=\"searchmaxlenght\" value=\"{$ur["idx_searchmaxlenght"]}\" size=\"4\"></p>";
echo "<br/><br/>
<b>Last Comment Options</b> :
<p><input type=\"radio\" name=\"lastcmtonoff\" value=\"1\"";
if($ur["idx_lastcmtonoff"]=="1")
{
echo " checked";
}
echo ">Enable | <input type=\"radio\" name=\"lastcmtonoff\" value=\"2\"";
if($ur["idx_lastcmtonoff"]=="2")
{
echo " checked";
}
echo ">Disable </p>
<p>---- Total Comment : <input type=\"text\" name=\"jmllastcmt\" value=\"{$ur["idx_jmllastcmt"]}\" size=\"4\"></p>
<p>---- Name Minimal Char : <input type=\"text\" name=\"lastcmtname\" value=\"{$ur["idx_lastcmtname"]}\" size=\"4\"> Char</p>
<p>---- Comment Minimal Char : <input type=\"text\" name=\"lastcmtpesan\" value=\"{$ur["idx_lastcmtpesan"]}\" size=\"4\"> Char</p>
<br/>
<br/>
<b>Most Hit Options</b> :
<p><input type=\"radio\" name=\"mosthit\" value=\"1\"";
if($ur["idx_mosthitonoff"]=="1")
{
echo " checked";
}
echo ">Enable | <input type=\"radio\" name=\"mosthit\" value=\"2\"";
if($ur["idx_mosthitonoff"]=="2")
{
echo " checked";
}
echo ">Disable </p>
---- Total Most Hit : <input type=\"text\" name=\"jmlmosthit\" value=\"{$ur["idx_jmlmosthit"]}\" size=\"4\"></p>
<br/><br/>
<b>Most Hit Today</b> :
<p><input type=\"radio\" name=\"mosthittoday\" value=\"1\"";
if($ur["idx_mosthittodayonoff"]=="1")
{
echo " checked";
}
echo ">Enable | <input type=\"radio\" name=\"mosthittoday\" value=\"2\"";
if($ur["idx_mosthittodayonoff"]=="2")
{
echo " checked";
}
echo ">Disable </p>
---- Total Most Hit Today : <input type=\"text\" name=\"jmlmosthittoday\" value=\"{$ur["idx_jmlmosthittoday"]}\" size=\"4\"></p>";
echo "<br/><br/>
<input type=\"submit\" value=\"Config Save\"></form><br/><a href=admin.php>Cancel</a></div><hr>";
}
else
{
echo "<title>Admin Room</title><center><div class=\"title\">Blog Config</div><br/><br/></center>";
echo "<div class=\"blog\">Options Config :<br/>
-&gt; <a href=admin.php?cnhome>Home Page Config</a><br/>
-&gt; <a href=admin.php?cnblog>Blog Config</a><br/>
-&gt; <a href=admin.php?cncomment>Comment Config</a><br/>
-&gt; <a href=admin.php?cnwrite>Write Config</a><br/><br/><form action=\"admin.php?general\" method=\"post\">General Options :<br/>Header <br/><textarea cols=20 rows=8 name=\"header\" maxlenght=\"1000\">{$ur["header"]}</textarea><br/><br/>Footer<br/><textarea cols=20 rows=8 name=\"footer\">{$ur["footer"]}</textarea><br/><br/>Background Color : <input type=\"text\" name=\"background\" value=\"{$ur["backcolor"]}\"><br/><br/>CSS : <input type=\"radio\" name=\"cssonoff\" value=\"1\"";
if($ur["cssonoff"]=="1")
{
echo " checked";
}
echo ">Yes <input type=\"radio\" name=\"cssonoff\" value=\"2\"";
if($ur["cssonoff"]=="2")
{
echo " checked";
}
echo ">No <br/><br/>
Bbcodes : <input type=\"radio\" name=\"bbcodeonoff\" value=\"1\"";
if($ur["bbcodeonoff"]=="1")
{
echo " checked";
}
echo ">Yes <input type=\"radio\" name=\"bbcodeonoff\" value=\"2\"";
if($ur["bbcodeonoff"]=="2")
{
echo " checked";
}
echo ">No <br/><br/>
Smiley : <input type=\"radio\" name=\"smileyonoff\" value=\"1\"";
if($ur["smileyonoff"]=="1")
{
echo " checked";
}
echo ">Yes <input type=\"radio\" name=\"smileyonoff\" value=\"2\"";
if($ur["smileyonoff"]=="2")
{
echo " checked";
}
echo ">No <br/><br/>
<input type=\"submit\" value=\"Update\"></form><br/>
<i>NB : In admin room, We don't need high security. So use it as well</i><br/><br/>
<a href=index.php>Back To Home</a></div>";
}
echo "<br/><br/><div class=\"header\">{$ur["footon"]}<br/></div>
<br/>
</body>
</html>";
?>