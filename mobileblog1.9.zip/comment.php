<?php
/********************************
* This Script created by		* 
* Huteri Manza					*
* http://huteri.net				*
* copyright 2009				*
********************************/
?>
<?php
session_start();
require("config.php");
require("func.php");
if(isset($_GET["blog"]) and isset($_GET["del"]))
{
if(!isset($_SESSION["user"]))
die("forbidden Error");
$_GET["del"]=trim($_GET["del"]);
$_GET["blog"]=trim($_GET["blog"]);
mysql_query("delete from comment where id='{$_GET["del"]}'") or die(mysql_error());
header("location:comment.php?blog={$_GET["blog"]}");
}
echo "
<html>
<head>";
if($ur["cssonoff"]=="1")
{
echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"style.css\">";
}
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\">
<meta http-equiv=\"CONTENT-LANGUAGE\" content=\"EN-US\">
<meta name=\"revisit-after\" content=\"1 days\">
<meta name=\"robots\" content=\"all,index,follow\">
<meta name=\"Distribution\" content=\"Global\">
<meta name=\"Rating\" content=\"General\">
</head>
<body bgcolor=\"{$ur["backcolor"]}\">
<div class=\"header\">{$ur["header"]}</div><hr>";
?>
<?php
if(isset($_POST["submit"]))
{
$_POST["name"]=trim(addslashes(strip_tags($_POST["name"])));
$_POST["comment"]=trim(addslashes($_POST["comment"]));
$_POST["url"]=trim(addslashes(strip_tags($_POST["url"])));
if(empty($_POST["name"]) or empty($_POST["comment"]) or empty($_POST["kode"]))
{
echo repost("<title>Failed To Insert Comment</title><div class=\"blog\">Field isn't complete",$_POST);
die();
}
elseif($_POST["kode"]!=$_SESSION["angka"])
{
echo repost("<title>Failed To Insert Comment</title><div class=\"blog\">Wrong Captcha Code",$_POST);
die();
}
unset($_SESSION["angka"]);
if(!empty($_POST["url"]))
{
if(!ereg("^http://", $_POST["url"]))
{
$_POST["url"]="http://{$_POST["url"]}";
}
}
else
{
$_POST["url"]="blank";
}
$a=mysql_query("select message from comment order by id desc limit 1") or die(mysql_error());
$e=mysql_fetch_row($a);
if($_POST["comment"]==$e[0])
{
echo repost("<title>anti Flood Control</title> <div class=\"blog\">anti flood control", $_POST);
die();
}
mysql_query("insert into comment (name, message, time, blog_id, cat_id, url) values ('{$_POST["name"]}','{$_POST["comment"]}', now(), '{$_POST["blog_id"]}', '{$_POST["cat_id"]}', '{$_POST["url"]}')") or die(mysql_error());
echo "<title>Insert Comment Success</title><div class=\"blog\">Comment Saved :D <br/><a href=comment.php?blog={$_POST["blog_id"]}>next</a></div>";
}
elseif(isset($_GET["blog"]))
{
if(!is_numeric($_GET["blog"]))
die("<b>Error</b> : Invalid char detected");
echo "<title>View Commment</title>";
$show=$ur["cmt_komenperpage"];
$p = $_GET['p'];
$total=jmlkomen($_GET["blog"]);
if($total=="0")
{
die("No comment inside<br/><a href=index.php?blog={$_GET["blog"]}>Go Back</a>");
}
$pg=ceil($total/$show);
if($p>$pg && $p!=1)
$p=$pg;
if($p<1)
$p=1;
$j = ($p-1) * $show;
$a=mysql_query("select id, name, message, date_format(time, '%d/%m %y %H:%i') as 'time', blog_id, url from comment where blog_id='{$_GET["blog"]}' order by id desc limit $j, $show");
while($d=mysql_fetch_array($a))
{
echo "<div class=\"blog\">";
$d["name"]=htmlentities(stripslashes($d["name"]));
$d["message"]=htmlentities(stripslashes($d["message"]));
if($ur["bbcodeonoff"]=="1")
{
$d["message"]=bbcodes($d["message"]);
}
if($ur["smileyonoff"]=="1")
{
$d["message"]=smiley($d["message"]);
}

$d["url"]=htmlentities(stripslashes($d["url"]));
if($d["url"]=="blank")
echo "<b><u>{$d["name"]}</b></u>";
else 
echo "<a href=\"{$d["url"]}\"><b><u>{$d["name"]}</b></u></a>";

echo " - {$d["time"]}<br/>{$d["message"]}";
if(isset($_SESSION["user"]))
{
echo " [<a href=comment.php?blog={$d["blog_id"]}&del={$d["id"]}>Delete</a>]";
}
else { echo ""; }
echo "<br/><br/></div>";
}
echo "<div class=\"paging\">";
$sc=$ur["cmt_linkperpage"];
$st=floor($p/$sc)*$sc;
$en=$st+$sc;
$g=$st;
if($g<"2") print("");
else
if($g>"0")
print("<a href=comment.php?blog={$_GET["blog"]}&p=".($g-1).">[&lt;]</a> ");
else
print("");

for($g;($g<$en);$g++)
{
if($g==$p)
{
print(" [<b>".$g."</b>] ");
}
elseif($g<=$pg)
{
if($g>"0")
print("<a href=comment.php?blog={$_GET["blog"]}&p=".$g.">".$g."</a> ");
}
else
{
print(" ");
}
}
if($g<=$pg)
print("<a href=comment.php?blog={$_GET["blog"]}&p=".$g.">[&gt;]</a>");
else
print("");
echo "</div><br/><br/>&lt;-<a href=index.php?blog={$_GET["blog"]}>back</a><hr/>";
}
else 
{
die("<title>Error</title><div class=\"blog\">Hei.. You enter here without use a bridge -strike-</div>");
}

?> 