<?php
/********************************
* This Script created by		* 
* Huteri Manza					*
* http://huteri.net				*
* copyright 2009				*
********************************/
?>
<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body bgcolor="lightgreen">
<?php
require("config.php");
if(isset($_POST["submit"]))
{
$_POST["name"]=trim($_POST["name"]);
$_POST["password"]=trim($_POST["password"]);
$_POST["repassword"]=trim($_POST["repassword"]);
if(empty($_POST["name"]) or empty($_POST["password"]) or empty($_POST["repassword"]))
die("<title>Installation Failed</title>Data not complete<br/><a href=install.php>back</a>");
if($_POST["password"]!=$_POST["repassword"])
die("<title>Installation Failed</title>Password not same<br/><a href=install.php>back</a>");

mysql_query("CREATE TABLE blog (
  id smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  title varchar(100) NOT NULL DEFAULT 'No Title',
  text varchar(5000) NOT NULL,
  cat_id smallint(5) unsigned NOT NULL,
  time datetime DEFAULT NULL,
  user_id varchar(100) NOT NULL,
  hit smallint(5) unsigned NOT NULL DEFAULT '0',
uptime datetime DEFAULT '0000-00-00 00:00:00',
  hittoday smallint(5) unsigned DEFAULT '0',
  PRIMARY KEY (id)
) ENGINE=MyISAM") OR DIE("First Table failed to create :".mysql_error());
mysql_query("CREATE TABLE comment (
  id mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  name varchar(100) NOT NULL,
  message varchar(1000) NOT NULL,
  time datetime DEFAULT NULL,
  url varchar(100) DEFAULT NULL,
  blog_id smallint(5) unsigned NOT NULL,
  cat_id smallint(5) unsigned NOT NULL,
  PRIMARY KEY (id)
) ENGINE=MyISAM") or die("Second Table Failed to create :".mysql_error());
mysql_query("CREATE TABLE kategori (
  id mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  kategori varchar(100) NOT NULL,
  PRIMARY KEY (id)
) ENGINE=MyISAM") or die("Third table Failed to create :".mysql_error());
mysql_query("CREATE TABLE user (
  id smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  name varchar(100) NOT NULL,
  password varchar(100) NOT NULL,
  blogperpage tinyint(3) unsigned NOT NULL DEFAULT '5',
  linkperpage tinyint(3) unsigned NOT NULL DEFAULT '4',
  idx_hitonoff tinyint(1) unsigned NOT NULL DEFAULT '1',
  idx_komenonoff tinyint(1) unsigned NOT NULL DEFAULT '1',
  idx_searchsize tinyint(3) unsigned NOT NULL DEFAULT '17',
  idx_textperblog smallint(5) unsigned NOT NULL DEFAULT '50',
  idx_searchmaxlenght smallint(5) unsigned NOT NULL DEFAULT '50',
  blg_komenperpage tinyint(3) unsigned NOT NULL DEFAULT '3',
  blg_komennamesize tinyint(3) unsigned NOT NULL DEFAULT '17',
  blg_komennamelenght smallint(5) unsigned NOT NULL DEFAULT '20',
  blg_komenurlsize smallint(5) unsigned NOT NULL DEFAULT '17',
  blg_komenurllenght smallint(5) unsigned NOT NULL DEFAULT '100',
  blg_komenpesancols smallint(5) unsigned NOT NULL DEFAULT '17',
  blg_komenpesanrows smallint(5) unsigned NOT NULL DEFAULT '8',
  blg_komenpesanlenght smallint(5) unsigned NOT NULL DEFAULT '500',
  cmt_komenperpage tinyint(3) unsigned NOT NULL DEFAULT '5',
  cmt_linkperpage tinyint(3) unsigned NOT NULL DEFAULT '4',
  wr_titlesize tinyint(3) unsigned NOT NULL DEFAULT '17',
  wr_titlelenght smallint(5) unsigned NOT NULL DEFAULT '100',
  wr_textcols smallint(5) unsigned NOT NULL DEFAULT '50',
  wr_textrows smallint(5) unsigned NOT NULL DEFAULT '15',
  wr_textlenght smallint(5) unsigned NOT NULL DEFAULT '5000',
  cssonoff tinyint(1) unsigned NOT NULL DEFAULT '1',
  header varchar(1000) NOT NULL DEFAULT 'Huteri Blog',
  footer varchar(1000) NOT NULL DEFAULT 'Created By Huteri Manza<br/>\r\n&copy; 2009',
  bbcodeonoff tinyint(1) unsigned not null default '1',
  smileyonoff tinyint(1) unsigned not null default '1',
  footon varchar(100) NOT NULL DEFAULT 'Created By Huteri Manza<br/>\r\n&copy; 2009',
  backcolor varchar(20) NOT NULL DEFAULT 'lightgreen',
  time date DEFAULT '0000-00-00',
  idx_lastcmtonoff enum('1','2') NOT NULL DEFAULT '2',
  idx_mosthitonoff enum('1','2') NOT NULL DEFAULT '1',
  idx_mosthittodayonoff enum('1','2') NOT NULL DEFAULT '1',
  idx_jmllastcmt tinyint(3) unsigned NOT NULL DEFAULT '3',
  idx_jmlmosthit tinyint(3) unsigned NOT NULL DEFAULT '3',
  idx_jmlmosthittoday tinyint(3) unsigned NOT NULL DEFAULT '3',
  idx_lastcmtname smallint(5) unsigned NOT NULL DEFAULT '7',
  idx_lastcmtpesan smallint(5) unsigned NOT NULL DEFAULT '20',
  idx_hittodayonoff enum('1','2') NOT NULL DEFAULT '1',
  idx_cmttodayonoff enum('1','2') NOT NULL DEFAULT '1',
  idx_updatenot varchar(100) NOT NULL DEFAULT '[<font color=red>!!</font>]',
  blg_seealsoonoff enum('1','2') NOT NULL DEFAULT '2',
  blg_seealsojml tinyint(3) unsigned NOT NULL DEFAULT '3',
  blg_seealsoorder enum('random','kategori') NOT NULL DEFAULT 'random',
  PRIMARY KEY (id)
) ENGINE=MyISAM") or die("Last Table Failed To create :".mysql_error());
mysql_query("insert into user (id, name, password, time) values ('50','admin','admin',curdate()),('1','{$_POST["name"]}', '{$_POST["password"]}', curdate())") or die("Failed Insert Data".mysql_error());
mysql_query("insert into kategori (kategori) values ('General')") or die("Failed To insert cattegory".mysql_error());
mysql_query("INSERT INTO `blog` (`id`, `title`, `text`, `cat_id`, `time`, `user_id`, `hit`) VALUES ('1','Welcome in Mobile Blog', 'Use this blog as well. \r\n Enjoy the mobile blog  :D\r\n Created by Huteri Manza \r\n http://huteri.net', 1, now(), '50', 0)") or die(mysql_error());
echo "<title>Installation Success</title><div class=\"blog\">Installation Success<br/>Delete install.php file in your server immedietely :)<br/><a href=index.php>NEXT</a></div>";
}
else
{
echo "<title>Instalation script Mobile Blog</title><div class=\"title\"><center>Installation Mobile Blog</center></div><br/><br/>
<div class=\"blog\"><form action=\"install.php\" method=\"post\">
Admin Required >>>><br/>
Admin Name : <input type=\"text\" name=\"name\" maxlenght=\"100\"><br/><br/>
Admin Password : <input type=\"password\" name=\"password\" maxlenght=\"100\"><br/><br/>
Admin Re-Password : <input type=\"password\" name=\"repassword\" maxlenght=\"100\"><br/><br/>
<input type=\"submit\" value=\"Submit\" name=\"submit\"></div><br/><br/><div class=\"header\">Created By Huteri Manza<br/>&copy; 2009</div><hr>";
}
?>
</body>
</html>
