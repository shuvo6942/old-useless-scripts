<?php
/********************************
* This Script created by		* 
* Huteri Manza					*
* http://huteri.net				*
* copyright 2009				*
********************************/
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<?php
session_set_cookie_params(time()+3600);
require("config.php");
require("func.php");
echo "
<html>
<head>";
if($ur["cssonoff"]=="1")
{
echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"style.css\">";
}
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\">
<meta http-equiv=\"CONTENT-LANGUAGE\" content=\"EN-US\">
<meta name=\"revisit-after\" content=\"1 days\">
<meta name=\"robots\" content=\"all,index,follow\">
<meta name=\"Distribution\" content=\"Global\">
<meta name=\"Rating\" content=\"General\">
</head>
<body bgcolor=\"{$ur["backcolor"]}\">
<div class=\"header\">{$ur["header"]}</div><hr>";
?>