<?php
/********************************
* This Script created by		* 
* Huteri Manza					*
* http://huteri.net				*
* copyright 2009				*
********************************/
?>
<?php
echo "<br/><br/><div class=\"header\">{$ur["footer"]}<br/></div>
<br/>
</body>
</html>";
?>