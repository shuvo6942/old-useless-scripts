<?php
/********************************
* This Script created by		* 
* Huteri Manza					*
* http://huteri.net				*
* copyright 2009				*
********************************/
?>
<?php
session_start();
require("header.php");
if(isset($_GET["blog"]) and isset($_GET["editsave"]))
{
if(!isset($_SESSION["user"]))
die("Forbidden Error");
$_POST["title"]=trim($_POST["title"]);
$_POST["text"]=trim($_POST["text"]);
edit_save($_POST, $ur);
}
elseif(isset($_GET["blog"]) and isset($_GET["delete"]))
{
if(!isset($_SESSION["user"]))
die("Forbidden Error");
$_GET["blog"]=trim($_GET["blog"]);
blog_delete($_GET["blog"]);
}
elseif(isset($_GET["blog"]) and isset($_GET["edit"]))
{
if(!isset($_SESSION["user"]))
die("Forbidden. Error");
$_GET["blog"]=trim($_GET["blog"]);
form_edit($_GET["blog"], $ur);
}
elseif(isset($_GET["delnot"]))
{
if(!isset($_SESSION["user"]))
die("forbidden.. Error");

$hut=mysql_query("select title from blog where id='{$_GET["delnot"]}'") or die(mysql_error());
$show=mysql_fetch_row($hut);
$showl=str_replace($ur["idx_updatenot"], "", $show[0]);
mysql_query("update blog set title='$showl' where id='{$_GET["delnot"]}'") or die(mysql_error());
echo "<title>Success</title><div class=\"blog\">Success<br/><a href=index.php>back</a></div>";
}
elseif(isset($_GET["lo"]))
{
session_destroy();
echo "You have been sign out<br/><a href=index.php>Click Here To Continue</a>";
}
elseif(isset($_GET["blog"]))
{
if(!is_numeric($_GET["blog"]))
die("<b>Error</b> : Invalid char detected");
blog($_POST, $_GET["blog"], $ur);
}
elseif(isset($_GET["cat"]))
{
if(!is_numeric($_GET["cat"]))
die("<b>Error</b> : Invalid char detected");
echo "<title>{$ur["name"]} blog</title>";
$show=$ur["blogperpage"];
$p = $_GET['p'];
$count=mysql_query("select count(*) from blog where cat_id='{$_GET["cat"]}'") or die(mysql_error());
$total=mysql_fetch_row($count);
if($total[0]=="0")
die("Zero Result");
$pg=ceil($total[0]/$show);
if($p>$pg && $p!=1)
$p=$pg;
if($p<1)
$p=1;
$j = ($p-1) * $show;
$a=mysql_query("select id, title, text, cat_id, date_format(time, '%d/%m %y') as 'time',time as 'timeorder', hit,hittoday, user_id from blog where cat_id='{$_GET["cat"]}' order by timeorder desc limit $j, $show") or die(mysql_error());
while($b=mysql_fetch_array($a))
{
$cat=catname($b["cat_id"]);
$user=username($b["user_id"]);

$b["text"]=substr($b["text"], 0, $ur["idx_textperblog"]);
echo "<div class=\"blog\"><a href=index.php?blog={$b["id"]}>{$b["title"]}</a>";

echo "<br/>{$b["time"]} | <a href=index.php?cat={$b["cat_id"]}>$cat</a> | $user<br/><i>{$b["text"]}...</i><a href=index.php?blog={$b["id"]}>Read More</a><br/>";
if($ur["idx_hitonoff"]=="1")
{
echo " [Views : {$b["hittoday"]}/".($b["hittoday"]+$b["hit"])."]";
}
if($ur["idx_komenonoff"]=="1")
{
echo " [Comment : ".countcomment($b["id"])."/".jmlkomen($b["id"])."]";
}
if(isset($_SESSION["user"]))
{
$check=strpos($b["title"], "[<font color=\"red\">!!</font>]");
if($check!==false)
{
echo "<br/><a href=index.php?delnot={$b["id"]}>Del Notify</a>";
}
}
echo "<br/></div>";
}
$sc=$ur["linkperpage"];
$st=floor($p/$sc)*$sc;
$en=$st+$sc;
$g=$st;
echo "<div class=\"paging\">";
if($g<"2") print("");
else
if($g>"0")
print("<a href=index.php?cat={$_GET["cat"]}&p=".($g-1).">[&lt;]</a> ");
else
print(" ");

for($g;($g<$en);$g++)
	{
if($g==$p)
	{
print(" [<b>".$g."</b>] ");
	}
elseif($g<=$pg)
	{
if($g>"0")
print("<a href=index.php?cat={$_GET["cat"]}&p=".$g.">".$g."</a> ");
	}
else
	{
print(" ");
	}
	}
if($g<=$pg)
print("<a href=index.php?cat={$_GET["cat"]}&p=".$g.">[&gt;]</a>");
else
print("");
echo "</div><br/><br/>";
search($ur);
listcat();
lastcomment($ur);
mosthit($ur);
mosthitall($ur);
}
elseif(isset($_GET["s"]))
{
$_POST["search"]=mysql_real_escape_string(trim($_POST["search"]));
search_result($_POST["search"], $ur);
}
else
{
echo "<title>{$ur["name"]} blog</title>";
$show=$ur["blogperpage"];
$p = $_GET['p'];
$count=mysql_query("select count(*) from blog") or die(mysql_error());
$total=mysql_fetch_row($count);
$pg=ceil($total[0]/$show);
if($p>$pg && $p!=1)
$p=$pg;
if($p<1)
$p=1;
$j = ($p-1) * $show;
$a=mysql_query("select id, title, text, cat_id, date_format(time, '%d/%m %y') as 'time',time as 'timeorder', hit,hittoday, user_id from blog order by timeorder desc limit $j, $show") or die(mysql_error());
while($b=mysql_fetch_array($a))
{
$cat=catname($b["cat_id"]);
$user=username($b["user_id"]);
$b["text"]=stripslashes($b["text"]);
$b["title"]=stripslashes($b["title"]);
$b["text"]=substr($b["text"], 0, $ur["idx_textperblog"]);
echo "<div class=\"blog\"><a href=index.php?blog={$b["id"]}>{$b["title"]}</a>";

echo "<br/>{$b["time"]} | <a href=index.php?cat={$b["cat_id"]}>$cat</a> | $user<br/><i>{$b["text"]}...</i><a href=index.php?blog={$b["id"]}>Read More</a><br/>";
if($ur["idx_hitonoff"]=="1")
{
if($ur["idx_hittodayonoff"]=="1")
{
echo " [Views : {$b["hittoday"]}/".($b["hittoday"]+$b["hit"])."]";
}
else
{
echo " [Views : ".($b["hittoday"]+$b["hit"])." ]";
}
}
if($ur["idx_komenonoff"]=="1")
{
if($ur["idx_cmttodayonoff"]=="1")
{
echo " [Comment : ".countcomment($b["id"])."/".jmlkomen($b["id"])."]";
}
else
{
echo " [Comment : ".jmlkomen($b["id"])."]";
}
}
if(isset($_SESSION["user"]))
{
$check=strpos($b["title"], $ur["idx_updatenot"]);
if($check!==false)
{
echo "<br/><a href=index.php?delnot={$b["id"]}>Del Notify</a>";
}
}
echo "<br/></div>";
}
echo "<div class=\"paging\">";
$sc=$ur["linkperpage"];;
$st=floor($p/$sc)*$sc;
$en=$st+$sc;
$g=$st;
if($g<"2") print("");
else
if($g>"0")
print("<a href=index.php?p=".($g-1).">[&lt;]</a> ");
else
print(" ");

for($g;($g<$en);$g++)
	{
if($g==$p)
	{
print(" [<b>".$g."</b>] ");
	}
elseif($g<=$pg)
	{
if($g>"0")
print("<a href=index.php?p=".$g.">".$g."</a> ");
	}
else
	{
print(" ");
	}
	}
if($g<=$pg)
print("<a href=index.php?p=".$g.">[&gt;]</a>");
else
print("");
echo "</div><br/><br/>";
search($ur);
listcat();
lastcomment($ur);
mosthit($ur);
mosthitall($ur);
}
require("footer.php");
?>