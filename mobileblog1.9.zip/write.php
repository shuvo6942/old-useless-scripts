<?php
/********************************
* This Script created by		* 
* Huteri Manza					*
* http://huteri.net				*
* copyright 2009				*
********************************/
?><?php
session_start();
require("header.php");
if(!isset($_SESSION["user"]))
die("You can't enter here");

if(isset($_POST["submit"]))
{
$_POST["title"]=trim($_POST["title"]);
$_POST["kategori"]=trim($_POST["kategori"]);
$_POST["text"]=trim($_POST["text"]);
if(empty($_POST["title"]) or empty($_POST["text"]) or empty($_POST["kategori"]))
die("<title>Failed To create Item</title><div class=\"blog\">Data Not Complete<br/><a href=write.php>back</a></div><hr>");
$uid=userid($_SESSION["user"]);
$cat=catid($_POST["kategori"]);
mysql_query("insert into blog (title, text, user_id, time, cat_id) values ('{$_POST["title"]}', '{$_POST["text"]}', '$uid', now(), '$cat')");
echo "<title>Create Item Success</title><div class=\"blog\">Create Item Success<br/><a href=index.php>next</a></div><hr>";
}
else
{
echo "<title>Create a Item</title><center><div class=\"title\">Create a Item</div></center><br/><br/><div class=\"blog\">
<form action=\"write.php\" method=\"post\">
Title :<br/>
<input type=\"text\" name=\"title\" maxlenght=\"{$ur["wr_titlelenght"]}\" size=\"{$ur["wr_titlesize"]}\"><br/>
<br/>
Text : <br/>
<textarea cols=\"{$ur["wr_textcols"]}\" rows=\"{$ur["wr_textrows"]}\" wrap=\"virtual\" name=\"text\" maxlenght=\"{$ur["wr_textlenght"]}\"></textarea>
<br/>
<br/>
Cattegory : <br/>
<select name=\"kategori\">";
$a=mysql_query("select * from kategori order by id") or die(mysql_error());
while($b=mysql_fetch_array($a))
{
echo "<option value=\"{$b["kategori"]}\">{$b["kategori"]}";
}
echo "</option></select>";
echo "<br/><br/><input type=\"submit\" name=\"submit\" value=\"Create Item\"></form>";
echo "<br/><a href=\"index.php\">Cancel</a></div><hr>";
}
require("footer.php");
?>
