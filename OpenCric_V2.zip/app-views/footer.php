<div id="footer">Copyright &copy; <?php echo date('Y');?> <?php echo $_SITE['name'];?> - All Rights Are Reserved.</div>
</body>
</html>