<?php

$_SITE=array(
	'name' => 'OpenCric',
	'tagline' => 'Live Cricket Score & Fixtures!',
	'url' => 'http://cricket.lik3r2.ml',
	'desc' => 'OpenCric allows you to create a full featured live cricket score mobile site for free! By UpCoders team!',
	'fb_url' => 'https://web.facebook.com/Khalequzzaman.Labonno/'
	);
