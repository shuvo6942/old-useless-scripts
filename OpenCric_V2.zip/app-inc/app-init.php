<?php
/* Bismillah! */
define("MAC_ROOT",dirname(dirname(__FILE__)). "/");
require_once MAC_ROOT.'app-inc/app-config.php';
require_once MAC_ROOT.'app-lib/classes/cricket.class.php';
require_once MAC_ROOT.'app-lib/functions.php';