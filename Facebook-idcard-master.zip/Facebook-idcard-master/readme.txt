@author		:	Giriraj Namachivayam
@date 		:	Mar 01, 2013
@demourl	:	http://ngiriraj.com/socialMedia/fbidcard/
@document	:	http://ngiriraj.com/work/

Facebook ID card maker:
=======================
/* CONFIGURE */
$facebookAppId      = '321176691239227'; 
$facebookAppSecret  = 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'; 
$return_url         = 'http://ngiriraj.com/socialMedia/fbidcard/'; #Redirect_uri
$idDir		    = 'fbcards/'; #Dir path to store ID card images
$fbPermissions      = 'publish_stream,user_hometown,user_birthday';#Required facebook permissions
$fbTemplate_img     = 'fbidcard.png'; #Facebook standared id card image template
$font               = 'DidactGothic.ttf'; #Font used


