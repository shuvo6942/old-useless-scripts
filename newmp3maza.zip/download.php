<?php
/* Script developed by pankaj*/

include 'config.php';
$id=$_GET['id'];
if(!$id){
die('<br/>Error: id wrong.');
}
$headers = get_headers('http://newmp3maza.com/files/download/id/'.$id.'',1);
$dl = str_replace(' ','%20',$headers['Location']);
// file name n replace
$filename = basename($dl);
$filename = str_ireplace('newmp3maza.com',''.$sitename.'',$filename);
$filename = str_replace(array('%20','_'),' ',$filename);
// dir make
$dir = "pankajbd_com";
if(!is_dir($dir)){
mkdir($dir);
chmod($dir,0777);
} 

$save = ''.$dir.'/'.$filename.'';
$file_extension=pathinfo($save, PATHINFO_EXTENSION);
if(!file_exists($save)) {
if($file_extension=="mp3"){
if(copy($dl,$save)){
if ($voice == 'ON') { file_put_contents(''.$save.'',    file_get_contents(''.$save.'').   file_get_contents('voice.mp3')); }
@include 'tag.php'; }
}  else {
copy($dl,$save); }
header("Location: /$save");
} 
 else {
header("Location: /$save");
}
?>