<?php
  error_reporting(0);
include'd.php';
  include 'header.php';
  include 'home.php';
  include 'footer.php';?>