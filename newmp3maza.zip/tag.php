<?php
include ('config.php');
$mp3_tagformat = 'UTF-8';

require_once('getid3/getid3.php');
$mp3_handler = new getID3;


$info = $mp3_handler->analyze($save);
$head = $info['id3v2']['comments'];
$mp3_tagformat = 'UTF-8';
$mp3_title = str_ireplace('newmp3maza.com',$sitename,$head['title'][0]);
$mp3_album = str_ireplace('newmp3maza.com',$sitename,$head['album'][0]);
$mp3_artist = str_ireplace('newmp3maza.com',$sitename,$head['artist'][0]);
$mp3_year = str_ireplace('newmp3maza.com',$sitename,$head['year'][0]);
$mp3_genre = str_ireplace('newmp3maza.com',$sitename,$head['genre'][0]);
$mp3_comment = str_ireplace('newmp3maza.com',$sitename,$head['comment'][0]);
$mp3_publisher = str_ireplace('newmp3maza.com',$sitename,$head['publisher'][0]);

$mp3_handler->setOption(array('encoding'=>$mp3_tagformat));
require_once('getid3/write.php');


$mp3_writter = new getid3_writetags;
$mp3_writter->filename       = $save;


$mp3_writter->tagformats     = array('id3v1', 'id3v2.3');
$mp3_writter->overwrite_tags = true;
$mp3_writter->tag_encoding   = $mp3_tagformat;
$mp3_writter->remove_other_tags = true;


$mp3_data['title'][]   = $mp3_title;
$mp3_data['artist'][]  = $mp3_artist;
$mp3_data['album'][]   = $mp3_album;
$mp3_data['year'][]    = $mp3_year;
$mp3_data['genre'][]   = $mp3_genre;
$mp3_data['comment'][] = $mp3_comment;
$mp3_data['publisher'][] = $mp3_publisher;

$mp3_data['attached_picture'][0]['data'] = file_get_contents('album_art.jpg');
$mp3_data['attached_picture'][0]['picturetypeid'] = "image/jpeg";
$mp3_data['attached_picture'][0]['description'] = "Mp3 Cover Image by pankaj";
$mp3_data['attached_picture'][0]['mime'] = "image/jpeg";



$mp3_writter->tag_data = $mp3_data;

$mp3_writter->WriteTags();
?>
