<?php
include'config.php';
$file=preg_replace('|<script(.*?)</script>|is','',$file);
$file = preg_replace('|<div class="ad(.*?)</div>|is','',$file);
$file = preg_replace('|<div class="logo">(.*?)</div>|is','<div class="logo"><a href="'.$siteurl.'"><img width="100%" alt="'.$sitename.'" src="/images/logo.png" /></a></div>'.$search.'',$file);
$file=str_replace('SKYiTech.com','PANKAJBD.COM',$file);
$file=str_ireplace('NewMp3Maza.com',$sitename,$file);
$file=str_replace('newmp3maza.css','pankajbd.css',$file);
$file = preg_replace('|<form method="get"(.*?)</form>|is','',$file);
$file = str_replace('href="/','href="'.$siteurl.'/',$file);
$file = preg_replace('|<div class="f1">(.*?)</html>|is','',$file); 
$file=preg_replace(array('|<img src="/siteuploads(.*?)/>|','|<p class="showimage">(.*?)</p>|'),'',$file);
?>