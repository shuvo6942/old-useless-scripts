<?php  include'config.php';
  echo'<h2><a href="'.$siteurl.'">'.$sitename.'</a><br/>Developed By <a href="//facebook.com/pankaj.kumar.420"><font color="lime">Pankaj</a></h2>';
include'online.php';
echo'</body> </html>';  ?>