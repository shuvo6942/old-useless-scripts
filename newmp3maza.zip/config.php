<?php
if
(!file_exists("pankajbd.php")) {
echo "Please install before!";
exit;
}
include'pankajbd.php';

$search='<div class="search"><form action="/search.php" method="get"><input type="text" name="find" id="find" value="" size="20" /><select name="ext" id="ext"><option value="ALL" selected="selected">ALL</option>
<option value="JPG">JPG</option>
<option value="GIF">GIF</option>
<option value="MP3">MP3</option>
<option value="3GP">3GP</option>
<option value="MP4">MP4</option>
<option value="NTH">NTH</option>
<option value="THM">THM</option>
</select><input type="submit" name="commit" value="Search" /></form></div>'; 
 ?>