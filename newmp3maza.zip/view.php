<?php
/* Script created by pankaj */

$link='http://newmp3maza.com/'.$_GET['view'];
$file = file_get_contents(''.$link.'');
include 'pankaj.php'; 
echo $file; 
include 'footer.php';  


?>