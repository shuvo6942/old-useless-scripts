<? include'config.php';  
echo'<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="title" content="'.$sitename.' :: Free HD Videos - Bollywood HD Videos, Mobile Ringtones, Wallpapers, Themes, Games, Softwares, Mp3 Songs, Videos, Mobile Live TV, Pc Downloads, iPhone Download, More... Visit PANKAJBD.COM" />
<meta name="robots" content="index, follow" />
<meta name="language" content="en" />
<title>'.$sitename.' :: Free HD Videos - Bollywood HD Videos, Mobile Ringtones, Wallpapers, Themes, Games, Softwares, Mp3 Songs, Videos, Mobile Live TV, Pc Downloads, iPhone Download, More... Visit PANKAJBD.COM</title>
<link rel="shortcut icon" href="/favicon.ico" />
<link href="/css/pankajbd.css" type="text/css" rel="stylesheet"/>
</head>
<body>
<div class="logo">
	<a href="'.$siteurl.'"><img alt="NewMp3Maza.com" src="/images/logo.png" width="100%" /></a></div>
<div id="mainDiv">
	<div class="bkmk"><b>BookMark Us ! PANKAJBD.COM</b></div>';
 echo $search;
 ?>