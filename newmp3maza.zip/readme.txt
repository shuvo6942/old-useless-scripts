paid + free host 100% working

if you use  a free host so must use http://hostp.ga or http://pkhost.gq else not work .:(
 
Installing:
 upload your host & make extract. 
After complete Now go http://YOUR_SITE_URL/install.php than Fill in the form and click install.
 

Finally Your site is ready :)


more script visit & bookmark now http://pankajbd.com