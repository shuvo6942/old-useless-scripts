<?php
/* Script by pankaj */
$file = file_get_contents('http://newmp3maza.com/files/search/?'.$_SERVER['QUERY_STRING'].'');
$file=str_replace('http://newmp3maza.com',''.$siteurl.'',$file);
include 'pankaj.php';
echo $file;
include 'footer.php';?>