<?
  $c_time = (1200);
  $sec = "$c_time";
  $folder = "pankajbd_com/";
  del_old_files($folder,$sec);
  function del_old_files($folder,$time)
  {
  foreach(glob($folder."*") as $rmdir)
  foreach(glob($folder."/*") as $file)
  {
  if(is_dir($file))
  del_old_files($file,$time);
  else
  if(filemtime($file)<time()-$time)
  unlink($file);
  @rmdir("$rmdir");
  }
  }
  ?>