<?php
/* script created by pankajbd.com */
$page = file_get_contents('http://newmp3maza.com/');
$page = preg_replace('|<!DOCTYPE html(.*?)<!-- SKYiTech.com :: Display Random files -->|is','',$page);
$page = str_replace('href="/','href="'.$siteurl.'/',$page);
$page = preg_replace('|<h2>Sponsor Sites</h2>(.*?)</html>|is','',$page);
$page=str_ireplace('http://newmp3maza.com',$siteurl,$page); 
echo $page; 
 ?>