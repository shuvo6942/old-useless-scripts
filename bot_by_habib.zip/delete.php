<?php
$file = "error_log";
if (!unlink($file))
?>