<?php get_header(); ?>

 <div class="block_posts">
        <h2> <?php single_cat_title(); ?> Archives </h2>
		        <ul class="rpul">  <?php 
                if (have_posts()) : while (have_posts()) : the_post();

                    get_template_part('post', 'homepage');
                    
                endwhile;
                
                else :
                    get_template_part('post', 'noresults');
                endif; 
                
                get_template_part('navigation');
            ?> 
<ul></div> <?php get_sidebar();?>
 

<?php get_footer(); ?>
