		  <div id="ow-search">
	<form method="get" action="<?php bloginfo( 'home' ); ?>/">
	  <input type="text" class="inp-text" name="s" value="<?php the_search_query(); ?>" />
	  <input type="submit" class="inp-btn" value="Search" />
	</form>
      </div>