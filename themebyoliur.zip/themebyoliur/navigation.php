<!-- ADD Custom Numbered Pagination code. -->
<?php echo '<div class="wp-pagenavi">'; if(function_exists('pagenavi')) { pagenavi(); } 
echo '</div>'; ?>
   
