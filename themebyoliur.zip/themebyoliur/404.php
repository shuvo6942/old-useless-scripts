<?php get_header(); ?>
          <div class="entrybox" style="padding:7px;margin:3px;border:1px solid #ccc;background-color:#fff;"> The page you requested could not be found.  </div><!-- #main -->
    
<?php get_footer(); ?>