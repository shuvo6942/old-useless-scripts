<?php get_header(); ?>

	<div id="content">
		
			<h3 class="highlight">
				<?php if ( is_category() ) : ?>
					<?php single_cat_title(); ?> Archives
				<?php elseif ( is_day() ) : ?>
					Archive for <?php the_time( 'F jS, Y' ); ?>
				<?php elseif ( is_month() ) : ?>
					Archive for <?php the_time( 'F, Y' ); ?>
				<?php elseif ( is_year() ) : ?>
					Archive for <?php the_time('Y'); ?>
				<?php endif; ?>
			</h3><div class="postt">
		

		 <?php 

                if (have_posts()) : while (have_posts()) : the_post();

                     

                    get_template_part('post', 'category');

                endwhile;

                

                else :

                    get_template_part('post', 'noresults');

                endif; 

                

                get_template_part('navigation');

            ?></div></div> 

<?php get_footer(); ?>