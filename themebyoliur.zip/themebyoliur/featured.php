<div class="block_posts"><h2>Featured post</h2><ul class="rpul"><?php query_posts('posts_per_page=1&cat=2'); if (have_posts()) : while (have_posts()) : the_post();
get_template_part('post', 'homepage');
                    endwhile;
                               else :
                    get_template_part('post', 'noresults');
                endif; ?> <?php wp_reset_query(); ?> 
		</ul>
</div>

<div class="block_posts"><h2>Hot post</h2><ul class="rpul"><?php query_posts('posts_per_page=3&cat=3'); if (have_posts()) : while (have_posts()) : the_post();
                    get_template_part('post', 'homepage');                    
                endwhile;                
                else :
                    get_template_part('post', 'noresults');
                endif; ?> <?php wp_reset_query(); ?></ul>
</div>