Thank you for Downloading Trickbd Mobile Theme by TechFevo. 
If you face any difficulty, feel free to open new ticket  in our support forums (https://techfevo.com/),
our support staff will be more than happy to assist you.

Don't forget to check our in dept WordPress tutorials from
here: https://techfevo.com/

Know more about Trickbd mobile Nulled Version here:
https://mythemeshop.com/themes/sociallyviral/

Happy Blogging!

-
TECHFEVO Team
