<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<meta charset="UTF-8">
<head>
<title><?php if ( is_single() ) { 
			single_post_title(); echo ' | '; bloginfo( 'name' );
		} elseif ( is_home() || is_front_page() ) {
			bloginfo( 'name' ); echo ' | ' ; bloginfo( 'description' ); 
		} elseif ( is_page() ) {
			single_post_title( '' ); echo ' | '; bloginfo( 'name' );
		} elseif ( is_search() ) {
			echo 'Search results | '; bloginfo( 'name' );
		} elseif ( is_404() ) { 
			echo 'Not Found | '; bloginfo( 'name' );
		} else { 
			wp_title( '' ); echo ' | '; bloginfo( 'name' ); } ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<link href="<?php bloginfo( 'template_url' ); ?>/style.css" rel="stylesheet" type="text/css" media="all, handheld" />
<link rel="icon" type="image/png" href="<?php bloginfo( 'template_url' );?>/img/t.png" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" /> 
<script type="text/javascript" src="<?php bloginfo( 'template_url' );?>/js/image_resizer.js"></script>   
<?php echo '<!--- Need Theme Concact fb.me/oliurbd9 | Themes Made By Oliur Rahman --->'; ?>
<?php wp_head(); ?> </head>
<body>
<?php
if ( is_user_logged_in() ) {
	echo '<div class="block_top_menu">
		<div class="menu-top-pc-logged-container">
			<ul class="menu" id="menu-top-pc-logged">
				<li><a href="/wp-admin">Dashboard</a></li>
				<li><a href="/wp-admin/profile.php">Profile</a></li>

				<li><a href="/wp-admin/post-new.php">New Post</a></li>

			</ul>

		</div>

	</div>';

}  ?>
<div class="block_header">

        <table class="header_logo" width="100%">

            <td>

                <a href="<?php bloginfo('url'); ?>"><img src="http://trickbd.com/wp-content/uploads/2015/08/trickbd-logo.png"/></a></td><td width="50px" align="right"> <?php

if ( is_user_logged_in() ) {

	 global $current_user;
      get_currentuserinfo();
      echo 'hi, ' . $current_user->user_login . "\n";
} else { echo '<a class="login_box" href="/wp-login.php">Login</a></td><td width="50px" align="right"><a class="login_box" href="/wp-login.php?action=register">Signup</a>';
} ?></td></table><div class="main_nav"><div class="menu-mobile-nav-container"><ul id="menu-mobile-nav" class="menu"><li class="menu-item current_page_item menu-item-home "><a href="<?php bloginfo('url'); ?>">Home</a></li></ul></div></div></div>