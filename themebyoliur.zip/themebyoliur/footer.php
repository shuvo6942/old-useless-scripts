<div class="block_fotter">

	<div class="footer_left">

	<div class="menu-footer-mobile-left-container"><ul id="menu-footer-mobile-left" class="menu"><li id="menu-item-36" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-36"><a href="/about">About Us</a></li>

<li id="menu-item-35" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-35"><a href="/advertise">Advertise</a></li>

<li id="menu-item-34" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-34"><a href="/contact">Contact Us</a></li>

<li id="menu-item-33" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-33"><a href="/terms">Terms of Use</a></li>

</ul></div>	</div>

	<div class="footer_right">

	<div class="menu-footer-mobile-right-container"><ul id="menu-footer-mobile-right" class="menu"><li id="menu-item-37" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-37"><a href="/rights">User Rights</a></li>

<li id="menu-item-38" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-38"><a href="/privacy">Privacy Policy</a></li>

<li id="menu-item-39" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-39"><a href="/faq">FAQ</a></li>

<li id="menu-item-40" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-40"><a href="/copyright">Copyright issues</a></li>

<?php if ( is_user_logged_in() ) { ?><li id="menu-item-41" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-41"> <a href="<?php echo wp_logout_url( get_permalink() ); ?>"><?php global $current_user;

      get_currentuserinfo();

      echo 'Logout (' . $current_user->user_login."\n"; echo ')';

?></a>

</li><?php } ?>

</ul></div>	</div>

<div class="switch_pc"><small><a rel="external" data-ajax="false" href="http://techfevo.com" class="am-switch-btn godesktop"> Nulled By Techfevo.com</a></small></div>

</div>

</body>



</html>
