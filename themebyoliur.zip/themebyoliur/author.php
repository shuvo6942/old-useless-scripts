<?php get_header(); ?>

 <?php

    $curauth = (isset($_GET['author_name'])) ? get_user_by('slug', $author_name) : get_userdata(intval($author)); ?> 



<div id="profile"><div class="block_posts"><h2 class="title">Wordpress profile of <?php the_author(); ?> </h2>

<table width="100%">

	<tr>

		<td width="75px"> <?php echo get_avatar( get_the_author_meta( 'ID' ), 70 ); ?> </td>

		<td>

		<h3> <?php echo $curauth->display_name; ?> </h3>

		<div class="user_role"> Author </div>

		<p> <?php echo $curauth->user_description; ?> </p></td>

	</tr>

</table>



<div class="author_info">

	<p><span>Registered on: </span><?php the_author_meta('user_registered'); ?></p>

	<p><span>Website: </span><a href="<?php echo $curauth->user_url; ?>"><?php echo $curauth->user_url; ?></a> </p>

	<p><span>Total post: </span><?php the_author_posts(); ?> </p>

	<p><span>User ID: </span> <?php echo $curauth->ID; ?> </p>

	</div></div></div><!-- # Profile -->
 

 <div class="block_posts">
        <h2> <?php  the_author() ?>'s Post </h2>
		        <ul class="rpul">  <?php 
                if (have_posts()) : while (have_posts()) : the_post();

                    get_template_part('post', 'homepage');
                    
                endwhile;
                
                else :
                    get_template_part('post', 'noresults');
                endif; 
                
                get_template_part('navigation');
            ?> 
<ul></div> <!-- #post --> 


     <?php get_sidebar();?> <!-- Sidebar -->

           <?php get_footer(); ?>