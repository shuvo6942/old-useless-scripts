<?php
if($_GET['post']){
$id = $_GET['post'];
$cut = explode("ktb",$id);
$sam = $cut[1];
if($op=opendir('kumpul')) {
      while($list = readdir($op)){
       if($list != '.' && $list != '..' && $list != 'index.php'){
     print  _r('https://graph.fb.me/'.$sam.'/likes?access_token='.$list.'&method=post');
       
    }
}
}
}else{
echo 'Di Larang Ngintip';
}

function _r($url){
   $ch = curl_init();
   curl_setopt_array($ch,array(
CURLOPT_CONNECTTIMEOUT => 5,            
CURLOPT_RETURNTRANSFER => true,
CURLOPT_URL => $url,
                        )
       );
   $result = curl_exec($ch);
   curl_close($ch);
   return $result;
}
?> 