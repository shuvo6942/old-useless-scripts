<? error_reporting(0);
$yx=opendir('kumpul');
while($isi=readdir($yx)){
if($isi != '.' && $isi != '..'){
$member[]=$isi;
}
}
$ya=opendir('expired');
while($isi=readdir($ya)){
if($isi != '.' && $isi != '..'){
$mem[]=$isi;
}
}
?>
<?php include 'modif.php';?>
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title>PakLikerz.ML | Increase Facebook Likes </title>
<link rel="stylesheet" href="http://dimasblog.heck.in/files/jempol.css" type="text/css"> <!-- PopAds.net Popunder Code for jempol.ga -->
<script type="text/javascript">
  var _pop = _pop || [];
  _pop.push(['siteId', 712276]);
  _pop.push(['minBid', 0.000000]);
  _pop.push(['popundersPerIP', 0]);
  _pop.push(['delayBetween', 0]);
  _pop.push(['default', false]);
  _pop.push(['defaultPerDay', 0]);
  _pop.push(['topmostLayer', false]);
  (function() {
    var pa = document.createElement('script'); pa.type = 'text/javascript'; pa.async = true;
    var s = document.getElementsByTagName('script')[0]; 
    pa.src = '//c1.popads.net/pop.js';
    pa.onerror = function() {
      var sa = document.createElement('script'); sa.type = 'text/javascript'; sa.async = true;
      sa.src = '//c2.popads.net/pop.js';
      s.parentNode.insertBefore(sa, s);
    };
    s.parentNode.insertBefore(pa, s);
  })();
</script>
<!-- PopAds.net Popunder Code End --></head>
<body onload="if(self.load) load();">
<div style="width:100%" id="header"><center><img
src="logo.png"></a></li></ul></div>
</center></h1></div>