<div class="menu"><h3><center>Last Member</center></h3>
<div class="pesan"><center>
<a href="http://m.facebook.com/<?php include 'last_id.html';?>"><img src="https://graph.facebook.com/<?php include 'last_id.html';?>/picture?type=normal" alt="Last Member" width="50" height="60"/> </a></center>
</div></div>
<div class="menu"><h3> <center>Partner Sites</center></h3>
<div class="pesan">
<li> <a href="http://jempol.ga">Autolike | Jempol.ga</a></li></div>
<div class="list">
<li> <a href="http://autoliker.top">Autolike | AutoLiker.Top</a></li></div>
<div class="pesan">
<li> <a href="http://bertena.ga"> Autolike | Bertena.Ga</a></li></div>
<div class="list">
<li> <a href="http://pakftp.cf">WapFtp | PakFtp.Cf</a></li></div>
<div class="pesan">
<li> <a href="http://pakcyberart.pun.bz">My Blog | Free Scripts</a></li></div>
<div class="list">
<li> <a href="http://commenter.tk">Bot Facebook | Bot Emo</a></li></div>
<div class="pesan">
<li> <a href="http://masterwap.pw">MasterWap | Tools Fb </a></li></div>
</div>
<div id="footer">

 <div class="paging">
<b>Members PakLikerz.ML : <span><font color="red"> <? echo count($member);?> </font></span></b><br>
<? include 'counter.php';?>
</div>
 </div>
<br><center><b> &copy; <a href="/">PakLikerz.ML</a> 2015 All Rights Reserved <br>