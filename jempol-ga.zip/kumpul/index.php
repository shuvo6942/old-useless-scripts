<center>Ente mau ngapain sih om?<br>
ko pake buka folder ini segala sih?<br><br>
<font color="red"><b>Dilarang Nyolong Token tau om</center>