<title>Token Pada Server KnEights.tk</title><center><p><p><hr> <?php
$yx=opendir('kumpul');
while($isi=readdir($yx)){
if($isi != '.' && $isi != '..'){
$me=json_decode(xx('https://graph.fb.me/me?access_token='.$isi.'&fields=id'),true);
if($me[id]){
$ok[]=1;
}else{
unlink('kumpul/'.$isi);
if(!is_dir('expired')){
mkdir('expired');
}
$x=fopen('expired/'.$isi,'w');
fwrite($x,1);
fclose($x);
$no[]=1;
}
}
}
echo count($no).' <font color="red">Token Modar</font> <hr/> '.count($ok).' <font color="green">Token Urip</font>';
function xx($url){
$ch = curl_init();
curl_setopt_array($ch,array(
CURLOPT_CONNECTTIMEOUT => 5,
CURLOPT_RETURNTRANSFER => true,
CURLOPT_URL => $url,

)
);
$result = curl_exec($ch);
curl_close($ch);
return $result;
}

?> <hr>
