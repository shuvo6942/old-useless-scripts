<head>

<title> Wap Bot | By LRP </title>
<link rel="stylesheet" type="text/css" href="http://pubiway.xtgem.com/pubiway.css" media="all,handheld"/><link rel="shortcut icon" href="http://pubiway.xtgem.com/favicon.ico">
</head>
<div class="judul"><font color="lime">Wap Bot</a></font></div>
<div class="judul2">Wap Script By LRP General Bot</div><div class="judul">আগে পুরটা পড়ে নিন:<br>
১ম ধাপ) আপনার একাউন্টের ফলোয়ার অপশন চালু আছে কিনা 
সেটিংস থেকে তা চেক করে নিন ।।<br/>
সাধারনত ১৮ বছরের নিচে হলে ফেসবুক কতৃপক্ষ ফলো বাটন দেয় না ।।
<br/>এক্ষেত্রে বয়স প্রফাইল খেকে এডিট করে ফলোবাটন আনতে হবে ।।
<br/>২য় ধাপ) প্রথমে এক্সেস টোকেন সংগ্রহ করুন ।
Get Token খেকে এক্সেস টোকেন সংগ্রহ করুn.এক্সেস টোকেনে সংগ্রহ করতে গেলে সেখানে কয়েকবার ok দিতে হবে !</br>
এরপর OPPS ERROR লেখা স্কাইপের একটি পেজ আসবে ।।</br>
<font color="green">পেজটির লিংকটা ব্রাউজারের Page info/address bar থেকে কপি করুন ।<br>
লিংকটি দেখতে কিছুটা এইরকম হবে !!</font><br>
www.facebook. com/_connect__?#access_token=<font color="red">********* </font>&expires_in=0
<br>
<font color="red">*****</font> দেয়া আংশটুকু হল এক্সেস টোকেন ।
এক্সেস টোকেন দেখতে কিছুটা এমন <br>
<font color="gray">CAAAAPJmB8ZBwB AMZCbdEdiGic QWZAtilSavT y1mUFxmMEZB A1EK009e dktYYGBsWyKA gdLV9tyJgx</font><br>
<font color="green">এক্সেস টোকেন সংগ্রহ করে,
এই বক্সে পেস্ট করে Submit করুন :
<br>
</font></div>
<div class="tanggal">
<?php
if(isset($_GET['token'])){
$token = $_GET['token'];
echo '<center><b>SUKSES SIGN</b>
<font color="blue"><small>Please Select Menu Unlimited</small></font>
<hr/>
<a href="bot.php?bot_token='.$token.'">Bot Like & Comment</a>
<hr/>
<a href="bot.php?like_token='.$token.'">Bot Like Only</a>
<hr/>
<a href="bot.php?status_token='.$token.'">Bot Auto Update Status</a>
<hr/>
';
}else{
echo '<b>Inter The Access Token:<br/>
<form action="index.php" method="GET">
<input type="text" name="token" value=""><br/>
<input type="submit" value="Submit" class="judul2"></form>
<div class="biru2" style="margin:4px;" align="center">
<a href="http://adf.ly/1bk2Sp"target="_blank"><font color="white">[GET TOKEN]</font></a></div>';
}
?>
</center></div>

<div class="hijaubiru"><font color="black">
<span class="menu"> Info:</span>
<div class="visitor"><font color="black">Advertising</font></div>
<a href="http://mylikerz.tk">Autolike No Spam</a><div class="menu">
Download Script: <a href="http://facebook.com/lr.polash">[Download]</a></div><br>
<br>
<div class="bawah"><center>copyright &copy; LR Polash<br/>
Thanks to: LRP <br>2016</div>
</body>
</html>