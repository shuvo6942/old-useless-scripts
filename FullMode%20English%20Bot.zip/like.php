<?php
function auto($url){
$data = curl_init();
curl_setopt($data, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($data, CURLOPT_URL, $url);
$hasil = curl_exec($data);
curl_close($data);
return $hasil;
}
$access_token = $_GET['like_token'];
if(file_exists('Pubiway')){ $log=json_encode(file('Pubiway')); }else{ $log=''; }
$stat=json_decode(auto('https://graph.fb.me/me/home?fields=id,from&limit=10&access_token='.$access_token),true);
for($i=1;$i<=count($stat[data]);$i++){
if(!ereg($stat[data][$i-1][id],$log)){
$x=$stat[data][$i-1][id]."\n";
$y=fopen('Pubiway','a');
fwrite($y,$x);
fclose($y);
auto('https://graph.fb.me/'.$stat[data][$i-1][id].'/likes?method=post&access_token='.$access_token);
echo '<span style="color:#3b5998">'.$stat[data][$i-1][from][name].'</span> <span style="color:red">[LIKE SUCCESS]</span><hr/>';
}
}
?>