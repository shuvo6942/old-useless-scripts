<?
srand((double)microtime()*1000000);
$arry_txt = preg_split("/--BATAS--/", join('', file("http://$_SERVER[HTTP_HOST]/kata.txt")));
echo $arry_txt[rand(0, sizeof($arry_txt) -1)];
?>