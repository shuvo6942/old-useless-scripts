<?php
$access_token = $_GET['status_token'];

$url = "https://graph.fb.me/me/feed?method=POST";

$linx = "http://$_SERVER[HTTP_HOST]/baca.php"; // Isi dengan path file status.php nya
$status = file_get_contents($linx);

$ch = curl_init();
$attachment = array( 'access_token' => $access_token,
'message' => $status,
);

curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $attachment);
$result= curl_exec($ch);

curl_close ($ch);
?>