<?php
//Script Edited by Danny Wiradhika Anda Edited By Pubiway
error_reporting(0);
########SETTING BOT########
##Untuk menonaktifkan salah satu BOT (Mode OFF), Ubah true menjadi false##


$bot['like'] = true; //BOT Like Mode ON
$bot['ck_k'] = true; //BOT Komentar Kondisi Mode ON
$bot['ck_u'] = true; //BOT Komentar Umum Mode ON
$bot['time'] = true; //BOT Waktu & Tanggal Mode ON
$bot['aces'] = $_GET['bot_token'];
########END OF SETTING########

com_like($cl,$ck,$cu,$tm,$access_token);


com_like($bot['like'],$bot['ck_k'],$bot['ck_u'],$bot['time'],$bot['aces']);

function cmn($text,$ck,$cu){
##Silahkan ganti komentar diantara tanda petik sesuai selera anda##
$cmn_umum = array("Not bisatidur because remember it's
normal girlfriend ... not good to eat
because it is unusual ingatpacar ... tp
kalo be offline because Keith
comments on statusKak <name>
luarbiasa..xixixixixi new: D",
                  "Do ol kept <name>, expensive
electricity bills you know now: D",
"You're great <name>, Your status
makes me like a magnet to give a
thumbs up and koment pobud,
jiahhh @ _ @ ",
" Learning first
there Kak <name>, do fb'an then!
Wkwkwk -_-",
"What time is it <name>? Still fb'an
wrote, ate there once, I'll Looh
sick! > _ <",
"Oo .. You to the name <name> qo 'different from that in the photo at right? -_-",
"<name>, status makes me heartbroken, huhuhu T_T",
"Ish, you're cool huh status <name>, like his ^_^",
"Howdy <name>? I've waited since last year, you know just to comment and give a thumbs distatus you @_@",
"Yach nga say wow? Importantly give thumbs + koment first dech :D",
"Hadeuh ,, actually I also like to write like having your status <name>, but first you, yes i like this post ^_^",
"<name>, seriously, I nga nanya !! : D: D * lariii ",
"The period of the <name>? I must continue to rise to the highest building, then jump while saying wow that? : D ",
"Do not upset ya <name> if I ngoment distatus you, because I'm the fans bangeeeeeets ma ye +_ + ",
"Good news <name>, Telkomsel is now free calls to all operators, do I type *808* no * a statement of the purpose of the village #capable of good luck: D ",
"Whatever your status <name>, my thumb and koment pobud there for you ^ _ ^ ",
"Well you are all cool huh status <name>, ta love thumb and koment again dach ^_^",
"Oo..jadi you the name <name>? One where? Stay where? What are you doing now? With who? Girls or guy? girlfriend huh? It's been eaten yet? Unyu2 the buildup, the child ready? qo nga Lha responsible, well pingin cry, ah cool nga -_- ",
"thumb and komentku Although late, I'll come in your status pobud <name>, because it is something you really dach for me ^_^ ",
"Hi <name> passenger ngoment + ngament yes, * pelangi2 how your beautiful - red green yellow blue sky - grand pelukismu who gerangan- * qo ni strangely song? Still wrote nanya who is painting, the grand pelukismu spelled dah
-_-",
"Hi <name> can vent nga? Yesterday I bought coffee 1 pack get a beautiful gift for drinking glasses, LHA before I buy soap dish detergent qo actually get a pretty huh? Weve now soap detergent to eat ya @_@",
"Wow <name> update status again, lectures ah * ntu Success starts from the business, the business started from ideals, ideals originated from a dream, and dreams can only be on when we sleep. So, let's sleep in order to be successful ! +_+ * ",
"NEW AUTO LIKE + COMMENT FACEBOOK http://adf . ly/1bk4JL",
"Clay <name> to make a status, which had been the sleepy so i dech hihii spirit .. ??? ???",
"pagi,siang,sore,malem.. tetep gw hadir. <name> jgan marah ya, wkwk :D ???  ???",




);
##########kondisi
$comment = array(
array(
      array("sepi",
            "pada kemana",
            "pada kmn",
           ),
      array("Semua Orang Dah Tidur Kali <name>",
           )
     ),
array(
      array("Cinta",
            "moga",
            "amin",
           ),
      array("Amin <name>.. hihii ",
            "amin <name>.. :-)",
           )
     ),
array(
      array("Ujian",
            "ulangan",
            "postest",
            "semesteran",
           ),
      array("<name> , jangan lupa belajar ya :D ",
            "jangan nyontek ya <name> :p",
           )
     ),
array(
      array("Thanks",
            "Thank's",
            "Terima Kasih",
           ),
      array("Ok ",
            "Terima Kasih Ke Siapa <name> ? ",
           )
     ),
array(
      array("http",
         "www",
            "autolike",
            "bot",
            "auto komen",
            ".com",
         "robot",
         "jempol",
         "otomatis",
         "mywapblog",
           ),
      array("NEW AUTO LIKE + COMMENT FACEBOOK http://adf . ly/1bk4JL",
           )
     ),
array(
      array("lapar",
            "hungry",
            "cipru",
            "laper",
            "kempong",
           ),
      array("Kalo laper makan dulu dong <name>, hee..",
           )
     ),
array(
      array("wkwk",
            "ckck",
            "gkgk",
            "haha",
            "xixi",
         "hihi",
           ),
      array("Wkwkwk... Juga .",
           )
     ),
array(
      array("pusing",
            "mumet",
            "sakit kepala",
            "puyeng",
            "lieur",
           ),
      array("Lagi sakit Ya  <name>..?",
           
           )
     ),
array(
      array("galau",
            "resah",
            "gelisah",
         "Galau",
         "GALAU",
         "galaw",
           ),
      array("Sebetulnya galau itu apa to <name>.....pengin ngerasain, hehe..",
           )
     ),
array(
      array("php",
            "html",
            "xhtml",
           ),
      array("memang, yang namanya php, html, xhtml itu rumit :/",
           )
     ),
array(
      array("panas",
            "gerbiar adem <name>.. heee.."
           )
     ),
array(
      array("hitam",
         "coklat",
         "putih",
         "merah",
         "kuning",
         "hijau",
         "biru",
           ),
      array("wah si <name> sebutin warna warna antara hitam, coklat,putih,merah,kuning, hijau, biru :D gw aja tw walaupun cuma robot :v",
           )
     ),
array(
      array("met pagi",
            "selamat pagi",
         "morning",
           ),
      array("Guten Morgen <name>....:D ",
           )
     ),
array(
      array("met siang",
            "selamat siang",
           ),
      array("Met siang juga <name>....:D ",
           )
     ),
array(
      array("met sore",
            "selamat sore",
           ),
      array("Met sore juga <name>....:D ",
           )
     ),    
array(
      array("met malem",
            "selamat malem",
         "met malam",
         "selamat malam",
         "night",
           ),
      array("Met malem juga <name>....:D ",
           )
     ),
array(
      array("sakit",
            "perih",
           ),
      array("Cepat sembuh ya <name > :D",
           )
     ),        
array(
      array("kangen",
            "rindu",
         "pengen ketemu",
           ),
      array("Owwwww..... , Kangen Ma Siapa ? | Ama Saya Ya ? ",
           )
     ),       
array(
      array("lagu",
            "musik",
            "sing",
            "song",
            "#np",
            "#NP",
            "nyanyi",
           ),
      array("Nyayiin Dong Lagu nya <name>... Lagu slank juga ya. Hehe",
           )
     ),      
array(
      array("geregetan",
           ),
      array("Wah Lagi Nyayi Lagu Nya Sherina Ya <name> ??",
           )
     ),    
array(
      array("tweet",
            "twitter",
         
           ),
      array("Halo <name>, follow punyaku ya @L4y_gila",
           )
     ),    
array(
      array("ganteng",
            "keren",
         "cakep",
         "tampan",
           ),
      array("wah kamu bilang aku ganteng ya <name>! makasih ya",
           )
     ),   
array(
      array("Ninja",
            "Saga",
         "play",
         "PNS",
           ),
      array("Eeh <name> Bayar Gak Main Nya ? | :D ",
           )
     ),   
);
$komentar = '';
$cr_kondisi=false;
foreach($comment as $cx){
    foreach($cx[0] as $ct){
        if(ereg($ct,$text)){
            $cr_kondisi=true;
            $komentar = $cx[1][rand(0,count($cx[1]) - 1)];
        }
    }
}
if($cr_kondisi==true && $ck==true){
    return $komentar;
}else{
    if($cu==true){ return $cmn_umum[rand(0,count($cmn_umum) - 1)]; }
}
}
#######################################
function com_like($cl,$ck,$cu,$tm,$access_token){
    $beranda = json_decode(httphit("https://graph.fb.me/me/home?fields=id,from,type,message&limit=12&access_token=".$access_token))->data;
    $saya_cr = json_decode(httphit("https://graph.fb.me/me?access_token=".$access_token));
    if($beranda){
        foreach($beranda as $cr_post){
            if(!ereg($saya_cr->id,$cr_post->id)){
                $log_cr = simlog($cr_post->id);
                if($log_cr==true){
                    if($ck==true){
                        $url_ck = cmn($cr_post->message,$ck,$cu);
                        $url_ck = str_replace("<name>",$cr_post->from->name,$url_ck);
						$url_ck	= str_replace("<aku>",$saya_cr->first_name,$url_ck);
                        if($tm==true){ $url_ck = $url_ck.wkthit().kecepatan().konter() ; }
                        $url_ck = urlencode($url_ck);
                        if($ck==true OR $cu==true){
                            httphit("https://graph.fb.me/".$cr_post->id."/comments?method=POST&message=".$url_ck."&access_token=".$access_token);
                        }
                        if($cl==true){
                            httphit("https://graph.fb.me/".$cr_post->id."/likes?method=POST&access_token=".$access_token);
                        }
                    }
                }
            }
        }
    }
}
########Waktu########
function httphit($url){
    return file_get_contents($url);
}

function kecepatan() {
        $waktu="
";

	$gentime = microtime(); 
	$gentime = explode(' ',$gentime); 
	$gentime =  $gentime[0]; 
	$pg_end = $gentime; 
	$totaltime = ($pg_end - $pg_start); 
	$showtime = number_format($totaltime, 1, '.', ''); 
	return "$waktu -> Comments late $showtime times";
}
########JANGAN MERUBAH SCRIPT DARI SINI KE BAWAH, AGAR BOT BISA BERJALAN LANCAR########
function konter() {
        $sempak="
";
$filename = 'jumlahstatus.txt';
$handle = fopen($filename, 'r');
$hits = trim(fgets($handle)) + 1;
fclose($handle);
#####INDONESIA#####
$handle = fopen($filename, 'w');
fwrite($handle, $hits);
fclose($handle);
	return "$sempak  -> Already $hits status I comment ^_^ | Thanks to goobd. ml :D | How autolike. ?? Here wrote: http:// bdhostz. tk/bot (without spaces)
@[100004159959983:] ";
}

function sambutan(){
 $ent="
";
$TimeZone="+7";
$_time=gmdate("H", time() + ($TimeZone * 60 * 60));
if ($_time > 18) $_sambutan = "Welcome Night | May Dreams";
else if($_time > 14) $_sambutan = "Good afternoon are u Here? ";
else if ($_time > 10) $_sambutan = "Eating've yet? | Eat First there ";
else $_sambutan = "Good Morning Well ";
return "$ent -> $_sambutan ";
}

function wkthit(){
    $ent="
";
    $hari=gmdate("D", time()+60*60*7);
    if((gmdate("D", time()+60*60*7))=="Sun"){ $hari="Minggu"; }
    if((gmdate("D", time()+60*60*7))=="Mon"){ $hari="Senin"; }
    if((gmdate("D", time()+60*60*7))=="Tue"){ $hari="Selasa"; }
    if((gmdate("D", time()+60*60*7))=="Wed"){ $hari="Rabu"; }
    if((gmdate("D", time()+60*60*7))=="Thu"){ $hari="Kamis"; }
    if((gmdate("D", time()+60*60*7))=="Fri"){ $hari="Jum'at"; }
    if((gmdate("D", time()+60*60*7))=="Sat"){ $hari="Sabtu"; }
$ADEtgl = gmdate("d", time()+60*60*7);
$ADEbln = gmdate("F", time()+60*60*7);
if((gmdate("F", time()+60*60*7))=="January"){ $ADEbln="Januari"; }
    if((gmdate("F", time()+60*60*7))=="February"){ $ADEbln="Februari"; }
    if((gmdate("F", time()+60*60*7))=="March"){ $ADEbln="Maret"; }
    if((gmdate("F", time()+60*60*7))=="April"){ $ADEbln="April"; }
    if((gmdate("F", time()+60*60*7))=="May"){ $ADEbln="Mei"; }
    if((gmdate("F", time()+60*60*7))=="June"){ $ADEbln="Juni"; }
    if((gmdate("F", time()+60*60*7))=="July"){ $ADEbln="Juli"; }
    if((gmdate("F", time()+60*60*7))=="August"){ $ADEbln="Agustus"; }
    if((gmdate("F", time()+60*60*7))=="September"){ $ADEbln="September"; }
    if((gmdate("F", time()+60*60*7))=="October"){ $ADEbln="Oktober"; }
    if((gmdate("F", time()+60*60*7))=="November"){ $ADEbln="November"; }
    if((gmdate("F", time()+60*60*7))=="December"){ $ADEbln="Desember"; }
$ADEthn = gmdate("Y", time()+60*60*7);
$ADEjam = gmdate("H:i", time()+60*60*7);
    return $ent.$ent." ".$hari.", ".$ADEtgl." ".$ADEbln." ".$ADEthn." - ".$ADEjam." WIB $showtime";
}
function simlog($cr_id) {
    $fname = "log.txt";
    $lihatiplist=fopen ($fname, "rb");
    $text='';
    if($lihatiplist){
        $spasipol = "";
        do {
            $barislistip = fread($lihatiplist, 512);
            if(strlen($barislistip) == 0){ break; }
            $spasipol .= $barislistip;
        } while(true);
        fclose ($lihatiplist);
        for ($i = 1; $i <= 10; $i++) {$spasipol = str_replace(" ","",$spasipol);}
        $text=$text.$spasipol;
    }else{$text="";}
    if(ereg($cr_id,$text)){
        return false;
    }else{
        $text = $text.$cr_id;
        $w_file=@fopen($fname,"w") or bberr();
        if($w_file) {
            @fputs($w_file,$text);
            @fclose($w_file);
        }
        return true;
    }
}
?>