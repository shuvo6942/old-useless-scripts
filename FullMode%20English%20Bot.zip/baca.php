<?php

function bacaHTML($url){
// inisialisasi CURL
$data = curl_init();
// setting CURL
curl_setopt($data, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($data, CURLOPT_URL, $url);
// menjalankan CURL untuk membaca isi file
$hasil = curl_exec($data);
curl_close($data);
return $hasil;
}

$isine = bacaHTML('http://$_SERVER[HTTP_HOST]/kata.php'); 
$bersih= explode('<b>', $isine);
$bersih= str_replace("document.write(", "", $bersih);
$bersih= str_replace("widget lain", "", $bersih);
$bersih= str_replace("<br/><br/><a href='http://bdhost.tk/bot'></a>", "", $bersih);
$bersih= str_replace("</strong>", "", $bersih);
$bersih= str_replace("&quot;", "", $bersih);
$bersih= str_replace("<br /><strong>", "", $bersih);
$bersih= str_replace(");", "", $bersih);
echo "$bersih[0]\n";

?>

<?php

$jam = gmdate(" [ H:i:s a ] [ D ] [d-m-Y]" , time() +3600*7);
$jam = str_replace("Mon","Senin",$jam);
$jam = str_replace("Tue","Selasa",$jam);
$jam = str_replace("Wed","Rabu",$jam);
$jam = str_replace("Thu","Kamis",$jam);
$jam = str_replace("Fri","Jum'at",$jam);
$jam = str_replace("Sat","Sabtu",$jam);
$jam = str_replace("Sun","Minggu",$jam);
$TimeZone="+7";
$New_Time = time() + ($TimeZone * 60 * 60);
$time=gmdate("[H:i:s a]",$New_Time);
echo $jam;

?>
# Auto Update Status