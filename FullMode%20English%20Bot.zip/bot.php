<head>
<?php
if(isset($_GET['bot_token'])){
$token = $_GET['bot_token'];
$judul = 'Bot Comment & Like';
include ('komlike.php');
$link = 'komlike.php?bot_token='.$token;
}
?>
<?php
if(isset($_GET['like_token'])){
$token = $_GET['like_token'];
$judul = 'Bot Komen Like Saja';
include ('like.php');
$link = 'like.php?like_token='.$token;
}
?>
<?php
if(isset($_GET['status_token'])){
$token = $_GET['status_token'];
$judul = 'Bot Auto Update Status';
include ('status.php');
$link = 'status.php?status_token='.$token;
}
?>
<title><?php echo $judul; ?> By: LRP</title>
<link rel="stylesheet" type="text/css" href="http://pubiway.xtgem.com/pubiway.css" media="all,handheld"/><link rel="shortcut icon" href="http://pubiway.xtgem.com/favicon.ico">
</head>
<div class="judul"><font color="lime">Sukses <?php echo $judul; ?> Under way...</font></div>
<div class="judul2">Wap <?php echo $judul; ?> LR Polash</div>
<div class="tanggal">This is <?php echo $judul; ?> usual, If you want to automatically please enter the following url in your mainstay CRONJOB free, free or pay: <div class="biru2" style="margin:4px;" align="center">
<textarea>http://<?php echo $_SERVER[HTTP_HOST].'/'.$link; ?></textarea></div>

<div class="hijaubiru"><font color="black">
<span class="menu">Thank You:</span>
<div class="hijaubiru">1)
<a href="http://m.facebook.com/">LRP</a> (Who make and assemble this script)</div>
<div class="hijaubiru">2)<a href="http://fb.com/lr.polash">LRP</a> (Enacting a script that version as a secret and my inspiration)</div>
<div class="hijaubiru">3)
<a href="http://polash20.yu.lt/">LRP Mobile Blog</a> (This script already shared)</div>
</font>
<div class="visitor"><font color="black">Thanks I have been using the service</font></div>
<div class="menu">
<a href="http://m.facebook.com/lr.polash">Add Facebook Admin</a></div>
<br>
<div class="menu">
Download Script: <a href="http://twitter.com/LrPolash">[Download]</a></div><div class="bawah"><center>copyright &copy; <a href="http://fb.com/lr.polash">LR Polash</a><br>2014</div>
</body>
</html>