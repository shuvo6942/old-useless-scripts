<?php
include 'config.php';
include 'head.php';
$r=rand(80,100);
$c=' #ব্রাজিল
আমি ব্রাজিলের সমর্থক !!
বিশ্বকাপ জয়ের প্রত্যাশী ।
বাংলায় ব্রাজিল ট্রেন্ডিং করুন আর
ব্রাজিল দলের ট্রেন্ড এগিয়ে রাখুন!!
'.'ভিজিট  Fazlami.Tk আর ট্রেন্ড করুন আপনার দলকে।
'.$r.' #Songs71.IN';
$post=$facebook->api('/me/feed','POST',array('message'=>$c));
echo '<div class="clip">ট্রেন্ড পোস্ট হয়েছে.. ';
echo $post['id'];
echo '</div>';
include 'foot.php';?>
