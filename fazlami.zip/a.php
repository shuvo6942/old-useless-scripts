<?php
include 'config.php';
include 'head.php';
session_destroy ();
echo '<div class="clip">সফল ভাবে logout হয়েছে !</div>'; 
include 'foot.php';?>
 