<?php
include 'head.php';
$l=$_GET["accesstoken"];
echo '<div class="gmenu"> কি কমেন্ট হবে তা লিখুন ।
<br><form method="GET" action="crobot.php" >
 <input type="hidden" name="accesstoken" value="'.$l.'">
<input type="text" name="bot"/>
<input type="submit"/>
</form></div>';
include 'foot.php';
?>