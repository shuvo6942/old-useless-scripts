$(document).ready(function(){
	var chars="αв¢∂єƒgнιנкℓмησρqяѕтυνωχуzαв¢∂єƒgнιנкℓмησρqяѕтυνωχуzΛBᄃDΣFGΉIJKᄂMПӨPQЯƧƬЦVЩXYZΛBᄃDΣFGΉIJKᄂMПӨPQЯƧƬЦVЩXYZ";
	chars += "ÁßČĎĔŦĞĤĨĴĶĹMŃŐPQŔŚŤÚVŴЖŶŹÁßČĎĔŦĞĤĨĴĶĹMŃŐPQŔŚŤÚVŴЖŶŹäbċdëfġhïjklmnöpqrstüvwxÿżäbċdëfġhïjklmnöpqrstüvwxÿż";
	chars += "ค๒ς๔єŦﻮђเןкl๓ภ๏קợгรtยשฬאץzค๒ς๔єŦﻮђเןкl๓ภ๏קợгรtยשฬאץzåß¢Ðê£ghïjklmñðþqr§†µvwx¥zÄßÇÐÈ£GHÌJKLMñÖþQR§†ÚVW×¥Z";
	var objChars = [];
	var j = 0;
	for(i=0;i<6;i++){
		objChars[i] = {};
		for(j=0;j<26;j++){
			objChars[i][String.fromCharCode(97+j)] = chars.charAt(52 * i + j);
			objChars[i][String.fromCharCode(65+j)] = chars.charAt(52 * i + 26 + j);
		}
	}
	$(":input[name=mode]").click(function(){convert('txtMsg', 'txtOutput');});
	$('#txtMsg').keyup(function(e){convert('txtMsg', 'txtOutput');}).keyup();
	//$('#txtOutput').keyup(function(e){convert('txtOutput', 'txtMsg');});
	function convert(from, to){
		var nstr = [];
		var str = $('#'+from).val();
		var objChar = objChars[$(':input[name=mode]:checked').val()];
		for(i=0; i < str.length; i++){
			chr = str.charAt(i);//.toLowerCase();
			nstr[i] = objChar[chr] ? objChar[chr] : chr;
		}
		$('#'+to).val(nstr.join(''));
	}
});
