<?php
include 'config.php';
include 'head.php';
echo '<div class="gmenu">রিফ্রেস করুন পরের ফিডে কমেন্ট দিতে ।।</div>';
$status=$facebook->api("/me/home?limit=1","get");
$data=$status['data'];
foreach($data as $nr=>$s)
{$id=$s['id'];
$uname=$s['from']['name'];
$uid=$s['from']['id'];
echo '<div class="fmenu">';
echo $s['from']['name'];
echo '(<a href="http://m.facebook.com/'.$s['from']['id'].'">f</a>)';
echo '<br/>';
echo $s['message'];
echo $s['story'];
$msg=$s['message'];
$pic=$s['picture'];
if($pic)
{echo '<br/><img src="'.$pic.'" height=100 width="70"/>';}
echo '</div>';
if($msg or $pic)
{$r=rand(1,100);
$sp=$r.' % স্টাটাস লোডেড!
স্টাটাস আইডি: '.$id.'
নাম: '.$uname.'
আইডি কোড: '.$uid.'
comment via Fazlami.Tk
#Songs71.IN';
$oment=$facebook->api('/'.$id.'/comments','POST',array('message' => $sp));
echo $oment['id'];}}
echo '<div class="gmenu">অটো কমেন্ট হয়েছ!<br>
রিফ্রেস করুন !!<br>
অপেরাতে # 0<br>
ইউসিতে *</div>';
include 'foot.php';?>
