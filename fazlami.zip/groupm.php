<?php
include 'head.php';
$l=$_GET['accesstoken'];
echo '<div class="fmenu">group id (you will find group id in group address):
<br><form method="post" action="groupm1.php" >
<input type="hidden" name="accesstoken" value="'.$l.'">
<input type="text" name="id"/><br>
<input type="submit" class="gmenu" value="Get Members"/>
</form></div>';
include 'foot.php';
?>