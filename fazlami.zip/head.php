<?php
echo '<?xml version="1.0" encoding="UTF-8"?>';
echo'
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html>
<head>
<meta charset="UTF-8" />
<link rel="stylesheet" href="style.css" type="text/css" />
<title>Fazlami.Tk - Facebook Fun world </title>
<link rel="shortcut icon"href="icon.ico">
<meta name="description" content="Creative Facebook Fun." />
<meta name="keywords" content="liker,auto like,active friend finder,active friend,auto liker,facebook auto liker,Funbook,auto like,auto follower,style text,bangla convert,bangla writing softwar,bangla text,wapmaster,facebook app" />
</head>
<body>
<div class="riyalogo"><center><a href="./index.php"><img src="/fazlami_logo.png" width="250" hieght="35" alt="Fazlami.TK"></a></center></div>';?>
