<?php 
// include 'on.php';
// include 'part.php';
 ?> <?php
echo '<div class="riya"><font color="gray">Power By Songs71.IN & RiyaBD.Com</font></div></body></html>';
?> 
<noscript/>