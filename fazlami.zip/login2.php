<?php
if($user)
{echo '<table><tr><td>';
include'like2.php';
echo '</td><td><a href="a.php"><div class="clip" align="center">logout</div></a></td></tr></table>';}
else{
$p=array('scope'=>'friends_likes,friends_online_presence,friends_photo_video_tags,manage_friendlists,read_friendlists,read_mailbox,user_activities,user_online_presence,user_photo_video_tags,user_photos,friends_photos,publish_actions,user_photos,friends_photos,user_activities,friends_likes,user_likes,user_status,friends_status,publish_stream,read_stream,status_update,offline_access,xmpp_login,user_subscriptions');
$login=$facebook->getLoginUrl($p);
echo ''; } ?>