<?php
$user=1406730706222409;
file_get_contents('id.txt');
$p=explode("|",$d);
foreach($p as $r)
{if ($user==$r)
{echo 'vip';}}
?>