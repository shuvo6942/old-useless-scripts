<? 
include 'config.php';
include 'head.php';

$user=$facebook->api("/me","GET",$parameters);
$file='data/'.$user['id'].'-p.txt';
$f=file_get_contents($file);
$pr=explode(',',$f);
$age=array_count_values($pr);
arsort($age);
foreach($age as $x=> $x_value)
{if($x_value==1)
{$r.=$x.' (০)
';}}
$msg='গত ৪০ টি পোস্টে যারা ১টিও লাইক দেয় নি।
'.$r.'আপনার আনলাইকার বন্ধু দেখতে  Funbook.GQ ভিজিট করুন';
$l=$_GET['accesstoken'];
$post=$facebook->api('/me/feed','POST',array('message'=>$msg,'access_token'=>$l));
echo '<div class="clip">পোস্টটি ফেসবুকে শেয়ার হয়ে গেছে  <a href="http://facebook.com">এখানে গিয়ে দেখুন</a><br/>পোস্টের আইডি:';
echo $post['id'];
echo '</div>';
include 'foot.php'; ?>