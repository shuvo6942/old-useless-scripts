<?php
include 'config.php';
include 'head.php';
$a=$facebook->api("me/subscribers?limit=3000","GET");
$fr=$a['data'];
echo '<div class="gmenu"> মোট সাবস্কিবার: ';
echo count($fr);
echo '</div><div class="fmenu">';
foreach($fr as $n=>$friend)
{echo '<a href="mewall.php?id='.$friend['id'].'">'.$friend['name'].'</a><br>'; }
echo '</div>';
include 'foot.php'; ?>