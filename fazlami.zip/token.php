<div class="bmenu">নিচের অংশটুকু ভালোভাবে পড়ে নিন</div>
<div class="an">
এক্সেস টোকেনে সংগ্রহ করতে গেলে সেখানে কয়েকবার okay দিতে হবে !
এরপর ERROR লেখা পেজ আসবে ।।</div><div class="an">
<font color="green">পেজটির লিংকটি ব্রাউজারের Page info/address bar থেকে কপি করুন ।<br>লিংকটি দেখতে কিছুটা এইরকম হবে !!</font>
publish.nokia.com/login/_Riya_Technologies_Ltd__?#access_token=<font color="red">********* </font>&expires_in=0
</div><div class="an">
<font color="red">*****</font> দেয়া আংশটুকু হল এক্সেস টোকেন ।
এক্সেস টোকেন দেখতে কিছুটা এমন 
<font color="gray">CAAAAPJmB8ZBwB AMZCbdEdiGic QWZAtilSavT y1mUFxmMEZB A1EK009e dktYYGBsWyKA gdLV9tyJgx</font></div>
<div class="an">
<font color="green">
মনে রাখবেন accsses_token=এর পর থেকে &expires_in=0 এর আগে পর্যন্ত কপি করতে হবে। <br>
এক্সেস টোকেন সংগ্রহ করে,
এই বক্সে পেস্ট করে লগিন করুন.
</font><div>
</div>

</div></div>
<div class="bmenu"> এখান থেকে এক্সেস টোকেন সংগ্রহ করুন</div><div class="fmenu">
 <a href="/mytoken.php">Click Here To Go Access Token</a></div>

<div class="bmenu"> নিচের বক্সে টোকেনটি পেস্ট করুন</div>
<div class="an">
<center>
 <form method="get" action="index2.php"><input type="text" name="accesstoken" class="clip"><br>
<input class="zero11" type="submit" value="Connect">
</form></center></div>
