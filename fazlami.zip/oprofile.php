<?php
include 'config.php'; 
include 'head.php';
echo '<div class="gmenu">পরবর্তি প্রফাইলে যেতে রিলোড করুন ।।<br>
uc *<br>
opera # 0</div>';
$user=$facebook->api("/me","GET");
$Fil="data/".$user['id']."-sd.txt";
$handle =fopen($Fil,'r+'); 
$data=fread($handle,512); 
$count=$data+1;
fseek($handle,0); 
fwrite($handle,$count);
fclose($handle); 
$user=$facebook->api("/me","GET");
$file='data/'.$user['id'].'-od.txt';
$f=file_get_contents($file);
$fr=explode('|',$f);
$pid=$fr[$count];
$status=$facebook->api("/".$pid."/statuses?limit=9","GET");
$data=$status['data'];
foreach($data as $nr=>$s)
{$id=$s['id'];
$uname=$s['from']['name'];
$uid=$s['from']['id'];
echo '<div class="fmenu">';
echo '<a href="http://m.facebook.com/'.$s['from']['id'].'">'.$s['from']['name'].'</a>';
echo '<br/>';
$msg=$s['message'];
if($msg)
{
echo $msg;}
$st=$s['story'];
if($st)
{echo $st;}
$pic=$s['picture'];
if($pic)
{echo '<br/><img src="'.$pic.'" height=100 width="70"/>';
echo '<br/><font color="gray">Photo Liking disabled</font>';}
echo '</div>';
if($msg)
{echo '<div class="menu"> comment:</font><br/><form method="POST" action="comment.php">
<input type="text" name="c" class="clip"/><input type="hidden" name="id" value="'.$id.'"><input type="submit" class="clip"/></form></div></div>';
}}
include 'foot.php'; ?>