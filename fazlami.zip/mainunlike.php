<?php
include 'head.php';
$l="?accesstoken=".$_GET['accesstoken'];
echo '<div class="bmenu">আনলাইকার মেনু</div><a href="unlikem4.php'.$l.'">
<div class="fmenu">মেনুটি আগে ব্যাবহার করে থাকলে<br>এখানে ক্লিক করে শুরু করুন ।</div>
</a><a href="unlike.php'.$l.'"><div class="fmenu">আনলাইকারদের নাম দেখুন ।।</div></a>
<a href="unlikem.php'.$l.'"><div class="fmenu">আনলাইকারদের মেনশন দেখুন ।।</div></a>';
include 'foot.php'; ?>