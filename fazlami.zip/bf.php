<?php
include 'config.php';
include 'head.php';
$fql="SELECT uid,name,online_presence FROM user WHERE online_presence IN ('active','idle') AND uid IN (SELECT uid2 FROM friend WHERE uid1=$user limit 10)";
$p=$_GET['accesstoken'];
$r=$facebook->api(array('method'=>'fql.query','access_token'=>$p,'query'=>$fql));
foreach($r as $nr=>$o)
{$f.=$o['name'].'
';}
$msg=' আজকের ফ্রেন্ডস অফ দ্যা ডে।
'.$f.'

আসা করি তাদের সাথে ভালো বন্ধুত্ব সর্বদা থাকবে ।

ফ্রেন্ডস অফ দ্যা ডে দেখতে ভিজিট করুন: Fazlami.Tk

#Songs71.IN';
$post=$facebook->api('/me/feed','POST',array('message'=>$msg,'access_token'=>$p));
echo '<div class="clip">post success goto <a href="http://facebook.com">facebook</a>';
echo $post['id'];
echo '</div>';
include 'foot.php';?>
