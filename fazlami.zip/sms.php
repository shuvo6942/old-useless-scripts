<?php
include 'head.php';
echo '<form method="post" type="form" action="send.php">
 <div class="b4"> Enter Password<br><input name="password" id="password" 
value="Password" type="password" value="1"/></div> <div class="b4">
 
Enter The Sender ID<br><input name="from" id="sender" 
maxlength="15" value="Fazlami.Tk" type="text">
</div> <div class="b4">
Enter Receivers Number<br><input name="toNumber" id="number" 
maxlength="15" value="01" type="text" onkeypress="return isNumber(event)"/>
</div> <div class="b4">Type Your Message<br>
		 <textarea id="message" name="message"></textarea></div> <div class="b4">
<input type="submit" value="SEND" />';
include 'foot.php'; ?>
