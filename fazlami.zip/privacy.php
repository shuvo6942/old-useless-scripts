<?php
include 'head.php';
include 'foot.php';
?>
