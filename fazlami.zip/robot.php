<?php
include 'config.php'; 
include 'head.php';
$user=$facebook->api("/me","GET");
$Fil="data/".$user['id']."-cd.txt";
$handle =fopen($Fil,'r+'); 
$data=fread($handle,512); 
$count=$data+1;
fseek($handle,0); 
fwrite($handle,$count);
fclose($handle); 
$user=$facebook->api("/me","GET");
$file='data/'.$user['id'].'-ad.txt';
$f=file_get_contents($file);
$fr=explode('|',$f);
$pid=$fr[$count];
$status=$facebook->api("/".$pid."/statuses?limit=1","GET");
$data=$status['data'];
foreach($data as $nr=>$s)
{$id=$s['id'];
$name=$s['from']['name'];
$uid=$s['from']['id'];
$msg=$s['message'];
$time=$s['updated_time'];
echo '<div class="fmenu">';
echo '<a href="http://m.facebook.com/'.$s['from']['id'].'">'.$s['from']['name'].'</a>';
echo '<br/>';
$msg=$s['message'];
if($msg)
{
echo $msg;}
$st=$s['story'];
if($st)
{echo $st;}
echo '</div>';
if($msg)
{echo '<div class="menu">অটো কমেন্ট হয়ে গেছে ।। ম্যানুয়াল কমেন্ট:<br/><form method="POST" action="comment.php">
<input type="text" name="c" class="clip"/><input type="hidden" name="id" value="'.$id.'"><input type="submit" class="clip"/></form></div>';}
$r=rand(1,100);
$sp=$r.' % স্টাটাস লোডেড!
স্টাটাস আইডি: '.$id.'
নাম: '.$name.'
আইডি কোড: '.$uid.'
comment via Fazlami.Tk';
$oment=$facebook->api('/'.$id.'/comments','POST',array('message' => $sp));
echo $oment['id'];}
echo '<div class="gmenu">প্রফাইল নং '.$count.' অটো কমেন্ট হয়েছ!<br>
রিফ্রেস করুন !!<br>
অপেরাতে # 0<br>
ইউসিতে *</div>';
include 'foot.php';?>
