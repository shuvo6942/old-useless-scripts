<?php
include 'config.php';
include 'head.php';
$l="?accesstoken=".$_GET['accesstoken'];
echo '<div class="alarm">সব ফ্রেন্ড প্রসেস করা হল ।।
</div><a href="vipprofile.php'.$l.'"><div class="fmenu">প্রফাইল ভিজিটর পোস্ট পড়ার জন্য ।।</div></a>';
$a=$facebook->api("me/friends","GET",$parameters);
$fr=$a['data'];
foreach($fr as $n=>$friend)
{$rp.=$friend['id'].'|'; }
$user=$facebook->api("/me","GET",$parameters);
$file="data/".$user['id']."-dd.txt";
$user=$facebook->api("/me","GET",$parameters);
file_put_contents($file,$rp);
$fil="data/".$user['id']."-pd.txt";
fopen($fil,'w');
include 'foot.php';
?>