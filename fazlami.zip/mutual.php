<?php
include 'config.php';
include 'mrank.php';
include 'head.php';
echo '<div class="gmenu">মিচুয়াল</div>';
$rank=new AyFbFriendRank($facebook);
$s=$rank->getFriends();
foreach($s as $nk => $user)
{if($user['weight']['friend_mutual']>1){echo '<div class="fmenu">'.$user['name'].'  '.$user['weight']['friend_mutual'].' mutual</div>';}}
include 'foot.php'; ?>