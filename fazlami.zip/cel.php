<?php
include 'config.php';
include 'head.php';

$user=$facebook->api("/me","GET",$parameters);
$l="data/".$user['id'].".txt";
$fp=file_get_contents($l);
$f=explode("|",$fp);
foreach($f as $lid)
{$r=$facebook->api('/'.$lid.'/likes?limit=1000','GET',$parameters);
foreach($r['data'] as $l)
{$rp.=$l['name'].',';}}
$user=$facebook->api("/me","GET",$parameters);
$file="data/".$user['id']."-l.txt";
file_put_contents($file,$rp);
$l="?accesstoken=".$_GET['accesstoken']; echo '<div class="alarm">বিগত ২০ টি পোস্টের সকল লাইকার প্রসেস করা হল ।<br>
view liker এ গিয়ে লাইকার এ গিয়ে । <br>লাইকারের তালিকা দেখুন । </div><a href="cel2.php'.$l.'"><div class="clip">View liker</div></a>';
include 'foot.php';?>