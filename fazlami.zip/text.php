<?php
include 'head.php'; ?>
<meta http-equiv="Content-Type" content="text/html;charset=utf-8" /><script type='text/javascript' src='http://www.mallubar.com/assets/js/jquery.js'>
<script type="text/javascript">
var _DRCB = _DRCB || [];
var User = {"id":0,"name":"","name_encoded":"","level":0,"loggedin":false,"registered":false};
(function() {
var d = document, de = d.documentElement;
de.className = de.className.replace(/(\bno-js\b)?\s?/, 'js ');
_DRCB.push(function () {
$(d).bind('auth_status_change', function (e, data) {User = data;});
});
})();
window.google_analytics_uacct = "UA-1458794-6";
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','//www.google-analytics.com/analytics.js','ga');

ga('create', 'UA-1458794-6', 'Funbook.GQ');
ga('send', 'pageview');
</script><script type="text/javascript" src="fancy-text.js"> </script>
<div id="middleContent">
<div class="bmenu">টেক্স কনভার্টার! প্রথমে লিখুন এবং স্টাইল সিলেক্ট করুন..:-)</div>
<div class="clip">
<div id="mode"><span class="label">Select Style:</span><label><input name="mode" type="radio" value="0" checked="checked"/>Set 1</label><label><input name="mode" type="radio" value="1"/>Set 2</label><label><input name="mode" type="radio" value="2"/>Set 3</label><label><input name="mode" type="radio" value="3"/>Set 4</label><label><input name="mode" type="radio" value="4"/>Set 5</label><label><input name="mode" type="radio" value="5"/>Set 6</label></div>
<span class="label">Normal Text:</span>
<textarea id="txtMsg" class="clip">Write your message in this text box.</textarea>
<span class="label">Converted Text:</span>
<textarea id="txtOutput" class="clip"></textarea>
</div>
<?php include 'foot.php'; ?>
