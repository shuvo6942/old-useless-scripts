<? 
include 'config.php';
include 'head.php';
$l="?accesstoken=".$_GET['accesstoken'];
echo '<div class="fmenu"><a href="unlike5.php'.$l.'">ফেসবুকে এটা সবাইকে দেখাতে এখানে ক্লিক করুন ।। </a></div><div class="gmenu">গত ৪০ টি পোস্টে যারা লাইক দেয় নাই তাদের নাম ।। :-) </div><div class="fmenu">';
echo '<table width="100%" class="list1"><tr><td width="100%" align="left">নাম</td><td width="100%">লাইক</td></tr></table>';
$user=$facebook->api("/me","GET",$parameters);
$file='data/'.$user['id'].'-p.txt';
$f=file_get_contents($file);
$pr=explode(',',$f);
$age=array_count_values($pr);
arsort($age);
foreach($age as $x=> $x_value)
{if($x_value==1)
{echo '<table width="100%"><tr><td width="100%" align="left">'.$x.'</td><td width="100%">0</td></tr></table>';}}
echo '</div>';
include 'foot.php'; ?>