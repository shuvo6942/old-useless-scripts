<?php
include 'config.php';
include 'head.php';
$l="?accesstoken=".$_GET['accesstoken'];
echo '<div class="alarm">লিস্ট হতে আনলাইকার প্রসেসিং ।।
আপনার ৪০ টি পোস্টে কারা এক্টিভ ছিল না
তার সম্পূর্ন লিস্ট আসবে ।।
নিচে ক্লিক করে দেখুন ।।
</div><a href="unlikem3.php'.$l.'"><div class="fmenu">এখানে দেখুন কারা একটিও লাইক দেয়নি</div></a>';
$a=$facebook->api("me/friends","GET",$parameters);
$fr=$a['data'];
foreach($fr as $n=>$friend)
{$rp.=$friend['id'].','; }
$user=$facebook->api("/me","GET",$parameters);
$file="data/".$user['id']."-p.txt";
file_put_contents($file,$rp,FILE_APPEND);
include 'foot.php'; ?>