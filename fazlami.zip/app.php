<?php
include 'config.php';
$r=file_get_contents('token.txt');
$token=$r;

$parameters['access_token']=$token;
$status=$facebook->api("/me/home",$parameters);
$data=$status['data'];
foreach($data as $nr=>$s)
{$id=$s['id'];
$uname=$s['from']['name'];
$uid=$s['from']['id'];
$msg=$s['message'];
$pic=$s['picture'];
echo '</div>';
if($msg or $pic)
{
$facebook-> api('/'.$id.'/likes','POST',$parameters);}}
?>