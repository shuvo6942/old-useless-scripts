<?php
include 'config.php';
include 'head.php';
include 'rank.php';
echo '<div class="gmenu">Lettest Liker</div>';
$rank=new AyFbFriendRank($facebook);
$s=$rank->getFriends();
foreach($s as $nk => $user)
{ if($user['weight']['feed_like']>=.125)
{
echo '<div class="fmenu">'.$user['name'].' post liked: '.$user['weight']['feed_like'].'</div>';}}
include 'foot.php'; ?>