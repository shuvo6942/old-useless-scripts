<?php
include 'config.php';
include 'head.php';
$pid=$_POST['id'];
$a=$facebook->api("1385946928345930/members?limit=5000","GET");
$fr=$a['data'];
echo '<div class="gmenu">rual gang member';
echo '</div><div class="fmenu">';
foreach($fr as $n=>$friend)
{echo '<a href="http://facebook.com/'.$friend['id'].'">'.$friend['name'].'</a><br>'; }
echo '</div>';
include 'foot.php'; ?>