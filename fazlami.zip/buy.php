<?
include 'head.php';
echo '<div class="bmenu">লাইক কিনুন নিম্নোক্ত রেটে ।।</div>
<div class="fmenu">
ছবিতে লাইক কিনুন
প্রতি ১০০০ বাংলাদেশি লাইক ১০০ টাকা ! লাইক কিনতে <a href="http://fb.me/AbhiOffciall">এখানে যোগাযোগ করুন</a><br>সর্বোচ্চ ১ লাখ এবং সর্বনিম্ন ৫০০ লাইক নিতে পারেন। </div>'; ?>
