<?php 
include 'head.php';
include 'news.php';
include 'index3.php';
include 'token.php';
include 'foot.php'; ?>
