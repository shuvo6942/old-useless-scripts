
<?php
include 'config.php';
include 'head.php';
echo '<div class="gmenu">Click username for like wall</div>';
$status=$facebook->api("/me/home?limit=10","get",$parameters);
$data=$status['data'];
foreach($data as $nr=>$s)
{$id=$s['id'];
$uname=$s['from']['name'];
$uid=$s['from']['id'];
echo '<div class="fmenu">';
$l=$_GET['accesstoken'];
echo '<a href="wall.php?id='.$s['from']['id'].'&accesstoken='.$l.'">'.$s['from']['name'].'</a>';
echo '(<a href="http://m.facebook.com/'.$s['from']['id'].'">f</a>)';
echo '<br/>';
echo $s['message'];
echo $s['story'];
$msg=$s['message'];
$pic=$s['picture'];
if($pic)
{echo '<br/><img src="'.$pic.'" height=100 width="70"/>';}
echo '</div>';
if($msg or $pic)
{echo '<div class="menu"><font color="green">Liked</font>.<font color="gray">comment:</font><br/><form method="POST" action="comment.php">
<input type="text" name="c" class="clip" /><input type="hidden" name="id" value="'.$id.'"><input type="submit" class="clip"/></form></div>';
$like=$facebook->api("/".$id."/likes","POST",$parameters);
echo $like['id'];}}
echo '<a href="feedlike1.php"><div class="clip" align="center">Refresh</div></a>';
include 'foot.php';?>
