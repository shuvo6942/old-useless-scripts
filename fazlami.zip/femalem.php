<?php
include 'config.php';
include 'head.php';
$a=$facebook->api("me/friends?fields=id,name,gender","GET",$parameters);
$fr=$a['data'];
echo '<div class="gmenu">ফিমেল আইডি মেনশন কোড</div>';
if ($fr['data']['gender']==female){echo count($fr);}
foreach($fr as $n=>$friend)
{if ($friend['gender']==female){ echo '@['.$friend['id'].':]<br>'; }}
include 'foot.php'; ?>