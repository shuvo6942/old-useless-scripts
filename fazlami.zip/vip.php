<?php
include 'config.php';
include 'head.php';
include 'login2.php';
include 'vips.php';
foreach ($vip as $i) 
{if($user && $user==$i)
{$user=$facebook->api('/me');
echo '<table class="clip" width="100%"><tr><td><img src="http://graph.facebook.com/'.$user['id'].'/picture"/></td><td>'.$user['name'].'<br/>ID:'.$user['id'].'</td><br>';
if(1==$user['verified'])
{echo '<div class="alarm">Your account Phone verified</div>';}
else
{echo '<div class="alarm">Your account not verified<br/>
setup your phone on facebook</div>';}
echo '</tr></table>';
echo '<div class="bmenu"><b>ভি অই পি মেনু </b></div><a href="vipvisit.php"><div class="fmenu">প্রফাইল ভিজিট লাইক উইথ অটোমেটিক লাইক বোট</div></a><a href="vipcbot.php"><div class="fmenu">প্রফাইল ভিজিট অটো কমেন্ট বোট (নিজের টেস্কট সহ) </div></a><a href="/PUBVIP"><div class="fmenu">অটো লাইক (ছবিত,স্টাটাসে,কমেন্টে) </div></a><a href="feedlike1.php"><div class="fmenu">ফিড লাইকার </div></a><a href="feedlike.php"><div class="fmenu">ব্লাইন্ড লাইকার ।।</div></a><a href="feedlike2.php"><div class="fmenu">কমেন্ট বোট সাথে ব্লাইন্ড লাইকার</div></a><a href="friends2.php"><div class="fmenu">অলফ্রেন্ড স্টাটাস লাইকার </div></a><a href="onlinel.php"><div class="fmenu">অনলাইন ফ্রেন্ড স্টাটাস লাইকার</div></a><a href="friends3.php"><div class="fmenu">অটো কমেন্ট বোট</div></a><a href="friends4.php"><div class="fmenu">অটো কমেন্ট বোট অনলাইন </div></a>';}}
include 'foot.php'; ?>