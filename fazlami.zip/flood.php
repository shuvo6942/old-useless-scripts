<?php
include 'head.php';
echo '<div class="alarm">বেশী দ্রুত যাচ্ছেন!!<br/>
দয়া করে ২০ মিনিট পর পর চেস্টা করুন </div>';

include 'foot.php'; ?>