<?php

/*

* Author: Khalequzzaman
* Language: PHP, HTML, CSS
* Project Name: 9Apps Grabber
* URL: http://apk.nextmusics.com/

*/

if(!empty($_GET['keyword'])){
$url = '/search/tag-'.$_GET['keyword'].'-1/';
header('location:'.$url.'');
}
else {
include_once 'inc/func.php';
include_once 'inc/data.php';
$title = $_GET['q'].' Android Apps & Games (Free Download) - '.$sitename;
$description = $sitename.' is an android app store which owns massive free android applications especially '.$_GET['q'].' apps, it provides you with professional '.$_GET['q'].' android apps and '.$_GET['q'].' apps free download. '.$sitename.' have everything about android mobile phone you expect to find.';
$keyword = $_GET['q'].' apps, '.$_GET['q'].' app free download, '.$_GET['q'].' android apps';
include_once 'inc/head.php';

if(!empty($_GET['page'])){$page = $_GET['page'];}else{$page = 1;}
$grab = xlink('http://www.9apps.com/search/tag-'.$_GET['q'].'-'.$page.'/');
if(preg_match('<div class="app-list">', $grab)){
$list = cut($grab, '<div class="app-list">','<div class="footer">');
$list = str_replace('/jump/','http://www.9apps.com/jump/', $list);
echo '<div class="app-list">'.$list;
}
else{
$notfound = cut($grab, '<div class="search-tips">','<div class="footer">');
echo '<div class="search-tips">'.$notfound;
}
include_once 'inc/foot.php';
}
?>