<?php

/*

* Author: Khalequzzaman
* Language: PHP, HTML, CSS
* Project Name: 9Apps Grabber
* URL: http://apk.nextmusics.com/

*/

include_once 'inc/func.php';
include_once 'inc/data.php';

if(!empty($_GET['type']) && !empty($_GET['file'])){
$grab = xlink('http://www.9apps.com/android-'.$_GET['type'].'/'.$_GET['file'].'/?f='.$_GET['f'].'');
$download = cut($grab,'</header>','<div class="footer">');
$download = str_replace('/jump/','http://9apps.com/jump/',$download);
$filename = cut($download,'<span itemprop="name">','</span>');
$category = cut($download,'<p class="others">','|');
if(!empty($filename)){
$title = $filename.' for Android (Free Download) - '.$sitename;
include 'inc/head.php';
echo '<header class="header">
    <div class="header-l">
        <a class="go-back" href="javascript:history.back();"><i style="margin:1px 6px 0px 0px;"></i><img src="'.$logowap.'" width="60" height="16" alt="'.$sitename.'" /></a>

    </div>
    <div class="header-m">
        <h2>DETAILS</h2>
    </div>
    <div class="header-r">
        <a class="icon-home" href="/"></a>
    </div>
</header><center><script type="text/javascript" src="http://4ads.in/adv/javascript/id/560"></script></center>';
echo $download;
echo '<center><script type="text/javascript" src="http://9wapusd.com/adv/javascript/id/1908"></script></center>';

include 'inc/foot.php';
}
}
if(empty($_GET['type']) && empty($_GET['file']) && empty($filename)){
include '404.php';
}
?>

