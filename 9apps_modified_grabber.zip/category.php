<?php

/*

* Author: Khalequzzaman
* Language: PHP, HTML, CSS
* Project Name: 9Apps Grabber
* URL: http://apk.nextmusics.com/

*/

include_once 'inc/func.php';
include_once 'inc/data.php';

if(!empty($_GET['type']) && !empty($_GET['view'])){
if(!empty($_GET['page'])){$page = $_GET['page'];}else{$page = 1;}
$grab = xlink('http://www.9apps.com/android-apps/'.$_GET['order'].'-'.$_GET['view'].'-'.$_GET['type'].'-'.$page.'/?f='.$_GET['f'].'');
$list = cut($grab,'<body>','<div class="footer">');
$list = str_replace('/asset/mini/images/logo.png', $logowap, $list);
$list = str_replace('9APPS', $sitename, $list);
$list = str_replace('/jump/', 'http://www.9apps.com/jump/', $list);
$categories = cut($list,'<h2>','</h2>');
$title = ucwords($_GET['order'].' Android '.$categories.' '.$_GET['type'].' Download - '.$sitename);
$description = $sitename.' provide top and popular Android '.$categories.' apps that will satisfy the needs of all types for you.';
$keyword = 'top android '.$categories.' '.$_GET['type'];

include 'inc/head.php';

echo $list;

include 'inc/foot.php';
}
elseif(!empty($_GET['type']) && empty($_GET['view'])){
$grab = xlink('http://www.9apps.com/android-'.$_GET['type'].'-categories/?f='.$_GET['f'].'');
$category = cut($grab,'<div class="tabs">','<div class="footer">');
$title = 'Android '.ucwords($_GET['type']).' Categories - '.$sitename;
$description = $sitename.' provide thousands hot and popular Android apps that will satisfy the needs of all types for you.';
$keyword = 'android '.$_GET['type'].' categories';
include 'inc/head.php';

echo '<div class="tabs">'.$category;

include 'inc/foot.php';
}
else{
include '404.php';
}
?>