<?php

/*

* Author: Khalequzzaman
* Language: PHP, HTML, CSS
* Project Name: 9Apps Grabber
* URL: http://apk.nextmusics.com/

*/

include_once 'inc/func.php';
include_once 'inc/data.php';
$title = 'Latest Android Apps & Games Downloads Portal - '.$sitename.'';
include_once 'inc/head.php';

if(!empty($_GET['page'])){$page = $_GET['page'];}else{$page = 1;}
$grab = xlink('http://www.9apps.com/?f='.$_GET['f'].'&page='.$page.'');
$list = cut($grab, '<div class="app-list">','<div class="footer">');
$list = str_replace('/jump/','http://www.9apps.com/jump/', $list);
echo '<div class="app-list">'.$list;

include_once 'inc/foot.php';
?>