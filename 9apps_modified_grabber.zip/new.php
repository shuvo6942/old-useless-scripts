<?php

/*

* Author: Khalequzzaman
* Language: PHP, HTML, CSS
* Project Name: 9Apps Grabber
* URL: http://apk.nextmusics.com/

*/

include_once 'inc/func.php';
include_once 'inc/data.php';


if(!empty($_GET['type'])){
if(!empty($_GET['page'])){$page = $_GET['page'];}else{$page = 1;}
$grab = xlink('http://www.9apps.com/new-android-'.$_GET['type'].'-'.$page.'/?f='.$_GET['f'].'');
$top = cut($grab,'<div class="tabs">','<div class="footer">');
$top = str_replace('/jump/','http://www.9apps.com/jump/', $top);
$title = 'Top New Free Android Apps Download - '.$sitename;
$description = 'Looking for some new '.$_GET['type'].' to play on your Android device? '.$sitename.' supports top best new Android '.$_GET['type'].' download.';
$keyword = 'new android '.$_GET['type'].' for mini';
include_once 'inc/head.php';
echo '<div class="tabs">'.$top;
include_once 'inc/foot.php';
}
else{
include '404.php';
}
?>