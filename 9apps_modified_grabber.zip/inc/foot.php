<?php
/*

* Author: Khalequzzaman
* Language: PHP, HTML, CSS
* Project Name: 9Apps Grabber
* URL: http://apk.nextmusics.com/

*/

echo '    <div class="footer">
    <div class="friendly-links well">
        <ul class="row first">
            <li class="item"><a class="f-like" href="https://web.facebook.com/Khalequzzaman24" target="_blank">Facebook</a></li>
            <li class="item"><a class="t-like" href="https://www.twitter.com/Khalequzzaman24" target="_blank">Twitter</a></li>
            <li class="item"><a class="icon_app" href="http://upcoders.blogspot.com/">Blogger</a></li>
        </ul>
    </div>
    <div class="footer-links"><a>Contact:</a> <a class="link" href="mailto:admin@nextmusics.com">'.$email.'</a>
    </div>
    <div class="copyright">

        <p>Copyright &copy; 2016 Apk.NextMusics.Com</p>
    </div>
</div>';
?>

<script>
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
            m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
    ga('create', 'UA-61680264-2', 'auto');
    ga('send', 'pageview');
</script>

</body>
</html>