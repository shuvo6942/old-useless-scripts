
<!DOCTYPE html>
<html lang="en">
  <head>
    	<!-- Basic -->
			<meta charset="UTF-8" />
			<title>
					Contact | HostBengal			</title>
    	<meta name="description" content="">
    	<meta name="author" content="">

      <!-- Mobile Metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	<link rel="icon" type="image/png" href="http://hostbengal.com/wp-content/uploads/2014/07/hostbengal-favicon.png" />		
    	<link rel="pingback" href="http://hostbengal.com/xmlrpc.php" />
      <link rel="alternate" type="application/rss+xml" title="HostBengal" href="http://hostbengal.com/feed/" />  

      <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
    	<!--[if IE]>
            <link rel="stylesheet" href="css/ie/ie.css">
        <![endif]-->
    
      <!--[if lt IE 9]>
        <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
      <![endif]--> 

      <link rel="alternate" type="application/rss+xml" title="HostBengal &raquo; Feed" href="http://hostbengal.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="HostBengal &raquo; Comments Feed" href="http://hostbengal.com/comments/feed/" />
<link rel="alternate" type="application/rss+xml" title="HostBengal &raquo; Contact Comments Feed" href="http://hostbengal.com/contact/feed/" />
<link rel='stylesheet' id='styles-icon-css'  href='http://hostbengal.com/wp-content/themes/megahost/inc/theme-icon/css/input.css?ver=4.0.5' type='text/css' media='all' />
<link rel='stylesheet' id='styles-icon1-css'  href='http://hostbengal.com/wp-content/themes/megahost/inc/theme-icon/assets/css/font-awesome.css?ver=4.0.5' type='text/css' media='all' />
<link rel='stylesheet' id='styles-icon2-css'  href='http://hostbengal.com/wp-content/themes/megahost/inc/theme-icon/assets/css/font-awesome-corp.css?ver=4.0.5' type='text/css' media='all' />
<link rel='stylesheet' id='styles-icon3-css'  href='http://hostbengal.com/wp-content/themes/megahost/inc/theme-icon/assets/css/font-awesome-ext.css?ver=4.0.5' type='text/css' media='all' />
<link rel='stylesheet' id='styles-icon4-css'  href='http://hostbengal.com/wp-content/themes/megahost/inc/theme-icon/assets/css/font-awesome-social.css?ver=4.0.5' type='text/css' media='all' />
<link rel='stylesheet' id='styles-icon5-css'  href='http://hostbengal.com/wp-content/themes/megahost/inc/theme-icon/assets/css/font-awesome-more-ie7.min.css?ver=4.0.5' type='text/css' media='all' />
<link rel='stylesheet' id='flick-css'  href='http://hostbengal.com/wp-content/plugins/mailchimp//css/flick/flick.css?ver=4.0.5' type='text/css' media='all' />
<link rel='stylesheet' id='mailchimpSF_main_css-css'  href='http://hostbengal.com/?mcsf_action=main_css&#038;ver=4.0.5' type='text/css' media='all' />
<!--[if IE]>
<link rel='stylesheet' id='mailchimpSF_ie_css-css'  href='http://hostbengal.com/wp-content/plugins/mailchimp/css/ie.css?ver=4.0.5' type='text/css' media='all' />
<![endif]-->
<link rel='stylesheet' id='dcwp_plugin_admin_dcscf_css-css'  href='http://hostbengal.com/wp-content/plugins/slick-contact-forms/css/admin.css?ver=4.0.5' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-css'  href='http://hostbengal.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=3.8.1' type='text/css' media='all' />
<link rel='stylesheet' id='rs-plugin-settings-css'  href='http://hostbengal.com/wp-content/plugins/revslider/rs-plugin/css/settings.css?rev=4.5.01&#038;ver=4.0.5' type='text/css' media='all' />
<style type='text/css'>
.tp-caption.medium_grey {
position:absolute;
color:#fff;
text-shadow:0px 2px 5px rgba(0, 0, 0, 0.5);
font-weight:700;
font-size:20px;
line-height:20px;
font-family:Arial;
padding:2px 4px;
margin:0px;
border-width:0px;
border-style:none;
background-color:#888;
white-space:nowrap;
}

.tp-caption.small_text {
position:absolute;
color:#fff;
text-shadow:0px 2px 5px rgba(0, 0, 0, 0.5);
font-weight:700;
font-size:14px;
line-height:20px;
font-family:Arial;
margin:0px;
border-width:0px;
border-style:none;
white-space:nowrap;
}

.tp-caption.medium_text {
color:#ffffff;
text-shadow:rgba(0, 0, 0, 0.498039) 0px 2px 5px;
font-weight:700;
font-size:20px;
line-height:20px;
font-family:Arial;
margin:0px;
white-space:nowrap;
max-width:40%;
background-color:transparent;
text-decoration:none;
border-width:0px;
border-color:rgb(255, 255, 255);
border-style:none;
}

.tp-caption.large_text {
position:absolute;
color:#fff;
text-shadow:0px 2px 5px rgba(0, 0, 0, 0.5);
font-weight:700;
font-size:40px;
line-height:40px;
font-family:Arial;
margin:0px;
border-width:0px;
border-style:none;
white-space:nowrap;
}

.tp-caption.very_large_text {
position:absolute;
color:#fff;
text-shadow:0px 2px 5px rgba(0, 0, 0, 0.5);
font-weight:700;
font-size:60px;
line-height:60px;
font-family:Arial;
margin:0px;
border-width:0px;
border-style:none;
white-space:nowrap;
letter-spacing:-2px;
}

.tp-caption.very_big_white {
position:absolute;
color:#fff;
text-shadow:none;
font-weight:800;
font-size:60px;
line-height:60px;
font-family:Arial;
margin:0px;
border-width:0px;
border-style:none;
white-space:nowrap;
padding:0px 4px;
padding-top:1px;
background-color:#000;
}

.tp-caption.very_big_black {
position:absolute;
color:#000;
text-shadow:none;
font-weight:700;
font-size:60px;
line-height:60px;
font-family:Arial;
margin:0px;
border-width:0px;
border-style:none;
white-space:nowrap;
padding:0px 4px;
padding-top:1px;
background-color:#fff;
}

.tp-caption.modern_medium_fat {
position:absolute;
color:#000;
text-shadow:none;
font-weight:800;
font-size:24px;
line-height:20px;
font-family:"Open Sans", sans-serif;
margin:0px;
border-width:0px;
border-style:none;
white-space:nowrap;
}

.tp-caption.modern_medium_fat_white {
position:absolute;
color:#fff;
text-shadow:none;
font-weight:800;
font-size:24px;
line-height:20px;
font-family:"Open Sans", sans-serif;
margin:0px;
border-width:0px;
border-style:none;
white-space:nowrap;
}

.tp-caption.modern_medium_light {
position:absolute;
color:#000;
text-shadow:none;
font-weight:300;
font-size:24px;
line-height:20px;
font-family:"Open Sans", sans-serif;
margin:0px;
border-width:0px;
border-style:none;
white-space:nowrap;
}

.tp-caption.modern_big_bluebg {
position:absolute;
color:#fff;
text-shadow:none;
font-weight:800;
font-size:30px;
line-height:36px;
font-family:"Open Sans", sans-serif;
padding:3px 10px;
margin:0px;
border-width:0px;
border-style:none;
background-color:#4e5b6c;
letter-spacing:0;
}

.tp-caption.modern_big_redbg {
position:absolute;
color:#fff;
text-shadow:none;
font-weight:300;
font-size:30px;
line-height:36px;
font-family:"Open Sans", sans-serif;
padding:3px 10px;
padding-top:1px;
margin:0px;
border-width:0px;
border-style:none;
background-color:#de543e;
letter-spacing:0;
}

.tp-caption.modern_small_text_dark {
position:absolute;
color:#555;
text-shadow:none;
font-size:14px;
line-height:22px;
font-family:Arial;
margin:0px;
border-width:0px;
border-style:none;
white-space:nowrap;
}

.tp-caption.boxshadow {
-moz-box-shadow:0px 0px 20px rgba(0, 0, 0, 0.5);
-webkit-box-shadow:0px 0px 20px rgba(0, 0, 0, 0.5);
box-shadow:0px 0px 20px rgba(0, 0, 0, 0.5);
}

.tp-caption.black {
color:#000;
text-shadow:none;
}

.tp-caption.noshadow {
text-shadow:none;
}

.tp-caption.thinheadline_dark {
position:absolute;
color:rgba(0,0,0,0.85);
text-shadow:none;
font-weight:300;
font-size:30px;
line-height:30px;
font-family:"Open Sans";
background-color:transparent;
}

.tp-caption.thintext_dark {
position:absolute;
color:rgba(0,0,0,0.85);
text-shadow:none;
font-weight:300;
font-size:16px;
line-height:26px;
font-family:"Open Sans";
background-color:transparent;
}

.tp-caption.largeblackbg {
position:absolute;
color:#fff;
text-shadow:none;
font-weight:300;
font-size:50px;
line-height:70px;
font-family:"Open Sans";
background-color:#000;
padding:0px 20px;
-webkit-border-radius:0px;
-moz-border-radius:0px;
border-radius:0px;
}

.tp-caption.largepinkbg {
position:absolute;
color:#fff;
text-shadow:none;
font-weight:300;
font-size:50px;
line-height:70px;
font-family:"Open Sans";
background-color:#db4360;
padding:0px 20px;
-webkit-border-radius:0px;
-moz-border-radius:0px;
border-radius:0px;
}

.tp-caption.largewhitebg {
position:absolute;
color:#000;
text-shadow:none;
font-weight:300;
font-size:50px;
line-height:70px;
font-family:"Open Sans";
background-color:#fff;
padding:0px 20px;
-webkit-border-radius:0px;
-moz-border-radius:0px;
border-radius:0px;
}

.tp-caption.largegreenbg {
position:absolute;
color:#fff;
text-shadow:none;
font-weight:300;
font-size:50px;
line-height:70px;
font-family:"Open Sans";
background-color:#67ae73;
padding:0px 20px;
-webkit-border-radius:0px;
-moz-border-radius:0px;
border-radius:0px;
}

.tp-caption.excerpt {
font-size:36px;
line-height:36px;
font-weight:700;
font-family:Arial;
color:#ffffff;
text-decoration:none;
background-color:rgba(0, 0, 0, 1);
text-shadow:none;
margin:0px;
letter-spacing:-1.5px;
padding:1px 4px 0px 4px;
width:150px;
white-space:normal !important;
height:auto;
border-width:0px;
border-color:rgb(255, 255, 255);
border-style:none;
}

.tp-caption.large_bold_grey {
font-size:60px;
line-height:60px;
font-weight:800;
font-family:"Open Sans";
color:rgb(102, 102, 102);
text-decoration:none;
background-color:transparent;
text-shadow:none;
margin:0px;
padding:1px 4px 0px;
border-width:0px;
border-color:rgb(255, 214, 88);
border-style:none;
}

.tp-caption.medium_thin_grey {
font-size:34px;
line-height:30px;
font-weight:300;
font-family:"Open Sans";
color:rgb(102, 102, 102);
text-decoration:none;
background-color:transparent;
padding:1px 4px 0px;
text-shadow:none;
margin:0px;
border-width:0px;
border-color:rgb(255, 214, 88);
border-style:none;
}

.tp-caption.small_thin_grey {
font-size:18px;
line-height:26px;
font-weight:300;
font-family:"Open Sans";
color:rgb(117, 117, 117);
text-decoration:none;
background-color:transparent;
padding:1px 4px 0px;
text-shadow:none;
margin:0px;
border-width:0px;
border-color:rgb(255, 214, 88);
border-style:none;
}

.tp-caption.lightgrey_divider {
text-decoration:none;
background-color:rgba(235, 235, 235, 1);
width:370px;
height:3px;
background-position:initial initial;
background-repeat:initial initial;
border-width:0px;
border-color:rgb(34, 34, 34);
border-style:none;
}

.tp-caption.large_bold_darkblue {
font-size:58px;
line-height:60px;
font-weight:800;
font-family:"Open Sans";
color:rgb(52, 73, 94);
text-decoration:none;
background-color:transparent;
border-width:0px;
border-color:rgb(255, 214, 88);
border-style:none;
}

.tp-caption.medium_bg_darkblue {
font-size:20px;
line-height:20px;
font-weight:800;
font-family:"Open Sans";
color:rgb(255, 255, 255);
text-decoration:none;
background-color:rgb(52, 73, 94);
padding:10px;
border-width:0px;
border-color:rgb(255, 214, 88);
border-style:none;
}

.tp-caption.medium_bold_red {
font-size:24px;
line-height:30px;
font-weight:800;
font-family:"Open Sans";
color:rgb(227, 58, 12);
text-decoration:none;
background-color:transparent;
padding:0px;
border-width:0px;
border-color:rgb(255, 214, 88);
border-style:none;
}

.tp-caption.medium_light_red {
font-size:21px;
line-height:26px;
font-weight:300;
font-family:"Open Sans";
color:rgb(227, 58, 12);
text-decoration:none;
background-color:transparent;
padding:0px;
border-width:0px;
border-color:rgb(255, 214, 88);
border-style:none;
}

.tp-caption.medium_bg_red {
font-size:20px;
line-height:20px;
font-weight:800;
font-family:"Open Sans";
color:rgb(255, 255, 255);
text-decoration:none;
background-color:rgb(227, 58, 12);
padding:10px;
border-width:0px;
border-color:rgb(255, 214, 88);
border-style:none;
}

.tp-caption.medium_bold_orange {
font-size:24px;
line-height:30px;
font-weight:800;
font-family:"Open Sans";
color:rgb(243, 156, 18);
text-decoration:none;
background-color:transparent;
border-width:0px;
border-color:rgb(255, 214, 88);
border-style:none;
}

.tp-caption.medium_bg_orange {
font-size:20px;
line-height:20px;
font-weight:800;
font-family:"Open Sans";
color:rgb(255, 255, 255);
text-decoration:none;
background-color:rgb(243, 156, 18);
padding:10px;
border-width:0px;
border-color:rgb(255, 214, 88);
border-style:none;
}

.tp-caption.grassfloor {
text-decoration:none;
background-color:rgba(160, 179, 151, 1);
width:4000px;
height:150px;
border-width:0px;
border-color:rgb(34, 34, 34);
border-style:none;
}

.tp-caption.large_bold_white {
font-size:58px;
line-height:60px;
font-weight:800;
font-family:"Open Sans";
color:rgb(255, 255, 255);
text-decoration:none;
background-color:transparent;
border-width:0px;
border-color:rgb(255, 214, 88);
border-style:none;
}

.tp-caption.medium_light_white {
font-size:30px;
line-height:36px;
font-weight:300;
font-family:"Open Sans";
color:rgb(255, 255, 255);
text-decoration:none;
background-color:transparent;
padding:0px;
border-width:0px;
border-color:rgb(255, 214, 88);
border-style:none;
}

.tp-caption.mediumlarge_light_white {
font-size:34px;
line-height:40px;
font-weight:300;
font-family:"Open Sans";
color:rgb(255, 255, 255);
text-decoration:none;
background-color:transparent;
padding:0px;
border-width:0px;
border-color:rgb(255, 214, 88);
border-style:none;
}

.tp-caption.mediumlarge_light_white_center {
font-size:34px;
line-height:40px;
font-weight:300;
font-family:"Open Sans";
color:#ffffff;
text-decoration:none;
background-color:transparent;
padding:0px 0px 0px 0px;
text-align:center;
border-width:0px;
border-color:rgb(255, 214, 88);
border-style:none;
}

.tp-caption.medium_bg_asbestos {
font-size:20px;
line-height:20px;
font-weight:800;
font-family:"Open Sans";
color:rgb(255, 255, 255);
text-decoration:none;
background-color:rgb(127, 140, 141);
padding:10px;
border-width:0px;
border-color:rgb(255, 214, 88);
border-style:none;
}

.tp-caption.medium_light_black {
font-size:30px;
line-height:36px;
font-weight:300;
font-family:"Open Sans";
color:rgb(0, 0, 0);
text-decoration:none;
background-color:transparent;
padding:0px;
border-width:0px;
border-color:rgb(255, 214, 88);
border-style:none;
}

.tp-caption.large_bold_black {
font-size:58px;
line-height:60px;
font-weight:800;
font-family:"Open Sans";
color:rgb(0, 0, 0);
text-decoration:none;
background-color:transparent;
border-width:0px;
border-color:rgb(255, 214, 88);
border-style:none;
}

.tp-caption.mediumlarge_light_darkblue {
font-size:34px;
line-height:40px;
font-weight:300;
font-family:"Open Sans";
color:rgb(52, 73, 94);
text-decoration:none;
background-color:transparent;
padding:0px;
border-width:0px;
border-color:rgb(255, 214, 88);
border-style:none;
}

.tp-caption.small_light_white {
font-size:17px;
line-height:28px;
font-weight:300;
font-family:"Open Sans";
color:rgb(255, 255, 255);
text-decoration:none;
background-color:transparent;
padding:0px;
border-width:0px;
border-color:rgb(255, 214, 88);
border-style:none;
}

.tp-caption.roundedimage {
border-width:0px;
border-color:rgb(34, 34, 34);
border-style:none;
}

.tp-caption.large_bg_black {
font-size:63px;
line-height:58px;
font-weight:800;
font-family:"Open Sans";
color:rgb(255, 255, 255);
text-decoration:none;
background-color:rgb(88, 152, 255);
padding:10px 20px 15px;
border-width:0px;
border-color:rgb(255, 214, 88);
border-style:none;
}

.tp-caption.large_bg_black:hover {
color:rgb(255, 255, 255);
background-color:rgb(0, 0, 0);
font-size:40px;
line-height:40px;
font-weight:800;
font-family:"Open Sans";
font-style:italic;
text-decoration:none;
padding:10px 20px 15px;
border-width:0px;
border-color:rgb(255, 214, 88);
border-style:none;
}

.tp-caption.mediumwhitebg {
font-size:30px;
line-height:30px;
font-weight:300;
font-family:"Open Sans";
color:rgb(0, 0, 0);
text-decoration:none;
background-color:rgb(255, 255, 255);
padding:5px 15px 10px;
text-shadow:none;
border-width:0px;
border-color:rgb(0, 0, 0);
border-style:none;
}

.tp-caption.Megahost_p_4 {
color:#ffffff;
width:50%;
max-width:520px;
padding:15px 10px 15px 10px;
margin-bottom:20px;
text-decoration:none;
background:rgba(0, 0, 0, 0.701961);
background-color:rgba(0, 0, 0, 0.701961);
border-width:0px;
border-color:rgb(255, 255, 255);
border-style:none;
}

.tp-caption.Megahost_button_2 {
width:auto;
height:auto;
color:#fff !important;
padding:7px 15px 7px 15px;
text-decoration:none;
background-color:transparent;
border-radius:3px 3px 3px 3px;
border-width:0px;
border-color:rgb(255, 255, 255);
border-style:none;
}

.tp-caption.Megahost_h1_2 {
text-shadow:rgba(0, 0, 0, 0.498039) 0px 2px 5px;
font-weight:700;
font-family:OpenSansBold, Arial, sans-serif;
margin:0px;
white-space:nowrap;
text-decoration:none;
font-size:40px;
line-height:45px;
color:#ffffff;
padding:15px 20px 15px 20px;
background-color:transparent;
border-width:0px;
border-color:rgb(255, 255, 255);
border-style:none;
}

.tp-caption.Megahost_p_2 {
color:#fff;
width:50%;
max-width:700px;
padding:15px 10px 15px 10px;
margin-bottom:20px;
background-color:rgba(35, 35, 35, 1);
background:rgba(0,0,0,0.7);
text-decoration:none;
border-width:0px;
border-color:rgb(255, 255, 255);
border-style:none;
}

.tp-caption.Megahost_h1_3 {
text-shadow:rgba(0, 0, 0, 0.498039) 0px 2px 5px;
font-weight:700;
font-family:OpenSansBold, Arial, sans-serif;
margin:0px;
white-space:nowrap;
text-decoration:none;
font-size:40px;
line-height:45px;
color:#ffffff;
padding:15px 20px 15px 20px;
background-color:transparent;
width:60%;
max-width:1100px;
border-width:0px;
border-color:rgb(255, 255, 255);
border-style:none;
}

.tp-caption.Megahost_p_3 {
color:#fff;
width:70%;
max-width:1170px;
padding:15px 10px 15px 10px;
margin-bottom:20px;
background-color:rgba(35, 35, 35, 1);
background:rgba(0,0,0,0.7);
text-decoration:none;
border-width:0px;
border-color:rgb(255, 255, 255);
border-style:none;
}


@import url(http://fonts.googleapis.com/css?family=Open+Sans:400,800,300,700);

.tp-caption a {
text-shadow:none;
-webkit-transition:all 0.2s ease-out;
-moz-transition:all 0.2s ease-out;
-o-transition:all 0.2s ease-out;
-ms-transition:all 0.2s ease-out;
}
</style>
<link rel='stylesheet' id='megahost_style-css'  href='http://hostbengal.com/wp-content/themes/megahost/css/style.css?ver=4.0.5' type='text/css' media='screen' />
<link rel='stylesheet' id='skins-css'  href='http://hostbengal.com/wp-content/themes/megahost/css/skins/blue/blue.css?ver=4.0.5' type='text/css' media='screen' />
<link rel='stylesheet' id='wpgmaps-style-css'  href='http://hostbengal.com/wp-content/plugins/wp-google-maps/css/wpgmza_style.css?ver=4.0.5' type='text/css' media='all' />
<script type='text/javascript' src='http://hostbengal.com/wp-includes/js/jquery/jquery.js?ver=1.11.1'></script>
<script type='text/javascript' src='http://hostbengal.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.2.1'></script>
<script type='text/javascript' src='http://hostbengal.com/wp-content/plugins/mailchimp/js/scrollTo.js?ver=1.4.1'></script>
<script type='text/javascript' src='http://hostbengal.com/wp-content/plugins/contact-form-7/includes/js/jquery.form.min.js?ver=3.50.0-2014.02.05'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var mailchimpSF = {"ajax_url":"http:\/\/hostbengal.com\/"};
/* ]]> */
</script>
<script type='text/javascript' src='http://hostbengal.com/wp-content/plugins/mailchimp/js/mailchimp.js?ver=1.4.1'></script>
<script type='text/javascript' src='http://hostbengal.com/wp-includes/js/jquery/ui/jquery.ui.core.min.js?ver=1.10.4'></script>
<script type='text/javascript' src='http://hostbengal.com/wp-content/plugins/mailchimp//js/datepicker.js?ver=4.0.5'></script>
<script type='text/javascript' src='http://hostbengal.com/wp-content/plugins/revslider/rs-plugin/js/jquery.themepunch.plugins.min.js?rev=4.5.01&#038;ver=4.0.5'></script>
<script type='text/javascript' src='http://hostbengal.com/wp-content/plugins/revslider/rs-plugin/js/jquery.themepunch.revolution.min.js?rev=4.5.01&#038;ver=4.0.5'></script>
<script type='text/javascript' src='http://hostbengal.com/wp-content/plugins/slick-contact-forms/js/jquery.slick.contact.1.3.2.js?ver=4.0.5'></script>
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://hostbengal.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://hostbengal.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.0.5" />
<link rel='canonical' href='http://hostbengal.com/contact/' />
<link rel='shortlink' href='http://hostbengal.com/?p=88' />
	<script type="text/javascript">
		jQuery(function($) {
			$('.date-pick').each(function() {
				var format = $(this).data('format') || 'mm/dd/yyyy';
				format = format.replace(/yyyy/i, 'yy');
				$(this).datepicker({
					autoFocusNextInput: true,
					constrainInput: false,
					changeMonth: true,
					changeYear: true,
					beforeShow: function(input, inst) { $('#ui-datepicker-div').addClass('show'); },
					dateFormat: format.toLowerCase(),
				});
			});
			d = new Date();
			$('.birthdate-pick').each(function() {
				var format = $(this).data('format') || 'mm/dd';
				format = format.replace(/yyyy/i, 'yy');
				$(this).datepicker({
					autoFocusNextInput: true,
					constrainInput: false,
					changeMonth: true,
					changeYear: false,
					minDate: new Date(d.getFullYear(), 1-1, 1),
					maxDate: new Date(d.getFullYear(), 12-1, 31),
					beforeShow: function(input, inst) { $('#ui-datepicker-div').removeClass('show'); },
					dateFormat: format.toLowerCase(),
				});

			});

		});
	</script>
	<script type="text/javascript">$=jQuery;</script><link rel="Shortcut Icon" type="image/x-icon" href="http://hostbengal.com/wp-content/themes/megahost/img/icons/favicon.ico" />	<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>

	<link rel="stylesheet" href="http://hostbengal.com/wp-content/plugins/slick-contact-forms/skin.php?widget_id=2&amp;skin=black" type="text/css" media="screen"  />
	<link rel="stylesheet" href="http://hostbengal.com/wp-content/plugins/slick-contact-forms/css/form.css" type="text/css" media="screen"  />	</head>

    <body class="page page-id-88 page-template page-template-template-contact-php"> 
      
            
      <!-- layout-->
      
      <div id="layout" class="">

        				
        <!-- Header -->
        <header>
						<!-- Info Head -->
        		<section class="container">
              <div class="row info_head">
                <div class="col-md-12">
                  <ul>
                      <li><i  class="icon-phone" style="color: #0a0000; font-size: 14pxpx;" ></i><a href="http://www.hostbengal.com">+88 01734 636060</a></li><li><i  class="icon-comments" style="color: #0a0000; font-size: 14pxpx;" ></i><a href="">Skype: shahinur_cse</a></li><li><i  class="icon-laptop" style="color: #0a0000; font-size: 14pxpx;" ></i><a href="http://secure.hostbengal.com/index.php">Support</a></li>                  </ul>
                </div>
						</div>
        </section>
        <!-- Info Head -->

        <!-- Nav -->
        <nav class="gray">
            <div class="container">
                <div class="row">
                    <!-- Logo -->
                    <div class="logo col-md-2">
                                                <a style="color: ; font-style: ; font-family: ; font-size: px;" 
 href="http://hostbengal.com">
                                
                                                                 <img src="http://hostbengal.com/wp-content/uploads/2014/07/logo-v.png" alt="" />
                                                            </a>
                                            </div>
                    <!-- End Logo -->

                    <div class="col-md-10">
                       <ul id="menu" class="sf-menu"><li id="menu-item-485" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-485"><a href="http://hostbengal.com/">Home</a></li>
<li id="menu-item-556" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-556"><a href="http://hostbengal.com/domain-name/">Domain Name&#8217;s</a></li>
<li id="menu-item-487" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-487"><a href="http://hostbengal.com/shared-hosting/">Shared Hosting</a></li>
<li id="menu-item-495" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-495"><a href="http://hostbengal.com/virtual-servers/">VPS Hosting</a></li>
<li id="menu-item-496" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-496"><a href="http://hostbengal.com/dedicated-servers/">Dedicated Hosting</a></li>
<li id="menu-item-601" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-601"><a href="#">Client Area</a>
<ul class="sub-menu">
	<li id="menu-item-474" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-474"><a href="http://secure.hostbengal.com/">Client Acces</a></li>
	<li id="menu-item-602" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-602"><a href="http://secure.hostbengal.com/index.php/order/domain-checker">Domain Checker</a></li>
	<li id="menu-item-475" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-475"><a href="http://secure.hostbengal.com/index.php/order">Order</a></li>
</ul>
</li>
<li id="menu-item-490" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-88 current_page_item menu-item-490"><a href="http://hostbengal.com/contact/">Contact</a></li>
</ul>                    </div>
                </div>
            </div>
        </nav>
                <section class="section_title">
        <div class="container">
            <div class="row-fluid">
                  <h1>Contact</h1>            </div>
        </div>
    </section>
     </header>
	<section class="info_content " style="background-color: ;"><div class="container"><div class="row">
<div class="col-sm-6 col-md-4">
  <div class="item_location">
      <div class="row">
           <div class="col-md-6">
              <img src="http://hostbengal.com/wp-content/uploads/2014/05/office21.jpg" alt="" class="img-responsive">                              
          </div>
          <div class="span6">
              <h4>Jessore</h4>
              <ul>
                <li>+88 01795 430102</li><li>contact@hostbengal.com</li>              </ul>
          </div>
          <div class="col-md-12">
               <p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</p>
          </div>
      </div> 
  </div>
</div>      
      
</div></div></section><section class="info_content gray shadows borders"><div class="container">  
          <div class="container">

              <div class="row">
                  <div class="col-md-5 contact">
                      <h2>Contact With Us</h2>
                      <div class="wpcf7" id="wpcf7-f4-o1">
<div class="screen-reader-response"></div>
<form action="/contact/#wpcf7-f4-o1" method="post" class="wpcf7-form" novalidate="novalidate">
<div style="display: none;">
<input type="hidden" name="_wpcf7" value="4" />
<input type="hidden" name="_wpcf7_version" value="3.8.1" />
<input type="hidden" name="_wpcf7_locale" value="en_US" />
<input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f4-o1" />
<input type="hidden" name="_wpnonce" value="78a2b63676" />
</div>
<p>Your Name (required)<br />
    <span class="wpcf7-form-control-wrap your-name"><input type="text" name="your-name" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" /></span> </p>
<p>Your Email (required)<br />
    <span class="wpcf7-form-control-wrap your-email"><input type="email" name="your-email" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email" aria-required="true" aria-invalid="false" /></span> </p>
<p>Your Message<br />
    <span class="wpcf7-form-control-wrap your-message"><textarea name="your-message" cols="40" rows="10" class="wpcf7-form-control wpcf7-textarea" aria-invalid="false"></textarea></span> </p>
<p><input type="submit" value="Send" class="wpcf7-form-control wpcf7-submit" /></p>
<div class="wpcf7-response-output wpcf7-display-none"></div></form></div>                      
                  </div>
                  <div class="col-md-7 map">
                      
            <style>
            #wpgmza_map img { max-width:none !important; }
            </style>
            
                
            <div id="wpgmza_map" style="display:block; overflow:auto; width:600px; height:400px; float:left;">
                <div style='text-align:center; width:90%;'>
                        <small><strong>The map could not load.</strong><br />This is normally caused by a conflict with another plugin or a JavaScript error that is preventing our plugin's Javascript from executing. Please try disable all plugins one by one and see if this problem persists. If it persists, please contact WP Google Maps for support.</small>
                    
                </div>
            </div>
                                                </div>  
              </div>

          </div>

    </section>
    
    
<!-- Footer top-->
<div class="shadows">
    <footer class="container footer_top">
                <div class="row">
          
						<!-- Social Footer -->
            <div class="col-md-3">
                <h2>Follow HostBengal</h2>
                            <ul class="social_footer"><li><a href="https://www.facebook.com/HostBengalHosting" target="_blank"><i  class="icon-facebook" style="color: #232323; font-size: 20pxpx;" >		</i>Follow on Facebook</a></li><li><a href="#" target="_blank"><i  class="icon-twitter" style="color: #232323; font-size: 20pxpx;" >		</i>Follow on twitter</a></li><li><a href="#" target="_blank"><i  class="icon-google-plus-sign" style="color: #232323; font-size: 20pxpx;" >		</i>Follow on Google</a></li><li><a href="#" target="_blank"><i  class="" style="color: #00bc96; font-size: 36pxpx;" >		</i>Follow on...</a></li></ul>            </div>
           	<!-- End Social Footer -->
          
						<!-- About Us Footer -->
                            <div class="col-md-3">   
                    <h2>About Us</h2>
                    <p>We are a webhosting and domain registration company in bangladesh. Client satisfaction is our motto. We provide low cost Webhosting And Domain Registration.</p>
                    <a href="#">
                        <img src="" alt="">
                    </a>
                </div>
                       <!-- End About Us Footer -->

          	<!-- Newsletter-->
                            <div class="newsletter" id="mc_embed_signup">
                    <div class="col-md-3">    
                        <h2>Newsletter</h2>
                        <p>Subscribe to our email newsletter for useful tips and valuable resources.</p>
            
                        <div class="newsletter" id="mc_embed_signup">
                          
<div id="sidebar" role="complementary">

  <div id="mailchimpsf_widget-2" class="widget widget_mailchimpsf_widget">
<style>
	.widget_mailchimpsf_widget .widget-title {
		line-height: 1.4em;
		margin-bottom: 0.75em;
	}
	#mc_subheader {
		line-height: 1.25em;
		margin-bottom: 18px;
	}
	.mc_merge_var {
		margin-bottom: 1.0em;
	}
	.mc_var_label,
	.mc_interest_label {
		display: block;
		margin-bottom: 0.5em;
	}
	.mc_input {
		-moz-box-sizing: border-box;
		-webkit-box-sizing: border-box;
		box-sizing: border-box;
		width: 100%;
	}
	.mc_input.mc_phone {
		width: auto;
	}
	select.mc_select {
		margin-top: 0.5em;
		width: 100%;
	}
	.mc_address_label {
		margin-top: 1.0em;
		margin-bottom: 0.5em;
		display: block;
	}
	.mc_address_label ~ select {
		width: 100%;		
	}
	.mc_list li {
		list-style: none;
		background: none !important;
	}
	.mc_interests_header {
		margin-top: 1.0em;
		margin-bottom: 0.5em;
	}
	.mc_interest label,
	.mc_interest input {
		margin-bottom: 0.4em;
	}
	#mc_signup_submit {
		margin-top: 1.5em;
		width: 80%;
	}
	#mc_unsub_link a {
		font-size: 0.75em;
	}
	#mc_unsub_link {
		margin-top: 1.0em;
	}
	.mc_header_address,
	.mc_email_format {
		display: block;
		font-weight: bold;
		margin-top: 1.0em;
		margin-bottom: 0.5em;
	}
	.mc_email_options {
		margin-top: 0.5em;
	}
	.mc_email_type {
		padding-left: 4px;
	}
</style>

<div id="mc_signup">
	<form method="post" action="#mc_signup" id="mc_signup_form">
		<input type="hidden" id="mc_submit_type" name="mc_submit_type" value="html" />
		<input type="hidden" name="mcsf_action" value="mc_submit_signup_form" />
		<input type="hidden" id="_mc_submit_signup_form_nonce" name="_mc_submit_signup_form_nonce" value="fc2ad59b59" />		
		
	<div class="mc_form_inside">
		
		<div class="updated" id="mc_message">
					</div><!-- /mc_message -->

		
<div class="mc_merge_var">
		<label for="mc_mv_EMAIL" class="mc_var_label mc_header mc_header_email">Email Address<span class="mc_required">*</span></label>
	<input type="text" size="18" placeholder="" name="mc_mv_EMAIL" id="mc_mv_EMAIL" class="mc_input"/>
</div><!-- /mc_merge_var -->
<div class="mc_merge_var">
		<label for="mc_mv_FNAME" class="mc_var_label mc_header mc_header_text">First Name</label>
	<input type="text" size="18" placeholder="" name="mc_mv_FNAME" id="mc_mv_FNAME" class="mc_input"/>
</div><!-- /mc_merge_var -->			<div id="mc-indicates-required">
				* = required field			</div><!-- /mc-indicates-required -->
			
		<div class="mc_signup_submit">
			<input type="submit" name="mc_signup_submit" id="mc_signup_submit" value="Subscribe" class="button" />
		</div><!-- /mc_signup_submit -->
	
	
					<br/>
			<div id="mc_display_rewards" align="center">
				powered by <a href="http://www.mailchimp.com/affiliates/?aid=4778cc81ec53d894fbc91c921&#038;afl=1">MailChimp</a>!
			</div><!-- /mc_display_rewards -->
					
	</div><!-- /mc_form_inside -->
	</form><!-- /mc_signup_form -->
</div><!-- /mc_signup_container -->
	</div>		<div class="dcjq-contact" id="dc_jqslickcontact_widget-2-item">
		
		<div class="dc-corner"><span></span></div>
			<form class="slick-form" method="post" action="http://hostbengal.com/wp-content/plugins/slick-contact-forms/slick_mail.php">
			  <fieldset>
			    <ol>
				  									  <li class="input-row">
				    <label for="input1">Name</label>
					<input class="required defaultText text-input" id="input1" name="input1" value="" title="Name" />
					<input type="hidden" name="valid1" value="1" />
				  </li>
				    									  <li class="input-row">	
				    <label for="input2">Email</label>
					<input class="required email defaultText text-input" id="input2" name="input2" value="" title="Email" />
					<input type="hidden" name="valid2" value="2" />
				  </li>
				  				  				  				  <li class="text-row">	
				    <label for="dcscf-comments">Questions/Comments</label>
					<textarea id="dcscf-comments" name="comments" class="required defaultText text-area" rows="6" title="Questions/Comments"></textarea>
				  </li>
				  				  <li class="nocomment">
					<label for="nocomment">Leave This Field Empty</label>
					<input id="nocomment" value="" name="nocomment" />
				  </li>
				  <li class="comment-row">We welcome any feedback, questions or comments</li>				  <li class="button-row">
					<input type="submit" name="submit" value="Submit" class="btn-submit" />
					<input type="hidden" name="key" value="5f65dcf0a88d32657aa654b08a146a1f" /><input type="hidden" name="label1" value="Name" /><input type="hidden" name="label2" value="Email" /><input type="hidden" name="labelText" value="Questions/Comments" /><input type="hidden" name="tabText" value="Contact Us" /><input type="hidden" name="emailTo" value="" /><input type="hidden" name="action" value="submit" /><input type="hidden" name="v_error" id="v-error" value="Required" /><input type="hidden" name="v_email" id="v-email" value="Enter a valid email" />				  </li>
				</ol>
			  </fieldset>
			  <div class="slick-response"></div>
			</form>
				</div>
		
</div>                      </div>
                  </div>
                        <!-- End Newsletter-->

            <!-- Contact Us Footer-->
                            <div class="col-md-3">   
                    <h2>Contact Us</h2>
                    <p>For any kind of query or abuse olease contact with us...</p>
                    <ul class="contact_footer">
                        <li><i  class="icon-envelope" style="color: #555555; font-size: 12pxpx;" ></i>E-Mail Us:<a href="#">contact@hostbengal.com</a></li><li><i  class="icon-phone" style="color: #555555; font-size: 12pxpx;" ></i>Call Us at:<a href="#">+88 01734 636060</a></li><li><i  class="icon-map-marker" style="color: #555555; font-size: 12pxpx;" ></i>Location:<a href="#">Jessore, Ambattala</a></li>                      </ul>
                    </div>
                                    	<!-- End Contact Us Footer-->
                </div>
            </div>
                </footer>
     </div>
			
			<!-- Footer Down-->
			<footer class="footer_down">
        <div class="container">
            <div class="row">
              <!-- About Footer -->
                <div class="col-md-8">
                    <ul id="menu" class="nav_footer"><li id="menu-item-508" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-508"><a href="http://hostbengal.com/">Home</a></li>
<li id="menu-item-652" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-652"><a href="http://hostbengal.com/promotions/">Current Promotion&#8217;s</a></li>
<li id="menu-item-491" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-88 current_page_item menu-item-491"><a href="http://hostbengal.com/contact/">Contact</a></li>
<li id="menu-item-655" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-655"><a href="http://hostbengal.com/privacy-policy/">Privacy Policy</a></li>
<li id="menu-item-677" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-677"><a href="http://hostbengal.com/how-to-pay/">How To Pay</a></li>
</ul>									</div>
              		<!-- End Nav Footer -->
									
              		<!-- copyright Footer -->
                  <div class="col-md-4 text_right">
                                            <p><a href="http://hostbengal.com">© 2013-14 HostBengal. All rights reserved.</a></p>
                                        </div>
              		<!-- End copyright Footer -->
              </div>
          </div>
      </footer>
      <!-- End Footer Down-->
              
        
                
        <script type="text/javascript">
            var gmapsJsHost = (("https:" == document.location.protocol) ? "https://" : "http://");
            document.write(unescape("%3Cscript src='" + gmapsJsHost + "maps.google.com/maps/api/js?v=3.14&sensor=false' type='text/javascript'%3E%3C/script%3E"));
        </script>

                
       
        <script type="text/javascript" >

            if ('undefined' == typeof window.jQuery) {
                document.getElementById('wpgmza_map').innerHTML = 'Error: In order for WP Google Maps to work, jQuery must be installed. A check was done and jQuery was not present. Please see the <a href="http://www.wpgmaps.com/documentation/troubleshooting/jquery-troubleshooting/" title="WP Google Maps - jQuery Troubleshooting">jQuery troubleshooting section of our site</a> for more information.';
            } else {
                // all good.. continue...
            }

            jQuery(function() {


                jQuery(document).ready(function(){
                    if (/1\.(0|1|2|3|4|5|6|7)\.(0|1|2|3|4|5|6|7|8|9)/.test(jQuery.fn.jquery)) {
                        document.getElementById('wpgmza_map').innerHTML = 'Error: Your version of jQuery is outdated. WP Google Maps requires jQuery version 1.7+ to function correctly. Go to Maps->Settings and check the box that allows you to over-ride your current jQuery to try eliminate this problem.';
                    } else {

                        jQuery("#wpgmza_map").css({
                            height:'400px',
                            width:'600px'
                        });
                        var myLatLng = new google.maps.LatLng(23.168523,89.217997);
                        MYMAP.init('#wpgmza_map', myLatLng, 14);
                        UniqueCode=Math.round(Math.random()*10000);
                        MYMAP.placeMarkers('http://hostbengal.com/wp-content/uploads/wp-google-maps/1markers.xml?u='+UniqueCode,1,null,null,null);

                        jQuery('body').on('tabsactivate', function(event, ui) {
                            MYMAP.init('#wpgmza_map', myLatLng, 14);
                            UniqueCode=Math.round(Math.random()*10000);
                            MYMAP.placeMarkers('http://hostbengal.com/wp-content/uploads/wp-google-maps/1markers.xml?u='+UniqueCode,1,null,null,null);
                        });
                    }

                });

            });


            var MYMAP = {
                map: null,
                bounds: null
            }

            MYMAP.init = function(selector, latLng, zoom) {
                var myOptions = {
                    zoom:zoom,
                    center: latLng,
                    zoomControl: true,
                    panControl: true,
                    mapTypeControl: true,
                    streetViewControl: true,
                    draggable: true,
                    disableDoubleClickZoom: false,
                    scrollwheel: true,
                    mapTypeId: google.maps.MapTypeId.HYBRID                }

                this.map = new google.maps.Map(jQuery(selector)[0], myOptions);
                this.bounds = new google.maps.LatLngBounds();
                
                
                
                

            

           
                 
                
                
                
                                                                                                
                google.maps.event.addListener(MYMAP.map, 'click', function() {
                    infoWindow.close();
                });
                
                
                
            }

            var infoWindow = new google.maps.InfoWindow();
                        infoWindow.setOptions({maxWidth:250});

            google.maps.event.addDomListener(window, 'resize', function() {
                var myLatLng = new google.maps.LatLng(23.168523,89.217997);
                MYMAP.map.setCenter(myLatLng);
            });
            MYMAP.placeMarkers = function(filename,map_id,radius,searched_center,distance_type) {
                var check1 = 0;
                jQuery.get(filename, function(xml){
                    jQuery(xml).find("marker").each(function(){
                        var wpmgza_map_id = jQuery(this).find('map_id').text();

                        if (wpmgza_map_id == map_id) {
                            var wpmgza_address = jQuery(this).find('address').text();
                            var lat = jQuery(this).find('lat').text();
                            var lng = jQuery(this).find('lng').text();
                            var wpmgza_anim = jQuery(this).find('anim').text();
                            var wpmgza_infoopen = jQuery(this).find('infoopen').text();
                            var current_lat = jQuery(this).find('lat').text();
                            var current_lng = jQuery(this).find('lng').text();
                            var show_marker_radius = true;
                            
                            if (radius !== null) {
                                if (check1 > 0 ) { } else { 
                                    
                                
                                    var point = new google.maps.LatLng(parseFloat(searched_center.lat()),parseFloat(searched_center.lng()));
                                    MYMAP.bounds.extend(point);

                                    var marker = new google.maps.Marker({
                                            position: point,
                                            map: MYMAP.map,
                                            animation: google.maps.Animation.BOUNCE
                                    });
                                    if (distance_type === "1") {
                                        var populationOptions = {
                                              strokeColor: '#FF0000',
                                              strokeOpacity: 0.25,
                                              strokeWeight: 2,
                                              fillColor: '#FF0000',
                                              fillOpacity: 0.15,
                                              map: MYMAP.map,
                                              center: point,
                                              radius: parseInt(radius / 0.000621371)
                                            };
                                    } else {
                                        var populationOptions = {
                                              strokeColor: '#FF0000',
                                              strokeOpacity: 0.25,
                                              strokeWeight: 2,
                                              fillColor: '#FF0000',
                                              fillOpacity: 0.15,
                                              map: MYMAP.map,
                                              center: point,
                                              radius: parseInt(radius / 0.001)
                                            };
                                    }
                                    // Add the circle for this city to the map.
                                    cityCircle = new google.maps.Circle(populationOptions);
                                    check1 = check1 + 1;
                                }
                                var R = 0;
                                if (distance_type === "1") {
                                    R = 3958.7558657440545; // Radius of earth in Miles 
                                } else {
                                    R = 6378.16; // Radius of earth in kilometers 
                                }
                                var dLat = toRad(searched_center.lat()-current_lat);
                                var dLon = toRad(searched_center.lng()-current_lng); 
                                var a = Math.sin(dLat/2) * Math.sin(dLat/2) + Math.cos(toRad(current_lat)) * Math.cos(toRad(searched_center.lat())) * Math.sin(dLon/2) * Math.sin(dLon/2); 
                                var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
                                var d = R * c;
                                //alert("distance: "+d);
                                if (d < radius) { show_marker_radius = true; } else { show_marker_radius = false; }
                            }



                            var point = new google.maps.LatLng(parseFloat(lat),parseFloat(lng));
                            MYMAP.bounds.extend(point);
                            if (show_marker_radius === true) {
                                if (wpmgza_anim === "1") {
                                var marker = new google.maps.Marker({
                                        position: point,
                                        map: MYMAP.map,
                                        animation: google.maps.Animation.BOUNCE
                                    });
                                }
                                else if (wpmgza_anim === "2") {
                                    var marker = new google.maps.Marker({
                                            position: point,
                                            map: MYMAP.map,
                                            animation: google.maps.Animation.DROP
                                    });
                                }
                                else {
                                    var marker = new google.maps.Marker({
                                            position: point,
                                            map: MYMAP.map
                                    });
                                }
                                var d_string = "";
                                if (radius !== null) {                                 
                                    if (distance_type === "1") {
                                        d_string = "<br />"+Math.round(d,2)+" miles away<br />"; 
                                    } else {
                                        d_string = "<br />"+Math.round(d,2)+" km away<br />"; 
                                    }
                                } else { d_string = ''; }
                                
                                
                                var html=''+wpmgza_address+''+d_string;
                                if (wpmgza_infoopen === "1") {
                                    infoWindow.setContent(html);
                                    infoWindow.open(MYMAP.map, marker);
                                }
                                                                google.maps.event.addListener(marker, 'click', function() {
                                    infoWindow.close();
                                    infoWindow.setContent(html);
                                    infoWindow.open(MYMAP.map, marker);

                                });
                                                            }
                        }
                    });

                });
            }
            function searchLocations(map_id) {
                var address = document.getElementById("addressInput").value;

                var geocoder = new google.maps.Geocoder();
                geocoder.geocode({address: address}, function(results, status) {
                  if (status === google.maps.GeocoderStatus.OK) {
                       searchLocationsNear(map_id,results[0].geometry.location);
                  } else {
                       alert(address + ' not found');
                  }
                });
              }

            function clearLocations() {
                infoWindow.close();
            }




            function searchLocationsNear(mapid,center_searched) {
                clearLocations();
                var distance_type = document.getElementById("wpgmza_distance_type").value;
                var radius = document.getElementById('radiusSelect').value;
                if (distance_type === "1") {
                    if (radius === "1") { zoomie = 14; }
                    else if (radius === "5") { zoomie = 12; }
                    else if (radius === "10") { zoomie = 11; }
                    else if (radius === "25") { zoomie = 9; }
                    else if (radius === "50") { zoomie = 8; }
                    else if (radius === "75") { zoomie = 8; }
                    else if (radius === "100") { zoomie = 7; }
                    else if (radius === "150") { zoomie = 7; }
                    else if (radius === "200") { zoomie = 6; }
                    else if (radius === "300") { zoomie = 6; }
                    else { zoomie = 14; }
                } else {
                    if (radius === "1") { zoomie = 14; }
                    else if (radius === "5") { zoomie = 12; }
                    else if (radius === "10") { zoomie = 11; }
                    else if (radius === "25") { zoomie = 10; }
                    else if (radius === "50") { zoomie = 9; }
                    else if (radius === "75") { zoomie = 9; }
                    else if (radius === "100") { zoomie = 8; }
                    else if (radius === "150") { zoomie = 8; }
                    else if (radius === "200") { zoomie = 7; }
                    else if (radius === "300") { zoomie = 7; }
                    else { zoomie = 14; }
                }
                MYMAP.init("#wpgmza_map", center_searched, zoomie, 3);
                MYMAP.placeMarkers('http://hostbengal.com/wp-content/uploads/wp-google-maps/1markers.xml?u='+UniqueCode,mapid,radius,center_searched,distance_type);
            }

            function toRad(Value) {
                /** Converts numeric degrees to radians */
                return Value * Math.PI / 180;
            }



        </script>
    			
			<script type="text/javascript">
				jQuery(document).ready(function($){
					var config = {
						method: 'stick',
						event: 'click',
						classWrapper: 'dc-contact-stick',
						classContent: 'dc-contact-content',
						width: 300,
						location: 'bottom',
						align: 'left',
						speedContent: 600,
						speedFloat: 1500,
						offsetLocation: 0,
						offsetAlign: 0,
						autoClose: true,
						tabText: 'Contact Us',
						idWrapper: 'dc-contact-2',
						animateError: true,
						loadOpen: false,
						ajaxSubmit: true						
					};
					if(!jQuery().dcSlickContact) {
						$.getScript("http://hostbengal.com/wp-content/plugins/slick-contact-forms/js/jquery.slick.contact.1.3.2.js", function(){
							jQuery('#dc_jqslickcontact_widget-2-item').dcSlickContact(config);
						}); 
					} else {
						jQuery('#dc_jqslickcontact_widget-2-item').dcSlickContact(config);
					}
				});
				
			</script>
		
			<script type='text/javascript' src='http://hostbengal.com/wp-content/themes/megahost/inc/theme-icon/js/icon-admin.js?ver=4.0.5'></script>
<script type='text/javascript' src='http://hostbengal.com/wp-includes/js/jquery/ui/jquery.ui.widget.min.js?ver=1.10.4'></script>
<script type='text/javascript' src='http://hostbengal.com/wp-includes/js/jquery/ui/jquery.ui.mouse.min.js?ver=1.10.4'></script>
<script type='text/javascript' src='http://hostbengal.com/wp-includes/js/jquery/ui/jquery.ui.slider.min.js?ver=1.10.4'></script>
<script type='text/javascript' src='http://hostbengal.com/wp-includes/js/jquery/ui/jquery.ui.button.min.js?ver=1.10.4'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var _wpcf7 = {"loaderUrl":"http:\/\/hostbengal.com\/wp-content\/plugins\/contact-form-7\/images\/ajax-loader.gif","sending":"Sending ...","cached":"1"};
/* ]]> */
</script>
<script type='text/javascript' src='http://hostbengal.com/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=3.8.1'></script>
<script type='text/javascript' src='http://hostbengal.com/wp-content/themes/megahost/js/nav/tinynav.js?ver=4.0.5'></script>
<script type='text/javascript' src='http://hostbengal.com/wp-includes/js/hoverIntent.min.js?ver=r7'></script>
<script type='text/javascript' src='http://hostbengal.com/wp-content/themes/megahost/js/nav/superfish.js?ver=4.0.5'></script>
<script type='text/javascript' src='http://hostbengal.com/wp-content/themes/megahost/js/nav/jquery.sticky.js?ver=4.0.5'></script>
<script type='text/javascript' src='http://hostbengal.com/wp-content/themes/megahost/js/carousel/owl.carousel.js?ver=4.0.5'></script>
<script type='text/javascript' src='http://hostbengal.com/wp-content/themes/megahost/js/fancybox/jquery.fancybox.js?ver=4.0.5'></script>
<script type='text/javascript' src='http://hostbengal.com/wp-content/themes/megahost/js/totop/jquery.ui.totop.js?ver=4.0.5'></script>
<script type='text/javascript' src='http://hostbengal.com/wp-content/themes/megahost/js/bootstrap/bootstrap.js?ver=4.0.5'></script>
<script type='text/javascript' src='http://hostbengal.com/wp-content/themes/megahost/js/main.js?ver=4.0.5'></script>

    </div>
    <!-- End layout-->

	</body>
</html>