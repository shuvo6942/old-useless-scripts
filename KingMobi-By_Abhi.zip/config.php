<?php

/* 
 SCRIPT Made BY Songs71.IN owner
 webSITE - WWW.Songs71.IN
 Powered By - AbhiaN
 FB- http://fb.me/AbhianOfficial
 Tw- Twitter.com/Abhix3  
*/

$url = "http://Songs71.in";
$site = "Songs71.IN";
$home = "Songs71.IN";
/* MP3 Tag Settings */
$albumart = "album_art.jpg";
$mp3_album = "Songs71.IN";
$mp3_artist = "Songs71.IN";
$mp3_composer = "Songs71.IN";
$mp3_copyright = "Songs71.IN";
$mp3_comment = "Various Songs Available On Songs71.IN";
$mp3_genre = "Songs71.IN";
$mp3_year = "2016";
$mp3_original_artist = "Songs71.IN";
$mp3_encoded_by = "Songs71.IN";
?>