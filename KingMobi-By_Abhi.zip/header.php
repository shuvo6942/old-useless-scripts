<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="title" content="Songs71.IN :: Free Mobile Downloads Portal" />
<meta name="robots" content="index, follow" />
<meta name="language" content="en" />
<title>Songs71.IN :: Free Mobile Downloads Portal</title>
<meta name="description" content="Songs71.IN is a full free mobile downloads site"/>
<meta name="GOOGLEBOT" content="INDEX, FOLLOW"/>
<meta name="Audience" content="All">
<link rel="shortcut icon" href="/images/favicon.ico" /><link href="/css/riyabd.css" type="text/css" rel="stylesheet"/>
</head><body>
<div class="logo"><a href="/"><img alt="Songs71" src="/images/logo.png" width="300" height="55" "/></a></div>