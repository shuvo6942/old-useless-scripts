<?php
/* 
 SCRIPT Made BY Songs71.IN owner
 webSITE - WWW.Songs71.IN
 Powered By - AbhiaN
 FB- http://fb.me/AbhianOfficial
 Tw- Twitter.com/Abhix3  
*/



eval(base64_decode("ZXJyb3JfcmVwb3J0aW5nKDApOwppbmNsdWRlICdjb25maWcucGhwJzsKJHM9JF9HRVRbJ3Nob3cn
XTsKJGxpbms9J2h0dHA6Ly9raW5nbW9iaS5pbi8nLiRzOwokZmlsZSA9IGZpbGVfZ2V0X2NvbnRl
bnRzKCcnLiRsaW5rLicnKTsKaW5jbHVkZSAnc29uZ3M3MS5waHAnOwppbmNsdWRlICdoZWFkZXIu
cGhwJzsKZWNobyAkZmlsZTs="));
/* Email: abhianayon@yahoo.com */
/* Script Made By Abhi */
?>
