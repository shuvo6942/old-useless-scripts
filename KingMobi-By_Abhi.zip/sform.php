<div class= "search" ><form method= "get"
action= "search.php" ><input type= "text"
name="find" id= "find" value= "" size="15"
placeholder="Find What? Songs71.IN ?" /><input type= "submit"
name="commit" value= "Search" /></form></div>