<?php
/* 
 SCRIPT Made BY Songs71.IN owner
 webSITE - WWW.Songs71.IN
 Powered By - AbhiaN
 FB- http://fb.me/AbhianOfficial
 Tw- Twitter.com/Abhix3  
*/


eval(base64_decode(aW5jbHVkZSAnY29uZmlnLnBocCc7CmluY2x1ZGUgJ2hlYWRlci5waHAnOwokZmlsZSA9IGZpbGVf
Z2V0X2NvbnRlbnRzKCdodHRwOi8va2luZ21vYmkuaW4vZmlsZXMvc2VhcmNoLz8nLiRfU0VSVkVS
WydRVUVSWV9TVFJJTkcnXS4nJyk7CmluY2x1ZGUgJ3NvbmdzNzEucGhwJzsKZWNobyAkZmlsZTs="));
/* Email: abhianayon@yahoo.com */
/* Script Made By Abhi */
?>

