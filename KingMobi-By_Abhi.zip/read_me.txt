/* 
 SCRIPT Made BY Songs71.In Owner
  D- 07/06/2016
   Web- www.songs71.in
    Admin- AbhiaN
     FB- http://fb.me/AbhiaNOfficial
      */

Installation :
1.Just unzip all files in your server.

Edit :
config.php
header.php

 if u face any problem then Contact me On Fb @ http://facebook.com/AbhianOfficial
