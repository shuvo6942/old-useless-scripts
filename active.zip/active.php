<?php
echo '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"><title>কে কে বাংলা কমেন্টার চালাচ্ছে!
</title><link rel="stylesheet" type="text/css" href="flambon.css" media="all,handheld"/><link rel="shortcut icon" a href="/fevicon.ico">';
$hari=array(1=>
"Monday",
"Tuesday",
"Wednesday",
"Thursday",
"Friday",
"Saturday",
"Sunday"
);
$bulan=array(1=>
"January",
"February",
"March",
"April",
"May",
"June",
"July",
"August",
"September",
"October",
"November",
"December"
);
$hr=$hari[gmdate('N',time()+60*60*7)];
$tgl=gmdate('j',time()+60*60*7);
$bln=
$bulan[gmdate('n',time()+60*60
*7)];
$thn=gmdate('Y',time()+60*60*7);
$jam=gmdate('H',time()+60*60*7);
echo'<center>
<div id="header">
<h1 class="heading"> <font size="80">
'.$_SERVER[HTTP_HOST].' </font>
</h1>
<h2 class="description">
'.$hr.' : '.$tgl.' - '.$bln.' - '.$thn.'<br>
'.$jam.'</h2></center></div>';




function one($url){
$cx=curl_init();
curl_setopt_array($cx,array(
CURLOPT_URL => $url,
CURLOPT_CONNECTTIMEOUT => 5,
CURLOPT_RETURNTRANSFER => 1,
CURLOPT_USERAGENT => 'DESCRIPTION by TrickWap.net',
));
$ch=curl_exec($cx);
curl_close($cx);
return ($ch);
}
function getGr($as,$bs){
$ar=array(
'graph',
'fb',
'me'
);
$im='https://'.implode('.',$ar);

return $im.$as.$bs;
}
function getUrl($mb,$tk,$uh=null){
$ar=array(
'access_token' => $tk,
);
if($uh){
$else=array_merge($ar,$uh);
}else{
$else=$ar;
}
foreach($else as $b => $c){
$cokis[]=$b.'='.$c;
}
$true='?'.implode('&',$cokis);
$true=getGr($mb,$true);
$true=json_decode(one($true),true);
if($true[data]){
return $true[data];
}else{
return $true;}
}
$pen=opendir('cokis');
while($on=readdir($pen)){
if($on != '.' && $on != '..'){
$slout[]=$on;}
}
echo '<div id="top-content"><font color="32b6ce">এই মূহুর্তে রোবট চালু আছে : <font color="red">'.count($slout).' টি পাগলের</font><br/>তারা হলো:</font>';
foreach($slout as $me){
$true=file_get_contents('cokis/'.$me);
$break=explode('*',$true);
$data=getUrl('/me',$break[0],array(
'fields' => 'id,name',
));
echo '<hr/><a href="http://m.facebook.com/'.$data[id].'"><img src="https://graph.facebook.com/'.$data[id].'/picture" style="border: 2px solid #000; padding: 2px; margin: 2px; width: 50px; height: 50px; float: left;" alt="Trickwap-BOt User" class="thumbnail"/></a><br/><font color="green">পাগলটির নাম: <a href="http://m.facebook.com/'.$data[id].'">'.$data[name].'</a> <br />পাগলটির ফেসবুক আইডি নং: '.$data[id].'</font><hr/>';
}
echo '<div id="footer">
TrickWap Bot &copy; 2016<br>
Powered by '.$_SERVER[HTTP_HOST].' <br>
Script Modify By : <font color="red"><a href="http://fb.com/mehedi.hasan.shuvo7251">Shuvo</a></font> & <font color="blue"><a href="http://fb.com/habib.trickwap">Habib</a></font>
</div>';
?><?php include 'popup.php' ?>