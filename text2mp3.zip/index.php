<?php

                               /*=====================================================*\

                                                    * Text to Mp3
                                           * Downloaded Frm : www.wapscripts.info
                                          * Free Wapscripts,Cheap Translated Script
                                      * Live Support- (c)Powered by www.wapscripts.info

                              \*======================================================*/
echo "<head><title>Text To Mp3 - www.wapscripts.info</title></head><link rel='stylesheet' href='wapscripts.info.css'/></head>
<div class='logo'><img src='logo.gif' alt='Wapscripts.Info'/></div><div class='header'>TEXT TO MP3</div><div class='shout'>";
echo "<form action=\"mp3.php\" method=\"GET\">
Teks: <br>
<textarea rows=\"3\" cols=\"20\" name=\"teks\"></textarea> <br>
<input type=\"submit\" value=\"Make MP3\">
</form></div><div class='footer'>WAPMASTER:<br/><a href='http://www.wapscripts.info'>TEXT 2 MP3 For Your Site</a></div><div class='shout'><a href='/index.php'>Wapscripts.info</a></div><div class='shout'>Powered by &#169;Wapscripts.info</div>";

?>