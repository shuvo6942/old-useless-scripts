<?php

                               /*=====================================================*\

                                                    * Text to Mp3
                                           * Downloaded Frm : www.wapscripts.info
                                          * Free Wapscripts,Cheap Translated Script
                                      * Live Support- (c)Powered by www.wapscripts.info

                              \*======================================================*/

header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');
header('Last-Modified: ' . date('r'));
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Cache-Control: post-check=0, pre-check=0', FALSE);
header('Pragma: no-cache');

header("Content-type: audio/mpeg");
header("Content-Disposition: attachment; filename=\"new.mp3\"");

include('sts.class.php');

$teks = $_GET[teks];

$s_ts = &new s_TS($teks, 'eng');
echo $s_ts->print_bufor();

?>