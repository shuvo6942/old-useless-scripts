<?php
include '../header.php';
?>
<div class="menu">
<h3>Group Poster</h3>
<li><a href="/accesstoken.php"> Get Access Token </a></li>
<li><form method="GET" action="/fbtools/multy_groups.php">Access Token<br><input name="token"></li>
<li><center><input id="hidden" name="id" value="<?php echo $user-id;?>"><br><input value="Log In" type="submit"></form></li>
</div>
<?php
include '../footer.php';
?>
