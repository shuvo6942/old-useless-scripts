<?php
include 'header.php';
?>
<div class="menu">
	<h3>Follow These All Steps To Get Your Access Token .</h3>
    <li>
    Your Access Token Is Used Like Others Posts !
    </li>
</div>
<div class="menu">
    <h3>Step 1</h3>
    <li>
    <a href="/token.php" target="_blank">=> CLICK HERE <=</a>
    </li>
</div>
<div class="menu">
    <h3>Step 2</h3>
    <li>
    <img src="http://oi57.tinypic.com/2dhtfk2.jpg" alt="" width="143" height="106">
    <br/>
    Click OK OK OK .
    </li>
</div>
<div class="menu">
    <h3>Step 3 ( for UC browser )</h3>
    <li>
    <a href="/tokenuc.php" target="_blank">=> CLICK HERE <=</a>
    </li>
</div>
<div class="menu">
    <h3>Step 4</h3>
    <li>
    <img src="http://oi62.tinypic.com/16ab0ix.jpg" width="181" height="242">
    <br/>
    Copy The URL Of Error Page .<br/>
    The URL Is Your Access Token .
    </li>
</div>
<div id="top-content">
</div>
<br/>
<?php
include 'footer.php';
?>