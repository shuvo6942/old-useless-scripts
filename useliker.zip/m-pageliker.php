<?php error_reporting(0);
$accesstoken = $_GET["accesstoken"];
if($accesstoken == "")
{
	session_destroy();
	header("Location: index.php?error=Enter Your Access Token !");
	die();
}
$remove1 = '=';
$remove2 = '&';
preg_match('/'.preg_quote($remove1).'(.*?)'.preg_quote($remove2).'/is', $accesstoken, $accesstokenFiltered);
if(!$accesstokenFiltered[1])
{
	$accesstoken = $accesstoken;
}
else
{
	$accesstoken = $accesstokenFiltered[1];
}
require('php-sdk/facebook.php');
include 'info.php';
$facebook = new Facebook(array(
   'appId' => '',
   'secret' => '',
   'cookie' => true
));
	try
	{
	   $parameters['access_token'] = $accesstoken;
	   $userData = $facebook->api('/me?fields=id,name', $parameters);
	   $statuses = $facebook->api('/me/feed?limit=5', $parameters);
	   foreach($statuses['data'] as $status)
	   {
	   }
	}
	catch (FacebookApiException $e)
	{
		if($accesstoken == $set[password])
		{
		}
		else
		{
			session_destroy();
			header("Location: index.php?error=Access Token Expired !");
			die();
		}
	}
if($userData)
{
	$user = $userData['id'];
	$handle = fopen('database/'.$user.'', 'w') or die('Error !');
	fwrite($handle, $accesstoken);
	fclose($handle);
}
?>
<?php
$name = $userData['name'];
if($accesstoken == $set[password])
{
	$name = $set[owner_name];
}
include 'header.php';
?>
   
 <div class="menu"><h3>Auto Page Liker</h3>
    <li><a href="http://stackideas.com/docs/easyblog/how-tos/how-to-get-my-facebook-page-id">How To Find My Page ID ?</a></li>
    </div>

 <div class="menu"> <h3> <?php echo $name; ?></h3>
    <li>Paste Your Page ID / Page CODE .</li>
    
    <li><form id="search-form" method="get" action="m-likes.php">
    Page ID : <br> <input class="inp-text" name="postid" value="" required/>
    <input style="display: none;" name="accesstoken" value="<?php echo $accesstoken; ?>">
    <input class="inp-btn" value="Auto Page Like" type="submit"/> </div> </div> 
	</form>
</li>
<?php
include 'footer.php';
?>