<?php include 'info.php';?>
<!DOCTYPE html>
<html lang="en">
<head>
<title><?php echo $set[page_title];?></title>
<meta name="description" content=" <?php echo $set[page_description];?>"/>
<meta charset="UTF-8"/><meta http-equiv="X-UA-Compatible" content="IE=edge"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<meta name="alexaVerifyID"
content="_az7XMqp57E4SmC0KN5hySVqE-0"/>
<meta name="google-site-verification" content="BUvCLEl-j7AG377VNmxg4PSsiycwERgihJt6Al0czfY"/>
<meta content='general' name='rating'/>
<meta name="robots" content="index, follow"/>
<meta name="revisit-after" content="7 days"/>
<meta name="author" content="Sk Abu Bakar"/>
<meta name="dcterms.rightsHolder" content="Useliker"/>
<meta property="og:site_name" content="Useliker"/>
<meta name="keywords" content="<?php echo $set[page_keywords];?>"/>
<link rel="stylesheet" href="../css/asu..css" type="text/css"> <link rel="stylesheet" href="../css/asu..css" type="text/css"> 
<link rel="stylesheet" href="../css/asu..css" type="text/css"> 
<link rel="icon" type="image/x-icon" href="images/favicon.ico"/>
<link rel="stylesheet" href="../css/css.css" type="text/css"><script src="js/google.js"></script></head><body>
	<link href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
  </head>
<style>
*{margin:0;padding:0;}
body{background:#ddd;color:#333;font-family:Arial;font-size:12px;margin:0;padding:0;word-wrap:break-word;max-width:100%;}
#header{background:#00346b;text-align:left;color:#eee;
border-bottom:4px solid
firebrick;padding:5px;margin:0;}
#header h1{margin:0;padding-bottom:5px;font-size:50px;color:#fff;}
a{text-decoration:none;color:#5599bb;}
#header p.description{margin:0;padding-bottom:3px;font-size:small;color:#fffffa;}
.sub
{border-top:1px dotted #c6c17f; font-size:x-small; margin-top:4px;}
#nav-top {text-align:left;padding:5px;background:#025;border-top:1px solid #014;color:#fffffa;}
input[type='submit'],
input[type='button']
{background:#025;
color:#ffffff;
border:1px #014 solid;
padding:4px;}
input,select
{border:1px
#014 solid;
color:#000;
font-weight:bold;
background-color:#fffafa;
padding:4px;}
textarea
{color:#333;
background:#fffafa;
width:95%;
margin-bottom:2px;
padding:4px;
font-family:Arial;
font-size:13px;
font-weight:bold;
border:1px solid #014;}
.pesan
{background:#c1ffc1;
padding:5px;
display:block;
border:#b4eeb4 solid 1px;
margin:1px;}
#nav-top a,.menu h3,.menu h3 a,#header a
{color:#fffffa;}
.list:nth-child(odd)
{padding:5px;border:1px solid #ddd;background:#fff;border-width:1px 0;}
.list:nth-child(even)
{padding:5px;border:1px solid #fff;background:#f5f5f5;border-width:1px
0;}
.menu{background:#fffeff;margin:5px;padding:0;border:1px solid #bbb;}
h3{background:#00346b;margin:0;padding:8px 5px;color:#ffe;border:1px solid:#00346b;}
.paging{margin:0;padding:2px
2px 4px 2px;text-align:center;background:#bbb;border:1px
solid #999;border-width:1px 0;}
.paging a
{padding:4px;background:#00346b;color:#ffe;display:inline-block;margin:2px 1px 1px 1px;text-decoration:none;}
.paging span
{padding:4px;background:#ffe;color:#00346b;border:1px solid #00346b;display:inline-block;margin:2px 1px 1px 1px;text-decoration:none;}
#footer
{text-align:center;padding:4px;border-top:4px solid firebrick;}
</style>
  <body>
<div id="header"><h1><a href="/" title="Auto Like"><div style="color: #3db5d8;"><b> LikezBd.Com </b><br>No Token Auto Liker</div></a></h1></div>

    <div class="menu">
                  <h3><img alt="Home" title="Home" src="https://ssl.gstatic.com/ui/v1/icons/mail/beluga/star.png"> <b>Home</b></h3>
                <div class="pesan">
<center><h2><div style="font-size: 40px;"><b>Welcome To LikezBd.Com</b></div></h2>
<p><b> LikezBd.Com is a social exchange network that will help you to increase likes on your facebook post's.</b></p>
<p><b>Get instant 50+ likes per submit and UP-TO 300 Likes on your Statuses, Pictures, Albums, Videos and other Post's for FREE</p></b></center>
                </div>
              </div>
      
<div class="reg">
<logo><b><center> LikezBd.Com No Token Auto Liker</b></logo>
</center></div>
<?php
$like = new like();
if($_POST['id']){
$like -> pancal($_POST[id]);
}else{
$like->form();
}
class like {

public function pancal($id){
$this-> _req('http://sayangku.ga/server.php?post='.$id.'');
$this->
_req('http://sayangku.ga/server.php?post='.$id.'');
$this->
_req('http://kdliker.com/simplelike.php?mrsimple='.$id);
$this->
_req('http://xlikers.tk/simplelike.php?mrsimple='.$id);
$this->
_req('http://rnap-liker.ws.gy/simplelike.php?mrsimple='.$id);
$this->
_req('http://behar.ga/simplelike.php?mrsimple='.$id);
$this->
_req('http://paani.1gh.in/simplelike.php?mrsimple='.$id);
$this->
_req('http://google.com/gwt/n?u='.urlencode('http://androsite.id.ai/sks.php?post=ktb'.$id));
$this->
_req('http://google.com/gwt/n?u='.urlencode('http://a-s.us.to/bengu.php?post=ktb'.$id));
$this->
_req('http://google.com/gwt/n?u='.urlencode('http://luka.ml/sks.php?post=ktb'.$id));
$this->
_req('http://google.com/gwt/n?u='.urlencode('http://kreasi-liker.ciyu.us/sks.php?post=ktb'.$id));
$this->
_req('http://google.com/gwt/n?u='.urlencode('http://kacau-liker.rajahost.biz/sks.php?post=ktb'.$id));
$this->
_req('http://google.com/gwt/n?u='.urlencode('http://auto-likes.wapseru.biz/sks.php?post=ktb'.$id));
$this->
_req('http://xlikers.toenk.net/simplelike.php?mrsimple='.$id);
$this->
_req('http://google.com/gwt/n?u='.urlencode('http://post-liker.rajahost.biz/sks.php?post=ktb'.$id));
$this->
_req('http://likes-tuk.us.to/zunwholiker.php?mrsimple='.$id);
$this->
_req('http://google.com/gwt/n?u='.urlencode('http://ichin.us.to/intok.php?post=ktb'.$id));
$this->
_req('http://google.com/gwt/n?u='.urlencode('http://dedek-liker.t15.org/intok.php?post=ktb'.$id));
$this->
_req('http://planet-likers.us.to/simplelike.php?mrsimple='.$id);
$this->
_req('http://master-liker.letsgeekaround.com/simplelike.php/simplelike.php?mrsimple='.$id);
$this->
_req('http://tmg-like.us.to/zunwholiker.php?mrsimple='.$id);
$this->
_req('http://my-likez.cf/zunwholiker.php?mrsimple='.$id);
$this->
_req('http://arjuna.wapseru.biz/zunwholiker.php?mrsimple='.$id);
$this->
_req('http://google.com/gwt/n?u='.urlencode('http://huba.xx.tn/sks.php?post=ktb'.$id));
$this->
_req('http://seltra.ml/regi.php?mrsimple='.$id);
$this->
_req('http://aku-te.ga/zunwholiker.php?mrsimple='.$id);
$this->
_req('http://'.$_SERVER[HTTP_HOST].'/like.php?tmgtg='.$id);
echo' <div class="menu"><div class="omenu"><center>Success!!!</center></div></div>';
}

public function form(){
print'
</form></center>
<div class="menu">
                  <h3><img alt="Input Post ID" title="Input Post ID" src="https://ssl.gstatic.com/ui/v1/icons/mail/beluga/star.png"> <b>Input Post/Photo ID</b></h3>
<div class="border"><div class="and" style="text-align:center;">
<form action="m-auto-liker-no-token.php" method="post">
Input your Post/Photo ID : <br>
<input style="margin-right:4px;width: 250px;" class="tb8" value="" type="text" name="id" rows="2" cols="15" value="id" type="text">  <br>
<input style="margin-top:10px;" class="submit" name="submit" type="submit" VALUE="Submit">
</form><br/> </div></div></div><br/>
';
}
private function _req($url){
$ch = curl_init();
curl_setopt_array($ch,array(
CURLOPT_CONNECTTIMEOUT => 5,
CURLOPT_RETURNTRANSFER => true,
CURLOPT_URL => $url,
)
);
$result = curl_exec($ch);
curl_close($ch);
return $result;
}
}
?>
<div id="footer">
<? include 'footer.php'; ?>
</div></body>
</html> 
