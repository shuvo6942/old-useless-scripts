<?xml version="1.0" encoding="utf-8"?><!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru">
<head><title>Download</title>
<link rel="shortcut icon" href="/favicon.ico" />
<link rel="stylesheet" href="/style/themes/2015/style.css" type="text/css" />
<link rel="stylesheet" href="/style/themes/2015/fb.css" type="text/css" />
<meta name="description" content="Bangladesh no one community site. Milion of people here. you can enjoy chating and dating. Forum,group, send img, bulk sms , earning tips here." />
<meta name="keywords" content="Bangladesh no one community site. Milion of people here. you can enjoy chating and dating. Forum,group, send img, bulk sms , earning tips here." />
</head>
<body>
<div valign="center" class="logo"><table><tr><td><a href="/index.php"><img class="img" src="/style/themes/2015/i.png" id="facebook_logo" alt="I" title="forceimage" /></a></td><td><img class="img" src="/style/themes/2015/logo.png" id="facebook_logo" alt="ICTfair" title="forceimage" width="76" height="20" /></td></tr></table></div><title>ICTfair</title><style type="text/css">.bs{appearance:none;background:none;display:inline-block;font-size:12px;height:28px;line-height:28px;margin:0;color:#ffffff;overflow:visible;padding:0 9px;text-align:center;vertical-align:top;white-space:nowrap;} .bs{border-radius:2px;}.bx{background-color:#4e69a2;border:1px solid #385490;} background: #fff;
padding: 3px; border: solid
1px #ddd; }
.bu{background-color:#E42217;border:1px solid #E42217;} .buv{background-color:#FCDFFF;border:1px solid #FCDFFF;}.b z::after{content:"";display:inline-block;height:100%;vertical-align:middle;} .bz{height:26px;line-height:26px;}</style><div class='status'><b>OPPs Not found</b></div>
<div class='black' style='background: #404140; padding: 6px; color: white;'><br/><a href='feed/feedback.php'><b>Report Any Problem</b></div><noscript/></body></html>