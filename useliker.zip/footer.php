<div class="menu">
        <h3><?php echo $set[groups_heading];?></h3>
        <li>
        <a target="_top" href="http://<?php echo $set[partner_1_link];?>/"><?php echo $set[partner_1_name];?></a>
        </li>
        <li>
        <a target="_top" href="http://<?php echo $set[partner_2_link];?>/"><?php echo $set[partner_2_name];?></a>
        </li>
    </div>
    <div class="menu">
        <h3><?php echo $set[pages_heading];?></h3>
        <li>
        <a target="_top" href="https://m.facebook.com/<?php echo $set[page_1_id];?>"><?php echo $set[page_1_name];?></a>
        </li>
        <li>
        <a target="_top" href="https://m.facebook.com/<?php echo $set[page_2_id];?>"><?php echo $set[page_2_name];?></a>
        </li>
    </div>

<div class="menu"><h3><center>Follow Devoloper</center></h3></div>
<center>

<a href="http://m.facebook.com/sk.bakars" target="_top"><img src="https://graph.facebook.com/sk.bakars/picture?width=120&height=120" width="50" /></a>

&nbsp;&nbsp;&nbsp;&nbsp;

<br/>

<a href="http://m.facebook.com/sk.bakars" target="_top">Sk Abu Bakar</a></center>

<center>

<iframe src="//www.facebook.com/plugins/subscribe.php?href=https://www.facebook.com/sk.bakars&layout=button_count&amp;show_faces=false&colorscheme=light&font=lucida grande&amp;width=105&appId=281570931938574" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:110px; height:50px;" allowTransparency="true"></iframe>





</center>
    <div id="footer">
<div class="paging">
<?php
include 'count.php';
?> </div>
<script type='text/javascript' src='http://u-on.eu/js.php?u=77175'></script><noscript><a href='http://u-on.eu/in.php?u=77175'><img src='http://u-on.eu/c.php?u=77175' alt='U-ON'></a></noscript>
<a href='http://www.siteuptime.com/' onMouseOver='this.href="http://www.siteuptime.com/statistics.php?Id=13752&UserId=192390";'><img width=85 height=16 border=0 alt='website uptime' src="http://btn.siteuptime.com/genbutton.php?u=192390&m=13752&c=blue&p=total"></a><noscript><a href='http://www.siteuptime.com/'>website monitoring</a></noscript>
<div class="menu">
2014-15 WwW.LikezBd.Com <br> Powered By : <b>Sk Abu Bakar</b> <br/>
        [ Bangladeshi Developers ] <br> All Rights Reserved.      </div>
</body>
</html>