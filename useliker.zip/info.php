<?php
$set[password]="100000";
$set[site_status]="online";
$set[owner_name]="Sk Abu Bakar";
$set[owner_profile_id]="sk.bakars";
$set[page_title]="wWw.LikezBd.Com | Facebook Auto Liker,Auto Commenter,Follower,Friends Adder,Page Liker and get others facebook tools!";
$set[page_description]="LikezBd.Com - Increase Facebook Likes,Comments,Followers,Friends,Page Likes and get others facebook tools.The Best Facebook Auto Liker,Auto Commenter,Follower,Friends Adder,Page Liker Site In Bangladesh Created by Sk Abu Bakar !";
$set[page_keywords]="Auto Like Facebook, Auto Like Facebook Page, Auto Like Facebook 2015, Auto Like Facebook Photo App, Auto Like Facebook, Photo 1000 Likes, Auto Like Facebook Fan Page, Auto Like Facebook Software For Android, Auto Like Facebook Photo, Auto Like Facebook Script, Auto Like Facebook Page Free Download, Auto Comment Facebook, Auto Comment Facebook Script, Auto Comment Facebook 2015, Auto Comment Facebook Online, Auto Comment Facebook 2014 Free, Auto Comment Facebook App, Auto Comment Facebook Photo, Auto Comment Facebook Group, Auto Comment Facebook Free Online, Auto Comment Facebook Page, Auto Follower Facebook, Auto Follower Facebook 2015, Auto Follower Facebook Link, Auto Follower Facebook Free 2014, Auto Follower Facebook Bot, Auto Follower Facebook App, Auto Follower Facebook Access Token, Auto Follower Facebook Official, Auto Follower Facebook Apk, Auto Follower Facebook Free, Auto Friend Adder Facebook, Auto Friend Adder Facebook Free Online, Auto Friend Adder Facebook Free, Auto Friend Adder Facebook 2015, Auto Friend Adder Facebook Group Script, Auto Friend Adder Facebook 2014, Auto Friend Adder Facebook 2013, Auto Friend Adder Facebook 2012, Facebook Auto Friend Adder Pro V3.2, Facebook Auto Friend Adder Pro V3.1 Crack, Facebook Auto Page Liker, Facebook Useful Tools, Auto Like 2015, Auto Like 2015 No Spam, Auto Like 2015 Terbaru, Auto Like 2015 Maret, Auto Like 2015 Indonesia, Auto like 2015 Bangladesh, Bangladeshi Auto Like, LikezBd.Com";
$set[main_heading]="★ wWw.LikezBd.Com ★";
$set[sub_heading]="AutoLike ¤ AutoFollow ¤ MultiPost";
$set[icon_link]="http://facebook.com/favicon.ico";
$set[token_link]="http://berti.ga/token2.php";
$set[developer_heading]="Follow Developer";
$set[author]=$set[site_status];
$set[liker_status]="[ Active ]";
$set[commenter_status]="[ Active ]";
$set[groups_heading]="Site Partner";
$set[partner_1_link]="Tipsfire.com";
$set[partner_1_name]="wWw.TipsFire.Com";
$set[partner_2_link]="m.facebook.com/sk.bakars";
$set[partner_2_name]="For Ad";
$set[pages_heading]="Help & Others";
$set[page_1_id]="rihs.bd";
$set[page_1_name]="Join Official Page";
$set[page_2_id]="sk.bakars";
$set[page_2_name]="Contact Admin";
?>