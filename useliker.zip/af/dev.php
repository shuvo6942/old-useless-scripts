<?php
#-----------------------------------------------------#
jk
#-----------------------------------------------------#
?><?include 'x.php';?><head><title>Register to Developer for free | <? echo $set[alamat];?></title>
</head>

<link rel="stylesheet" type="text/css" href="http://pubiway.xtgem.com/pubiway.css" media="all,handheld"/><link rel="shortcut icon" href="http://facebook.com/favicon.ico">

<div class="judul2">Mau jadi dev gratis? Daftar saja disini</div>
<div class="birumuda">Keuntungan: <br>
- Langsung punya button follow sehingga kamu berkemungkinan difollow oleh orang lain.<br>
- Tidak perlu takut di kick jika tidak lagi memromosikan.<br>
- Background halaman dengan foto kamu<br>
- Copyright di bagian bawah oleh username kamu juga sehingga seolah-olah anda pemilik web tersebut</div> 


<div class="menu">
Username Facebook kamu:
<form
method="get" class="menu" action="resmi.php">
<input class="visitor" name="username" rows="2" cols="15" style="width: 70%;margin-left: 15%;"  type="text">
<input value="Proses" type="submit" class="hijau" />
</form>
</div> 

<div class="bawah"><center>copyright &copy <? echo $set[nama_admin];?><br><? echo $set[tahun];?></div>
