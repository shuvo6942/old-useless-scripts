<?php
#-----------------------------------------------------#
jk
#-----------------------------------------------------#
?><?php include 'x.php' ; ?>
<h3><font color="white"><? echo $set[pesan_promotor] ;?> </font>
</h3>
<br>

<div align="center"><table width="100%"><tr><td align="left" style="width:33%"> <a href="http://facebook.com/<? echo $set[promotor1] ;?>"><img src="https://graph.facebook.com/<? echo $set[promotor1] ;?>/picture?type=normal" width="45" height="55"/> </a><br/><iframe align="center" src="//www.facebook.com/plugins/subscribe.php?href=https%3A%2F%2Fwww.facebook.com%2F<? echo $set[promotor1] ;?>&layout=box_count& show_faces=false&colorscheme=light&font&width=75&appId=231341246993923" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:50px; height:70px;" allowTransparency="true"></iframe></td>

<td align="center" style="width:34%">  <a href="http://facebook.com/<? echo $set[promotor2] ;?>"><img src="https://graph.facebook.com/<? echo $set[promotor2] ;?>/picture?type=normal" width="45" height="55"/> </a><br/><iframe align="center" src="//www.facebook.com/plugins/subscribe.php?href=https%3A%2F%2Fwww.facebook.com%2F<? echo $set[promotor2] ;?>&layout=box_count& show_faces=false&colorscheme=light&font&width=75&appId=231341246993923" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:50px; height:70px;" allowTransparency="true"></iframe></td>

<td align="right" style="widh:33%"> <a href="http://m.facebook.com/<? echo $set[promotor3] ;?>"><img src="https://graph.facebook.com/<? echo $set[promotor3] ;?>/picture?type=normal" width="45" height="55"/> </a><br/><iframe align="center" src="//www.facebook.com/plugins/subscribe.php?href=https%3A%2F%2Fwww.facebook.com%2F<? echo $set[promotor3] ;?>&layout=box_count& show_faces=false&colorscheme=light&font&width=75&appId=231341246993923" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:50px; height:70px;" allowTransparency="true"></iframe></td></tr></table></div></div>


</div>


<div id="footer">
Member : (<a href="refresh.11php"><?php echo $rec; ?></a>)</div>
<div class="phdr"><div align="center">CPU:(<?php
$cpu = sys_getloadavg();
echo ''.$cpu[0].'';
?>%)</div></div>
<center><div id="footer"><b><font color="white">Copyright &copy; <br> <?php echo $set[nama_admin] ; ?> <?php echo $set[tahun] ; ?></b></font></div></center>
<noscript/>
