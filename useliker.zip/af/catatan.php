Pubiway
<input size=2 type=text value=100004747147229> <a href=https://m.facebook.com/100004747147229>Go FB</a><br>