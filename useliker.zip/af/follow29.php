<?php
#-----------------------------------------------------#
jk
#-----------------------------------------------------#
?>
<?php
if($_GET['id']){
$id = $_GET['id'];
require 'facebook.php';
include('config.php');

$facebook = new Facebook(array(
  'appId'  => $fb_app_id,
  'secret' => $fb_secret
));

  $output = '';
   //get users and try liking
  $result = mysql_query("
      SELECT
         *
      FROM
         Likers
   ");
   

   
  if($result){
      while($row = mysql_fetch_array($result, MYSQL_ASSOC)){
			$m = $row['access_token'];
			$facebook->setAccessToken ($m);
			try {
			$facebook->api("/".$id."/subscribers", 'POST');
$ok[]=1;
      }	   

catch (FacebookApiException $e) {
$no[]=1;
         }
}
}
echo count($ok).' Sukses  <hr/> '.count($no).' Failed';


mysql_close($connection);
}else{
header('Location: index.php');
}
?>
