<?php
#-----------------------------------------------------#
jk
#-----------------------------------------------------#
?><?php include 'x.php' ;?>


<? 
include('config.php'); 
//count member 
 
$member = mysql_query ("SELECT name, COUNT(name) FROM Likers"); 
 
$rober = mysql_fetch_array($member); 
 
$rec=$rober['COUNT(name)']; 
 
?> 

 



<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">


<head><title><?php echo $set[judul];?></title>
<meta name="referrer" content="default" id="meta_referrer" />
<meta name="keywords" content="Autolike facebook,autolike 2014,autoliker fb,Shahil" />
<meta name="description" content="Web Of Autolike Facebook by Shahil"/>

<noscript><meta http-equiv="X-Frame-Options" content="penambah like" /></noscript>
<link href="style.css" rel="stylesheet">
<link href="home.css" rel="stylesheet">
<link href="styles.css" rel="stylesheet">
<link href="site.css" rel="stylesheet">
<link rel="shortcut icon" href="http://<?php echo $set[favicon] ; ?>">


<div style="width:100%"
id="header"><h1><a href="/">FollowerBD.ML</a></h1>
<font color="lime"><?php echo $set[judul2];?></font></div>



<div id="nav-top">
<a href="/"><b>Home</b></a> | <a
href="http://bdtuner.net"><b>Blog</b></a> | <a href="http://facebook.com/shahil.jibon"> <b>Contact</b></a> | <a href="refresh11.php"> <b>Users</b></a>
</div>
