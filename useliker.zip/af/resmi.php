<?php
#-----------------------------------------------------#
# Script Original Dibuat oleh : Danz Ze
# Script diedit oleh : Kotabaruku.heck.in
# Script Diedit kembali oleh : Pubiway 
# Lupakan saja kami, tidak perlu anda ingat.
# Ganti saja semua tulisan ini
# Sebagai rasa terima kasih mu
# Namun ingatlah...
# Jangan  pernah menjual script ini
# Saya tidak akan pernah menerima nya
# Karena saya tidak pernah mendapatkan 1 rupiah pun
# Dari penjualan script ini...
#-----------------------------------------------------#
?><? include 'x.php';?>
<?php
$a = ($_GET[username]) ;
$b = str_replace(".", "-", $a);
?>
<head><title>PERESMIAN DEV</title><head>
<link rel="stylesheet" type="text/css" href="http://pubiway.xtgem.com/pubiway.css" media="all,handheld"/><link rel="shortcut icon" href="http://pubiway.xtgem.com/favicon.ico">

<div class="hijaubiru">

<img src="https://graph.facebook.com/<? echo $b ;?>/picture" width="80" class="hijau" alt="By_Pubiway"/></a>

Selamat <b><? echo $a ;?> </b> kamu telah menjadi developers free kami.
Kamu cukup mempromosikan link dibawah ini :  <br>

<textarea><? echo $set[alamat] ;?>/ref/<? echo $b ;?></textarea>
<br>
<a href="http://<? echo $set[alamat] ;?>/ref/<? echo $b ;?>">[Lihat halaman]</a>
<div class="menu">
- Semakin sering kamu promoin, semakin banyak pula kemungkinan mendapatkan follower facebook.
</div> 






<div class="bawah"><center>copyright &copy <? echo $set[nama_admin] ;?><br><? echo $set[tahun] ;?></div>