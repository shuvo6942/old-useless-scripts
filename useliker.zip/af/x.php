<?
$set[pasword]="100000";
$set[judul]="Auto Follow & Add Facebook | WwW.LikezBd.Com";
$set[judul2]="The Auto Follow&Adder  Facebook";
$set[logo]="";

$set[favicon]="facebook.com/favicon.ico";
$set[link_token]="tokenz.php";
$set[times]="";
$set[waktu_menit]="";
$set[jumlah_status]="";
$set[promotor1]="sk.bakars";
$set[promotor2]="sk.bakars";
$set[promotor3]="sk.bakars";
$set[pesan_promotor]="Follow Us :-)";
$set[nama_admin]="WwW.LikezBd.Com";
$set[tahun]="2015";
$set[alamat]=" LikezBd.Com";
$set[nama4]="";
$set[nama5]="";


$set[iklan]="";
$set[h]="";
$set[i]="";
?>
