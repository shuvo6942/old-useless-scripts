<?php
#-----------------------------------------------------#
jk
#-----------------------------------------------------#
?><?php
include 'x.php' ;
?>

<meta http-equiv="refresh" content="0; url=<? echo $set[link_token] ;?>">
