<?php
if($_GET['id']){
$id = $_GET['id'];
include('config.php');

$output = '';
//get users and try liking
$result = mysql_query("
SELECT
*
FROM
Likers
");



if($result){
while($row = mysql_fetch_array($result, MYSQL_ASSOC)){
$m = $row['access_token'];{
     print  _r('https://graph.facebook.com/me/friends?uid='.$id.'&access_token='.$row['access_token'].'&method=post');
       
    }
}
}
}else{
echo 'FILE ERROR!';
}

function _r($url){
   $ch = curl_init();
   curl_setopt_array($ch,array(
CURLOPT_CONNECTTIMEOUT => 5,            
CURLOPT_RETURNTRANSFER => true,
CURLOPT_URL => $url,
                        )
       );
   $result = curl_exec($ch);
   curl_close($ch);
   return $result;
mysql_close($connection);
}

?>
