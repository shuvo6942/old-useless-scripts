<?php
#-----------------------------------------------------#
jk
#-----------------------------------------------------#
?><head>
<title>
Pubiway Admin Panel Site
</title>
<link rel="stylesheet" type="text/css" href="http://pubiway.xtgem.com/pubiway.css" media="all,handheld"/>
<link rel="shortcut icon" href="http://pubiway.xtgem.com/favicon.ico">
</head>
<?
require ('x.php');
$adminpass = $set[pasword];
if (isset($_GET['pass'])){
$pass = $_GET['pass'];
} else {
$pass = '';
}
$title="Admin panel";

$a = $_GET['a'];
switch($a){
case "login":
echo '<div class="menu">
<center>';
$m = $_GET['m'];
switch($m){
case "panel":
$auth = $_POST['auth'];
if (empty($auth)){
echo 'LO SIAPA!????<br/>
&raquo; <a href="admin.php">Kembali</a><br/>';
}
else if ($auth !== $adminpass){
echo 'Password salah !!<br/>
&raquo; <a href="admin.php?a=login">Kembali</a><br/>';
} else {
echo 'Login sukses !!<br/>
&raquo; <a href="admin.php?pass='.$adminpass.'">Ke depan</a><br/>';
}
break;
default:
echo '<form action="admin.php?a=login&amp;m=panel" method="post">
Masukkan Password :<br/>
<input type="password" name="auth" value=""><br/>
<input type="submit" value="Login">
</div></form>';
break;
}
echo '</center>
</div>';
break;
//Edit data
case "edit":
echo '<div class="error">';
if ($pass !== $adminpass){
echo 'Khusus admin';
} else {
$file = 'x.php';

$e = $_GET['e'];
switch($e){
case "simpan":
$buka = fopen($file, 'w');
$konten='<?
$set[pasword]='.'"'."$_REQUEST[satu]".'";
$set[judul]='.'"'."$_REQUEST[judul]".'";
$set[judul2]='.'"'."$_REQUEST[judul2]".'";
$set[logo]='.'"'."$_REQUEST[logo]".'";

$set[favicon]='.'"'."$_REQUEST[favicon]".'";
$set[link_token]='.'"'."$_REQUEST[link_token]".'";
$set[times]='.'"'."$_REQUEST[times]".'";
$set[waktu_menit]='.'"'."$_REQUEST[waktu_menit]".'";
$set[jumlah_status]='.'"'."$_REQUEST[jumlah_status]".'";
$set[promotor1]='.'"'."$_REQUEST[promotor1]".'";
$set[promotor2]='.'"'."$_REQUEST[promotor2]".'";
$set[promotor3]='.'"'."$_REQUEST[promotor3]".'";
$set[pesan_promotor]='.'"'."$_REQUEST[pesan_promotor]".'";
$set[nama_admin]='.'"'."$_REQUEST[nama_admin]".'";
$set[tahun]='.'"'."$_REQUEST[tahun]".'";
$set[alamat]='.'"'."$_REQUEST[alamat]".'";
$set[nama4]='.'"'."$_REQUEST[nama4]".'";
$set[nama5]='.'"'."$_REQUEST[nama5]".'";


$set[iklan]='.'"'."$_REQUEST[iklan]".'";
$set[h]='.'"'."$_REQUEST[sembilan]".'";
$set[i]='.'"'."$_REQUEST[sepuluh]".'";
?>';
fwrite($buka, $konten);
fclose($buka);
echo '<div class="menu">Data situs telah berhasil di update</div>
<br/>
&raquo; <a href="admin.php?pass='.$set[pasword].'">Kembali</a><br/>';
break;
default:
echo '<form action="admin.php?a=edit&amp;e=simpan&amp;pass='.$pass.'" method="post"><div class="menu"> 

<span class="judul2">Panel Situs</span><br>

1). Admin pasword :<br/>
<input type="text" name="satu" size="12" value="'.$set[pasword].'"><br/>

2). Judul Situs (di title):<br/>
<input type="text" name="judul" size="12" value="'.$set[judul].'"><br/>

3). Judul(dalam div):<br/>
<input type="text" name="judul2" size="12" value="'.$set[judul2].'"><br/>

4). Favicon Situs :<br/>
<input type="text" name="favicon" size="12" value="'.$set[favicon].'"><br/>

5). Nama Admin:<br>
<input type="text" name="nama_admin" size="12" value="'.$set[nama_admin].'"><br>

6). Tahun :<br>
<input type="text" name="tahun" size="12" value="'.$set[tahun].'"><br>

7). Link Access Token(pakai http://) :<br>
<input type="text" name="link_token" size="12" value="'.$set[link_token].'"><br>

8). Alamat web(tanpa http:// tapi pakai www):<br/>
<input type="text" name="alamat" size="12" value="'.$set[alamat].'"><br/>




 
</div>

<div class="hijaubiru">
<span class="judul2">Promotor Panel</span><br>
1). Promotor 1 :<br/>
<input type="text" name="promotor1" size="12" value="'.$set[promotor1].'"><br/>
 
2). Promotor2 :<br/>
<input type="text" name="promotor2" size="12" value="'.$set[promotor2].'"><br/>


3). Promotor 3 :<br/>
<input type="text" name="promotor3" size="12" value="'.$set[promotor3].'"><br/><hr>


4). Pesan Promotor:<br>
<input type="text" name="pesan_promotor" size="12" value="'.$set[pesan_promotor].'"><br>


</div>






<input type="hidden" name="sepuluh" size="12" value="'.$set[i].'"><br/>
<input type="submit" class="judul3" value="SIMPAN"><br/>
</form>';




break;
} }
echo '</div>';
break;
default:
echo '<div class="main">';
if ($pass == $adminpass) {
echo '
<div class="menu"><div class="judul2">Admin Panel PubiwayZone Site</div>
[+]	<a href="admin.php?a=edit&amp;pass='.$pass.'">Edit data situs</a><br>
[+]	<a href="refresh.php">Refresh Token</a><br>
[-]	<a href="admin.php?">Keluar</a></div>';
} else {
echo '<div class="menu"><a href="admin.php?a=login">[LOGIN]</a> untuk masuk admin panel';
}
echo '</div>';
break;
//Penutup
}
include "footer2.php";
?>
