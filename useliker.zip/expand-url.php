<?php
include 'header.php';
?>
<div class="menu">
<h3>Find Source of Short URL</h3>
<li>Shortened URL</li>
<li><input name="url" value="Type Your Short Url"></li>
<input type="submit" value="Expand URL" onclick="OnSubmitPluginInput(this,'http://www.webtoolhub.com/plugins/wt561411-url-expander.aspx');">
</form>
  <tr>
    <td>
      <iframe name="pluginframe561411" frameborder="0" style="width: 100%; height: 100px"></iframe>
    </td>
  </tr>
  <tr>
    <td style="font-size: 9pt; font-family: Verdana, Arial;">
      Powered by: <a href="http://facebook.com/jkshahil" title="Free Webmaster Tools">Shahil Ahmed Jibon</a>
    </td>
  </tr>
<script type="text/javascript" src="https://secure.webtoolhub.com/plugin.axd"></script></div>
<?php
include 'footer.php';
?>