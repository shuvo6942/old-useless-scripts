<?php
header('Content-Type: text/html; charset=UTF-8');
session_start();
date_default_timezone_set('Asia/Jakarta');

$host = "mysql.0hosting.org";
$username = "u642014720_jk";
$password = "100000";	
$dbname = "u642014720_jk";



$ip = getenv("REMOTE_ADDR") ;
$time = time();
$waktu = date("G:i:s",time());
//database connect
mysql_connect($host,$username,$password) or die(mysql_error());
mysql_select_db($dbname) or die(mysql_error());
mysql_query("SET NAMES utf8");

function get_html($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($ch, CURLOPT_FAILONERROR, 0);
    $data = curl_exec($ch);
    curl_close($ch);
	return $data;
    }
$token = $_SESSION['token'];
if($token){
	$graph_url ="https://graph.facebook.com/me?fields=id,name&access_token=" . $token;
	$user = json_decode(get_html($graph_url));
$uid = $user->id;
	if ($user->error) {
		if ($user->error->type== "OAuthException") {
			session_destroy();
			header('Location: index.php?i=Token Expired, Please Re-Generate new Token..! !');
			}
		}
	}
	else{
	header('Location: /index.php');
	}
$result = mysql_query("
   SELECT * FROM cookies WHERE ip = '$ip' or id = '$uid'");
	if($result){
     while($row = mysql_fetch_array($result, MYSQL_ASSOC)){
			$times = $row;
			}
	$timer = time()- $times['time'];
	$countdown = 0 - $timer;
	};	
if(isset($_POST['submit'])) {
  $count = $_POST['count'];

if ($count > 210) {
 echo "<script language=javascript> alert(\"  Maximum 210 Likes - Go Back And Try Again With Less Value\");</script>"; 
		exit;
		}

        $token = $_SESSION['token'];
           if(!isset($token)){exit;}
	$postid = $_POST['id'];
	if(isset($postid)){
	if (time()- $times['time'] < 0){
 echo '<script type="text/javascript">alert("INFO: You can only submit one post per 15 minutes time .. try again in '.$countdown.' seconds  or use our 2nd serve for more likes.");</script>';
	}
	else{
	

	mysql_query("REPLACE INTO cookies (ip,time,waktu,id) VALUES ( '$ip','$time','$waktu','$uid')");
	$data = array('postid' =>$postid, 'count' =>$count);
	$ch = curl_init('http://beremp.at/firm_cok.php'); 
	curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt ($ch, CURLOPT_POST, 1);
	curl_setopt ($ch, CURLOPT_POSTFIELDS,$data); 
	
	$hasil = curl_exec ($ch);
	curl_close ($ch);
	curl_close ($ch);
    if (strpos($hasil,'time') !== false) {
		echo '<script type="text/javascript">alert("INFO: Something Went Wrong - \n Either you tryed to bypass the liker timer or some problem with me . \n further hacking activity will lead to ban");</script>';
			}
 if (strpos($hasil,'blocked') !== false) {
		echo '<script type="text/javascript">alert("INFO: Something Went Wrong - \n your liking permission is blocked \n try again from a new id to get likes");</script>';
			}
else{
        header("Location: http://linkshrink.net/7YJzQy");
session_destroy();
	}
	}
	}else{
	header("Location: index.php?ALERT=Post ID is Empty");
	};
}
	
else{







if(isset($_GET['type'])){
if($_GET['type'] == "status"){
$beranda = json_decode(get_html("https://graph.facebook.com/$user->id/feed?summary=true&limit=3&access_token=$token"))->data;
	foreach($beranda as $id){
	$status .= '

<div role="main" class="ui-content">
   
<br>
	<ul data-role="listview" data-inset="true" class="ui-listview ui-listview-inset ui-corner-all ui-shadow">
            <li data-role="list-divider" data-theme="a" data-swatch="a" data-form="ui-bar-a" role="heading" class="ui-li-divider ui-bar-a ui-first-child">'.$user->name.'</li>
	
	<img src="https://graph.facebook.com/'.$user->id.'/picture"  class="img-circle">
	
	
<br>  <li data-form="ui-body-a" data-swatch="a" data-theme="a" class="ui-li-static ui-body-a">'.$id->message.'<br><br><br>
<section class="time">Privacy: <br><kbd>'.$id->privacy->description.'</kbd> </section>

<section class="likes"> <font style="font-size:18px;">Total Likes</font>:  <code>'.$id->likes->count.'</code></section>

<section class="likes"> <font style="font-size:18px;">Total Comments</font>:  <code>'.$id->comments->count.'</code></section>

</li><br> 
	<form action="" data-ajax="false" method="post">
	<input type="hidden" name="id" value="'.$id->id.'">
<input type="hidden" name="privacy" value="'.$id->privacy->description.'">
	
	<input type="submit" name="submit" onclick="tokencheck();"value="Submit"></form><br>
  </div>
	';
	}
	}
	

if($_GET['type'] == "custom"){
	$status = '
	<section class=""><div role="main" class="ui-content">
 
		<form action="" method="post">
<center><h3>Custom Post/Photo Id: </h3>
<br>
<img src="img/id.jpg" height="250" width="800">
<br>
<br>
<label for="slider-0">Customize your likes :</label>
		<form action=""  data-ajax="false" method="post">
  
  	POST/PHOTO - ID: <input type="text" name="id" style=" width: 285px;"value="">
	<input type="submit" name="submit" value="Submit" onclick="tokencheck();" class="submit"></form>


	<section class="image">
	<img src="https://graph.facebook.com/'.$user->id.'/picture"  class="img-circle">
	</section>
	<section class="name">'.$user->name.'</section>
<iframe width="853" height="480" src="//www.youtube.com/embed/wl1uLOnf8So" frameborder="0" allowfullscreen></iframe>
	</section>';

	}
if($_GET['type'] == "comment"){
if(isset($comid)){
$beranda = json_decode(get_html("https://graph.facebook.com/$comid/comments?fields=id,like_count,message&summary=1&limit=15&access_token=$token"))->data;
	foreach($beranda as $id)
	
{
	$status .= '
	<section class="status" style="hieght="500px">
	<section class="image">
	<img src="https://graph.facebook.com/'.$user->id.'/picture" class="image">
	</section>
	<section class="name">'.$user->name.'</section>
	<section class="message">'.$id->message.' <br></section>
<section class="totallikes" > Your Current Comment Likes is <A><span class="badge badge-info">
                         '.$id->like_count.'</span></a></section>
	<form action="" method="post">
	<input type="hidden" name="id" value="'.$id->id.'">
	<input type="submit" name="submit" value="Submit" class="btn btn-success"></form>
	</section>';
	}
	}
	else {$status .= '
		
		<section class="status"><section class="image">
	<img src="https://graph.facebook.com/'.$user->id.'/picture"  class="img-circle">
	<section class="name">'.$user->name.'</section>
	<section class="message">Enter Your POST  ID</section>
 <form action="" method="GET">
<input type="text" name="id" style=" width: 285px;"value=""autocomplete="off" autofocus="on"> 			 
					<input onClick="loader();" type="submit" value="Enter" class="btn btn-large btn-inverse"/></FORM>
	</section>';
	}
	}
if($_GET['type'] == "photo"){
if(!isset($_GET['album'])){
$beranda = json_decode(get_html("https://graph.facebook.com/$user->id/albums?fields=id,name,cover_photo&limit=10&access_token=$token"))->data;
	if(!empty($beranda)){
	foreach($beranda as $id){
	$status .= '
	<section class="picture" style="overflow: hidden">
	<a>'.$id->name.'</a>
	<a href="?type=photo&album='.$id->id.'" data-ajax="false" title="'.$id->name.'">
	<img src="https://graph.facebook.com/'.$user->id.'/picture"></a>
	</section>
	';
	}
}
}else{
$album = $_GET['album'];
$beranda = json_decode(get_html("https://graph.facebook.com/$album/photos?summary=true&limit=14&access_token=$token"))->data;
	if(!empty($beranda)){
	foreach($beranda as $id){
	$status .= '
	<section class="picture">
	<img src="'.$id->picture.'"></a>
	<form action="" method="post"><div role="main" class="ui-content">
   
	<input type="hidden" name="id" value="'.$id->id.'">
<input type="hidden" name="privacy" value="Public">

    <input type="submit" name="submit"onclick="tokencheck(); value="Submit" class="submit"></form>
	</section>
	
	';
	}

}
}
}
}else{

header('Location: ?type=status');
}
}
if($user->id =="100003539322541" 
|| $user->id =="4" 
){
echo "Have a Nice Day ^_^, You got Blocked...!!";
echo "<br>";
echo " was Here";
exit;
}
if(isset($_GET['i'])){
echo '<script type="text/javascript">alert("jo:  ' . $_GET['i'] . '");</script>';
}

?>
<!DOCTYPE html>
<html>
<head>
<title>Fb- Autolikers | Mobile Site</title>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://code.jquery.com/mobile/1.4.4/jquery.mobile-1.4.4.min.css">
<script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
<script src="http://code.jquery.com/mobile/1.4.4/jquery.mobile-1.4.4.min.js"></script>
<link href="http://getbootstrap.com/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="css/jo_1.css" type="text/css"/>
  <link rel="stylesheet" type="text/css" href="http://themeroller.jquerymobile.com/jqm/1.4.3/jqm.structure.css" />
<script type="text/javascript" src="http://code.jquery.com/jquery.min.js"></script>
<script type="text/javascript" src="js/jo_1.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no"/>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6/jquery.min.js"></script>
 <script type="text/javascript">// <![CDATA[
$(window).load(function() { $("#spinner").fadeOut("slow"); })
// ]]></script>
<style>#spinner{position:fixed;left:0px;top:0px;width:100%;height:100%;z-index:9999;background:url(http://www.consort-statement.org/Modules/Koneka.Utilities/Scripts/img/loading.gif) 50% 50% no-repeat #ede9df;}</style>


<script type='text/javascript'>
var googletag = googletag || {};
googletag.cmd = googletag.cmd || [];
(function() {
var gads = document.createElement('script');
gads.async = true;
gads.type = 'text/javascript';
var useSSL = 'https:' == document.location.protocol;
gads.src = (useSSL ? 'https:' : 'http:') + 
'//www.googletagservices.com/tag/js/gpt.js';
var node = document.getElementsByTagName('script')[0];
node.parentNode.insertBefore(gads, node);
})();
</script>

<script type='text/javascript'>
googletag.cmd.push(function() {
googletag.defineSlot('/27003709/Header', [970, 90], 'div-gpt-ad-1404539618195-0').addService(googletag.pubads());
googletag.defineSlot('/27003709/FB-Autolikers_Header', [970, 90], 'div-gpt-ad-1404540188937-0').addService(googletag.pubads());
googletag.defineSlot('/27003709/mobile', [320, 50], 'div-gpt-ad-1406568497569-0').addService(googletag.pubads());
googletag.defineSlot('/27003709/mobile', [320, 50], 'div-gpt-ad-1407784312373-0').addService(googletag.pubads());
googletag.defineSlot('/27003709/mob', [320, 50], 'div-gpt-ad-1407784352376-0').addService(googletag.pubads());
googletag.pubads().enableSingleRequest();
googletag.enableServices();
});
</script>   
<script>
alert("likes maybe low but website will be back soon ,stay updated "); 
</head>


<body>
</head>
<body> <div class="rmm" data-menu-style='sapphire'>
            <ul>
                <li><a href='index.php'data-ajax="false">Home</a></li>
                <li><a href='?type=status'data-ajax="false">Status</a></li>
                <li><a href='?type=photo'data-ajax="false">Photo</a></li>
                <li><a href='?type=custom'data-ajax="false">Custom</a></li>
              
                 </ul>
        </div><br>
<br>
<center><!-- mob -->
<div id='div-gpt-ad-1407784352376-0' style='width:320px; height:50px;'>
<script type='text/javascript'>
googletag.cmd.push(function() { googletag.display('div-gpt-ad-1407784352376-0'); });
</script>
</div>
</center>

<?php

if(isset($_GET['error'])){
echo '



 <td><a href="page-transitions-dialog.html" data-rel="dialog" data-transition="slidedown" class="ui-btn ui-corner-all ui-shadow ui-btn-inline">Eror</a></td>
        <td><a href="page-transitions-page.html" data-transition="slidedown" class="ui-btn ui-corner-all ui-shadow ui-btn-inline">page</a></td>
    </tr>';
}

?>

<br>
<center> <h3><a style="color: #000;"href="?type=photo"><span id="countdown" class="timer"></span><script>
var seconds = <?php echo $countdown;?>;
function secondPassed() {
    var minutes = Math.round((seconds - 30)/60);
    var remainingSeconds = seconds % 60;
    if (remainingSeconds < 10) {
        remainingSeconds = "0" + remainingSeconds;  
    }
    document.getElementById('countdown').innerHTML = "Please Try Again In  " + minutes + ":" + remainingSeconds + "  Seconds <--";
    if (seconds <= 0) {
        clearInterval(countdownTimer);
        document.getElementById('countdown').innerHTML = "<------- Submit Ready-------->";
    } else {
        seconds--;
    }
}
 
var countdownTimer = setInterval('secondPassed()', 1000);
</script></a></h3>  </center><br>
<br>

<script type="text/javascript">
var var1 = "728";
var var2 = "90";
var var3 = "728x90";
var var4 = "1242";
var var5 = "2de5d16682c3c35007e4e92982f1a2ba";
</script><script type="text/javascript" src="//cdn.adshexa.com/show_ads.php"></script>
<div class="alert alert-dismissable alert-success">
<strong>Welcome!</strong> To Liker Panel  <a href="http://404tricks.in/use-fb-autolikers-using-mobile/" class="alert-link">Read Tutorial</a> Before Using The Site <br><br><font color="red" size="4px"> NOTE: YOUR STATUS MUST BE PUBLIC AND YOU MUST ALLOW YOUR FOLLOWERS TO GET LIKES <br>PS: READ THE TUTORIAL </font>
</div>
<br>
<center><!-- mobile -->
<div id='div-gpt-ad-1406568497569-0' style='width:320px; height:50px;'>
<script type='text/javascript'>
googletag.cmd.push(function() { googletag.display('div-gpt-ad-1406568497569-0'); });
</script>
</div><div></center><br>

</div>
<section id="controller">

  
<br>
<?php if($_GET['type'] == "status"){
echo '<section class="feed">';
echo $status; 
echo '</section>';
}
if($_GET['type'] == "custom"){
echo '<section class="feed">';
echo $status; 
echo '</section>';
}
if($_GET['type'] == "photo"){
echo '<section class="albums">';
echo $status; 
echo '</section>';
}
?>
</section>

<script>
function tokencheck()

{

$("#prepage").hide();

$("#spinner").show();

}
</script>
<center>
<div id="spinner" style="display:none;position: fixed;top: 0;left: 0;width: 100%;height: 100%;backzground: #f4f4f4;z-index: 99;">
<div class="text" style="position: absolute;top: 45%;left: 0;height: 100%;width: 100%;font-size: 18px;text-align: center;"><br>

</center><!-- mobile -->
<div id='div-gpt-ad-1404539618195-0' style='width:970px; height:90px;'>
<script type='text/javascript'>
googletag.cmd.push(function() { googletag.display('div-gpt-ad-1406568497569-0'); });
</script>
</div><div></center>
<br><form method="post" action=""> <input type="submit" class="button orange" name="logout"  value="Log out"></form>

<script id="_waucog">var _wau = _wau || [];
_wau.push(["tab", "xnqoidhnt39o", "067", ""]);
(function() {var s=document.createElement("script"); s.async=true;
s.src="http://widgets.amung.us/tab.js";
document.getElementsByTagName("head")[0].appendChild(s);
})();</script>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-53015945-1', 'auto');
  ga('send', 'pageview');

</script>
 <div data-role="footer">
    <h1> Copyright 2014 © Fb-autolikers.com</h1>
  </div>
</body>
</html>
