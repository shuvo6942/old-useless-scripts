<?php include 'info.php';?>
<!DOCTYPE html>
<html lang="en">
<head>
<title><?php echo $set[page_title];?></title>
<meta name="description" content=" <?php echo $set[page_description];?>"/>
<meta charset="UTF-8"/><meta http-equiv="X-UA-Compatible" content="IE=edge"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<meta name="google-site-verification" content="vQBBHMNzNDwv-2watW-KQKUfihRTdKxgzoXaA8548EM" />
<meta name="alexaVerifyID" content="YL1XYk3XzbFceve0mrcUDHlxzZY"/>
<meta content='general' name='rating'/>
<meta name="robots" content="index, follow"/>
<meta name="revisit-after" content="7 days"/>
<meta name="author" content="Sk Abu Bakar"/>
<meta name="dcterms.rightsHolder" content="LikezBd"/>
<meta property="og:site_name" content="LikezBd"/>
<meta name="keywords" content="<?php echo $set[page_keywords];?>"/>
<link rel="stylesheet" href="../css/asu..css" type="text/css"> <link rel="stylesheet" href="../css/asu..css" type="text/css"> 
<link rel="stylesheet" href="../css/asu..css" type="text/css"> 
<link rel="icon" type="image/x-icon" href="images/favicon.ico"/>
<link rel="stylesheet" href="../css/css.css" type="text/css"><script src="js/google.js"></script><script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-69270886-1', 'auto');
  ga('send', 'pageview');

</script></head><body><div id="header"><h1>LikezBd.Com</h1><p class="description">Increase Facebook Likes | FB Tools<br>Mobile Version | Use UC Browser Mini</p><hr><script>admin=('Admin@'+'LikezBd.Com');document.write('<small>Contact : <a href="mailto:'+admin+'">'+admin+'</a></small>')</script><div id="nav-top"><a href="/index.php">Home</a> <a href="/m-privacy.php">Privacy</a> <a href="/m-help.php">Help</a></div>
</div>
<div class="menu"><h3>We Are Social</h3><li><a href="http://facebook.com/rihs.bd">Like Official FB Page</a></li><li><a href="https://m.facebook.com/groups/tipsfire.official">Join Official FB Group</a></li><li><a href="/tut.php">HOW TO GET TOKEN</a></li>  </div>