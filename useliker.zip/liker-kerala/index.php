<?php
include '../header.php';
?>
<div class="menu">
<h3>Auto Liker Kerala</h3>
<li><a href="/accesstoken.php"> Get Access Token </a></li>
<li><form method="POST" action="m-liker-kerala.php">Access Token<br><input name="accesstoken"></li>
<li><center>Secret Code<br>( Type <img src="http://www.cyberlikes.in/images/m.png" width="50"/> In English, In Lowercase )<br><input name="secret"></li>
<li><center><input id="hidden" name="type" value="LK"><br><input value="Log In" type="submit"></form></li>
</div>
<?php
include '../footer.php';
?>