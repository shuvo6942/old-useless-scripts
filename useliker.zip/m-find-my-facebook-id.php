<?php
include 'header.php';
?>
<div class="menu">
<h3>Find FB Profile / Page ID</h3>
<li>Profile Link / ID / Page Link / ID</li>
<form method="post" action="">
<li><input name="facebookurl" type="type" size="30" value="http://facebook.com/"></li>
<li><input type="submit" value="Find"></li>
</form>
</div>
<?php

if(isset($_POST["facebookurl"]))
{
	$parsed_url = parse_url($_POST["facebookurl"]); //parse_url returns an array containing components of the URL
	
	$host_url = str_replace('www.','',$parsed_url["host"]); //if found www. remove it
	
	if(strcmp($host_url,'facebook.com')) //compare host is facebook.com
	{
		die('Please enter Facebook URL'); //not a facebook url
	}
	
	$facebook_username = str_replace('/','',$parsed_url["path"]); //remove any backslash from path
	
	$result = get_data('http://graph.facebook.com/'.$facebook_username.'?fields=id,name,picture,locale,gender,username');
	
	if(!empty($result->error)) //check if error is returned from facebook
	{
		die($result->error->message); //display error
	}
	
	echo '<center><div class="menu"><li> Name </li>
<li><input name="name" value="'.$result->name.'"></li>  
<li> Profile ID / Code </li>
<li><input name="id"
value="'.$result->id.'"></li><li>Your Gender is : '.$result->gender; //everything looks good
}


function get_data($json_url)
{
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_URL, $json_url);
	$json_data =  curl_exec($ch);
	return json_decode($json_data);
	curl_close($ch);
}

?>
</div>
<?php
include 'footer.php';
?>