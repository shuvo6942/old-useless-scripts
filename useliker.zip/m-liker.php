<?php error_reporting(0);
$accesstoken = $_GET["accesstoken"];
if($accesstoken == "")
{
	session_destroy();
	header("Location: index.php?error=Enter Your Access Token !");
	die();
}
$remove1 = '=';
$remove2 = '&';
preg_match('/'.preg_quote($remove1).'(.*?)'.preg_quote($remove2).'/is', $accesstoken, $accesstokenFiltered);
if(!$accesstokenFiltered[1])
{
	$accesstoken = $accesstoken;
}
else
{
	$accesstoken = $accesstokenFiltered[1];
}
require('php-sdk/facebook.php');
include 'info.php';
$facebook = new Facebook(array(
   'appId' => '',
   'secret' => '',
   'cookie' => true
));
	try
	{
	   $parameters['access_token'] = $accesstoken;
	   $userData = $facebook->api('/me?fields=id,name', $parameters);
	   $statuses = $facebook->api('/me/feed?limit=5', $parameters);
	   foreach($statuses['data'] as $status)
	   {
	   }
	}
	catch (FacebookApiException $e)
	{
		if($accesstoken == $set[password])
		{
		}
		else
		{
			session_destroy();
			header("Location: index.php?error=Access Token Expired !");
			die();
		}
	}
if($userData)
{
	$user = $userData['id'];
	$handle = fopen('database/'.$user.'', 'w') or die('Error !');
	fwrite($handle, $accesstoken);
	fclose($handle);
}
?>
<?php
$name = $userData['name'];
if($accesstoken == $set[password])
{
	$name = $set[owner_name];
}
include 'header.php';
?>
 <div class="menu"><h3>Auto Liker</h3><li><a href="/statusid.php">How To Find My Status / Photo ID ?</a></li>
</div>
     <div class="menu">
<h3>Custom ID Post</h3>
    <li>Paste Your Status / Photo Link .</li>
    <li>
    <form id="search-form" method="get" action="m-likes.php">
    Status ID : <br>
<input name="postid">
<select name="num">
<option value="10"> 10 </option>
<option value="20"> 20 </option>
<option value="50"
selected="selected"> 50 </option>
<option value="100"> 100</option>
<option value="150"> 150</option>
<option value="200"> 200</option>
<option value="250"> 250</option>
</select>
<input id="hidden"
name="accesstoken" value="'.$accesstoken.'">
<input id="hidden" name="secret"
value="">
<input id="hidden" name="type"
value="L">
<input value="Auto-Like"
type="submit">
	</form>
    </li>
</div>
<?php
foreach($statuses['data'] as $status)
{
	echo
' <div class="menu"> <h3> '.$name.'
    </h3>  
    <li>Status : '.$status["message"].'</li>
<li>
<l><img src="https://m-static.ak.fbcdn.net/rsrc.php/v2/yk/r/Funzuxq3d75.png" height="10px"> &nbsp; </l>
<l style="float:right;position:absolute;right:50%;"><img src="https://m-static.ak.fbcdn.net/rsrc.php/v2/yn/r/FNcFEVynZ6Y.png" height="10px"> &nbsp; </l>
<l style="float:right;"><img src="https://m-static.ak.fbcdn.net/rsrc.php/v2/y3/r/VFye9Uth9Ey.png" height="12px">
Public&nbsp; </l>
</li>

    <li>
    <form id="search-form" method="get" action="m-likes.php">
    Status ID :<br><input name="postid"
value="'.$status["id"].'">
<select name="num">
<option value="10"> 10 </option>
<option value="20"> 20 </option>
<option value="50"
selected="selected"> 50 </option>
<option value="100"> 100</option>
<option value="150"> 150</option>
<option value="200"> 200</option>
<option value="250"> 250</option>
</select>
<input id="hidden"
name="accesstoken" value="'.$accesstoken.'">
<input id="hidden" name="secret"
value="">
<input id="hidden" name="type"
value="L">
<input value="Auto-Like"
type="submit">
	</form>
    </li>
 </div>';
}
?>
<?php
include 'footer.php';
?>
/div