<?php
include 'header.php';
?>
<div class="menu">
<h3>Privacy Policy</h3>
<a class="pesan">Sharing your personal information</a>
<p>We don't sell, trade and rent your personal information to others and don't sell your access_token likes to other website. We are using your access_token just for free Facebook auto status and photo like and we don't sell your personal information to others.</p>
<a class="pesan">Third party websites</a>
<p>In our website third party advertisement may be display like adfly & yllix. Users may find advertising or other content on our site that link to the sites and services of our partners, suppliers, advertisers, sponsors, licensors and other third parties. We do not control the content or links that appear on these sites and are not responsible for the practices employed by websites linked to or from our Site. In addition, these sites or services, including their content and links, may be constantly changing. These sites and services may have their own privacy policies and customer service policies. Browsing and interaction on any other website, including websites which have a link to our site, is subject to that website's own terms and policies.</p>
<a class="pesan">Changes to this privacy policy</a>
<p>We encourage users to frequently check this page for any changes to stay informed about how we are helping to protect the personal information we collect. You acknowledge and agree that it is your responsibility to review this privacy policy periodically and become aware of modifications.</p>
<a class="pesan">Your acceptance of these terms</a>
<p>By using this site, you signify your acceptance of this policy. If you do not agree to this policy, please don't use our site. Your continued use of the site following the posting of changes to this policy will be deemed your acceptance of those changes.</p>
<a class="pesan">Contact us</a>
<p>If you have any questions about this Privacy Policy, the practices of this site, or your dealings with this site, please <script>admin=('admin@'+'useliker.gq');document.write('Contact : <a href="mailto:'+admin+'">'+admin+'</a>')</script>.This document was last updated on December 16, 2014.</p>
</div>
<?php
include 'footer.php';
?>