<?php
include '../header.php';
?>
<div class="menu">
<h3>Auto-Liker No-Token</h3>
<li><a href="/statusid.php" target="_blank">How To Find My Status / Photo ID ?</a></li>
</div>
<div class="menu">
<h3>100+ Likes Per Click !</h3>
<li>Paste Your Status ID / Link</li>
<li>
<form id="search-form" method="POST" action="/m-auto-liker-no-token.php">
Status ID
<br>
<input name="id"/>
<select name="num" disabled="disabled">
<option>100+</option>
</select>
<input value="Auto-Like" type="submit"/>
</form>
</li>
</div>
<?php
include '../footer.php';
?>