<?php
include 'header.php';
?>
<div class="menu"><h3>FAQs</h3><li><a href="images/tutorial.jpg">How To Use ?</a><p>Read this tutorial to know how to use the site.</p></li><li><a>Need Settings To Change ?</a><p>You must change your <a href="https://m.facebook.com/settings/subscribe/?refid=31">[ Follower Settings ]</a> to public to get likes and comments</p></li><li><a href="accesstoken.php?type=L">How To Get Token ?</a><p>Open above link and follow those steps to get token.</p></li><li><a href="statusid.php">How To Find Status ID / Link ?</a><p>Open above link and follow those steps to get your status ID / Link.</p></li><li><a>Supported Browsers</a><p>Opera MIni ( liker and commenter )</p><p>UC Browser Mini</p><p>Google Chrome</p></li><li><a href="m-users.php">Website Users</a><p>See our active users.</p></li><li><a>Desktop Version</a><p>Use our desktop version ( <a href="http://WwW.LikezBd.Com"> WwW.LikezBd.Com </a>) to get maximum likes and comments, google chrome or mozilla firefox recommended.</p></li></div>
<?php
include 'footer.php';
?>