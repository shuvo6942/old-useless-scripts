<?php include'header.php'; ?>
<div><div style="background-color:#eeeff8" class="pesan" ><p>
<hr/>(১) অটোলাইক নেয়ার জন্য আপনার বয়স ১৮ এর উপরে হতে হবে। আপনার বয়স ১৮ এর নিচে হলে<a href="https://m.facebook.com/editprofile.php?type=basic&amp;edit=birthday&amp;refid=17"> এই লিনকে </a>গিয়ে ফেসবুকে আপনার বয়স বারিয়ে নিন।</p> <hr/><div><div class="pesan" style="background-color:#eeeff8"><p><hr/>
(২) এর পর আপনি ফেসবুক ফলোয়ার সেটিং অন করেন। ফলোয়ার সেটিং অন করতে <a href="https://m.facebook.com/settings/subscribe/?refid=31">এই লিনকে</a> যান। তারপর সবগুলোতে ক্লিক করে "Public" অথবা" করে দিন।</p> <hr/></div>

<div class="pesan" style="background-color:#eeeff8"><p><hr/>
(৩) "Opera Mini" এর "Single Column View" অথবা "Mobile View" অবশ্যই  অফ থাকতে হবে।</p> <hr/></div></div></div></div>
<div class="menu"> এখান থেকে এক্সেস টোকেন সংগ্রহ করুন -> <b><a href="/token.php">NOKIA TOKEN</a></b><br>
এক্সেস টোকেনে সংগ্রহ করতে গেলে সেখানে কয়েকবার okye দিতে হবে !</br>
এরপর ERROR লেখা পেজ আসবে ।।</br>
<font color="green">পেজটির লিংকটি ব্রাউজারের Page info/address bar থেকে কপি করুন ।<br>লিংকটি দেখতে কিছুটা এইরকম হবে !!</font><br>https://account.nokia.com/login/useliker_sk_Abu_Bakar#access_token=<font color="red">********* </font>&expires_in=0
<br>
<font color="red">*****</font> দেয়া আংশটুকু হল এক্সেস টোকেন ।
এক্সেস টোকেন দেখতে কিছুটা এমন <br>
<font color="gray">CAAAAPJmB8ZBwB AMZCbdEdiGic QWZAtilSavT y1mUFxmMEZB A1EK009e dktYYGBsWyKA gdLV9tyJgx</font><br>
<font color="green">
মনে রাখবেন accsses_token=এর পর থেকে &expires_in=0 এর আগে পর্যন্ত কপি করতে হবে। <br>
এক্সেস টোকেন সংগ্রহ করে,
এই বক্সে পেস্ট করে কানেক্ট করুন :
<br>
</font></div>
<?php include'footer.php'; ?>