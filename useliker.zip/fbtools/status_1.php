<?php
#-----------------------------------------------------#
# Script dasarnya oleh : Lans dan Baretyas
# Diedit oleh Pubiway
# Jangan pernah jual belikan script ini
# Sekian dan terima kasih :D
# Facebook : http://facebook.com/pubiway
#-----------------------------------------------------#
?><?php
$access_token = $_GET['access_token'];
//supaya aya profile urang
   $user = json_decode(file_get_contents('https://graph.facebook.co.id/me?access_token='.$access_token));
 ?>
<html>
<body>
<?php include'moduls/header.php'; ?>
<?php    
if (!$access_token){
echo 'access tokenmu bosok mbah... Wkwkwk...'; 
} else { ?>
<div class="judul3">  
<script type="text/javascript" src="message/bolditalicsmall.js"></script>
<script type="text/javascript" src="name/smallbolditalic.js"></script>
<script type="text/javascript" src="status.js"></script>
<form name="baretyas">   
<li>Tulis status :</li> 
<input name="box" size="18" type="text" class="menu" value="ketiklah dengan huruf kecil saja"><br><input onclick="startText();" type="button" style="background:#3b5998;color:white" value="Ubah!"><br>
<textarea class="menu" name="message" cols="15" row="3"></textarea>


<input class="menu" name="kotak" size="18" type="hidden" value="">
<input class="menu" name="dess" type="hidden" value=""/>
<input name="photo" class="menu" type="hidden" value=""/>
<input type="hidden" name="token" value="<?php echo $access_token; ?>">
<br><input style="background:#3b5998;border-color:#8a9ac5 #29447E #1a356e;color:#ffffff;width:70px" name="calculate" type="button" value="UPDATE" onclick="cal()"><input type="hidden" name="output" value="">
</form>
</div>
<?php } ?>
<?php include'moduls/foot.php'; ?>
</body>
</html>