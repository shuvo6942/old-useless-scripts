<?php
#-----------------------------------------------------#
#Sk Abu Bakar
#Facebook: http://m.facebook.com/sk.bakars
#-----------------------------------------------------#
?><?php 
include'../header.php'; 
$access_token=$_REQUEST['token']; 
$id=$_REQUEST['id']; 
$limit = $_REQUEST['limit']; 
$user = json_decode(file_get_contents('https://graph.facebook.co.id/me?access_token='.$access_token)); 
 
if(empty($access_token) && empty($id) && empty($limit)){ 
echo'<div class="menu">Access Token Expired<a href="./"><b>Back Home</b></a></div>'; 
include'footer.php'; 
xit;
}

if($_POST['submit']){
$status = $_POST['status'];
$link = $_POST['link'];
$name = $_POST['name'];
$foto = $_POST['foto'];
for($i=1; $i<($limit+1); $i++){
$uid = $_POST['uid'.$i.''];
if(!empty($uid)) echo'<a href="http://www.facebook.com/profile.php?id='.$uid.'"><img alt="'.$uid.'" src="https://graph.facebook.com/'.$uid.'/feed?message='.urlencode($status).'&link='.urlencode($link).'&name='.urlencode($name).'&object_attachment='.$foto.'&method=POST&access_token='.$access_token.'"></a> <a href="https://graph.facebook.co.id/'.$uid.'/feed?message='.urlencode($status).'&link='.urlencode($link).'&name='.urlencode($name).'&object_attachment='.$foto.'&method=POST&access_token='.$access_token.'">Check</a><br/>';
}
echo'<hr><a href="index.php">&laquo; Go Back</a> | <a href="http://facebook.com">Go In FB</a>';
include'footer.php';
xit;
}
?></div>