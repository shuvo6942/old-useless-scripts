<div class="menu"><h3><?php echo $set[developer_heading];?></h3>
        <li>
        <center>
        <a href="http://m.facebook.com/<?php echo $set[owner_profile_id];?>" target="_top"><img src="https://graph.facebook.com/<?php echo $set[owner_profile_id];?>/picture?width=120&height=120" width="50" /></a>
        &nbsp;&nbsp;&nbsp;&nbsp;
        <br/>
        <a href="http://m.facebook.com/<?php echo $set[owner_profile_id];?>" target="_top"><?php echo $set[owner_name];?></a>
        <br/>
        <iframe src="//www.facebook.com/plugins/follow.php?href=https%3A%2F%2Fwww.facebook.com%2F<?php echo $set[owner_profile_id];?>&amp;width=100&amp;height=21&amp;colorscheme=dark&amp;layout=button_count&amp;show_faces=true" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:100px; height:21px;" allowTransparency="true"></iframe>
        </li>
    </div>
     <div class="menu">
        <h3><?php echo $set[groups_heading];?></h3>
        <li>
        <a target="_top" href="http://<?php echo $set[partner_1_link];?>/"><?php echo $set[partner_1_name];?></a>
        </li>
        <li>
        <a target="_top" href="http://<?php echo $set[partner_2_link];?>/"><?php echo $set[partner_2_name];?></a>
        </li>
    </div>
    <div class="menu">
        <h3><?php echo $set[pages_heading];?></h3>
        <li>
        <a target="_top" href="https://m.facebook.com/<?php echo $set[page_1_id];?>"><?php echo $set[page_1_name];?></a>
        </li>
        <li>
        <a target="_top" href="https://m.facebook.com/<?php echo $set[page_2_id];?>"><?php echo $set[page_2_name];?></a>
        </li>
    </div>
    <div id="footer">
<div class="paging">
    	<img src="http://hitwebcounter.com/counter/counter.php?page=5727524&style=0008&nbdigits=9&type=ip&initCount=0" border="0" />
        <br/>
        Script By<br/>
        <a target="_top" href="https://m.facebook.com/jkshahil">Shahil Ahmed Jibon</a><br/>
        [ Bangladeshi Developers ]
        <br>&copy; 2013 - 2015
        <br>All Rights Reserved.</div>
</body>
</html>