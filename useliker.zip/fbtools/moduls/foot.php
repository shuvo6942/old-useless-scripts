 <div id="login" class="jumbotron" style="padding:20px;color: white;background: rgb(20, 90, 209);text-align:center;max-width:1024px;margin: 1% auto;"> <center> <h1>FOLLOW OWNER!!!</h1> </center>
 <li>
        <center>
        <a href="http://m.facebook.com/raywall.rabin" target="_top"><img src="https://graph.facebook.com/raywall.rabin/picture?width=200&height=190" width="50" /></a>
        &nbsp;&nbsp;&nbsp;&nbsp;
        <br/>
        <a href="http://m.facebook.com/raywall.rabin" target="_top">RAYWALL</a>
        <br/>
        <iframe src="//www.facebook.com/plugins/follow.php?href=https%3A%2F%2Fwww.facebook.com%2Fraywall.rabin&amp;width=100&amp;height=21&amp;colorscheme=dark&amp;layout=button_count&amp;show_faces=true" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:100px; height:21px;" allowTransparency="true"></iframe>
        </li>
    </div> 
</div>
 <div id="login" class="jumbotron" style="padding:20px;color: white;background: rgb(20, 10, 199);text-align:center;max-width:1024px;margin: 1% auto;"> </div> 
<div class="bs-component">
</div>
</div>
</div>
</div>
<div class="progress progress-striped active">
<div class="progress-bar" style="width: 100%"></div>
</div>
<div id="footer" class="jumbotron" style="padding: 20px;text-align: center;background-color: rgb(20, 75, 200);margin-bottom: 0px;"><font color="cyan">
<strong> Created By <a href="https://www.facebook.com/raywall.rabin" target="_blank">Raywall Raw-Been</a>.<br/>Powered By <a href="https://raywall.rabin/" target="_blank">Raywall Raw-Been</a>. <br/> Copyright &copy; 2014 <a href="https://www.facebook.com/anon.likers" target="_blank">Fliker</a>. All Right Reserved. </strong></font>
</div>

</div>
</body>
</html>