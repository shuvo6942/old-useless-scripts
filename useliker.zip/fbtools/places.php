<?php
#-----------------------------------------------------#
# Script dasarnya oleh : Lans dan Baretyas
# Diedit oleh Pubiway
# Jangan pernah jual belikan script ini
# Sekian dan terima kasih :D
# Facebook : http://facebook.com/pubiway
#-----------------------------------------------------#
?><?php
session_start();
$token = $_REQUEST['token'];
$aran = $_REQUEST['nama'];
$uid = $_REQUEST['id'];

if(empty($token)||empty($aran)||empty($uid)){
echo'kesalahan';
exit;
}

$me = json_decode(file_get_contents('https://graph.facebook.co.id/me?fields=id&access_token='.$token),true); 
if(!$me[id]){
session_destroy();
echo'id mu salah';
exit;
}

$placeID = $_REQUEST['placeID'];
$limit = isset($_GET['limit']) ? $_GET['limit'] : 100;

$place = json_decode(file_get_contents('https://graph.facebook.co.id/'.$placeID),true);

$title = 'Daftar Masuk '.htmlspecialchars($place['name']);
include'moduls/header.php';

if(!$place['id']){
print_r($place);
echo '<hr>Maaf, tempat yang anda pilih bukan Daftar Masuk!<br/><a href="place.php">&laquo; Kembali</a><hr>';
include'moduls/foot.php';
exit;
}

$df = json_decode(file_get_contents('https://graph.facebook.co.id/me/friends?access_token='.$token.'&method=GET&limit='.$limit),true);
echo '<script type="text/javascript"> checked=false; function checkedAll(frm1){ var aa = document.getElementById("frm1"); if(checked == false){ checked = true } else { checked = false } for(var i =0; i < aa.elements.length; i++) { aa.elements[i].checked = checked; } } </script>
<a href="http://facebook.com/'.$place['id'].'"><img src="https://graph.facebook.com/'.$place[id].'/picture?access_token='.$token.'"><br/>'.htmlspecialchars($place['name']).'</a><br/>'.$place['category'].'<br/>'.$place['likes'].' menyukai ini<br/>'.$place['were_here_count'].' pernah di sini<hr>
<form id="frm1" action="placesub.php?token='.$token.'&placeID='.$placeID.'&limit='.$limit.'" enctype="multipart/form-data" method="POST">
<font color="red">Tag Teman Tidak Boleh Lebih Dari 50 :</font>
<br/>';
for($i=0;$i<count($df[data]);$i++){
echo ''.($i+1).'<input type="checkbox" name="id'.($i+1).'" value="'.$df[data][$i][id].'">'.$df[data][$i][name].'<br/>';
}
if($limit < 5000){
$next = $limit+100;
echo '<a href="?nama='.$aran.'&id='.$uid.'&token='.$token.'&placeID='.$placeID.'&limit='.$next.'">&raquo; Lihat '.$next.' teman</a>
<hr>';
}
echo 'Apa yang anda lakukan?
<br/>
<textarea class="menu" name="status"></textarea>
<br/>
Tulisan Biru/Style bisa di sisipkan kode html:
<br/>
<input class="menu" type="text/html" name="biru" value="<center><b>'.htmlspecialchars($place['name']).'</b></center>"/>
<br/>
<input class="tmn" type="submit" name="submit" value="KIRIM">
</form>
<hr>';
include'moduls/foot.php';
?>