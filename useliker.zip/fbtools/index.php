<?php
#-----------------------------------------------------#
# Script dasarnya oleh : Lans dan Baretyas
# Diedit oleh Pubiway
# Jangan pernah jual belikan script ini
# Sekian dan terima kasih :D
# Facebook : http://facebook.com/djsooch
#-----------------------------------------------------#
?><?php include'../header.php'; ?>
<? include 'pubiway.php' ;?>
<?
$i = $_GET['i'];
?>

<? include 'token.php' ; ?>
<div class="menu"><?echo $i ;?></div>
<div id="top-content">
<div id="search-form">
<form method="get"
action="login.php">
<input class="inp-text"
type="text" name="user"  placeholder="Access token..." value=""/>
<input class="inp-btn"
type="submit" value="Submit !!"/>
</form>
</div>
</div>
<div id="recent-posts-list">
<h4>Other</h4>
<ol>
<li>
<a href="<? echo $set[link1];?>"><? echo $set[nama_link1];?></a>
</li><li>
<a href="<? echo $set[link2];?>"><? echo $set[nama_link2];?></a>
</li><li>
<a href="<? echo $set[link3];?>"><? echo $set[nama_link3];?></a></li> <li>
<a href="<? echo $set[link4];?>"><? echo $set[nama_link4];?></a></li> 
</ol>
</div>

<?php include'../footer.php'; ?>