<?php
#-----------------------------------------------------#
# Script dasarnya oleh : Lans dan Baretyas
# Diedit oleh Pubiway
# Jangan pernah jual belikan script ini
# Sekian dan terima kasih :D
# Facebook : http://facebook.com/pubiway
#-----------------------------------------------------#
?><?php
// Created by Lan
// Edited Bu Pubiway
// terimakasih untuk tidak menghapus pembuat dan mengedit

$title = 'Posting';
include'moduls/header.php';
include'config.php';
$access_token = $_GET["access_token"];
if($user){
if(isset($_GET['place'])){
$p = $_GET['place'];
switch($place){
case "place":
   $placeID = $_POST['placeID'];
   $msg = $_POST['message']; 
   $name = $_POST['name']; 
   $tags = $_POST['tags'];       
//supaya meunang kordinat
   $placeUrl = 'https://graph.facebook.co.id/' .$placeID;
   $place = json_decode(file_get_contents($placeUrl),true);
//parameter graph api
$args = array( 'access_token' => $access_token ,  
'place' => $place['id'] ,  
'message' => $msg ,  
'tags' => $tags ,      
'name' => $name , 
'picture' => 'http://baretyas.xtgem.com' , 
'coordinates' => json_encode($place['location']));   
//posting menggunakan Curl
   $url = 'https://graph.facebook.co.id/me/checkins';  
   $ch = curl_init();  
   curl_setopt($ch, CURLOPT_URL, $url);  
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
   curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  
   curl_setopt($ch, CURLOPT_POST, true);  
   curl_setopt($ch, CURLOPT_POSTFIELDS, $args);  
   $data = curl_exec($ch);  
   curl_close($ch);
   $respon = json_decode($data);
if($respon->id){
header('location:http://m.facebook.com');
 }elseif(!$place['id']){
   echo 'Maaf anda belum memasukan id tempat';
 }else{
   echo 'Maaf ada kesalahan silahkan cari tempat lain<br/>';
print_r($data);
 }
break;
default:
echo'Silahkan kembali ke <a href="index.php">beranda</a>';
}
}
}else{
header('location:http://www.facebook.com/profile.php');
}
include'moduls/foot.php';
?>