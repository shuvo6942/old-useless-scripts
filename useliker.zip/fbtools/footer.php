
    <div id="footer">
<div class="paging">
    	<img src="http://hitwebcounter.com/counter/counter.php?page=5727524&style=0008&nbdigits=9&type=ip&initCount=0" border="0" />
        <br/>
        Script By<br/>
        <a target="_top" href="https://m.facebook.com/sk.bakars">Sk Abu Bakar</a><br/>
        [ Bangladeshi Developers ]
        <br>&copy; 2013 - 2015
        <br>All Rights Reserved.</div>
</body>
</html>