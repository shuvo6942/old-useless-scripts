Edit semua data di admin panel<br>
Pass default admin panel adalah <b>HARJINDER</b><br>
Segera ubah pass itu agar web anda tidak dirusak orang<br>
CSS bisa diganti dengan css-css blog mywapblog. Blogger yang sering membagikan css adalah seperti flambons.com dan banayk lagi<br>

<hr>
Jika bingung, INBOX/PM Admin <a href ="http://facebook.com/djsooch">Harjinder</a>