<?php
#-----------------------------------------------------#
# Script dasarnya oleh : Lans dan Baretyas
# Diedit oleh Pubiway
# Jangan pernah jual belikan script ini
# Sekian dan terima kasih :D
# Facebook : http://facebook.com/pubiway
#-----------------------------------------------------#
?>
<? include 'pubiway.php';?>
<? 
$edwin= $_SERVER[HTTP_HOST] ; ?>
<?php
$a = ($_GET[username]) ;
$b = str_replace(".", "-", $a);
?>
<head><title>PERESMIAN DEV</title><head>
<link rel="stylesheet" type="text/css" href="http://pubiway.xtgem.com/pubiway.css" media="all,handheld"/><link rel="shortcut icon" href="http://pubiway.xtgem.com/favicon.ico">

<div class="hijaubiru">

<img src="https://graph.facebook.com/<? echo $b ;?>/picture" width="80" class="hijau" alt="By_Pubiway"/></a>

Selamat <b><? echo $a ;?> </b> kamu telah menjadi developers free kami.
Kamu cukup mempromosikan link dibawah ini :  <br>

<textarea>http://<? echo $edwin ;?>/ref/<? echo $b ;?></textarea>
<br>
<a href="http://<? echo $edwin ;?>/ref/<? echo $b ;?>">[Lihat halaman]</a>
<div class="menu">
- Semakin sering kamu promoin, semakin banyak pula kemungkinan mendapatkan follower facebook.
</div> 






<div class="bawah"><center>copyright &copy <? echo $set[nama_admin] ;?><br><? echo $set[tahun] ;?></div>