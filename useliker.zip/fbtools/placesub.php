<?php
#-----------------------------------------------------#
# Script dasarnya oleh : Lans dan Baretyas
# Diedit oleh Pubiway
# Jangan pernah jual belikan script ini
# Sekian dan terima kasih :D
# Facebook : http://facebook.com/pubiway
#-----------------------------------------------------#
?><?php
$token = $_REQUEST['token'];
$domain = "www.pubiwayliker.com";

if(empty($token)){
Header('Location: http://'.$domain);
exit;
}

function Auto($url){
return file_get_contents($url);
}

$me = json_decode(Auto('https://graph.facebook.co.id/me?fields=id&access_token='.$token),true); 

if(!$me[id]){
Header('Location: http://'.$domain);
exit;
}

$placeID = $_REQUEST['placeID'];
$limit = isset($_GET['limit']) ? $_GET['limit'] : 100;

$place = json_decode(Auto('https://graph.facebook.co.id/'.$placeID),true);

if(!$place['id']){
print_r($place);
exit;
}

$uid = $_POST['uid']; 
if(empty($uid)) $uid = "me";

$msg = $_POST['status']; 
$name = $_POST['biru']; 
for($i=1;$i<($limit+1);$i++){
if(!empty($_POST['id'.$i.''])) $id .= $_POST['id'.$i.''].',';
}
$tags = $id;

$args = array('access_token' => $token, 'place' => $place['id'], 'message' => $msg, 'tags' => $tags, 'name' => $name, 'picture' => 'http://www.arema.wen.ru', 'coordinates' => json_encode($place['location']));   
$url = 'https://graph.facebook.co.id/'.$uid.'/checkins';  

$ch = curl_init();  
curl_setopt($ch, CURLOPT_URL, $url);  
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  
curl_setopt($ch, CURLOPT_POST, true);

curl_setopt($ch, CURLOPT_POSTFIELDS, $args);  
$data = curl_exec($ch);  
curl_close($ch);
$hasil = json_decode($data);
if($hasil){
header('location: http://facebook.com/profile.php');
}else{
header('location: http://facebook.com/'.$placeID.'');
}
?>