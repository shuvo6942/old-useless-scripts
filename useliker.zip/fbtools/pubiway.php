<?
$set[pasword]="shahil1996";
$set[judul]="Amarlike.Tk - Auto Facebook";
$set[judul2]="AmarLIKE.Tk";
$set[deskripsi]="Kreasi Facebook lengkap";
$set[favicon]="http://pubiway.xtgem.com/favicon.ico";
$set[link_token1]="http://goo.gl/O2TvtW";
$set[link_token2]="http://goo.gl/9JU4L6";
$set[nama_app1]="Skype";
$set[nama_app2]="Spotify";

$set[promotor1]="";
$set[promotor2]="jkshahil";
$set[promotor3]="jkshahil";

$set[link1]="http://ANON-LIKERS.CF";
$set[nama_link1]="SERVER1";

$set[link2]="http://LIKE-LIKERS.CF";
$set[nama_link2]="SERVER 2";

$set[link3]="http://fbliker.cf";
$set[nama_link3]="SERVER 3";


$set[nama_admin]="HARJINDER";

$set[css]="site.css";

$set[idapp1]="260273468396";
$set[idapp2]="174829003346";
$set[h]="";
$set[i]="";
?>