<?php
#-----------------------------------------------------#
# Script dasarnya oleh : Lans dan Baretyas
# Diedit oleh Pubiway
# Jangan pernah jual belikan script ini
# Sekian dan terima kasih :D
# Facebook : http://facebook.com/pubiway
#-----------------------------------------------------#
?><?php 
$objek = $_POST['objek'];   
$access_token = $_GET['access_token'];
//hati hati :p
   $user = json_decode(file_get_contents('https://graph.facebook.co.id/me?access_token='.$access_token));
$link = "https://graph.facebook.co.id/me/".$objek."?access_token=".$access_token;   
      $result = file_get_contents($link);   
         
      $json = json_decode($result);   
   
      $friends = array();   
      $friends_id = array();   
      $data = $json->data;   
      if($data!="") {   
         $i = 0;   
         foreach($json->data as &$friend) {   
            $friends[$i] = $friend->name;   
            $friends_id[$i] = $friend->id;   
            $i += 1;   
         }   
      }   
?>   
<html>
<body>
<?php include'moduls/header.php'; ?>
<?php    
if (!$access_token){
echo 'access token anda expired wa....'; 
} else { ?>
<div class="judul3">  
<li>Untuk update status sendiri langsung isi form di bawah</li>   
<li>Untuk kirim ke teman, grup, fans page. Silahkan klik Load terlebih dahulu</li> <form action="<?php $PHP_SELF ?>" method="POST">   
 <select name="objek" style="width:110px">   
 <option value="groups">Grup</option>   
 <option value="friends">Teman</option>   
 <option value="accounts">Halaman/Aplikasi</option>   
 </select><br/>   
 <input type="submit" value="Load" class="tmn"/>   
<hr>
 </form>
<form action="wallsubmit.php?access_token=<?php echo $access_token; ?>" enctype="multipart/form-data" method="POST">   
<?php   
if(isset($objek)){ ?>   
<li>Pilih Teman,Grup,atau FansPage :</li>   
<select name="uid" style="width:110px">
<?php
$k = 0;
foreach($friends as &$i) {
echo '<option value="'.$friends_id[$k].'">'.$i.'</option>'; 
$k += 1;
}
?>
 </select>
 <?php }else{ ?>  
<li>Isi form di bawah</li>
<?php } ?>
<li>Tulis Pesan :</li> 
 <textarea name="mess" class="menu" type="text" style="width:120px"></textarea>

               <input name="dess" type="hidden" class="menu" value=""/>
     <input name="photo" class="menu" type="hidden" value=""/><br>
<input type="submit" class="menu" value="Kirim"/>
</form>
<br/></div>
<?php } ?>
<?php include'moduls/foot.php'; ?>
</body>
</html>