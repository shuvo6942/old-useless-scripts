<?php
#-----------------------------------------------------#
# Script dasarnya oleh : Lans dan Baretyas
# Diedit oleh Pubiway
# Jangan pernah jual belikan script ini
# Sekian dan terima kasih :D
# Facebook : http://facebook.com/djsooch
#-----------------------------------------------------#
?><head>
<title>
Pubiway Admin Panel Site
</title>
<link rel="stylesheet" type="text/css" href="http://pubiway.xtgem.com/pubiway.css" media="all,handheld"/>
<link rel="shortcut icon" href="http://pubiway.xtgem.com/favicon.ico">
</head>
<?
require ('pubiway.php');
$adminpass = $set[pasword];
if (isset($_GET['pass'])){
$pass = $_GET['pass'];
} else {
$pass = '';
}
$title="Admin panel";

$a = $_GET['a'];
switch($a){
case "login":
echo '<div class="menu">
<center>';
$m = $_GET['m'];
switch($m){
case "panel":
$auth = $_POST['auth'];
if (empty($auth)){
echo 'LO SIAPA!????<br/>
&raquo; <a href="admin.php">Kembali</a><br/>';
}
else if ($auth !== $adminpass){
echo 'Password salah !!<br/>
&raquo; <a href="admin.php?a=login">Kembali</a><br/>';
} else {
echo 'Login sukses !!<br/>
&raquo; <a href="admin.php?pass='.$adminpass.'">Ke depan</a><br/>';
}
break;
default:
echo '<form action="admin.php?a=login&amp;m=panel" method="post">
Masukkan Password :<br/>
<input type="password" name="auth" value=""><br/>
<input type="submit" value="Login">
</div></form>';
break;
}
echo '</center>
</div>';
break;
//Edit data
case "edit":
echo '<div class="error">';
if ($pass !== $adminpass){
echo 'Khusus admin';
} else {
$file = 'pubiway.php';

$e = $_GET['e'];
switch($e){
case "simpan":
$buka = fopen($file, 'w');
$konten='<?
$set[pasword]='.'"'."$_REQUEST[satu]".'";
$set[judul]='.'"'."$_REQUEST[judul]".'";
$set[judul2]='.'"'."$_REQUEST[judul2]".'";
$set[deskripsi]='.'"'."$_REQUEST[deskripsi]".'";
$set[favicon]='.'"'."$_REQUEST[favicon]".'";
$set[link_token1]='.'"'."$_REQUEST[link_token1]".'";
$set[link_token2]='.'"'."$_REQUEST[link_token2]".'";
$set[nama_app1]='.'"'."$_REQUEST[nama_app1]".'";
$set[nama_app2]='.'"'."$_REQUEST[nama_app2]".'";

$set[promotor1]='.'"'."$_REQUEST[promotor1]".'";
$set[promotor2]='.'"'."$_REQUEST[promotor2]".'";
$set[promotor3]='.'"'."$_REQUEST[promotor3]".'";

$set[link1]='.'"'."$_REQUEST[link1]".'";
$set[nama_link1]='.'"'."$_REQUEST[nama_link1]".'";

$set[link2]='.'"'."$_REQUEST[link2]".'";
$set[nama_link2]='.'"'."$_REQUEST[nama_link2]".'";

$set[link3]='.'"'."$_REQUEST[link3]".'";
$set[nama_link3]='.'"'."$_REQUEST[nama_link3]".'";


$set[nama_admin]='.'"'."$_REQUEST[nama_admin]".'";

$set[css]='.'"'."$_REQUEST[css]".'";

$set[idapp1]='.'"'."$_REQUEST[idapp1]".'";
$set[idapp2]='.'"'."$_REQUEST[idapp2]".'";
$set[h]='.'"'."$_REQUEST[sembilan]".'";
$set[i]='.'"'."$_REQUEST[sepuluh]".'";
?>';
fwrite($buka, $konten);
fclose($buka);
echo '<div class="menu">Data situs telah berhasil di update</div>
<br/>
&raquo; <a href="admin.php?pass='.$set[pasword].'">Kembali</a><br/>';
break;
default:
echo '<form action="admin.php?a=edit&amp;e=simpan&amp;pass='.$pass.'" method="post"><div class="menu"> 

<span class="judul2">Pengaturan Umum</span><br>

1). Admin pasword :<br/>
<input type="text" name="satu" size="12" value="'.$set[pasword].'"><br/>

2). Judul Situs (di title):<br/>
<input type="text" name="judul" size="12" value="'.$set[judul].'"><br/>

3). Judul(dalam div):<br/>
<input type="text" name="judul2" size="12" value="'.$set[judul2].'"><br/>

4). Deskripsi Situs :<br/>
<input type="text" name="deskripsi" size="12" value="'.$set[deskripsi].'"><br/>

5). Favicon Situs :<br/>
<input type="text" name="favicon" size="12" value="'.$set[favicon].'"><br/>

6). Nama Admin:<br>
<input type="text" name="nama_admin" size="12" value="'.$set[nama_admin].'"><br>

7). Css Situs :<br/>
<input type="text" name="css" size="12" value="'.$set[css].'"><br/>Untuk css, kamu masukkan URL css nya, css yang boleh dipakai adalah css mywapblog, kalo kamu tidak tahu, kalau mau pakai yang bawaan, isi saja <b>site.css</b>
<br>
<span class="judul2">Pengaturan Token dan ID App</span><br>
#ID App fungsinya untuk menentukan token dari app mana saja yang boleh masuk ke situs kamu, disini saya menyediakan 2 menu. Jikalau kamu tidak mengerti, saya sarankan jangan ganti.
<br>
1). Link Token 1 (pakai http://) :<br>
<input type="text" name="link_token1" size="12" value="'.$set[link_token1].'"><br>

2). Nama App Link token 1 :<br>
<input type="text" name="nama_app1" size="12" value="'.$set[nama_app1].'"><br>

3). ID App Link token 1 :<br>
<input type="text" name="idapp1" size="12" value="'.$set[idapp1].'"><br>

4). Link Token 2 (pakai http://) :<br>
<input type="text" name="link_token2" size="12" value="'.$set[link_token2].'"><br>

5). Nama App Link token 2 :<br>
<input type="text" name="nama_app2" size="12" value="'.$set[nama_app2].'"><br>

3). ID App Link token 2 :<br>
<input type="text" name="idapp2" size="12" value="'.$set[idapp2].'"><br>


Kamu tetap dapat menambah nya dengan mengedit file <b>token.php</b>


</div>

<div class="hijaubiru">
<span class="judul2">Pengaturan Dev</span><br>
Cukup masukan <b>username</b> facebook nya saja...<br>
1). Dev 1 :<br/>
<input type="text" name="promotor1" size="12" value="'.$set[promotor1].'"><br/>
 
2). Dev 2 :<br/>
<input type="text" name="promotor2" size="12" value="'.$set[promotor2].'"><br/>


3). Dev 3 :<br/>
<input type="text" name="promotor3" size="12" value="'.$set[promotor3].'"><br/><hr>

</div>

<div class="hijaubiru">
<span class="judul2">Pengaturan Lainnya</span><br>
Jika kamu punya situs/link lain, kamu bisa tambahkan disini...<br>Ingat ya pakai <b>http://</b><br>

1). Link 1:<br/>
<input type="text" name="link1" size="12" value="'.$set[link1].'"><br/>

2). Nama Link 1:<br/>
<input type="text" name="nama_link1" size="12" value="'.$set[nama_link1].'"><br/>
<hr>

3). Link 2:<br/>
<input type="text" name="link2" size="12" value="'.$set[link2].'"><br/>

4). Nama Link 2:<br/>
<input type="text" name="nama_link2" size="12" value="'.$set[nama_link2].'"><br/>
<hr>

5). Link 3:<br/>
<input type="text" name="link3" size="12" value="'.$set[link3].'"><br/>

6). Nama Link 3:<br/>
<input type="text" name="nama_link3" size="12" value="'.$set[nama_link3].'"><br/>
<hr>



</div>






<input type="hidden" name="sepuluh" size="12" value="'.$set[i].'"><br/>
<input type="submit" class="judul3" value="SIMPAN"><br/>
</form>';




break;
} }
echo '</div>';
break;
default:
echo '<div class="main">';
if ($pass == $adminpass) {
echo '
<div class="birumuda"><div class="judul2">Admin Panel Site</div>
[+]	<a href="admin.php?a=edit&amp;pass='.$pass.'">Edit data situs</a><br>

[+]	<a href="edwin.php">Tutorial Penggunaan</a><br>

[-]	<a href="admin.php?">Keluar</a></div>';
} else {
echo '<div class="menu"><a href="admin.php?a=login">[LOGIN]</a> untuk masuk admin panel';
}
echo '</div>';
break;
//Penutup
}
include "footer2.php";
?>