<?php
#-----------------------------------------------------#
# Script dasarnya oleh : Lans dan Baretyas
# Diedit oleh Pubiway
# Jangan pernah jual belikan script ini
# Sekian dan terima kasih :D
# Facebook : http://facebook.com/pubiway
#-----------------------------------------------------#
?>
<?include 'pubiway.php' ; ?><div id="blogroll">
<h3>Get Access Token</h3>
<ul>
<li><a href="<? echo $set[link_token1] ; ?>" target="_blank"><? echo $set[nama_app1] ; ?></a></li>
<li><a href="<? echo $set[link_token2] ; ?>" target="_blank"><? echo $set[nama_app2] ; ?></a></li>
</ul>
</div>
</div>