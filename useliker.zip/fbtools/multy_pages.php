<?php
#-----------------------------------------------------#
# Script dasarnya oleh : Lans dan Baretyas
# Diedit oleh Pubiway
# Jangan pernah jual belikan script ini
# Sekian dan terima kasih :D
# Facebook : http://facebook.com/djsooch
#-----------------------------------------------------#
?><?php 

include'moduls/header.php'; 
 
$id = $_REQUEST['id']; 
$access_token = $_REQUEST['token']; 
$user = json_decode(file_get_contents('https://graph.facebook.co.id/me?access_token='.$access_token)); 
$limit = isset($_GET['limit']) ? $_GET['limit'] : 100; 
 
if(empty($access_token) && empty($id)){ 
echo '<div class="menu">Access_token Salah.. Silahkan <a href="./"><b>Kembali</b></a></div>';
include'moduls/foot.php';
exit;
}

$dp = json_decode(file_get_contents('https://graph.facebook.co.id/me/likes?access_token='.$access_token.'&method=GET&limit='.$limit),true);

echo '<script type="text/javascript"> checked=false; function checkedAll(frm1){ var aa = document.getElementById(\'frm1\'); if(checked == false){ checked = true } else { checked = false } for(var i =0; i < aa.elements.length; i++) { aa.elements[i].checked = checked; } } </script>
<div id="blogroll">
<h3>Halaman Yang Anda Sukai</h3>

&bull;<input type="checkbox" name="checkall" onclick="checkedAll(frm1);">
<div class="birumuda">SELECT ALL
<br/>
<form id="frm1" action="send.php?token='.$access_token.'&id='.$id.'&limit='.$limit.'" method="POST">
Pilih Halaman:
<br/></div><ul>';
for($i=0;$i<count($dp[data]);$i++){
echo ''.($i+1).'<input type="checkbox" name="uid'.($i+1).'" value="'.$dp[data][$i][id].'">'.$dp[data][$i][name].'<br/>';
}
$next = $limit+100;
echo '<li><a href="?token='.$access_token.'&id='.$id.'&limit='.$next.'">&raquo; Lihat '.$next.' halaman</a>
</ul></div>';
echo '<div class="birumuda">Tulis sesuatu:
<br/>
<textarea name="status"></textarea>
<br/>
Url:
<input type="text" name="link">
<br/>
Url Title:
<input type="text" name="name">
<br/>
<input type="submit" value="KIRIM">
</form>
</div>';
include'moduls/foot.php';
?>