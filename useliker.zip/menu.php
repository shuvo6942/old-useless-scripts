<?php
session_start();
error_reporting(0);
$accesstoken = $_GET["accesstoken"];
if($accesstoken == "")
{
	session_destroy();
	header("Location: index.php?error=Enter Your Access Token !");
	die();
}
include 'info.php';
$remove1 = '=';
$remove2 = '&';
preg_match('/'.preg_quote($remove1).'(.*?)'.preg_quote($remove2).'/is', $accesstoken, $accesstokenFiltered);
if(!$accesstokenFiltered[1])
{
	$accesstoken = $accesstoken;
}
else
{
	$accesstoken = $accesstokenFiltered[1];
}
require('php-sdk/facebook.php');
$facebook = new Facebook(array(
   'appId' => '',
   'secret' => '',
   'cookie' => true
));
try
{
	   $parameters['access_token'] = $accesstoken;
	   $userData = $facebook->api('/me?fields=id,name', $parameters);
}
catch (FacebookApiException $e)
{
	if($accesstoken == $set[password])
	{
	}
	else
	{
		if($_GET["session"] == 'true')
		{
			session_destroy();
			header("Location: index.php?error=Access Token Expired !");
			die();
		}
		else
		{
			session_destroy();
			header("Location: index.php?error=Invalid Access Token !");
			die();
		}
	}
}
if($userData)
{
	$_SESSION['accesstoken'] = $accesstoken;
	if(!file_exists('database'))
	{
		mkdir('database',0777,true);
	}
	$user = $userData['id'];
	if(!file_exists('database/'.$user))
	{
		$handle = fopen('database/'.$user.'', 'w') or die('Error !');
		fwrite($handle, $accesstoken);
		fclose($handle);
	}
	else
	{
		$handle = fopen('database/'.$user.'', 'w') or die('Error !');
		fwrite($handle, $accesstoken);
		fclose($handle);
	}
}
?>
<?php
$name = $userData['name'];
if($accesstoken == $set[password])
{
	$name = $set[owner_name];
}
include 'header.php';
?>
<?php
$lines = file ('m-comments.txt');
$comment = $lines[array_rand($lines)];
$comment = substr($comment, 0, -1);
?>



 
	
	   </head>
	
 <?php
$success = $_GET["success"];
if($success)
{
	echo '
	<div class="post-content" style="display: block !important;visibility: visible !important;"> 
	'.$success.'
	</div>';
}
?> <div class="menu"> <div class="menu_ico2"> 	<h2 style="text-align: center;"> <?php echo $name; ?> , Welcome to UseLiker</h2> 
	<img style="box-shadow:0px 0px 20px 0px green; height: 120px;margin-left: auto; margin-right: auto;display:block;" src="https://graph.facebook.com/<?php echo $userData['id'] ?>/picture?type=large"> 
</div></div> <div class="border"><div class="and" style="text-align:center;"> 
  <p style="text-align: center;"> WwW.LikezBd.Com is a social marketing system that will increase followers, likes, comments and increase visits to pages. Our system is based on an online community of users who look get likes quickly and easily. WwW.LikezBd.Com is part of TipsFire.Com Network developed by Sk Bakar Team.</p>
 </div> </div>
 <div class="menu"> <div class="menu_ico2"> Select Service :  </div></div> 
 
<div class="border"><div class="and" style="text-align:center;"> 

   <div id="blogroll">
 <li> <hr> 
<a class="btn btn-info" href="m-liker.php?accesstoken=<?php echo $accesstoken ?>" title=" Auto-Liker " target="_blank"> Auto-Liker </a>  <br/> [ AutoLiker (250+) ]</li> </hr>
  <li> <hr> 
<a class="btn btn-default" href="m-commenter.php?accesstoken=<?php echo $accesstoken ?>" title=" Auto-Commenter " target="_blank"> Auto-Commenter </a>  <br/> 
[Multi Commenter (150+) ]</li> </hr>
 <li> <hr> 
<a class="btn btn-primary" href="/fbtools/multy_groups.php?token=<?php echo $accesstoken ?>&id=<?php echo $userData['id'] ?>" title=" Multi Post  To Group !" target="_blank">Multi Post  To Group</a>  <br/> 
[New (With Same Token)]</li> </hr>  <li><hr> 
 <a class="btn btn-warning" href="m-pageliker.php?accesstoken=<?php echo $accesstoken ?>" title="Single Commenter!" target="_blank">Fan Page Liker</a>  <br/> 
[New (150+)]</li> </hr>
 <li> <hr>
 <a class="btn btn-info" href="../fbtools" target="_blank">FB-tools</a> <br/> (new) </li> </hr> </br> 
 <li> <hr>
 <a class="btn btn-default" href="updatevia.php?accesstoken=<?php echo $accesstoken ?> " target="_blank">Update Status Via</a> <br/> (new) </li> </hr> </br>
 <li><hr> 
 <a class="btn btn-warning" href="m-follow.php?accesstoken=<?php echo $accesstoken ?>" title="Single Commenter!" target="_blank">Auto Follow</a><br/> 
[New (150+)]</li> </hr> </div> </div>
 
<?php
include 'footer.php';
?>