<?php
include '../header.php';
?>
<div class="menu">
<h3>Auto Liker</h3>
<li><a href="/accesstoken.php"> Get Access Token </a></li>
<li><form method="GET" action="/m-liker.php">Access Token<br><input name="accesstoken"></li>
<li><center><input id="hidden" name="type" value="L"><br><input value="Log In" type="submit"></form></li>
</div>
<?php
include '../footer.php';
?>