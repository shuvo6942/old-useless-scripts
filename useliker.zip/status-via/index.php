<?php
include '../header.php';
?><div class="menu">
<h3>Update status via Fake Device</h3>
<li><a href="http://m.facebook.com/dialog/feed?_path=feed&app_id=567546596617367&redirect_uri=https%3A%2F%2Fwww.facebook.com" >Via Plz Like Kora Na !</a></li> 
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=172261202945270&redirect_uri=https%3A%2F%2Fwww.facebook.com" >Via BHUPEN Wapka WapMasters</a></li> 
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=412912448824915&redirect_uri=https%3A%2F%2Fwww.facebook.com" >Via Lumia 1020</a></li> 
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=183163795183494&redirect_uri=https%3A%2F%2Fwww.facebook.com" >Via Nokia Lumia 800</a></li> 
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=506078906127510&redirect_uri=https%3A%2F%2Fwww.facebook.com" >Sony Xperia SP</a></li> 
<li><a href="http://m.facebook.com/dialog/feed?_path=feed&app_id=190142277821672&redirect_uri=https%3A%2F%2Fwww.facebook.com" >Via Sony Xperia Tablet Z</a></b></li> 
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=172387106267280&redirect_uri=https%3A%2F%2Fwww.facebook.com" >MicroMax Canvas 4</a></li> 
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=198575483635750&redirect_uri=https%3A%2F%2Fwww.facebook.com" >Via PlayBoy</a></li> 
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=574350082603259&redirect_uri=https%3A%2F%2Fwww.facebook.com" >Android Smartphones  App</a></li> 
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=454959011267910&redirect_uri=https%3A%2F%2Fwww.facebook.com" >Via Vale Vale Like Kor Kela</a></li> 
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=393625914090739&redirect_uri=https%3A%2F%2Fwww.facebook.com" >Via My Broken Heart</a></li> 
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=345001415621885&redirect_uri=https%3A%2F%2Fwww.facebook.com" >Via My Mom Is My Angel</a></li> 
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=627605760584501&redirect_uri=https%3A%2F%2Fwww.facebook.com" >Via WhatsApp</a></li> 
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=217124265101869&redirect_uri=https%3A%2F%2Fwww.facebook.com" >Via WeChat</a></li> 
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=484544594972148&redirect_uri=https%3A%2F%2Fwww.facebook.com" >Via 2poni dhorise</a></li> 
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=175179605992060&redirect_uri=https%3A%2F%2Fwww.facebook.com" >Via Gold Flake Cigarette</a></li> 
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=193550517477603&redirect_uri=https%3A%2F%2Fwww.facebook.com" >Via Near Guwahati</a></li> <li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=681431141870533&redirect_uri=https%3A%2F%2Fwww.facebook.com" >Via Samsung Smart Tv</a></li> 
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=1397326543812096&redirect_uri=https%3A%2F%2Fwww.facebook.com"> Via Kom Dami Mobile</a></li> 
<li><a href="http://m.facebook.com/dialog/feed?app_id=5747726667&redirect_uri=https%3A%2F%2Fwww.facebook.com&to&display=touch" >Via Xbox  LIVE Social Experience</a></li> 
<li><a href="http://m.facebook.com/dialog/feed?_path=feed&app_id=224be7ed03ed1ba5e6194bf6a5ec13b8&redirect_uri=https%3A%2F%2Fwww.facebook.com&display=touch&to&from_login=1&m_sess=1dKlqw-dgO4-smF" >Via Anti BlackBerry</a></li> 
<li><a href="http://m.facebook.com/dialog/feed?_path=feed&app_id=7298ef02268857fa274b59d9d8b7bc3a&redirect_uri=https%3A%2F%2Fwww.facebook.com&display=touch&to&from_login=1&m_sess=1dKlqw-dgO4-smF" >Via BlackBerry Mobile Phone</a></li> 
<li><a href="http://m.facebook.com/dialog/feed?_path=feed&app_id=310677102401097&redirect_uri=https%3A%2F%2Fwww.facebook.com&display=touch&to&from_login=1&m_sess=1dKlqw-dgO4-smF" >Via Nokia 1202 Wifi</a></li> 
<li><a href="http://m.facebook.com/dialog/feed?_path=feed&app_id=607429995947347&redirect_uri=https%3A%2F%2Fwww.facebook.com&display=touch&to&from_login=1&m_sess=1dKlqw-dgO4-smF" >Via Girls Know Why</a></li> 
<li><a href="http://m.facebook.com/dialog/feed?_path=feed&app_id=1388810964667809&redirect_uri=https%3A%2F%2Fwww.facebook.com&display=touch&to&from_login=1&m_sess=1dKlqw-dgO4-smF" >Via Who Do We Think We Are</a></li> 
<li><a href="http://m.facebook.com/dialog/feed?_path=feed&app_id=602009296505385&redirect_uri=https%3A%2F%2Fwww.facebook.com&display=touch&to&from_login=1&m_sess=1dKlqw-dgO4-smF" >Via Yeah! That's Me!!!</a></li> 
<li><a href="http://m.facebook.com/dialog/feed?_path=feed&app_id=176675652509249&redirect_uri=https%3A%2F%2Fwww.facebook.com&display=touch&to&from_login=1&m_sess=1dKlqw-dgO4-smF" >Via Let Get Naughty</a></li> 
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=345629965470824&&redirect_uri=https%3A%2F%2Fwww.facebook.com&to&from_login=1&_rdr" >Via Sony Xperia Arc S</a></li> 
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=9400774cc79c2d29908dca53a23dc285&redirect_uri=https%3A%2F%2Fwww.facebook.com&display=touch&to&from_login=1&m_sess=1dKlqw-dgO4-smF&_rdr" >Via Nokia E72 Smartphone</a></li> 
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=195973253789544&redirect_uri=https%3A%2F%2Fwww.facebook.com&display=touch&to&from_login=1&m_sess=1dKlqw-dgO4-smF&_rdr" >Via Nokia E5 SmartPhone</a></li> 
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=b5ecc1c59bd8bde19ccd34d4ca572456&redirect_uri=https%3A%2F%2Fwww.facebook.com&display=touch&to&from_login=1&m_sess=1dKlqw-dgO4-smF&_rdr" >Via Nokia E66 Smartphone</a></li> 
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=204808116292172&redirect_uri=https%3A%2F%2Fwww.facebook.com&display=touch&to&from_login=1&m_sess=1dKlqw-dgO4-smF&_rdr" >Via Nokia E63 SmartPhone ®</a></li> 
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=101122399982503&redirect_uri=https%3A%2F%2Fwww.facebook.com&display=touch&to&from_login=1&m_sess=1dKlqw-dgO4-smF&_rdr" >Via Nokia e61 Smartphone</a></li> 
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=148608868582653&redirect_uri=https%3A%2F%2Fwww.facebook.com&display=touch&to&from_login=1&m_sess=1dKlqw-dgO4-smF&_rdr" >Via Lenovo A60 Smartphone</a></li> <li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=245182748836313&redirect_uri=https%3A%2F%2Fwww.facebook.com&display=touch&to&from_login=1&m_sess=1dKlqw-dgO4-smF&_rdr" >Via LG Optimus 2x Smartphone</a></li> 
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=388438864552808&&redirect_uri=https%3A%2F%2Fwww.facebook.com&to&from_login=1&_rdr" >Via Samsung Galaxy Y</a></li> 
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=375601822486485&&redirect_uri=https%3A%2F%2Fwww.facebook.com&to&from_login=1&_rdr" >Via Samsung Galaxy Tab 7.0</a></li> 
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=259000280822021&&redirect_uri=https%3A%2F%2Fwww.facebook.com&to&from_login=1&_rdr" >Via Blackbarry Curve 8520</a></li> 
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=+165486530216735&redirect_uri=https%3A%2F%2Fwww.facebook.com&display=touch&to&from_login=1&m_sess=1dKlqw-dgO4-smF&_rdr" >Via Nokia E7</a></li> 
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=164364423742283&redirect_uri=https%3A%2F%2Fwww.facebook.com&to& amp;display=touch&_rdr" > Via Bhupen hajong Official Page</a></li> 
<li><a href="https://m.facebook.com/dialog/feed?app_id=31d608d30292175bf7703149699ccb39&redirect_uri=https%3A%2F%2Fwww.facebook.com&to&display=touch&_rdr">Via NASA Satellite</a></li> 
<li><a href="http://m.facebook.com/dialog/feed?app_id=309437279094900&redirect_uri=https%3A%2F%2Fwww.facebook.com&to" > Via iPhone7</a></li> 
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=228389333903183&&redirect_uri=https%3A%2F%2Fwww.facebook.com&to&from_login=1&_rdr" >Via Nokia Xperia X8</a></li>
<li><a href="http://m.facebook.com/dialog/feed?app_id=266315686756783&redirect_uri=https%3A%2F%2Fwww.facebook.com&to" > Via Samsung Galaxy Tab</a></li> 
<li><a href="http://m.facebook.com/dialog/feed?app_id=41158896424&redirect_uri=https%3A%2F%2Fwww.facebook.com&to&display=touch" > Via HTC Sense</a></li> 
<li><a href="http://m.facebook.com/dialog/feed?app_id=7933375107&redirect_uri=https%3A%2F%2Fwww.facebook.com&to&display=touch" > Via Windows Phone (official)</a></li> 
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=305888176112290&redirect_uri=https%3A%2F%2Fwww.facebook.com&to&from_login=1" > Via Blackberry Playbook</a></li> 
<li><a href="http://m.facebook.com/dialog/feed?_path=feed&app_id=381529308566525&redirect_uri=https%3A%2F%2Fwww.facebook.com&to&from_login=1&client_id=381529308566525" > Via Samsung Galaxy SIII</a></li> 
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=309386465824881&redirect_uri=https%3A%2F%2Fwww.facebook.com" > Via Lumia 920</a></li> 
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=434618839942344&redirect_uri=https%3A%2F%2Fwww.facebook.com" > Via Lumia 510</a></li> 
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=489435827760505&redirect_uri=https%3A%2F%2Fwww.facebook.com" > Via Delhi</a></li> 
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=577063848994029&redirect_uri=https%3A%2F%2Fwww.facebook.com"> Via Sony Xperia Z</a></li> 
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=510353225679825&redirect_uri=https%3A%2F%2Fwww.facebook.com" > Via Blackberry Z10</a></li> 
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=574339092608669&redirect_uri=https%3A%2F%2Fwww.facebook.com" > Via Nokia 3310</a></li> 
<li><a href="https://m.facebook.com/dialog/feed?_path=feed&app_id=547423308630211&redirect_uri=https%3A%2F%2Fwww.facebook.com" > Via Samsung Galaxy S4</a></li> 
<li><a href="http://m.facebook.com/dialog/feed?app_id=105960999541322&redirect_uri=https%3A%2F%2Fwww.facebook.com&to&display=touch" > Via iPad Mini</a></li> 
<li><a href="http://m.facebook.com/dialog/feed?app_id=523785434303182&redirect_uri=https%3A%2F%2Fwww.facebook.com&to&display=touch" > Via Samsung Active Tab</a></li> 
<li><a href="http://m.facebook.com/dialog/feed?app_id=303851806334822&redirect_uri=https%3A%2F%2Fwww.facebook.com&to&display=touch" > Via Apple iPad 3</a></li> 
<li><a href="http://m.facebook.com/dialog/feed?app_id=114386822060164&redirect_uri=https%3A%2F%2Fwww.facebook.com&to&display=touch" > Via Apple iPad 4</a></li> 
<li><a href="http://m.facebook.com/dialog/feed?app_id=38125372145&redirect_uri=https%3A%2F%2Fwww.facebook.com&to&display=touch" > Via Sony Ericsson</a></li> 
<li><a href="http://m.facebook.com/dialog/feed?app_id=140881489259157&redirect_uri=https%3A%2F%2Fwww.facebook.com&to&display=touch" > Via Telegram</a></li> 
<li><a href="http://m.facebook.com/dialog/feed?app_id=110455835670222&redirect_uri=https%3A%2F%2Fwww.facebook.com&to&display=touch" > Via eye Phone</a></li> 
<li><a href="http://m.facebook.com/dialog/feed?app_id=242740155751069&redirect_uri=https%3A%2F%2Fwww.facebook.com&to&display=touch" > Via Microsoft Excel</a></li>
<li><a href="http://m.facebook.com/dialog/feed?app_id=211333348912523&redirect_uri=https%3A%2F%2Fwww.facebook.com&to&display=touch" > Via iPhon 5g</a></li> 
<li><a href="http://m.facebook.com/dialog/feed?app_id=173687282696461&redirect_uri=https%3A%2F%2Fwww.facebook.com&to&display=touch" > Via Toilet</a></li> </div>
<?php
include '../footer.php';
?> 