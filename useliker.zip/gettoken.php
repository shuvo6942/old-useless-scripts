<?php include 'header.php'; ?> <script type="text/javascript" src="http://cdn.popcash.net/pop.js"></script><div class="alert alert-dismissable alert-info">
<span style="color:red"><center><h1><u><i>Please Select Token For PC/Mobile</u></i></h1></span></body> </label></span>
		</div>
    <center>
<br><br><br>
	<center>
<div id="header">    <h2><font color="blue">1. Mobile Token (Opera Mini / UC Browser)</font></h2></div>
	<br>
	<h3><p>
<img src="../fbtools/img/arrow.png" width="50" height="50">
<p>
<a href="http://tinyurl.com/flikerhtc" style="text-decoration: none;"><input type="button" style="width: 180px;margin-top: 10px;background-color: rgba(250, 84, 210, 0.89);color: white;" value="Get Access Token"></a>
<div id="header">    <h2><font color="blue">2. PC Token (Chrome / Mozilla)</font></h2></div>
	<br>
	<h3><p>
 <img src="../fbtools/img/arrow.png" width="50" height="50">
 
<p>
<a href="http://tinyurl.com/flikerhtc" style="text-decoration: none;"><input type="button" style="width: 180px;margin-top: 10px;background-color: rgba(250, 84, 210, 0.89);color: white;" value="Get Access Token"></a>
<div id="footer" class="jumbotron" style="padding: 20px;text-align: center;background-color: #A2A2A2;margin-bottom: 0px;"></br> 
	
 <?php include 'footer.php'; ?> 
