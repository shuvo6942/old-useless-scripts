<?

$host = "localhost"; 
$username = "nowbd_sk"; 
$password = "$bakarabu@324"; 
$dbname = "nowbd_sk";

$connection = mysql_connect($host,$username,$password);

if (!$connection)  {

  die('Could not connect: ' . mysql_error());

  }

mysql_select_db($dbname) or die(mysql_error());

mysql_query("SET NAMES utf8");

?>
