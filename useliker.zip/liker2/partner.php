<div class="menu"><h3>Site Partner</h3>
<div class="list"><a href="http://TipsFire.Com">Best Forum Site</a></div>
<div class="list"><a href="http://likezbd.com">Auto Like server 2</a>
</div>
<div class="list"><a href="http://nowbd.cf">Fb Funny Apps</a></div>

<h3>Site Tools</h3>
<div class="list"><a href="http://likezbd.com/group-poster">multy post facebook </a></div>
<div class="list"><a href="vip.php">Vip Liker | 350+ Like</a></div><div class="list"><a href="ads.php">Download Script</a></div></div>
