<?php include 'header.php';?>
 <div class="menu">
	<h3>Follow These All Steps To Get Your Access Token .</h3>
    <div class="pesan">
    Your Access Token Is Used Like Others Posts !
    </div>


    <h3>::: Step 1</h3>
    
    <div class="list">Click Here <a href="/token.php" target="_blank">User Mobile</a> and Here <a href="/token2.php">User PC/UC</a>
    
</div>

    <h3>::: Step 2</h3>
    
    <div class="list">
    <img src="http://amarlike.com/images/1.png" alt="" width="181" height="241">
    <br/>
    Click OK > OK > OK .
    
</div>
    <h3>::: Step 3</h3>
    <div class="list">
    <img src="http://amarlike.com/images/2.png" alt="" width="181" height="241">
    <br/>
   <font color="gray">Copy Page info/address bar.<br>Your link looks like !!</font><br>
publish.nokia.com/login/_shahil__?#access_token=<font color="red">********* </font>&expires_in=0
<br>
<font color="red">*****</font> red star is your accss token.<br/>Access Token Looks like <br>
<font color="green"><u>CAAAAPJmB8ZBwB AMZCbdEdiGic QWZAtilSavT y1mUFxmMEZB A1EK009e dktYYGBsWyKA gdLV9tyJgx</u></font><br/>
    <i>Thank you</i>
</div></div>
<?php include 'footer.php';?>
