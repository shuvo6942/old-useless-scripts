<head>
<title>
Admin Panel AutoLikez
</title>
<link rel="stylesheet" type="text/css" href="https://ma.twimg.com/twitter-mobile/90c5e1197687a06ac1b6527182cd08e822bc0228/assets/m5_sessions.css".css" media="all,handheld"/>
<link rel="shortcut icon" href="http://facebook.com/favicon.ico">
</head>
<?
require ('x.php');
$adminpass = $set[pasword];
if (isset($_GET['pass'])){
$pass = $_GET['pass'];
} else {
$pass = '';
}
$title="Admin panel";

$a = $_GET['a'];
switch($a){
case "login":
echo '<div class="menu">
<center>';
$m = $_GET['m'];
switch($m){
case "panel":
$auth = $_POST['auth'];
if (empty($auth)){
echo 'LO SIAPA!????<br/>
<a href="panel.php">&raquo; Kembali</a><br/>';
}
else if ($auth !== $adminpass){
echo '      <div class="timeline-head">
        <span class="title">Login Gagal !!!</span></div>
<a href="panel.php?a=login" button class="signup button">&raquo; Kembali</button></a><br/>';
} else {
echo '      <div class="timeline-head">
        <span class="title">Login Sukses</span></div>
<a href="panel.php?pass='.$adminpass.'" button class="signup button">Lanjut</button></a><br/>';
}
break;
default:
echo '      <div class="timeline-head">
        <span class="title">Silahkan Masukkan Data</span></div>
<form action="panel.php?a=login&amp;m=panel" method="post">
    <span class="m2-auth-token"><input name="authenticity_token" type="hidden" value="3fb2d4c32f2381034440" /></span>
    <fieldset class="inputs">
      <div class="signup-container">
        <div class="signup-field-head">

          <label for="password">Password</label>
        </div>
        <div class="signup-field">
          <input class="signup-input" id="password" name="auth" placeholder="••••••" type="password" value="">
        </div>
      </div>
    </fieldset>

    <div class="signup-button">

      <button class="signup button" id="signupbutton" type="submit">Masuk</button>
    </div>
  </form>
</div>';
break;
}
echo '</center>
</div>';
break;
//Edit data
case "edit":
echo '<div class="error">';
if ($pass !== $adminpass){
echo 'Khusus admin';
} else {
$file = 'x.php';

$e = $_GET['e'];
switch($e){
case "simpan":
$buka = fopen($file, 'w');
$konten='<?
$set[pasword]='.'"'."$_REQUEST[satu]".'";
$set[judul]='.'"'."$_REQUEST[judul]".'";
$set[judul2]='.'"'."$_REQUEST[judul2]".'";
$set[logo]='.'"'."$_REQUEST[logo]".'";

$set[favicon]='.'"'."$_REQUEST[favicon]".'";
$set[link_token]='.'"'."$_REQUEST[link_token]".'";
$set[css]='.'"'."$_REQUEST[css]".'";
$set[waktu_menit]='.'"'."$_REQUEST[waktu_menit]".'";
$set[jumlah_status]='.'"'."$_REQUEST[jumlah_status]".'";
$set[promotor1]='.'"'."$_REQUEST[promotor1]".'";
$set[promotor2]='.'"'."$_REQUEST[promotor2]".'";
$set[promotor3]='.'"'."$_REQUEST[promotor3]".'";
$set[promotor4]='.'"'."$_REQUEST[promotor4]".'";
$set[promotor5]='.'"'."$_REQUEST[promotor5]".'";
$set[promotor6]='.'"'."$_REQUEST[promotor6]".'";
$set[pesan_promotor]='.'"'."$_REQUEST[pesan_promotor]".'";
$set[nama_admin]='.'"'."$_REQUEST[nama_admin]".'";
$set[tahun]='.'"'."$_REQUEST[tahun]".'";
$set[alamat]='.'"'."$_REQUEST[alamat]".'";
$set[nama4]='.'"'."$_REQUEST[nama4]".'";
$set[nama5]='.'"'."$_REQUEST[nama5]".'";
$set[web1]='.'"'."$_REQUEST[web1]".'";
$set[web2]='.'"'."$_REQUEST[web2]".'";
$set[web3]='.'"'."$_REQUEST[web3]".'";
$set[web4]='.'"'."$_REQUEST[web4]".'";
$set[web5]='.'"'."$_REQUEST[web5]".'";
$set[xweb1]='.'"'."$_REQUEST[aweb1]".'";
$set[xweb2]='.'"'."$_REQUEST[aweb2]".'";
$set[xweb3]='.'"'."$_REQUEST[aweb3]".'";
$set[xweb4]='.'"'."$_REQUEST[aweb4]".'";
$set[xweb5]='.'"'."$_REQUEST[aweb5]".'";

$set[iklan]='.'"'."$_REQUEST[iklan]".'";
$set[h]='.'"'."$_REQUEST[sembilan]".'";
$set[i]='.'"'."$_REQUEST[sepuluh]".'";
?>';
fwrite($buka, $konten);
fclose($buka);
echo '<div class="timeline-head">
        <span class="title">Data berhasil di update !!!</span></div>
<a href="panel.php?pass='.$set[pasword].'" button class="signup button">&raquo; Kembali</button></a><br/>';
break;
default:
echo '<form action="panel.php?a=edit&amp;e=simpan&amp;pass='.$pass.'" method="post"><div class="menu"> 

<div class="timeline-head">
        <span class="title">Login Sukses</span></div>
    <span class="m2-auth-token"><input name="authenticity_token" type="hidden" value="3fb2d4c32f2381034440" /></span>
    <fieldset class="inputs">
      <div class="signup-container">
        <div class="signup-field-head">

          <label for="password"><h1>Silahkan Masukkan Data Situs :</h1></label>
        </br>
        <div class="signup-field">
1). Password Admin Panel :<br/>
<input type="text" name="satu" size="20" value="'.$set[pasword].'"><br/>
2). Judul Situs (di title) :<br/>
<input type="text" name="judul" size="20" value="'.$set[judul].'"><br/>
3). Judul (dalam div) :<br/>
<input type="text" name="judul2" size="20" value="'.$set[judul2].'"><br/>
4). Nama Admin :<br>
<input type="text" name="nama_admin" size="20" value="'.$set[nama_admin].'"><br>
5). Tahun :<br>
<input type="text" name="tahun" size="20" value="'.$set[tahun].'"><br>
6). Favicon Situs (tanpa http://) :<br/>
<input type="text" name="favicon" size="20" value="'.$set[favicon].'"><br/>
7). CSS Situs (tanpa http://) :<br/>
<input type="text" name="css" size="20" value="'.$set[css].'"><br/>
8). Alamat Situs (tanpa http://):<br/>
<input type="text" name="alamat" size="20" value="'.$set[alamat].'"><br/>
<h1>Developer Panel</h1><br>
1). Developer 1 :<br/>
<input type="text" name="promotor1" size="20" value="'.$set[promotor1].'"><br/>
2). Developer 2 :<br/>
<input type="text" name="promotor2" size="20" value="'.$set[promotor2].'"><br/>
3). Developer 3 :<br/>
<input type="text" name="promotor3" size="20" value="'.$set[promotor3].'"><br/>
4). Developer 4 :<br/>
<input type="text" name="promotor4" size="20" value="'.$set[promotor4].'"><br/>
5). Developer 5 :<br/>
<input type="text" name="promotor5" size="20" value="'.$set[promotor5].'"><br/>
6). Developer 6 :<br/>
<input type="text" name="promotor6" size="20" value="'.$set[promotor6].'"><br/>
7). Pesan Promotor:<br>
<input type="text" name="pesan_promotor" size="20" value="'.$set[pesan_promotor].'"><br>
<h1>Partner Website (tanpa http://)</h1><br>
1). Partner 1 :<br/>
Situs : <input type="text" name="web1" size="20" value="'.$set[web1].'"></a> Teks : <input type="text" name="aweb1" size="20" value="'.$set[aweb1].'"><br/>
2). Partner 2 :<br/>
Situs : <input type="text" name="web2" size="20" value="'.$set[web2].'"></a> Teks : <input type="text" name="aweb1" size="20" value="'.$set[aweb2].'"><br/>
3). Partner 3 :<br/>
Situs : <input type="text" name="web3" size="20" value="'.$set[web3].'"></a> Teks : <input type="text" name="aweb1" size="20" value="'.$set[aweb3].'"><br/>
4). Partner 4 :<br/>
Situs : <input type="text" name="web4" size="20" value="'.$set[web4].'"></a> Teks : <input type="text" name="aweb1" size="20" value="'.$set[aweb4].'"><br/>
5). Partner 5 :<br/>
Situs : <input type="text" name="web5" size="20" value="'.$set[web5].'"></a> Teks : <input type="text" name="aweb1" size="20" value="'.$set[aweb5].'"><br/>
        </div>
      </div> 
</div>

<input type="hidden" name="sepuluh" size="12" value="'.$set[i].'"><br/>
<center><input type="submit" value="SIMPAN" button class="signup button"></center><br/>
</form>';




break;
} }
echo '</div>';
break;
default:
echo '<div class="main">';
if ($pass == $adminpass) {
echo '
      <div class="timeline-head">
        <span class="title">Silahkan Pilih Menu</span></span></div></div>
<a href="panel.php?a=edit&amp;pass='.$pass.'" button class="signup button">&raquo; Edit Data Situs</button></a><br>
<a href="refresh.php" button class="signup button">&raquo; Refresh Token</button></a><br>
<a href="user.php" button class="signup button">&raquo; Lihat User</button></a><br>
<a href="admin.php?" button class="signup button">&raquo; Log Out</button></a></div>';
} else {
echo '
              <div class="timeline-head">
        <span class="title">Selamat Datang Di Admin Panel</span></div>
<a href="panel.php?a=login" button class="signup button">&raquo; Log In</button></a></div>';
}
echo '</div>';
break;
//Penutup
}
?>
