<?php
#-----------------------------------------------------#
# Script Original Dibuat oleh : Bakar
# Script diedit oleh : Bakar
# Script Diedit kembali oleh : Pubiway 
# Lupakan saja kami, tidak perlu anda ingat.
# Ganti saja semua tulisan ini
# Sebagai rasa terima kasih mu
# Namun ingatlah...
# Jangan  pernah menjual script ini
# Saya tidak akan pernah menerima nya
# Karena saya tidak pernah mendapatkan 1 rupiah pun
# Dari penjualan script ini...
#-----------------------------------------------------#

session_start();
session_destroy();
 

header('Location: index.php');
?>
