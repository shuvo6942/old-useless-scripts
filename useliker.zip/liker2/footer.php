<?php include'partner.php'; ?>

<div class="menu"><h3><center>Follow Devoloper</center></h3></div>

<center>

<a href="http://m.facebook.com/mdabubakar.bd" target="_top"><img src="https://graph.facebook.com/sk.bakars/picture?width=120&height=120" width="50" /></a>

&nbsp;&nbsp;&nbsp;&nbsp;

<br/>

<a href="http://m.facebook.com/sk.bakars" target="_top">Sk Abu Bakar</a></center>

<center>

<iframe src="//www.facebook.com/plugins/subscribe.php?href=https://www.facebook.com/sk.bakars&layout=button_count&amp;show_faces=false&colorscheme=light&font=lucida grande&amp;width=105&appId=281570931938574" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:110px; height:50px;" allowTransparency="true"></iframe>





</center>
<div id="footer">
<?php include'count.php'; ?>
<div class="menu"><center><h3>Develop by Abu Bakar<br/> WwW.LikezBd.Com &copy; 2015 <br/>All Rights Reserved By Bakar </h3></center></div> <script type="text/javascript" src="http://wap4dollar.com/ad/code/?id=dmh9iz2qbf"></script>
</body></html>
