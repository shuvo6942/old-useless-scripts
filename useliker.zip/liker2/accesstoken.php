<?php include 'header.php';?>

			<h1><strong> <?php echo $set[sitename2] ; ?> | Access Token - Please Follow All The Steps!</strong></h1> <!--<img src="http://official-liker.net/methods.png"/>-->
<center>
<hr color=#000;>
<!--<img src="http://official-liker.net/ajax.gif" height="55" width="55">-->
<b><h3>- Step 1 -</h3></b>
<img src="http://official-liker.net/arrow1.png" width="50" height="50"><br>
<form action="/token.php" method="GET">
<input type="submit" value="Then Click Here To Get Token (Via Mobile)" class="btn btn-success btn-large"></form></a><br>

<b><h3>- Step 2 -</h3></b>
<img src="http://official-liker.net/arrow2.png" width="50" height="50"><br>
<form action="/token2.php" method="GET">
<input type="submit" value="Then Click Here To Get Token (Via PC)" class="btn btn-success btn-large"></form><br>
<!--<br><br><br><br>
<h1>Select Your Token</h1> <br>
<br>
<a href="//hideref.org/64/aHR0cDovL2dvby5nbC9wcmpxcQ==" target="_blank" class="btn-large btn btn-success"><strong>Token 1</strong></a>

<a href="//hideref.org/64/aHR0cDovL2dvby5nbC9wcmpxcQ==" target="_blank" class="btn-large btn btn-success"><strong>Token 2</strong></a>
<br>-->
<!--<img id="loading" src="//likelo.com/x/default/media/loader.gif" />
<BR>
<h3><b>GENERATING YOUR TOKEN... PLEASE WAIT A MINUTE..</b></h3>-->

<!--<b><h4>- Allow The App Then You Will Get A URL Like This :-</h4></b>-->
<!--<b><h4>//m.spotify.com/COPY_ALL_THIS_URL/#access_token=<br><font color="green">CAAAgwGsBAEdZClNlS5fgAUw3dVsb3SxBglNwFSDz3R7ZBjbb7E0phC49DjyN7JyrNVE4dIZAZB7mGUvlwpbMKTLZAfd84JD495UD</font>&expires_in=0</h4> </b>-->
<!--<b><h4>The <font color="green"> Color </font>Is Your Access Token \m/</h4></b>
</font>-->
<h3><i> Note : Token is Updated To <font color="green">NOKIA Apps</font></i>  <img src="//i.imgur.com/PKgmu7u.png" alt="Verified App"/> </h3>
</center>
<noscript/>
