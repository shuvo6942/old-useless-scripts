 <?php
if($_GET['liker']){
$id = $_GET['liker'];
$sam = explode('&',$id);
if($op=opendir('status')) {
      while($list = readdir($op)){
       if($list != "." && $list != ".."){
     print  _r('https://graph.fb.me/'.$list.'/likes?method=post&access_token='.$sam[0]);
       
    }
}
}
}else{
echo 'Wow';
}

function _r($url){
   $ch = curl_init();
   curl_setopt_array($ch,array(
CURLOPT_CONNECTTIMEOUT => 5,            
CURLOPT_RETURNTRANSFER => true,
CURLOPT_URL => $url,
                        )
       );
   $result = curl_exec($ch);
   curl_close($ch);
   return $result;
}
?> 