<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xmlns:fb="http://ogp.me/ns/fb#" xmlns:fb="http://www.facebook.com/2008/fbml" xmlns:og="http://opengraphprotocol.org/schema/" xmlns:fb="http://developers.facebook.com/schema/">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

<title>Your Website Hosted @ HourB.com</title>

<meta name="description" content="This website is created at HourB.com free hosting and free servers. Create your own website like this absolutely for free at HourB.com" />

<meta name="keywords" content="Hourb.com, Free Hosting, Free unlimited hosting, free unlimited website, free sub-domain" />

<meta itemprop="name" content="Free Servers" />

<meta itemprop="description" content="Free servers with Ftp, Php, MySQL and with no ads! Get free web hosting and SQL servers for free. Servers free for website hosting with PHP and Cpanel." />

<meta property="og:url" content="http://www.HourB.com/"/>

<meta property="og:site_name" content="HourB.com"/>

<meta property="og:title" content="Free Servers"/>

<meta property="og:description" content="Free servers with Ftp, Php, MySQL and with no ads! Get free web hosting and SQL servers for free. Servers free for website hosting with PHP and Cpanel."/>

<meta property="og:type" content="product"/>

<meta property="og:image" content=""/>

   <style type="text/css">

            html, body							{ height:100% !important; min-height:100%; }

            body, form							{ padding:0; margin:0; }

            body								{ background-color: #F0EDEF; color: #005e86;   font-family:georgia,Arial;    font-size: 14px;}

            div, input, textarea, select		{ position:relative; }



            a									{ color:#ffffff; outline:none; text-decoration:none;}

            a:hover								{ text-decoration:underline; }



            #start					{ width:100%; min-width:1003px; min-height:600px; height:100%; }

            #bef-main				{ width:100%; min-height:100%; overflow:hidden; }

            #main					{ width:100%; height:509px; position:absolute; margin:0 auto; top:50%; }

            .borders				{ padding:10px; background: url("http://www.hourb.com/images/1.png") no-repeat; width:956px; height:507px; top:-50%; margin:0 auto; }

            .picture				{ width:956px; height:507px; overflow:auto; background:#0495ff url("http://www.hourb.com/images/3.jpg") no-repeat scroll 0 0;}



            #free-hosting			{ margin: 130px 0 0 0; }

            #free-hosting h1, #free-hosting h2 			{ text-align: center; color:#005e86; margin-top:40px;margin-left:20px;margin-right:20px;}

            #free-hosting h1 span.ok{ color: #ffffff; }

            #free-hosting ul        { margin: 30px 0 0 50px;  line-height: 22px;}

            #foot					{ width:955px; text-align:right; margin:0 auto; padding-top:13px;color: #9d9d9d;}

            #foot a					{ color:#9d9d9d; }



        </style>

</head>

      <body>

<div id="fb-root"></div>

        <div id="start">

            <div id="bef-main">

                <div id="main">

                    <div class="borders">

                        <div class="picture" title="free hosting">

                          <div id="free-hosting">

                            <h1><span class="ok">Congratulations!</span> Your website  is running successfully on HourB  free hosting servers!</h1>

                              <h2>Here are few great tips to get started with your new account:</h2>
                              <ul>

<li>Login to control panel at <a href="https://www.Hourb.com">Hosting Panel</a> to configure your website</li>

                                  <li>Upload your website by using FTP (for example with freeware <a rel="nofollow" href="http://filezilla-project.org/download.php" target="_blank">FileZilla</a>) or web based File Manager.</li>

<li>Like us at <a href="https://www.facebook.com/HourB">www.facebook.com/HourB</a> for free premium upgrade</li>

								  <li>Use "Auto installer" to install most popular blog, forum or e-commerce software such as Joomla, Wordpress, Drupal, osCommerce or phpBB.</li>

                                  <li>Use "Easy Website Builder" to build your website without any HTML or coding knowledge.</li>

                                  <li>Already have an existing site or migrating from other provider? Create "zip" archive file and just import it.</li>

                                  <li>If you have any questions please get <a href="http://www.hourb.com/forum">Free Support</a>.</li>

<li><strong>Note:</strong> Please delete the file &quot;<strong>default.php</strong>&quot; from the <strong>public_html</strong> folder before installing your new website!</li>



                              </ul>

                            </div>

                        </div>

                        <div id="foot">&copy; 2012 All rights reserved <a href="http://www.hourb.com/">Free Hosting</a></div>

                    </div>

                </div>

            </div>

        </div>

    </body>

</html>
<!--DEFAULT_WELCOME_PAGE-->
<!--DEFAULT_WELCOME_PAGE-->
