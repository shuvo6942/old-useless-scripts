<?php include 'x.php' ;?>
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head title="Auto Like"><title><?php echo $set[title];?></title>
<link rel="apple-touch-icon-precomposed" href="<?php echo $set[favicon];?>" />
<!--pzbxeujvSvFchnQ48uKscsbKeRA-->

<meta name="description" content="Autolike Facebook I Get Free Auto Like For Post And Photo Instant" />
<meta name="keywords" content="useliker.tk,usefollow.tk,artlike.gq,Autolike Facebok,Autolike Photo,Autolike Status,Autolike Fans Page,Bot comment,Bot Like,Bom Like,Bomer Like,Big Like,Facebook,Google,Yahoo,Mywapblog,Bot koplak,Alexa,Ping,Twitter,pzbxeujvSvFchnQ48uKscsbKeRA,a93490b8b496266a655b" />
<meta name="HandheldFriendly" value="true" />
<meta name="referrer" content="default" id="meta_referrer" />
<meta http-equiv="expires"
content="0">
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="content-type" content="Text/html;charset=UTF-8">
<meta name="copyright" content="Copyright (c) 2015 LikezBd.Com ">
<meta name="author" content="Sk Abu Bakar">
<meta name="charset" content="UTF-8">
<meta name="distribution" content="Global">
<meta name="rating" content="General">
<meta name="robots" content="Autolike,hublaa,auto follower,autolike page,auto comment">
<meta name="revisit-after" content="3 Day">
<noscript><meta http-equiv="X-Frame-Options" content="DENY" /></noscript>
<link rel="stylesheet" href="<?php echo $set[css];?>" type="text/css">

</head><body onload="if(self.load) load();">

<div style="width:100%" id="header"><h1><a href="/"><font
color="red"> Auto </font> <font
color="green"> Like </font></a></h1>
<p class="description"><?php echo $set[sitename];?></div>
<div id="nav-top">
<a href="/"><b>Home</b></a> | <a href="http://tipsfire.com"><b>Blog</b></a> 
| <a href="http://facebook.com/sk.bakars"><b>Contact</b></a> 
| <a href="user.php">
             <b>Users</b></a></div>

<div class="menu"><h3><img src="https://ssl.gstatic.com/ui/v1/icons/mail/beluga/star.png"> Please Click</h3>
<div class="list"> <iframe src="http://www.facebook.com/plugins/subscribe.php?href=https%3A%2F%2Fwww.facebook.com%2Fsk.bakars&layout=button_
count&show_
faces=false&colorscheme=
light&font=lucida+grande&width=105&appId=281570931938574"
scrolling="no" frameborder="0"
style="border:none;
overflow:hidden;width:65px;height:58px;"allowTransparency="true"></iframe>
</div></div> 
