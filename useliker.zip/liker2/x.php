<?
$set[pasword]="";
$set[title]=" WwW.LikezBd.Com | Best Auto Like Bangladesh";
$set[sitename]=" WwW.LikezBd.Com | Free Auto Like Facebook";
$set[favicon]="http://stevendie.xtgem.com/images/4.png";
$set[css]="css/style.css";
$set[promotor1]="sk.bakars";
$set[promotor2]="";
$set[promotor3]="";
$set[promotor4]="";
$set[promotor5]="";
$set[promotor6]="";
$set[pesan_promotor]="Follow Developer";
$set[nama_admin]="Sk Abu Bakar";
$set[year]="2014";
$set[sitename2]="WwW.LikezBd.Com";
$set[web1]="vip.php";
$set[web2]="";
$set[web3]="";
$set[web4]="";
$set[web5]="";
$set[aweb1]="(Vip Auto Like)";
$set[aweb2]="(2)";
$set[aweb3]="(3)";
$set[aweb4]="(4)";
$set[aweb5]="(5)";
?>
