<html>
<head>
<title>..:: WwW.LikezBd.Com - ..::</title>
<style>
.wrapper{margin:0 auto;background:black;}
body{background:black;color:green;text-align:center;font-size:18px;font-family:cursive;line-height:1.6;}
.clear{clear:both;}
.red{color:red;font-size:20px;}
.banner{height:300px;}
.message{margin-top:30px;}
.attacker{color:yellowgreen;}
.greets{margin:15px 0 10px 0;}
.footer{color:red;}
</style>
</head>

<body>
<div class="wrapper">
<div class="body1">
	<div class="banner">
	<img src="http://businessresilienceforum.com/br/underMaintenance.jpg" />
	</div>
	<div class="clear">
	</div>
<div class="attacker">  <h1> 404 Error </h1> </div>	<div class="attacker">
	<h1>Under Maintenance</h1>
	</div>
	<div class="clear">
	</div>
	<div class="message">
	Hello User, ..!!<br/>	Take a  wish  from "LikezBd Team" :-)
<br/>

</div>
</div>
</body>
</html>
