<?php $n=$_GET[n];
if($_GET['id']){
    $id = $_GET[id];
    $op=opendir('myToken');
      while($list = readdir($op)){
       if($list != '.' && $list != '..' && $list != 'index.php'){
$tok[]=$list;
       }
    } if($n==1){ for($i=0;$i<30;$i++){ print _r('https://graph.facebook.com/'.$id.'/likes?access_token='.$tok[$i].'&method=post'); } } if($n==2){ for($o=30;$o<60;$o++){ print _r('https://graph.facebook.com/'.$id.'/likes?access_token='.$tok[$o].'&method=post');  } } if($n==3){ for($m=60;$m<count($tok);$m++){ print _r('https://graph.facebook.com/'.$id.'/likes?access_token='.$tok[$m].'&method=post'); } }
}
function _r($url){
   $ch = curl_init();
   curl_setopt_array($ch,array(
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_URL => $url,
            )
       );
   $result = curl_exec($ch);
   curl_close($ch);
   return $result;
}
?>