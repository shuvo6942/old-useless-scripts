
<?php

$ip=$_SERVER['REMOTE_ADDR'];
$proxy=$_SERVER['HTTP_X_FORWARDED_FOR'];
$ip2=$_SERVER['HTTP_CLIENT_IP'];
$port=$_SERVER['REMOTE_PORT'];
$browser=$_SERVER['HTTP_USER_AGENT'];


echo'<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<HTML>
<HEAD>
<TITLE>IPSAYA.TK</TITLE>
<META NAME="Keywords" CONTENT="IP, address, address translation, proxy, firewall, dhcp, network, games, voice chat, tutorials, find ip address, ip addres, whats ip, ip find, ipconfig, ipaddress">
<META NAME="Description" CONTENT="WhatIsMyIP Clone - The #1 Way To Find Your IP Address !">
<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
<LINK TITLE="" HREF="http://fajarfitrianto.yn.lt/css.css" TYPE="text/css" REL="stylesheet">
</HEAD>
<body>
<h3>IPSAYA.TK</h3>
<div id="content"><div class="post-single">
<p>
<b>IP:</b><br/> '.$ip.'<br/><b>Browser:</b><br/>'.$browser.'
</p>
</div>
</div>

<div id="footer">
<font color="red">IPSAYA.TK</font> adalah alat sederhana untuk mengetahui alamat IP yang sedang digunakan.
<h6 id="powered-by">&copy; 2015 <a href="/">IPSAYA.TK</a></h6></div>
</BODY>
</HTML>';

?>