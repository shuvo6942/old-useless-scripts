<?php
if(!empty($_GET['q'])){
if($_GET['act']=='music'){
$link=str_replace(' ', '-', $_GET['q']);
$link=strtolower($link);
$url='/carimp3-'.$link.'.xhtml';
}elseif($_GET['act']=='video'){
$links=str_replace(' ', '-', $_GET['q']);
$links=strtolower($links);
$url='/result/'.$links.'.xhtml';
}elseif($_GET['act']=='img'){
$urlku=str_replace(' ', '-', $_GET['q']);
$urlku=strtolower($urlku);
$url='/picture?q='.$urlku.'';
}else{
$url='/'; }}
header('location:'.$url.''); ?>
