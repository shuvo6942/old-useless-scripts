<?php 
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("X-XSS-Protection: 1; mode=block");
header("Last-Modified: " . gmdate("D, d M Y H:i:s")
. " GMT");
header("Strict-Transport-Security: max-age=31536000; includeSubDomains");
header("Cache-Control: no-store, no-cache, must-
revalidate");
header("Content-Security-Policy: default-src 'self' wapgit.ueuo.com ");
header("X-Content-Type-Options: nosniff");
header("Cache-Control: no-cache, no-store, must-revalidate");
header("X-Permitted-Cross-Domain-Policies: master-only");
header("Pragma: no-cache");
header("Connection: keep-alive");
header("X-Csrf-Token: i8XNjC4b8KVok4uw5RftR38Wgp2BFwql");
header("Age: 10");
header("ETag: 737060cd8c284d8af7ad3082f209582d");
header("Last-Modified: Tue, 15 Nov 2014 12:45:26 GMT
");
header("Public-Key-Pins: max-age=2592000; pin-
sha256=E9CZ9INDbd+2eRQozYqqbQ2yXLVKB9+xcprMF
+44U1g=;");
header("Server: Wapgit");
header("Set-Cookie: UserID=JohnDoe; Max-Age=3600;
Version=1");
header("X-Frame-Options: sameorigin");
header("Content-Type: text/html;charset=utf-8");
?>
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Mobile YouTube Video Downloader - WapGit</title>
<meta name="description" content="Free online youtube video downloader. Download any youtube videos for free on any platform such as linux or mac.">
<meta name="keywords" content="free youtube downloader,youtube downloader,wapgit downloader,Wapgit,video downloader,mobile downloader,youtube downloader">
<meta name="robot" content="index,follow">
<meta name="refresh" content="5">
<meta name="copyright" content="© 2016 WapGit">
<meta name="author" content="Wan Ahmad Aiman">
<meta name="generator" content="www.wapgit.ueuo.com">
<meta name="language" content="en">
<meta name="revisit-after" content="1 days">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="http://wapbit.com/bootstrap.min.css" rel="stylesheet">
<link href="http://wapbit.com/web.css" rel="stylesheet">
<script src="http://wapbit.com/jquery-1.10.2.min.js"></script>
<script src="http://wapbit.com/bootstrap.min.js"></script>
<style>.widget_advertisment{text-align:center}
.container{
    max-width:700px;
    margin:0 auto;
}

</style>
	
<style>
	#nav {
		width: 100%;
		float: left;
		margin: 0 0 3em 0;
		padding: 0;
		list-style: none;
		background-color: #eee;
		border-bottom: 1px solid #ccc; 
		border-top: 1px solid #ccc; }
	#nav li {
		float: left; }
	#nav li a {
		display: block;
		padding: 8px 15px;
		text-decoration: none;
		font-weight: bold;
		color: #2F4F4F;
		border-right: 1px solid #ccc; }
	#nav li a:hover {
		color: #c00;
		background-color: #fff; }
	#up {
		padding: 1em 10px;
		background-color:#2F4F4F;
		margin: 0;}

	
</style>




	
</head>
<body>
<?php
include 'anal.php'; ?>
<nav class="navbar navbar-fixed-top " >

<?php
$au = '22475';
$ref = '447182';
$auto = 'true';
$des ='NcIzcvKtNqAsxBNhtzVaSWLKmzncvGThnHtfHuLKMhsnTxvQakUy';

echo '<div id="up">
 
 
</div>
	
	<ul id="nav">
		<li><a href="http://wapgit.ueuo.com">Home</a></li>
		<li><a href="/d?au='.$au.'&refid='.$ref.'&auto='.$auto.'&des='.$des.'">DMCA</a></li>
		<li><a href="https://facebook.com/WapGit-1137665626273968/">Facebook</a></li>
	
	</ul>

</nav>
'; ?>
<?php
$ipad = $_SERVER['REMOTE_ADDR']?:($_SERVER['HTTP_X_
FORWARDED_FOR']?:$_SERVER['HTTP_CLIENT_IP']);
include 'vfunc.php';
$q=queryencode($_GET['q']);
if(!empty($_GET['q'])){
$title ='Download '.$q.' video';

$description ='Download '.$q.' video.';
}else{
$title  = 'Mobile YouTube Downloader | WapGit';

$description = 'WapGit is a free YouTube Downloader and Mobile YouTube Downloader.Download any YouTube videos any much as you want.We support on all platform such as linux,mac,unix,freebsd,fedora and more. ';
}


echo '<p style="margin-bottom:60px"></p>	
<div class="container">
<div style="margin:5px"></div>
<div class="widget_advertisment" style="padding:2px">
';
?>

<?php
/* AD */
echo '</div>
<div class="widget_searchform">
<form action="/" method="get" role="form" class="form-search">
<input type="hidden" value="browser" name="client">
<input type="hidden" name="ip" value="'.$ipad.'">
<div class="input-group"><input type="text" class="form-control" name="q" placeholder="Search videos" value="'.$q.'">
<span class="input-group-btn">
<input class="btn btn-default" name="ref" type="submit" value="Search"></input>
</span>
</div>
<center>
<input name="lang" type="radio" value="en" checked="checked">YouTube
</center
</form>
</div>
<div style="padding:2px">
</div>
';

echo '<div class="widget_facebook">

 </div>';
			
			
if(!empty($_GET['q'])){
   echo ' <div class="video_info_breadcrumb text-left">
        <ol class="breadcrumb">
Result for '.$q.'</ol></div>
 '; }
     else
  {
echo '<div class="video_info_breadcrumb text-left">
        <ol class="breadcrumb">
Most Popular</ol></div>
';
              }
if($_GET['q']){
$q = $_GET['q'];
} else {
$sam=ngegrab('https://gdata.youtube.com/feeds/api/charts/movies/most_recent?region=US');
}
$qu=$q;
$qu=str_replace(" ","+", $qu);
$qu=str_replace("-","+", $qu);
$qu=str_replace("_","+", $qu);
if(strlen($_GET['page']) >1){$yesPage=$_GET['page'];}
else{$yesPage='';}
$grab=ngegrab('https://www.googleapis.com/youtube/v3/search?key=AIzaSyBbshoPpKKEUko4Pnb7vBYUYRtLi0lcwjE&part=snippet&order=relevance&maxResults=15&q='.$qu.'&pageToken='.$yesPage.'&type=video');
$json = json_decode($grab);
$nextpage=$json->nextPageToken;
$prevpage=$json->prevPageToken;
if($json)
{
foreach ($json->items as $sam)
{
$link= $sam->id->videoId;
$name= $sam->snippet->title;
if(!empty($sam->snippet->description)){
$desc = $sam->snippet->description;
}else{
$desc = ''.$name.' - ...';
}
$channel = $sam->snippet->channelTitle;
 
$chid = $sam->snippet->channelId;
$date = dateyt($sam->snippet->publishedAt);
$sam = ngegrab('https://www.googleapis.com/youtube/v3/videos?key=AIzaSyBbshoPpKKEUko4Pnb7vBYUYRtLi0lcwjE&part=contentDetails,statistics&id='.$link.'');
$dt=json_decode($sam);
foreach ($dt->items as $dta){
$time=$dta->contentDetails->duration;
$views= $dta->statistics->viewCount;
$masa = format_time($time);
$lihat= number_format($views);
$suka= number_format($like);
$tak= number_format($dislike);
$like= $dta->statistics->likeCount;
$dislike= $dta->statistics->dislikeCount;   
}

echo '<div class="panel-body" style="margin:0px;padding: 0px;padding-top: 5px;"><div class="widget_videolist">
<ul class="media-list video_list">
<li class="media">
';
echo '<a class="pull-left img-thumbnail" style="padding: 1px;" href="/id/?v='.$link.'">
';
echo '<img title="'.$name.'" class="media-object" width="80" height="120" src="http://i.ytimg.com/vi/'.$link.'/default.jpg">
</a>
';
echo '<div class="media-body">
<h4 class="media-heading"><a href="/id/?v='.$link.'">'.$name.'</a></h4>
';
echo '<div><br/>';
echo '<span>'.$channel.'</span></div>'; 
echo '<div> ';
echo ''.$masa.'';
echo '</div> <div>'.$lihat.' views</div>';
echo '</div>
</li><hr/>
</ul>
</div>
</div>'; 

echo '<div class="widget_advertisment">';
?>
<?php
/* AD */
echo '</div>'; } }

if (strlen($nextpage)>1)
{
if (strlen($_GET['q'])>1)
{
echo '<div class="panel panel-default" style="margin:8px;padding: 0px;">';

echo '<div class="panel-heading text-left" style="text-align:center;"><a class="navCurrent" href="/video?q='.$_GET['q'].'&page='.$nextpage.'">Load More </a>';
}
else
{
echo '<div class="panel panel-default" style="margin:8px;padding: 0px;"><div class="panel-heading text-left" style="text-align:center;"> <a class="navCurrent" href="/video?q='.$q.'&page='.$nextpage.'">Load More</a>';
} }

echo ' 
</div></div></div> 
<br><center> 
 <script id="_wauabl"> var _wau = _wau || []; _wau.push([ "classic" , "b32vuvmptklj" , "abl" ]);
(function() {var s=document.createElement( "script" ); s.async= true ;
s.src= "http://widgets.amung.us/classic.js" ;
document.getElementsByTagName( "head" )[0].appendChild(s);
})(); </script></center><center><a href="http://www.beyondsecurity.com/vulnerability-scanner-verification/wapgit.ueuo.com"><img src="https://seal.beyondsecurity.com/verification-images/wapgit.ueuo.com/vulnerability-scanner-2.gif" alt="Website Security Test" border="0" /></a>
</center> <!-- OPENTRACKER START -->
<script type="text/javascript" defer="defer"
src="// script.opentracker.net/?site=wapgit.ueuo.com "></
script>
<!-- OPENTRACKER END --> <script src="http://t1.extreme-dm.com/f.js"
id="eXF-sexger-0" async defer></script>
</body></html>';
?> 
<?php
if(!empty($_GET['q'])){
if($_GET['act']=='music'){
$link=str_replace(' ', '-', $_GET['q']);
$link=strtolower($link);
$url='/carimp3-'.$link.'.xhtml';
}elseif($_GET['lang']=='en'){
$links=str_replace(' ', '+', $_GET['q']);
$links=strtolower($links);
$url='/q/file/cloud/crypt/116181992937177492731118902738937918378199119377283898371828/client/7719937/'.$links.'.aspx';
}elseif($_GET['act']=='img'){
$urlku=str_replace(' ', '-', $_GET['q']);
$urlku=strtolower($urlku);
$url='/picture?q='.$urlku.'';
}else{
$url='/'; }}
header('location:'.$url.''); ?>