<?php

echo' <link href="http://wapbit.com/bootstrap.min.css" rel="stylesheet">
<link href="http://wapbit.com/web.css" rel="stylesheet">
<script src="http://wapbit.com/jquery-1.10.2.min.js"></script>
<script src="http://wapbit.com/bootstrap.min.js"></script>
<style>.widget_advertisment{text-align:center}
.container{
    max-width:700px;
    margin:0 auto;
}

</style>
	
<style>
	#nav {
		width: 100%;
		float: left;
		margin: 0 0 3em 0;
		padding: 0;
		list-style: none;
		background-color: #eee;
		border-bottom: 1px solid #ccc; 
		border-top: 1px solid #ccc; }
	#nav li {
		float: left; }
	#nav li a {
		display: block;
		padding: 8px 15px;
		text-decoration: none;
		font-weight: bold;
		color: #2F4F4F;
		border-right: 1px solid #ccc; }
	#nav li a:hover {
		color: #c00;
		background-color: #fff; }
	#up {
		padding: 1em 10px;
		background-color:#2F4F4F;
		margin: 0;}

	
</style>
<div class="nganan"><div class="title2">Video Terkait</div>';
echo'<table class="otable"><tbody>';
$grab=ngegrab('https://www.googleapis.com/youtube/v3/search?key=AIzaSyBbshoPpKKEUko4Pnb7vBYUYRtLi0lcwjE&part=snippet&maxResults=8&relatedToVideoId='.$id.'&type=video');
$json = json_decode($grab);
if($json)
{
foreach($json->items as $hasil) 
{
$name = $hasil->snippet->title;
$link = $hasil->id->videoId;
$tgl = $hasil->snippet->publishedAt;
$date = dateyt($tgl);
$des = $hasil->snippet->description;
$chid = $hasil->snippet->channel;
$sam=ngegrab('https://www.googleapis.com/youtube/v3/videos?key=AIzaSyBbshoPpKKEUko4Pnb7vBYUYRtLi0lcwjE&part=contentDetails,statistics&id='.$link.'');
$dt=json_decode($sam);
foreach ($dt->items as $dta)
{
$durasi = $dta->contentDetails->duration;
$duration = $durasi;

$masa = format_time($durasi);

$duration = str_replace('PT', '', $duration);
$duration = str_replace('H', ' hour ', $duration);
$duration = str_replace('M', ' min ', $duration);
$duration = str_replace('S', ' sec ', $duration);
}
echo '<div class="panel-body" style="margin:0px;padding: 0px;padding-top: 5px;"><div class="widget_videolist">
<ul class="media-list video_list">
<li class="media">
';
echo '<a class="pull-left img-thumbnail" style="padding: 1px;" href="/id/?v='.$link.'">
';
echo '<img title="'.$name.'" class="media-object" width="80" height="120" src="http://i.ytimg.com/vi/'.$link.'/default.jpg">
</a>
';
echo '<div class="media-body">
<h4 class="media-heading"><a href="/id/?v='.$link.'">'.$name.'</a></h4>
';
echo '<div><br/>';
echo '<span>'.$chid.'</span></div>'; 
echo '<div> ';
echo ''.$masa.'';
echo '</div> <div>'.$lihat.' views</div>';
echo '</div>
</li><hr/>
</ul>
</div>
</div>'; 
}

?>