<?php 
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("X-XSS-Protection: 1; mode=block");
header("Last-Modified: " . gmdate("D, d M Y H:i:s")
. " GMT");
header("Strict-Transport-Security: max-age=31536000; includeSubDomains");
header("Cache-Control: no-store, no-cache, must-
revalidate");
header("Content-Security-Policy: default-src 'self' wapgit.ueuo.com");
header("X-Content-Type-Options: nosniff");
header("Cache-Control: no-cache, no-store, must-revalidate");
header("X-Permitted-Cross-Domain-Policies: master-only");
header("Pragma: no-cache");
header("Connection: keep-alive");
header("X-Csrf-Token: i8XNjC4b8KVok4uw5RftR38Wgp2BFwql");
header("Age: 10");
header("ETag: 737060cd8c284d8af7ad3082f209582d");
header("Last-Modified: Tue, 15 Nov 2014 12:45:26 GMT
");
header("Public-Key-Pins: max-age=2592000; pin-
sha256=E9CZ9INDbd+2eRQozYqqbQ2yXLVKB9+xcprMF
+44U1g=;");
header("Server: Wapgit");
header("Set-Cookie: UserID=JohnDoe; Max-Age=3600;
Version=1");
header("X-Frame-Options: sameorigin");
header("Content-Type: text/html;charset=utf-8");
?>
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Download in 3GP,MP4 and MP3 - WapGit</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
 <meta name="viewport " content="width=device-width, initial-scale=1">
<link href="http://wapbit.com/bootstrap.min.css" rel="stylesheet">
<link href="http://wapbit.com/web.css" rel="stylesheet">
<script src="http://wapbit.com/jquery-1.10.2.min.js"></script>
<script src="http://wapbit.com/bootstrap.min.js"></script>
<style>.widget_advertisment{text-align:center}
.container{
    max-width:700px;
    margin:0 auto;
}

</style>
	
<style>
	#nav {
		width: 100%;
		float: left;
		margin: 0 0 3em 0;
		padding: 0;
		list-style: none;
		background-color: #eee;
		border-bottom: 1px solid #ccc; 
		border-top: 1px solid #ccc; }
	#nav li {
		float: left; }
	#nav li a {
		display: block;
		padding: 8px 15px;
		text-decoration: none;
		font-weight: bold;
		color: #2F4F4F;
		border-right: 1px solid #ccc; }
	#nav li a:hover {
		color: #c00;
		background-color: #fff; }
	#up {
		padding: 1em 10px;
		background-color:#2F4F4F;
		margin: 0;}

	
</style>
</head>
<?php
$id = $_GET['v'];
include 'vfunc.php';
$yf=json_decode(ngegrab('https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails,statistics&id='.$id.'&maxResults=1&key=AIzaSyBbshoPpKKEUko4Pnb7vBYUYRtLi0lcwjE'),true);
$name=$yf[items][0][snippet][title];
$q=$name;
$tgl=$yf[items][0][snippet][publishedAt];
$date=dateyt($tgl);
$des=$yf[items][0][snippet][description];

$channel=$yf[items][0][snippet][channelTitle];
$viewCount=$yf[items][0][statistics][viewCount];
$lihat = number_format($viewCount);
$likeCount=$yf[items][0][statistics][likeCount];
$dislikeCount=$yf[items][0][statistics][dislikeCount];
$durasi =$yf[items][0][contentDetails][duration];
$masa = format_time($durasi);
$suka = number_format($likeCount);
$tak = number_format($dislikeCount);

$duration = str_replace('PT', '', $duration);
$duration = str_replace('H',' : ', $duration);
$duration = str_replace('M',' : ', $duration);
$duration = str_replace('S',' ', $duration);
$kata = ''.$name.''; 
$kate = preg_replace('/[^a-z0-9_\-\.]/i','-',$name);
$kate = str_replace('.', '-', $kate);
$kate = str_replace('---', '-', $kate);
$kate = str_replace('--', '-', $kate);
$value = '4';
if (str_word_count($kata) > $value)
{
$limit = implode(' ', array_slice(explode(' ', $kata), 0, $value)).'';
$lmit = preg_replace('/[^a-z0-9_\-\.]/i','-',$limit);
$lmit = str_replace('---', '-', $lmit);
$lmit = str_replace('--', '-', $lmit);
$lmit = str_replace(' ', '-', $lmit);
$lmit = str_replace('.', '-', $lmit);
}
else
{
$limit = $kata;
$lmit = str_replace('  ', '-', $limit);
}
define('TITLE','Download '.$name.' video - WapGit');
$title = 'Download '.$name.'';
$get_video = file_get_contents('http://YOUR_SITE/dlvideos.php?id='.$id);
$description = ''.$des.''; 
echo '<body>
<nav class="navbar navbar-fixed-top">

<div id="up">

</div>
	
	<ul id="nav">
		<li><a href="http://wapgit.ueuo.com">Home</a></li>
		<li><a href="/d?au=1137628092&ref=lang&auto=none&des=552673589262961893729032993725436388290362235526">DMCA</a></li>
		<li><a href="https://facebook.com/WapGit-1137665626273968/ ">Facebook</a></li>
	
	</ul>

</nav>';

include 'anal.php';
echo '<p style="margin-bottom:60px"></p>	
<div class="container">
<div style="margin:5px"></div>
<div class="widget_advertisment" style="padding:2px">'; ?>

<?php
$ipad = $_SERVER['REMOTE_ADDR']?:($_SERVER['HTTP_X_
FORWARDED_FOR']?:$_SERVER['HTTP_CLIENT_IP']);
echo '</div>
<div class="widget_searchform">
<form action="/" method="get" role="form" class="form-search">
<input type="hidden" value="browser" name="client">
<input type="hidden" name="ip" value="'.$ipad.'">
<div class="input-group">
<input type="text" class="form-control" name="q" placeholder="Search videos">
<span class="input-group-btn">
<input class="btn btn-default" type="submit" name="ref" value="Search"></input>
</span>
</div>
</div>
<center>
<input name="lang" type="radio" value="en" checked="checked">YouTube
</center>
</form>
<br/>
<div style="padding:2px">
</div>
<div class="widget_facebook">';

			/* Like box */

echo '</div>  <div class="video_info_breadcrumb text-left">
        <ol class="breadcrumb">
  <a href="/">Home</a>
  <li class="active">'.$name.'</ol>
    </div>';
    
echo '<div style="margin:1px 5px 5px 5px;text-align:center;display:block">
<br><hr><b>Share us</b><br>
<hr>
<a href="http://facebook.com/share.php?u=http://wapgit.ueuo.com/id/?v='.$id.'" rel="nofollow" target="_blank">
<img alt="share" src="/image/fb.png" width="40" /> 
</a> 
<a href="https://twitter.com/intent/tweet?url=http://wapgit.ueuo.com/id/?v='.$id.'" target="_blank"> 
<img alt="tweet" src="/image/tw.png"  width="40" /> 
</a>';

echo '<a href="https://plus.google.com/share?url=http://wapgit.ueuo.com/id/?v='.$id.'" rel="nofollow" target="_blank">
<img alt="G+" src="/image/gp.png" width="40">
</a> 
<a href="whatsapp://send?text=Download '.$name.' Video at http://wapgit.ueuo.com/id/?v='.$id.'" target="_blank">
<img alt="Wa" src="/image/wa.png" width="40" /> 
</a>';

echo '<a href="http://line.me/R/msg/text/?Download '.$name.' Video at http://wapgit.ueuo.com/id/?v='.$id.'" target="_blank">
<img alt="line" src="/image/line.png"  width="40" /> 
</a>
</div>';

echo '<center style="background:#000;padding:2px">
<iframe src="http://www.youtube.com/embed/'.$id.'?autoplay=1" frameborder="0" width="100%" height="100%" allowfullscreen></iframe>
</center>
<center style="background:#000">

<table border="0">
<tr>
<td>
<img src="http://i.ytimg.com/vi/'.$id.'/1.jpg" width="100" height="100">

</td>
<td>
<img src="http://i.ytimg.com/vi/'.$id.'/2.jpg" width="100" height="100">
</td>
<td>
<img src="http://i.ytimg.com/vi/'.$id.'/3.jpg" width="100" height="100">
</td>
</tr></table></center>';

echo '<center style="margin:3px">'; ?>

<?php


echo '</center>

   <div class="text-left video_text">
        <table class="table table-bordered">
        <tr><td colspan="2"><b>Video Description</b></td></tr>
                        <tr><td colspan="2">'.$des.'</td></tr>
<tr>
                        <td><b>Duration</b><td>'.$masa.'</td></tr> 
<tr>
                        <td><b>Views</b></td><td>'.$lihat.'</td></tr> 
<tr>
                        <td><b>Uploaded</b></td><td>'.$tgl.'</td></tr> 

<tr>
                        <td><b>Likes</b></td><td>'.$suka.'</td></tr> 

<tr>
                        <td><b>Dislikes</b></td><td>'.$tak.'</td></tr> 
<tr>
                        <td><b>Uploader</b></td><td><a href="/?client=browser&ip='.$ipad.'&q='.$channel.'&ref=Search&lang=en">'.$channel.'</td></tr> 


   </table>
    </div>';


echo '<div style="margin:1px 5px 5px 5px;text-align:center;display:block">
 <br><hr><b>Share us</b><br>
<hr>
<a href="http://facebook.com/share.php?u=http://wapgit.ueuo.com/id/?v='.$id.'" rel="nofollow" target="_blank">
<img alt="share" src="/image/fb.png" width="40" /> 
</a> 
<a href="https://twitter.com/intent/tweet?url=http://wapgit.ueuo.com/id/?v='.$id.'" target="_blank"> 
<img alt="tweet" src="/image/tw.png"  width="40" /> 
</a> 
<a href="https://plus.google.com/share?url=http://wapgit.ueuo.com/id/?v='.$id.'" rel="nofollow" target="_blank">
<img alt="G+" src="/image/gp.png" width="40">
</a>  
<a href="whatsapp://send?text=Download '.$name.' Video at http://wapgit.ueuo.com/id/?v='.$id.'" target="_blank">
<img alt="Wa" src="/image/wa.png" width="40" /> 
</a>  
<a href="http://line.me/R/msg/text/?Download '.$name.' Video at http://wapgit.ueuo.com/id/?v='.$id.'" target="_blank">
<img alt="line" src="/image/line.png"  width="40" /> 
</a>
</div>
<center style="margin:3px">';?>

<?php


echo '</center>


<div class="panel panel-default" style="margin:0px;padding: 0px;">
							<div class="panel-heading text-left" style="">Download Links</div></div>';
						
echo ''.$get_video.' <div class="panel-body" style="margin:0px;padding: 0px;padding-top: 5px;"><div class="widget_categorylist">
<div class="list-group" style="text-align:left"> 
<a class="list-group-item" href="http://youtubeinmp3.com/fetch/?video=http://youtube.com/watch?='.$_GET['id'].'">Download as mp3
</a>            
</div>
</div>
</div><hr> <p align="left">Please refresh this page if download link not available</p><hr>';

   
if(!empty($_GET['q'])){
if($_GET['act']=='music'){
$link=str_replace(' ', '-', $_GET['q']);
$link=strtolower($link);
$url='/carimp3-'.$link.'.xhtml';
}elseif($_GET['lang']=='en'){
$links=str_replace(' ', '+', $_GET['q']);
$links=strtolower($links);
$url='/q/file/cloud/crypt/116181992937177492731118902738937918378199119377283898371828/client/7719937/'.$links.'.aspx';
}elseif($_GET['act']=='img'){
$urlku=str_replace(' ', '-', $_GET['q']);
$urlku=strtolower($urlku);
$url='/picture?q='.$urlku.'';
}else{
$url='/'; }}
header('location:'.$url.'');

echo '<div  style="text-align:center; margin:2px;">'; ?>
<?php
echo '</div>';
include 'related.php';
echo '
</body></html>'; ?>