﻿<?php
error_reporting(0);
         //*****************************\\ 
        //******Editor By_Ara***********\\
       //**http://facebook.com/ara.ajj***\\
      //*********************************\\
// Dilararang mengubah tulisan ini jika anda masih merasa manusia :p
$fileAccess = file('my_token.txt');
$access_token=$fileAccess[0];

if(file_exists('like_saja_log')){
$log=json_encode(file('like_saja_log'));
}else{
$log='';
}

$me = json_decode(auto('https://graph.facebook.com/me?access_token='.$access_token.'&fields=id'),true);
$stat=json_decode(auto('https://graph.facebook.com/me/home?fields=id,message,created_time,from,comments,type&access_token='.$access_token.'&offset=0&limit=30'),true);

for($i=1;$i<=count($stat[data]);$i++){
if(!ereg($stat[data][$i-1][id],$log)){
if($stat[data][$i-1][from][id] != $me[id]){
$x=$stat[data][$i-1][id].'  ';
$y = fopen('like_saja_log','a');
fwrite($y,$x);
fclose($y);

$tes=auto('https://graph.facebook.com/'.$stat[data][$i-1][id].'/likes?access_token='.$access_token.'&method=post');
echo' '.$tes.' ' ;
}
}
}

function auto($url){
$curl = curl_init();
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($curl, CURLOPT_URL, $url);
$ch = curl_exec($curl);
curl_close($curl);
return $ch;
}


?>