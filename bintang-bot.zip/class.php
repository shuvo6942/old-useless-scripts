<?
/*
Atom and RSS Extractor and Displayer
(c) 2009  Borne Wap
*/

$Borne_Content = array();
$Borne_Style ="p";
$Borne_Date_Font = "size='-1'";

function RSS_Tags($item, $type)
{
global $Borne_Content;

$y = array();
$y["title"] = $item->getElementsByTagName("title")->item(0)->firstChild->data;
$y["link"] = $item->getElementsByTagName("link")->item(0)->firstChild->data;
$y["description"] = $item->getElementsByTagName("description")->item(0)->firstChild->data;

$tnl = $item->getElementsByTagName("pubDate");
if($tnl->length == 0)
{
$tnl = $item->getElementsByTagName("lastBuildDate");
}
if($tnl->length != 0)
{
$tnl =$tnl->item(0)->firstChild->data;
}
else
$tnl = true;

$y["updated"] = $tnl;
$y["type"] = $type;

array_push($Borne_Content, $y);
}


function RSS_Channel($channel)
{
global $Borne_Content;

$items = $channel->getElementsByTagName("item");


RSS_Tags($channel, 0);

foreach($items as $item)
{
RSS_Tags($item, 1);
}
}

function RSS_Retrieve($url)
{
global $Borne_Content;

$doc  = new DOMDocument();
$doc->load($url);

$channels = $doc->getElementsByTagName("channel");

$Borne_Content = array();

foreach($channels as $channel)
{
RSS_Channel($channel);
}

return ( count($Borne_Content) > 0);
}



function Atom_Tags($item)
{
global $Borne_Content;

$y = array();
$y["title"] = $item->getElementsByTagName("title")->item(0)->firstChild->data;
$y["link"] = $item->getElementsByTagName("link")->item(0)->getAttribute("href");
$y["description"] = $item->getElementsByTagName("summary")->item(0)->firstChild->data;
$y["updated"] = $item->getElementsByTagName("updated")->item(0)->firstChild->data;
$y["type"] = 1;

array_push($Borne_Content, $y);
}

function Atom_Feed($doc)
{
global $Borne_Content;

$entries = $doc->getElementsByTagName("entry");

if($entries->length == 0) return false;


$y = array();
$y["title"] = $doc->getElementsByTagName("title")->item(0)->firstChild->data;
$y["link"] = $doc->getElementsByTagName("link")->item(0)->getAttribute("href");
$y["description"] = $doc->getElementsByTagName("subtitle")->item(0)->firstChild->data;
$y["updated"] = $doc->getElementsByTagName("updated")->item(0)->firstChild->data;
$y["type"] = 0;

array_push($Borne_Content, $y);


foreach($entries as $entry)
{
Atom_Tags($entry);         }

return true;
}


function Atom_Retrieve($url)
{
global $Borne_Content;

$doc  = new DOMDocument();
$doc->load($url);

$Borne_Content = array();

return Atom_Feed($doc);

}



function Borne_Display($url, $ukuran = 25, $chanopt = false, $descopt = false, $dateopt = false)
{
global $Borne_Content;
global $Borne_Style;
global $Borne_Date_Font;

$buka = false;
$halaman = "";

if(Atom_Retrieve($url) === false)
{
if(RSS_Retrieve($url) === false)
{
return "Belum ada data...";
}
}
if($ukuran > 0)
{
$ukuran += 1;
$terbaru = array_slice($Borne_Content, 0, $ukuran);
}

foreach($terbaru as $artikel)
{
$type = $artikel["type"];

if($type == 0)
{
if($chanopt != true) continue;
if($buka == true)
{
$halaman .="";
$buka = false;
}
//$halaman .="";
}
else
{
if($buka == false && $chanopt == true)
{
$halaman .= "";
$buka = true;
}
}
$judul = $artikel["title"];
$link = $artikel["link"];
$halaman .= "<".$Borne_Style.">$judul
";

if($descopt != false)
{
$deskripsi = $artikel["description"];
if($deskripsi != false)
{
$halaman .= "
$deskripsi";
}
}
if($dateopt != false)
{
$updated = $artikel["updated"];
if($updated != false)
{
$halaman .= "<font $Borne_Date_Font>$updated</font>";
}
}
$halaman .= "</".$Borne_Style.">";

}

if($buka == true)
{
$halaman .="";
}
return $halaman."";

}


?>
