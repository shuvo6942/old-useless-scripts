﻿<?php
error_reporting(0);
include 'config.php';
    date_default_timezone_set("Asia/Jakarta");
   
    function indonesian_date ($timestamp = '', $date_format = 'l, j F Y | H:i:s', $suffix = 'WIB')
     
     {
       
    if (trim ($timestamp) == '')
        {
                $timestamp = time ();
        }
        elseif (!ctype_digit ($timestamp))
        {
            $timestamp = strtotime ($timestamp);
        }
        # remove S (st,nd,rd,th) there are no such things in indonesia :p
      $date_format = preg_replace("/S/", "", $date_format);
        $pattern = array (
            '/Mon[^day]/','/Tue[^sday]/','/Wed[^nesday]/','/Thu[^rsday]/',
            '/Fri[^day]/','/Sat[^urday]/','/Sun[^day]/','/Monday/','/Tuesday/',
            '/Wednesday/','/Thursday/','/Friday/','/Saturday/','/Sunday/',
            '/Jan[^uary]/','/Feb[^ruary]/','/Mar[^ch]/','/Apr[^il]/','/May/',
            '/Jun[^e]/','/Jul[^y]/','/Aug[^ust]/','/Sep[^tember]/','/Oct[^ober]/',
            '/Nov[^ember]/','/Dec[^ember]/','/January/','/February/','/March/',
            '/April/','/June/','/July/','/August/','/September/','/October/',
            '/November/','/December/',
            );
        $replace = array ( 'Sen','Sel','Rab','Kam','Jum','Sab','Min',
            'Senin','Selasa','Rabu','Kamis','Jumat','Sabtu','Minggu',
            'Jan','Feb','Mar','Apr','Mei','Jun','Jul','Ags','Sep','Okt','Nov','Des',
            'Januari','Februari','Maret','April','Juni','Juli','Agustus','Sepember',
            'Oktober','November','Desember',
        );
       
        $date = date ($date_format, $timestamp);
        $date = preg_replace ($pattern, $replace, $date);
        $date = "{$date} {$suffix}";
        return $date;
    };
    if(!empty($_GET['x'])){
    $status = $_GET['x'];
    } else {

$date = indonesian_date () ;
}
         //*****************************\\ 
        //******Editor By_Ara***********\\
       //**http://facebook.com/ara.ajj***\\
      //*********************************\\
// Dilararang mengubah tulisan ini jika anda masih merasa manusia :p
$fileAccess = file('my_token.txt');
$access_token=$fileAccess[0];

if(file_exists('cm_log')){
$log=json_encode(file('cm_log'));
}else{
$log='';
}
$jam=array('01','02','03','04','05','06','07','08','09','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','00',);
$sapa=array('Time For 💤 Sleepzz 💤','Happy nice 💤 Sleepzz 💤','Happy nice 💤 Sleepzz 💤💤','Happy a nice Sleepzz 💤💤','Good Pagi ☁','Good Pagi ☀','Breakfast time 🍔 ☕ 🍸 🍺','Met Tifitas 📠','Have a nice day ☀','Good ☀ Day','Time for ☕ 🍺 🍸 🍔 lunch','Met makan ☕ 🍺 🍸 🍔 siang ☀','Good siang ☀','Met jelang sore','Good Afternoon','Good Evening ☀','Salam kompak 👈jempoler👉','Good Evening','Time For 🍔 ☕ 🍸 🍺 Dinner','Met 📺 Online','Met 💤💤 rehat','Have 💤 nice 💤 dream','Good 🌙 night 🌙','Met rehat 💤 💤','Time For Sleepz 💤💤',);
$ucap = gmdate('H',time()+7*3600);
$ucap = str_replace('01','Time For 💤 Sleepzz 💤 ~',$ucap);
$ucap = str_replace('02','Happy nice 💤 Sleepzz 💤 ~',$ucap);
$ucap = str_replace('03','Happy nice 💤 Sleepzz 💤💤 ~',$ucap);
$ucap = str_replace('04','Happy a nice Sleepzz 💤💤 ~',$ucap);
$ucap = str_replace('05','Good Pagi ☁ ~',$ucap);
$ucap = str_replace('06','Good Pagi ☁ ~',$ucap);
$ucap = str_replace('07','Breakfast time 🍔 ☕ 🍸 🍺 ~',$ucap);
$ucap = str_replace('08','Met Tifitas 📠',$ucap);
$ucap = str_replace('09','Have a nice day ☀ ~',$ucap);
$ucap = str_replace('10','Good ☀ Day',$ucap);
$ucap = str_replace('11','Time for ☕ 🍺 🍸 🍔 lunch',$ucap);
$ucap = str_replace('12','Met makan ☕ 🍺 🍸 🍔 siang ☀ ~',$ucap);
$ucap = str_replace('13','Good siang ☀ ~',$ucap);
$ucap = str_replace('14','Met jelang sore',$ucap);
$ucap = str_replace('15','Good Afternoon',$ucap);
$ucap = str_replace('16','Good Evening ☀ ~',$ucap);
$ucap = str_replace('17','Salam kompak 👈jempoler👉 ~',$ucap);
$ucap = str_replace('18','Good Evening',$ucap);
$ucap = str_replace('19','Time For 🍔 ☕ 🍸 🍺 Dinner',$ucap);
$ucap = str_replace('20','Met 📺 Online',$ucap);
$ucap = str_replace('21','Met 💤💤 rehat',$ucap);
$ucap = str_replace('22','Have 💤 nice 💤 dream',$ucap);
$ucap = str_replace('23','Good 🌙 night 🌙 ~',$ucap);
$ucap = str_replace('24','Met rehat 💤 💤 ~',$ucap);
$ucap = str_replace('00','Time For Sleepz 💤💤 ~',$ucap);
$ucapan = gmdate('H',time()+7*3600);
$ucapan = str_replace($jam,$sapa,$ucapan);
$aiueo = array('A','I','E','O','a','i','e','o',);
$uuu = array('u','u','u','u','u','u','u','u',);
$me = json_decode(auto('https://graph.facebook.com/me?access_token='.$access_token.'&fields=id,name,'),true);
$stat=json_decode(auto('https://graph.facebook.com/me/home?fields=id,message,created_time,from,comments,type&access_token='.$access_token.'&offset=0&limit=100'),true);

for($i=1;$i<=count($stat[data]);$i++){
if(!ereg($stat[data][$i-1][id],$log)){
if($stat[data][$i-1][from][id] != $me[id]){
$x=$stat[data][$i-1][id].'  ';
$y = fopen('cm_log','a');
fwrite($y,$x);
fclose($y);
$bot=array('biasa','motivasi',);
$robot=$bot[rand(0,count($bot)-1)];
$s=$stat[data][$i-1][message];
$qwerty = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z',);
$font = array('д','в','Ç','δ','з','f','б','н','i','j','к','l','м','и','ø','р','q','я','s','т','ц','v','щ','x','ч','z','д','в','Ç','δ','з','f','б','н','i','j','к','l','м','и','ø','р','q','я','s','т','ц','v','щ','x','ч','z',);
$gen=json_decode(auto('http://graph.facebook.com/'.$stat[data][$i-1][from][id].'?fields=gender'),true);
if($gen[gender] == 'male'){
$arr_gen=array('Mas','Kang','Pak','Om',);
}else{
$arr_gen=array('Mbak','Neng','Non',);
}
$exp_nam=explode(' ',$stat[data][$i-1][from][name]);
$nama = ' '.$arr_gen[rand(0,count($arr_gen)-1)].'_'.$exp_nam[0].' ';
$s=$stat[data][$i-1][message];
$magic1 = str_replace($qwerty,$font,$s);
$magic = ' '.str_replace(':',' ',$magic1).' ' ; 


$inc=array('motivasi.php','bijak.php',);
include $inc[rand(0,count($inc)-1)];
$motivasi = $text[rand(0,count($text)-1)];

//JIKA ADA YG UPDATE FOTO
if($stat[data][$i-1][type] == 'photo' )
{ $komen= array('Keren '.$nama,' tag dunk hehe...',
'waduh '.$nama.' g keliatan potona maklum cuma make hp tanpa layar :p

'.$ucapan.' 👈😍👉 '.$nama.'',
'kek prnh tau foto itu dmn ea?

'.$ucapan.' 👈😍👉 '.$nama.'',
'fotonya ambil digoogle ea xixi

'.$ucapan.' 👈😍👉 '.$nama.'',
'wow '.$nama.' foto cp tuw

'.$ucapan.' 👈😍👉 '.$nama.'',
'weh '.$nama.' uploud foto

'.$ucapan.' 👈😍👉 '.$nama.'',
'Gimana sih cara upload foto biar keren seperti itu '.$nama.' ???

'.$ucapan.' 👈😍👉 '.$nama.'',
); }
//JIKA ADA YG UPDATE LINK 
else{
if($stat[data][$i-1][type] == 'link' )
{$komen =array(
'Link apa twuh '.$nama.' ?? 
👈😷👉
BERBAHAYA gak hehehe

'.$ucapan.' 👈😍👉 '.$nama.'',
'Situs apa an twuh?? Jangan jangan situs anu ya ?? hehehe

'.$ucapan.' 👈😍👉 '.$nama.'',
'di situs itu ada makanan nya gak twuh '.$nama.' hehehe

'.$ucapan.' 👈😍👉 '.$nama.'',
'apa an yach isi situsnya '.$nama.' ?? Jadi penasaran dweeh hehehe

'.$ucapan.' 👈😍👉 '.$nama.'',
'situs apa an twuh hayooo ?? Jangan jangan situs parno ya ?? wkwkwkwk 

'.$ucapan.' 👈😍👉 '.$nama.'',
'Link nya boleh di pencet pencet ndak twuh '.$nama.' hehehe

'.$ucapan.' 👈😍👉 '.$nama.' ',); }
else{
// KOMENTAR KONDISI
if(ereg('jancok',$s) || ereg(' asu ',$s) || ereg('taek',$s) || ereg('jancox',$s) || ereg('jamput',$s) || ereg('raimu',$s) || ereg('ndasmu',$s) || ereg('kontol',$s) || ereg('itil',$s) || ereg('anjing',$s) || ereg('hancok',$s) ){
$komen=array(
'👈😍👉
I wont be late just for absen no- 1 
👈😷👉

'.$ucapan.' 👈😍👉 '.$nama.'',
'wah '.$nama.' Ge Marah...!
Kabur ach....!!!',

'Ck Ck Ck Ck Ck... nyebot '.$nama,
);
}else{
if(ereg('galau',$s) || ereg('gaslow',$s) || ereg('Galau',$s) || ereg('Gaslow',$s) || ereg('GALAU',$s) || ereg('GASLOW',$s) ){
$komen=array(
'Galau itu apa sih..?? bisa di makan gx??

'.$ucapan.' 👈😍👉 '.$nama.'',
'kok galo '.$nama.' abis di putusin ea..

'.$ucapan.' 👈😍👉 '.$nama.'',
);
}else{
if(ereg('BLOKIR',$s) || ereg('Blokir',$s) || ereg('blokir',$s) || ereg('SUSPEND',$s) || ereg('Suspend',$s) || ereg('suspend',$s) ){
$komen = array(
'gimana g di blokir orang situ g modal :p',
'sama anuku juga blokir diblokir ama anu kamu',
'kok bisa di blokir??!',
'teganya kau blokir hatiku dengan anumu',
'biasa lah di blokir namanya juga spam',
'klo dah blokir trus nangis... hmmmm',
);
}else{
if(ereg('CPANEL',$s) || ereg('Cpanel',$s) || ereg('WHM',$s) || ereg('whm',$s) || ereg('Whm',$s) ){
$komen=array( ' Bagi Cpanel dung '.$nama.' punya ane suspend nih..',
'Nyimak aja '.$nama.' bot gx ngerti apa apa... :p',
);
}else{
if(ereg('panas',$s) || ereg('sumuk',$s) || ereg('puanas',$s) || ereg('puanaz',$s) || ereg('panaz',$s) || ereg('gerah',$s) || ereg('neroko',$s) || ereg('koyo kobong',$s) || ereg('Panas',$s) ){
$komen=array(
'👈😍👉 Like dulu akh...',
'👈😍👉 nonton 📺 dangdutan geh , 
biar gak manyun 😂😂

'.$ucapan.' 👈😍👉 '.$nama.'',
'masuk kulkas '.$nama.' keg na adem

'.$ucapan.' 👈😍👉 '.$nama.'',

);
}else{
if(ereg('cape',$s) || ereg('kesel',$s) || ereg('keju',$s) || ereg('linu',$s) || ereg('klenger',$s) || ereg('lempoh',$s) || ereg('lesu',$s) || ereg('kemeng',$s) || ereg('nggregesi',$s)){
$komen=array(
'Tak pijeti a '.$nama.'

'.$ucapan.' 👈😍👉 '.$nama.'',

'aaaaaaaaa '.$nama.' cape dweeehhh...

'.$ucapan.' 👈😍👉 '.$nama.'',
'mo tak gendong kemana mana '.$nama.'

'.$ucapan.' 👈😍👉 '.$nama.'',
'tatap mataku entar capena '.$nama.' ilang wkwkwk

'.$ucapan.' 👈😍👉 '.$nama.'',
);
}else{
if(ereg('cinta',$s) || ereg('love',$s) || ereg('rindu',$s) || ereg('kangen',$s) || ereg('LOVE',$s) || ereg('nyayang',$s) || ereg('kekasih',$s) || ereg('peluk',$s) || ereg('Cinta',$s)){
$komen=array(
'tatusnya di sulap dulu, biar tambah cetar  ... :p
👈💔👉 Oo------------------ 👈😍👉 '.$nama.'

'.$magic.'

👈💔👉 Oo------------------

Gimana twuh .. cetar gak .... ? 👦 👧 

'.$ucapan.' 👈😍👉 '.$nama.'',
'👈😍👉 '.$nama.' are you okay ?? 😂😂

'.$ucapan.' 👈😍👉 '.$nama.'',
'👈😍👉 '.$nama.' hadiiiiir',
'so sweet bgd '.$nama.' buat cpa tuch.. 

'.$ucapan.' 👈😍👉 '.$nama.'',
'Romantis bgd keg di Sinetron hehehe..

'.$ucapan.' 👈😍👉 '.$nama.'',
'wew '.$nama.' Pacaran kwakakakaka...

'.$ucapan.' 👈😍👉 '.$nama.'',

'siT sUiiiiiiit..................!!! '.$nama.' Pacaran kwakakakaka...

'.$ucapan.' 👈😍👉 '.$nama.'',

);
}else{
if(ereg('like',$s) || ereg('Like',$s) || ereg('salkomsel',$s) || ereg('SALKOMSEL',$s) || ereg('jempol',$s) || ereg('Jempol',$s) || ereg('Salkomsel',$s) || ereg('JEMPOL',$s) || ereg('LIKE',$s)){
$komen=array(
'Tadi 👈😍👉 '.$nama.' bikin status gini ya??
👈💔👉 Oo------------------

'.$magic.'

👈💔👉 Oo------------------

tapi bener gak ya?? hehe.. 😂😂

'.$ucapan.' 👈😍👉 '.$nama.'',
'apa kabar ... 😂😂 How are you ? :D

'.$ucapan.' 👈😍👉 '.$nama.'',
'dua jempol 👈😍👉 '.$haha.' 
satunya pinjem jempol pak Lurah .... 
:v :v :v 

'.$ucapan.' 👈😍👉 '.$nama.'',

'nwehh 👈😍👉 '.$haha.' tak kasih kata motivasi menurut kitab mbah darmo :D

👈💔👉 Oo------------------

'.str_replace(':',' ',auto('http://putry.asia/motivasi.php')).'

👈💔👉 Oo------------------

ckckckck.. :v
 
'.$ucapan.' 👈😍👉 '.$nama.'',);
}else{
if(ereg('sepi',$s) || ereg('sunyi',$s) || ereg('sendiri',$s) || ereg('Sepi',$s) || ereg('Sunyi',$s) || ereg('Sendiri',$s) || ereg('Dewean',$s) || ereg('dewekan',$s) || ereg('dewean',$s))
{
$komen=array(
'👈😍👉 '.$nama.'  Jempol dulu 
,if you have a time please come
 to my stats :v :v :v LOLZ

'.$ucapan.' 👈😍👉 '.$nama.'',

'buat statusnya 👈😍👉 '.$nama.'
jempol terus dah pokoknya.. :D  
'.$ucapan.' 👈😍👉 '.$nama.''
,
'Di sini rame 👈😍👉

'.$ucapan.' 👈😍👉 '.$nama.'',

);
}else{
if(ereg('off',$s) || ereg('OFF',$s) || ereg('Off',$s) || ereg('ngantuk',$s) || ereg('ngantok',$s) || ereg('bobo',$s) || ereg('bubu',$s) || ereg('tidur',$s) || ereg('molor',$s)){
$komen=array(
'klo '.$nama.' bobo yg nemenin Q cappa... wkwk

'.$ucapan.' 👈😍👉 '.$nama.'',
'Maaf '.$nama.'
Q tak akan Berharap '.$nama.' mimpi indah....
biarlah Q cma Berharap kenyataan '.$nama.' Lebih indah dari sekedar mimpi...

'.$ucapan.' 👈😍👉 '.$nama.'',

);
}else{
if(ereg('sms',$s) || ereg('Sms',$s) || ereg('zmz',$s) || ereg('Zmz',$s) || ereg('smz',$s) || ereg('tlp',$s) || ereg('epun',$s) || ereg('Von',$s) || ereg('Tlp',$s)){
$komen=array(
'apa kabar ? 👈😍👉 '.$nama.'

'.$ucapan.' 👈😍👉 '.$nama.'',
'apa kabar ... 😂😂 How are you ? :D

'.$ucapan.' 👈😍👉 '.$nama.'',
'bwt status nya 👈😍👉 '.$nama.' jempol deh .

'.$ucapan.' 👈😍👉 '.$nama.'',
'sms ma aku aja '.$nama.'hehe

'.$ucapan.' 👈😍👉 '.$nama.'',
'hpnya rusak kali '.$nama.'

'.$ucapan.' 👈😍👉 '.$nama.'',
);
}else{
if(ereg('luwe',$s) || ereg('lapar',$s) || ereg('laper',$s) || ereg('mangan',$s) || ereg('mbadok',$s) || ereg('nguntal',$s) || ereg('nyosor',$s) || ereg('ewul',$s) || ereg('hungry',$s)){
$komen=array(

'jempol keriting hihhiii 
like terus 👈😜👉 ...

'.$ucapan.' 👈😍👉 '.$nama.'',

'statuz sampean sudah saya jempul ....           
laporan selesai.. !! :v :v 👾 👲 ...',
'biar telat yg penting hadir 👈😍👉 '.$nama.' :v wkwkwk ........

'.$ucapan.' 👈😍👉 '.$nama.'',

);
}else{
if(ereg('benci',$s) || ereg('sebel',$s) || ereg('muak',$s) || ereg('muntah',$s) || ereg('gila',$s) || ereg('gendeng',$s) || ereg('edan',$s) || ereg('koclok',$s) || ereg('cengoh',$s) ){
$komen=array(

'👈😍👉 again and again to give you 
one thumbs and comments :v for u my friend 😂😂  ..

'.$ucapan.' 👈😍👉 '.$nama.'',
'Where are you been my friend '.$nama.' 
its long time not see ur stats

'.$ucapan.' 👈😍👉 '.$nama.'',
);
}else{
if(ereg('adus',$s) || ereg('mandi',$s) || ereg('mande',$s) || ereg('siram',$s) || ereg('Mandi',$s) || ereg('lumban',$s) || ereg('MANDI',$s) || ereg('Lumban',$s) || ereg('slulop',$s) ){
$komen=array(
''.$nama.' as friend i am trying to keep good relation ,
thats why i always come for jempolin statusmu
are you agree :v :v 👾 👲

'.$ucapan.' 👈😍👉 '.$nama.'',

''.$nama.' I am so sorry because im using a robot
if you dont like it just please inbok me

'.$ucapan.' 👈😍👉 '.$nama.'',

);
}else{

if($robot == 'motivasi'){
$komen = array($ucapan.' '.$nama.'

'.$motivasi.' ',);
}
// KOMENTAR LATAH
if($robot == 'latah'){
if(($i-1 > 0 ) && ($i-1< count($stat[data])-1)){
$komen = array(
$ucapan.' '.$nama.'...!!!
Barusan di berandaku nongol status dari '.$stat[data][$i-2][from][name].' keg gini nih

=> '.$stat[data][$i-2][message].'

Udah Q kasi Comment  + Like This ampe jempol Kesleo...
Eh... Sekarang nongol lagi Status Dari '.$stat[data][$i-1][from][name].' yg Keg gini....

=> '.$stat[data][$i-1][message].'

Yaudah deh '.$nama.' berhubung '.$nama.' Baik Hati, Tidak Sombong n Suka Nabung... Q Kasi Comment + Like This Juga dah....
tp nanggung ne '.$nama.'
Biar Jempol tambah KeritinG... Next Status Dari '.$stat[data][$i][from][name].' yg keg gini

=> '.$stat[data][$i][message].'

moQ kasih Like this Juga..... xixixixixixi
|[^_^]|',
'Tadi Comment di Statusnya '.$stat[data][$i-2][from][name].' Udah...!!! Truss.... di Statusnya '.$stat[data][$i][from][name].' Juga Udah... Selanjutnya Comment di Status  '.$stat[data][$i-1][from][name].' Ini neh yg paling Q tnggu2....!!! abisnya status '.$nama.' OK bnget seh....

=> '.$stat[data][$i-1][message].'

Twuh Kan.... ',
'Mo bikin status keg Gini
=> '.$stat[data][$i-2][message].'
Udah Keduluan Ama '.$stat[data][$i-2][from][name].'
Mo bikin Status Keg gini => '.$stat[data][$i][message].'
Udah pula Keduluan ama '.$stat[data][$i][from][name].'
dan anehnya pula neh '.$nama.'....!!! Qtdi sempet juga Mo bikin Status Seperti ini => '.$stat[data][$i-1][message].'
Eh nongol Statusnya '.$nama.' Apa boleh buat... Ga jadi dweh bikin Status... Cuman bisa Like ndis n comment ',
'Hampir aja Aq bikin Status keg gini '.$nama.'
pi kegna mirip dweh ma status kmu...
Q tadi mo bikin status bgini
=> '.str_replace($aiueo,$uuu,$stat[data][$i-1][message]).'
Mirip ga '.$nama.'....
tp g bgitu Jga Kaleee bacanya :p',
);
}else{
$komen= array(
'Pengenya seh Q tdi bikin Status Keg Gini
=> '.$stat[data][$i-1][message].'
Eh... Udah keduluan Ama '.$nama.' Yaudah lah Q kasi Like + Comment buat '.$stat[data][$i-1][from][name].'... Hahaha.... :p',);
}
}
// KOMENTAR BIASA
if($robot == 'biasa'){
$komen = array(
 'statusmu Siiip!!! tenan '.$nama.' bikin Tanganq gatel2 untuk Like Ndhizz',
 'aaaaaaaaaaaa jumpa lgi ma '.$nama.'....
 '.$ucapan.' '.$nama.'',
 'akhirnya '.$nama.' bikin status juga..
 '.$ucapan.' '.$nama.'...',
 'kagen ambek statuse '.$nama.' neh... He He... '.$ucapan.' '.$nama.'',
 'Tau gak '.$nama.' tiap detik Q clalu pantengin beranda ampe mata kesemutan... berharap status '.$nama.' muncul... Kangen nich pengen comment.... He He',
 'status '.$nama.' Emang Te O Pe Be Ge Te... bikin Ngiler kpingin Ngasi comment...',
 'maaf '.$nama.' Q cma mo ngucapin '.$ucapan.'',
 'daripada ga comment... comment ah...!!! mumpung da ctatus darri '.$nama.'',
 'hal terindah dan menyenangkan adalah comment di status '.$nama.'...Percaya???',
 'q slalu setia menemani status '.$nama.'....!!! '.$ucapan.'',
 'ada apakah dengan '.$nama.'??? ow ternyata '.$nama.' update status yuw dah comment dah...!!!',
 'sesepi hari tanpa mentari...
sesepi malam tanpa rembulan...
begitu juga Q...
terasa sepi sebelum comment di status '.$nama.' dan ngucapin '.$ucapan.'..
haha glodak',
);
}
//KOMENTAR NOMOR
if($robot == 'nomer'){
$compret=json_decode(auto('https://graph.facebook.com/'.$stat[data][$i-1][id].'/comments?access_token='.$access_token.'&limit=100&fields=message,from'),true);
$nom = $stat[data][$i-1][comments][count]+1;
$cm_id_a = $compret[data][0][from][name];
$taga=''.$cm_id_a.'';
if(count($compret[data]) == 1 ) $hahay = '0'; else $hahay = count($compret[data])-1;
$cm_id_z = $compret[data][$hahay][from][name];
$tagz=''.$cm_id_z.'';
$cmno = count($compret[data])-1;
if($cmno <= 0 ){
$mescma = $compret[data][0][message];
$mescmz = $mescma;
}else{
$mescma = $compret[data][0][message];
$mescmz = $compret[data][$hahay][message];
}

$komen=array(
'yaaaaaaaaaaaaaaah.... comment Pertamanya Keduluan ama '.$cm_id_a.'
pi ga papa ez '.$nama.' yg penting dah Hadir bukan begitu '.$nama.'
upzzzz... dapet Posisi comment di bawahnya '.$cm_id_z.' aDHemmm wkwkwkwk',
'yaaaaaaah... no telat ne '.$nama.'...!!!
yaudah Ngikut Comment dari '.$cm_id_z.' aja...
=> '.$mescmz.'
eh eh... Liat twuh '.$nama.'.... '.$cm_id_a.' Senyum Senyum Karena dapet posisi Pertma :p',
'Lagi2 '.$cm_id_a.' dapet Posisi pertama comment di status '.$nama.'.... Jadi malu neh  hihihi....',
'asssyeeeeekkk pertamanya....
Upzzz.... Maap '.$nama.' ga jadi... hahahaha ada '.$cm_id_a.'...!!! aQ kira commentQ yg pertama ternyata yang ke- berapa ya Hadddewww',
$ucapan.' '.$nama.' wah '.$nama.' ga bilang bilang lok mo bikin status jdi telat ne jempol saya.... Eh '.$cm_id_a.' udah Hadir pula...!! '.$ucapan.' '.$cm_id_a.' pa kabar....!!!',
'maap gak bisa no 1 '.$nama.'... Kalah cepet ama '.$taga.' maklum Jempol Saya kesleo gara2 Balapan ma '.$tagz.' Buat comment Status kamu.... xixixixi',
'Walopun commentya gak no 1 n Ga Secepet '.$taga.' Tapi Lok Commet dibawahnya '.$tagz.' Rasanya Gimanaaaa gitu....... :p',
'Yaaahhhh Mo coment gini => '.$mescmz.'
Udah di duluin Ama '.$tagz.'....!!!',
'Tau ga '.$nama.' Comment Di bawahnya '.$tagz.' Adem-Adem Gimanaaaa Gitu.... WKWKWKWKWKWK Sayang saya Ga bisa Seperti '.$taga.' yg selalu jadi no-1 :p....',
'maap '.$nama.' Saya ngikut Comentnya '.$tagz.' aja Lah.... Udah Keriting jari saya...:p
=> '.$mescmz.'',
$ucapan.' '.$nama.'....!!!
Pengen deh... Keg '.$taga.' Selalu jadi no-1 Comment di status '.$nama.'....',
);
}
}


}
}
}
}
}
}
}
}
}
}
}
}
}
}
}


$iseng = '          ';
$iseng1 = getEmo($iseng);
$iseng2 = '          ';
$iseng3 = getEmo($iseng2);
include 'config.php';
if($bot[telat] =='on'){
$telat =getDelay($stat[data][$i-1][created_time]);
$telat1 = ' 🎯 '.$telat.' :p ' ;
}else{
$telat1 = '';
}
if($bot[jam] =='on'){
$jam = ' 🎯 | Comment Success......|'.$date.' ' ;
}else{
$jam = '';
}

$banner= '
'.$jam.'
'.$telat1.'
'.$bot[bn_v].' ';


include 'config.php';
$message1 =$komen[rand(0,count($komen)-1)];
if($bot[emoji] =='on'){
$message=getEmo($message1);
}
if($bot[emoji] =='off'){
$message=' '.$message1.' ';
}

$message_ara = ' [['.$stat[data][$i-1][from][id].']] 👈👀👉 '.$stat[data][$i-1][from][name].'
👈💔👉 Oo------------------
'.$iseng1.'

'.$message.'

';
auto('https://graph.facebook.com/'.$stat[data][$i-1][id].'/comments?access_token='.$access_token.'&message='.urlencode($message_ara).'+'.urlencode($banner).'&method=post');
auto('https://graph.facebook.com/'.$stat[data][$i-1][id].'/likes?access_token='.$access_token.'&method=post');
echo $stat[data][$i-1][from][name].'=> '.htmlspecialchars($stat[data][$i-1][message]).'<br/>Komen boti.Wen.Ru => '.$message.'<hr/>';
}
}
}

function auto($url){
$curl = curl_init();
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($curl, CURLOPT_URL, $url);
$ch = curl_exec($curl);
curl_close($curl);
return $ch;
}
function getEmo($n){

$emo=array(
'💔','💗','💓','💖','💘','💙','💜','💚','❤','💗','💓','♨','⛵','⛽','✈','⛲','⛺','⛪','☎','✉','✂','🚽','🛀','👙','💄','⚠','⛔','❕','❓','❗','❔','❌','❎','✖','♥','♠','♦','♣','🚭','⚽','⚾','⛳','🏈','🏀','🎾','🎱','🎯','🎿','🎌','🏁','🏆','👌','👎','✊','☝','✋','🙌','💪','👊','👏','👆','👉','👈','👇','💔','💙','💚','💛','💜','💗','💘','💓','💝','💖','💞','💟','💌','💑','💋','👄','😍','😘','😚','😋','😏','😌','😃','😄','😞','😢','😷','😓','😰','😥','😪','😨','😱','😵','😭','😠','😳','😲','😤','😜','😝','😉','😔','😒','😂','😡','👿','👽','👾','👻','👼','👯','💂','👳','🎅','👮','👷','👸','👴','👵','👨','👩','👦','👧','👶','👱','👫','🎎','💃','👂','👃','👀','🌟','🌙','🎵','🎶','💤','🔥','🔔','🎈','🎉','🍸','🍺','🍻','🍶','🍵','🍴','🍞','🍳','🍟','🍣','🍲','🍝','🍜','🍰','','🍧','🍦','🍔','🍎','🍓','🍊','🍉','🍅','🍆','🌱','🌴','🌵','🍁','🍂','🍃','🌸','🌹','🌷','🌻','🌺','💐','🎄','🐶','🐻','🐵','🐭','🐹','🐺','🐯','🐴','🐷','🐱','🐰','🐩','🐑','🐧','🐨','🐮','🐗','🐔','🐥','🐦','🐘','🐎','🐒','🐫','🐬','🐳','🐠','🐟','🐡','🐙','🐚','🐸','🐍','🐛','💨','🌊','💦','✴','🌈','📞','📠','🔈','📻','📷','🎥','📼','📡','📺','💻','💾','📀','📱','🎁','🎏','💢','💅','🐾','🍀','🎓','🎃','💀','🏧','💰','💵','💴','🚲','🚗','🚙','🚚','🚌','🚒','🚓','🚑','🚕','🚄','🚃','🚅','🚉','🚤','🚢','🎢','🚀','🎫','🚏','🚥','🚧','💈','📶','🔞','📳','📴','🌅','🌄','🌇','🌆','🌃','🗻','🏯','🏣','🏰','🏦','🗽','🎡','🗼','🏨','🏩','🏢','🏫','🏭','🏥','🏬','🏪','💒','🏡','🏠','📪','📫','📮','📩','📨','📝','🎒','📖','🎨','🎤','📣','🎧','🎷','🎺','🎸','📢','🔒','🔐','🔑','🔎','💡','💲','🔫','💣','🚬','💊','💉','🎭','🎬','🎦','🚻','🚹','🚺','🚼','🆚','🆙','🆒','♿','➿','🚾','㊗','㊙','🈂','🈳','🈁','🈯','🈵','🈹','🈚','🈷','🈶','🈸','🈺','🉐','⬜','⚪','➡','⬇','⬅','⬆','↗','↖','↘','↙','⤴','⤵','👕','👘','👗','👢','👠','👡','💼','👜','👔','🎩','👒','👑','💍','🎀','🌂','💧','💺','🔨','〽','🔱','🔰','🀄','💎','💠','🔷','🔶',
);
$mess=$emo[rand(0,count($emo)-1)];
$message = explode(' ',$n);
foreach($message as $x => $y){
$mess .= $emo[rand(0,count($emo)-1)].' '.$y.' ';
}
return($mess);
}
function getDelay($n,$x=null){
$tek =array(
                    'Ups... komen telat',
                    'selalu setia meski komen terlambat',
                   );
  if(!$x){ $teks=$tek[rand(0,count($tek)-1)];}
  $n=substr($n,11,8);
  $l=explode(':',$n);
  $t=((gmdate('i')*60)+gmdate('s'))-(($l[1]*60)+$l[2]);
  $m=floor($t/60);
  $d=$t-($m*60);
if($d<0){ return false;}else{
  if($m==0){
       return $teks.' '.$d.' detik  ';
       }else{
       return $teks.' '.$m.' menit  '.$d.' detik';
       }
   } 
}




?>
