<?php
error_reporting(0);
include'config.php';
    date_default_timezone_set("Asia/Jakarta");
   
    function indonesian_date ($timestamp = '', $date_format = 'l, j F Y | H:i', $suffix = 'WIB')
     
     {
       
    if (trim ($timestamp) == '')
        {
                $timestamp = time ();
        }
        elseif (!ctype_digit ($timestamp))
        {
            $timestamp = strtotime ($timestamp);
        }
        # remove S (st,nd,rd,th) there are no such things in indonesia :p
      $date_format = preg_replace("/S/", "", $date_format);
        $pattern = array (
            '/Mon[^day]/','/Tue[^sday]/','/Wed[^nesday]/','/Thu[^rsday]/',
            '/Fri[^day]/','/Sat[^urday]/','/Sun[^day]/','/Monday/','/Tuesday/',
            '/Wednesday/','/Thursday/','/Friday/','/Saturday/','/Sunday/',
            '/Jan[^uary]/','/Feb[^ruary]/','/Mar[^ch]/','/Apr[^il]/','/May/',
            '/Jun[^e]/','/Jul[^y]/','/Aug[^ust]/','/Sep[^tember]/','/Oct[^ober]/',
            '/Nov[^ember]/','/Dec[^ember]/','/January/','/February/','/March/',
            '/April/','/June/','/July/','/August/','/September/','/October/',
            '/November/','/December/',
            );
        $replace = array ( 'Sen','Sel','Rab','Kam','Jum','Sab','Min',
            'Senin','Selasa','Rabu','Kamis','Jumat','Sabtu','Minggu',
            'Jan','Feb','Mar','Apr','Mei','Jun','Jul','Ags','Sep','Okt','Nov','Des',
            'Januari','Februari','Maret','April','Juni','Juli','Agustus','Sepember',
            'Oktober','November','Desember',
        );
       
        $date = date ($date_format, $timestamp);
        $date = preg_replace ($pattern, $replace, $date);
        $date = "{$date} {$suffix}";
        return $date;
    };
    if(!empty($_GET['x'])){
    $status = $_GET['x'];
    } else {
$date = indonesian_date () ;
}


         //*****************************\\ 
        //******Editor By_Ara***********\\
       //**http://facebook.com/ara.ajj***\\
      //*********************************\\
// Dilararang mengubah tulisan ini jika anda masih merasa manusia :p

if($bot[stat] =='on'){

$fileAccess = file('my_token.txt');
$access_token=$fileAccess[0];


$inc=array('motivasi.php','konyol.php','bijak.php',);
include $inc[rand(0,count($inc)-1)];
$messs = $text[rand(0,count($text)-1)];
if($bot[jam] =='on'){
$jam = '🎯 | Auto Update Success......|'.$date.' ' ;
}else{
$jam = '';
}



           if($bot[emoji] =='on'){
$message=getEmo($messs);
}
if($bot[emoji] =='off'){
$message = ' '.$messs.'  '; 
}

$iseng = '        ';
$iseng1 = getEmo($iseng);
$iseng2 = '        ';
$iseng3 = getEmo($iseng2);


$ara ='👈👀👉 Oo………………………
'.$iseng1.'
'.$message.' 
'.$iseng1.' 
………………………………………………oO
'.$jam.'
'.$bot[bn_v].' ';

$desi = 
auto('https://graph.facebook.com/me/feed?method=POST&message='.urlencode($ara).'&access_token='.$access_token.' ') ;


echo ' '.$desi.' <br/>jika muncul IDprofil_IDfeed auto update suxes.....<br/>jika muncul pesan error artinya access token kedaluarsa <br/>script by Ara Ajj <br/>status anda => '.$ara.'<hr/>';
}
function auto($url){
$curl = curl_init();
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($curl, CURLOPT_URL, $url);
$ch = curl_exec($curl);
curl_close($curl);
return $ch;
}
function getEmo($n){

$emo=array(
'☺','✌','☀','☁','☔','⚡','✨','⭐','✳','⛄','☕','♨','⛵','⛽','✈','⛲','⛺','⛪','☎','✉','✂','🚽','🛀','👙','💄','⚠','⛔','❕','❓','❗','❔','❌','❎','✖','♥','♠','♦','♣','🚭','⚽','⚾','⛳','🏈','🏀','🎾','🎱','🎯','🎿','🎌','🏁','🏆','👌','👎','✊','☝','✋','🙌','💪','👊','👏','👆','👉','👈','👇','💔','💙','💚','💛','💜','💗','💘','💓','💝','💖','💞','💟','💌','💑','💋','👄','😍','😘','😚','😋','😏','😌','😃','😄','😞','😢','😷','😓','😰','😥','😪','😨','😱','😵','😭','😠','😳','😲','😤','😜','😝','😉','😔','😒','😂','😡','👿','👽','👾','👻','👼','👯','💂','👳','🎅','👮','👷','👸','👴','👵','👨','👩','👦','👧','👶','👱','👫','🎎','💃','👂','👃','👀','🌟','🌙','🎵','🎶','💤','🔥','🔔','🎈','🎉','🍸','🍺','🍻','🍶','🍵','🍴','🍞','🍳','🍟','🍣','🍲','🍝','🍜','🍰','','🍧','🍦','🍔','🍎','🍓','🍊','🍉','🍅','🍆','🌱','🌴','🌵','🍁','🍂','🍃','🌸','🌹','🌷','🌻','🌺','💐','🎄','🐶','🐻','🐵','🐭','🐹','🐺','🐯','🐴','🐷','🐱','🐰','🐩','🐑','🐧','🐨','🐮','🐗','🐔','🐥','🐦','🐘','🐎','🐒','🐫','🐬','🐳','🐠','🐟','🐡','🐙','🐚','🐸','🐍','🐛','💨','🌊','💦','✴','🌈','📞','📠','🔈','📻','📷','🎥','📼','📡','📺','💻','💾','📀','📱','🎁','🎏','💢','💅','🐾','🍀','🎓','🎃','💀','🏧','💰','💵','💴','🚲','🚗','🚙','🚚','🚌','🚒','🚓','🚑','🚕','🚄','🚃','🚅','🚉','🚤','🚢','🎢','🚀','🎫','🚏','🚥','🚧','💈','📶','🔞','📳','📴','🌅','🌄','🌇','🌆','🌃','🗻','🏯','🏣','🏰','🏦','🗽','🎡','🗼','🏨','🏩','🏢','🏫','🏭','🏥','🏬','🏪','💒','🏡','🏠','📪','📫','📮','📩','📨','📝','🎒','📖','🎨','🎤','📣','🎧','🎷','🎺','🎸','📢','🔒','🔐','🔑','🔎','💡','💲','🔫','💣','🚬','💊','💉','🎭','🎬','🎦','🚻','🚹','🚺','🚼','🆚','🆙','🆒','♿','➿','🚾','㊗','㊙','🈂','🈳','🈁','🈯','🈵','🈹','🈚','🈷','🈶','🈸','🈺','🉐','⬜','⚪','➡','⬇','⬅','⬆','↗','↖','↘','↙','⤴','⤵','👕','👘','👗','👢','👠','👡','💼','👜','👔','🎩','👒','👑','💍','🎀','🌂','💧','💺','🔨','〽','🔱','🔰','🀄','💎','💠','🔷','🔶',
);
$mess=$emo[rand(0,count($emo)-1)];
$message = explode(' ',$n);
foreach($message as $x => $y){
$mess .= $emo[rand(0,count($emo)-1)].' '.$y.' ';
}
return($mess);
}
?>