﻿<?php
error_reporting(0);
         //*****************************\\ 
        //******Editor By_Ara***********\\
       //**http://facebook.com/ara.ajj***\\
      //*********************************\\
// Dilararang mengubah tulisan ini jika anda masih merasa manusia :p
    date_default_timezone_set("Asia/Jakarta");
   
    function indonesian_date ($timestamp = '', $date_format = 'l, j F Y | H:i', $suffix = 'WIB')
     
     {
       
    if (trim ($timestamp) == '')
        {
                $timestamp = time ();
        }
        elseif (!ctype_digit ($timestamp))
        {
            $timestamp = strtotime ($timestamp);
        }
        # remove S (st,nd,rd,th) there are no such things in indonesia :p
      $date_format = preg_replace("/S/", "", $date_format);
        $pattern = array (
            '/Mon[^day]/','/Tue[^sday]/','/Wed[^nesday]/','/Thu[^rsday]/',
            '/Fri[^day]/','/Sat[^urday]/','/Sun[^day]/','/Monday/','/Tuesday/',
            '/Wednesday/','/Thursday/','/Friday/','/Saturday/','/Sunday/',
            '/Jan[^uary]/','/Feb[^ruary]/','/Mar[^ch]/','/Apr[^il]/','/May/',
            '/Jun[^e]/','/Jul[^y]/','/Aug[^ust]/','/Sep[^tember]/','/Oct[^ober]/',
            '/Nov[^ember]/','/Dec[^ember]/','/January/','/February/','/March/',
            '/April/','/June/','/July/','/August/','/September/','/October/',
            '/November/','/December/',
            );
        $replace = array ( 'Sen','Sel','Rab','Kam','Jum','Sab','Min',
            'Senin','Selasa','Rabu','Kamis','Jumat','Sabtu','Minggu',
            'Jan','Feb','Mar','Apr','Mei','Jun','Jul','Ags','Sep','Okt','Nov','Des',
            'Januari','Februari','Maret','April','Juni','Juli','Agustus','Sepember',
            'Oktober','November','Desember',
        );
       
        $date = date ($date_format, $timestamp);
        $date = preg_replace ($pattern, $replace, $date);
        $date = "{$date} {$suffix}";
        return $date;
    };
    if(!empty($_GET['x'])){
    $status = $_GET['x'];
    } else {

$date = indonesian_date () ;
}
$fileAccess = file('my_token.txt');
$access_token=$fileAccess[0];
$notif = json_decode(auto('https://graph.facebook.com/fql?q='.urlencode('SELECT sender_id, title_text, object_id FROM notification WHERE recipient_id=me() AND is_hidden = 0').'&access_token='.$access_token),true); echo json_encode($notif);
if(file_exists('rlk_log')){
   $log = json_encode(file('rlk_log'));
   }else{
   $log='';
  }
for($i=1;$i<=count($notif[data])-1;$i++){
   if(ereg('likes your comment',$notif[data][$i-1][title_text])){
       if(!ereg($notif[data][$i-1][object_id].'_'.$notif[data][$i-1][sender_id],$log)){
           $x = $notif[data][$i-1][object_id].'_'.$notif[data][$i-1][sender_id].' ';
           $y = fopen('rlk_log','a');
                     fwrite($y,$x);
                     fclose($y);
           $sender_id = json_decode(auto('http://graph.facebook.com/'.$notif[data][$i-1][sender_id].'?fields=id,gender,name'),true);
           if($sender_id[gender] == 'male'){
               $arr_gen = array('Mas','Brow','Pak','Om',);
               }else{
               $arr_gen = array('Mbak','Non','Neng','Jeng',);
               }
           
           $exp_nam = explode(' ',$sender_id[name]);
           $nama = ''.$arr_gen[rand(0,count($arr_gen)-1)].'_'.$exp_nam[0].'';
           $tags = explode('_',$notif[data][$i-1][object_id]);
           $tag1=json_decode(auto('http://graph.facebook.com/'.$tags[0].'?fields=id,gender,name'),true);
           $tag2= explode(' ',$tag1[name]);
           $tag = ' '.$tag2[0].' ';
           $mess = array(
               'makasih banyak '.$nama.' ... dah like komentarku',
            'UUUhuuiii '.$nama.' like komenku',
            $nama.' dapet gelas cantik coz dah like komenku hohoho',
            'ngek ngok '.$nama.' like komenku makasih ',
            $nama.' ... jempuul km emang mancap smpai sampai komenku dikasih jempool makasih ya',
               'hehe '.$nama.' suka komenq kah?...',
            'Ciyuuuss tuh '.$nama.' suka komen q wkwkwkw',
            'jempool  '.$nama.' Genit komenku dilike jadi pengen komen terus deh hohoho',
            'asik asiikkk '.$nama.        'like komenku',
            'kommen lagi ah  '.$nama.' cooozzz seneng kl komenku dilike ',
            'suitt suiiit '.$nama.'... like komentarku',
            'dapet piring cantik kamu  '.$nama.'  ... dah like komentarku wkwkwkkw',
            $nama.' ... like lagi dong komenku hohoho',
               'seneng deh lok  '.$nama.' like komenq',
            'tuuuiing datang lagi mau ngucapin makasih buat '.$nama.' dah mau like komentarku hehe',
            'Prikitiwwww '.$nama.        ' SUKA KOMEN Q ya..?? dari pada like komenku Ikutan Abang dangdutan yukk hahaiiii ROBOT KOPLAK',
               $nama.' ... suka koment q ya?',
               'duuuuuuh '.$nama.' jempulna genit deh...  makasih ea dah like komentarku',
               'cye cye da yg suka komentar q makasih '.$nama,
               'makasih dah like komen Q ya '.$nama,
               'suka banget deh lok '.$nama.' like komenq',
               'makasih '.$nama.' walopun cuma bot dah mau like komentarku',
               'klo '.$nama.' like komentarQ rasanya gimanaaaaaaaaa gtu hahaha',
            'ciat ciat ciat '.$nama.' suka komenku',
               'jempol  '.$nama.' banyak ya ..?? komenku dilke terus heheheh makasih dah like komenku '.$nama,
               'wEw '.$nama.' like komenq... makasi ea... jd rajin komen nih di status '.$tag,
            'Dapet komen lagi dariku coz dah like komenku terimakasih  '.$nama,
               'Eh... '.$nama.' gak keriting kah jari kmu... kok setiap  komenQ kmu Like hixhix',
               'YEZ YEZ YEZ]] '.$nama.        ' SUKA KOMENQ PADAHAL CUMA KOMEN ROBOT]]',
               'Maap]] '.$tag.' Q dateng Lagi Cuma buat ngucapin Makasih ama  '.$nama.' Karena Dah Likee KomenQ walaupun cuma komen robot',
               'Hwadehhh... '.$tag.' ...!!! JempoL '.$nama.' slalu Nemplok di KomenQ knapa? Padahal cuma komen robot',
               'makash ea '.$nama.'  yg udah Like KomenQ meski hanya komen robot!!!!',
               );


include 'config.php';

if($bot[jam] =='on'){
$jam = ' 🎯 | Respon Success....|'.$date.' ' ;
}else{
$jam = '';
}
if($bot[telat] =='on'){
$telat =getDelay($notif[data][$i-1][created_time]);
$telat1 = ' 🎯 '.$telat.' :p ' ;
}else{
$telat1 = '';
}
           $message1 = $mess[rand(0,count($mess)-1)];
           if($bot[emoji] =='on'){
$message=getEmo($message1);
}
if($bot[emoji] =='off'){
$message=' '.$message1.' ';
}
$iseng = '           ';
$iseng1 = getEmo($iseng);
$iseng2 = '        ';
$iseng3 = getEmo($iseng2);

$message3 = ' [['.$notif[data][$i-1][sender_id].']] 👈😱👉 '.$exp_nam[0].'
👈💗👉 Oo------------------
'.$iseng1.'

'.$message.'

'.$jam.' 
'.$telat1.'
'.$bot[bn_v].' ';
           auto('https://graph.facebook.com/'.$notif[data][$i-1][object_id].'/comments?access_token='.$access_token.'&message='.urlencode($message3).'&method=post');
           }
       }
   }

function auto($url){
   $curl = curl_init();
   curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
   curl_setopt($curl, CURLOPT_URL, $url);
   $ch = curl_exec($curl);
   curl_close($curl);
   return $ch;
   }



function getEmo($n){

$emo=array(
'☺','✌','☀','☁','☔','⚡','✨','⭐','✳','⛄','☕','♨','⛵','⛽','✈','⛲','⛺','⛪','☎','✉','✂','🚽','🛀','👙','💄','⚠','⛔','❕','❓','❗','❔','❌','❎','✖','♥','♠','♦','♣','🚭','⚽','⚾','⛳','🏈','🏀','🎾','🎱','🎯','🎿','🎌','🏁','🏆','👌','👎','✊','☝','✋','🙌','💪','👊','👏','👆','👉','👈','👇','💔','💙','💚','💛','💜','💗','💘','💓','💝','💖','💞','💟','💌','💑','💋','👄','😍','😘','😚','😋','😏','😌','😃','😄','😞','😢','😷','😓','😰','😥','😪','😨','😱','😵','😭','😠','😳','😲','😤','😜','😝','😉','😔','😒','😂','😡','👿','👽','👾','👻','👼','👯','💂','👳','🎅','👮','👷','👸','👴','👵','👨','👩','👦','👧','👶','👱','👫','🎎','💃','👂','👃','👀','🌟','🌙','🎵','🎶','💤','🔥','🔔','🎈','🎉','🍸','🍺','🍻','🍶','🍵','🍴','🍞','🍳','🍟','🍣','🍲','🍝','🍜','🍰','','🍧','🍦','🍔','🍎','🍓','🍊','🍉','🍅','🍆','🌱','🌴','🌵','🍁','🍂','🍃','🌸','🌹','🌷','🌻','🌺','💐','🎄','🐶','🐻','🐵','🐭','🐹','🐺','🐯','🐴','🐷','🐱','🐰','🐩','🐑','🐧','🐨','🐮','🐗','🐔','🐥','🐦','🐘','🐎','🐒','🐫','🐬','🐳','🐠','🐟','🐡','🐙','🐚','🐸','🐍','🐛','💨','🌊','💦','✴','🌈','📞','📠','🔈','📻','📷','🎥','📼','📡','📺','💻','💾','📀','📱','🎁','🎏','💢','💅','🐾','🍀','🎓','🎃','💀','🏧','💰','💵','💴','🚲','🚗','🚙','🚚','🚌','🚒','🚓','🚑','🚕','🚄','🚃','🚅','🚉','🚤','🚢','🎢','🚀','🎫','🚏','🚥','🚧','💈','📶','🔞','📳','📴','🌅','🌄','🌇','🌆','🌃','🗻','🏯','🏣','🏰','🏦','🗽','🎡','🗼','🏨','🏩','🏢','🏫','🏭','🏥','🏬','🏪','💒','🏡','🏠','📪','📫','📮','📩','📨','📝','🎒','📖','🎨','🎤','📣','🎧','🎷','🎺','🎸','📢','🔒','🔐','🔑','🔎','💡','💲','🔫','💣','🚬','💊','💉','🎭','🎬','🎦','🚻','🚹','🚺','🚼','🆚','🆙','🆒','♿','➿','🚾','㊗','㊙','🈂','🈳','🈁','🈯','🈵','🈹','🈚','🈷','🈶','🈸','🈺','🉐','⬜','⚪','➡','⬇','⬅','⬆','↗','↖','↘','↙','⤴','⤵','👕','👘','👗','👢','👠','👡','💼','👜','👔','🎩','👒','👑','💍','🎀','🌂','💧','💺','🔨','〽','🔱','🔰','🀄','💎','💠','🔷','🔶',
);
$mess=$emo[rand(0,count($emo)-1)];
$message = explode(' ',$n);
foreach($message as $x => $y){
$mess .= $emo[rand(0,count($emo)-1)].' '.$y.' ';
}
return($mess);
}
function getDelay($n,$x=null){
$tek =array(
                    'Ups... komen telat',
                    'selalu setia meski komen terlambat',
                   );
  if(!$x){ $teks=$tek[rand(0,count($tek)-1)];}
  $n=substr($n,11,8);
  $l=explode(':',$n);
  $t=((gmdate('i')*60)+gmdate('s'))-(($l[1]*60)+$l[2]);
  $m=floor($t/60);
  $d=$t-($m*60);
if($d<0){ return false;}else{
  if($m==0){
       return $teks.' '.$d.' detik  ';
       }else{
       return $teks.' '.$m.' menit  '.$d.' detik';
       }
   } 
}

?>