<?php 
$inc = array('sport.php','viva.php','oto.php',);
$ken_inc = acak($inc);
include ''.$ken_inc.'';
function acak($inc){ return $inc[rand(0,count($inc) - 1)]; }
?>