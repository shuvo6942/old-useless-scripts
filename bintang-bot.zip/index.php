<?php
error_reporting(0);
$version = "2.0"; // Version Status
$act=$_GET[act];
if(file_exists('config.php')){ include 'config.php'; }
if($bot[lock]=='on'){ $s_pass = md5($bot[pass]); }else{ $s_pass = ''; }
$s_login_time = 3600 * 24 * 7;
$s_auth = false; // login status
if(strlen(trim($s_pass))>0){
if(isset($_COOKIE['index'])){
if(strtolower(trim($s_pass)) == strtolower(trim($_COOKIE['index']))) $s_auth = true;
}
if(isset($_REQUEST['pass'])){
$login = strtolower(trim($_REQUEST['pass']));
if(strtolower(trim($s_pass)) == md5($login)){
setcookie("index",md5($login),time() + $s_login_time);
$m = $_SERVER['PHP_SELF'];
header("Location: ".$m);
die();
}else{
setcookie("index",$login,time() - $s_login_time);
$m = $_SERVER['PHP_SELF'];
header("Location: ".$m);
die();
}
}
}
else $s_auth = true; // $s_pass variable (password) is empty , go ahead, no login page
if(isset($_REQUEST['logout'])){
setcookie("index",$login,time() - $s_login_time);
setcookie("file",$login,time() - $s_login_time);
$m = "tawon_ndast.php";
header("Location: ".$m);
}


if(file_exists('my_token.txt')){ $access=file('my_token.txt'); }
$me= json_decode(auto('https://graph.facebook.com/me?access_token='.$access[0].'&fields=id,name'),true);

?>
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.2//EN" "http://www.openmobilealliance.org/tech/DTD/xhtml-mobile12.dtd">  <html xmlns="http://www.w3.org/1999/xhtml" lang="en">  <head>  <title>Bintang-Bot</title>  <meta http-equiv="Content-Type" content="application/vnd.wap.xhtml+xml; charset=utf-8" />  <meta name="viewport" content="width=device-width,initial-scale=1">  <meta name="description" content="ARa-Bot" />  <meta name="author" content="ION" />  <meta name="keywords" content="ARa-Bot" />
<meta name="Generator" content="ION, http://nextions.xtgem.com">
<link rel="stylesheet" type="text/css" href="http://petaonan.mw.lt/themes/default3/style.css" media="all,handheld"/>
<link rel="stylesheet" href="/emoji/emoji.css" type="text/css" media="all,handheld">
<link rel="shortcut icon" href="http://www.facebook.com/favicon.ico">
<head><body>
<div class="menu"><script language="JavaScript" src="http://petaonan.mw.lt/themes/black_horizontal/style.css"></script></div>


<div class="list2"><center><b><font color="lime">Bot Facebook - Auto Like - Auto Komen - Update Status Dll.</font></b></center></div><br/><div class="header"><table width="100%" border="0 "><tr><td width="33%" bgcolor="black" align="center"><a href="http://facebook.com/Mr.ArdandiV.For"><font color="white">My FB</font></a></td><td width="34%" bgcolor="black" align="center"><a href="http://ardandi.com"><font color="white">My Autolike</font></a></td><td width="33%" bgcolor="black" align="center"><a href="http://yellow-flazh.heck.in"><font color="white">My Blogs</font></a></td></tr></table></div>
<div class="list2"><br style="clear:both"><fieldset
class="feature-column">
<legend><img src="https://fbstatic-a.akamaihd.net/rsrc.php/v2/yw/r/C0eConWN8vs.png"><font color="red"><b>Ikuti Admin</b></font></legend>
<div style="text-align:
left"><font color="lime"><img src="https://graph.facebook.com/Mr.ArdandiV.For/picture" alt=""/><br/><iframe src="//www.facebook.com/plugins/follow.php?href=https%3A%2F%2Fwww.facebook.com%2FMr.ArdandiV.For&amp;width&amp;height=21&amp;colorscheme=light&amp;layout=button_count&amp;show_faces=true&amp;appId=421560461258395" scrolling="no" frameborder="0" style="border:none; overflow:hidden; height:21px;" allowTransparency="true"></iframe>
</div>
</fieldset>
</div>
<script type="text/javascript">
var __lc = {};
__lc.license = 4408481;

(function() {
	var lc = document.createElement('script'); lc.type = 'text/javascript'; lc.async = true;
	lc.src = ('https:' == document.location.protocol ? 'https' : 'http://') + 'cdn.livechatinc.com/tracking.js';
	var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(lc, s);
})();
</script>

<div class="header"><center><span style="text-shadow:gray 0.5mm 0.4mm 0.3mm;color:red"><b>Selamat Datang Di Bintang-Bot</b></span></font></div>
<?php
if($s_auth==true){
echo '</head>
<body>

<div class="auto">';
if(file_exists('dataLog.php')){ include 'dataLog.php'; }
if($bot[cm] == 'on'){
$selcm='<select name="cm"><option value="on">On</option><option value="off">Off</option></select>';
}else{
$selcm='<select name="cm"><option value="off">Off</option><option value="on">On</option></select>';
}
if($bot[lk_sj] == 'on'){
$sellk_sj='<select name="lk_sj"><option value="on">On</option><option value="off">Off</option></select>';
}else{
$sellk_sj='<select name="lk_sj"><option value="off">Off</option><option value="on">On</option></select>';
}
if($bot[auto_add] == 'on'){
$selauto_add='<select name="auto_add"><option value="on">On</option><option value="off">Off</option></select>';
}else{
$selauto_add='<select name="auto_add"><option value="off">Off</option><option value="on">On</option></select>';
}
if($bot[tolak] == 'on'){
$seltolak='<select name="tolak"><option value="on">On</option><option value="off">Off</option></select>';
}else{
$seltolak='<select name="tolak"><option value="off">Off</option><option value="on">On</option></select>';
}
if($bot[anu] == 'biasa'){
$selanu='<select name="anu"><option value="biasa">Biasa</option><option value="cerewet">Cerewet</option><option value="off">Off</option></select>';
}else
if($bot[anu] == 'cerewet'){
$selanu='<select name="anu"><option value="cerewet">Cerewet</option><option value="Biasa">Biasa</option><option value="off">Off</option></select>';
}else{
$selanu='<select name="anu"><option value="off">Off</option><option value="cerewet">Cerewet</option><option value="biasa">Biasa</option></select>';
}
if($bot[anu1] == 'biasa'){
$selanu1='<select name="anu1"><option value="biasa">Motivasi</option><option value="copas">Copas</option><option value="off">Off</option></select>';
}else
if($bot[anu1] == 'copas'){
$selanu1='<select name="anu1"><option value="copas">Copas</option><option value="biasa">Motivasi</option><option value="off">Off</option></select>';
}else{
$selanu1='<select name="anu1"><option value="off">Off</option><option value="copas">Copas</option><option value="biasa">Motivasi</option></select>';
}
if($bot[rcg] == 'biasa'){
$selrcg='<select name="rcg"><option value="biasa">Biasa</option><option value="copas">Copas</option><option value="cerewet">Cerewet</option><option value="motivasi">Motivasi</option><option value="off">Off</option></select>';
}elseif($bot[rcg] == 'copas'){
$selrcg='<select name="rcg"><option value="copas">Copas</option><option value="biasa">Biasa</option><option value="cerewet">Cerewet</option><option value="motivasi">Motivasi</option><option value="off">Off</option></select>';
}elseif($bot[rcg] == 'cerewet'){
$selrcg='<select name="rcg"><option value="cerewet">Cerewet</option><option value="copas">Copas</option><option value="biasa">Biasa</option><option value="motivasi">Motivasi</option><option value="off">Off</option></select>';
}elseif($bot[rcg] == 'motivasi'){
$selrcg='<select name="rcg"><option value="motivasi">Motivasi</option><option value="cerewet">Cerewet</option><option value="biasa">biasa</option><option value="copas">Copas</option><option value="off">Off</option></select>';
}else{
$selrcg='<select name="rcg"><option value="off">Off</option><option value="biasa">Biasa</option><option value="motivasi">Motivasi</option><option value="cerewet">Cerewet</option><option value="copas">Copas</option></select>';
}
if($bot[r_cm] == 'on'){
$selr_cm='<select name="r_cm"><option value="on">On</option><option value="off">Off</option></select>';
}else{
$selr_cm='<select name="r_cm"><option value="off">Off</option><option value="on">On</option></select>';
}
if($bot[r_lk] == 'on'){
$selr_lk='<select name="r_lk"><option value="on">On</option><option value="off">Off</option></select>';
}else{
$selr_lk='<select name="r_lk"><option value="off">Off</option><option value="on">On</option></select>';
}
if($bot[stat] == 'on'){
$selstat='<select name="stat"><option value="on">On</option><option value="off">Off</option></select>';
}else{
$selstat='<select name="stat"><option value="off">Off</option><option value="on">On</option></select>';
}
if($bot[stat2] == 'on'){
$selstat2='<select name="stat2"><option value="on">On</option><option value="off">Off</option></select>';
}else{
$selstat2='<select name="stat2"><option value="off">Off</option><option value="on">On</option></select>';
}
if($bot[cnf] == 'on'){
$selcnf='<select name="cnf"><option value="on">On</option><option value="off">Off</option></select>';
}else{
$selcnf='<select name="cnf"><option value="off">Off</option><option value="on">On</option></select>';
}
if($bot[lk] == 'on'){
$sellk='<select name="lk"><option value="on">On</option><option value="off">Off</option></select>';
}else{
$sellk='<select name="lk"><option value="off">Off</option><option value="on">On</option></select>';
}
if($bot[in] == 'on'){
$selin='<select name="in"><option value="on">On</option><option value="off">Off</option></select>';
}else{
$selin='<select name="in"><option value="off">Off</option><option value="on">On</option></select>';
}

if($bot[pk] == 'on'){
$selpk='<select name="pk"><option value="on">On</option><option value="off">Off</option></select>';
}else{
$selpk='<select name="pk"><option value="off">Off</option><option value="on">On</option></select>';
}
if($bot[stat_ny] == 'on'){
$selstat_ny='<select name="stat_ny"><option value="on">On</option><option value="off">Off</option></select>';
}else{
$selstat_ny='<select name="stat_ny"><option value="off">Off</option><option value="on">On</option></select>';
}
if($bot[feed] == 'on'){
$selfeed='<select name="feed"><option value="on">On</option><option value="off">Off</option></select>';
}else{
$selfeed='<select name="feed"><option value="off">Off</option><option value="on">On</option></select>';
}
if($bot[emoji] == 'on'){
$selemoji='<select name="emoji"><option value="on">On</option><option value="off">Off</option></select>';
}else{
$selemoji='<select name="emoji"><option value="off">Off</option><option value="on">On</option></select>';
}
if($bot[jam] == 'on'){
$seljam='<select name="jam"><option value="on">On</option><option value="off">Off</option></select>';
}else{
$seljam='<select name="jam"><option value="off">Off</option><option value="on">On</option></select>';
}

if($bot[telat] == 'on'){
$seltelat='<select name="telat"><option value="on">On</option><option value="off">Off</option></select>';
}else{
$seltelat='<select name="telat"><option value="off">Off</option><option value="on">On</option></select>';
}


#####Hosting URL#####
$instal   = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
$host   = explode("index.php",$instal);
#####Hosting URL#####


$formChange="\n".'<form action="'.$_SERVER['PHP_SELF'].'"><div class="header"><center><span style="text-shadow:gray 0.5mm 0.4mm 0.3mm;color:red"><b><input type="hidden" name="act" value="change"><input type="submit" value="Ganti Akun"></form></b></span></font></div>';
$formSetting="\n".'<form action="'.$_SERVER['PHP_SELF'].'"><div class="header"><center><span style="text-shadow:gray 0.5mm 0.4mm 0.3mm;color:red"><b><input type="hidden" name="act" value="conf"><input type="submit" value="Pengaturan"></b></span></font></div>
<div class="header"><center><span style="text-shadow:gray 0.5mm 0.4mm 0.3mm;color:red"><b>Silahkan Buat Cronjob </br><hr/></b></span></font></div><div class="header"><center><span style="text-shadow:gray 0.5mm 0.4mm 0.3mm;color:red"><b>Jika menggunakan Cronjob Cpanel : <br/>curl http://'.htmlspecialchars($host[0]).'cron.php<br/>
curl http://'.htmlspecialchars($host[0]).'cron1.php<br/>
curl http://'.htmlspecialchars($host[0]).'cron2.php</b></span></font></div>';

$formConfig='
<form action="'.$_SERVER['PHP_SELF'].'" method="post">
<br/></div>
<div class="list2"><center><b><font color="lime">Pengaturan</font></b></center></div><br/>
</div>
<div class="list2"><center><b><font color="lime">
<table width="100%"><tr><td width="70%">Comment dan like</td><td width="30%">'.$selcm.'</td></tr></table><hr/>
<table width="100%"><tr><td width="70%">Like saja</td><td width="30%">'.$sellk_sj.'</td></tr></table><hr/>
<table width="100%"><tr><td width="70%">Auto Add</td><td width="30%">'.$selauto_add.'</td></tr></table><hr/>
<table width="100%"><tr><td width="70%">Auto konfirmasi</td><td width="30%">'.$selcnf.'</td></tr></table><hr/>
<table width="100%"><tr><td width="70%">Riject permintaan pertemanan</td><td width="30%">'.$seltolak.'</td></tr></table><hr/>
<table width="100%"><tr><td width="70%">Auto inbox</td><td width="30%">'.$selin.'</td></tr></table><hr/>
<table width="100%"><tr><td width="70%">Auto colek</td><td width="30%">'.$selpk.'</td></tr></table><hr/>
<table width="100%"><tr><td width="70%">Like comment</td><td width="30%">'.$sellk.'</td></tr></table><hr/>
<table width="100%"><tr><td width="70%">Respon Status Anda</td><td width="30%">'.$selrcg.'</td></tr></table><hr/>
<table width="100%"><tr><td width="70%">Respon Status Teman</td><td width="30%">'.$selanu.'</td></tr></table><hr/>
<table width="100%"><tr><td width="70%">Respon Status Teman 1</td><td width="30%">'.$selanu1.'</td></tr></table><hr/>
<table width="100%"><tr><td width="70%">Respon like</td><td width="30%">'.$selr_lk.'</td></tr></table>
<hr/>
<table width="100%"><tr><td width="70%">Status Motivasi</td><td width="30%">'.$selstat.'</td></tr></table>
<hr/>
<table width="100%"><tr><td width="70%">Status Nyolong</td><td width="30%">'.$selstat_ny.'</td></tr></table>
<hr/>
<table width="100%"><tr><td width="70%">Berita</td><td width="30%">'.$selfeed.'</td></tr></table>
<hr/>
<table width="100%"><tr><td width="70%">Jam</td><td width="30%">'.$seljam.'</td></tr></table>
<hr/>
<table width="100%"><tr><td width="70%">Emoji</td><td width="30%">'.$selemoji.'</td></tr></table>
<hr/>
<table width="100%"><tr><td width="70%">Telat</td><td width="30%">'.$seltelat.'</td></tr></table>
<hr/>

<table width="100%"><tr><td width="70%">Status Buat Sendiri</td><td width="30%">'.$selstat2.'</td></tr></table>
</font></b></center></div>
<br/>

</div>
<div class="list2"><center><b><font color="lime">
Jika  Update Status Sendiri On <br />
Masukan Status kamu Pisahkan Dengan Tanda koma ( , )<br />
Status Anda : <br />
<textarea name="stat2_v" cols="35" rows="5">'.htmlspecialchars($bot[stat2_v]).'</textarea></font></b></center></div>

<br/>


</div>
<div class="list2"><center><b><font color="lime">Banner Value :<br/><br/>(Powered/Link List kamu)<br/>
<textarea name="bn_v" cols="35" rows="3">'.$bot[bn_v].'</textarea></font></b></center></div><br/>

</div>
<div class="list2"><center><b><font color="lime">
<input name="simpen" value="Simpan" type="submit"/><input type="hidden" name="act" value=""><input type="submit" value="Kembali"/></font></b></center></div>
';
$formInstal='
<form action="'.$_SERVER['PHP_SELF'].'" method="post">
<input name="pasang" value="Install" type="submit"><center><input type="hidden" name="act" value=""><input type="submit" value="Batalkan"></center></form>';
$formDataLog = '<table>Masukan email dan sandi facebook Kamu.<br/><form action="'.$_SERVER['PHP_SELF'].'" method="post"><br/>Email: <input name="email" type="text" value="'.htmlspecialchars($dataLog[email]).'"><br/>Sandi: <input name="pass" type="password" value="'.htmlspecialchars($dataLog[pass]).'"> <input type="submit" value="Masuk" name="dataLog"></table></form> <br/>
<div class="list2"><br style="clear:both"><fieldset
class="feature-column">
<legend><font color="red"><b><img src="http://1.bp.blogspot.com/-uH2xaORsNAs/U2zobdhfvmI/AAAAAAAAHVs/nI1XqhF8Wek/s1600/rightwards-arrow.png" alt=""/> Token Manual</b></font></legend>
<div style="text-align:
left"><font color="lime"> <span
class="composerTextSelected"><img src="http://2.bp.blogspot.com/-3XI6TeC7Dcw/UZPoxNyg5UI/AAAAAAAADw8/hfSNNvn9zpU/s1600/facebook-eyes-symbol.png" alt=""/><img src="http://3.bp.blogspot.com/-KZ7zG3cC7DE/UaaH36I1BTI/AAAAAAAAEFU/kwXz1jWid0o/s1600/finger-pointing-to-right.png" alt=""/> Silahkan Anda ambil Access Tokennya
 <form action="https://www.facebook.com/dialog/oauth?" target="_blank"><font color="green"><b></b><b><img src="http://2.bp.blogspot.com/-3XI6TeC7Dcw/UZPoxNyg5UI/AAAAAAAADw8/hfSNNvn9zpU/s1600/facebook-eyes-symbol.png" alt=""/><img src="http://3.bp.blogspot.com/-KZ7zG3cC7DE/UaaH36I1BTI/AAAAAAAAEFU/kwXz1jWid0o/s1600/finger-pointing-to-right.png" alt=""/>Pilih Access_Token Via :</b></font><br/><img src="http://2.bp.blogspot.com/-3XI6TeC7Dcw/UZPoxNyg5UI/AAAAAAAADw8/hfSNNvn9zpU/s1600/facebook-eyes-symbol.png" alt=""/><img src="http://3.bp.blogspot.com/-KZ7zG3cC7DE/UaaH36I1BTI/AAAAAAAAEFU/kwXz1jWid0o/s1600/finger-pointing-to-right.png" alt=""/><input type="hidden" name="response_type" value="token">
<input type="hidden" name="display" value="popup">
<select class="menu" name="client_id" style="width:110px">
<option value="2389801228">Texas</option>
</select><input type="hidden" name="redirect_uri" value="http://www.facebook.com/connect/login_success.html">
<input type="hidden" name="perms" value="email,publish_stream,publish_checkins,offline_access,user_about_me"><input type="submit" value="Ambil Token" class="menu"></form>
<img src="http://2.bp.blogspot.com/-3XI6TeC7Dcw/UZPoxNyg5UI/AAAAAAAADw8/hfSNNvn9zpU/s1600/facebook-eyes-symbol.png" alt=""/><img src="http://3.bp.blogspot.com/-KZ7zG3cC7DE/UaaH36I1BTI/AAAAAAAAEFU/kwXz1jWid0o/s1600/finger-pointing-to-right.png" alt=""/> Masukan Access Token Anda<br/>
<form action="cek.php"><input type="text" name="access_token" class="menu" style="width:410px"> <input type="submit" class="tmn" value="Hajar Bray"></form></div></fieldset></div>




';
         
//--DOWNLOAD SCRIPT BOT--//
if($_POST[mulai]){

echo'<meta http-equiv="refresh" content="0; url='.$_SERVER['PHP_SELF'].'?act=instal">';
}
if($_POST[dataLog]){
$data =  urldecode('<').'?php
$dataLog = array( "host" =>  "'.$host[0].'",
"pass" => "'.$_POST[pass].'",
"email" => "'.$_POST[email].'",
);
?'.urldecode('>');
$fx=fopen('dataLog.php','w');
fwrite($fx,$data);
fclose($fx);
auto('http://'.$host[0].'/refresh.php');
echo'<meta http-equiv="refresh" content="0; url='.$_SERVER['PHP_SELF'].'?act=conf">';
}
if($_POST[pasang]){
$data =  urldecode('<').'?php
$bot = array( "instal" => "ok",
"host" => "'.$host[0].'",
"lock" => "'.$_POST[lock].'",
"pass" => "'.$_POST[passwod].'",


"cm" => "'.$_POST[cm].'",
"lk_sj" => "'.$_POST[lk_sj].'",
"auto_add" => "'.$_POST[auto_add].'",
"cm" => "'.$_POST[cm].'",
"cnf" => "'.$_POST[cnf].'",
"tolak" => "'.$_POST[tolak].'",
"in" => "'.$_POST[in].'",
"pk" => "'.$_POST[pk].'",
"lk" => "'.$_POST[lk].'",
"rcg" => "'.$_POST[rcg].'",
"anu" => "'.$_POST[anu].'",
"anu1" => "'.$_POST[anu1].'",
"r_lk" => "'.$_POST[r_lk].'",
"stat" => "'.$_POST[stat].'",
"stat_ny" => "'.$_POST[stat_ny].'",
"feed" => "'.$_POST[feed].'",
"stat2" => "'.$_POST[stat2].'",
"emoji" => "'.$_POST[emoji].'",
"jam" => "'.$_POST[jam].'",
"telat" => "'.$_POST[telat].'",
"stat2_v" => "'.$_POST[stat2_v].'",
"bn_v" => "'.$_POST[bn_v].'",
);
?'.urldecode('>');
$fx=fopen('config.php','w');
fwrite($fx,$data);
fclose($fx);

//auto('http://'.$host[0].'/lp.php');
echo '<div class="info"><font color="red">Berhasil install</font></div>';
echo'<meta http-equiv="refresh" content="0; url='.$_SERVER['PHP_SELF'].'">';
}
if($_POST[simpen]){
$data =  urldecode('<').'?php
$bot = array( "instal" => "ok",
"host" => "'.$host[0].'",
"lock" => "'.$_POST[lock].'",
"pass" => "'.$_POST[passwod].'",
"cm" => "'.$_POST[cm].'",
"lk_sj" => "'.$_POST[lk_sj].'",
"auto_add" => "'.$_POST[auto_add].'",
"cm" => "'.$_POST[cm].'",
"cnf" => "'.$_POST[cnf].'",
"tolak" => "'.$_POST[tolak].'",
"in" => "'.$_POST[in].'",
"pk" => "'.$_POST[pk].'",
"lk" => "'.$_POST[lk].'",
"rcg" => "'.$_POST[rcg].'",
"anu" => "'.$_POST[anu].'",
"anu1" => "'.$_POST[anu1].'",
"r_lk" => "'.$_POST[r_lk].'",
"stat" => "'.$_POST[stat].'",
"stat_ny" => "'.$_POST[stat_ny].'",
"feed" => "'.$_POST[feed].'",
"stat2" => "'.$_POST[stat2].'",
"emoji" => "'.$_POST[emoji].'",
"jam" => "'.$_POST[jam].'",
"telat" => "'.$_POST[telat].'",
"stat2_v" => "'.$_POST[stat2_v].'",
"bn_v" => "'.$_POST[bn_v].'",
);
?'.urldecode('>');
$fx=fopen('config.php','w');
fwrite($fx,$data);
fclose($fx);

echo '<div class="info"><font color="red">Pengaturan di simpan</font></div>';
echo'<meta http-equiv="refresh" content="0; url='.$_SERVER['PHP_SELF'].'">';
}
include'ucapan.php';
if(file_exists('my_token.txt')){ $access=file('my_token.txt'); }
$me= json_decode(auto('https://graph.facebook.com/me?access_token='.$access[0].'&fields=id,name'),true);
if(!empty($me[id])){ echo "\n".'<div class="header"><center><span style="text-shadow:gray 0.5mm 0.4mm 0.3mm;color:red"><b><br/><img src="http://graph.facebook.com/'.$me[id].'/picture?type=small" alt=""/><br/> <hr/>'.$rx.' '.$me[name].'</b></span></font></div><br/>';}; if($bot[lock]=='on'){ echo "\n".'<form action="'.$_SERVER['PHP_SELF'].'?logout"><input type="hidden" name="logout" value="logout"><input type="submit" value="Keluar" title="Are you sure want to Logout '.$me[name].'???"/></form></div>';}else{ echo '</div>';}
if($act=='conf'){
if(empty($me[id])){

echo 'Tidak bisa masuk ke facebook. pastikan email dan sandi yang kamu masukan adalah benar,  coba masuk kembali.<br/><hr/>'.$formDataLog.'<hr/>
<br/>atau login ke facebook kamu seperti biasa, lalu klik "Ini Oke". bila ada pemberitahuan akun anda di akses dari perangkat yang tidak di kenal kemudian Install Ulang bot kamu
<br/>
</center><br/><center></center>';
}else{
if(file_exists('config.php')){ echo $formConfig; }else{ echo $formInstal; }
}
}else{
if($act=='instal'){
echo $formDataLog;
$vx = urldecode('<').'?php '.urldecode('%24').'versi = "'.$version.'"'.urldecode('%3B').' ?'.urldecode('>');
$v = fopen('version.php','w');
fwrite($v,$vx);
fclose($v);
}else{
if(file_exists('dataLog.php')){
if(!empty($bot[acc])){
$astok = auto('http://'.$dataLog[host].'/other_token.txt');
$gw = json_decode(auto('https://graph.facebook.com/me?access_token='.$astok),true);
if(empty($gw[id])){
echo '<center></center>'."\n".'<meta http-equiv="refresh" content="1; url='.$_SERVER['PHP_SELF'].'?act=cek"/>';
}
}




echo '<br/></div>
<div class="header"><center><span style="text-shadow:gray 0.5mm 0.4mm 0.3mm;color:red"><b>
<form action="cron.php"><input type="submit" value="Tes Bot"></form>
<form action="refresh.php"><input type="submit" value="Tes Token"></form></b></span></font></div>
';
echo $formManager.$formUpdater.$formRefresh.$formChange;

if(file_exists('config.php')){
echo $formSetting;
}else{
auto('http://'.$dataLog[host].'/refresh.php');
echo'<meta http-equiv="refresh" content="0; url='.$_SERVER['PHP_SELF'].'?act=conf"/>';
}
}else{


if(!file_exists('cron.php')){
echo'<div class="header"><center><span style="text-shadow:gray 0.5mm 0.4mm 0.3mm;color:red"><b>Pertama ijinkan Amplikasi Aplikasi Texas Poker Sampai Ada Bacaan Sukses <a href="https://m.facebook.com/dialog/oauth?scope=publish_stream,offline_access,read_stream,publish_actions&redirect_uri=https://www.facebook.com/connect/login_success.html&response_type=token&client_id=2389801228">klik di sini</a> Kemudian Klik <form method="post" action="index.php"><input name="mulai" value="MULAI" type="submit"/><form></b></span></font></div>
';


}else{
echo'<div class="header"><center><span style="text-shadow:gray 0.5mm 0.4mm 0.3mm;color:red"><b>Pertama ijinkan Aplikasi texas Sampai Ada Bacaan Sukses <a href="https://m.facebook.com/dialog/oauth?scope=publish_stream,offline_access,read_stream,publish_actions&redirect_uri=https://www.facebook.com/connect/login_success.html&response_type=token&client_id=2389801228">klik di sini</a> Kemudian Klik <form method="post" action="index.php"><input name="mulai" value="MULAI" type="submit"/><form </b></span></font></div>';

}
}
}
}

if($act=='change'){
unlink('coker_log');
unlink('my_token.txt');
unlink('config.php');
echo'<meta http-equiv="refresh" content="0;url='.$_SERVER['PHP_SELF'].'?act=mulai">';
}
if($act=='cek'){
auto('http://'.$dataLog[host].'/refresh.php');
echo'<meta http-equiv="refresh" content="0; url='.$_SERVER['PHP_SELF'].'?act=conf">';
}



echo'<br/>


<center></center>
<div id="footer"
<div class="header"><center><span style="text-shadow:gray 0.5mm 0.4mm 0.3mm;color:red"><b>Breaking News..!!!</div>
<div class="bmenu"><center><font color="lime"> 34Rb follower 10rb Pulsa minat inbox saya </font><a href="http://facebook.com/Mr.ArdandiV.For"><font color="red"> Disini...!!!</font></a></div><br/>
<div class="header"><center><span style="text-shadow:gray 0.5mm 0.4mm 0.3mm;color:red"><b>Donasi...!!!</div>
<div class="menu"align="center"><center><span style="font-weight:130px; text-shadow:gray 0.1em 0.1em 0.1em"><b><font color="gold">Bagi yang ingin berpartisipasi Sumbangan Dapat di salurkan via Pulsa Tri 089680628778 <br/> Sumbangan anda sangat berati  <img src="http://4.bp.blogspot.com/-bTF2qiAqvi0/UZCuIO7xbOI/AAAAAAAADnI/GVx0hhhmM40/s1600/facebook-tongue-out-emoticon.png" alt=""/></font></div>
<div class="footer"><center>Copyrights &copy 2014 <a href="https://facebook.com/ara.ajj"target=blank>Ardandi™</a> 
<br/><font color="lime">All Right Reserved</font></center></div></center></div>
</div>
</body>
</html>';
}else{ ?>
</head>
<body>

<div class="auto" style="width:100%;text-align:center;">
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<img src="http://graph.facebook.com/<?php echo $me[id]; ?>/picture" style="margin:2px;vertical-align:middle;" title="This is Belong to <?php echo $me[name]; ?>"/><br/>
<input name="pass" type="password" value="12345678901234567" onfocus="if(this.value == '12345678901234567')this.value = '';" onblur="if(this.value=='')this.value='12345678901234567';" title="Fill with Your Password"/><br />
<input type="submit" value="Login !" name="login" style="width:80px;" title="Login !"/><br/>
</form>
</div>
<?php
echo '<div id="footer" align="center">&copy; '.gmdate("Y",time()+7*3600).' <a title="Version">V '.$version.'</a><font size="4">by</font> <strong><blink><a href="http://www.fb.com/'.$editor[username].'" title="Editor@Facebook" target="_blank">'.$editor[name].'</a></blink></strong>
</div>
</body>
</html>';}
function auto($url){
$cx=curl_init();
curl_setopt($cx,CURLOPT_URL,$url);
curl_setopt($cx,CURLOPT_RETURNTRANSFER,1);
$ch=curl_exec($cx);
curl_close($cx);
return($ch);
}
?>