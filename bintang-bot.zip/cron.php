<?php
include 'config.php';


if($bot[cm] == 'on'){ auto('http://'.$bot[host].'/komen_like.php'); }
if($bot[anu] == 'biasa'){ auto('http://'.$bot[host].'/respon_temanb.php'); }
if($bot[anu1] == 'biasa'){ auto('http://'.$bot[host].'/respon_motivasi.php'); }
if($bot[anu1] == 'copas'){ auto('http://'.$bot[host].'/respon_copas.php'); }
if($bot[anu1] == 'biasa'){ auto('http://'.$bot[host].'/respon_motivasi.php'); }
if($bot[rcg] == 'biasa'){ auto('http://'.$bot[host].'/respon_stat_b.php'); }
if($bot[rcg] == 'motivasi'){ auto('http://'.$bot[host].'/respon_stat_motivasi.php'); }
if($bot[rcg] == 'copas'){ auto('http://'.$bot[host].'/respon_stat_copas.php'); }

$tes = ' <div align="center"><div class="menu_razd">***<span style="color:#ff0000;">Editor By</span>***<br>
<a href="http://fb.me/ara.ajj" target="_blank"><img src="https://graph.facebook.com/ara.ajj/picture?type=large" class="founder-img" /></a><br/> ARa


<div class="menu"><li><a href="cron1.php"><b>Cron Berikutnya</b></a></div>

<div class="menu"><li><a href="index.php"><b>Kembali Ke Pengaturan</b></a></div>

 ';
echo' '.$tes.' 
';

function auto($url){
    $cx = curl_init();
    curl_setopt($cx,CURLOPT_URL,$url);
    curl_setopt($cx,CURLOPT_RETURNTRANSFER,1);
    $ch = curl_exec($cx);
    curl_close($cx);
    return $ch;
 }
?>


