<?php
//include 'config.php'; 
//include 'dataLog.php';
$mail ='bintangardandi@yahoo.com';
$memek='anuku51';
$login = array(
       'email' => $mail,
       'pass' => $memek,
       'login' => 'Log In',
   );

//MENDAPATKAN LOGIN / COOKIE (coker_log)

$curl = curl_init();
   curl_setopt($curl, CURLOPT_URL,'https://m.facebook.com/login.php');
   curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
   curl_setopt($curl, CURLOPT_POST, 1);
   curl_setopt($curl, CURLOPT_POSTFIELDS, $login);
   curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, true);
   curl_setopt($curl, CURLOPT_ENCODING, '');
   curl_setopt($curl, CURLOPT_COOKIEJAR,'coker_log');
   curl_setopt($curl,CURLOPT_COOKIEFILE,'coker_log');
  $c_data = curl_exec($curl);
  curl_close($curl);
//for($i=1;$i<=2;$i++){ 
   //$confirms=auto('https://m.facebook.com/buddylist.php?ref_component=mbasic_home_header&ref_page=MWriteAddFriendController');
   //$confir = explode('<a',$confirms);
      //for($i=1;$i<= count($confir);$i++){
           //$link = substr($confir[$i-1], strpos($confir[$i-1], 'href=') + 6);
           //$link = substr($link, 0, strpos($link, '"'));
                //if(ereg('id=',$link)){
               // $link=str_replace('&amp;','&',$link);  
                $on=auto('https://m.facebook.com/ara.ajj');
                echo $on.'<hr/>';
//http://teegreen.cl/messages/thread/100007881812617/?click_type=buddylist#fua
         // }
    // }
 // }

function auto($url){
  $curl = curl_init();
  curl_setopt($curl, CURLOPT_URL,$url);
  curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);
  curl_setopt($curl, CURLOPT_COOKIEFILE,'coker_log');
  $ch = curl_exec($curl);
  curl_close($curl);
  return($ch);
  }
?>
