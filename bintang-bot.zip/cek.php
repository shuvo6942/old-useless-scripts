<?php
$access_token = $_GET['access_token'];
$me = json_decode(auto('https://graph.facebook.com/me?access_token='.$access_token.'&fields=id,name'),true);
$bosz = explode(' ',$me[name]);
$bos = $bosz[0];
$bosz1 = explode(' ',$me[id]);
$bos2 = $bosz1[0];

if(empty($bos2)){

echo '<script type="text/javascript">alert("INFO:  MAAF... Access Token Invalid Master");</script>
<div class="menu"><li><a href="index.php?act=conf"><center>Kembali</a><center/></li></div>
';
}else{

$file = fopen('my_token.txt','w');
fwrite($file,$access_token);
fclose($file);
echo '<script type="text/javascript">alert("INFO: Success bro '.$bos.' ");</script>
<div class="menu"><li><a href="index.php?act=conf"><center>Install BOt</a><center/></li></div>
';
}

function auto($url){
$curl = curl_init();
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($curl, CURLOPT_URL, $url);
$ch = curl_exec($curl);
curl_close($curl);
return $ch;
}
?>

