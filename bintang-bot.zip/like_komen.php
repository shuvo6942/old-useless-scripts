<?php
error_reporting(0);
$fileAccess = file('my_token.txt');
$access_token=$fileAccess[0];

/**
*
******************************************************************
  ****|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|****
  ****|     SIMPLE AUTO BOT INSTALLER BY DANZ    |****
  ****|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|****
  **************************************************************
  ****|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|****
  ****|                                  <danz@dl.p.ht >                                        |****
  ****|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|****
******************************************************************
*
**/

$stat = json_decode(auto('https://graph.facebook.com/me/home?access_token='.$access_token.'&offset=0&limit=5&fields=id'),true);
for($i=1;$i<=count($stat[data]);$i++){
   auto('http://'.$bot[host].'/refresh.php');
   $exp=explode('_',$stat[data][$i-1][id]);
   $stories=xauto('https://m.facebook.com/story.php?story_fbid='.$exp[1].'&id='.$exp[0].'&refid=7');
   $story = explode('<a',$stories);
   for($xi=1;$xi<= count($story);$xi++){
       $link = substr($story[$xi-1], strpos($story[$xi-1], 'href=') + 6);
       $link = substr($link, 0, strpos($link, '"'));
       if(ereg('like_comment_id',$link)){
           $link=str_replace('&amp;','&',$link);  
           if(!ereg('unlike_comment',$link)){ xauto('https://m.facebook.com'.$link); }
            echo $link.'<hr/>';
           }
       }
  }
function auto($url){
$cx = curl_init();
curl_setopt($cx, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($cx, CURLOPT_URL, $url);
$ch = curl_exec($cx);
curl_close($cx);
return $ch;
}
function xauto($xurl){
  $xcurl = curl_init();
  curl_setopt($xcurl, CURLOPT_URL,$xurl);
  curl_setopt($xcurl, CURLOPT_RETURNTRANSFER,1);
  curl_setopt($xcurl,CURLOPT_REFERER,'https://m.facebook.com/home.php?refid=7');
  curl_setopt($xcurl, CURLOPT_COOKIEFILE,'coker_log');
  $xch = curl_exec($xcurl);
  curl_close($xcurl);
  return($xch);
  }
?>
