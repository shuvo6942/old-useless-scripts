﻿<?php
error_reporting(0);


         //*****************************\\ 
        //******Editor By_Ara***********\\
       //**http://facebook.com/ara.ajj***\\
      //*********************************\\
// Dilararang mengubah tulisan ini jika anda masih merasa manusia :p
$fileAccess = file('my_token.txt');
$access_token=$fileAccess[0];
$me = json_decode(auto('https://graph.facebook.com/me?access_token='.$access_token.'&fields=id'),true);
$stat = json_decode(auto('https://graph.facebook.com/me/home?fields=id&access_token='.$access_token.'&offset=0&limit=10'),true);
$log = json_encode(file('likecom'));
for($i=1;$i<=count($stat[data]);$i++){
$com = json_decode(auto('https://graph.facebook.com/'.$stat[data][$i-1][id].'/comments?access_token='.$access_token.'&limit=500&fields=id,message,from'),true);
if(count($com[data]) > 0){
for($c=1;$c<=count($com[data]);$c++){
$dat = explode($com[data][$c-1][id],$log);
if(count($dat) > 1){
echo'Done<br/>';
}else{
$logx = $com[data][$c-1][id].'__';
$logy = fopen('likekom','a');
fwrite($logy,$logx);
fclose($logy);
$nama = '  @['.$com[data][$c-1][from][id].':1]';








if($com[data][$c-1][from][id] != $me[id]) {

$ara = auto('https://graph.facebook.com/'.$com[data][$c-1][id].'/likes?access_token='.$access_token.'&method=post');
echo' '.$com[data][$c-1][from][name].' => success <hr/><br/> ';

}
}
}
}
}

function auto($url){
$curl = curl_init();
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($curl, CURLOPT_URL, $url);
$ch = curl_exec($curl);
curl_close($curl);
return $ch;
}



?>

