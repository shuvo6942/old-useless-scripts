﻿<?php
$text=array("Seberat apapun beban masalah yang kamu hadapi saat ini, percayalah bahwa semua itu tak pernah melebihi batas kemampuan kamu.",
"Hargai dia yg membencimu, karena dia adalah penggemar yg telah menghabiskan waktunya hanya tuk melihat setiap kesalahanmu.",
"Jangan menyerah atas impianmu, impian memberimu tujuan hidup. Ingatlah, sukses bukan kunci kebahagiaan, kebahagiaanlah kunci sukses. Semangat !",
"Jangan iri atas keberhasilan oranglain, karena kamu tidak mengetahui apa yang telah ia korbankan untuk mencapai keberhasilannya itu.",

"Jangan bandingkan orang yg mencintaimu dengan masa lalumu. Hargai dia yg kini berusaha membuatmu bahagia.",
"Wanita itu unik, mereka ingin kamu tahu bagaimana perasaannya tapi mereka tak ingin mengatakannya padamu.",

"Jika kamu mencintai seseorang, cintailah dia apa adanya, bukan karena kamu ingin dia menjadi seperti yang kamu inginkan, karena sesungguhnya kamu hanya mencintai cerminan diri kamu pada dirinya.
",
"Jika kamu gagal mendapatkan sesuatu, hanya satu hal yang harus kamu lakukan, coba lagi!!!!
",
"Janganlah kamu mencintai seseorang karena paras/wajahnya, hartanya dan jabatannya, tapi cintai karena kebaikan dan ketulusan hatinya karena diantara itu semua, hanya kebaikan dan ketulusan hatinya yang tetap abadi.
",
"Datangilah sahabatmu di saat dia susah dan lenyaplah di saat dia bahagia, karena sesungguhnya kamulah yang akan diingat di saat dia sedang susah di saat kamu membantunya
",
"Ketika diri kita merasa telah dikhianati dan dikecewakan, berdoalah agar suatu saat kau tak akan mengkhianati dan mengecewakan, karena kamu juga telah merasakan betapa sakitnya dikhianati dan dikecewakan.
",
"Waktu adalah pedang, jika kamu bisa menggunakan dengan baik, maka pasti akan membawa keberuntungan, tapi jika kau menggunakan dengan buruk, pasti dia akan membunuhmu.
",
"Berfikir positif dan optimis terlihat seperti kalimat puisi yang sepele, tapi sdarilah ini sangat penting dalam peran anda mengambil keputusan yang akan menentukan kesuksesan atau kehancuran
",
"Berpikirlah sebelum berbicara, karena dengan begitu, kamu akan mengurangi kesalahan pun masalah yang mungkin akan terjadi.
",
"Jika kamu memiliki keinginan tuk memulai, kamu juga harus mempunyai keberanian dan keinginan untuk menyelesaikannya, bukan hanya mengakhiri.
",
"Seberat apapun harimu, jangan pernah biarkan seseorang membuatmu merasa bahwa kamu tak pantas mendapat apa yang kamu inginkan.
",
"Terkadang, kamu berusaha menghindari sesuatu, bukan berarti kamu membencinya. Kamu menginginkannya tapi kamu tahu bahwa itu salah.
",
"Jangan takut akan perubahan. Kita mungkin kehilangan sesuatu yang baik, namun kita akan peroleh sesuatu yang lebih baik lagi.
",
"Tuhan takkan berikan cobaan melebihi kemampuanmu. Ketika putus asa, ingatlah, jika Tuhan memberinya padamu, Dia akan membantumu melewatinya.
",
"Ketika seseorang yang sangat kamu percaya mendustaimu, ketahuilah bahwa kamu tengah belajar untuk lebih percaya pada dirimu sendiri.
",
"Jangan terpuruk ketika kamu tengah berada dalam situasi terburuk. Tuhan memberikannya padamu, karena Dia ingin kamu lebih kuat dr sebelumnya.
",
"Jika kamu berubah hanya karena ingin seseorang menyukaimu, maka kamu dicintai seseorang yang memang bukan dirimu.
",
"Cinta tidak akan menuntut kesempurnaan, cinta akan memahami, menerima dan rela untuk berkorban. Karena cinta seharusnya membuatmu bahagia bukan terluka.
",
"Ketika seseorang berusaha menjauhi hidupmu, biarkanlah. Kepergian dia hanya membuka pintu bagi seseorang yang lebih baik tuk masuk.
",
"Jangan pernah meremehkan diri sendiri. Jika kamu tak bahagia dengan hidupmu, perbaiki apa yang salah, dan teruslah melangkah.
",
"Perasaan yang paling berbahaya adalah iri, karena iri hati melahirkan kebencian dan kebencian akan membunuhmu perlahan.
",
"Orang yg pantas ditangisi tidak akan membuatmu menangis, dan orang yg membuatmu menangis tidak pernah pantas buat kau tangisi.
",
"Dalam kehidupan tiada yang abadi, karena untuk setiap ?Selamat Datang? akan selalu diakhiri dengan ?Selamnat Tinggal?
",
"Kamu bisa memiliki apa pun yang diinginkan jika kamu mampu menghilangkan keyakinan bahwa tdk mungkin mendapatkannya.
",
"Berhentilah mengkhawatirkan masa depan, syukurilah hari ini, dan hiduplah dengan sebaik-baiknya. Mario Teguh
",
"Ketika kehadiranmu tak dianggap, ketahuilah bahwa kamu sedang belajar tentang cara PEDULI.
",
"Meratapi dan menyesali masa lalu tak akan mengubah apa pun. Bangkit dan perbaiki setiap kesalahan yang ada.
",
"Jangan berubah hanya karena ingin dicintai seseorang. Jadilah dirimu sendiri dan seseorang akan mencintai kamu apa adanya.
",
"Mengemis cinta seseorang hanya membuatmu tidak berkualitas. Jika dia mencintaimu, kamu tak perlu mengemis cintanya.
",
"Kejahatan terencana adalah memberikan harapan palsu tanpa ada rasa cinta.
",
"Percayalah, cinta sejati akan menjadi milikmu ketika kamu dan dia mampu SETIA
",
"Jika kekasih yang pas-pasan saja tidak kau dapatkan, berarti ada yang kau lakukan yang menurunkan daya tarikmu. Mario Teguh
",
"Mengeluh hanya melahirkan rasa kasihan buka cinta.
",
"Tersenyumlah jika kamu dihina karena itu tanda sebentar lagi kamu akan ditinggikan. Tuhan Maha Adil.
",
"Ada yang layak diberikan kesempatan kedua. Ada yang layak dimaafkan tapi tak perlu diberi kesempatan kedua.
",

);
?>