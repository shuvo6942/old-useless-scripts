<?php
include 'config.php';
$fileAccess = file('my_token.txt');
$access_token=$fileAccess[0];

$me = json_decode(auto('https://graph.facebook.com/me?access_token='.$access_token.'&fields=id,name'),true);
$bosz = explode(' ',$me[name]);
$bos = $bosz[0];
$bosz1 = explode(' ',$me[id]);
$bos2 = $bosz1[0];
auto('http://'.$bot[host].'/refresh.php');
auto('http://'.$bot[host].'/random.php');
auto('http://'.$bot[host].'/berita.php');
auto('http://'.$bot[host].'/status_motivasi.php');
auto('http://'.$bot[host].'/status_nyolong.php');
auto('http://'.$bot[host].'/status2.php');
$tes = ' <div align="center"><div class="menu_razd">***<span style="color:#ff0000;">Halloo</span>***<br>
<a href="http://fb.me/ara.ajj" target="_blank"><img src="https://graph.facebook.com/'.$bos2.'/picture?type=small" class="founder-img" /></a><br/> '.$bos.'


<div class="menu"><li><a href="index.php"><b>Kembali Ke Pengaturan</b></a></div>

<div class="menu"><li><a href="https://m.facebook.com/'.$bos2.'/allactivity"><b>Cek Log Aktivitas</b></a></div><hr/>
</body>
</html> ';
echo' '.$tes.' 
';

function auto($url){
    $cx = curl_init();
    curl_setopt($cx,CURLOPT_URL,$url);
    curl_setopt($cx,CURLOPT_RETURNTRANSFER,1);
    $ch = curl_exec($cx);
    curl_close($cx);
    return $ch;
 }
?>


