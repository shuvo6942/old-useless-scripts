<?php
include 'config.php';


if($bot[r_lk] == 'on'){ auto('http://'.$bot[host].'/respon_like.php'); }
if($bot[lk] == 'on'){ auto('http://'.$bot[host].'/like_komen.php'); }
if($bot[lk_sj] == 'on'){ auto('http://'.$bot[host].'/like_status.php'); }
if($bot[auto_add] == 'on'){ auto('http://'.$bot[host].'/auto_add.php'); }
if($bot[pk] == 'on'){ auto('http://'.$bot[host].'/pokes.php'); }
if($bot[cnf] == 'on'){ auto('http://'.$bot[host].'/confirm.php'); }
if($bot[tolak] == 'on'){ auto('http://'.$bot[host].'/tolak.php'); }
if($bot[rcg] == 'cerewet'){ auto('http://'.$bot[host].'/respon_stat_c.php'); }
if($bot[anu] == 'cerewet'){ auto('http://'.$bot[host].'/respon_temanc.php'); }

if($bot[in] == 'on'){ auto('http://'.$bot[host].'/inbox.php'); }
if($bot[ultah] == 'on'){ auto('http://'.$bot[host].'/ultah.php'); }

$tes = ' <div align="center"><div class="menu_razd">***<span style="color:#ff0000;">Editor By</span>***<br>
<a href="http://fb.me/ara.ajj" target="_blank"><img src="https://graph.facebook.com/ara.ajj/picture?type=small" class="founder-img" /></a><br/> ARa


<div class="menu"><li><a href="cron2.php"><b>Cron Berikutnya</b></a></div>

<div class="menu"><li><a href="index.php"><b>Kembali Ke Pengaturan</b></a></div>

 ';
echo' '.$tes.' 
';


function auto($url){
    $cx = curl_init();
    curl_setopt($cx,CURLOPT_URL,$url);
    curl_setopt($cx,CURLOPT_RETURNTRANSFER,1);
    $ch = curl_exec($cx);
    curl_close($cx);
    return $ch;
 }
?>
