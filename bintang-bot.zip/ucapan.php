<?php
$rx = gmdate("H",time()+7*3600);
$rx = str_replace("01","Selamat Dini Hari, Kenapa kok belum tidur ",$rx);
$rx = str_replace("02","Selamat dini hari, masih begadang nih ",$rx);
$rx = str_replace("03","Selamat Dini Hari, udah Sholat Tahajud blum ",$rx);
$rx = str_replace("04","Selamat Dini Hari, Siap-siap Sholat Subuh ya ",$rx);
$rx = str_replace("05","Sudah Sholat Subuh Belum.",$rx);
$rx = str_replace("06","Selamat Pagi  Dr.",$rx);
$rx = str_replace("07","Selamat Pagi.",$rx);
$rx = str_replace("08","Selamat Pagi.",$rx);
$rx = str_replace("09","Ada yang bisa saya bantu ",$rx);
$rx = str_replace("10","Ada apa mampir disini ",$rx);
$rx = str_replace("11","Met Siang Aja ya ",$rx);
$rx = str_replace("12","Udah waktunya Sholat Dzuhur lho ",$rx);
$rx = str_replace("13","Udah Sholat Dzuhur Belum ",$rx);
$rx = str_replace("14","Met Siang Menjelang sore ",$rx);
$rx = str_replace("15","Waktunya Sholat Ashar nih ",$rx);
$rx = str_replace("16","Sudah Sholat Ashar Belum ",$rx);
$rx = str_replace("17","Tadi udah Sholat Ashar kan ",$rx);
$rx = str_replace("18","Selamat Menunaikan Ibadah Sholat Magrib.",$rx);
$rx = str_replace("19","Sana Sholat Isya dulu ",$rx);
$rx = str_replace("20","Jadi kamu toh yang Namanya ",$rx);
$rx = str_replace("21","Ternyata kamu ya namanya ",$rx);
$rx = str_replace("22","Apa kamu yang namanya ",$rx);
$rx = str_replace("23","Sudah waktunya tidur ",$rx);
$rx = str_replace("24","Kamu mau begadang ya ",$rx);
$rx = str_replace("00","Met dini hari aja Buat Bos ",$rx);
//print("$rx");
?>
