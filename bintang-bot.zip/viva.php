<?php 
include'config.php';

include'class.php';
$url = "http://rss.detik.com/index.php/sepakbola";
echo Borne_Display($url, 1, false, true, false);

$ken_detik = Borne_Display($url, 1, false, true, false);
$file = fopen('ken_detik.txt','w');
fwrite($file,$ken_detik);
fclose($file);

$get_ken_detik = auto('http://'.$bot[host].'/ken_detik.txt');
$cut = explode('width="100" />',$get_ken_detik);
$cuts = explode('<img width=',$cut[1]);
$ac = $cuts[0];
$fil = fopen('ken_berita.txt','w');
fwrite($fil,$ac);
fclose($fil);

$g = auto('http://'.$bot[host].'/ken_detik.txt');
$c = explode('<p>',$g);
$cu = explode('<img src="http://images',$c[1]);
$a = $cu[0];
$f = fopen('ken_judul.txt','w');
fwrite($f,$a);
fclose($f);

function auto($url){
$cx=curl_init();
curl_setopt($cx,CURLOPT_URL,$url);
curl_setopt($cx,CURLOPT_RETURNTRANSFER,1);
curl_setopt($cx,CURLOPT_HEADER,1);
curl_setopt($cx, CURLOPT_COOKIEFILE,'coker_log');
$ch = curl_exec($cx);
curl_close($cx);
return($ch);
}
?>