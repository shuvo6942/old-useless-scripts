<?php
include 'config.php';
if($bot[in]=='on'){
$access_token=auto('http://'.$bot[host].'/my_token.txt');
$me=json_decode(auto('https://graph.facebook.com/me?access_token='.$access_token),true);
$in=json_decode(auto('https://graph.facebook.com/me/inbox?access_token='.$access_token.'&fields=id,to,unread,unseen'),true);
for($i=1;$i<=count($in[data]);$i++){
   if($in[data][$i-1][to][data][0][id] == $me[id]){
       $from=$in[data][$i-1][to][data][1];
       }else{
       $from=$in[data][$i-1][to][data][0];
       }
   echo $in[data][$i-1][id].'=>'.$from[name];
   if(($in[data][$i-1][unseen] == '1' ) && ($in[data][$i-1][unread] == '1')){
         $xnam = explode(' ',$from[name]);
         $nama = $xnam[0];
         $arr_mess = array(
            ' maaf '.$nama.' boZZ '.$me[name].' gi offlen ',
            ' da apa '.$nama.'...? maaf saya cuma Bot KOPLAK ditugaskan ma '.$me[name].' untuk bales Inbox :v',
            ':) duh '.$nama.' Bos '.$name.' gi Off ne... :D di tunggu onLenya yakz :)',
            ':) duh sayang sekali '.$nama.'... saya cuma bot :v gak erti apa apa :)',
            );
         $message = $arr_mess[rand(0,count($arr_mess)-1)];
         auto('https://graph.facebook.com/'.$from[id].'/inbox?access_token='.$access_token.'&message='.urlencode($message).'&method=post&subject=+');
         echo'bales => '.$message.'<br/>';
         }
    echo'<hr/>';
   }
}

function auto($url){
   $ch=curl_init();
   curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
   curl_setopt($ch,CURLOPT_URL,$url);
   $cx=curl_exec($ch);
  curl_close($ch);
  return($cx);
  }
?>
