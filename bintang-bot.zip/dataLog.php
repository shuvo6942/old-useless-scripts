<?php
$dataLog = array( "host" =>  "m.ardandi.net/bi/",
"pass" => "anuku51",
"email" => "bintangardandi@yahoo.com",
);
?>