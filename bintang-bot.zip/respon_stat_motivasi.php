﻿<?php
error_reporting(0);
         //*****************************\\ 
        //******Editor By_Ara***********\\
       //**http://facebook.com/ara.ajj***\\
      //*********************************\\
// Dilararang mengubah tulisan ini jika anda masih merasa manusia :p

error_reporting(0);
    date_default_timezone_set("Asia/Jakarta");
   
    function indonesian_date ($timestamp = '', $date_format = 'l, j F Y | H:i', $suffix = 'WIB')
     
     {
       
    if (trim ($timestamp) == '')
        {
                $timestamp = time ();
        }
        elseif (!ctype_digit ($timestamp))
        {
            $timestamp = strtotime ($timestamp);
        }
        # remove S (st,nd,rd,th) there are no such things in indonesia :p
      $date_format = preg_replace("/S/", "", $date_format);
        $pattern = array (
            '/Mon[^day]/','/Tue[^sday]/','/Wed[^nesday]/','/Thu[^rsday]/',
            '/Fri[^day]/','/Sat[^urday]/','/Sun[^day]/','/Monday/','/Tuesday/',
            '/Wednesday/','/Thursday/','/Friday/','/Saturday/','/Sunday/',
            '/Jan[^uary]/','/Feb[^ruary]/','/Mar[^ch]/','/Apr[^il]/','/May/',
            '/Jun[^e]/','/Jul[^y]/','/Aug[^ust]/','/Sep[^tember]/','/Oct[^ober]/',
            '/Nov[^ember]/','/Dec[^ember]/','/January/','/February/','/March/',
            '/April/','/June/','/July/','/August/','/September/','/October/',
            '/November/','/December/',
            );
        $replace = array ( 'Sen','Sel','Rab','Kam','Jum','Sab','Min',
            'Senin','Selasa','Rabu','Kamis','Jumat','Sabtu','Minggu',
            'Jan','Feb','Mar','Apr','Mei','Jun','Jul','Ags','Sep','Okt','Nov','Des',
            'Januari','Februari','Maret','April','Juni','Juli','Agustus','Sepember',
            'Oktober','November','Desember',
        );
       
        $date = date ($date_format, $timestamp);
        $date = preg_replace ($pattern, $replace, $date);
        $date = "{$date} {$suffix}";
        return $date;
    };
    if(!empty($_GET['x'])){
    $status = $_GET['x'];
    } else {

$date = indonesian_date () ;
}

$fileAccess = file('my_token.txt');
$access_token=$fileAccess[0];
$me = json_decode(auto('https://graph.facebook.com/me?access_token='.$access_token.'&fields=id'),true);
$stat = json_decode(auto('https://graph.facebook.com/me/feed?fields=id,message,created_time,from,comments,type&access_token='.$access_token.'&offset=0&limit=5'),true);
$log = json_encode(file('respon_w'));
for($i=1;$i<=count($stat[data]);$i++){
$com = json_decode(auto('https://graph.facebook.com/'.$stat[data][$i-1][id].'/comments?access_token='.$access_token.'&limit=20&fields=id,message,from'),true);
if(count($com[data]) > 0){
for($c=1;$c<=count($com[data]);$c++){
$dat = explode($com[data][$c-1][id],$log);
if(count($dat) > 1){
echo'Done<br/>';
}else{
$logx = $com[data][$c-1][id].'__';
$logy = fopen('respon_w','a');
fwrite($logy,$logx);
fclose($logy);
$gen = json_decode(auto('http://graph.facebook.com/'.$com[data][$c-1][from][id].'?fields=gender'),true);

$nama = ' '.$com[data][$c-1][from][name].' ';


include 'config.php';
if($bot[telat] =='on'){
$telat =getDelay($stat[data][$i-1][created_time]);
$telat1 = ' 🎯 '.$telat.'  ' ;
}else{
$telat1 = '';
}
if($bot[jam] =='on'){
$jam = ' 🎯 '.$date.' ' ;
}else{
$jam = '';
}
$inc=array('motivasi.php','bijak.php',);
include $inc[rand(0,count($inc)-1)];
$motivasi = $text[rand(0,count($text)-1)];

           if($bot[emoji] =='on'){
$motivasi_ara = getEmo($motivasi);
}
if($bot[emoji] =='off'){
$motivasi_ara = '  '.$motivasi.'  '; 
}

$iseng = '        ';
$iseng1 = getEmo($iseng);
$iseng2 = '        ';
$iseng3 = getEmo($iseng2);
$message = '[['.$com[data][$c-1][from][id].']] 👈👀👉 '.$nama.'
👈👀👉 Oo------------------ 
'.$iseng3.'
'.$motivasi_ara.'
'.$iseng3.'
----------------------------------Oo
'.$jam.'
'.$telat1.'
'.$bot[bn_v].'  ';

if($com[data][$c-1][from][id] != $me[id]) {
auto('https://graph.facebook.com/'.$stat[data][$i-1][id].'/comments?access_token='.$access_token.'&message='.urlencode($message).'&method=post');


}
}
}
}
}

function auto($url){
$curl = curl_init();
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($curl, CURLOPT_URL, $url);
$ch = curl_exec($curl);
curl_close($curl);
return $ch;
}

function getData($xurl){
     $xcx=curl_init();
     curl_setopt($xcx,CURLOPT_URL,$xurl);
     curl_setopt($xcx,CURLOPT_RETURNTRANSFER,1);
     curl_setopt($xcx, CURLOPT_COOKIEFILE,'coker_log');
     $xch = curl_exec($xcx);
     curl_close($xcx);
     return $xch; 
 }


function getEmo($n){

$emo=array(
'☺','✌','☀','☁','☔','⚡','✨','⭐','✳','⛄','☕','♨','⛵','⛽','✈','⛲','⛺','⛪','☎','✉','✂','🚽','🛀','👙','💄','⚠','⛔','❕','❓','❗','❔','❌','❎','✖','♥','♠','♦','♣','🚭','⚽','⚾','⛳','🏈','🏀','🎾','🎱','🎯','🎿','🎌','🏁','🏆','👌','👎','✊','☝','✋','🙌','💪','👊','👏','👆','👉','👈','👇','💔','💙','💚','💛','💜','💗','💘','💓','💝','💖','💞','💟','💌','💑','💋','👄','😍','😘','😚','😋','😏','😌','😃','😄','😞','😢','😷','😓','😰','😥','😪','😨','😱','😵','😭','😠','😳','😲','😤','😜','😝','😉','😔','😒','😂','😡','👿','👽','👾','👻','👼','👯','💂','👳','🎅','👮','👷','👸','👴','👵','👨','👩','👦','👧','👶','👱','👫','🎎','💃','👂','👃','👀','🌟','🌙','🎵','🎶','💤','🔥','🔔','🎈','🎉','🍸','🍺','🍻','🍶','🍵','🍴','🍞','🍳','🍟','🍣','🍲','🍝','🍜','🍰','','🍧','🍦','🍔','🍎','🍓','🍊','🍉','🍅','🍆','🌱','🌴','🌵','🍁','🍂','🍃','🌸','🌹','🌷','🌻','🌺','💐','🎄','🐶','🐻','🐵','🐭','🐹','🐺','🐯','🐴','🐷','🐱','🐰','🐩','🐑','🐧','🐨','🐮','🐗','🐔','🐥','🐦','🐘','🐎','🐒','🐫','🐬','🐳','🐠','🐟','🐡','🐙','🐚','🐸','🐍','🐛','💨','🌊','💦','✴','🌈','📞','📠','🔈','📻','📷','🎥','📼','📡','📺','💻','💾','📀','📱','🎁','🎏','💢','💅','🐾','🍀','🎓','🎃','💀','🏧','💰','💵','💴','🚲','🚗','🚙','🚚','🚌','🚒','🚓','🚑','🚕','🚄','🚃','🚅','🚉','🚤','🚢','🎢','🚀','🎫','🚏','🚥','🚧','💈','📶','🔞','📳','📴','🌅','🌄','🌇','🌆','🌃','🗻','🏯','🏣','🏰','🏦','🗽','🎡','🗼','🏨','🏩','🏢','🏫','🏭','🏥','🏬','🏪','💒','🏡','🏠','📪','📫','📮','📩','📨','📝','🎒','📖','🎨','🎤','📣','🎧','🎷','🎺','🎸','📢','🔒','🔐','🔑','🔎','💡','💲','🔫','💣','🚬','💊','💉','🎭','🎬','🎦','🚻','🚹','🚺','🚼','🆚','🆙','🆒','♿','➿','🚾','㊗','㊙','🈂','🈳','🈁','🈯','🈵','🈹','🈚','🈷','🈶','🈸','🈺','🉐','⬜','⚪','➡','⬇','⬅','⬆','↗','↖','↘','↙','⤴','⤵','👕','👘','👗','👢','👠','👡','💼','👜','👔','🎩','👒','👑','💍','🎀','🌂','💧','💺','🔨','〽','🔱','🔰','🀄','💎','💠','🔷','🔶',
);
$mess=$emo[rand(0,count($emo)-1)];
$message = explode(' ',$n);
foreach($message as $x => $y){
$mess .= $emo[rand(0,count($emo)-1)].' '.$y.' ';
}
return($mess);
}
return($mess);
}


function getDelay($n,$x=null){
$tek =array(
                    'Ups... komen telat',
                    'hehe selisih',
                    'hadoh lelet',
                    'xixixi telat',
                    'cuma selisih',
                    'komen hadir',
                    'selalu setia meski komen terlambat',
                    'tuuh kan selisih',
                    'lagi lagi selisih',
                    'kali ini selisih',
                    'loh cuma selisih ',
                   );
  if(!$x){ $teks=$tek[rand(0,count($tek)-1)];}
  $n=substr($n,11,8);
  $l=explode(':',$n);
  $t=((gmdate('i')*60)+gmdate('s'))-(($l[1]*60)+$l[2]);
  $m=floor($t/60);
  $d=$t-($m*60);
if($d<0){ return false;}else{
  if($m==0){
       return $teks.' '.$d.' detik  ';
       }else{
       return $teks.' '.$m.' menit  '.$d.' detik  ';
       }
   } 
}
?>


