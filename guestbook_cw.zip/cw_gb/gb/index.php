<?php
/********************************
* CyberWAP Projects
* By. The-Unknown (support@cyberwap.net)
*********************************/

$config = array(
"datafilename" => "dgt4err.txt",
"adminpassword" => "3439c00f0d202cd1fe33262035de233e",
"itemperpage" => 5,
"bgcolor" => "#afcbbb",
"title" => "GuestBook",
"linkable" => 1,
"tagable" => 0,
"imageable" => 0
);


require("../lib/xhtml.inc.php");
require("../lib/dbfile.inc.php");
require("../lib/textformat.inc.php");
require("../lib/mobilebrowser.inc.php");

$page = (isset($_GET["p"]) && is_numeric($_GET["p"])) ? (int) $_GET["p"] : 0;

if(($_SERVER["REQUEST_METHOD"] == "GET") && ($_SERVER["QUERY_STRING"] == "write")) {
    XHeader(false);
    XBegin("<title>{$config["title"]}</title>", "bgcolor=\"green\"");
    print("<form action=\"{$_SERVER["PHP_SELF"]}\" method=\"post\">");
    print("Username:<br/><input name=\"usr\" size=\"16\"/><br/>");
    print("Subject/Link:<br/><input name=\"sbj\"/><br/>");
    //print("Text:<br/><input name=\"txt\" size=\"24\"/><br/>");
    print("Text:<br/><textarea name=\"txt\"></textarea><br/>");
    print("<input type=\"submit\" name=\"submit\" value=\"Write\"/>");
    print("<input type=\"submit\" value=\"View\"/>");
    print("</form>");
    XEnd();
    exit();
}


$dbfile = new CDBFile($config["datafilename"]);

if(($_SERVER["REQUEST_METHOD"] == "POST") && ($_POST["submit"])) {
    if(!($_POST["usr"] && $_POST["txt"])) XDie("Empty Username/Text", "{$_SERVER["PHP_SELF"]}?write");
    
    $set = array(
    "username" => $_POST["usr"],
    "subject" => $_POST["sbj"],
    "text" => stripslashes($_POST["txt"]),
    "time" => time(),
    "browser" => $_SERVER["HTTP_USER_AGENT"],
    "ip" => $_SERVER["REMOTE_ADDR"]
    );
    
    if(strlen($set["subject"]) > 64) $set["subject"] = substr($set["subject"],0,64);
    if(strlen($set["text"]) > 320) $set["text"] = substr($set["text"],0,320);
    
    // Anti Flood
    $row = $dbfile->Select(-1, 1);
    if($lastpost = @unserialize($row[0])) {
        if($lastpost["text"] == $set["text"]) XDie("Flooding Protection!", $_SERVER["PHP_SELF"]);
    }
    
    $dbfile->Insert(serialize($set));
}

XHeader(false);
XBegin("<title>{$config["title"]}</title>", "bgcolor=\"{$config["bgcolor"]}\"");
print("<p><a href=\"{$_SERVER["PHP_SELF"]}?write\">[Write]</a> <a href=\"{$_SERVER["PHP_SELF"]}?p=0\">[Refresh]</a></p>");

$postr = $dbfile->Select(round($page * $config["itemperpage"]), $config["itemperpage"], "DESC");

print("<p>");
foreach($postr as $post) {
    $post = unserialize($post);
    
    $browser = new CMobileBrowser($post["browser"], $post["ip"]);
    $date = date("H:i d-M", $post["time"]);
    $username = htmlspecialchars($post["username"]);
    $subject = htmlspecialchars($post["subject"]);
    $text = htmlspecialchars($post["text"]);
    
    if($config["linkable"]) {
        if(preg_match('#^(http://[^ \"\n\r\t<]*)#is', $subject)) {
            $username = "<a href=\"{$subject}\">{$username}</a>";
            $subject = "";
        }
        Text_Linkable($text);
    }
    
    if($config["tagable"]) {
        Text_Tagable($text);
    }
    
    if($config["imageable"]) {
        Text_Imageable($text, "smiley/");
    }
    
    print("<b><u>{$username}</u></b>".($subject ? " [{$subject}]" : "")."<br/>");
    print("[{$date}] ".htmlspecialchars($browser->displayname)."<br/>");
    print("{$text}<br/>");
    
    print("<br/>");
}
print("</p>");

print("<p>");
if($page > 0) print("<a href=\"{$_SERVER["PHP_SELF"]}?p=".($page-1)."\">[&lt;]</a> "); else print("[&lt;] ");
//Status Page
print(".{$page}.");
if($page < 100) print("<a href=\"{$_SERVER["PHP_SELF"]}?p=".($page+1)."\">[&gt;]</a>"); else print("[&gt;]");
print("</p>");

XEnd();

$dbfile->Close();
exit();
?>