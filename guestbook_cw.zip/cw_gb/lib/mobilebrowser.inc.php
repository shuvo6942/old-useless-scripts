<?php
/********************************
* CyberWAP Projects
* By. The-Unknown (support@cyberwap.net)
*********************************/

if(!defined("MOBILEBROWSER_INCLUDED")) {
define("MOBILEBROWSER_INCLUDED", true);

class CMobileBrowser
{
    var $useragent, $via, $accept, $acceptencoding, $remoteaddr, $xforwardedfor;
    var $type, $model, $displayname;
    
    function CMobileBrowser($ua = "", $ip ="")
    {
        if($ua) {
            $this->useragent = $ua;
            $this->remoteaddr = $ip;
        } else {
            if(isset($_SERVER["HTTP_USER_AGENT"])) $this->useragent = $_SERVER["HTTP_USER_AGENT"];
            if(isset($_SERVER["HTTP_VIA"])) $this->via = $_SERVER["HTTP_VIA"];
            if(isset($_SERVER["HTTP_ACCEPT"])) $this->accept = $_SERVER["HTTP_ACCEPT"];
            if(isset($_SERVER["HTTP_ACCEPT_ENCODING"])) $this->acceptencoding = $_SERVER["HTTP_ACCEPT_ENCODING"];
            if(isset($_SERVER["REMOTE_ADDR"])) $this->remoteaddr = $_SERVER["REMOTE_ADDR"];
            if(isset($_SERVER["HTTP_X_FORWARDED_FOR"])) $this->xforwardedfor = $_SERVER["HTTP_X_FORWARDED_FOR"];
        }
        $this->ParseUserAgent();
    }
    
    function ParseUserAgent()
    {
        $name = $this->GetName($this->useragent);
        $index = strtoupper(substr($name,0,3));
        
        switch($index)
        {
            case "NOK":
                $this->type = "nokia";
                $this->model = substr($name, 5);
                $this->displayname = "N-{$this->model}";
            break;
            
            case "SON":
                $this->type = "sonyericsson";
                $this->model = substr($name, 12);
                $this->displayname = "SE-{$this->model}";
            break;
            
            case "SIE":
                $this->type = "siemens";
                $this->model = substr($name, 4);
                $this->displayname = "SIE-{$this->model}";
            break;
            
            case "SAM":
                $this->type = "samsung";
                $this->model = substr($name, 8);
                $this->displayname = "SAM-{$this->model}";
            break;
            
            case "MOT":
                $this->type = "motorola";
                $this->model = substr($name, 4);
                $this->displayname = "MOT-{$this->model}";
            break;
            
            case "PHI":
                $this->type = "philips";
                $this->model = substr($name, 8);
                $this->displayname = "PHI-{$this->model}";
            break;
            
            case "MOZ":
                $this->type = "mozilla";
                $this->model = "";
                $this->displayname = "Mozilla";
            break;
            
            default:
                $this->displayname = ucfirst($name);
            break;
        }
    }
    
    
    function GetName($ua)
    {
        if(@preg_match('#^([\w|-]+[^\/ ])#i', $ua, $match)) {
            return $match[1];
        } else {
            return false;
        }
    }
}

}
?>