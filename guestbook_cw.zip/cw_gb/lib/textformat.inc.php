<?php
/********************************
* CyberWAP Projects
* By. The-Unknown (support@cyberwap.net)
*********************************/

if(!defined("TEXTFORMAT_INCLUDED")) {
define("TEXTFORMAT_INCLUDED", TRUE);


function Text_Linkable(&$s, $limit = 3)
{
    $s = preg_replace(
            array('#(^|[\n ])([\w]+?://[^ \"\n\r\t<]*)#is', '#(^|[\n ])((www|ftp)\.[^ \"\t\n\r<]*)#is', '#(^|[\n ])([a-z0-9&\-_.]+?)@([\w\-]+\.([\w\-\.]+\.)*[\w]+)#i'),
            array("\\1<a href=\"\\2\">\\2</a>", "\\1<a href=\"http://\\2\">\\2</a>", "\\1<a href=\"mailto:\\2@\\3\">\\2@\\3</a>"),
            $s, $limit);
    return true;
}


function Text_Tagable(&$s, $limit = 3)
{
    $s = preg_replace(
            array('#\[(b|i|u)/(.*?)/(|b|i|u)\]#is', '#\[a/(.*?)/(.*?)/(|a)\]#si'), 
            array("<\\1>\\2</\\1>", "<a href=\"\\2\">\\1</a>"),
            $s);
    return true;
}


function Text_StripTagable(&$s)
{
    $s = preg_replace(
            array('#\[(b|i|u)/(.*?)/(|b|i|u)\]#is', '#\[a/(.*?)/(.*?)/(|a)\]#si'), 
            array("\\2", "\\2"), 
            $s);
    return true;
}

$text_imageabledir = "";
function Text_Imageable(&$s, $dir, $limit = 3)
{
    global $text_imageabledir;
    if(is_dir($dir)) {
        $text_imageabledir = $dir;
        $s = preg_replace_callback('#:(\w+):#', "Text_ImageableCallback", $s, $limit = 3);
        return true;
    } else return false;
}

function Text_ImageableCallback($match)
{
    global $text_imageabledir;
    
    $imgfile = $text_imageabledir.$match[1].".gif";
    if(file_exists($imgfile)) {
        return "<img src=\"{$imgfile}\" alt=\"*{$match[1]}*\"/>";
    } else {
        return $match[0];
    }
}
}
?>