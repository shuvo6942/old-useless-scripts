<?php
/********************************
* CyberWAP Projects
* By. The-Unknown (support@cyberwap.net)
*********************************/

if(!defined("XHTML_INCLUDED")) {
define("XHTML_INCLUDED", TRUE);


function XHeader($cacheable)
{
    header("Content-type: text/html");
    if($cacheable) {
        header("Cache-Control: public");
        header("Pragma: cache");
    } else {
        header("Cache-Control: no-cache, must-revalidate");
        header("Pragma: no-cache");  
    }
}

function XBegin($head, $bodyoptions = "")
{
    print("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n");
    print("<html>\n");
    if($head) print("<head>{$head}</head>\n");
    if($bodyoptions) print("<body {$bodyoptions}>\n"); else print("<body>\n");
}

function XEnd()
{
    print("\n</body>\n");
    print("</html>");
}

function XDie($s, $ref = "")
{
    if(!headers_sent()) {
        XHeader(false);
        XBegin("", "bgcolor=\"#996666\"");
        print("<p>");
        print(htmlspecialchars($s));
        print("</p>");
        if($ref) print("<p><a href=\"{$ref}\">Continue</a></p>"); else print("<p><a href=\"{$_SERVER["PHP_SELF"]}\">Back</a></p>");
        XEnd();
    } else {
        print("<p>");
        print(htmlspecialchars($s));
        print("</p>");
        if($ref) print("<p><a href=\"{$ref}\">Continue</a></p>"); else print("<p><a href=\"{$_SERVER["PHP_SELF"]}\">Back</a></p>");
        XEnd();
    }
    exit();
}

}
?>