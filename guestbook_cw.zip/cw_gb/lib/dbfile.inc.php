<?php
/********************************
* CyberWAP Projects
* By. The-Unknown (support@cyberwap.net)
*********************************/

if(!defined("DBFILE_INCLUDED")) {
define("DBFILE_INCLUDED", TRUE);

class CDBFile
{
    var $filename;
    var $lines;
    var $fp;
    
    function CDBFile($filename)
    {
        $this->fp = fopen($filename, "a+");
        
        if($this->fp) {
            $this->filename = $filename;
        }
    }
    
    function Close()
    {
        if($this->fp) fclose($this->fp);
    }
    
    function Select($offset = 0, $length = 1000, $order = "ASC")
    {
        if(!$this->fp) return false;
        $ar = array();
        
        rewind($this->fp);
        while(!feof($this->fp)) {
            $buff = fgets($this->fp, 8094);
            if($buff == "") continue;
            $buff = $this->TextFilterOutput($buff);
            if($order == "ASC") {
                array_push($ar, $buff);
            } elseif($order == "DESC") {
                array_unshift($ar, $buff);
            }
        }
        
        return array_splice($ar, $offset, $length);
    }
    
    function Insert($s)
    {
        if(!$this->fp) return false;
        fseek($this->fp, 0, SEEK_END);
        return fwrite($this->fp, $this->TextFilterInput($s)."\r\n");
    }
    
    function Update()
    {
        if(!$this->fp) return false;
        
    }
    
    function Delete()
    {
        if(!$this->fp) return false;
        
    }
    
    
    var $textfilter = array(
            "\r" => "\\r",
            "\n" => "\\n",
            );
    
    function TextFilterInput($s)
    {
        return str_replace(array_keys($this->textfilter), array_values($this->textfilter), $s);
    }
    function TextFilterOutput($s)
    {
        return str_replace(array_values($this->textfilter), array_keys($this->textfilter), $s);
    }
}

}
?>