<?php
$file = "error_log";
if (!unlink($file))
  {
  echo ("Error deleting $file");
  }
else
  {
  echo ("Thanks for visit bot.trickwap.net");
  }
?>