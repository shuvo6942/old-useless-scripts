<?php

require 'Unicode2Bijoy.php'; // https://github.com/mirazmac/Unicode2Bijoy
use mirazmac\Unicode2Bijoy;

$str = Unicode2Bijoy::convert("যুক্তাক্ষর প্রিন্ট করা \n খুবই সোজা"); //convert the text

$im = imagecreatetruecolor(300, 300); //create the image

$bg = imagecolorallocate($im, 255, 255, 255); //allocating white background image
$color = imagecolorallocate($im, 0, 0, 255); //color of the text

imagefill($im, 0, 0, $bg);
$fontfile = 'kalpurushANSI.ttf'; //ansi font file

imagettftext ($im , 20 , 0 , 20 , 30 , $color , $fontfile , $str); //write the text on image, you need to have ImageMagick installed

header('Content-type: image/png');

imagepng($im); //output
imagedestroy($im); //free memory
