<?php error_reporting(0);
$accesstoken = $_GET["accesstoken"];
if($accesstoken == "")
{
	session_destroy();
	header("Location: index.php?error=Enter Your Access Token !");
	die();
}
$remove1 = '=';
$remove2 = '&';
preg_match('/'.preg_quote($remove1).'(.*?)'.preg_quote($remove2).'/is', $accesstoken, $accesstokenFiltered);
if(!$accesstokenFiltered[1])
{
	$accesstoken = $accesstoken;
}
else
{
	$accesstoken = $accesstokenFiltered[1];
}
require('php-sdk/facebook.php');

$facebook = new Facebook(array(
   'appId' => '',
   'secret' => '',
   'cookie' => true
));
	try
	{
	   $parameters['access_token'] = $accesstoken;
	   $userData = $facebook->api('/me?fields=id,name', $parameters);
	   $statuses = $facebook->api('/me/feed?limit=5', $parameters);
	   foreach($statuses['data'] as $status)
	   {
	   }
	}
	catch (FacebookApiException $e)
	{
		if($accesstoken == $set[password])
		{
		}
		else
		{
			session_destroy();
			header("Location: index.php?error=Access Token Expired !");
			die();
		}
	}
if($userData)
{
	$user = $userData['id'];
	$handle = fopen('database/'.$user.'', 'w') or die('Error !');
	fwrite($handle, $accesstoken);
	fclose($handle);
}
?>
<?php
$name = $userData['name'];
if($accesstoken == $set[password])
{
	$name = $set[owner_name];
}
include 'header.php';
?>
<center><?php
$success = $_GET["success"];
if($success)
{
   echo '
   <div class="item1" style="display: block !important;visibility: visible !important;">
   '.$success.'
  </div>';
}
?></center>

<center><div class="whole"><div class="menubar"><b><?php echo $name; ?></b></ div><div class="item1">
  </div>
Paste Your Status / Photo Link </div> 

    <form id="search-form" method="get" action="m-comments.php">
    Customs ID : <br/><input class="whole" name="postid" value="" required/>
    <input style="display: none;" name="accesstoken" value="<?php echo $accesstoken; ?>">
    <input class="menu" value="Comment" type="submit"/>
</form>
</center>
</div>
<?php
foreach($statuses['data'] as $status)
{
	echo
'<div class="whole"> <div class="menubar">'.$name.'
</div>
   
<div class="item2"><b>Status :</b> '.$status["message"].'</div>

    
<div class="item1" align="right">    <form id="search-form" method="get" action="m-comments.php">
 <input class="whole" name="postid" value="'.$status["id"].'" required/>
    <input style="display: none;" name="accesstoken" value="'.$accesstoken.'">
    <input class="menu" value="Auto-Cmnt" type="submit"/>
</form>
    </div>
 </div>';
}
?>
<?php
include 'footer.php';
?>