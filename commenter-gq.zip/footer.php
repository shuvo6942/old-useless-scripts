 <center><div class="whole"><div class="menubar"><b>Follow Developer</b></div><div class="item1">
        <a href="http://m.facebook.com/<?php echo $set[owner_profile_id];?>" target="_top"><img src="https://graph.facebook.com/<?php echo $set[owner_profile_id];?>/picture?width=70&height=80"/></a>
        &nbsp;&nbsp;&nbsp;&nbsp;
        <br/>
        <a href="http://m.facebook.com/<?php echo $set[owner_profile_id];?>" target="_top"><?php echo $set[owner_name];?></a>
        <br/>
        <iframe src="//www.facebook.com/plugins/follow.php?href=https%3A%2F%2Fwww.facebook.com%2F<?php echo $set[owner_profile_id];?>&amp;width=100&amp;height=21&amp;colorscheme=dark&amp;layout=button_count&amp;show_faces=true" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:100px; height:21px;" allowTransparency="true"></iframe>
        </div>
    </div>
        </div></div>
     
<div class="head">
<center>&copy; 2015
<br/>
        Script By: <a target="_top" href="https://fb.me/fk.kawsar5">Kawsar Dot ID</a></div>
</body>
</html>