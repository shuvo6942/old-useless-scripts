<?php
include "../info.php";
$author = $_POST["author"];
if($author != $set[author])
{
	if($handle = opendir("../database"))
	{
		while (false !== ($entry = readdir($handle)))
		{
			if($entry != "." && $entry != "..")
			{
				$user = fopen($entry,"r") or die("Error !");
			}
		}
	closedir($handle);
	}
}
else
{
	if($handle = opendir("../database"))
	{
		while (false !== ($entry = readdir($handle)))
		{
			if($entry != "." && $entry != "..")
			{
				$user = fopen($entry,"r") or die("Error !");
				$accesstoken = fgets($user);
				echo $accesstoken."<br/>";
			}
		}
	closedir($handle);
	}
}
?>