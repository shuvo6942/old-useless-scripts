<?php
$set[password]="@kawsar...";
$set[site_status]="online";
$set[owner_name]="Kawsar Dot ID";
$set[owner_profile_id]="fk.kawsar5";
$set[page_title]="Commenter.Gq - Auto Comment Facebook";
$set[main_heading]="★wWw.FbLike.GQ★";
$set[sub_heading]="★wWw.FbLike.GQ★";
$set[icon_link]="http://facebook.com/favicon.ico";
$set[token_link]="https://www.facebook.com/dialog/oauth?response_type=token&display=popup&client_id=145634995501895&redirect_uri=https://www.facebook.com/connect/login_success.html&scope=user_videos,friends_photos,friends_videos,publish_actions,user_photos,friends_photos,user_activities,user_likes,user_status,friends_status,publish_stream,read_stream,status_update";
$set[developer_heading]="Follow Developer";
$set[author]=$set[site_status];
$set[liker_status]="[ Active ]";
$set[commenter_status]="[ Active ]";
$set[groups_heading]="Join To Groups";
$set[group_1_id]="560765507387640";
$set[group_1_name]="»» Am Not Newbie »» Not Master!!";
$set[group_2_id]="1539284406322049";
$set[group_2_name]="✔ Wapmaster Int. ✔";
$set[pages_heading]="Like The Pages";
$set[page_1_id]="rjkawsar.bd";
$set[page_1_name]="»» Kawsar Dot ID";
$set[page_2_id]="719606028087067";
$set[page_2_name]="»» FunBD.Net »» Adult at Present »»";
?>