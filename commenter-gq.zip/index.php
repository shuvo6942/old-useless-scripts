<?php
#Script By : Kawsar Dot ID
#Contact Me : www.facebook.com/FK.KAWSAR5
?>
<?php
session_start();
if($_SESSION['accesstoken'])
{
	$accesstoken = $_SESSION['accesstoken'];
	header("Location: m-commenter.php?accesstoken=".$accesstoken."&session=true");
}
include 'header.php';
?>
<center><div class="whole"><div class="menubar"><b>Method Login</b></div><div class="item1"><a href="https://goo.gl/mJ8YF1" class="menu"><b>Click Here</b></a>
 & Allow Application to the permissions You have to paste that whole URL/ Access Token to the text box below. </b><br/><br/>


<a href="https://m.facebook.com/settings/subscribe/" class="menubar">NB : Before Using Change Your Follower Setting To PUBLIC</a>  <font color="#CC3300"><b>
<?php
    $error = $_GET["error"];
	if($error)
	{
		echo '<hr/>'.$error;
	}
	?>
    </b></font>
    <?php
    if($set[site_status] == 'online')
	{
		echo '
    <form method="get" action="m-commenter.php">
    <br/>
    <b>Input Access Token</b>
 <br/>   <input class="whole" type="text" name="accesstoken" value="" required>
 <br/>
    <input style="margin-top: 3px;" class="menu" type="submit" value="LogIn To Commenter">
    </form>';
	}
	else
	{
		echo '<a>Website Under Construction !<br/>Please Check After Few Minutes !</a>';
	}
	?>
</div>
</div>
</center>

<?php
include 'footer.php';
?>