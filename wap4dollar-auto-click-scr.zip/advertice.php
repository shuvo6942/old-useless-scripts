 <?php

$grab=file_get_contents('http://wap4dollar.com/ad/nonadult/serve.php?id=dtz4yeptvo');

$grab=str_replace('">', '" alt="" height="1" width="1"/>', $grab);
$grab=str_replace('a href', 'img src', $grab);
$grab=preg_replace('|<img src="(.*)</br>|is', '',$grab);
$grab=str_replace("document.write(' ');", "", $grab);
$grab=str_replace("document.write('');", "", $grab);
$grab=str_replace("Daily Updated Sex Site! Only 18+", "", $grab);
$grab=str_replace("Sunny Leone Latest Videos", "", $grab);
$grab=preg_replace('|">(.*)</a>|is', '',$grab);
$grab=str_replace("Best Java Games, Apps Free", "", $grab);
$grab=str_replace("Free Android Apps Downloads", "", $grab);

echo ''.$grab.'';

?>