// this three lines of code will upload an image from any url to the your folder!
 <?php
$url = "http://NEXTMUSICS.COM/data/Pyaar%20Ho%20Gaya%20-%20DJ%20Shadow%20Remix-(NextMusics.Com).mp4
";
$name = basename($url);
file_put_contents("uploads/$name", file_get_contents($url);
?>