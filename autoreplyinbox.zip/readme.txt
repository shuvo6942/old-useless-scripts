-Script Koceng edited By Pubiway
-Support hosting gratis seperti Idhostinger.com, nazuka.net, pubiway.pw
-Gunakan Token dari app xperia
-Tutorial langsung saja ke www.edwinblog.us atau www.emsblue.heck.in
 