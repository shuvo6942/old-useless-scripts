<?php
#-----------------------------------------------------#
# Thanx For : Koceng
# Edited By : Pubiway
# Blog : www.EdwinBlog.Us
#-----------------------------------------------------#


$access_token='Access-Token-Anda';



$me=json_decode(auto('https://graph.fb.me/me?access_token='.$access_token),true);
$in=json_decode(auto('https://graph.fb.me/me/inbox?access_token='.$access_token.'&fields=id,to,unread,unseen'),true);
for($i=1;$i<=count($in[data]);$i++){
   if($in[data][$i-1][to][data][0][id] == $me[id]){
       $from=$in[data][$i-1][to][data][1];
       }else{
       $from=$in[data][$i-1][to][data][0];
       }
   echo $in[data][$i-1][id].'=>'.$from[name];
   if(($in[data][$i-1][unseen] == '1' ) && ($in[data][$i-1][unread] == '1')){
         $minggu = explode(' ',$from[name]);
         $nama = $minggu[0];
         $arr_mess = array(
            'Admin '.$me[name].' sedang offline, silahkan menunggu sampai dia online kembali',
            'Mohon maaf '.$nama.' pengguna '.$me[name].' sedang nonaktif.',
            'Maafin '.$me[name].' ya '.$nama.' , ia sedang tidak online',
            'MAAF! SAYA SEBAGAI ROBOT AKAN MENYAMPAIKAN PESAN '.$nama.' kepada '.$me[name].' ketika ia online nanti',
            ''.$me[name].'  sedang sibuk, silahkan menunggu sampai ia tidak sibuk kembali.',
            );
         $message = $arr_mess[rand(0,count($arr_mess)-1)];
         auto('https://graph.fb.me/'.$from[id].'/inbox?access_token='.$access_token.'&message='.urlencode($message).'&method=post&subject=+');
         echo' Dibalas : <font color="blue"><b>'.$message.'</font></b><br/>';
         }
    echo'<hr color="red">';
   }


function auto($url){
   $ch=curl_init();
   curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
   curl_setopt($ch,CURLOPT_URL,$url);
   $cx=curl_exec($ch);
  curl_close($ch);
  return($cx);
  }
?>