<?php
defined('PAGEDISPLAY') or die('Access Forbidden..!!');
$session_language = isset($_SESSION['language']) ? htmlentities($_SESSION['language']) : 'bangla';
$session_language = strtolower(preg_replace('#([\W_]+)#','-',$session_language));
if ($session_language == "index") 
$session_language = "bangla";
if (file_exists("lang/".$session_language.".php")) {
require("lang/".$session_language.".php");
} else {
require("lang/bangla.php");
}
?>