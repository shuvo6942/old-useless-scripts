<?php
    ob_start();
    echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">' .
         '<html xmlns="http://www.w3.org/1999/xhtml">' .
         '<title>Installation WAP-FTP</title>' . 
         '<style type="text/css">' .
         'a, a:link, a:visited{color: blue;}' .
         'body {font-family: Arial, Helvetica, sans-serif; font-size: small; color: #000000; background-color: #FFFFFF}' .
         'h1{margin: 0; padding: 0; padding-bottom: 4px;}' .
         'h2{margin: 0; padding: 0; padding-bottom: 4px;}' .
         'h3{margin: 0; padding: 0; padding-bottom: 2px;}' .
         'ul{margin:0; padding-left:20px; }' .
         'li{padding-bottom: 6px; }' .
         '.red{color: #FF0000;}' .
         '.green{color: #009933;}' .
         '.blue{color: #0000EE;}' .
         '.gray{color: gray;}' .
         '.pgl{padding-left: 8px}' .
         '.select{color: blue; font-size: medium; font-weight: bold}' .
         '.small{font-size: x-small}' .
         '.st{color: gray; text-decoration: line-through}' .
         '</style>' .
         '</head><body>' .
         '<h2 class="green">WAP-FTP</h2><hr />';

        $db_host = isset($_POST['dbhost']) ? htmlentities(trim($_POST['dbhost'])) : 'localhost';
        $db_name = isset($_POST['dbname']) ? htmlentities(trim($_POST['dbname'])) : 'myftp';
        $db_user = isset($_POST['dbuser']) ? htmlentities(trim($_POST['dbuser'])) : 'root';
        $db_pass = isset($_POST['dbpass']) ? htmlentities(trim($_POST['dbpass'])) : '';
$db_prefix = isset($_POST['dbprefix']) ? htmlentities(trim($_POST['dbprefix'])) : 'myftp_';
$dir_dataftp = isset($_POST['dirdataftp']) ? htmlentities(trim($_POST['dirdataftp'])) : './myftp_tmp';
$admin_pass = isset($_POST['adminpass']) ? htmlentities(trim($_POST['adminpass'])) : $_SERVER['HTTP_HOST'];
$admin_pass = md5($admin_pass);
if (isset($_POST['install'])) {
if (file_exists("includes/config.php")) {
echo "Please delete the file includes/config.php first.</body></html>";
exit;
}
if ($dir_dataftp == "") {
die('ERROR: invalid directory data ftp</body></html>');
}
$connect = mysql_connect($db_host, $db_user, $db_pass) or die('ERROR: cannot connect to DB server</body></html>');
                mysql_select_db($db_name) or die('ERROR: cannot select DB</body></html>');
mysql_query("DROP TABLE IF EXISTS `".$db_prefix."ftp`") or die(mysql_error());
mysql_query("CREATE TABLE `".$db_prefix."ftp` (
  `id` int(15) unsigned NOT NULL AUTO_INCREMENT,
  `server` varchar(250) NOT NULL,
  `port` int(6) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `size` varchar(3) NOT NULL,
  `icon` varchar(3) NOT NULL,
  `view` int(3) NOT NULL,
  `cookie` varchar(32) NOT NULL,
  `help` varchar(3) NOT NULL DEFAULT 'yes',
  `lastlogin` int(10) NOT NULL,
  `delete` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8") or die(mysql_error());
mysql_close($connect);
$adminfile = "<?php\r\n\r\n" .
                          '$admin_password = ' . "'$admin_pass';\r\n" .
                          '?>';                $configfile = "<?php\r\n\r\n" .
                          "defined('PAGEDISPLAY') or die ('Access Forbidden!');\r\n\r\n" .
                          '$db_host = ' . "'$db_host';\r\n" .
                          '$db_name = ' . "'$db_name';\r\n" .
                          '$db_user = ' . "'$db_user';\r\n" .
                          '$db_pass = ' . "'$db_pass';\r\n" .
                          '$db_prefix = ' . "'$db_prefix';\r\n" .
                          '$dir_dataftp = ' . "'$dir_dataftp';\r\n" .
                          '$admin_pass = ' . "'$admin_pass';\r\n\r\n" .
                          '?>';
                if (!file_put_contents('includes/config.php', $configfile)) {
                    echo 'ERROR: Can not write config.php</body></html>';
                    exit;
                }
else {
echo "INSTALLATION SUCCESSFULLY.<br />WARNING!!!, PLEASE DELETE THIS INSTALLATION FILE FOR SECURITY REASON!";
echo '</body></html>';
exit;
}

}
echo '<form action="'.basename(__FILE__).'" method="post">

<small class="blue"><b>MySQL Host:</b></small><br /><input type="text" name="dbhost" value="'.$db_host.'"><br />

<small class="blue"><b>MySQL Database:</b></small><br /><input type="text" name="dbname" value="'.$db_name.'"><br />

<small class="blue"><b>MySQL User:</b></small><br /><input type="text" name="dbuser" value="'.$db_user.'"><br />

<small class="blue"><b>MySQL Password:</b></small><br /><input type="text" name="dbpass" value="'.$db_pass.'"><br />

<small class="blue"><b>Table Prefix:</b></small><br /><input type="text" name="dbprefix" value="'.$db_prefix.'"><br />

<small class="blue"><b>Directory Data FTP:</b></small><br /><input type="text" name="dirdataftp" value="'.$dir_dataftp.'"><br />

<small class="blue"><b>Admin Password:</b></small><br /><input type="text" name="adminpass" value=""><br />

<input type="submit" name="install" value="INSTALL"></form>';
echo '</body></html>';
?>