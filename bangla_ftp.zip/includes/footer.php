<?php
defined('PAGEDISPLAY') or die('Access Forbidden..!!');
$ol = time() - 300;
$user_ol=mysql_result(mysql_query("SELECT COUNT(*) FROM `".$db_prefix."ftp` WHERE `lastlogin` > $ol"), 0);
echo '<div class="header"><table width="100%" cellspacing="0px" cellpading="0px" border="0px"><tr><td align="center" width="auto"><a href="changelanguage.php?language=english">ইংরেজি</a></td><td align="center" width="8px"><img src="/images/ver.png" alt=""/></td><td align="center" width="auto"><a href="changelanguage.php?language=bangla">বাংলা</a></td><td align="center" width="auto"></td></tr></table></div>';
echo '<div id="footer"><p>Active connection '.$user_ol.'<br/>&copy; '.date('Y',time()).' - '.$_SERVER['HTTP_HOST'].'<br/>All Rights Reserved</p></div></div></body></html>';
mysql_close($sql_connect);
?>