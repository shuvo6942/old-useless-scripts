<?php

defined('PAGEDISPLAY') or die ('Access Forbidden!');

$db_host = 'localhost';
$db_name = 'shuvo_dhur';
$db_user = 'shuvo_uii';
$db_pass = 'GI&68f7ry/?h';
$db_prefix = 'myftp_ftp3';
$dir_dataftp = './myftp_tmp';
$admin_pass = 'f798924301f107c2fdb9cab4df7e6d2c';

?>