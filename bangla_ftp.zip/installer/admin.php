<?php

$admin_password = 'f798924301f107c2fdb9cab4df7e6d2c';
?>