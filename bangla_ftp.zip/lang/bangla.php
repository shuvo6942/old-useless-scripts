<?
// A
$_lng['about'] = "এফটিপি সম্বন্ধে";
$_lng['aboutftp'] = "<h1> এফটিপি সম্বন্ধে </h1> ফাইল ট্রান্সফার প্রোটোকল একটি ইন্টারনেট প্রটোকল যে সঞ্চালিত হয়
অ্যাপ্লিকেশন লেয়ার যা ফাইল একটি নেটওয়ার্ক ইন্টারনেট দেবার সময় আপনার কমপিউটারের মেশিনের মধ্যে (ফাইল) পাঠানোর জন্য প্রমিত. <br/> এফটিপি নিকটতম ইন্টারনেটের উন্নত প্রোটোকল এক, এবং তা আজও ব্যবহৃত হয় 
কম্পিউটার এবং এফটিপি ক্লায়েন্টের মধ্যে ফাইল আপলোড (আপলোড) ও ডাউনলোড (ডাউনলোড) করার জন্য৷
FTP সার্ভার. একটি এফটিপি ক্লায়েন্ট একটি আবেদন যে FTP সার্ভার এফটিপি কমান্ড ইস্যু করতে পারে, যখন সার্ভার উইন্ডোজ এফটিপি সেবা বা ডিমন যে একটি এফটিপি ক্লায়েন্ট থেকে কমান্ড সাড়া যে একটি কম্পিউটার উপর সঞ্চালিত হয় হয়. <br/>
FTP- র কমান্ড, বাইনারি এবং ASCII মধ্যে বন্টন মোড পরিবর্তন, ডিরেক্টরি পরিবর্তন করতে ব্যবহার করা যেতে পারে
.Namaserver বিন্যাস: FTP সার্ভার এবং FTP সার্ভার থেকে ফাইল ডাউনলোড করার জন্য একটি কম্পিউটার ফাইলের শিল্পানুগ <br/> FTP সার্ভারের একটি ইউনিভার্সাল রিসোর্স আইডেন্টিফাইয়ার (কোনো URI) ব্যবহার FTP ব্যবহার দ্বারা ব্যবহার করা হয়. এফটিপি ক্লায়েন্ট কোনো URI খোলার দ্বারা FTP সার্ভারের সাথে যোগাযোগ করতে পারেন. FTP প্রোটোকল ট্রান্সমিশন কন্ট্রোল প্রোটোকল ব্যবহার <br/>
(টিসিপি) ক্লায়েন্ট এবং সার্ভারের মধ্যে তথ্য যোগাযোগের জন্য, তাই এই দুটি উপাদান মধ্যবর্তী হবে
সামনে ডাটা ট্রান্সমিশন শুরু একটি যোগাযোগ সেশন তৈরি করা. সংযোগ করার আগে, সার্ভার সাইড উপর TCP পোর্ট সংখ্যা 21 একটি এফটিপি ক্লায়েন্ট বিচার সংযোগ শুনতে হবে এবং তারপর একটি হিসাবে ব্যবহার করা নিয়ামক পোর্ট (নিয়ন্ত্রণ পোর্ট) (1) ক্লায়েন্ট এবং সার্ভারের মধ্যে একটি সংযোগ তৈরি, (2) করার জন্য ক্লায়েন্ট FTP সার্ভার থেকে একটি কমান্ড পাঠাতে এবং (3) কমান্ড সার্ভার প্রতিক্রিয়া ফেরৎ.
একবার নিয়ন্ত্রণ প্রতিবার সংযোগ তৈরী করা হয়েছে, তারপর সার্ভার TCP পোর্ট সংখ্যা 20 ওপেন শুরু হবে
ক্লায়েন্ট প্রকৃত তথ্য যে একটি ডাউনলোড এবং আপলোড করার সময় বিনিময় হচ্ছে পাঠাতে সঙ্গে একটি নতুন সংযোগ স্থাপন করা. <br/> এফটিপি শুধুমাত্র মান প্রমাণীকরণ পদ্ধতি ব্যবহার করে, যথা ব্যবহারকারীর নাম ব্যবহার করে এবং
পাসওয়ার্ড আলকাতরা আকারে এনক্রিপ্টেড নয় পাঠানো হয়. নিবন্ধিত ব্যবহারকারী ব্যবহারকারী নাম এবং পাসওয়ার্ড ব্যবহার করতে পারেন
প্রবেশাধিকার, ডাউনলোড, এবং আপলোড ফাইল করতে সে চায়. সাধারণত, নিবন্ধিত ব্যবহারকারী, যাতে তারা, ফাইল তৈরী করব ডিরেক্টরি তৈরি, এবং এমনকি ফাইল ডিলিট, একাধিক ডিরেক্টরি পূর্ণ প্রবেশাধিকার আছে.ব্যবহারকারী আছে যারা
না নিবন্ধিত এছাড়াও, বেনামী লগইন পদ্ধতি ব্যবহার করতে পারেন বেনামী ব্যবহারকারী নাম এবং পাসওয়ার্ড ব্যবহার করছেন দ্বারা
ই-মেইল ঠিকানা ব্যবহার করে পূরণ <br/> <br/> সূত্রঃ. <a href='http://en.m.wikipedia.org/wiki/File_Transfer_Protocol'> ফাইল ট্রান্সফার প্রোটোকল </a>";
$_lng['actionbutton'] = "প্রয়োগ করুন";
$_lng['actionconfirm'] = "আপনি কি নিশ্চিত এই পদক্ষেপ নিবেন?";
$_lng['agreement'] = "আমি বিশ্বাস করি যে আমার অ্যাকাউন্টের <a href=\"privacy.php\"> গোপনীয়তা </a> এখানে নিরাপদ৷";
$_lng['agreementerror'] = "আপনি অনুমোদন কলাম চিহ্নিত করেন নি৷";
$_lng['archiveempty'] = "সংরক্ষাণাগার খালি";
$_lng['acpri'] = "একাউন্টের গোপনীয়তা";

// B
$_lng['back'] = "পিছনে";
$_lng['backupwithdirectory'] = " %s ডাইরেক্টরির ভিতর দিয়ে?";
$_lng['backupbutton'] = "ব্যাকআপ";
$_lng ['backuperror'] = "তৈরি করতে ব্যর্থ";
$_lng['backupsuccess'] = "সংরক্ষাণাগার সফলভাবে তৈরি এবং যে নামে সংরক্ষণ করা হয়েছে তা হল";
$_lng['backuptitle'] = "ব্যাকআপ";

// C
$_lng['cantcopyfile'] = "ফাইল কপি করা যাচ্ছে না!";
$_lng['cantcopydirectory'] = "ডাইরেক্টরি কপি করা যাচ্ছে না!";
$_lng['cantcreatedirectory'] = "ডাইরেক্টরি তৈরি করা যাচ্ছে না!";
$_lng['cantcreatefile'] = "ফাইল তৈরি করা যাচ্ছে না!";
$_lng['cantgetfile'] = "ফাইল পাওয়া করা যাচ্ছে না!";
$_lng['cantsavefile'] = "ফাইল সংরক্ষণ করা যাচ্ছে না!";
$_lng['checksyntax'] = "সিনটেক্স পরীক্ষা করুন";
$_lng['chmod'] = "সিএইচমোড";
$_lng['chmodbutton'] = "সিএইচমোড";
$_lng['connectbutton'] = "সংযুক্ত হন";
$_lng['chmoddirerror'] = "ডাইরেক্টরিটির সিএইচমোড %s1 থেকে %s2 তে বদলানো যাচ্ছে না!";
$_lng['chmoddirsuccess'] = "ডাইরেক্টরিটির সিএইচমোড %s1 থেকে %s2 তে সফলভাবে পরিবর্তন করা হয়েছে";
$_lng['chmodfileerror'] = "ফাইলটির সিএইচমোড %s1 থেকে %s2 তে বদলানো যাচ্ছে না!";
$_lng['chmodfilesuccess'] = "ফাইলটির সিএইচমোড %s1 থেকে %s2 তে সফলভাবে পরিবর্তন করা হয়েছে";
$_lng['chmoddirectory'] = "ডাইরেক্টরি সিএইচমোড করুন";
$_lng['chmoderror'] = "সিএইচমোড করতে ব্যর্থ!";
$_lng['chmodfile'] = "ফাইল সিএইচমোড করুন";
$_lng['chmodterms'] = "সিএইচমোডে শুধুমাত্র অঙ্ক অনুমদিত এবং দৈর্ঘ্য 3!";
$_lng['chmodtitle'] = "সিএইচমোড";
$_lng['connectingerror'] = "নিচে অ্যাকাউন্টের বিশদ বিবরণ দিয়ে FTP সার্ভারের সাথে সংযোগ করতে অক্ষম";
$_lng['connectingerror2'] = "অথবা কিছুক্ষন পর চেষ্টা করুন.";
$_lng['contact'] = "আমাদের সাথে যোগাযোগ করুন";
$_lng['cookieterms'] = "কুকিজ এবং জাভাস্ক্রিপ্ট সক্রিয় থাকা আবশ্যক";
$_lng['copybutton'] = "কপি করুন";
$_lng['copydirerror'] = "ডাইরেক্টরি: %s<br />ডাইরেক্টরিটি %s1 থেকে %s2 তে কপি করা যাচ্ছে না";
$_lng['copydirsuccess'] = "ডাইরেক্টরি: %s<br />সফলভাবে %s1 থেকে %s2 তে কপি করা হয়েছে";
$_lng['copyfileerror'] = "ফাইল: %s<br />ফাইলটি %s1 থেকে %s2 তে কপি করা যাচ্ছে না";
$_lng['copyfilesuccess'] = "ফাইল: %s<br />সফলভাবে %s1 থেকে %s2 তে কপি করা হয়েছে";
$_lng['copygeterror'] = "ডাইরেক্টরি: %s<br />ফাইল পাওয়া যাচ্ছে না %s2";
$_lng['copyfilegeterror'] = "ফাইল: %s<br />ফাইল পাওয়া যাচ্ছে না %s2";
$_lng['copyto'] = "যেখানে কপি করবেন";
$_lng['copytitle'] = "কপি করুন";
$_lng['createbutton'] = "তৈরি করুন";
$_lng['createtitle'] = "তৈরি করুন";
$_lng['createinstaller'] = "ইনস্টলার তৈরি করুন";
$_lng['createsqlbutton'] = "তৈরি করুন";

// D
$_lng['day'] = "দিন";
$_lng['deletedirectoryerror'] = "ডাইরেক্টরিটি মুছে ফেলতে সমস্যা";
$_lng['deletefileerror'] = "ফাইলটি মুছে ফেলতে সমস্যা";
$_lng['deleteconfirm'] = "আপনি এইটা মুছে ফেলতে চান এ ব্যাপারে আপনি কি নিশ্চিত?";
$_lng['deletedirerror'] = "%s ডাইরেক্টরিটি মুছে ফেলা যাচ্ছে না";
$_lng['deletefileerror'] = "%s ফাইলটি মুছে ফেলা যাচ্ছে না";
$_lng['deletedirsuccess'] = "%s ডাইরেক্টরিটি সফলভাবে মুছে ফেলা হয়েছে";
$_lng['deletefilesuccess'] = "%s ফাইলটি সফলভাবে মুছে ফেলা হয়েছে";
$_lng['deletetitle'] = "মুছুন";
$_lng['deletebutton'] = "মুছুন";
$_lng['directory'] = "ডাইরেক্টরি";
$_lng['download'] = "ডাউনলোড করুন";

// E
$_lng['editerror'] = "বদলগুলো সংরক্ষন করা যাচ্ছে না";
$_lng['editfile'] = "ফাইল সম্পাদনা";
$_lng['editsuccess'] = "বদলগুলো সফলভাবে সংরক্ষন করা হয়েছে";
$_lng['elementsperpage'] = "প্রতি পাতায় উপাদানসমূহ";
$_lng['emptyname'] = "নাম খালি রাখা যাবে না";
$_lng['emptynewname'] = "নতুন নাম খালি রাখা যাবে না";$_lng['error'] = "সমস্যা!";
$_lng['extractbutton'] = "এক্সট্রাক্ট";
$_lng['extracttitle'] = "এক্সট্রাক্ট";
$_lng['extractarchive'] = "সংরক্ষণাগার এক্সট্রাক্ট করুন";
$_lng['extracterror'] = "ফাইল এক্সট্রাক্ট করতে অক্ষম";
$_lng['extractitemsuccess'] = "আইটেম সফলভাবে এক্সট্রাক্ট এবং যে নামে সংরক্ষণ করা হয়েছে তা হল";

// F
$_lng['faq'] = "এফএকিউ";
$_lng['fileinfo'] = "ফাইলের তথ্য";
$_lng['filename'] = "নাম";
$_lng['filesize'] = "আয়তন";
$_lng['filenotfound'] = "ফাইল পাওয়া যাচ্ছে না!";
$_lng['filetitle'] = "ফাইল";
$_lng['filetoobig'] = "ফাইল %s আমদানি করার জন্য অত্যন্ত বড়. সর্বাধিক ফাইলের আকার 5mb";
$_lng['formerror'] = "দয়া করে ফরমটি পূরণ করুন!";
$_lng['ftpconnecterror'] = "এফটিপি সার্ভারের সাথে সংযোগ স্থাপন করা যাচ্ছে না!";
$_lng['ftpdirectory'] = "ডাইরেক্টরি";
$_lng['ftppassword'] = "পাসওয়ার্ড";
$_lng['ftpport'] = "এফটিপি পোর্ট";
$_lng['ftpserver'] = "এফটিপি সার্ভার";
$_lng['ftpusername'] = "ইউজারনেম";

// G
$_lng['globaltitle'] = "মোবাইল এফটিপি";
$_lng['go'] = "যাও";

// H
$_lng['height'] = "উচ্চতা";
$_lng['hour'] = "ঘন্টা";
// I
$_lng['imageresize'] = "ছবির আকার বদলান";
$_lng['importbutton'] = "আমদানি করুন";
$_lng['importtitle'] = "আমদানি করুন";
$_lng['importsuccess'] = "ফাইলটি %s সফলভাবে আমদানি করা হয়েছে";
$_lng['item'] = "পদ";

// L
$_lng['language'] = "ভাষা";
$_lng['lastmodified'] = "সর্বশেষ পরিবর্তিত";
$_lng['listtitle'] = "তালিকাগুলো";
$_lng['login'] = "লগিন করুন";
$_lng['loginfor'] = "যতদিনের জন্য লগিন করবেন";
$_lng['logout'] = "লগআউট";
$_lng['log'] = "আপনি সফলভাবে লগআউট হয়েছেন..!!";

// M
$_lng['minute'] = "মিনিট";
$_lng['month'] = "মাস";
$_lng['movebutton'] = "সরান";
$_lng['moveerror'] = "সরাতে সমস্যা";
$_lng['movedirerror'] = "%s1 ডাইরেক্টরিটি %s2 তে সরানো যাচ্ছে না";
$_lng['movedirsuccess'] = "%s1 ডাইরেক্টরিটি %s2 তে সফলভাবে সরানো হয়েছে";
$_lng['movefileerror'] = "%s1 ফাইলটি %s2 তে সরানো যাচ্ছে না";
$_lng['movefilesuccess'] = "%s1 ফাইলটি %s2 তে সফলভাবে সরানো হয়েছে";
$_lng['movetitle'] = "সরান";
$_lng['moveto'] = "যেখানে সরাবেন";

// N
$_lng['name'] = "নাম";
$_lng['newname'] = "নতুন নাম";
$_lng['no'] = "না";

// O
$_lng['oldname'] = "পুরতন নাম";
$_lng['openarchive'] = "সংরণাগার খুলুন";

// P
$_lng['password'] = "পাসওয়ার্ড";
$_lng['privacy'] = "<h1>Account Privacy</h1>By using the services we mean you agree that your FTP account 
for the time we save on the system, but we do not store your FTP account password but the password is 
stored in your browser cookies and the password has been encryption.<br/>Each time you log in to the 
service then our system automatically registering your FTP account that system will provide your account 
secret code and store it on your browsers cookies along with your FTP account password that has been 
encrypted.<br/>When you go to the site browser Our system then will check if your browser has cookies 
secret code, if it does not have cookies browse the secret code and password cookies then your browser 
will be redirected to the Login page, but if your browser has cookies secret code that corresponds to 
the data on the system then the next we describe the system will be your FTP account password.<br/>You 
can delete cookies secret code and password of your FTP account even delete the FTP account data (server,
 port, user name and other additional settings) that exist on the system at any time when you log out 


(প্রস্থান) কিন্তু এমনকি যদি আপনি লগ আউট না করেন (প্রস্থান) তবুও আমাদের সিস্টেমে স্বয়ংক্রিয়ভাবে আপনার অ্যাকাউন্ট মুছে ফেলা হবে যদি আপনার সিজনের সময়ের মেয়াদ শেষ হয়ে যায় (মেয়াদ শেষ). 
<br/>
<h1> আমাদের পেশাদারি </h1 > * আপনার অ্যাকাউন্টের গোপনীয়তা সংরক্ষণ. <br/> * যে কেউ আপনার অ্যাকাউন্ট তথ্য দেবে না. <br/> * আপনার FTP একাউন্ট ঢোকা হবে না. <br/> <br/><b> আপনার আস্থা আমাদের দায়িত্ব. </b>";

// R
$_lng['renamebutton'] = "নাম পরিবর্তন করুন";
$_lng['renamedirerror'] = "ডাইরেক্টরিটির নাম %s1 থেকে %s2 তে পরিবর্তন করা যাচ্ছে না";
$_lng['renamedirsuccess'] = "ডাইরেক্টরিটির নাম %s1 থেকে %s2 তে সফলভাবে পরিবর্তন করা হয়েছে";
$_lng['renameerror'] = "নাম পরিবর্তনে ব্যর্থ!";
$_lng['renamefileerror'] = "ফাইলটির নাম %s1 থেকে %s2 তে পরিবর্তন করা যাচ্ছে না";
$_lng['renamefilesuccess'] = "ফাইলটির নাম %s1 থেকে %s2 তে সফলভাবে পরিবর্তন করা হয়েছে";
$_lng['renametitle'] = "নাম পরিবর্তন করুন";
$_lng['renameto'] = "যে নামে পরিবর্তন করবেন";
$_lng['resizeimage'] = "মাপ পরিবর্তন করুন";
$_lng['resizeimageerror'] = "চিত্রটি সংরক্ষন করা যাচ্ছে না";
$_lng['resizeimagesuccess'] = "চিত্রটির মাপ %w x %h তে পরিবর্তন হয়েছে এবং %image হিসাবে সংরক্ষণ করা হয়েছে";

// S
$_lng['saveas'] = "যে নামে সংরক্ষন করবেন";
$_lng['savebutton'] = "সংরক্ষন";
$_lng['sessionerror'] = "সময় সময় সীমা অতিক্রম করেছে.";
$_lng['settings'] = "সেটিংস";
$_lng['settingssuccessfullysaved'] = "সেটিংস সফলভাবে সংরক্ষিত হয়েছে";
$_lng['showhelptext'] = "সাহায্যকারী লেখাগুলো প্রদর্শন";
$_lng['showicon'] = "আইকন প্রদর্শন";
$_lng['showsize'] = "আকার প্রদর্শন";
$_lng['sourcetitle'] = "সোর্স";
$_lng['sqldatabase'] = "ডেটাবেস";
$_lng['sqlhost'] = "হোস্ট";
$_lng['sqlpassword'] = "পাসওয়ার্ড";
$_lng['sqluser'] = "ইউসার";
$_lng['syntaxtitle'] = "সিনটেক্স";

// T
$_lng['totalfile'] = "মোট ফাইল";
$_lng['type'] = "প্রকার";

// U
$_lng['unableextract'] = "ফাইল এক্সট্রাক্ট করা যাচ্ছে না";
$_lng['untarbutton'] = "এক্সট্রাক্ট করুন";
$_lng['untartitle'] = "আনটেয়ার করুন";
$_lng['untarerror'] = "আপনার সার্ভারে পাঠানো যাচ্ছে না";
$_lng['untarsuccess'] = "আপনার সার্ভারে সফলভাবে পাঠানো হয়েছে";
$_lng['unzipbutton'] = "আনজিপ করুন";
$_lng['unziperror'] = "আপনার সার্ভারে পাঠানো যাচ্ছে না";
$_lng['unzipdir'] = "ডাইরেক্টরি";
$_lng['unzipsuccess'] = "আপনার সার্ভারে সফলভাবে পাঠানো হয়েছে";
$_lng['unziptitle'] = "আনজিপ করুন";
$_lng['uploadbutton'] = "আপলোড করুন";
$_lng['uploaderror'] = "আপলোড করা যাচ্ছে না";
$_lng['uploadinfo'] = "ফাইল বাছুন (সর্বোচ্চ 5 mb প্রত্যেক ফাইল)";
$_lng['uploadsuccess'] = "সফলভাবে আপলোড করা হয়েছে";
$_lng['uploadtitle'] = "আপলোড করুন";

// W
$_lng['width'] = "প্রস্থ";
$_lng['week'] = "সপ্তাহ";
$_lng['withselected'] = "চিহ্নিত উপাদানগুলোর সাথে";
$_lng['withsize'] = "আকারের সাথে";

// Y
$_lng['yes'] = "হ্যাঁ";

// Z
$_lng['zipinstaller'] = "জিপ ইনস্টলার";

$_lng['help_chmod'] = "ডিরেক্টরি বা ফাইলের জন্য অনুমতি সেট করুন৷ CHMOD এ শুধুমাত্র অঙ্ক সংখ্যা অনুমদিত (000 পর্যন্ত 777) এবং 3 ডিজিটের হতে হবে";
$_lng['help_copy'] = "ফাইল বা ডিরেক্টরি কপি করুন৷গন্তব্য নির্দেশিকা ইতিমধ্যেই উপস্থিত থাকা আবশ্যক.";
$_lng['help_create'] = "নাম লিখে টাইপ নির্বাচন করুন৷আপনি ফাইল তৈরি করলে তার CHMOD স্বয়ংক্রিয়ভাবে 644 আর আপনি ডাইরেক্টরি তৈরি করলে তার CHMOD স্বয়ংক্রিয়ভাবে 755 হয়ে যাবে৷";
$_lng['help_list'] = "ডিরেক্টরি এবং ফাইল দেখানো হচ্ছে৷ডিরেক্টরি বা ফাইল তৈরি করতে <b>তৈরি করুন</b> ক্লিক করুন৷";
$_lng['help_move'] = "অন্য ডিরেক্টরিতে ফাইল বা ডিরেক্টরি সরান৷গন্তব্য নির্দেশিকা ইতিমধ্যেই উপস্থিত থাকা আবশ্যক৷";
$_lng['help_unzip'] = "এই ফাইলটির এক্সট্রাক্ট ডিরেক্টরি অবস্থান সন্নিবেশ করুন.গন্তব্য ডিরেক্টরিটি উপস্থিত না থাকলে এটি স্বয়ংক্রিয়ভাবে তৈরি করা হবে";
?>