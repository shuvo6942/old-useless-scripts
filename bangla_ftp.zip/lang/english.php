<?
// A
$_lng['about'] = "About FTP";
$_lng['aboutftp'] = "<h1>About FTP</h1>File Transfer Protocol is an Internet protocol that runs in the application layer which is the standard for sending files (files) between your computer machines in a network Internet.<br/>FTP is one of the earliest Internet protocols developed, and is still used today to perform the download (download) and upload (upload) files between the computer and the FTP client FTP server. An FTP Client is an application that can issue FTP commands to an FTP server, while the server is a Windows FTP service or daemon that runs on a computer that responds to commands from an FTP client.<br/>FTP commands can be used to change the directory, changing the mode of delivery between binary and ASCII, evocative of a computer file to the FTP server, and download files from an FTP server.<br/>An FTP server is accessed by using a Universal Resource Identifier (URI) using ftp://namaserver format. FTP client can contact the FTP server by opening the URI.<br/>Using the FTP protocol Transmission Control Protocol (TCP) for data communication between the client and the server, so in between these two components will be made a communication session before data transmission begins. Before making the connection, the TCP port number 21 on the server side will listen trial connection of an FTP client and then be used as a controller port (control port) to (1) create a connection between the client and server, (2) to allow the client to send a command to the FTP server and also (3) returns the server response to the command. Once the control connection has been made, then the server will start to open the TCP port number 20 to establish a new connection with the client to send the actual data that is being exchanged during a download and upload.<br/>FTP uses only standard authentication methods, namely using the username and password are sent in the form of tar is not encrypted. Registered users can use the username and password to access, download, and upload files he wants. Generally, the registered users have full access to multiple directories, so that they can create files, create directories, and even delete files. Users who have not registered may also use anonymous login method, by using the anonymous user name and password are filled in using the e-mail address.<br/><br/>Source: <a href=\"http://en.m.wikipedia.org/wiki/File_Transfer_Protocol\">File Transfer Protocol</a>";
$_lng['actionbutton'] = "Apply";
$_lng['actionconfirm'] = "Are you sure will take this action?";
$_lng['agreement'] = "I believe that the <a href=\"privacy.php\">privacy</a> of my account is safe here.";
$_lng['agreementerror'] = "You do not mark the approval column.";
$_lng['archiveempty'] = "Archive Empty";
$_lng['acpri'] = "Account Privacy";

// B
$_lng['back'] = "Back";
$_lng['backupwithdirectory'] = "With the %s directory inside?";
$_lng['backupbutton'] = "Backup";
$_lng ['backuperror'] = "Failed to create";
$_lng['backupsuccess'] = "Archive successfully created and has been saved as";
$_lng['backuptitle'] = "Backup";

// C
$_lng['cantcopyfile'] = "Can't copy file!";
$_lng['cantcopydirectory'] = "Can't copy directory!";
$_lng['cantcreatedirectory'] = "Cant create directory";
$_lng['cantcreatefile'] = "Cant create file";
$_lng['cantgetfile'] = "Can't get file!";
$_lng['cantsavefile'] = "Can't save file";
$_lng['checksyntax'] = "Check Syntax";
$_lng['chmod'] = "CHMOD";
$_lng['chmodbutton'] = "Chmod";
$_lng['connectbutton'] = "Connect";
$_lng['chmoddirerror'] = "Directory %s1 cant chmod to %s2";
$_lng['chmoddirsuccess'] = "Directory %s1 successfully chmod to %s2";
$_lng['chmodfileerror'] = "File %s1 cant chmod to %s2";
$_lng['chmodfilesuccess'] = "File %s1 successfully chmod to %s2";
$_lng['chmoddirectory'] = "CHMOD Directory";
$_lng['chmoderror'] = "Chmod failed!";
$_lng['chmodfile'] = "CHMOD File";
$_lng['chmodterms'] = "Chmod only digit allowed and lenght 3!";
$_lng['chmodtitle'] = "Chmod";
$_lng['connectingerror'] = "Unable to connect to FTP server with the account details below.";
$_lng['connectingerror2'] = "or try again later.";
$_lng['contact'] = "Contact Us";
$_lng['cookieterms'] = "Cookies and Javascript must be enabled.";
$_lng['copybutton'] = "Copy";
$_lng['copydirerror'] = "Directory: %s<br />Can't copy %s1 to %s2";
$_lng['copydirsuccess'] = "Directory: %s<br />Successfully copy %s1 to %s2";
$_lng['copyfileerror'] = "File: %s<br />Can't copy %s1 to %s2";
$_lng['copyfilesuccess'] = "File: %s<br />Successfully copy %s1 to %s2";
$_lng['copygeterror'] = "Directory: %s<br />Can't get the file %s2";
$_lng['copyfilegeterror'] = "File: %s<br />Can't get the file %s2";
$_lng['copyto'] = "Copy to";
$_lng['copytitle'] = "Copy";
$_lng['createbutton'] = "Create";
$_lng['createtitle'] = "Create";
$_lng['createinstaller'] = "Create Installer";
$_lng['createsqlbutton'] = "Create";

// D
$_lng['day'] = "Day";
$_lng['deletedirectoryerror'] = "Error deleting directory";
$_lng['deletefileerror'] = "Error deleting file";
$_lng['deleteconfirm'] = "Are you sure you want to delete this?";
$_lng['deletedirerror'] = "Directory %s cant be deleted";
$_lng['deletefileerror'] = "File %s cant be deleted";
$_lng['deletedirsuccess'] = "Directory %s successfully deleted";
$_lng['deletefilesuccess'] = "File %s successfully deleted";
$_lng['deletetitle'] = "Delete";
$_lng['deletebutton'] = "Delete";
$_lng['directory'] = "Directory";
$_lng['download'] = "Download";

// E
$_lng['editerror'] = "Changes can't be saved";
$_lng['editfile'] = "Edit File";
$_lng['editsuccess'] = "Changes successfully saved";
$_lng['elementsperpage'] = "Elements per page";
$_lng['emptyname'] = "Name cant be empty";
$_lng['emptynewname'] = "New name cant be empty!";
$_lng['error'] = "Error!";
$_lng['extractbutton'] = "Extract";
$_lng['extracttitle'] = "Extract";
$_lng['extractarchive'] = "Extract Archive";
$_lng['extracterror'] = "Unable to extract file";
$_lng['extractitemsuccess'] = "Item successfully extracted and has been saved as";

// F
$_lng['faq'] = "FAQ";
$_lng['fileinfo'] = "File Info";
$_lng['filename'] = "Name";
$_lng['filesize'] = "Size";
$_lng['filenotfound'] = "File not found!";
$_lng['filetitle'] = "File";
$_lng['filetoobig'] = "File %s is too big to imported. Max file size 5mb";
$_lng['formerror'] = "Please completed the form!";
$_lng['ftpconnecterror'] = "Can't connect to FTP server!";
$_lng['ftpdirectory'] = "Directory";
$_lng['ftppassword'] = "Password";
$_lng['ftpport'] = "FTP port";
$_lng['ftpserver'] = "FTP server";
$_lng['ftpusername'] = "Username";

// G
$_lng['globaltitle'] = "Mobile FTP";
$_lng['go'] = "Go";

// H
$_lng['height'] = "Height";
$_lng['hour'] = "Hour";

// I
$_lng['imageresize'] = "Image Resize";
$_lng['importbutton'] = "Import";
$_lng['importtitle'] = "Import";
$_lng['importsuccess'] = "File %s successfully imported";
$_lng['item'] = "Item";

// L
$_lng['language'] = "Language";
$_lng['lastmodified'] = "Last modified";
$_lng['listtitle'] = "Lists";
$_lng['login'] = "Login";
$_lng['loginfor'] = "Login for";
$_lng['logout'] = "Logout";
$_lng['log'] = "You have been successfully logged out..!!";

// M
$_lng['minute'] = "Minute";
$_lng['month'] = "Month";
$_lng['movebutton'] = "Move";
$_lng['moveerror'] = "Move Error";
$_lng['movedirerror'] = "Directory %s1 cant moved to %s2";
$_lng['movedirsuccess'] = "Directory %s1 successfully moved to %s2";
$_lng['movefileerror'] = "File %s1 cant moved to %s2";
$_lng['movefilesuccess'] = "File %s1 successfully moved to %s2";
$_lng['movetitle'] = "Move";
$_lng['moveto'] = "Move to";

// N
$_lng['name'] = "Name";
$_lng['newname'] = "New name";
$_lng['no'] = "No";

// O
$_lng['oldname'] = "Old name";
$_lng['openarchive'] = "Open Archive";

// P
$_lng['password'] = "Password";
$_lng['privacy'] = "<h1>Account Privacy</h1>By using the services we mean you agree that your FTP account for the time we save on the system, but we do not store your FTP account password but the password is stored in your browser cookies and the password has been encryption.<br/>Each time you log in to the service then our system automatically registering your FTP account that system will provide your account secret code and store it on your browsers cookies along with your FTP account password that has been encrypted.<br/>When you go to the site browser Our system then will check if your browser has cookies secret code, if it does not have cookies browse the secret code and password cookies then your browser will be redirected to the Login page, but if your browser has cookies secret code that corresponds to the data on the system then the next we describe the system will be your FTP account password.<br/>You can delete cookies secret code and password of your FTP account even delete the FTP account data (server, port, user name and other additional settings) that exist on the system at any time when you log out (Exit) but even if you do not log out (exit) Our system will automatically delete your account if the period you have chosen at the time of admission had expired (expires).<br/><h1>Our professionalism</h1>* Save the confidentiality of your account.<br/>* Will not let your account data to anyone.<br/>* Not going to go into your FTP account.<br/><br/><b>Your confidence is our responsibility.</b>";

// R
$_lng['renamebutton'] = "Rename";
$_lng['renamedirerror'] = "Directory %s1 cant renamed to %s2";
$_lng['renamedirsuccess'] = "Directory %s1 successfully renamed to %s2";
$_lng['renameerror'] = "Rename Failed!";
$_lng['renamefileerror'] = "File %s1 cant renamed to %s2";
$_lng['renamefilesuccess'] = "File %s1 successfully renamed to %s2";
$_lng['renametitle'] = "Rename";
$_lng['renameto'] = "Rename to";
$_lng['resizeimage'] = "Resize";
$_lng['resizeimageerror'] = "Image cant be saved";
$_lng['resizeimagesuccess'] = "Image has been resize to %w x %h and saved as %image";

// S
$_lng['saveas'] = "Save as";
$_lng['savebutton'] = "Save";
$_lng['sessionerror'] = "Session time out.";
$_lng['settings'] = "Settings";
$_lng['settingssuccessfullysaved'] = "Settings successfully saved";
$_lng['showhelptext'] = "Show help text";
$_lng['showicon'] = "Show icon";
$_lng['showsize'] = "Show size";
$_lng['sourcetitle'] = "Source";
$_lng['sqldatabase'] = "Database";
$_lng['sqlhost'] = "Host";
$_lng['sqlpassword'] = "Password";
$_lng['sqluser'] = "User";
$_lng['syntaxtitle'] = "Syntax";

// T
$_lng['totalfile'] = "Total Files";
$_lng['type'] = "Type";

// U
$_lng['unableextract'] = "Unable to extract file";
$_lng['untarbutton'] = "Extract";
$_lng['untartitle'] = "Untar";
$_lng['untarerror'] = "unable to sent to your server.";
$_lng['untarsuccess'] = "successfully sent to your server.";
$_lng['unzipbutton'] = "Unzip";
$_lng['unziperror'] = "unable sent to your server.";
$_lng['unzipdir'] = "Directory";
$_lng['unzipsuccess'] = "successfully sent to your server.";
$_lng['unziptitle'] = "Unzip";
$_lng['uploadbutton'] = "Upload";
$_lng['uploaderror'] = "can't to uploaded.";
$_lng['uploadinfo'] = "Choose files (max 5 mb per file)";
$_lng['uploadsuccess'] = "successfully uploaded.";
$_lng['uploadtitle'] = "Upload";

// W
$_lng['width'] = "Width";
$_lng['week'] = "Week";
$_lng['withselected'] = "With selected elements";
$_lng['withsize'] = "with size";

// Y
$_lng['yes'] = "Yes";

// Z
$_lng['zipinstaller'] = "Zip installer";

$_lng['help_chmod'] = "Set permission for directory or file. CHMOD only digit number allowed (000 up to 777) and must be 3 digits";
$_lng['help_copy'] = "Copy file or directory. The destination directory must already exist.";
$_lng['help_create'] = "Please insert Name and select type. If you create File then CHMOD automatically to 644 and if you create Directory then CHMOD automatically to 755.";
$_lng['help_list'] = "Showing directories and files. To start creating directory or file please click <b>Create</b>.";
$_lng['help_move'] = "Move file or directory to another directory. The destination directory must already exist.";
$_lng['help_unzip'] = "Please insert the directories location for extracting this file. If the destination directory does not exist it will be created automatically.";
?>