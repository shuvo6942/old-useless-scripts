﻿<?php
error_reporting(0);
include('header.php');
?>
<div class="menu">
	<h3>Users</h3>
	<?php
		$empty = 0;
		if($handle = opendir('database'))
		{
			while (false !== ($entry = readdir($handle)))
			{
			if($entry != "." && $entry != "..")
			{
				if(is_numeric($entry))
				{
					$empty = 1;
					$user = fopen('database/'.$entry.'',"r") or die('Error !');
					$user_data = fgets($user);
					$user_data = json_decode($user_data,true);
					$name = $user_data['name'];
					echo '<li><a>'.$name.'</a></li>';
					fclose($user);
				}
			}
			}
			closedir($handle);
		}
		if($empty == 0)
		{
			echo '<li><a href="#">Empty Database !</a></li>';
		}
	?>
</div>
<?php
include 'footer.php';
?>