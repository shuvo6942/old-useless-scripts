<?php
$totaluser = 0;
if($handle = opendir('database'))
{
	while(false !== ($entry = readdir($handle)))
	{
		if($entry != "." && $entry != "..")
		{
			if(is_numeric($entry))
			{
				$totaluser++;
			}
		}
	}
	closedir($handle);
}
?>
<div id="footer"><div class='paging'><a>Users : <?php echo $totaluser; ?></a></div>2014-15 Auto-Liker<br>Powered By <a href="http://m.facebook.com/FacebookDevelopers">Facebook Developers</a><br>All Rights Reserved.</div></body></html>