Features
***************************
No SQL Database Required
Auto Liker
Like Options 50,100,150,200,250
15 Minutes Waiting For Each Submit
Admin Panel
View Users
Refresh Tokens
Update Token Link & App ID Fast
Uses Cookies To Store Tokens Clientside
Without Token For Admins ( use password )

Installation
***************************
Just Upload The Files In This Folder
( No Other Steps Required )


Admin Panel Password : cyberlikes