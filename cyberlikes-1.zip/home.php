<?php
session_start();header('Content-Type: text/html; charset=utf-8');
include 'info.php';
if(isset($_GET['accesstoken']))
{
	$token = $_GET['accesstoken'];
}
else
{
	$token = $_COOKIE['accesstokenL'];
}
if(empty($token))
{
	header("Location: index.php?error=notoken");
	die();
}
?>
<?php
$remove1 = '=';
$remove2 = '&';
preg_match('/'.preg_quote($remove1).'(.*?)'.preg_quote($remove2).'/is', $token, $tokenFiltered);
if(!$tokenFiltered[1]){$token = $token;}else{$token = $tokenFiltered[1];}
?>
<?php
require('facebook.php');
$facebook = new Facebook(array('appId' => '','secret' => '','cookie' => true));
if($token != $set[password])
{
	try
	{
	   $parameters['access_token'] = $token;
	   $userData = $facebook->api('/me?fields=id,name', $parameters);
	   $statuses = $facebook->api('/me/feed?limit=5&fields=id', $parameters);
	}
	catch (FacebookApiException $e)
	{
		if($_COOKIE['accesstokenL'])
		{
			$date_of_expiry = time() - 60 * 60 * 24 * 30;
			setcookie('accesstokenL',$token, $date_of_expiry, "/" ) ;
			header("Location: index.php?error=expiredtoken");
			die();
		}
		else
		{
			$date_of_expiry = time() - 60 * 60 * 24 * 30;
			setcookie('accesstokenL',$token, $date_of_expiry, "/" ) ;
			header("Location: index.php?&error=invalidtoken");
			die();
		}
	}
}
if($userData)
{
	try
	{
		$parameters['access_token'] = $token;
		$appData = $facebook->api('/app?fields=id', $parameters);
		if($appData['id'] == $set[liker_token_appid])
		{
			$permData = $facebook->api('/me/permissions', $parameters);
			if(array_key_exists('publish_stream',$permData['data'][0]))
			{
			}
			else
			{
				$date_of_expiry = time() - 60 * 60 * 24 * 30;
				setcookie('accesstokenL',$token, $date_of_expiry, "/" ) ;
				header("Location: index.php?error=invalidtokenperm");
				die();
			}
		}
		else
		{
			$date_of_expiry = time() - 60 * 60 * 24 * 30;
			setcookie('accesstokenL',$token, $date_of_expiry, "/" ) ;
			header("Location: index.php?error=invalidtokenapp");
			die();
		}
	}
	catch (FacebookApiException $e)
	{
	}
	$user = $userData['id'];
	if(!file_exists('database/'.$user.''))
	{
		$newuser = true;
	}
	else
	{
		$newuser = false;
		$handle = fopen('database/'.$user.'',"r") or die('File Not Found ! ('.$user.')');
		$user_data = fgets($handle);
		$user_data = json_decode($user_data,true);
		$dbtime = $user_data['time'];
		$nextuse = $dbtime + (60*15);
		$nextuse = date('20y-m-d H:i:s',$nextuse);
		$currenttime = date('20y-m-d H:i:s');
		if($currenttime >= $nextuse)
		{
			$disabled = "";
		}
		else
		{
			$disabled = "disabled";
		}
		fclose($handle);
	}
}
$_SESSION['login'] = true;
$date_of_expiry = time()+60*60*24*30;
setcookie('accesstokenL',$token,$date_of_expiry,"/") ;
?>
<?php
$userpic = 'https://graph.facebook.com/me/picture?width=120&height=120&access_token='.$token;
if($token == $set[password])
{
	$userpic = 'https://graph.facebook.com/'.$set[owner_profile_id].'/picture?width=50&height=50';
	$userData['name'] = $set[owner_name];
}
?>
<?php
include 'header.php';
?>
<?php
echo '
<div class="menu">
	<h3>Auto Liker</h3>
	<li><a href="statusid.php">How To Find My Status / Photo ID ?</a></li>';
	if(isset($_GET["success"]) || isset($_GET["error"]))
	{
		echo '<li>';
	}
    $error = $_GET["error"];
	$success = $_GET["success"];
	if($success == 'success')
	{
		echo '<font color="green">Success !</font>';
	}
	if($error == 'nostatus')
	{
		echo '<font color="#CC3300">Enter Status ID !</font>';
	}
	if($error == 'invalidstatus')
	{
		echo '<font color="#CC3300">Invalid Status ID !</font>';
	}
	if($error == 'timelock')
	{
		echo '<img src="https://m-static.ak.fbcdn.net/rsrc.php/v2/yL/r/aDZnxc3h1wi.png" height="12"> <font color="#CC3300">Wait 15 Minutes For The Next Use !</font>';
	}
	if(isset($_GET["error"]) || isset($_GET["error"]))
	{
		echo '</li>';
	}
	if($disabled == "disabled")
	{
		echo '<li><img src="https://m-static.ak.fbcdn.net/rsrc.php/v2/yL/r/aDZnxc3h1wi.png" height="12"> <font color="#CC3300">Wait 15 Minutes For The Next Use !</font></li>';
	}
echo '
</div>
<div class="menu">
	<h3>'.$userData['name'].'</h3>
	<li>Paste Your Custom Status / Photo ID / Link</li>
	<li>
	<form method="POST" action="m-likes.php">
    Status ID
	<br>
	<input name="postid" />
	<select name="num">
	<option value="50" selected="selected">50</option>
	<option value="100">100</option>
	<option value="150">150</option>
	<option value="200">200</option>
	<option value="250">250</option>
	</select>
	<input id="hidden" name="accesstoken" value="'.$token.'">
    <input value="Auto-Like" type="submit" '.$disabled.'/>
	</form>
	</li>
</div>';
if($userData['id'])
{
foreach($statuses['data'] as $status)
{
	try
	{
		$statusData = $facebook->api('/'.$status["id"].'?fields=id,privacy,message,likes,comments',$parameters);
	}
	catch (FacebookApiException $e)
	{
	}
	$likesData = $statusData['likes'];
	$commentsData = $statusData['comments'];
	$privacyData = $statusData['privacy'];
	echo
'
<div class="menu">
	<h3>'.$userData['name'].'</h3>
	<li>Status : '.$statusData["message"].'</li>
	<li>
	<l><img src="https://m-static.ak.fbcdn.net/rsrc.php/v2/yk/r/Funzuxq3d75.png" height="10px">&nbsp;'.$likesData["count"].'</l>
	<l style="float:right;position:absolute;right:50%;"><img src="https://m-static.ak.fbcdn.net/rsrc.php/v2/yn/r/FNcFEVynZ6Y.png" height="10px">&nbsp;'.$commentsData["count"].'</l>
	<l style="float:right;"><img src="https://m-static.ak.fbcdn.net/rsrc.php/v2/y3/r/VFye9Uth9Ey.png" height="12px"> '.$privacyData['description'].'&nbsp;</l>
	</li>
	<li>
	<form method="POST" action="m-likes.php">
    Status ID
	<br>
	<input name="postid" value="'.$status["id"].'" />
	<select name="num">
	<option value="50" selected="selected">50</option>
	<option value="100">100</option>
	<option value="150">150</option>
	<option value="200">200</option>
	<option value="250">250</option>
	</select>
	<input id="hidden" name="accesstoken" value="'.$token.'">
    <input value="Auto-Like" type="submit" '.$disabled.'/>
	</form>
	</li>
</div>';
}
}
?>
<?php
include 'footer.php';
?>