<?php
session_start();
session_destroy();
$date_of_expiry = time() - 1;
setcookie('accesstokenL',$token,$date_of_expiry,"/");
header("Location: index.php?success=logout");
die();
?>