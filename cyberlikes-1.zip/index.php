<?php
session_start();
require("info.php");
if($_COOKIE['accesstokenL'])
{
$accesstoken = $_COOKIE['accesstokenL'];
header("Location: home.php?accesstoken=".$accesstoken."");
die();
}
require'header.php';
?>
<div class="menu">
<h3>Auto Liker</h3>
<?php if($set[site_status] == 'online') : ?>
<li><a href="accesstoken.php">Get Access Token !</a></li>
<?php
	if($_GET["error"])
	{
		echo '<li class="error">';
	}
    $error = $_GET["error"];
	if($error == 'notoken')
	{
		echo 'Enter Access Token !';
	}
	if($error == 'invalidtoken')
	{
		echo 'Invalid Access Token !';
	}
	if($error == 'expiredtoken')
	{
		echo 'Access Token Expired !';
	}
	if($error == 'invalidtokenperm')
	{
		echo 'Allow App To Access Your Profile !';
	}
	if($error == 'invalidtokenapp')
	{
		echo 'Invalid Access Token App !';
	}
	if($_GET["error"])
	{
		echo '</li>';
	}
?>
<li>
<form method="GET" action="home.php">Access Token<br><input name="accesstoken">
</li>
<li>
<center><br><input value="Log In" type="submit"></form></center>
</li>
<?php else : ?>
<li><center>Website Under Construction !</center></li>
<?php endif ?>
</div>
<?php
require('footer.php');
?>