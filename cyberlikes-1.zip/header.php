<?php
session_start();header('Content-type: text/html; charset=utf-8');
if (!function_exists('curl_init'))
{
	die('Error : Facebook needs the CURL PHP extension.');
}
if(!function_exists('json_decode'))
{
	die('Error : Facebook needs the JSON PHP extension.');
}
require'info.php';
if(!file_exists('database'))
{
	$oldmask = umask(0);
	mkdir('database',0777,true);
	umask($oldmask);
}
?>
<?php
	$title = "Auto Liker";
	$desc = "Auto Liker";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title><?php echo $title;?></title>
<meta name="description" content="<?php echo $desc; ?>" />
<meta charset="UTF-8" /><meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta content='general' name='rating' />
<meta name="robots" content="index, follow" />
<meta name="keywords" content="Auto-Liker" />
<link rel="icon" type="image/x-icon" href="images/favicon.ico" />
<link rel="stylesheet" href="css.css" type="text/css">
</head>
<body>
<div id="header">
<h1><?php echo $set[main_heading]; ?></h1>
<p class="description"><?php echo $set[sub_heading]; ?></p>
<div id="nav-top">
<a href="index.php">HOME</a>
<a href="m-users.php">USERS</a>
<?php if($_SESSION['login'] || $_COOKIE['accesstokenL'] || $_SESSION['password'])echo'<a href="logout.php">LOGOUT</a>';else echo '<a href="admin.php">ADMIN</a>';?>
</div>
</div>