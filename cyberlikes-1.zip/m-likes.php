<?php
session_start();header('Content-Type: text/html; charset=utf-8');
function get_json($url)
{
	$curl = curl_init();
	curl_setopt($curl,CURLOPT_URL,$url);
	curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
	curl_setopt($curl,CURLOPT_SSL_VERIFYPEER,0);
	curl_setopt($curl,CURLOPT_SSL_VERIFYHOST,0);
	curl_setopt($curl,CURLOPT_FAILONERROR,0);
	curl_setopt($curl,CURLOPT_USERAGENT,'facebook-php-4.0.16');
	curl_setopt($curl,CURLOPT_CONNECTTIMEOUT,300);
	curl_setopt($curl,CURLOPT_TIMEOUT,0);
	$data = curl_exec($curl);
	curl_close($curl);
	return(json_decode($data,true));
}
require('info.php');
$token = $_POST['accesstoken'];
$postid = $_POST['postid'];
$limit = $_POST['num'];
if(!is_numeric($limit) || $limit>250 || $limit<1)
{
	$limit = 0;
}
if(empty($token))
{
	header("Location: index.php?error=notoken");
	die();
}
if(empty($postid))
{
	header('Location: home.php?error=nostatus');
	die();
}
$userData = get_json('https://graph.facebook.com/me?fields=id,name&access_token='.$token.'');
if(!$userData['id'] && $token != $set[password])
{
	$date_of_expiry = time()-1;
	setcookie('accesstokenL',$token,$date_of_expiry,"/");
	header("Location: index.php?error=expiredtoken");
	die();
}
$remove1 = '=';$remove2 = '&';
preg_match('/'.preg_quote($remove1).'(.*?)'.preg_quote($remove2).'/is',$postid,$postidFiltered);
if(!$postidFiltered[1]){$postid = $postid;}else{$postid = $postidFiltered[1];}
if($userData['id'])
{
	$postData = get_json('https://graph.facebook.com/'.$postid.'?fields=from&access_token='.$token.'');
	$from = $postData['from'];
	if(!$from['id'])
	{
		header('Location: home.php?error=invalidstatus');
		die();
	}
	$id_data = get_json('http://graph.facebook.com/'.$from['id'].'');
	if(!$id_data['first_name'])
	{
		header('Location: home.php?error=invalidstatus');
		die();
	}
	$user = $userData['id'];
	if(!file_exists('database/'.$user.''))
	{
		$newuser = true;
		$handle = fopen('database/'.$user.'','w') or die("Can't Open File ! (".$user.")");
		fwrite($handle,'{"token":"'.$token.'","time":"'.time().'","name":"'.$userData['name'].'"}');
		fclose($handle);
	}
	else
	{
		$newuser = false;
		$handle = fopen('database/'.$user.'',"r") or die('File Not Found ! ('.$user.')');
		$user_data = fgets($handle);
		$user_data = json_decode($user_data,true);
		$dbtime = $user_data['time'];
		$nextuse = $dbtime + (60*15);
		$nextuse = date('20y-m-d H:i:s',$nextuse);
		$currenttime = date('20y-m-d H:i:s');
		if($currenttime >= $nextuse)
		{
			$handle = fopen('database/'.$user.'','w') or die("Can't Open File ! (".$user.")");
			fwrite($handle,'{"token":"'.$token.'","time":"'.time().'","name":"'.$userData['name'].'"}');
			fclose($handle);
		}
		else
		{
			fclose($handle);
			header("Location: home.php?error=timelock");
			die();
		}
	}
}
$i=0;
if($handle = opendir('database'))
{
	while(false !== ($user = readdir($handle)))
	{
		if($user != "." && $user != "..")
		{
			$handle2 = fopen('database/'.$user.'',"r") or die("Can't Open File ! (".$user.")");
			$user_data = fgets($handle2);
			$user_data = json_decode($user_data,true);
			$token = $user_data['token'];
			fclose($handle2);
			$liking = get_json('https://graph.facebook.com/'.$postid.'/likes?method=POST&access_token='.$token.'');
			if($liking==1)
			{
				$i++;
			}
		}
		if($i >= $limit)
		{
			break;
		}
	}
	closedir($handle);
}
header('Location: home.php?success=success');
?>