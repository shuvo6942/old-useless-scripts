﻿<?php
error_reporting(0);
include('header.php');
function get_json($url)
{
	$curl = curl_init();
	curl_setopt($curl,CURLOPT_URL,$url);
	curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
	curl_setopt($curl,CURLOPT_SSL_VERIFYPEER,0);
	curl_setopt($curl,CURLOPT_SSL_VERIFYHOST,0);
	curl_setopt($curl,CURLOPT_FAILONERROR,0);
	curl_setopt($curl,CURLOPT_USERAGENT,'facebook-php-4.0.16');
	curl_setopt($curl,CURLOPT_CONNECTTIMEOUT,300);
	curl_setopt($curl,CURLOPT_TIMEOUT,0);
	$data = curl_exec($curl);
	curl_close($curl);
	return(json_decode($data,true));
}
?>
<div class="menu">
	<h3>Users</h3>
	<?php
		$empty = 0;
		if($handle = opendir('database'))
		{
			while (false !== ($entry = readdir($handle)))
			{
			if($entry != "." && $entry != "..")
			{
				if(is_numeric($entry))
				{
					$empty = 1;
					$user = fopen('database/'.$entry.'',"r") or die('Error !');
					$user_data = fgets($user);
					$user_data = json_decode($user_data,true);
					$name = $user_data['name'];
					$token = $user_data['token'];
					fclose($user);
					$userData = get_json('https://graph.facebook.com/me?fields=id&access_token='.$token.'');
					if(!$userData['id'])
					{
						echo '<li><font color="red">'.$name.'</font></li>';
						unlink('database/'.$entry.'');
					}
					else
					{
						echo '<li><font color="green">'.$name.'</font></li>';
					}
				}
			}
			}
			closedir($handle);
		}
		if($empty == 0)
		{
			echo '<li><a href="#">Empty Database !</a></li>';
		}
	?>
</div>
<?php
include 'footer.php';
?>