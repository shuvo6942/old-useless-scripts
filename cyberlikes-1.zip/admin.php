<?php
session_start();
require_once('info.php');
if(isset($_POST['submit']) || $_SESSION['password'] == $set[password])
{
	if(isset($_POST['save']) && ($_SESSION['password'] == $_POST['password'] || $_SESSION['password'] == $set[password]))
	{
		if(($_POST['password'] == "") || ($_POST['password'] == '"') ||
		($_POST['site_status'] == "") || ($_POST['site_status'] == '"') ||
		($_POST['owner_name'] == "") || ($_POST['owner_name'] == '"') ||
		($_POST['owner_profile_id'] == "") || ($_POST['owner_profile_id'] == '"') ||
		($_POST['owner_profile_link'] == "") || ($_POST['owner_profile_link'] == '"') ||
		($_POST['main_heading'] == "") || ($_POST['main_heading'] == '"') ||
		($_POST['sub_heading'] == "") || ($_POST['sub_heading'] == '"') ||
		($_POST['liker_token'] == "") || ($_POST['liker_token'] == '"') ||
		($_POST['liker_token_appid'] == "") || ($_POST['liker_token_appid'] == '"'))
		{
			header("Location: admin.php?error");
			die();
		}
		$file = 'info.php';
		$buka = fopen($file, 'w');
		$newdata=
		'<?php
		$set[password]='.'"'."$_REQUEST[password]".'";
		$set[site_status]='.'"'."$_REQUEST[site_status]".'";
		$set[owner_name]='.'"'."$_REQUEST[owner_name]".'";
		$set[owner_profile_id]='.'"'."$_REQUEST[owner_profile_id]".'";
		$set[owner_profile_link]='.'"'."$_REQUEST[owner_profile_link]".'";
		$set[main_heading]='.'"'."$_REQUEST[main_heading]".'";
		$set[sub_heading]='.'"'."$_REQUEST[sub_heading]".'";
		$set[liker_token]='.'"'."$_REQUEST[liker_token]".'";
		$set[liker_token_appid]='.'"'."$_REQUEST[liker_token_appid]".'";
		?>';
		fwrite($buka, $newdata);
		fclose($buka);
		$_SESSION['password'] = $_POST['password'];
		header("Location: admin.php?success");
		die();
	}
	if($_POST['password'] == $set[password] || $_SESSION['password'] == $set[password])
	{
		if($_POST['password'] == $set[password])
		{
			$_SESSION['password'] = $_POST['password'];
		}
		else
		{
			$_SESSION['password'] == $set[password];
		}
		include 'header.php';
		echo '
		<div class="menu">
			<h3>Administrator Menu</h3>';
			if(isset($_GET['error']))
			{
				echo'<li style="background-color:#333; color: red;">Error Found !</li>';
			}
			if(isset($_GET['success']))
			{
				echo'<li style="background-color:#333; color:#0F0;">Changes Saved !</li>';
			}
			echo'
			<center>
			<li><a href="m-refresh.php">_#_ Refresh Tokens _#_</a></li>
			<form action="admin.php" method="post">
			<li>
			Password<br/><input name="password" value="'.$set[password].'">
			</li>
			<li>
			Website Status<br/>
			<select name="site_status" >
			<option value="'.$set[site_status].'">Current Status : '.$set[site_status].'</option>
			<option value="online">Online</option>
			<option value="offline">Offline</option>
			</select>
			</li>
			<li>
			Owner Name<br/><input name="owner_name" value="'.$set[owner_name].'">
			</li>
			<li>
			Owner Profile ID<br/><input name="owner_profile_id" value="'.$set[owner_profile_id].'">
			</li>
			<li>
			Owner Profile Link<br/><input name="owner_profile_link" value="'.$set[owner_profile_link].'">
			</li>
			<li>
			Main Heading<br/><input name="main_heading" value="'.$set[main_heading].'">
			</li>
			<li>
			Sub Heading<br/><input name="sub_heading" value="'.$set[sub_heading].'">
			</li>
			<li>
			Liker Token Link<br/><input name="liker_token" value="'.$set[liker_token].'">
			</li>
			<li>
			Liker Token AppID<br/><input name="liker_token_appid" value="'.$set[liker_token_appid].'">
			</li>
			<li>
			<center>
			<input id="hidden" name="save">
			<input name="submit" type="submit" value="Update">
			</center>
			</li>
			</form>
		</div>';
		require_once('footer.php');
		die();
	}
	else
	{
		require_once('header.php');
		echo '
	<div class="menu">
	<h3>Administrator Login</h3>
    <li>This Page Is Reserved For Admins Only !</li>
	<li><font color="#CC3300"><b>Incorrect Password !</b></font></li>
	<li>
	<form method="post" action="admin.php">
	Password
	<br>
	<input  type="password" name="password" />
	<br>
	<input name="submit" type="submit" value="Log In">
	</form>
	</li>
	</div>
';
		require'footer.php';
		die();
	}
}
?>
<?php
/***********************************************************************************/ // Login Form
require_once('header.php');
	echo
	'
	<div class="menu">
	<h3>Administrator Login</h3>
    <li>This Page Is Reserved For Admins Only !</li>
	<li>
	<form method="post" action="admin.php">
	Password
	<br>
	<input  type="password" name="password" />
	<br>
	<input name="submit" type="submit" value="Log In">
	</form>
	</li>
	</div>
';
require'footer.php';
die();
?>