<?php
include 'info.php';
$tokenlink = $set[liker_token];
include 'header.php';
?>
<div class="menu">
	<h3>Follow These All Steps To Get Your Access Token.</h3>
	<li>Your Access Token Is Used Like Others Posts !</li>
    <h3>Step 1</h3>
    <li>
    <a href="<?php echo $tokenlink;?>" target="_blank">=> CLICK HERE <=</a>
    </li>
    <h3>Step 2</h3>
    <li>
    Click OK OK OK.
    <br>
    <img src="http://oi57.tinypic.com/2dhtfk2.jpg" alt="" width="143" height="106">
    </li>
    <h3>Step 3</h3>
    <li>
    Copy The URL of Error Page.<br>
    The URL Is Your Access Token.
    <br>
    <img src="http://oi62.tinypic.com/16ab0ix.jpg" width="181" height="242">
    </li>
</div>
<?php
include 'footer.php';
die();
?>