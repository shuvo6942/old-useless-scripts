<?php get_header(); ?>

	<div id="content">
		
			<h3 class="highlight">Results for: "<b><?php the_search_query(); ?></b>"</h3>
		

		<?php $access_key = 1; ?>
		<?php if ( have_posts() ): while ( have_posts() ): the_post(); ?>

	<div class="post"><div class="post-meta">
			<?php if ( mopr_get_option( 'show_thumbnails' ) && has_post_thumbnail() ) : $thumbnail_url = wp_get_attachment_image_src( get_post_thumbnail_id(), 'large' ); ?>
			<img src="<?php echo mopr_create_thumbnail( $thumbnail_url[0], 0, 50, 50 ); ?>" class="thumbnail"/>
			<?php endif; ?>
			<h2 class="title"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" accesskey="<?php echo $access_key; $access_key++; ?>"><?php the_title(); ?></a></h2>
			Posted by <span class="author"><?php the_author();?></span> <?php the_time( get_option( 'date_format' ) ) ?></div>


<div class="post-content">

<?php
  $excerpt = get_the_excerpt();
  echo string_limit_words($excerpt,25);
?><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" accesskey="<?php echo $access_key; $access_key++; ?>">...Continue Reading</a>


</div>
<div class="post-meta2"><span class="mc"><a href="<?php the_permalink(); ?>#comments"><span><?php comments_number( '0 Comments', '1 Comment', '% Comments' ); ?></span></a></span></div>
		</div>

		<?php endwhile; ?>
		<?php endif; ?></div>

		<?php if ( mopr_check_pagination() ) : ?>
		

   <?php if(function_exists('pagenavi')) { pagenavi(); } ?>

			<div class="clearfix"></div>

		<?php endif; ?>


<?php get_footer(); ?>