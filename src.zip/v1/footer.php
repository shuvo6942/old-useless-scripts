<?php  include'config.php';

  echo' <div class="block_posts"> '.$footerAd.'
<h2 align="center">&copy; '.date("Y").' -  '.$site.'</h2>';
echo'</body> </html>';  ?>
