<?php
$site='HamWap.Ga';  // Your Site Name
$admin='Gabber Man';  // Your Name

$fbPage='<a href="http://facebook.com/hamwap2016">সকল আপডেট পেতে ক্লিক করুন </a>';  // Your Page
$headerAd='<div class="ad_block"><center> <a href="http://hamwap.com"><img src="http://hamwap.com/img/HeaderAd.jpg"/> </a></center></div>';  // Your Header Ad
$footerAd='<div class="ad_block"><center> <a href="http://hamwap.com"><img src="http://hamwap.com/img/footerAd.jpg"/> </a></center></div>';  // Your Footer Ad
$postAd='<div class="author_block">
<h2> Our Top News</h2>
<div class="ad_block" >
<a href="http://facebook.com/huzaifa.ham">Huzaifa Ham... Fb Id</a>
</div>
</div>';  // Your Post/Middle Ad