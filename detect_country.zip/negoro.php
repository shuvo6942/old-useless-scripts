<?php
/*
Script modif dari :
http://indro.alqaeda.ca
Skrip ini bebas untuk digunakan dan disebarluaskan dengan resiko ditanggung masing-masing.
Syarat skrip ini berfungsi adalah server yang enable curl.
Cara penggunaan: include file ini ke halamanmu.
Kalau cuma ingin menampilkan negara tinggal edit bagian echo di bawah.
* *
Nb dari g3ni: Hati2 dgn penggunaan Curl script karena dpt membahayakan host dan server. Jika tdk mendesak, jgn gunakan terlalu bnyk curl.
* *
*/
$forward = $_SERVER["HTTP_X_FORWARDED_FOR"];
$for = explode(",", $forward);
if ($_SERVER["HTTP_X_FORWARDED_FOR"] != "") { $ad = $for[0]; }
else
$ad = $_SERVER['REMOTE_ADDR'];
$url = "http://mobilust.net/whoisip/default.asp?B1=Check&ip=$ad";

$ch = curl_init();
curl_setopt ($ch, CURLOPT_URL, $url);
curl_setopt ($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

$content = curl_exec ($ch);
curl_close ($ch);

$gambar = explode("<b>Country:</b> ", $content);
$flag = explode("</img>", $gambar[1]);
$gendero = $flag[0];
$gendero = str_replace('/onlines', 'http://mobilust.net/onlines', $gendero);

$isi = explode("</img>", $content);
$mumet = explode("<br/>", $isi[1]);
$negara = $mumet[0];
$stres = explode("</b>", $mumet[1]);
$oper = explode("<div", $stres[1]);
$isp = $oper[0];
echo "IP-mu : $ad <br>Negara : $negara $gendero <br>ISP : $isp";
exit;
?>