<?php
require_once ("header.php");
    
echo '<h2>Online Users Details</h2>';
$data = file('online.txt');

foreach($data as $val)
{
$ex = explode('::', $val);
$ex2 = explode(' ', $ex[0]);

$punk = explode('.', $ex[1]);
$hiddenip = ''.$punk[0].'.'.$punk[1].'.'.$punk[2].'.xxx';
$page = str_replace('%20',' ',$ex[2]);

$i++;
echo " <div class=\"search\"><b><font color=\"#ff0000\">$i.</font> </b>$ex[0]<br/><b><font color=\"#ff0000\">IP:</font></b> $hiddenip<br/><b><font color=\"#FF0000\">Current Page:</font></b> <a href=\"".$siteurl."$ex[2]\">".$siteurl."$page</a></div>";}
require_once ("footer.php");
    
?>