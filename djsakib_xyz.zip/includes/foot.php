﻿<?php
include 'includes/info.php';
?>

<div class="header" style="text-align:center">Copyright &copy; 2016 DJSakib.xyz</div></body></html>