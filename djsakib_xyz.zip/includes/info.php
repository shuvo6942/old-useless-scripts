<?php

$site = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'].'';

$host = $_SERVER['HTTP_HOST'];

$sitename ='DJSakib.xyz'; // Your Site Name

$logo = '/images/logo.png'; //Logo Picture URL

$google = '/googled3b9f9006c07f297.html'; //Google Verification Code

$alexa = 'Alexa Verification Code'; //Alexa Verification Code

$bing = 'Bing Web master Tool ID'; //Bing Verification Code

$facebook = 'https://facebook.com/Khalequzzaman24'; //Facebook Fanpage URL

$twitter = 'https://twitter.com/Khalequzzaman24'; //Twitter URL

$google = 'https://plus.google.com/Khalequzzaman24'; //Your Google+ Here

$mail = 'admin@djsakib.xyz'; //Your Email Here

$info = 'YouTube Video Downloader';

$adb =''; // nothing

$adt = ''; // nothing

$keywords ='Free, downmload, video, youtube, api v3, youtube downloader to mp3, mp3, 3gp, webm, popular, news, on the spot, gaming, music, hollywood, bollywood, disney, animation, animal, funny, movies, films, konser, sinetron';

?>