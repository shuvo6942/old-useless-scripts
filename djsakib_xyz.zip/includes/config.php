<?php
include 'info.php';
?>
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<head>
<meta http-equiv="content-type" content="application/xhtml xml; charset=utf-8"/>
<meta name="google-site-verification" content="<?php echo $google;?>"/>
<title><?php echo $title;?></title> 
<meta name="description" content="Live Streaming  And Free Download youtube videos in hd 3gp mp4 and flv format directly on your Mobile browsers."/>
<meta name="keywords" content="<?php echo $keywords;?>"/>
<meta name="msvalidate.01" content="<?php echo ''.$bing.'';?>"/>
<meta name="alexaVerifyID" content="<?php echo ''.$alexa.'';?>" />
<meta name="robots" content="index,follow"/>
<meta property="og:title" content="Mobile Youtube Video Downloder And Converter"/>
<meta property="og:url" content="http://<?php echo ''.$host.'';?>/"/>
<meta property="og:image" content="http://<?php echo ''.$host.'';?><?php echo ''.$logo.'';?>"/>
<meta name="viewport" content="width=device-width,initial-scale=1.0"/><link rel="stylesheet" href="http://exyoutube.com/style.css"/>
<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css"/>
<link media="handheld,all" href="/style.css" rel="stylesheet" type="text/css" />
<link media="handheld,all" href="http://exyoutube.com/style.css" rel="stylesheet" type="text/css"/>
<style type="text/css">
body img {max-width:98%;max-height:50%}
body {max-width:98%;max-height:50%}
width {max-width:98%;max-height:50%}
img {max-width:98%;max-height:50%}
</style>
<link rel="icon" href="/favicon.ico" type="image/x-icon"/>
<link rel="stylesheet" href="http://waptube.net/style.css" type="text/css"/><link rel="stylesheet" href="http://limon24.wap.sh/css/callback.css" type="text/css"/>
</head>
<body>
<div class="c"><center>
<a href="/"><img src="<?php echo ''.$logo.'';?>" alt="<?php echo ''.$sitename.'';?>" height="60" width="280" /></center></a>
</div><div id="groupp">
<div class="group" align="center">
<form action="/search.php" method="get">
<input type="text" name="q" placeholder="Write video name..."/> 
<input type="submit" value="Search" title="Search"/>
</form>
</div>