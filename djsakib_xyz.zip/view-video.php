<?php
include 'includes/func.php';
include 'includes/info.php';
$yf=ngegrab('https://www.googleapis.com/youtube/v3/videos?key='.$devkey.'&part=snippet,contentDetails,statistics,topicDetails&id='.$_GET['id'].'');
$yf=json_decode($yf);

// WapTube API here.

$mdlink = file_get_contents('http://api.waptube.net/video-mp4?v='.$_GET['id'].''); 
$mdlink=str_replace('yoursite',''.$sitename.'',$mdlink); // Site Name Replaceing
$mdlink=str_replace('<span class="didl">','<span class="didl">',$mdlink); // Span Class Replaceing
$mdlink=str_replace('<div class="dllink" align="left" style="padding: 6px;">','<div class="dllink" align="left" style="padding: 6px;">',$mdlink); // Div Class Replaceing

if($yf){
foreach ($yf->items as $item)
{

$name=$item->snippet->title;
$des = $item->snippet->description;
$date = dateyt($item->snippet->publishedAt);
$channelId = $item->snippet->channelId;
$chtitle = $item->snippet->channelTitle;
$ctd=$item->contentDetails;
$duration=format_time($ctd->duration);
$hd = $ctd->definition;
$st= $item->statistics;
$views = $st->viewCount;
$likes = $st->likeCount;
$dislike = $st->dislikeCount;
$favoriteCount = $st->favoriteCount;
$commentCount = $st->commentCount;
{$title='Download '.$name.' ('.$duration.') in 3GP, MP4, FLV and WEBM Format';}
$tag=$name;
$tag=str_replace(" ",",", $tag);
$dtag=$des;
include 'includes/config.php';
echo '<div class="subheader" align="center">'.$name.'</div>';
echo '<div class="group" align="center">';
echo '<img src="http://img.youtube.com/vi/'.$_GET['id'].'/hqdefault.jpg" width="300" height="auto"/>';
echo '<br/>';
echo '<img src="http://ytimg.googleusercontent.com/vi/'.$_GET['id'].'/1.jpg"/><img src="http://ytimg.googleusercontent.com/vi/'.$_GET['id'].'/2.jpg"/><img src="http://ytimg.googleusercontent.com/vi/'.$_GET['id'].'/3.jpg"/>';
echo ''.$adb.'</div>';
echo '<div class="group">';
echo '<table>';
echo '<tr valign="top">';
echo '<td width="30%">Title</td>';
echo '<td>:</td>';
echo '<td><a href="">'.$name.'</a></td>';
echo '</tr>';
echo '<tr valign="top">';
echo '<td width="30%">Duration</td>';
echo '<td>:</td>';
echo '<td>'.$duration.' Min</td>';
echo '</tr>';
echo '<tr valign="top">';
echo '<td width="30%">Extensions</td>';
echo '<td>:</td>';
echo '<td>MP4 + 3GP + FLV + WEBM</td>';
echo '</tr>';
echo '<tr valign="top">';
echo '<td width="30%">Channel</td>';
echo '<td>:</td>';
echo '<td>'.$chtitle.'</td>';
echo '</tr>';
echo '<tr valign="top">';
echo '<td width="30%">Uploaded At</td>';
echo '<td>:</td>';
echo '<td>'.$date.'</td>';
echo '</tr>';
echo '<tr valign="top">';
echo '<td width="30%">Views</td>';
echo '<td>:</td>';
echo '<td>'.$views.'</td>';
echo '</tr>';
echo '<tr valign="top">';
echo '<td width="30%">Likes</td>';
echo '<td>:</td>';
echo '<td>'.$likes.'</td>';
echo '</tr>';
echo '<tr valign="top">';
echo '<td width="30%">Source</td>';
echo '<td>:</td>';
echo '<td><a href="https://www.youtube.com/watch?v='.$_GET['id'].'"><font color="red"><b>YouTube</b></font></a></td>';
echo '</table>';
echo '</div>';
echo '<div class="subheader" align="center">Download Video</div>';
echo ''.$mdlink.'';
echo ''.$des.'';
echo '</div><div class="subheader" align="center">Share</div>';
echo '<div class="group" align="center">';
echo '<br/>';
echo '<input type="text" value="http://'.$host.'/video-download/'.$_GET['id'].'/'.$final.'.html"/>';
echo '</div>';
}
}
include 'related.php';
include 'includes/foot.php';
?>