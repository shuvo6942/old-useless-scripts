<?php
include 'includes/func.php';

$title  = 'DJSakib.xyz - YouTube Video Downloader'; //Edit Homepage Title

include 'includes/config.php';
echo'<div class="header">Top Updated Videos</div>';
if($_GET['q']){
$q = $_GET['q'];
} else {
$a = array("timesmusic");
$b = count($a)-1;
$q = $a[rand(0,$b)];
}
$qu=$q;
$qu=str_replace(" ","+", $qu);
$qu=str_replace("-","+", $qu);
$qu=str_replace("_","+", $qu);
if(strlen($_GET['page']) >1){$yesPage=$_GET['page'];}
else{$yesPage='';}
$grab=ngegrab('https://www.googleapis.com/youtube/v3/search?key='.$devkey.'&part=snippet&order=relevance&maxResults=15&q='.$qu.'&pageToken='.$yesPage.'&type=video');
$json = json_decode($grab);
$nextpage=$json->nextPageToken;
$prevpage=$json->prevPageToken;
if($json)
{
foreach ($json->items as $sam)
{
$link= $sam->id->videoId;
$name= $sam->snippet->title;
$desc = $sam->snippet->description;
$chtitle = $sam->snippet->channelTitle;
$chid = $sam->snippet->channelId;
$date = dateyt($sam->snippet->publishedAt);
$sam = ngegrab('https://www.googleapis.com/youtube/v3/videos?key='.$devkey.'&part=contentDetails,statistics&id='.$link.'');
$linkmake = preg_replace("/[^A-Za-z0-9[:space:]]/","$1",$name);
$linkmake = str_replace(' ','-',$linkmake);
$final = strtolower("$linkmake");
$dt=json_decode($sam);
foreach ($dt->items as $dta){
$time=$dta->contentDetails->duration;
$duration= format_time($time);
$views= $dta->statistics->viewCount;   
}
echo '<div class="x">';
echo '<div class="link">';
echo '<a href="/video-download/'.$link.'/'.$final.'.html">';
echo '<table>';
echo '<tbody>';
echo '<tr valign="middle">';
echo '<td>';
echo '<a href="'.$adt.'"><img src="http://ytimg.googleusercontent.com/vi/'.$link.'/mqdefault.jpg" alt="Thumbnail" height="60px" width="100px" class="thumb"></a>';
echo '</td>';
echo '<td style="padding-left:2px;">';
echo '<div style="padding-bottom:1px;">';
echo '<td valign="top">';
echo '<font color="green">'.$name.'</font><br />Duration: '.$duration.' Min<br/>Views: '.$views.'';
echo '</td>';
echo '</tr>';
echo '</tbody>';
echo '</table>';
echo '</a>';
echo '</div>';
echo '</div>';
}
echo '<div class="topmenu" align="center">';
if (strlen($prevpage)>1)
{
echo '<a href="/page/'.$prevpage.'" class="page">&#171; Prev Page</a> ';}
if (strlen($nextpage)>1)
{
echo '<a href="/page/'.$nextpage.'" class="ad1">Next Page &#187;</a>';
}
echo '</div>';
}
include 'includes/foot.php';
?>