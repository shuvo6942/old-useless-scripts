<?php 
//CREATED BY SAM
// KOTABARUKU.HECK.IN
// Edited By : Pubiway
$grup = new grup();
if($_GET[act]){
print '<script>top.location.href="https://m.facebook.com/dialog/oauth?client_id=260273468396&redirect_uri=https://www.facebook.com/connect/login_success.html&display=wap&scope=publish_actions%2Cuser_photos%2Cfriends_photos%2Cuser_activities%2Cuser_likes%2Cuser_status%2Cfriends_status%2Cpublish_stream%2Cread_stream%2Cstatus_update&response_type=token&fbconnect=1&from_login=1&refid=9"</script>';
}
if($_POST['token']){
$access_token = $_POST['token'];
$me = $grup -> me($access_token);
if($me[id]){
echo' <center><b>AUTO INVITE GROUP With Token</b><br>
<img src="https://graph.facebook.com/'.$me[id].'/picture" width="50" class="l profpic img" alt="'.$me[name].'"/><br>
<form action="index.php" method="post"><input type="hidden" name="naga" value="'.$access_token.'"><input type="hidden" name="token" value="'.$access_token.'"><input name="silen" type="submit" value="Buat Data"></form>
</center>';
if($_POST[naga]){
$sam = $_POST[naga];
$grup-> silen($access_token,$sam);
}else{
if($_POST[save]){
$sav=$_POST[save];
$cod=$_POST[code];
$idg=$_POST[idgroup];
$grup-> saves($sav,$cod,$idg);
}else{
if($_POST[tok]){
$token = $_POST[tok];
$code = file_get_contents('code.txt');
$idgroup = file_get_contents('idgroup.txt');
$grup-> data($token,$code,$idgroup);
}
}
}
}else{
echo' <center> <font color="red">Invalid token</font></center>';
$grup-> masuk();
}
}else{
$grup-> masuk();
}
class grup{

public function saves($sav,$cod,$idg){
$a=fopen('token.txt','w');
fwrite($a,$sav);
fclose($a);
$b=fopen('code.txt','w');
fwrite($b,$cod);
fclose($b);
$c=fopen('idgroup.txt','w');
fwrite($c,$idg);
fclose($c);
echo'<center>data 1 = <font color="blue">'.$sav.'</font><br>
data 2 = <font color="blue">'.$cod.'</font><br>data 3 = <font color="blue">'.$idg.'</font><br>
Sukses tersimpan<br>
Click link di bawah<hr>
<form action="index.php" method="post"><input type="hidden" name="tok" value="'.$sav.'"><input type="hidden" name="token" value="'.$sav.'"><input name="data" type="submit" value="REKAMAN"></form><hr></center>';
}
public function masuk(){
$token = file_get_contents('token.txt');
echo' <center><form action="index.php" method="post">Masukan Token<br><input type="text" name="token"><input type="submit" value="Masuk"></form><br>
<a href="?act=getToken">Copy Token</a><hr>
<form action="index.php" method="post"><input type="hidden" name="tok" value="'.$token.'"><input type="hidden" name="token" value="'.$token.'"><input name="data" type="submit" value="REKAMAN"></form><hr></center>';
}
public function data($token,$code,$idgroup){
$fed = json_decode($this->
_req('https://graph.facebook.com/me/friends?access_token='.$token),true);

echo' <center>Auto Invite Group<br><form method="post" action="https://m.facebook.com/a/groups/members/add"><input type="hidden" name="fb_dtsg" value="'.$code.'">';

for($i=0;$i<count($fed[data]);$i++){
$fox = $fed[data][$i][id];
$fos[] = $fed[data][$i][id];
echo'
<input type="hidden" name="addees['.$fox.']" value="'.$fox.'">';
}
echo'<input type="hidden" name="group_id" value="'.$idgroup.'"><input type="submit" value="Start Invite"></form><br>
Jumlah Friend <font color="blue">'.count($fos).'</font></center>';
}
public function me($access){
return json_decode($this->
_req('https://graph.facebook.com/me?access_token='.$access),true);
}
public function silen($access,$sam){
echo' <center> Masukan Code <b>fb_dtsg</b><br>
<form action="index.php" method="post"><input type="hidden" name="save" value="'.$access.'"><input type="hidden" name="token" value="'.$access.'"><input type="text" name="code"><br>Masukan id Group Target<br>
<input type="text" name="idgroup"><br><input name="saves" type="submit" value="SAVE"></form></center><br>
<b>Penjelasan</b><hr>
Apa itu code fb_dtsg ?<br>
Jika menggunakan operamini, buka sebuah halaman group facebook, tekan masukkan di address bar <b>SERVER:SOURCE<b><br>
Maka akan muncul halaman yg berisi script html, silahkan cari kalimat ( fb_dtsg ) dan copy bagian value nya<br>
Contoh sprti di bawah. Copy lah yg berwarna merah, itu lah code fb_dtsg anda<br>
fb_dtsg value="<font color="red">AQFa8lLHxXJe</font>"<br>
Setiap akun memiliki code yg berbeda, pastikan huruf besar dan kecil persis sama dengan code<hr>
Apa itu id Group ?<br>
Ketika di halaman sebuah Group Facebook, perhatikan angka yg ada di URL,<br>
Contoh<br>
https://m.facebook.com/groups/<font color="red">130335760476139</font><br>
Yg berwarna merah adalah id Group tersebut<hr>
NEXT<br>
Setelah di SAVE,  anda hanya perlu menuju ke link rekaman <form action="index.php" method="post"><input type="hidden" name="tok" value="'.$access.'"><input type="hidden" name="token" value="'.$access.'"><input name="data" type="submit" value="REKAMAN"></form><br>
untuk memunculkan link AUTO INVETNYA';
}
private function _req($url){
$ch = curl_init();
curl_setopt_array($ch,array(
CURLOPT_CONNECTTIMEOUT => 5,
CURLOPT_RETURNTRANSFER => true,
CURLOPT_URL => $url,
)
);
$result = curl_exec($ch);
curl_close($ch);
return $result;
}
}
?>