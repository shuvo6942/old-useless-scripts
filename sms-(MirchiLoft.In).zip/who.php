<?php

$headmod = 'mtube.pankajbd.com';
$textl = 'Online User Details &raquo; ';
require_once ("header.php");
    
echo '<div class="mainblok"><div class="phdr"><b>Online Users Details</b></div>';
$data = file('online.txt');

foreach($data as $val)
{
$ex = explode('::', $val);
$ex2 = explode(' ', $ex[0]);

$punk = explode('.', $ex[1]);
$hiddenip = ''.$punk[0].'.'.$punk[1].'.'.$punk[2].'.'.$punk[3].'';
$page = str_replace('%20',' ',$ex[2]);

$i++;
echo $i % 2 ? '<div class="menu2">' : '<div class="rmenu">';
echo "<b>$i. </b>$ex[0]<br/><b>IP:</b> $hiddenip<br/><b>Current Page:</b> <a href=\"$ex[2]\">http://egyoutube.com$page</a></div>"; 
$ii++;
}
echo'</div>';
require_once ("footer.php");
    
?>