<?php 
function passgen($length) { $vals =
"abcdefghijklmnopqrstuvwxyz0123456789"; 
$result = '';
for ($i = 1; $i <= $length; $i++) { $result .= $vals{rand(0, strlen($vals))}; }
return $result;
}

include'includes/config.php'; 
$NTITLE='Password Reset';
include'header.php'; 
echo'<h2>Password Reset</h2>';
if(isset($_POST['submit']))
{ 
 $mail=$_POST['mail'];
 $res=$db->query("select *
from users where email='".
$mail."'");
if($db->query("select *
from users where email='".
$mail."'")){
$newpass = passgen(10);

$db->query('update users set password="'.md5($newpass).'" where email="'.mysql_real_escape_string($mail).'"');

  $to=$res[0]['email'];
  $subject='Your New Password Request (no replay)';
  $message='Hello '.$res[0]['username'].', 

Your New Account Details: 
Username: '.$res[0]['username'].' 
Password: '.$newpass.' 
Email: '.$res[0]['email'].' 


Best Regards, 
The '.SITENAME.' Team. 

Developed By: Pankaj 
Phone: +8801738978596 
Email: pongkoj.kumar@gmail.com 
FB: fb.com/pankaj.kumar.420 
';
  $headers='From: "'.SITENAME.'" <'.MAIL.'>';
  $m=mail($to,$subject,
$message,$headers);
  if($m)
  {
    echo'<div class="info">New Password Send Success! <br/> Please Check your inbox/spam folder in mail.</div>';
  }
  else
  {
   echo'<div class="error">mail is not send.</div>';
  }
 }
 else
 {
  echo'<div class="error">User Not Found!</div>';
 }
}
echo'<form action="" method="POST">Email:*<br/><input type="text" name="mail" placeholder="@" /><br/><input type="submit" name="submit" value="Send" /></form>';

echo'<div class="path"> &raquo; <a href="/">Home</a></div>';
include'footer.php';
?>