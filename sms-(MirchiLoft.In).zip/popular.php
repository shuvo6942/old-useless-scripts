<?php
include 'includes/config.php';
include 'header.php';

$NTITLE= 'Popular SMS';
$pagingqry = 'select * from `sms` order by sms_copy desc';
$rowsPerPage=10;
$gets='?';
$pagelink = BASE_PATH.'smslist/popular/';
include("includes/paging.php");

$SMS = $db->query($pagingqry.$limit);

$PATH = '&raquo;&nbsp;<a href="'.BASE_PATH.'">Home</a>&nbsp;';

echo '<!-- pongkoj.kumar@gmail.com :: Display Random sms -->';
?>
<h2>Latest SMS</h2>
<?php
$sms_tot = count($SMS);
for($i=0;$i<$sms_tot;$i++)
{
echo '<div align="left">';
include'smslist.php';
}
?>
<center>
<?=$PAGE_CODE?>
</center>

<div class="path">
<?=$PATH?>
</div>

<?php
include 'footer.php';
?>
