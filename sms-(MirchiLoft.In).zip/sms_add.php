<?php 
include'includes/config.php';
$db->connect();

if ($_SESSION['userid'] =='') {
header('Location: /err');
exit;
}

$NTITLE= 'Add SMS';
include 'header.php'; 
echo'<h2>Add SMS</h2>';
if ($_POST['submit']) {
if (strlen($_POST['text']) < 10){ 
echo'<div class="error">Please entrer atleast 10 char sms</div>'; } else {
$text =  htmlentities($_REQUEST['text']);
$username = $_SESSION['username'];
$userid = $_SESSION['userid'];
$cid = $_POST['cid'];

$qryUpdate = "insert into usr_post (text, user_id, username, cid, date) VALUES ('".mysql_real_escape_string($text)."', '$userid', '$username', '$cid', '".time()."')";
if($db->query($qryUpdate))
echo'<div class="info">SMS Added Successfully <br/> - Pending for Admin Approval-</div>'; 
}
}

$getcid=$db->query("select DISTINCT cid from sms order by id desc"); 
echo'<div align="left">   <form action="" method="post">Write SMS:<br/><textarea name="text"></textarea><br/>Category:<br/> <select name="cid">'; 
foreach($getcid as $category){ 

$cat=$db->query("select id,name from category where id = ".$category['cid']." order by name"); 
echo'<option value="'.$cat[0]['id'].'">'.$cat[0]['name'].'</option>'; }

echo'</select><br/> <input type="submit" name="submit" id="submit" value="Submit" />    </form></div> ';

include'footer.php'; ?>