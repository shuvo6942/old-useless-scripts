<?php 
include'includes/config.php';
include'header.php'; 
echo'<div class="error">This request page doesn\'t exist.</div>'; 
include'footer.php'; 
?>