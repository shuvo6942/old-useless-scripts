<?php 
include'includes/config.php'; 
$id = $_GET['id'];

$qryUpdate = "update sms set sms_like = sms_like + 1 where id in($id)";

$db->query($qryUpdate);
$SMS = $db->query('select * from sms where id = '.$id,database::GET_ROW);
$CAT = $db->query('select * from category where id = '.$SMS['cid'],database::GET_ROW);

header('Location: /smslist/'.$SMS['cid'].'/'.str_replace(array(' ','%20'),'_',$CAT['name']).'#like'.$SMS['id']);

?>