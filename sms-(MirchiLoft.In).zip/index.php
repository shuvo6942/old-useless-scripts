<?php
include 'includes/config.php';
include 'header.php';
$check = '';
$TOTAL_SMS = 0;
$rowsPerPage=10;

$PATH = '';


if($parentid != 0)
{
$folddetail = $db->query("select * from category where id = ".$parentid, database::GET_ROW);
$seq =  $folddetail['pathc'];
$PATH = '<div class="path">» <a href="'.BASE_PATH.'">Home</a> ';
$PATH .= $seq.'</div>';
}

if($parentid == 0)
{
echo'<div class="catRow"><img src="/images/arrow.gif" alt="Arrow"/> <a href="/smslist/latest">Latest SMS</a></div><div class="catRow"> <img src="/images/arrow.gif" alt="Arrow"/> <a href="/smslist/popular">Popular SMS</a></div><div class="catRow">

<img src="/images/arrow.gif" alt="Arrow"/>
<a href="/topusers">Top Users</a></div>';

$check = 'now';
}
else
{

$getsmscat =  $folddetail['subcate']; 
$FOLDER = $NAME = $folddetail['name'];

if($getsmscat == 0)
{
$checkfileor = $folddetail['totalitem']; 

if($checkfileor != 0)
{
$TOTAL_SMS = 1;
$getsmslist = 'select * from sms where cid = '.$parentid.' order by id desc';

$rowsPerPage=8;
$pagingqry = $getsmslist;
$gets='?';

$pagelink = BASE_PATH.'smslist/'.$parentid.'/'.str_replace(array(' ',' '),'_',$nname).'/';
include("includes/paging.php");

$SMS = $db->query($pagingqry.$limit);
?>
<h2>
<?php
if($nname != '')
echo str_replace('_',' ',$nname);
else
echo 'SMS Categories';
?>
</h2>
<?php
$sms_tot = count($SMS);
for($i=0;$i<$sms_tot;$i++)
{
include'smslist.php';
}

}
}
else
$check = 'now';
}

if($check == 'now' )
{
echo '<!-- mirchiloft.in@gmail.com :: Display category list -->';
?>
<div id='cateogry' align="left">
<h2>
<?php
if($nname != '')
echo str_replace('_',' ',$nname);
else
echo 'SMS Categories';
?>
</h2>
<?php
$rowsPerPage=12;
$pagingqry = "select * from category where parentid = ".$parentid. ' order by posi desc';

$gets='?';

$pagelink = BASE_PATH.'smslist/'.$parentid.'/'.str_replace(' ','_',$_GET['ct']).'/';
include("includes/paging.php");

$CATEGORY = $db->query($pagingqry.$limit);


?>
<div class='catList' align="left">
<?php
$l = 1;
$totcat = count($CATEGORY);
for($i = 0 ; $i < $totcat ; $i++)
{
if($l==1)
{
$l++;
$class = 'catRow';
}
else
{
$l=1;
$class='catRow';
}


echo "<div class='$class'><img src='/images/arrow.gif' alt='Arrow'/> <a href='".BASE_PATH."smslist/".$CATEGORY[$i]['id']."/".str_replace(array(' ',' '),'_',$CATEGORY[$i]['name'])."' class='new_link'>";
echo $CATEGORY[$i]['name'];
if($CATEGORY[$i]['totalitem'] != 0)
{
echo ' ['. $CATEGORY[$i]['totalitem'] . ']';
}

if($CATEGORY[$i]['newitemtag'] == 1){
echo '<img alt="New" src="'.BASE_PATH.'images/new.gif">'; }
echo '</a>';
echo '</div>';
}

if($LOGO != '')
{
echo '<div class="advertisement">';
include 'c'.$agent_ext;
echo '</div>';
}
?>
</div>
</div>
<?
}

if($nname != ''){
echo'<center>'.$PAGE_CODE.'</center>'; }

?>
<br/>
<h2>Partner Site</h2>

<center>
<a href="http://kingfun.biz">Kingfun.Biz</a> |
<a href="http://mirchiloft.in">MirchiLoft.In</a> |
<a href="http://skymp3.info">SKYMp3.Info</a>
</center>



<?=$PATH?>

<?php
include 'footer.php';
?>