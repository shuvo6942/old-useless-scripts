<?php 
$CAT = $db->query('select * from category where id = '.$SMS[$i]['cid'],database::GET_ROW);

echo'<div class="smsRow" id="like'.$SMS[$i]['id'].'"><div class="smsBy">By: <a href="/smslist/uid/'.$SMS[$i]['user_id'].'/'.$SMS[$i]['username'].'">'.$SMS[$i]['username'].'</a> In: <a href="/smslist/'.$SMS[$i]['cid'].'/'.str_replace(array(' ','%20'),'_',$CAT['name']).'">'.$CAT['name'].'</a></div> <p class="sms">'.$SMS[$i]['text'].'</p><div class="smsInfo">
		<div><a href="/sms_like/id/'.$SMS[$i]['id'].'">Like:</a> '.$SMS[$i]['sms_like'].' - <a href="/sms_read/'.$SMS[$i]['id'].'">Copy:</a> '.$SMS[$i]['sms_copy'].' - Length: '.strlen($SMS[$i]['text']).' Char</div><div> <a href="sms:?body='.$SMS[$i]['text'].'">Forward</a> - <a href="https://www.facebook.com/home.php?p='.$SMS[$i]['text'].'
By - '.BASE_PATH.'">Facebook</a> -  <a href="mailto:?Subject=SMS&amp;Body='.$SMS['text'].' 
BY- '.BASEPATH.'">Email</a></div><div>'; echo time_ago($SMS[$i]['date']).'</div></div>
</div> ';
?>