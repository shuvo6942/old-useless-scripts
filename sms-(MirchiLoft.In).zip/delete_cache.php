<?php $dir = "cache/";
$dirHandle = opendir($dir);
while ($file = readdir($dirHandle)) {if(!is_dir($file)) {unlink("$dir"."$file");} }
closedir($dirHandle);
rmdir($dir); ?>
