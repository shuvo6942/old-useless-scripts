<?php 
include'includes/config.php';
$id = $_GET['id'];

$qryUpdate = "update sms set sms_copy = sms_copy + 1 where id in($id)";

$db->query($qryUpdate);


$SMS = $db->query('select * from sms where id = '.$id,database::GET_ROW);

$cat = $db->query('select * from category where id = '.$SMS['cid'],database::GET_ROW);
$seq =  $cat['pathc'];
$PATH = '<div class="path">» <a href="'.BASE_PATH.'">Home</a> ';
$PATH .= $seq.'</div>';
$NTITLE = 'Free SMS '.$SMS['text'];
include'header.php';
echo'<h2>Copy SMS</h2><div class="smsRow"><div class="smsBy">By: <a href="/smslist/uid/'.$SMS['user_id'].'/'.$SMS['username'].'">'.$SMS['username'].'</a> In: <a href="/smslist/'.$SMS['cid'].'/'.str_replace(array(' ','%20'),'_',$cat['name']).'">'.$cat['name'].'</a></div> <p class="sms"><textarea>'.$SMS['text'].'
By: '.BASE_PATH.'</textarea></p><div class="smsInfo">
		<div>Like: '.$SMS['sms_like'].' - Copy: '.$SMS['sms_copy'].' - Length: '.strlen($SMS['text']).' Character</div><div><a href="sms:?body='.$SMS['text'].'">Forward</a> - <a href="http://m.facebook.com/home.php?p='.$SMS['text'].'
BY - '.BASE_PATH.'">Facebook</a> - <a href="mailto:?Subject=SMS&amp;Body='.$SMS['text'].' 
BY- '.BASEPATH.'">Email</a></div><div>'; echo time_ago($SMS['date']).'</div></div></div>';

echo $PATH;
include'footer.php';
?>