<?php $db_host = "localhost";
$db_user = "mirchilo_demo";
$db_pass = "D801698wap";
$db_name = "mirchilo_demo";
// Calling the object with adatabase selected
$db = new database($db_host,$db_user,$db_pass,$db_name); ?>