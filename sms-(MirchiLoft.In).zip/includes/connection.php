<?php
require_once 'includes/CacheHandler.Class.php';
require_once 'includes/class.database.php';
include 'includes/db_details.php';
?>
