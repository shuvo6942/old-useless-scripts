<?php
function isValidEmail($email) {
    return eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$", $email);
}

//function instr
function InStr($String, $Find, $CaseSensitive = false) {
    $i = 0;
    while (strlen($String) >= $i) {
        unset($substring);
        if ($CaseSensitive) {
            $Find = strtolower($Find);
            $String = strtolower($String);
        }
        $substring = substr($String, $i, strlen($Find));
        if ($substring == $Find)
            return true;
        $i++;
    }
    return false;
}

//post all posted variables again to specified url
function submitfrm($url) {

    $strfrm = "<html><head></head><body><form name='frmsub1' id='frmsub1' method='post' action='" . $url . "'>";

    //get all form fields
    foreach ($_REQUEST as $key => $val) {
        //echo $key.'-->'.$val.'<br>';
        $strfrm = $strfrm . "<input type='hidden' name='" . $key . "' value='" . $val . "'>";
    }

    //exit;
    $strfrm = $strfrm . "</form><script> document.frmsub1.submit(); </script></body></html> ";

    echo $strfrm;
    exit();
}

function selfURL() {
    $s = empty($_SERVER["HTTPS"]) ? '' : ($_SERVER["HTTPS"] == "on") ? "s" : "";
    $protocol = strleft(strtolower($_SERVER["SERVER_PROTOCOL"]), "/") . $s;
    $port = ($_SERVER["SERVER_PORT"] == "80") ? "" : (":" . $_SERVER["SERVER_PORT"]);
    return $protocol . "://" . $_SERVER['SERVER_NAME'] . $port . $_SERVER['REQUEST_URI'];
}

//check compulsory fields
function CheckCompulsory($arrcompulsory, $url) {

    for ($i = 0; $i <= count($arrcompulsory) - 1; $i++) {
        if (strlen($_REQUEST[$arrcompulsory[$i]]) > 0 && $_REQUEST[$arrcompulsory[$i]] != '') {

        } else {
            if (InStr($url, '?')) {
                submitfrm($url . '&err=compulsory&errfld=' . $arrcompulsory[$i]);
            } else {
                submitfrm($url . '?errid=10&errfld=' . $arrcompulsory[$i]);
            }
        }
    }
}

function getfrmvalue($arr) {
    $myvals = array();

    for ($i = 0; $i <= count($arr) - 1; $i++) {
        $myvals[$i] = "'" . $_REQUEST[$arr[$i]] . "'";
    }

    return $myvals;
}

function EditFlds($arrfld, $arrval) {
    $str = '';

    for ($i = 0; $i <= count($arrfld) - 1; $i++) {
        $str = $str . $arrfld[$i] . "=" . $arrval[$i] . ",";
    }

    if (endsWith($str, ",")) {
        $str = substr($str, 0, $str . length - 1);
    }

    return $str;
}

function endsWith($str, $sub) {
    return ( substr($str, strlen($str) - strlen($sub)) === $sub );
}

function IsUserLogin() {

    if (strlen($_SESSION['admin_id']) > 0 && $_SESSION['admin_id'] != '') {
        return true;
    } else {
        return false;
    }
}

function CheckAdminLogin($path) {
    if (IsUserLogin ()) {
        $_SESSION['adminlink'] = '';
    } else {
        $_SESSION['adminlink'] = $_SERVER['REQUEST_URI'];
        submitfrm($path . "admin_login.php?errid=2");
    }
}

function CheckLogin() {
    if (IsLogin ()) {
        $_SESSION['file_name'] = '';
        return;
    } else {
        $_SESSION['file_name'] = $_SERVER['REQUEST_URI'];
        submitfrm(BASE_PATH . "common/login.php?errid=1");
    }
}

// convert from mysql DATETIME to "dd/mm/yyyy"
function fromSqlDate($strSqlDate, $format) {
    // Error checking
    $err = false;

    // We will be doning many levels of error checking
    // and will need to bale at any time,
    // so we do this...
    if (strlen($strSqlDate) >= 8 || strlen($strSqlDate) <= 10) {
        // separate date and time with space
        $tempDate = explode(' ', $strSqlDate);

        // if we got both
        if (count($tempDate) == 2) {
            $mydate = explode('-', $tempDate[0]);
            $mytime = explode(':', $tempDate[1]);
            $hour = $mytime[0];
            $minute = $mytime[1];
            $second = $mytime[2];
            $year = $mydate[0];
            $month = $mydate[1];
            $daynum = $mydate[2];
        } elseif (count($tempDate == 1)) {
            $mydate = explode('-', $tempDate[0]);

            $hour = 0;
            $minute = 0;
            $second = 0;
            $year = $mydate[0];
            $month = $mydate[1];
            $daynum = $mydate[2];
        }
        else
            $err = true;
    }
    else
        $err = true;

    if (!$err)
    // PHP Date Object
        return date($format, mktime($hour, $minute, $sec, $month, $daynum, $year));
    else
        return false;
}


function time_ago($provided_time){ $time_difference = time() - $provided_time ; 
$seconds = $time_difference;
$minutes = round($time_difference / 60 );
  $hours = round($time_difference / 3600 );
  $days = round($time_difference / 86400 );
  $weeks = round($time_difference / 604800 );
  $months = round($time_difference / 2419200 );
  $years = round($time_difference / 29030400 );
  if($seconds <= 60){ 
     echo "$seconds seconds ago";
  }else if($minutes <=60){      if($minutes==1){
        echo "one minute ago";
     }else{
        echo "$minutes minutes ago";
     }
  }else if($hours <=24){
     if($hours==1){
        echo "one hour ago";
     }else{
        echo "$hours hours ago";
     }
  }else if($days <= 7){
     if($days==1){
        echo "one day ago";
     }else{
        echo "$days days ago";
     }
  }else if($weeks <= 4){
     if($weeks==1){
        echo "one week ago";
     }
     else{
        echo "$weeks weeks ago";
     }
  }else if($months <=12){
      if($months==1){
        echo "one month ago";
      }else{
        echo "$months months ago";
      }
   }else{
      if($years==1){
         echo "one year ago";
      }else{
         echo "$years years ago";
      }
   }
}

?>