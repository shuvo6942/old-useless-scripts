<?php
session_start();

$agent_c = $_SERVER['HTTP_USER_AGENT'];

$rootDir = dirname(dirname(__FILE__));
set_include_path($rootDir . PATH_SEPARATOR . get_include_path());

require_once('includes/function.php');
require_once('includes/connection.php');
//for error message
if ($_REQUEST['errid'] != "" && is_numeric($_REQUEST['errid'])) {
if (count($message) < $_REQUEST['errid']) {
$msg = $message[0];
} else {
$msg = $message[$_REQUEST['errid']];
}

$CurrentMessage = "<span class='error'>" . $msg . "</span><br>";
}

$nname = $_GET['ct'];

if ($_GET['pid'] != '')
$parentid = $_GET['pid'];
else
$parentid = 0;


if (!is_numeric($parentid)) {
echo "Please do not edit url manually!";
exit;
}


// get title
if ($parentid != '' && $parentid > 0) {
$folqtt = $db->query("select clink from category where id = " . $_REQUEST['pid'], database::GET_FIELD);
$NTITLE = str_replace('/', ' > ', $folqtt);
}
$set = $db->query("SELECT *
FROM `settings` WHERE id=1");
define('BASE_PATH',$set[0]['homeurl']);
define('SITENAME',$set[0]['sitename']);  
define('MAIL',$set[0]['email']);
?>