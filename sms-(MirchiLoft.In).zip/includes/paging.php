<?php

if($_GET['page'] !='') {
$pageNum = $_GET['page'];
} else { 
$pageNum = 1;
}

$PAGE = $pageNum;
// counting the offset
$offset = ($pageNum - 1) * $rowsPerPage;
$limit = " LIMIT $offset, $rowsPerPage";

// how many rows we have in database
//$result = $db->numrow($pagingqry);
if($pagingpassid == '' )
$pagingpassid = 'id';
$numrows = $db->numrow($pagingqry,$pagingpassid);

//if records found
if($numrows>0)
{
// how many pages we have when using paging?
$maxPage = ceil($numrows/$rowsPerPage);

// print the link to access each page
$self = $_SERVER['PHP_SELF'].$gets;
$nav  = '';


if($pageNum > 2)
{
$startpage = $pageNum - 2;
}
else
$startpage = 1;

$endpage = $startpage + 5;

if($endpage > $maxPage)
$endpage = $maxPage+1;

if($maxPage > 1)
{
for($page = $startpage; $page < $endpage; $page++)
{
if ($page == $pageNum)
{
$nav .= " <span class='cur'>$page</span> "; // no need to create a link to current page
}
else
{
$nav .= "<a href=\"$pagelink$page$htmlpage\">$page</a> ";
}
}
}

// creating previous and next link
// plus the link to go straight to
// the first and last page

if ($pageNum > 1)
{
$page  = $pageNum - 1;
$prev  = " <a href=\"$pagelink$page$htmlpage\">Prev</a> ";
$gofirst = 1;
$first = " <a href=\"$pagelink$gofirst$htmlpage\" >First</a> ";
}
else
{
$prev  = ''; // we're on page one, don't print previous link
$first = ''; // nor the first page link
}

if ($pageNum < $maxPage)
{
$page = $pageNum + 1;
$next = " <a href=\"$pagelink$page$htmlpage\">Next</a> ";

$last = " <a href=\"$pagelink$maxPage$htmlpage\">Last</a> ";
}
else
{
$next = ''; // we're on the last page, don't print next link
$last = ''; // nor the last page link
}

$jumppage = '';
$jumppage .= '<form name="frme" method="get" action="'.BASE_PATH.'jumppage.php">';
$jumppage .= 'Jump to : ';
$jumppage .= '<input type="text" name="page" value="'.$pageNum.'" id="page" size="3" />';
$jumppage .= "<input type='submit' name='go' value='Go&raquo;' />";
$jumppage .= "<input type='hidden' name='pagelink' value='".$pagelink."' />";
$jumppage .= "<input type='hidden' name='htmlpage' value='".$htmlpage."' />";
$jumppage .= '</form>';


if($maxPage > 1)
{
// print the navigation link
$str = "<div class='pgn' align='center'>";
$str .=  $first . $prev . $nav . $next . $last ."<br/>" . $pageNum ." of ".$maxPage." pages". $jumppage ;
$str .=	"</div>";
} else {
$str='<div class="pgn"><span class="cur">'.$pageNum.'</span></div>'; }

$PAGE_CODE = $str;


}
else
{
$PAGE_CODE = 'Sorry, No Records Found';
}



?>
