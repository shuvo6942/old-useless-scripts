<?php 
include'includes/config.php';


if(!isset($_SESSION['userid']))
{ header('location: /error'); }
$db->connect();
include'header.php'; 
echo'<h2>Profile Info</h2>'; 


$user = mysql_fetch_array(mysql_query('select username,email,mobile,password from users where id="'.$_SESSION['userid'].'"'));
	echo'<div class="info">Username: '.$user['username'].'<br/> Email: '.$user['email'].'<br/> Mobile: '.$user['mobile'].'</div><h2>Change Password</h2>';	

	if(isset($_POST['oldpass'], $_POST['newpass'], $_POST['newpassverif'])){ 

if(md5($_POST['oldpass']) == $user['password']){
$_POST['newpass'] = stripslashes($_POST['newpass']); 
$_POST['newpassverif'] = stripslashes($_POST['newpassverif']);

	if($_POST['newpass']==$_POST['newpassverif']){ 

if(strlen($_POST['newpass'])>=6) {
$newpass = mysql_real_escape_string($_POST['newpass']);

if(mysql_query('update users set password="'.md5($newpass).'" where id="'.mysql_real_escape_string($_SESSION['userid']).'"')){
echo'<div class="info">Your Password have successfuly been changed.</div>'; 
} else {
echo'<div class="error">An error occurred while changing  your password.</div>';
}

} else { 
echo'<div class="error">Your password must contain at least 6 characters.</div>';
} 
} else {
echo'<div class="error">The verify  password  not match.</div>';
}
} else {
echo'<div class="error">Old password not correct.</div>';
}
} 
  echo'<form action="" method="post"><b>Old Password:*</b><br/> <input type="password" name="oldpass" /><br/>
<b>Password:*</b> (6 characters min.) <br/> <input type="password" name="newpass" /><br /><b>
Re Type Password:*</b><br/><input type="password" name="newpassverif" value="" /><br /><input type="submit" value="Submit" /></form>'; 
include'footer.php'; 
?>