<?php 
$db->connect ();
$session=session_id();
$time=time();
$time_check=$time-300; //SET TIME 10 Minute
$onl="SELECT * FROM online WHERE session='$session'";
$result=mysql_query($onl);

$count=mysql_num_rows($result);
if($count=="0"){

$onl1="INSERT INTO online(session, time)VALUES('$session', '$time')";
$result1=mysql_query($onl1);
}

else {
"$inl2=UPDATE online SET time='$time' WHERE session = '$session'";
$result2=mysql_query($onl2);
}

$onl3="SELECT * FROM online";
$result3=mysql_query($onl3);
$count_user_online=mysql_num_rows($result3);
echo "User online : $count_user_online ";

// if over 10 minute, delete session 
$onl4="DELETE FROM online WHERE time<$time_check";
$result4=mysql_query($onl4); 
?>