<?php
include 'includes/config.php';
include 'header.php';

if($_GET['do'] == 'top20')
$wh = ' where category.id = file.cid order by file.download desc ';
if($_GET['do'] == 'last-added')
$wh = ' where category.id = file.cid order by file.id desc ';

$special = 'select file.id,file.name,file.dname,file.ext,file.cid,file.thumbext,file.size,file.download,file.newtag,category.folder,category.thumb from `file` , category '.$wh;
$rowsPerPage=7;
$pagingpassid = 'file.id';
$pagingqry = $special;
$gets='?';

$pagelink = BASE_PATH.'top/'.$_GET['do'].'/';
//echo $sort;

$htmlpage =str_replace(array(' ','%20'),'_',$nname).'.html';
include("includes/paging.php");

$do = $_GET['do'];

$SPECIAL = $db->query($pagingqry.$limit);
$PATH = '&raquo;&nbsp;<a href="'.BASE_PATH.'">Home</a>&nbsp;';

echo '<!-- pankajbd.com :: Display Random files -->';
?>
<table cellspacing="0">
<tbody>
<tr>
<td align="center" colspan="2">
<?php
if($do == 'today')
echo'<h3>Today\'s Most Popular Downloads</h3>
<div class="path">Top 21 Files: <a href="'.BASE_PATH.'top/yesterday.html">Yesterday</a>, <a href="'.BASE_PATH.'top/week.html">Week</a>, <a href="'.BASE_PATH.'top/month.html">Month</a>, <a href="'.BASE_PATH.'top/all.html">All</a></div>';

elseif($do == 'yesterday')
echo'<h3>Yesterday\'s Most Popular Downloads</h3>
<div class="path">Top 21 Files:
<a href="'.BASE_PATH.'top/today.html">Today</a>,  <a href="'.BASE_PATH.'top/week.html">Week</a>, <a href="'.BASE_PATH.'top/month.html">Month</a>, <a href="'.BASE_PATH.'top/all.html">All</a></div>';
elseif($do == 'week')
echo'<h3>This Week\'s Most Popular Downloads</h3>
<div class="path">Top 21 Files:
<a href="'.BASE_PATH.'top/today.html">Today</a>, <a href="'.BASE_PATH.'top/yesterday.html">Yesterday</a>, <a href="'.BASE_PATH.'top/month.html">Month</a>, <a href="'.BASE_PATH.'top/all.html">All</a></div>';
elseif($do == 'month')
echo'<h3>This Month\'s Most Popular Downloads</h3>
<div class="path">Top 21 Files:
<a href="'.BASE_PATH.'top/today.html">Today</a>, <a href="'.BASE_PATH.'top/yesterday.html">Yesterday</a>, <a href="'.BASE_PATH.'top/week.html">Week</a>, <a href="'.BASE_PATH.'top/all.html">All</a></div>';
elseif($do == 'all')
echo'<h3>Most Popular Downloads</h3>
<div class="path">Top 21 Files:
<a href="'.BASE_PATH.'top/today.html">Today</a>, <a href="'.BASE_PATH.'top/yesterday.html">Yesterday</a>, <a href="'.BASE_PATH.'top/week.html">Week</a>, <a href="'.BASE_PATH.'top/month.html">Month</a>';
elseif($do == 'top20')
echo '<h3>Top 20</h3>';
elseif($do == 'last-added')
echo '<h3>Recently Added</h3>';
?>
</td>
</tr>
<?php
$l = 1;
$file_tot = count($SPECIAL);
for($i=0;$i<$file_tot;$i++)
{
if($l==1)
{
$l++;
$class = 'fl odd';
}
else
{
$l=1;
$class='fl odd';
}

?>
<tr class="<?=$class?>">
<td class="tblimg">
<?php include 'spe_preview.php'; ?>
</td>
<td align="left">
<a class="new_link" href="<?=BASE_PATH?>filedownload/<?=$SPECIAL[$i]['cid']?>/<?=$SPECIAL[$i]['id']?>/<?=str_replace(array(' ','%20'),'_',$SPECIAL[$i]['name'])?>.html"><?=$SPECIAL[$i]['name']?>.<?=$SPECIAL[$i]['ext']?></a>
<?php
if($SPECIAL[$i]['newtag'] == 1)
echo '<img alt="new" src="'.BASE_PATH.'images/new.gif">';
?>
<br />
[<?=getSize($SPECIAL[$i]['size'])?> ] <br/> <?=$SPECIAL[$i]['download']?> Downloads
</td>
</tr>
<?php
}	?>
</tbody>
</table>
<center>
<?=$PAGE_CODE?>
</center>

<div class="path">
<?=$PATH?>
</div>

<?php
$parentid = 1;
include 'footer.php';
?>