<?php

include'includes/config.php';
$NTITLE='Registration';
include'header.php';
$db->connect();

if(isset($_POST['username'], $_POST['password'], $_POST['passverif'], $_POST['email'], $_POST['mobile']) and $_POST['username']!='')
{
	//We remove slashes depending on the configuration
	if(get_magic_quotes_gpc())
	{
		$_POST['username'] = stripslashes($_POST['username']);
		$_POST['password'] = stripslashes($_POST['password']);
		$_POST['passverif'] = stripslashes($_POST['passverif']);
		$_POST['email'] = stripslashes($_POST['email']);
		$_POST['mobile'] = stripslashes($_POST['mobile']);
	}
	//We check if the two passwords are identical
	if($_POST['password']==$_POST['passverif'])
	{
		//We check if the password has 6 or more characters
		if(strlen($_POST['password'])>=6)
		{
			//We check if the email form is valid
			if(preg_match('#^(([a-z0-9!\#$%&\\\'*+/=?^_`{|}~-]+\.?)*[a-z0-9!\#$%&\\\'*+/=?^_`{|}~-]+)@(([a-z0-9-_]+\.?)*[a-z0-9-_]+)\.[a-z]{2,}$#i',$_POST['email']))
			{
				//We protect the variables
				$username = mysql_real_escape_string($_POST['username']);
				$password = mysql_real_escape_string($_POST['password']);
				$email = mysql_real_escape_string($_POST['email']);
				$mobile = mysql_real_escape_string($_POST['mobile']);
				//We check if there is no other user using the same username
				$dn = mysql_num_rows(mysql_query('select id from users where username="'.$username.'"'));
				if($dn==0)
				{
					//We count the number of users to give an ID to this one
					$dn2 = mysql_num_rows(mysql_query('select id from users'));
					$id = $dn2+1;
					//We save the informations to the databse
					if(mysql_query('insert into users(id, username, password, email, mobile, regdate) values ('.$id.', "'.$username.'", "'.md5($password).'", "'.$email.'", "'.$mobile.'", "'.time().'")'))
					{
						//We dont display the form
		$form = false;
echo'<div class="message">You have successfuly been signed up. You can log in.<br /><a href="/login">Log in</a></div>';
					}
					else
					{
						//Otherwise, we say that an error occured
						$form = true;
						$regnoti = 'An error occurred while signing up.';
					}
				}
				else
				{
					//Otherwise, we say the username is not available
					$form = true;
					$regnoti = 'The username you want to use is not available, please choose another one.';
				}
			}
			else
			{
				//Otherwise, we say the email is not valid
				$form = true;
				$regnoti = 'The email you entered is not valid.';
			}
		}
		else
		{
			//Otherwise, we say the password is too short
			$form = true;
			$regnoti = 'Your password must contain at least 6 characters.';
		}
	}
	else
	{
		//Otherwise, we say the passwords are not identical
		$form = true;
		$regnoti = 'The passwords you entered are not identical.';
	}
}
else
{
	$form = true;
}
echo'<h2>Registration</h2>';
if($form)
{
	//We display a message if necessary
	if(isset($regnoti))
	{
		echo '<div class="message">'.$regnoti.'</div>';
	}
	//We display the form
?>

    <form action="" method="post">
        Username:<br/> <input type="text" name="username" value="<?php if(isset($_POST['username'])){echo htmlentities($_POST['username'], ENT_QUOTES, 'UTF-8');} ?>" /><br />
           Password: <span class="small">(6 characters min.)</span></br><input type="password" name="password" /><br />
            Retype Password: <br/><input type="password" name="passverif" /><br />
            Email: <br/> <input type="text" name="email" value="<?php if(isset($_POST['email'])){echo htmlentities($_POST['email'], ENT_QUOTES, 'UTF-8');} ?>" /><br />
         Mobile: </br><input type="text" name="mobile" value="<?php if(isset($_POST['mobile'])){echo htmlentities($_POST['mobile'], ENT_QUOTES, 'UTF-8');} ?>" /><br />
            <input type="submit" value="Sign up" />
		
    </form>
<?php

echo'<div class="path"> &raquo; <a href="/">Home</a></div>';
include'footer.php';
}
?>