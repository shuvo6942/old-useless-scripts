<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><title><?php
if($NTITLE != ''){
echo ''.SITENAME.' :: '.$NTITLE; }else{
echo SITENAME.' ::  SMS, Free Sms, Christmas SMS, New Year SMS, Jokes SMS, Love Sms, Funny Sms, Good Night Sms, Good Morning Sms, Winter Sms'; } ?></title> <meta http-equiv="content-type" content="text/html; charset=UTF-8" /><meta name="language" content="en" />
<meta name="description" content="<?=$nname?> -  SMS, Free Sms, Christmas SMS, New Year SMS, Jokes SMS, Love Sms, Funny Sms, Good Night Sms, Good Morning Sms, Winter Sms" />
<meta name="keywords" content="<?=$nname?> , SMS, Free Sms, Christmas SMS, New Year SMS, Jokes SMS, Love Sms, Funny Sms, Good Night Sms, Good Morning Sms, Winter Sms" />
<meta name="robots" content="index, follow" />

<link rel="shortcut icon" href="<?=BASE_PATH?>favicon.ico" />
<link rel="stylesheet" href="<?=BASE_PATH?>css/sms.css" type="text/css" />
</head><body><div class="logo"><a href="<?=BASE_PATH?>"><img src="<?=BASE_PATH?>logo/logo.png" width="220" height="35" alt="<?=SITENAME?>"/></a> </div>
<div align="right"><b> 
<?php
if(isset($_SESSION['username']))
{
echo'<div id="setting"><div id="loginout">Welcome <a href="/profile">'.$_SESSION['username'].'</a> &bull; <a href="/sms/add">Add SMS</a> &bull; <a href="/smslist/uid/'.$_SESSION['userid'].'/'.$_SESSION['username'].'">My SMS</a> &bull; ';
if ($_SESSION['rights'] >= 7) { echo'<a href="/panel">CPanel</a> &bull; '; } echo'<a href="/logout">Logout</a></div></div>';
}
else
{

echo'<div id="setting"><div id="loginout"><a href="/sign_up">Sign Up</a> &bull; <a href="/login">Log in</a></div></div>';
}
?></b></div>
<center>
<?php
if(strstr(strtolower($agent_c),'windows'))
$agent_ext = '.pdv';
else
$agent_ext = '.adv';

if($LOGO != '')
include 'a'.$agent_ext;
else
include 'd'.$agent_ext;
?>
</center>
<div class="search">
<form method="get" action="<?=BASE_PATH?>search.php">
Search SMS :
<input id="search" size="20" type="text" name="q" value="<?=$search?>">
<input value="Search" type="submit" name="submit">
</form>
</div>