<?php

if($_GET['submit']) 
header('location: /smslist/find/'.$_GET['q']);

include 'includes/config.php';
if($_GET['q'] =='')
header('location: /smslist/latest'); 

$search = $_GET['q']; 

include 'header.php';
$seq = "select * from category as c,sms as s where s.text like '%".$_GET['q']."%' and s.cid = c.id";

$rowsPerPage = 10;
$pagingqry = $seq;
$gets = '?';

$pagelink = BASE_PATH . 'smslist/find/' . $_GET['q'] . '/';

$pagingpassid = 's.id';
include("includes/paging.php");

$SMS = $db->query($pagingqry . $limit,0,'no');

$LISTTOTAL = $numrows;


$PATH = '&raquo;&nbsp;<a href="' . BASE_PATH . '">Home</a>&nbsp;';
?>
<?php
if ($LISTTOTAL != 0) {
echo '<!-- pankajbd.com :: Display sms list -->';
echo'<h2>Search Result For "'.$search.'"</h2>';
$sms_tot = count($SMS);
for ($i = 0; $i < $sms_tot; $i++) {
include'smslist.php'; 
}
}
else {
echo'Sorry No match found!'; } 
if ($LISTTOTAL != 0)
echo $PAGE_CODE;
?>
<div class="path">
<?= $PATH ?>
</div>

<?php
include 'footer.php';
?>