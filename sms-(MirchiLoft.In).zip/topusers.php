<?php
include 'includes/config.php';
$NTITLE= 'Top Users';
include'header.php';
$pagingqry = 'select * from `users` order by sms desc';
$rowsPerPage=10;
$gets='?';
$pagelink = BASE_PATH.'topusers/';
include("includes/paging.php");

$USR = $db->query($pagingqry.$limit);

$PATH = '&raquo;&nbsp;<a href="'.BASE_PATH.'">Home</a>&nbsp;';

echo '<!-- pongkoj.kumar@gmail.com :: Display Random users -->';
?>
<h2>Top Users</h2>
<?php
$usr_tot = count($USR);
for($i=0;$i<$usr_tot;$i++)
{
echo'<div class="catRow"><a href="/smslist/uid/'.$USR[$i]['id'].'/'.$USR[$i]['username'].'">'.$USR[$i]['username'].' ['.$USR[$i]['sms'].' sms]</a></div>';
}
?>
<center>
<?=$PAGE_CODE?>
</center>

<div class="path">
<?=$PATH?>
</div>

<?php
include 'footer.php';
?>