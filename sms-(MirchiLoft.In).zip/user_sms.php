<?php
include 'includes/config.php';
include 'header.php';

$NTITLE= 'User SMS';
$pagingqry = 'select * from `sms` where user_id = '.$_GET['id'].' order by id desc';
$rowsPerPage=10;
$gets='?';
$pagelink = BASE_PATH.'smslist/uid/'.$_GET['id'].'/'.$_GET['user'].'/';
include("includes/paging.php");

$SMS = $db->query($pagingqry.$limit);

$PATH = '&raquo;&nbsp;<a href="'.BASE_PATH.'">Home</a>&nbsp;';

echo '<!-- pongkoj.kumar@gmail.com :: Display Random sms -->';
?>

<?php
$st = $db->query('SELECT COUNT(*) FROM sms where user_id = '.$_GET['id'].'');

$sms_tot = count($SMS);
echo'<h2>User: '.$_GET['user'].' ['.$st[0]['COUNT(*)'].' SMS]</h2>';

for($i=0;$i<$sms_tot;$i++)
{
echo '<div align="left">';
include'smslist.php';
}
?>
<center>
<?=$PAGE_CODE?>
</center>

<div class="path">
<?=$PATH?>
</div>

<?php
include 'footer.php';
?>
