<?php
include 'includes/config.php';
$db->connect();
$NTITLE='Login';
if(isset($_SESSION['username']))
{
	
header("location: /index.php");
}
else
{
	$ousername = '';
	
	if(isset($_POST['username'], $_POST['password']))
	{
	
		if(get_magic_quotes_gpc())
		{
			$ousername = stripslashes($_POST['username']);
			$username = mysql_real_escape_string(stripslashes($_POST['username']));
			$password = stripslashes($_POST['password']);
		}
		else
		{
			$username = mysql_real_escape_string($_POST['username']);
			$password = $_POST['password'];
		}
	
		$req = mysql_query('select password,id,rights from users where username="'.$username.'"');
		$dn = mysql_fetch_array($req);
	
		if($dn['password']==md5($password) and mysql_num_rows($req)>0)
		{
			

			$_SESSION['username'] = $_POST['username'];
			$_SESSION['userid'] = $dn['id'];
$_SESSION['rights'] = $dn['rights'];
header("Location: /");
		}
		else
		{
			$lognoti = 'The username or password is incorrect.';
		}
	}
	
	include'header.php';

echo'<h2>Login</h2><div class="content">';

	if(isset($lognoti))
	{
		echo '<div class="message">'.$lognoti.'</div>';
	}
    echo'<form action="" method="post">
Username:<br />
 <input type="text" name="username" id="username" value="'.htmlentities($ousername, ENT_QUOTES, 'UTF-8').'" /><br />
 Password: <br/> <input type="password" name="password" id="password" /><br />
          <input type="submit" value="Log in" />
   </form>
<br/> 
<a href="/lost_pass">Forgot Password?</a> <br/> <a href="/sign_up">Sign Up!</a>
</div>';
echo'<div class="path"> &raquo; <a href="/">Home</a></div>';
include'footer.php'; 
}
?>