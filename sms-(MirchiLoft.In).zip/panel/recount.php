<?php

$a = 'select * from category';
$z = $db->query($a);
if(count($z) > 0)
{
    foreach($z as $key => $val)
    {
            $qnq = 'select count(id) as totsms from sms where cid = '.$val['id'];
            $qnz = $db->query($qnq , database::GET_ROW);
            if($qnz['totsms'] >= 0)
            {
                $upd = 'update category set totalitem = '.$qnz['totsms'].' where id = '.$val['id'];
                $db->query($upd);
            }

    }
}

$total = 0;
global $total;
function showlist($parent, $indent = 0,$db)
{
	global $total;
	$result = $db->query("SELECT * FROM category WHERE parentid =" . mysql_real_escape_string($parent));
	$n = count($result);
	for($i=0;$i<$n;$i++)
	{

		if($result[$i]['subcate'] == 0)
		{
		
			$indent = $result[$i]['totalitem'];
			$total = $total + $indent;
		}
	
	}
}

$q = $db->query('select * from category where subcate = 1');
$n = count($q);
for($i=0;$i<$n;$i++)
{
	$total = 0;
	showlist($q[$i]['id'],0,$db);
	$db->query('update category set totalitem = '.$total.' where id = '.$q[$i]['id']);
	
}
