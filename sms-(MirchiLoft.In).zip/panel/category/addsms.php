<?php 
include'../../includes/config.php';


if ($_SESSION['rights'] < 8) {
header('Location: /err');
exit;
}

$NTITLE= '> cPanel > Category > Add SMS';
include '../../header.php'; 
if ($_GET['id'] == '')
    exit;

$id = $_REQUEST['id'];
?> 
<a href="index.php?pid=<?= $id ?>">&laquo; Go Back To Sms list</a>
<h2>Add SMS</h2>
<div align="left">
    <form action="addsms_db.php" method="post">Write SMS:<br/><textarea name="sms"></textarea>
 <input type="hidden" name="cid" value="<?= $id ?>" />
<input type="submit" name="submit" id="submit" value="Submit" />
    </form>
</div>
<?php include'../../footer.php'; ?>