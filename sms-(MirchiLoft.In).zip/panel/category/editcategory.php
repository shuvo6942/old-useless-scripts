<?php 
include'../../includes/config.php';


if ($_SESSION['rights'] < 8) {
header('Location: /err');
exit;
}

$NTITLE= '> cPanel > Category > Edit Category';
 include '../../header.php'; ?>
<?php
    if($_GET['pid'] != '')
        $parentid = $_GET['pid'];
    else
        exit;
    $id = $_GET['id'];
    $q = "select * from category where id = ".$_GET['id'];
    $CATEGORY = $db->query($q,  database::GET_ROW);
?>

<a href="index.php?pid=<?= $pid ?>">&laquo; Go Back To Categories list</a>
<h2>Edit Category</h2>
<div align="left">
    <form action="edit_cat_db.php" method="post">
<b>Category name: </b>(Use only alphabatical character)<br/><input type="text" value="<?=$CATEGORY['name']?>" name="name" id="" size="30" />
 <br/> New item tag:<br/>
                    <?php
                        if($CATEGORY['newitemtag'] == 1)
                            echo '<input type="checkbox" name="newitemtag" checked="checked" value="1" />';
                        else
      echo '<input type="checkbox" name="newitemtag" value="1" />';
   ?>
         <br/>
                    <input type="hidden" name="id" value="<?=$id?>" />
                    <input type="hidden" name="pid" value="<?=$parentid?>" />
                    <input type="submit" name="submit" id="submit" value="Update Category" />
    </form>
</div>
<?php include '../../footer.php'; ?>