<?php
	include("../../includes/config.php");
	

if ($_SESSION['rights'] < 8) {
header('Location: /err');
exit;
}

	if($_GET['id'] != '' && $_GET['cid'] != '')
	{
		$cid = $_GET['cid'];
		$id = $_GET['id'];
		
		$q = 'select * from sms where id = '.$id;
		$qt = $db->query($q,  database::GET_ROW);

		$delete = 'delete from sms where id = '.$id;
		$db->query($delete);
					
		$updatesubcat = 'update category set totalitem = totalitem - 1 where id = '.$cid;
		$db->query($updatesubcat);
		
$userid = $qt['user_id'];
$qryUpdate = 'update users set sms = sms - 1 where id = '.$userid;

$db->query($qryUpdate);

		if($cid != 0)
			header("location: index.php?errid=9&pid=$cid");
		else
			header("location: index.php?errid=9");
	}
	
?>