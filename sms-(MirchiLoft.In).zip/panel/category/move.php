<?php
	include("../../includes/config.php");

if ($_SESSION['rights'] < 8) {
header('Location: /err');
exit;
}
	if($_REQUEST['act'] == up){ $posi= $_REQUEST['posi'] + 1; } elseif ($_REQUEST['act'] == down){ $posi = $_REQUEST['posi'] - 1; }

		$qryUpdate = "update category set posi = $posi where id =".$_REQUEST['id'];
	
	$db->query($qryUpdate);
	
	if($_REQUEST['page'] == '')
            header('location: index.php?pid='.$_REQUEST['pid']);
        else
            header('location: index.php?pid='.$_REQUEST['pid'].'&page='.$_REQUEST['page']);

?>