<?php
	
include'../../includes/config.php';

if ($_SESSION['rights'] < 8) {
header('Location: /err');
exit;
}
	
	if($_POST['pid'] != '')
	{
		$parentid = $_REQUEST['pid'];
				
		$chkdup = 'select id from category where name = "'.$_REQUEST['name'].'" and parentid = '.$_POST['pid'];
                $a = $db->query($chkdup,  database::GET_FIELD);
		if(count($a) > 0 )
		{
			if($parentid != 0)
				header("location: index.php?errid=5&pid=$parentid");
			else
				header("location: index.php?errid=5");
			exit;
		}
		if($_POST['pid'] != 0)
		{
			$qfol = 'select clink from category where id = '.$parentid;
			$fo = $db->query($qfol,  database::GET_ROW);
                        $clinkp = $fo['clink'];
		}
		
		$newid = $db->query("insert into category (name,parentid)
			values('".mysql_real_escape_string($_REQUEST['name'])."','$parentid')");
                $newid = $db->insert_id;
                
                if($newid < 1)
                    echo 'error';
       

		$clink = $clinkp.'/'.$_REQUEST['name'];
                $db->query("update category set clink = '".mysql_real_escape_string($clink)."' where id = ".$newid);
                if($parentid > 0)
                    $db->query("update category set subcate = 1 where id = ".$parentid);
		
		$q = 'select path from category where id = '.$parentid;
                if($parentid > 0)
                    $path = $db->query($q,  database::GET_FIELD) . '&nbsp;&raquo;&nbsp;<a href="?pid='.$newid.'">'.$_REQUEST['name'].'</a>';
                else
                    $path = '&nbsp;&raquo;&nbsp;<a href="?pid='.$newid.'">'.$_REQUEST['name'].'</a>';
                
		$qc = 'select pathc from category where id = '.$parentid;
         if($parentid > 0) 
                    $pathc = $db->query($qc,  database::GET_FIELD) . '&nbsp;&raquo;&nbsp;<a href="/smslist/'.$newid.'/'.str_replace(array(' ','%20'),'_',$_REQUEST['name']).'">'.$_REQUEST['name'].'</a>';
           else
                    $pathc = '&nbsp;&raquo;&nbsp;<a href="/smslist/'.$newid.'/'.str_replace(array(' ','%20'),'_',$_REQUEST['name']).'">'.$_REQUEST['name'].'</a>'; 
          
                $getnewid = $newid;
                $qrygetposi = $db->query("select count(id) from category where parentid = $parentid",  database::GET_FIELD);
                $qryupdateposi = $db->query("update category set posi = $qrygetposi where id = $getnewid");
               
        	$db->query("update category set path = '".mysql_real_escape_string($path)."',pathc = '".mysql_real_escape_string($pathc)."' where id = ".$newid);
		
		
		if($parentid != 0)
			header("location: index.php?errid=3&pid=$parentid");
		else
			header("location: index.php?errid=3");
	}
	
?>