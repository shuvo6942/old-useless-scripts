<?php
	include("../../includes/config.php");

if ($_SESSION['rights'] < 8) {
header('Location: /err');
exit;
}

	if($_POST['id'] != '' || $_POST['cid'] != '')
	{
            $id = $_REQUEST['id'];
            $cid = $_REQUEST['cid'];
       $text = $_REQUEST['text'];
   $newtag = $_REQUEST['newtag'];

            $qryUpdate = "update sms set text = '$text', newtag = '$newtag' where id = ".$id;
            $db->query($qryUpdate);

            header("location: index.php?pid=$cid");
	}
	
?>
