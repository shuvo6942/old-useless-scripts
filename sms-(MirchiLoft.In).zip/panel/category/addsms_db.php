<?php
include'../../includes/config.php';
$db->connect();

if ($_SESSION['rights'] < 8) {
header('Location: /err');
exit;
}

if ($_POST['cid'] != '') {
$text =  htmlentities($_REQUEST['sms']);
$username = $_SESSION['username'];
$userid = $_SESSION['userid'];
$cid = $_REQUEST['cid'];

$qryUpdate = "insert into sms (text, user_id, username, cid, newtag, date) VALUES ('".mysql_real_escape_string($text)."', '$userid', '".mysql_real_escape_string($username)."', '$cid', '1', '".time()."')";
$db->query($qryUpdate);

$qryUpdate = "update category set totalitem = totalitem + 1 where id in($cid)";
$db->query($qryUpdate);


$qryUpdate = "update users set sms = sms + 1 where id in($userid)";

$db->query($qryUpdate);

header("Location: index.php?pid=$cid");
}
?>

