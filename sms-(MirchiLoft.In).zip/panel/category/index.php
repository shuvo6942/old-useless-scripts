<?php  
require'../../includes/config.php';

if ($_SESSION['rights'] < 8) {
header('Location: /err');
exit;
}

$NTITLE= '> cPanel > Category';
require '../../header.php'; ?>
<?php
if($_GET['pid'] != '')
    $parentid = $_GET['pid'];
else
    $parentid = 0;

if($parentid != 0)
{ 
$seq = "select path from category where id = ".$parentid; 
$PATH = '&raquo;&nbsp;<a href="index.php">Home</a>&nbsp;'.$db->query($seq,database::GET_FIELD);
} 

$WHER = 'where parentid = '.$parentid . ' order by posi desc'; 

$pagingqry = "select * from category ".$WHER;
$rowsPerPage=10;
$gets='?';

$pagelink = 'index.php?pid='.$parentid.'&page=';

include("../../includes/paging_admin.php");

$CATEGORY = $db->query($pagingqry.$limit);
$totalcategory = $numrows;
 
$start_sr_no = $offset + 1;

if($totalcategory > 0){ 
echo' <h2>Categories Management</h2>';
foreach($CATEGORY as $key => $val) { echo'<div class="fl odd">'.$start_sr_no++; echo'. <a href="?pid='.$val['id'].'"><b>'.$val['name'].'</b></a>';
 if($val['totalitem'] != 0) echo ' ('.$val['totalitem'] .')'; 
echo'<center><div class="sub">';
if($val['subcate'] != 1)
 echo '<a href="addsms.php?id='.$val['id'].'">Add Sms</a> | ';
if($totalcategory - 1 > $val['posi']){ echo'<a href="move.php?id='.$val['id'].'&act=up&posi='.$val['posi'].'&pid='.$parentid.'&page='.$_GET['page'].'">Up</a> | '; }
if($val['posi'] != 0) { echo'<a href="move.php?id='.$val['id'].'&act=down&posi='.$val['posi'].'&pid='.$parentid.'&page='.$_GET['page'].'">Down</a> | '; }

echo'<a href="editcategory.php?id='.$val['id'].'&pid='.$parentid.'">Edit</a> | <a href="deletecategory.php?id='.$val['id'].'&pid='.$parentid.'">Delete</a></div></center></div>';
}
 ?>
<?=$PAGE_CODE?>
 <div class="path"><?=$PATH?></div> 
 <?php 
 } else { 
echo' <h2>SMS Management</h2>';
$pagingqry = 'select * from sms where cid = '.$parentid .' order by id desc'; $rowsPerPage=10;
 $gets='?';
 
$pagelink = ADMIN_BASE_PATH.'category/index.php?pid='.$parentid.'&page=';
  include("../../includes/paging_admin.php");
 $SMS = $db->query($pagingqry.$limit); $TOTAL_SMS = $numrows;
 foreach($SMS as $key => $val) {    echo'<div class="fl">'.$start_sr_no ++; 
echo'. <b>'.$val['text'].'</b> <br/><center><div class="sub"><a href="editsms.php?id='.$val['id'].'&cid='.$parentid.'">Edit</a> | <a href="deletesms.php?id='.$val['id'].'&cid='.$parentid.'">Delete</a></div></center></div>';
                          
                        }
                    ?>
            <?=$PAGE_CODE?>
           <?php
        }

        if($TOTAL_SMS == 0)
        {
            ?>
    
            <h2> Add Category</h2>
            <div class="form">
                <form method="post" action="create_category.php" onsubmit="return chkfrm(compulsory,dispError,this)"> Category name: (Use only alphabatical character)<br/><input type="text" name="name" id="" size="30" /><input type="hidden" name="pid" value="<?=$parentid?>" /><input type="submit" name="submit" id="submit" value="Create" />
                </form>
    
            <?php
        }
        else
        {
            ?><h2>Add SMS</h2>
<div align="left">
    <form action="addsms_db.php" method="post">Write New SMS:<br/><textarea name="sms"></textarea>
 <input type="hidden" name="cid" value="<?= $parentid ?>" />
<input type="submit" name="submit" id="submit" value="Submit" />
    </form>
</div>
            <?php
        }
        ?>
</div>
<?php include '../../footer.php'; ?>