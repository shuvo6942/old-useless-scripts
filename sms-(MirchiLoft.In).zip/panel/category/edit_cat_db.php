<?php


include'../../includes/config.php';
$db->connect();
if ($_SESSION['rights'] < 8) {
header('Location: /err');
exit;
}
if ($_POST['pid'] != '') {

        function set_newpath_rename_category($id,$pid,$newname,$db,$base_path,$new = 0)
        {
            $parent_path = $db->query('select path,pathc,clink from category where id = '.$pid , database::GET_ROW);
            $new_create_path = $db->query('select * from category where id = '.$id , database::GET_ROW);

            $newpath = $parent_path['path'];
            $newpathc = $parent_path['pathc'];
            $newclink = $parent_path['clink'];
            $name = $new_create_path['name'];
            if($new != 1)
                $newname = $name;

            $newpath .= '&nbsp;&raquo;&nbsp;<a href="?pid='.$id.'">'.$newname.'</a>';
           
            $newpathc .= '&nbsp;&raquo;&nbsp;<a href="/smslist/'.$id.'/'.str_replace(array(' ','%20'),'_',$newname).'">'.$newname.'</a>';
           
            $newclink .= '/'.$newname;
           
            $db->query("update category set path = '".mysql_real_escape_string($newpath)."' , pathc = '".mysql_real_escape_string($newpathc)."' , clink = '".mysql_real_escape_string($newclink)."' where id = $id");
        }
        function showlist($parent, $indent = 0,$newname,$base_path,$db)
        {
                global $total;
                $result = $db->query("SELECT * FROM category WHERE parentid =" . mysql_real_escape_string($parent));
                $n = count($result);
                for($i=0;$i<$n;$i++)
                {
       
                        set_newpath_rename_category($result[$i]["id"], $result[$i]["parentid"], $newname, $db, $base_path);
                        showlist($result[$i]["id"], $indent = 0,$newname,BASE_PATH,$db);
                }
        }
    $parentid = $_REQUEST['pid'];
    $id = $_REQUEST['id'];
    
    $qnew = 'select name from category where id = ' . $id;
    $old = $db->query($qnew,  database::GET_ROW);
    $oldname = $old['name'];
    
    $newname = mysql_real_escape_string($_REQUEST['name']);
    $flds = array("name", "newitemtag");
    $vals = getfrmvalue($flds);

    $qryUpdate = "update category set " . EditFlds($flds, $vals) . " where id=" . $id;

    $db->query($qryUpdate);

    if($oldname != $newname)
    {
       
        set_newpath_rename_category($id, $parentid, $newname, $db, BASE_PATH,1);
        showlist($id, $indent = 0,$newname,BASE_PATH,$db);
     
 
    }

    $para = ($parentid !=0 ? "errid=12&id=" . $id . "&pid=$parentid" : "errid=12&id=" . $id );
    
    if ($parentid != 0)
        header("location: index.php?" . $para);
    else
        header("location: index.php?". $para);
}
?>