<?php
include'../../includes/config.php';


if ($_SESSION['rights'] < 8) {
header('Location: /err');
exit;
}

$NTITLE= '> cPanel > Category > Edit SMS';
 include '../../header.php'; ?>
<?php
$id = $_GET['id'];
$cid = $_GET['cid'];
if($_GET['id'] == '' || $_GET['cid'] == '')
	exit;
else
{
	$n = $db->query('select * from sms where id = '.$id,database::GET_ROW);
}

?>
  
    <a href="index.php?pid=<?=$cid?>">&laquo; Go Back To SMS list</a>
    <h2>Edit SMS</h2>
    <div align="left">
        <form action="editsms_db.php" method="post">Edit SMS: <br/> <textarea name="text"><?=$n['text']?></textarea><br/>New Item Tag:<br/>
                        <?php
                        if($n['newtag'] == 1)
                            echo '<input type="checkbox" checked="checked" name="newtag" value="1" />';
                        else
                            echo '<input type="checkbox" name="newtag" value="1" />';
                  ?>
               <br/>  <input type="hidden" name="id" value="<?=$id?>" />
                <input type="hidden" name="cid" value="<?=$cid?>" />
                        <input type="submit" name="submit" id="submit" value="Update Now" />
         </form>
         </div>
<?php include '../../footer.php'; ?>