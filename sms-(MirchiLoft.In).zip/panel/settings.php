<?php
include'../includes/config.php'; 
$NTITLE='cPanel > Settings';
include'../header.php';
if ($_SESSION['rights'] < 9) {
header('Location: /err');
exit;
}
echo'<h2>Site Settings</h2>';

if (isset($_POST['submit'])) {
$homeurl=$_POST['homeurl']; 
$sitename=$_POST['sitename']; 
$mail=$_POST['mail'];

if($db->query("UPDATE `settings` SET `homeurl` = '$homeurl', `email` = '$mail', `sitename` = '$sitename' WHERE `id` = '1'")){ 
echo'<div class="info">Successfully Saved.</div>'; } else { echo'<div class="error">Cannot Saved!</div>'; }
}
$set = $db->query("SELECT *
FROM `settings` WHERE id=1");

echo'<form action="" method="post"><b>Home URL:</b> (With <b>http://</b> & last <b>/</b>)<br/><input type="text" name="homeurl" value="'.$set[0]['homeurl'].'"/><br/><b>Site Name:</b><br/><input type="text" name="sitename" value="'.$set[0]['sitename'].'"/><br/><b>Email:</b><br/><input name="mail" maxlength="50" value="'.$set[0]['email'].'"/><br /><input type="submit" name="submit" value="Save"/></form>'; 

echo'<div class="path"> &raquo; <a href="/">Home</a> &raquo; <a href="/panel">cPanel</a></div>';
include'../footer.php';
?>