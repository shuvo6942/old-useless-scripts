<?php 
include'../../includes/config.php';
$db->connect();
$user = mysql_fetch_array(mysql_query('select username,email,mobile,password,regdate,ban,sms from users where id="'.$_GET['id'].'"'));
$NTITLE='cPanel > Users > '.$user['username'];
if ($_SESSION['rights'] < 9) {
header('Location: /err');
exit;
}

include'../../header.php'; 

switch ($_GET['act']) {
    case 'del':
        if ($_GET['id'] != $_SESSION['userid'] && $user['rights'] != 9){ 
if(mysql_query('DELETE FROM users WHERE id="'.$_GET['id'].'"')){ echo'<div class="info">User Delete Successful.</div>'; }else{ echo'unknown error'; } 

}
 echo'<div class="path"><a href="index.php">&laquo; Go back User List</a></div>';
 break;
    case 'ban':
if($user['ban'] != 1){
        if(mysql_query('update users set ban="1" where id="'.$_GET['id'].'"')){ echo'<div class="info">User Banned Successful.</div>'; }else{ echo'unknown error'; } }else{ echo'<div class="error ">User Already Banned.</div>'; }
echo'<div class="path"><a href="profile.php?id='.$_GET['id'].'">&laquo; Go back</a></div>';
        break;
    default:
echo'<h2>'.$user['username'].'\'s Profile Info</h2>'; 

if ($_SESSION['rights'] == 9){ 
echo'<a href="edit.php?id=' . $_GET['id'] . '">Edit</a> &raquo; ';
if ($_GET['id'] != $_SESSION['userid']){
echo'<a href="profile.php?act=del&amp;id='.$_GET['id'].'">Delete</a>'; 
if($user['ban']!=1)
echo' &raquo; <a href="profile.php?act=ban&amp;id='.$_GET['id'].'">Ban</a>'; 
} }
echo'<div class="info" align="left">Username: '.$user['username'].'<br/> Email: '.$user['email'].'<br/> Mobile: '.$user['mobile'].'<br/>Total Post: '.$user['sms'].' SMS <br/>Registered: '.date("Y-M-d h:i:sa",$user['regdate']).'</div>';
echo'<div class="path"> &raquo; <a href="/">Home</a> &raquo; <a href="/panel">cPanel</a> &raquo; <a href="/panel/users">Users</a></div>';
}
include'footer.php'; 
?>