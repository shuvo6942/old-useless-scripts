<?php  
require'../../includes/config.php';

if ($_SESSION['rights'] < 8) {
header('Location: /err');
exit;
}

$NTITLE= '> cPanel > Users';
require '../../header.php'; 


echo' <h2>Users Management</h2>';

$pagingqry = 'select * from users order by id'; $rowsPerPage=10;
 $gets='?';
 
$pagelink = 'index.php?page=';
  include("../../includes/paging_admin.php");
 $USR = $db->query($pagingqry.$limit); $TOTAL_USR = $numrows;
 foreach($USR as $key => $val) {   
 echo'<div class="catRow"><a href="profile.php?id='.$val['id'].'">'.$val['username'];
if($val['rights'] == 9){ 
echo' (Head Admin)'; }
elseif($val['rights'] == 8){ 
echo' (second Admin)'; } 
elseif($val['rights'] == 7){ 
echo' (Third Admin)'; } 
echo'</a></div>'; 
}
 echo $PAGE_CODE; 
echo'<div class="path"> &raquo; <a href="/">Home</a> &raquo; <a href="/panel">cPanel</a></div>';
 include '../../footer.php'; ?>