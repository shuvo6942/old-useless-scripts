<?php
include'../../includes/config.php';
$db->connect();
$user = mysql_fetch_array(mysql_query('select username,email,mobile,password,regdate,ban,rights from users where id="'.$_REQUEST['id'].'"'));
$userid=$user['id'];
$NTITLE='cPanel > Users > Edit Peofile: '.$user['username'];
if ($_SESSION['rights'] != 9) {
header('Location: /err');
exit;
}

include'../../header.php'; 

echo'<h2>Edit Profile: '.$user['username'].'</h2>';


if($_POST['submit']!=''){
if(strlen($_POST['username']) >= 4){
if(preg_match('#^(([a-z0-9!\#$%&\\\'*+/=?^_`{|}~-]+\.?)*[a-z0-9!\#$%&\\\'*+/=?^_`{|}~-]+)@(([a-z0-9-_]+\.?)*[a-z0-9-_]+)\.[a-z]{2,}$#i',$_POST['email'])){				$nusername = mysql_real_escape_string($_POST['username']);
$ousername = mysql_real_escape_string($user['username']);
$userid=$_REQUEST['id'];
$email = mysql_real_escape_string($_POST['email']);
					$mobile = mysql_real_escape_string($_POST['mobile']);
$totalsms = mysql_result(mysql_query("SELECT COUNT(*) FROM sms WHERE user_id = '$userid'"), 0);
if(isset($_POST['ban'], $_POST['rights']) ==''){
$ban = $user['ban'];
$rights = $user['rights'];
}else{ 
$ban = $_POST['ban'];
$rights = $_POST['rights'];
}
if($ousername == $nusername){	if(mysql_query('update users set username="'.$nusername.'", ban="'.$ban.'", email="'.$email.'", mobile="'.$mobile.'", rights="'.$rights.'", sms="'.$totalsms.'" where id="'.mysql_real_escape_string($_REQUEST['id']).'"')){
echo'<div class="info">successfuly been updated.</div>';					}else{
echo'<div class="error">An error occurred while updating your informations.</div>';
}
}else{

$dn = mysql_fetch_array(mysql_query('select count(*) as nb from users where username="'.$nusername.'"'));
if($dn['nb']==0)					{
						if(mysql_query('update users set username="'.$nusername.'", ban="'.$ban.'", email="'.$email.'", mobile="'.$mobile.'", rights="'.$rights.'", sms="'.$totalsms.'" where id="'.mysql_real_escape_string($_REQUEST['id']).'"')){
echo'<div class="info">successfuly been updated.</div>';					}else{
echo'<div class="error">An error occurred while updating your informations.</div>';						}					}else{
												echo'<div class="error">The username already exit.</div>';
					}
}
}else{
					 echo'<div class="error">The email you entered is not valid.</div>'; 
}
}else{ 
echo'<div class="error ">Username must contain at least 4 characters.</div>';
}
}
echo'<form action="" method="post"><div class="fl odd">User Name:<br /><input type="text" value="' . $user['username'] . '" name="username" /></div><div class="fl odd">email: <br /><input type="text" value="' . $user['email'] . '" name="email" /></div><div class="fl odd">Mobile: <br /><input type="text" value="' . $user['mobile'] . '" name="mobile" /></div>'; 

if($_REQUEST['id'] != $_SESSION['userid']){
echo'<div class="fl odd">Banned: <br/> <input type="radio" value="1" name="ban" ' . ($user['ban'] == '1' ? 'checked="checked"' : '') . '/>Yes <input type="radio" value="0" name="ban" ' . ($user['ban'] == '0' ? 'checked="checked"' : '') . '/>No</div><div class="fl odd">Functionary on the site:<br/><input type="radio" value="0" name="rights" ' . ($user['rights'] < '7' ? 'checked="checked"' : '') . '/> User <br/><input type="radio" value="7" name="rights" ' . ($user['rights'] == '7' ? 'checked="checked"' : '') . '/> Third Admin <br/><input type="radio" value="8" name="rights" ' . ($user['rights'] == '8' ? 'checked="checked"' : '') . '/> Second Admin <br/><input type="radio" value="9" name="rights" ' . ($user['rights'] == '9' ? 'checked="checked"' : '') . '/> <font color="red">Head Admin</font></div>'; 
}
echo'<div class="fl odd"><a href="chpass.php?id='.$_GET['id'].'">Change Password</a><br/><br /><input type="hidden" name="id" value="'.$_REQUEST['id'].'" /><input name="submit" type="submit" value="Save" /></div> </form>';
echo'<div class="path"><a href="profile.php?id='.$_REQUEST['id'].'"> &laquo; Go back</a></div>';
include'../../footer.php'; 
?>