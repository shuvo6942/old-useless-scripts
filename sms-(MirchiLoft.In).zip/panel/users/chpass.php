<?php 

include'../../includes/config.php';
$db->connect();
$user = mysql_fetch_array(mysql_query('select username,email,mobile,password,regdate,ban,sms from users where id="'.$_REQUEST['id'].'"'));
$NTITLE='cPanel > Users > '.$user['username'];
if ($_SESSION['rights'] < 9) {
header('Location: /err');
exit;
}

include'../../header.php'; 
echo'<h2>Change Password: '.$user['username'].'</h2>';	

	if(isset($_POST['newpass'], $_POST['newpassverif'])){ 

$_POST['newpass'] = stripslashes($_POST['newpass']); 
$_POST['newpassverif'] = stripslashes($_POST['newpassverif']);

	if($_POST['newpass']==$_POST['newpassverif']){ 

if(strlen($_POST['newpass'])>=6) {
$newpass = mysql_real_escape_string($_POST['newpass']);

if(mysql_query('update users set password="'.md5($newpass).'" where id="'.mysql_real_escape_string($_REQUEST['id']).'"')){
echo'<div class="info">User Password have successfuly been changed.</div>'; 
} else {
echo'<div class="error">An error occurred while changing User password.</div>';
}

} else { 
echo'<div class="error"> password must contain at least 6 characters.</div>';
} 
} else {
echo'<div class="error">The verify  password  not match.</div>';
}
} 
  echo'<form action="" method="post"><div class="fl odd">
<b>Password:*</b> (6 characters min.) <br/> <input type="password" name="newpass" /></div><div class="fl odd"><b>
Re Type Password:*</b><br/><input type="password" name="newpassverif" value="" /><br /><input type="hidden" name="id" value="'.$_REQUEST['id'].'" /><input type="submit" value="change" /></div></form>'; 
include'footer.php'; 
?>