<?php  
require'../includes/config.php';

if ($_SESSION['rights'] < 7) {
header('Location: /err');
exit;
}

$NTITLE= '> cPanel > Pending SMS';
require '../header.php'; 


echo' <h2>Pending SMS Management</h2>';

switch ($_POST['act']) { 
case 'del':
if (empty($_POST['id'])) {
echo'<div class="error">You do not choose to delete!</div>'; } else { 
if($_POST['act'] == del){
foreach ($_POST['id'] as $delid) { 
$delete = 'delete from usr_post where id = '.$delid;
$db->query($delete);
}
echo'<div class="info">SMS Deleted!</div>'; 
}
}

break; 
case 'approve':
if (empty($_POST['id'])) {
echo'<div class="error">You do not choose to delete!</div>'; } else { 
if($_POST['act'] == approve){
foreach ($_POST['id'] as $id) { 

$sms = $db->query('select * from usr_post where id = '.$id,database::GET_ROW);

$approve = "insert into sms (text, user_id, username, cid, newtag, date) VALUES ('".$sms["text"]."', '".$sms["user_id"]."', '".$sms["username"]."', '".$sms["cid"]."', '1', '".$sms["date"]."')";
$db->query($approve);

$approveUpdate = 'update category set totalitem = totalitem + 1 where id ='.$sms['cid'];
$db->query($approveUpdate);


$approveUpdate = 'update users set sms = sms + 1 where id = '.$sms['user_id'];
$db->query($approveUpdate);
$delete = 'delete from usr_post where id = '.$id;
$db->query($delete);

}
echo'<div class="info">SMS Approved!</div>'; 
}
}

break; }

$pagingqry = 'select * from usr_post order by id desc'; $rowsPerPage=10;
 $gets='?';
 
$pagelink = BASE_PATH.'pending.php?page=';
  include("../includes/paging_admin.php");
 $SMS = $db->query($pagingqry.$limit); $TOTAL_SMS = $numrows;

if($TOTAL_SMS !=0){
echo'<form action="" method="POST">';
 foreach($SMS as $key => $val) {   
$cat = $db->query('select * from category where id = '.$val['cid'],database::GET_ROW);

 echo'<div class="smsRow"><p class="sms"><input type="checkbox" name="id[]" value="'.$val["id"].'"/>&nbsp;<b>'.$val['text'].'</b></p><div class="smsInfo">By: <a href="/smslist/uid/'.$val['user_id'].'/'.$val['username'].'">'.$val['username'].'</a> In: <a href="/smslist/'.$val['cid'].'/'.str_replace(array(' ','%20'),'_',$cat['name']).'">'.$cat['name'].'</a><br/>'; echo time_ago($val['date']).'</div> </div>';
                          
                        }

echo'Action:<br/><select name="act"><option value="approve">Approve</option><option value="del">Delete</option></select> <input type="submit" value="Apply"/></form>';}
               echo $PAGE_CODE; 


echo'<div class="path"> &raquo; <a href="/">Home</a> &raquo; <a href="/panel">cPanel</a></div>';
 include '../footer.php'; ?>