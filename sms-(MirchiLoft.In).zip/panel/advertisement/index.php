<?php
include'../../includes/config.php';
 include '../../header.php'; ?>
<h2>Manage Advertisement</h2>
<form name="frmu" action="adver_db.php" method="post" class="niceform">
<h2>Home Top</h2> 
<h4>Mobile Version</h4>
                    <textarea name="home_topm"><?php
                            $File = "../../a.adv";
                            $Handle = fopen($File, 'r');
                            $theData = @fread($Handle, filesize($File));
                            fclose($Handle);
                            echo $theData;
                        ?></textarea>
                    <h4>Pc Version</h4>
                    <textarea name="home_topp"><?php
                            $File = "../../a.pdv";
                            $Handle = fopen($File, 'r');
                            $theData = @fread($Handle, filesize($File));
                            fclose($Handle);
                            echo $theData;
                        ?></textarea>
               
<br/> <br/>
                <h2>Home Bottom</h2>
             
                    <h4>Mobile Version</h4>
                    <textarea name="home_bottomm"><?php
                            $File = "../../b.adv";
                            $Handle = fopen($File, 'r');
                            $theData = @fread($Handle, filesize($File));
                            fclose($Handle);
                            echo $theData;
                        ?></textarea>
                    <h4>Pc Version</h4>
                    <textarea name="home_bottomp"><?php
                            $File = "../../b.pdv";
                            $Handle = fopen($File, 'r');
                            $theData = @fread($Handle, filesize($File));
                            fclose($Handle);
                            echo $theData;
                        ?></textarea>
<br/> <br/> 
                <h2>Home Category End</h2>
              
                    <h4>Mobile Version</h4>
                    <textarea name="home_categorym"><?php
                            $File = "../../c.adv";
                            $Handle = fopen($File, 'r');
                            $theData = @fread($Handle, filesize($File));
                            fclose($Handle);
                            echo $theData;
                        ?></textarea>
                    <h4>Pc Version</h4>
                    <textarea name="home_categoryp"><?php
                            $File = "../../c.pdv";
                            $Handle = fopen($File, 'r');
                            $theData = @fread($Handle, filesize($File));
                            fclose($Handle);
                            echo $theData;
                        ?></textarea>
            <h2>All Page Top</h2>
              
                    <h4>Mobile Version</h4>
                    <textarea name="all_page_topm"><?php
                            $File = "../../d.adv";
                            $Handle = fopen($File, 'r');
                            $theData = @fread($Handle, filesize($File));
                            fclose($Handle);
                            echo $theData;
                        ?></textarea>
                    <h4>Pc Version</h4>
                    <textarea name="all_page_topp"><?php
                            $File = "../../d.pdv";
                            $Handle = fopen($File, 'r');
                            $theData = @fread($Handle, filesize($File));
                            fclose($Handle);
                            echo $theData;
                        ?></textarea>
                <br/> <br/> 
<h2>All Page Bottom</h2>
                    <h4>Mobile Version</h4>
                    <textarea name="all_page_bottomm"><?php
                            $File = "../../e.adv";
                            $Handle = fopen($File, 'r');
                            $theData = @fread($Handle, filesize($File));
                            fclose($Handle);
                            echo $theData;
                        ?></textarea>
<h4>Pc Version</h4>
                    <textarea name="all_page_bottomp"><?php
                            $File = "../../e.pdv";
                            $Handle = fopen($File, 'r');
                            $theData = @fread($Handle, filesize($File));
                            fclose($Handle);
                            echo $theData;
                        ?></textarea>
           <br /><br/>
                <input type="submit" name="submit" value="Save Advertisement" />
        </form>
<?php include'../../footer.php'; ?>