<?php
	include("../../includes/config.php");
	if(get_magic_quotes_runtime())
		set_magic_quotes_runtime(0);

	if (get_magic_quotes_gpc())
	{
		function stripslashes_array($array)
		{
			return is_array($array) ? array_map('stripslashes_array', $array) : stripslashes($array);
		}

	
		$_REQUEST = stripslashes_array($_REQUEST);
	
	}
		$am = $_REQUEST['home_topm'];
		$bm = $_REQUEST['home_bottomm'];
		$cm = $_REQUEST['home_categorym'];
		$dm = $_REQUEST['all_page_topm'];
		$em = $_REQUEST['all_page_bottomm'];
		$ap = $_REQUEST['home_topp'];
		$bp = $_REQUEST['home_bottomp'];
		$cp = $_REQUEST['home_categoryp'];
		$dp = $_REQUEST['all_page_topp'];
		$ep = $_REQUEST['all_page_bottomp'];

		$addarray = array('a.adv','b.adv','c.adv','d.adv','e.adv',
                    'a.pdv','b.pdv','c.pdv','d.pdv','e.pdv');
		$valarray = array($am,$bm,$cm,$dm,$em,
                    $ap,$bp,$cp,$dp,$ep);
		foreach($addarray as $k => $v)
		{
			$File = "../../$v"; 
			$Handle = fopen($File, 'w');
			$Data = $valarray[$k]; 
			fwrite($Handle, $Data); 
			fclose($Handle); 
		}
		header("location: index.php?errid=13");
		
?>