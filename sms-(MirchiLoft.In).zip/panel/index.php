<?php 
require('../includes/config.php');
$db->connect();
include'recount.php';

if ($_SESSION['rights'] < 7) {
header('Location: /err');
exit;
}

$NTITLE= 'cPanel';
require('../header.php');

echo '<h2>Admin Panel';
if($_SESSION['rights'] == 9){ 
echo' (Head Admin)'; }
elseif($_SESSION['rights'] == 8){ 
echo' (second Admin)'; } 
elseif($_SESSION['rights'] == 7){ 
echo' (Third Admin)'; }
echo'</h2>';
if ($_SESSION['rights'] >=8) { 

echo'<div class="catRow"><a href="category">Categories Management</a></div>'; 
}
echo'<div class="catRow"><a href="pending.php">Pending SMS ('.mysql_result(mysql_query("SELECT COUNT(*) FROM `usr_post` WHERE `id`"), 0).')</a></div>'; 
if ($_SESSION['rights'] == 9) { echo '<div class="catRow"><a href="users">Users ('.mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `id`"), 0).')</a></div>';
echo'<div class="catRow"><a href="admin.php">Administration('.mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `rights` >= '7'"), 0).')</a></div>'; 
echo'<div class="catRow"><a href="ban.php">Banned ('.mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `ban` ='1'"), 0).')</a></div>';
echo '<div class="catRow"><a href="advertisement">Advertisement</a></div><div class="catRow"><a href="settings.php">Settings</a></div>'; } 
echo'<div class="path"> &raquo; <a href="/">Home</a></div>';
require('../footer.php');

?>