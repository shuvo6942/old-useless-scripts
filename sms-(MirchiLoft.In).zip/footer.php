<center>
<?php if($LOGO != '')
{
include 'b'.$agent_ext;
}
?>
<center/>
<center>
<?php
if($LOGO == '')
include 'e'.$agent_ext;
?>
<div id="online">
<?php
include'online.php'; 
 $db->disconnect(); ?></div>

</center><div class="ftrLink"><a class="siteLink" href="<?=BASE_PATH?>" style="font-size:14px"><?=SITENAME?></a> - <a href="/disclaimer" class="siteLink">Disclaimer</a> - <a href="/contact" class="siteLink">Contact Us</a> </div>

</body></html>