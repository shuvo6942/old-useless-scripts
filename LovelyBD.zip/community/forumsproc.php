<?php
session_start();
include("config.php");
include("core.php");
connectdb();
header("Content-type: text/html; charset=utf-8");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo "<head>";
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
##F0RUMS C0D3 100% CR3AT3D BY CJ UDAY :-)
echo "<body><meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG : Don't Try To Hack OR else :P\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"main,all,follow\"/></head>";
echo "<body>";
$action = $_GET["action"]; $sid = $_SESSION["sid"];
$clid = $_GET["clid"]; $page = $_GET["page"];
$who = $_GET["who"];
$uid = getuid_sid($sid);
$sitename = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='sitename'"));
$sitename = $sitename[0];
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
echo "<br/>";
echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
$banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
$remain =  $banto[0] - time();
$rmsg = gettimemsg($remain);
echo "<b>Time Remaining: $rmsg</b><br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "</p>";
echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
$uid = getuid_sid($sid);
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php"); 
echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
 echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "<div class=\"div align=\"center\">Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");  
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please Contact <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(isdeactivated(getuid_sid($sid), $uid))
{
echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<br/><b>Your Account Has Been Deactivated.<br/>And It Will Be Never Activated Again!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
////////////////////////Updated :)
if($action=="newtopic")
{
  $fid = $_POST["fid"];
  $ntitle = $_POST["ntitle"];
  $tpctxt = $_POST["tpctxt"];
$udayt = $_POST["tpctag"];
  $type = $_POST["type"];
  if(!canaccess(getuid_sid($sid), $fid))
    {
	echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
  echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>You Don't Have A Permission To View The Contents Of This Forum<br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
    }
if(istrashed(getuid_sid($sid)))
  {
	echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
  echo "<div class=\"shout2\" align=\"center\">";
      echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Unknown error cannot create topic!<br/>please try again later...<br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../img/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      echo "</html>";
      exit();
  }
  addonline(getuid_sid($sid),"Created New Topic","forums.php?action=$action");
	    echo "<head>";
    echo "<title>Create A New Topic</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
			echo "<b>Create Topic</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
      $crdate = time();
     $texst = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_topics WHERE name LIKE '".$ntitle."' AND fid='".$fid."'"));
      if($texst[0]==0)
      {
        $res = false;
        $ltopic = mysql_fetch_array(mysql_query("SELECT crdate FROM ibwff_topics WHERE authorid='".$uid."' ORDER BY crdate DESC LIMIT 1"));
        global $topic_af;
        $antiflood = time()-$ltopic[0];
        if($antiflood>$topic_af)
{
  if((trim($ntitle)!="")||(strlen($tpctxt)<200) || (trim($udayt)!=""))
      {
    if(!isblocked($ntitle,$uid)&&!isblocked($tpctxt,$uid))
   {
if(fmtvldtn())
{
$cj = '1';
}else{
$cj = '0';
}
      $res = mysql_query("INSERT INTO ibwff_topics SET name='".$ntitle."', fid='".$fid."', authorid='".$uid."', text='".$tpctxt."', type='".$type."', crdate='".$crdate."', lastpost='".$crdate."', uday_tag='".$udayt."', uday_vld='".$cj."'");
    }else{
    echo "<b><u><i>Can't Create Topic!!!<br/><br/>";
   echo "You Just Tried To Spam In FireBD via Topic<br/>So You Are Now Forum Banned!<br/>If You Forum Banned By Our Mistake or Want To Be Forum Unban<br/>Then Please Contact <a href=\"online.php?action=stfol\">Online Staffs</a></b></i></u><br/><br/>";
        $user = getnick_sid($sid);
    mysql_query("UPDATE ibwff_users SET forumban='1' WHERE id='".$uid."'");
    mysql_query("INSERT INTO ibwff_private SET text='[b](forwarded spam via creating new topic)[/b][br/]".$tpctxt."', byuid='".$uid."', touid='1', timesent='".$crdate."'");
	mysql_query("INSERT INTO ibwff_private SET text='[b](forwarded spam via creating new topic)[/b][br/]".$tpctxt."', byuid='".$uid."', touid='2', timesent='".$crdate."'");
	mysql_query("INSERT INTO ibwff_private SET text='[b](forwarded spam via creating new topic)[/b][br/]".$tpctxt."', byuid='".$uid."', touid='4', timesent='".$crdate."'");
	echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      echo "</body>";
      echo "</html>";
      exit();
  }
     }
       if($res)
      {
        $cow = mysql_fetch_array(mysql_query("SELECT topics,plusses FROM ibwff_users WHERE id='".$uid."'"));
        $utpc = $cow[0]+1;
$uday = mkfpoint();
        $upl = $cow[1]+$uday;
        mysql_query("UPDATE ibwff_users SET topics='".$utpc."', plusses='".$upl."' WHERE id='".$uid."'");
        $tnm = htmlspecialchars($ntitle);
$ibwff = time()+6*60*60;
$user = getnick_uid($uid);
$who = getnick_uid($who);
mysql_query("insert into ibwff_events (event,time) values ('<b>$user</b> has created a new topic','$ibwff')");
        echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Topic <b>$tnm</b> Created Successfully!";
mysql_query("INSERT INTO uday_ftag SET tid='".$tid."' AND tags ='".$udayt."'");
        $tid = mysql_fetch_array(mysql_query("SELECT id FROM ibwff_topics WHERE name='".$ntitle."' AND fid='".$fid."'"));
        echo "<br/><br/><a href=\"forums.php?clid=$clid&tid=$tid[0]\">";
echo "View Topic</a><br/><br/>";
$clid = $_GET["clid"];
		if ($clid>0)
{
mysql_query("UPDATE ibwff_clubs SET plusses=plusses+10 WHERE id='".$clid."'");
mysql_query("UPDATE ibwff_clubmembers SET points=points+10 WHERE uid=$uid AND clid=$clid");
$name = getclubname($clid);
echo "<br/>Topic create under <b>$name</b> club!<br/>";
$msg = "[b]Club notification:[/b] A new topic named [topic=$tid[0]]".$ntitle."[/topic] created in ".$name." club by [user=$uid]".$user."[/user]";
clubnot_uday($clid,$msg);
$history = "<b>$user</b> has created a new topic <b>$ntitle</b>";
clubhis_uday($clid,$history);
}
      }else{
        echo "<br/><img src=\"../avatars/notok.gif\" alt=\"X\"/>Error Creating New Topic!<br/>";
      }
      }else{
        $af = $topic_af -$antiflood;
        echo "<br/><img src=\"../avatars/notok.gif\" alt=\"X\"/>Flood Control: $af<br/><u>Please Wait A Few Seconds</u><br/><br/>";
      }
      }else{
        echo "<br/><img src=\"../avatars/notok.gif\" alt=\"X\"/>Topic Name Already Exist!<br/>";
      }
      $fname = getfname($fid);
      echo "<br/><br/><a href=\"forums.php?action=viewtopicbox&clid=$clid&fid=$fid\">";
echo "$fname</a><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="post")
{
 $ban = mysql_fetch_array(mysql_query("SELECT postban FROM ibwff_users WHERE id='".$uid."'"));
if($ban[0] > 0)
  {
	echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
			 echo "<div class=\"header\" align=\"center\">";
			  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/><b><u><i>Can't Post On Topic<br/>";
  echo "You're Topic Post banned!</i></u></b><br/><br/>";
 echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
    exit();
    }
    $tid = $_POST["tid"];
    $tfid = mysql_fetch_array(mysql_query("SELECT fid FROM ibwff_topics WHERE id='".$tid."'"));
if(!canaccess(getuid_sid($sid), $tfid[0]))
    {
	echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
			echo "<img src=\"../avatars/notok.gif\"><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>You Don't Have A Permission To View The Contents Of This Forum<br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      echo "</html>";
      exit();
    }
if(istrashed(getuid_sid($sid)))
  {
	echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
			echo "<img src=\"../avatars/notok.gif\"><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
      echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Unknown error cannot post! <br/>please try again later...<br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
      exit();
  }
  $reptxt = $_POST["reptxt"];
  $qut = $_POST["qut"];
  addonline(getuid_sid($sid),"Posting A Reply","forums.php?action=viewtopic");
	    echo "<head>";
    echo "<title>Posted A Reply</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
			echo "<b>Post Reply</b></div>";
  echo "<div class=\"shout2\" align=\"left\">";
      $crdate = time();
      $res = false;
	 $closed = mysql_fetch_array(mysql_query("SELECT closed FROM ibwff_topics WHERE id='".$tid."'"));
	    if($closed[0]!='0')
      {
	  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Topic Is Closed For Posting!";
	  echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
	  exit();
	  }
$x = mysql_fetch_array(mysql_query("SELECT ttyp FROM ibwff_topics WHERE id='".$tid."'"));
$y = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_posts WHERE uid='".$uid."' AND tid='".$tid."'"));
if($y[0]!=0 && $x[0]==1)
{
      echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>This is a one post topic and you have posted once. So, you cannot post!<br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
      if(($closed[0]!='1')||(ismod($uid)))
      {
        $lpost = mysql_fetch_array(mysql_query("SELECT dtpost FROM ibwff_posts WHERE uid='".$uid."' ORDER BY dtpost DESC LIMIT 1"));
		$time = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_antifloods WHERE name='tpostaf'"));
        global $post_af;
        $antiflood = time()-$lpost[0];
        if($antiflood>$post_af)
{
  if(trim($reptxt)!="")
      {
      $postxt = parsepm($reptxt,$sid);
$nrom = substr_count($postxt,"<img src=");
    if($nrom>2){
      echo "<small>";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\">You can use just 2 smiles on post !!!<br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
    }
      $res = mysql_query("INSERT INTO ibwff_posts SET text='".$reptxt."', tid='".$tid."', uid='".$uid."', dtpost='".$crdate."'");
  }
      if($res)
      {
        $cow = mysql_fetch_array(mysql_query("SELECT posts,plusses FROM ibwff_users WHERE id='".$uid."'"));
		$res2 = mysql_fetch_array(mysql_query("SELECT name,authorid FROM ibwff_topics WHERE id='".$tid."'"));
	    $replayer = getnick_sid($sid);
		$tname = htmlspecialchars($res2[0]);		 mysql_query("INSERT INTO ibwff_notifications SET text='Your Topic [topic=$tid]$tname"."[/topic] Has Been Replied By [user=$uid]$replayer"."[/user]', touid='".$res2[1]."', timesent='".time()."'");
$a = mysql_fetch_array(mysql_query("SELECT * FROM uday_subtop WHERE uid='".$uid."' AND tid='".$tid."'"));
if($a[0]==0)
{
mysql_query("INSERT INTO uday_subtop SET uid='".$uid."', tid='".$tid."', time='".$tm."'");
}
//TOPIC N0TIFICATI0N :-)
$msg = "[b]Topic Notification[/b]: Your Subscribed Topic [topic=$tid]".$tname."[/topic] Has Been Replied By [user=$uid]".$replayer."[/user]";
topnot_uday($tid,$msg);
////D0NE!
        $ups = $cow[0]+1;
$uday = fcompoint();
        $upl = $cow[1]+$uday;
        mysql_query("UPDATE ibwff_users SET posts='".$ups."', plusses='".$upl."' WHERE id='".$uid."'");
        mysql_query("UPDATE ibwff_topics SET lastpost='".$crdate."' WHERE id='".$tid."'");
        echo "<br/><img src=\"../avatars/ok.gif\" alt=\"O\"/>Topic Replied Successfully!";
        echo "<br/><br/><a href=\"forums.php?clid=$clid&tid=$tid&go=last\">";
echo "View Topic</a><br/><br/>";
      }else{
        echo "<br/><img src=\"../avatars/notok.gif\" alt=\"X\"/>Error To Repalied This Topic<br/><br/>";
      }
      }else{
$af = $post_af -$antiflood;
        echo "<br/><img src=\"../avatars/notok.gif\" alt=\"X\"/>Antiflood Control: $af<br/><br/>";
      }
      }else{
        echo "<br/><img src=\"../avatars/notok.gif\" alt=\"X\"/>Topic Is Closed for Posting<br/><br/>";
      }
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="rpost")
{
  $pid = $_GET["pid"];
  addonline(getuid_sid($sid),"Reporting Post","forums.php?action=forums");
    	    echo "<head>";
    echo "<title>Report A Post</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
			echo "<b>Report A Topic Post</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  $pinfo = mysql_fetch_array(mysql_query("SELECT reported FROM ibwff_posts WHERE id='".$pid."'"));
          if($pinfo[0]=="0")
          {
          $str = mysql_query("UPDATE ibwff_posts SET reported='1' WHERE id='".$pid."' ");
          if($str)
          {
            echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Post reported to mods Successfully!";
          }else{
            echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Can't report post at the moment";
          }
          }else{
            echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>This Post is already reported";
          }
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="rtpc")
{
  $tid = $_GET["tid"];
  addonline(getuid_sid($sid),"Reporting Topic","forums.php?action=forums");
    	    echo "<head>";
    echo "<title>Report A Topic</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
			echo "<b>Report A Topic</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  $pinfo = mysql_fetch_array(mysql_query("SELECT reported FROM ibwff_topics WHERE id='".$tid."'"));
          if($pinfo[0]=="0")
          {
          $str = mysql_query("UPDATE ibwff_topics SET reported='1' WHERE id='".$tid."' ");
          if($str)
          {
            echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Topic reported to mods Successfully!";
          }else{
            echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Can't report topic at the moment";
          }
          }else{
            echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>This Topic is already reported";
          }
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="tpcrate")
{
     echo "<head>";
    echo "<title>Rating Topic</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
						echo "<div class=\"header\" align=\"center\">";
			echo "<b>Rating A Topic</b></div>";
						echo "<div class=\"shout2\" align=\"left\">";
$tid = $_GET["tid"];
$rate = $_POST["rate"];
$tm = time();
$x = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM uday_tpcrate WHERE uid='".$uid."' AND tid='".$tid."'"));
if($x[0]==0)
{
$tid = $_GET["tid"];
$rate = $_POST["rate"];
$tm = time();
$rx = mysql_query("INSERT INTO uday_tpcrate SET uid='".$uid."', tid='".$tid."', rate='".$rate."', time='".time()."'");
if($rx)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> Topic Rated Successfully!<br/>&#171;<a href=\"forums.php?tid=$tid\">View Topic</a>";
//T0PIC N0TIFICATION :-)
$tn = mysql_fetch_array(mysql_query("SELECT name FROM ibwff_topics WHERE id='".$tid."'"));
$tnm = htmlspecialchars($tn[0]);
$nick = getnick_sid($sid);
$msg = "[b]Topic Notification[/b]: Your Subscribed Topic [topic=$tid]".$tnm."[/topic] Has Been Rated ".$rate." Out Of 5 By [user=$uid]".$nick."[/user]";
topnot_uday($tid,$msg);
//D0NE :-)
}else{
echo "<img src=\"../images/notok.gif\" alt=\"O\"> Topic Cannot Be Rated At This Moment!<br/>&#171;<a href=\"forums.php?tid=$tid\">View Topic</a>";
}
}else{
echo "<img src=\"../images/notok.gif\" alt=\"O\"> You Have Already Rated This Topic!<br/>&#171;<a href=\"forums.php?tid=$tid\">View Topic</a>";
}
    echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php?\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="tpcsub")
{
  $who = $_GET["who"];
$tid = $_GET["tid"];
$tm = time();
     echo "<head>";
    echo "<title>Subscribing Topic</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
						echo "<div class=\"header\" align=\"center\">";
			echo "<b>Subscribing A Topic</b></div>";
						echo "<div class=\"shout2\" align=\"left\">";
$uid = getuid_sid($sid);
$rx = mysql_query("INSERT INTO uday_subtop SET uid='".$uid."', tid='".$tid."', time='".$tm."'");
if($rx)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> Topic Subscribed Successfully!<br/>&#171;<a href=\"forums.php?tid=$tid\">View Topic</a>";
}else{
echo "<img src=\"../images/notok.gif\" alt=\"O\"> Topic Cannot Be Subscribed At This Moment!<br/>&#171;<a href=\"forums.php?tid=$tid\">View Topic</a>";
} 
    echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="tpcunsub")
{
$uid = getuid_sid($sid);
$tid = $_GET["tid"];
     echo "<head>";
    echo "<title>Unsubscribing Topic</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
						echo "<div class=\"header\" align=\"center\">";
			echo "<b>Unsubscribing A Topic</b></div>";
						echo "<div class=\"shout2\" align=\"left\">";
$rx = mysql_query("DELETE FROM uday_subtop WHERE uid='".$uid."' AND tid='".$tid."'");
if($rx)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> Topic Unsubscribed Successfully!<br/>&#171;<a href=\"forums.php?tid=$tid\">View Topic</a>";
}else{
echo "<img src=\"../images/notok.gif\" alt=\"O\"> Topic Cannot Be Unsubscribed At This Moment!<br/>&#171;<a href=\"forums.php?tid=$tid\">View Topic</a>";
} 
    echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="opt")
{
$tid = $_GET["tid"];
     echo "<head>";
    echo "<title>One Post Topic</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
						echo "<div class=\"header\" align=\"center\">";
			echo "<b>One Posting Topic</b></div>";
						echo "<div class=\"shout2\" align=\"left\">";
$rx = mysql_query("UPDATE ibwff_topics SET ttyp='1' WHERE id='".$tid."'");
if($rx)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> Topic One Posted Successfully!<br/>&#171;<a href=\"forums.php?tid=$tid\">View Topic</a>";
}else{
echo "<img src=\"../images/notok.gif\" alt=\"O\"> Topic Cannot Be One Posted At This Moment!<br/>&#171;<a href=\"forums.php?tid=$tid\">View Topic</a>";
} 
    echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="upt")
{
$tid = $_GET["tid"];
     echo "<head>";
    echo "<title>Unlimited Post Topic</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
						echo "<div class=\"header\" align=\"center\">";
			echo "<b>Unlimited Posting Topic</b></div>";
						echo "<div class=\"shout2\" align=\"left\">";
$rx = mysql_query("UPDATE ibwff_topics SET ttyp='0' WHERE id='".$tid."'");
if($rx)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> Topic Unlimited Posted Successfully!<br/>&#171;<a href=\"forums.php?tid=$tid\">View Topic</a>";
}else{
echo "<img src=\"../images/notok.gif\" alt=\"O\"> Topic Cannot Be Unlimited Posted At This Moment!<br/>&#171;<a href=\"forums.php?tid=$tid\">View Topic</a>";
} 
    echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="clot")
{
$tid = $_GET["tid"];
$c = $_GET["tdo"];
if($c == '1')
{
$f = "Closed";
}else{
$f = "Open";
}
     echo "<head>";
    echo "<title>$f Topic</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
						echo "<div class=\"header\" align=\"center\">";
			echo "<b>$f Topic</b></div>";
						echo "<div class=\"shout2\" align=\"left\">";
$rx = mysql_query("UPDATE ibwff_topics SET closed='$c' WHERE id='".$tid."'");
if($rx)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> Topic $f Successfully!<br/>&#171;<a href=\"forums.php?tid=$tid\">View Topic</a>";
}else{
echo "<img src=\"../images/notok.gif\" alt=\"O\"> Topic Cannot Be $f At This Moment!<br/>&#171;<a href=\"forums.php?tid=$tid\">View Topic</a>";
} 
    echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="pint")
{
$tid = $_GET["tid"];
$c = $_GET["tdo"];
if($c == '1')
{
$f = "Pin";
}else{
$f = "Unpin";
}
     echo "<head>";
    echo "<title>$f Topic</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
						echo "<div class=\"header\" align=\"center\">";
			echo "<b>$f Topic</b></div>";
						echo "<div class=\"shout2\" align=\"left\">";
$rx = mysql_query("UPDATE ibwff_topics SET pinned='$c' WHERE id='".$tid."'");
if($rx)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> Topic $f Successfully!<br/>&#171;<a href=\"forums.php?tid=$tid\">View Topic</a>";
}else{
echo "<img src=\"../images/notok.gif\" alt=\"O\"> Topic Cannot Be $f At This Moment!<br/>&#171;<a href=\"forums.php?tid=$tid\">View Topic</a>";
} 
    echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
?>