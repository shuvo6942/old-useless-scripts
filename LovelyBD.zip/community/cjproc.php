<?php
session_start();
include("config.php");
include("core.php");  connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo '<head>';
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"title\" content=\"FireBD.NeT\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From Megh: Don't Try To Hack OR else :P\">
<meta name=\"keywords\" content=\"Site Desined By Megh :) :)\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/></head>";
echo "<body>";
$action = $_GET["action"]; $sid = $_SESSION["sid"];
$page = $_GET["page"];
$who = $_GET["who"];
$uid = getuid_sid($sid);
$name = $_GET["name"];
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();
////////////////Ip Banned By CJ UDAY :)	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
    echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
	echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
      echo "<br/>";
      echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
      $banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
      $remain =  $banto[0] - time();
      $rmsg = gettimemsg($remain);
      echo "<b>Time Remaining: $rmsg</b><br/>";
      $nick = getnick_uid($banto[2]);
       $text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
      echo "</p>";
    	echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
    echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
    echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
//////////////////Banned System Updated By CJ UDAY :)
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please With Contact Us <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
 echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
///////////////////Validation By CJ UDAY :)
					if(isvalidated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
	echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  You Are Not Validated!<br/>We are checking your ip and browser<br/>
	  This could take up to 15 munites pls be patient and try again soon<br/>Please try again later...<br/><b>Thank You</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }

///////////////////Deactivated Account By CJ UDAY :)
          if(isdeactivated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  <b>Your Account Has Been Deactivated Forever.<br/>And It Will Be Never Activate!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
if($_REQUEST['who'] =='1')
{
echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  echo "<b>Unknown Error!!!</b><br/>Unknown Security By CJ UDAY :)<br/><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
else if($_REQUEST['who'] =='2')
{
echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  echo "<b>Unknown Error!!!</b><br/>Unknown Security By CJ UDAY :)<br/><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
else if($_REQUEST['who'] =='3')
{
echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  echo "<b>Unknown Error!!!</b><br/>Unknown Security By CJ UDAY :)<br/><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
else if($_REQUEST['who'] =='4')
{
echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  echo "<b>Unknown Error!!!</b><br/>Unknown Security By CJ UDAY :)<br/><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
else if($action=="deactive")
  {
$bid = $_GET["who"];
addonline(getuid_sid($sid),"Deactivating User","main.php?action=$action");
	echo "<head>";
    echo "<title>Deactivate User</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<b>Deactivate User</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$lname = getnick_uid($bid);
$uday = mysql_query("UPDATE ibwff_users SET diactivate='1' WHERE id='".$bid."'");
if($uday)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> <b>$lname</b> deactivated successfully!<br/>";
$validater = getnick_sid($sid);
$action = 'Dectivate';
$msg = "[b]".$lname."[/b] is deactivated by [b]".$validater."[/b]";
adminnot($msg);
mlog($action, $msg);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> <b>$lname</b> cannot be deactivated at this moment!<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="active")
  {
$bid = $_GET["who"];
addonline(getuid_sid($sid),"Deactivating User","main.php?action=$action");
	echo "<head>";
    echo "<title>Activate User</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<b>Activate User</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$lname = getnick_uid($bid);
$uday = mysql_query("UPDATE ibwff_users SET diactivate='0' WHERE id='".$bid."'");
if($uday)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> <b>$lname</b> activated successfully!<br/>";
$validater = getnick_sid($sid);
$action = 'Activate';
$msg = "[b]".$lname."[/b] is activated by [b]".$validater."[/b]";
adminnot($msg);
mlog($action, $msg);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> <b>$lname</b> cannot be activated at this moment!<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="vip")
  {
$bid = $_GET["who"];
addonline(getuid_sid($sid),"Making User VIP","main.php?action=$action");
	echo "<head>";
    echo "<title>Making VIP</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<b>Making VIP</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$lname = getnick_uid($bid);
$uday = mysql_query("UPDATE ibwff_users SET vip='1' WHERE id='".$bid."'");
if($uday)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> <b>$lname</b> made vip successfully!<br/>";
$validater = getnick_sid($sid);
$action = 'VIP';
$msg = "[b]".$lname."[/b] is now a vip by [b]".$validater."[/b]";
adminnot($msg);
mlog($action, $msg);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> <b>$lname</b> cannot be made vip at this moment!<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="unvip")
  {
$bid = $_GET["who"];
addonline(getuid_sid($sid),"Making User Normal","main.php?action=$action");
	echo "<head>";
    echo "<title>Making Normal</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<b>Making Normal</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$lname = getnick_uid($bid);
$uday = mysql_query("UPDATE ibwff_users SET vip='0' WHERE id='".$bid."'");
if($uday)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> <b>$lname</b> made normal successfully!<br/>";
$validater = getnick_sid($sid);
$action = 'UnVIP';
$msg = "[b]".$lname."[/b] is now normal by [b]".$validater."[/b]";
adminnot($msg);
mlog($action, $msg);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> <b>$lname</b> cannot be normal vip at this moment!<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="trash")
{
  $who = $_GET["who"];
  addonline(getuid_sid($sid),"Trashing User","main.php?action=$action");
  echo "<head>";
  echo "<title>Trash</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"mblock1\" align=\"left\">";
  include("header.php");
  echo "</div>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<b>Trash</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  include("pm_by.php");
  $unick = getnick_uid($who);
  echo "Trashing $unick<br/><form action=\"cjproc.php?action=udaytrash&who=$who\" method=\"post\"> ";
  echo "<p align=\"left\">";
  echo "Reason: <br/><input name=\"pres\" maxlength=\"100\"/><br/>";
  echo "Days: <br/><input name=\"pds\" format=\"*N\" maxlength=\"4\"/><br/>";
  echo "Hours: <br/><input name=\"phr\" format=\"*N\" maxlength=\"4\"/><br/>";
  echo "Minutes: <br/><input name=\"pmn\" format=\"*N\" maxlength=\"2\"/><br/>";
  echo "Seconds: <br/><input name=\"psc\" format=\"*N\" maxlength=\"2\"/><br/>";
  echo "<input type=\"submit\" value=\"Trash\"/></form></p>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
  include("footer.php");
  echo "</div>";
      exit();
}
else if($action=="udaytrash")
{
  $who = $_GET["who"];
  $nick = getnick_uid($who);
  addonline(getuid_sid($sid),"Trashing User","main.php?action=$action");
  echo "<head>";
  echo "<title>Trash</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"mblock1\" align=\"left\">";
  include("header.php");
  echo "</div>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<b>Trash</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  include("pm_by.php");
  $pds = $_POST["pds"];
  $phr = $_POST["phr"];
  $pmn = $_POST["pmn"];
  $psc = $_POST["psc"];
$timeto = $pds*24*60*60;
  $timeto += $phr*60*60;
  $timeto += $pmn*60;
  $timeto += $psc;
  $ptime = $timeto + time();
  $res = mysql_query("INSERT INTO ibwff_penalties SET uid='".$who."', penalty='0', exid='".getuid_sid($sid)."', timeto='".$ptime."', pnreas='', ipadd='', browserm=''");
  if($res)
  {
echo "<img src=\"../images/ok.gif\" alt=\"O\"> <b>$nick</b> trashed successfully!<br/>";
$validater = getnick_sid($sid);
$action = 'Trash';
$msg = "[b]".$nick."[/b] is trashed by [b]".$validater."[/b]";
adminnot($msg);
mlog($action, $msg);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> <b>$lname</b> cannot be trashed at this moment!<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="untr")
{
  $who = $_GET["who"];
  $nick = getnick_uid($who);
  addonline(getuid_sid($sid),"Trashing User","main.php?action=$action");
  echo "<head>";
  echo "<title>Trash</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"mblock1\" align=\"left\">";
  include("header.php");
  echo "</div>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<b>Trash</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  include("pm_by.php");

  $res = mysql_query("DELETE FROM ibwff_penalties WHERE penalty='0' AND uid='".$who."'");
  if($res)
  {
echo "<img src=\"../images/ok.gif\" alt=\"O\"> <b>$nick</b> untrashed successfully!<br/>";
$validater = getnick_sid($sid);
$action = 'Untrash';
$msg = "[b]".$nick."[/b] is untrashed by [b]".$validater."[/b]";
adminnot($msg);
mlog($action, $msg);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> <b>$lname</b> cannot be untrashed at this moment!<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="shld")
  {
$bid = $_GET["who"];
addonline(getuid_sid($sid),"Shielding User","main.php?action=$action");
	echo "<head>";
    echo "<title>Shield User</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<b>Shield User</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$lname = getnick_uid($bid);
$uday = mysql_query("UPDATE ibwff_users SET shield='1' WHERE id='".$bid."'");
if($uday)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> <b>$lname</b> shielded successfully!<br/>";
$validater = getnick_sid($sid);
$action = 'Shield';
$msg = "[b]".$lname."[/b] is shielded by [b]".$validater."[/b]";
adminnot($msg);
mlog($action, $msg);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> <b>$lname</b> cannot shielded at this moment!<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="ushld")
  {
$bid = $_GET["who"];
addonline(getuid_sid($sid),"Unshielding User","main.php?action=$action");
	echo "<head>";
    echo "<title>Unshield User</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Unshield User</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$lname = getnick_uid($bid);
$uday = mysql_query("UPDATE ibwff_users SET shield='0' WHERE id='".$bid."'");
if($uday)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> <b>$lname</b> unshielded successfully!<br/>";
$validater = getnick_sid($sid);
$action = 'Unshield';
$msg = "[b]".$lname."[/b] is unshielded by [b]".$validater."[/b]";
adminnot($msg);
mlog($action, $msg);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> <b>$lname</b> cannot unshielded at this moment!<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="boot")
  {
$who = $_GET["who"];
addonline(getuid_sid($sid),"Booting User","main.php?action=$action");
	echo "<head>";
    echo "<title>Boot User</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Boot User</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$lname = getnick_uid($who);
$uday = mysql_query("DELETE FROM ibwff_ses WHERE uid='".$who."'");
if($uday)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> <b>$lname</b> booted successfully!<br/>";
$validater = getnick_sid($sid);
$action = 'Boot';
$msg = "[b]".$lname."[/b] is booted by [b]".$validater."[/b]";
adminnot($msg);
mlog($action, $msg);
$p = "You are booted by [b]".$validater."[/b]";
notify($po, $who);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> <b>$lname</b> cannot be booted at this moment!<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="up")
  {
$clid = $_GET["clid"];
$mod = $_POST["pf"];
$p = $_POST["p"];
	echo "<head>";
    echo "<title>Point</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Point</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$u = mysql_fetch_array(mysql_query("SELECT plusses FROM ibwff_clubs WHERE id='".$clid."'"));
if($mod=='a'){$x = $u[0] + $p;}
if($mod=='b'){$x = $u[0] - $p;}
$lname = getnick_uid($who);
$uday = mysql_query("UPDATE ibwff_clubs SET plusses='".$x."' WHERE id='".$clid."'");
if($uday)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> <b>$lname</b> points updated successfully!<br/>";
$validater = getnick_sid($sid);
$msg = "[b]".getclubname($clid)."[/b] point updated from ".$u[0]." to ".$x." by [b]".$validater."[/b]";
adminnot($msg);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> points cannot be updated at this moment!<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="uday")
{
echo "<head>";
    echo "<title>Hide Staff</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Hide Staff</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$who = $_GET["who"];
$ud = $_POST["uday"];
$f = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='cd'"));
if($f[0] == $ud)
{
mysql_query("UPDATE ibwff_users SET showonline='1' WHERE id='".$who."'");
echo "[0] staff hidden online successfully!";
}else{
echo "[x] unable to hidden staff online!";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
  echo "</html>";
  exit();
}
?>
</html>