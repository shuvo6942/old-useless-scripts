<?php
session_start();
include("config.php");
include("core.php");  connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo '<head>';
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"title\" content=\"FireBD.NeT\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From Megh: Don't Try To Hack OR else :P\">
<meta name=\"keywords\" content=\"Site Desined By Megh :) :)\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/></head>";
echo "<body>";
$action = $_GET["action"]; $sid = $_SESSION["sid"];
$page = $_GET["page"];
$who = $_GET["who"];
$uid = getuid_sid($sid);
$name = $_GET["name"];
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();
////////////////Ip Banned By CJ UDAY :)	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
    echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
	echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
      echo "<br/>";
      echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
      $banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
      $remain =  $banto[0] - time();
      $rmsg = gettimemsg($remain);
      echo "<b>Time Remaining: $rmsg</b><br/>";
      $nick = getnick_uid($banto[2]);
       $text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
      echo "</p>";
    	echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
    echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
    echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
//////////////////Banned System Updated By CJ UDAY :)
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please With Contact Us <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
 echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
///////////////////Validation By CJ UDAY :)
					if(isvalidated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
	echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  You Are Not Validated!<br/>We are checking your ip and browser<br/>
	  This could take up to 15 munites pls be patient and try again soon<br/>Please try again later...<br/><b>Thank You</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }

///////////////////Deactivated Account By CJ UDAY :)
          if(isdeactivated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  <b>Your Account Has Been Deactivated Forever.<br/>And It Will Be Never Activate!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="addfrm")
  {
$who = getuid_sid($sid);
	echo "<head>";
    echo "<title>Forums</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Add Forum</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<form action=\"cjproc2.php?action=af\" method=\"post\">";  
echo "Name:<br/><input name=\"fcname\" maxlength=\"30\"/><br/>";
  echo "Position:<input name=\"fcpos\" format=\"*N\" size=\"3\"  maxlength=\"3\"/><br/>";
  echo "<input type=\"submit\" value=\"Add\"/></form>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="addlfrm")
  {
$who = getuid_sid($sid);
	echo "<head>";
    echo "<title>Literature</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Add Literature</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<form action=\"cjproc2.php?action=alf\" method=\"post\">";  
echo "Name:<br/><input name=\"fcname\" maxlength=\"30\"/><br/>";
  echo "Position:<input name=\"fcpos\" format=\"*N\" size=\"3\"  maxlength=\"3\"/><br/>";
  echo "<input type=\"submit\" value=\"Add\"/></form>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="addsite")
  {
$who = getuid_sid($sid);
	echo "<head>";
    echo "<title>Blocked Site</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Add Site Name</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<form action=\"cjproc2.php?action=as\" method=\"post\">";  
echo "Name:<br/><input name=\"sname\" maxlength=\"30\"/><br/>";
  echo "<input type=\"submit\" value=\"Add\"/></form>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="addbreg")
  {
$who = getuid_sid($sid);
	echo "<head>";
    echo "<title>Bad Register</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Add Bad Register</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<form action=\"cjproc2.php?action=abr\" method=\"post\">";  
echo "Name:<br/><input name=\"breg\" maxlength=\"30\"/><br/>";
  echo "<input type=\"submit\" value=\"Add\"/></form>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="addbnick")
  {
$who = getuid_sid($sid);
	echo "<head>";
    echo "<title>Bad Nick Name</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Add Bad Nick Name</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<form action=\"cjproc2.php?action=abn\" method=\"post\">";  
echo "Name:<br/><input name=\"bnick\" maxlength=\"30\"/><br/>";
  echo "<input type=\"submit\" value=\"Add\"/></form>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="addfc")
  {
$who = getuid_sid($sid);
	echo "<head>";
    echo "<title>Forum Catagories</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Add Forum Catagories</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<form action=\"cjproc2.php?action=afc\" method=\"post\">";  
echo "Name:<br/><input name=\"fcname\" maxlength=\"30\"/><br/>";
  echo "Position:<input name=\"fcpos\" format=\"*N\" size=\"3\"  maxlength=\"3\"/><br/>";
  $fcats = mysql_query("SELECT id, name FROM ibwff_fcats ORDER BY position, id, name");
  echo "Category: <select name=\"fcid\">";
  while ($fcat=mysql_fetch_array($fcats))
  {
  echo "<option value=\"$fcat[0]\">$fcat[1]</option>";
  }
  echo "</select><br/>";
  echo "<input type=\"submit\" value=\"Add\"/></form>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="addlfc")
{
	echo "<head>";
    echo "<title>Literature Catagories</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Add Literatures Catagories</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<form action=\"cjproc2.php?action=alfc\" method=\"post\">";  
echo "Name:<br/><input name=\"fcname\" maxlength=\"30\"/><br/>";
  echo "Position:<input name=\"fcpos\" format=\"*N\" size=\"3\"  maxlength=\"3\"/><br/>";
  $fcats = mysql_query("SELECT id, name FROM ibwff_letcats ORDER BY position, id, name");
  echo "Category: <select name=\"fcid\">";
  while ($fcat=mysql_fetch_array($fcats))
  {
  echo "<option value=\"$fcat[0]\">$fcat[1]</option>";
  }
  echo "</select><br/>";
  echo "<input type=\"submit\" value=\"Add\"/></form>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
else if($action=="dellfrm")
  {
$who = getuid_sid($sid);
	echo "<head>";
    echo "<title>Delete Literature</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Delete Literature</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
  $forums = mysql_query("SELECT id,name FROM ibwff_letcats ORDER BY position, id, name");
while($a = mysql_fetch_array($forums))
{
echo "&#187; $a[1]<br/><a href=\"cjproc2.php?action=dellfrm&fcd=$a[0]\">Delete</a><br/><br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }

else if($action=="addch")
  {
$who = getuid_sid($sid);
	echo "<head>";
    echo "<title>Chatroom</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Add Chatroom</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<form action=\"cjproc2.php?action=acr\" method=\"post\">";  
echo "Name:<input name=\"bname\" maxlength=\"30\"/><br/>";
  echo "Min Age:<input name=\"chrage\" format=\"*N\" maxlength=\"3\" size=\"3\"/><br/>";
  echo "Max Age:<input name=\"maxage\" format=\"*N\" maxlength=\"3\" size=\"3\"/><br/>";
  echo "Minimum Chat Posts:<input name=\"chrpst\" format=\"*N\" maxlength=\"4\" size=\"4\"/><br/>";
  echo "Permissions:<select name=\"chrprm\">";
  echo "<option value=\"0\">Members Room</option>";
  echo "<option value=\"1\">Staffs Room</option>";
  echo "<option value=\"2\">Premium Room</option>";
  echo "<option value=\"3\">Vip Room</option>";
  echo "</select><br/>";
  echo "Censored:<select name=\"chrcns\">";
  echo "<option value=\"1\">Yes</option>";
  echo "<option value=\"0\">No</option>";
  echo "</select><br/>";
  echo "Fun:<select name=\"chrfun\">";
  echo "<option value=\"0\">No</option>";
  echo "<option value=\"1\">Esrever</option>";
  echo "<option value=\"2\">Ravebabe</option>";
  echo "</select><br/>";
  echo "<input type=\"submit\" value=\"Add\"/></form>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="delfrm")
  {
$who = $_GET["who"];
	echo "<head>";
    echo "<title>Delete Forum</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Delete Forum</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
  $forums = mysql_query("SELECT id,name FROM ibwff_fcats ORDER BY position, id, name");
while($a = mysql_fetch_array($forums))
{
echo "&#187; $a[1]<br/><a href=\"cjproc2.php?action=delfrm&fcd=$a[0]\">Delete</a><br/><br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="delfc")
  {
	echo "<head>";
    echo "<title>Delete Forum Catagory</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Delete Forum Catagory</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
  $forums = mysql_query("SELECT id,name FROM ibwff_forums ORDER BY position");
while($a = mysql_fetch_array($forums))
{
echo "&#187; $a[1]<br/><a href=\"cjproc2.php?action=delfc&fcd=$a[0]\">Delete</a><br/><br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
else if($action=="dellfc")
  {
$who = $_GET["who"];
	echo "<head>";
    echo "<title>Delete Literature Catagory</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Delete Literature Catagory</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
  $forums = mysql_query("SELECT id,name FROM ibwff_literatures ORDER BY position, id, name");
while($a = mysql_fetch_array($forums))
{
echo "&#187; $a[1]<br/><a href=\"cjproc2.php?action=dellfc&fd=$a[0]\">Delete</a><br/><br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
else if($action=="viewbnick")
  {
$who = $_GET["who"];
	echo "<head>";
    echo "<title>View Bad Nick</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>View Bad Nick</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
      $res = mysql_query("SELECT * FROM ibwff_nickblock88");
while ($row = mysql_fetch_array($res)) 
{
   echo $row[1];
   echo "<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
else if($action=="viewsite")
  {
$who = $_GET["who"];
	echo "<head>";
    echo "<title>Blocked Site</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>View Blocked Site</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
      $res = mysql_query("SELECT * FROM ibwff_blockedsite");
while ($row = mysql_fetch_array($res)) 
{
   echo $row[1];
   echo "<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
else if($action=="viewbreg")
  {
$who = $_GET["who"];
	echo "<head>";
    echo "<title>View Bad Register</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>View Bad Register</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
      $res = mysql_query("SELECT * FROM ibwff_regblock65");
while ($row = mysql_fetch_array($res)) 
{
   echo $row[1];
   echo "<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
else if($action=="viewch")
  {
$who = $_GET["who"];
	echo "<head>";
    echo "<title>View Chatrooms</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>View Chatrooms</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
      $res = mysql_query("SELECT name, id FROM ibwff_rooms ORDER BY id ASC");
while ($row = mysql_fetch_array($res)) 
{
   echo "&#187; $row[0]<br/><a href=\"cjproc2.php?action=dch&id=$row[1]\">Delete</a><br/>";
   echo "<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}