<?php
session_start();
include("config.php");
include("core.php");  connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo '<head>';
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"title\" content=\"Firebd.net\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From CJ UDAY: Don't Try To Hack OR else :P\">
<meta name=\"keywords\" content=\"Site Desined By CJ UDAY :) :)\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/></head>";
echo "<body>";
$action = $_GET["action"]; $sid = $_SESSION["sid"];
$page = $_GET["page"];
$who = $_GET["who"];
$uid = getuid_sid($sid);
$name = $_GET["name"];
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();
////////////////Ip Banned By CJ UDAY :)	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
    echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
	echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
      echo "<br/>";
      echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
      $banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
      $remain =  $banto[0] - time();
      $rmsg = gettimemsg($remain);
      echo "<b>Time Remaining: $rmsg</b><br/>";
      $nick = getnick_uid($banto[2]);
       $text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
      echo "</p>";
    	echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
    echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
    echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
//////////////////Banned System Updated By CJ UDAY :)
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please With Contact Us <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
 echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
///////////////////Validation By CJ UDAY :)
					if(isvalidated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
	echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  You Are Not Validated!<br/>We are checking your ip and browser<br/>
	  This could take up to 15 munites pls be patient and try again soon<br/>Please try again later...<br/><b>Thank You</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
///////////////////Deactivated Account By CJ UDAY :)
          if(isdeactivated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  <b>Your Account Has Been Deactivated Forever.<br/>And It Will Be Never Activate!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
if($action=="")
{
addonline(getuid_sid($sid),"Subscribe To Lotto","glotto.php?action=$action");
echo "<head>";
echo "<title>Subscribe To Golden Lotto</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<b>Golden Lotto</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
echo "<u><b> Golden Lotto Service</b></u><br/>";
echo "List of the features that you may win after subscribing to the service!<br/><br/>
(*) Common featurs for all subscribers: Points Booster.<br/>
(*) Points booster will boost your bonus points that you are getting by staying online for half an hour.<br/>
(*) At this moment, you are getting 5 points per half an hour but Points Booster offers you 15 Points per half an hour!<br/>
(*) The most exciting part of Golden Lotto is the magic box! You may win<b> 2 days Premium Membership or 10TK Account Balance or 100 Points or 300 game points </b>by opening the Magic Box!<br/>
(*) If you are already subscribed to one of our premium packages, 2 days will be added to your account as bonus if the magic box comes with a 2 days premium membership for you.<br/>
(*) How to subscribe to Golden Lotto Service? Simply choose any of the packages below.....<br/></p>";
echo "<p align=\"center\">";
echo "<u>Select Package</u><br/>";
echo "<b>Package 1</b><br/>";
echo "<b>15</b> Golden Coins = <b>7</b> Days Subscription<br/>";
echo "<b>Package 2</b><br/>";
echo "<b>30</b> Golden Coins = <b>15</b> Days Subscription";
echo "<br/><b>Package 3</b><br/>";
echo "<b>50</b> Golden Coins = <b>30</b> Days Subscription<br/>";
echo "<center><form action=\"glotto.php?action=upgrade\" method=\"post\">
<select name=\"pkg\">
<option value=\"7\">Package 1</option>";
echo "<option value=\"15\">Package 2</option>";
echo "<option value=\"30\">Package 3</option>
</select><br/>
<input type=\"submit\" value=\"Subscribe\"/>
</form>";
echo "</p>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="upgrade")
{
addonline(getuid_sid($sid),"Upgrading To Lotto","");
echo "<head>";
echo "<title>Subscribe To Golden Lotto</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<b>Golden Lotto</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
$pkg = $_POST["pkg"];
if($pkg=='7')
{
}else if($pkg=='15'){
}else if($pkg=='30'){
}else{
echo "<img src=\"../images/notok.gif\" alt=\"X\"/> Unknown Packege!<br/>";
}
$epp = mysql_fetch_array(mysql_query("SELECT coins FROM ibwff_users WHERE id='".$uid."'"));
if(($epp[0]<5) || ($pkg==7 && $epp[0]<5) || ($pkg==15 && $epp[0]<30) || ($pkg==35 && $epp[0]<55))
{
echo "<img src=\"../images/notok.gif\" alt=\"X\"/> You don't have Enough Golden Coins for subscribing in this package.<br/><br/>";
}
$timeto = $pkg*24*60*60;
$vtime = $timeto + time();
if($pkg=='7')
{
$mins = $epp[0] - 5;
}else if($pkg=='15'){
$mins = $epp[0] - 30;
}else if($pkg=='30'){
$mins = $epp[0] - 50;
}
$res = mysql_query("UPDATE ibwff_users SET lottotime='".$vtime."' WHERE id='".$uid."'");
if($res)
{
mysql_query("UPDATE ibwff_users SET lotto='1' WHERE id='".$uid."'");
mysql_query("UPDATE ibwff_users SET coins='".$mins."' WHERE id='".$uid."'");
$tm = time();
mysql_query("INSERT INTO ibwff_notification SET text='[b]Special Information:[/b][br/]You are now Golden Lotto User.', byuid='3', touid='".$uid."', timesent='".$tm."'");
$timeto = $pkg*24*60*60;
$vtime = $timeto + time();
mysql_query("INSERT INTO ibwff_notification SET text='[b]Limit Expiration Notice:[/b][br/] [br/][br/]After expiration of your Golden Lotto Package Period, You will be substracted from our Lotto subscribers list. [br/]Collect Golden Coins to renew your Package limit.[br/][br/] [b]Thank you[/b].', byuid='3', touid='".$uid."', timesent='".$vtime."'");
echo "<img src=\"ok.gif\" alt=\"O\"/> Successfully Subscribed to Golden Lotto serviece!";
echo "<br/><br/><b>Magic Box</b> has just Opened!<br/><br/>";
$magicbox = rand(1, 4);
if ($magicbox=="1")
{
$opl = mysql_fetch_array(mysql_query("SELECT rp FROM ibwff_users WHERE id='".$uid."'"));
$pval = 10;
$npl = $opl[0] + $pval;
mysql_query("UPDATE ibwff_users SET rp='".$npl."' WHERE id='".$uid."'");
echo "<b>Congratulations!</b><br/><br/>";
echo "You have got <b>10 Tk Account Balance</b>. Thanks for using this lotto serviece.<br/><br/>";
}else if($magicbox=="2")
{
$opl = mysql_fetch_array(mysql_query("SELECT plusses FROM ibwff_users WHERE id='".$uid."'"));
$pval = 100;
$npl = $opl[0] + $pval;
mysql_query("UPDATE ibwff_users SET plusses='".$npl."' WHERE id='".$uid."'");
echo "<b>Congratulations!</b><br/><br/>";
echo "You have got <b>100 Points</b> after opening the <b>Magic Lotto Box</b>.<br/> Thanks for using this lotto serviece.<br/><br/>";
}else if($magicbox=="3")
{
$opl = mysql_fetch_array(mysql_query("SELECT gplus FROM ibwff_users WHERE id='".$uid."'"));
$pval = 300;
$npl = $opl[0] + $pval;
mysql_query("UPDATE ibwff_users SET gplus='".$npl."' WHERE id='".$uid."'");
echo "<b>Congratulations!</b><br/><br/>";
echo "You have won <b>300 Game Points</b> after opening the <b>Magic Lotto Box</b>.<br/> Thanks for using this lotto serviece.<br/><br/>";
}else if($magicbox=="4")
{
if(ispu($uid) || spu($uid))
{
$opl = mysql_fetch_array(mysql_query("SELECT ptime FROM ibwff_users WHERE id='".$uid."'"));
$pval = 2*24*60*60;
$npl = $opl[0] + $pval;
$vtime = $npl + time();
mysql_query("UPDATE ibwf_users SET ptime='".$npl."' WHERE id='".$uid."'");
}else{
mysql_query("UPDATE ibwf_users SET pu='1' WHERE id='".$uid."'");
$timeto = 2*24*60*60;
$vtime = $timeto + time();
mysql_query("UPDATE ibwff_users SET ptime='".$vtime."' WHERE id='".$uid."'");
}
echo "<b>Congratulations!</b><br/><br/>";
echo "You have won <b>2 days Premium Membership</b> Package.<br/> Thanks for using this service.<br/><br/>";
}
}else{
echo "<img src=\"../images/notok.gif\" alt=\"X\"/> Subscription not complate. Please try again";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
exit();
}
?>
</html>