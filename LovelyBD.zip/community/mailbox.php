<?php
session_start();
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-cache, must-revalidate");
header("Pragma: no-cache");
echo "<?xml version=\"1.0\"?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\" \"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
 
?>
<html xmlns="http://www.w3.org/1999/xhtml">
 
<?php
include("config.php");
include("core2.php");
$bcon = connectdb();
if (!$bcon)
{
 
    echo "<head><title>Error!!</title></head>";
    echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"email.css\" />";
    echo "<body>";
    echo "<div class=\"status\">";
     echo "<p align=\"center\">";echo mobads();
    echo "<img src=\"../avatars/exit.gif\" alt=\"!\"/><br/>";
    echo "<b>Error! Cannot Connect To Database...</b><br/><br/>";
    echo "This error happens usually when backing up the database, please be patient...";
    echo "</p>";
    echo "</div>";
    echo "</body>";
    echo "</html>";
    exit();
}
$browser = mysql_real_escape_string($_SERVER['HTTP_USER_AGENT']);
$ubr = mysql_real_escape_string(strip_tags($browser));
$uip = getip();
$action = mysql_real_escape_string($_GET["action"]);
$sid = mysql_real_escape_string($_GET["sid"]);
$uid = getuid_sid($sid);
cleardata();
$sitename = mysql_fetch_array(mysql_query("SELECT value FROM ibwf_settings WHERE name='sitename'"));
$sitename = $sitename[0];
 
if(islogged($sid)==false)
{
    echo "<head><title>Error!!</title></head>";
    echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"email.css\" />";
    echo "<body>";
    echo "<div class=\"status\">";
      echo "<p align=\"center\">";
      echo "You are not logged in<br/>";
      echo "Or Your session has been expired<br/><br/>";
      echo "<a href=\"index.php\">Login</a>";
      echo "</p></div>";
      echo "</body>";
      echo "</html>";
      exit();
}
 
if(isbanned($uid))
    {
          echo "<head><title>Error!!</title></head>";
    echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"email.css\" />";
    echo "<body>";
    echo "<div class=\"status\">";
      echo "<p align=\"center\">";
      echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/><br/>";
      echo "<b>You are Banned</b><br/><br/>";
      $banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwf_penalties WHERE id='".$uid."' AND penalty='1' OR id='".$uid."' AND penalty='2'"));
    $banres = mysql_fetch_array(mysql_query("SELECT lstp3npp3sn FROM ibwf_users WHERE id='".$uid."'"));
      $remain = $banto[0]- time();
      $rmsg = gettimemsg($remain);
      echo "<b>Time Left: </b>$rmsg<br/>";
      $nick = getnick_id($banto[2]);
    echo "<b>By: </b>$nick<br/>";
    echo "<b>Reason: </b>$banto[1]";
      echo "</p></div>";
      echo "</body>";
      echo "</html>";
      exit();
    }
 
    /* {{{{{{{{{{{{<<<>>>}}}}}}}}}}}}
     
    This Script Writen By MiTuL for lavalair
    Do not Use Your Name As Script Writer.. ;)
     
    Lol, if you done this, You are fuc*ing Script kidde
    and a cheater!!!!!! :P
     
    Find Script Writer @ Facebook http://facebook.com/shahalammitul
     
    */
     
$blah = mysql_fetch_array(mysql_query("SELECT usermail FROM ibwf_users WHERE id='".$uid."'"));
if($blah[0]==0)
{
$uid = mysql_fetch_array(mysql_query("SELECT name FROM ibwf_users WHERE id='".$uid."'"));
$emailid = strtolower($uid[0]);
$cpuser = 'meghwap'; // cPanel username
$cppass = '$$$m3Gh$$$'; // cPanel password
$cpdomain = 'firebd.net'; // cPanel domain or IP
$cpskin = 'x3';
$epass = 'meghwap45'; // email password
$edomain = 'admin@firebd.net'; // email domain (usually same as cPanel domain above)
$equota = 20; // amount of space in megabytes
  
  
 $f = fopen ("http://$cpuser:$cppass@$cpdomain:2082/frontend/$cpskin/mail/doaddpop.html?email=$emailid&domain=$edomain&password=$epass&quota=$equota", "r");
 
$res = mysql_query("UPDATE ibwf_users SET usermail='1' WHERE id='".$uid."'");
 
    if (!$f) {
      $msg = 'System Cannot be proceed at this moment. Please contact with Administrator';
    echo "$msg<br/>";
             }
 
    }
 
ini_set("max_execution_time",360);
 
 $uid = mysql_fetch_array(mysql_query("SELECT name FROM ibwf_users WHERE id='".$uid."'"));
 $ltrdown = strtolower($uid[0]);
 
/* connect to server */
$hostname = '{localhost:143/imap/notls}INBOX';
$username = "$ltrdown@$cpdomain";
$password = 'meghwap45';
 
/* try to connect */
$inbox = imap_open($hostname,$username,$password);
 
if (!$inbox)
{
      echo "<head><title>$sitename E-Mail Service</title></head>";
    echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"email.css\" />";
    echo "<body>";
    echo "<div class=\"status\">";
  echo "<p align=\"center\">";
    echo "<img src=\"../avatars/exit.gif\" alt=\"!\"/><br/>";
    echo "<b>Error! Cannot Connect To Mail Server</b><br/><br/>";
    echo "<a href=\"home.php?action=main&amp;sid=$sid\"><img src=\"../avatars/home.gif\" alt=\"*\"/>";
    echo "Home</a>";
    echo "</p></div>";
  echo "</body>";
  echo "</html>";
  exit();
}
 
/* grab emails */
$emails = imap_search($inbox,'ALL');
 
/* if emails are returned, cycle through eachâ€¦ */
//if($emails) {
 
/* put the newest emails on top */
rsort($emails);
 
$action = $_GET['action'];
 
if($action=="main"){
 
  addonline(getuid_sid($sid),"E-mail index","");
       echo "<head><title>$sitename E-Mail Service</title></head>";
    echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"email.css\" />";
    echo "<body>";
    echo "<div class=\"status\">";
  echo "<p align=\"center\">";
  echo "<b>Welcome To $sitename Email Service By <b></b>!</b><br/><br/>";
 
 
  echo "Your Email Address is: <b>$ltrdown@firebd.net</b>";
  echo "</p><br/>";
 
    echo "<p align=\"left\">";
function CountUnreadMail($host, $login, $passwd) {
    $mbox = imap_open($host, $login, $passwd);
    $count = 0;
    if (!$mbox) {
        echo "Error";
    } else {
        $headers = imap_headers($mbox);
        foreach ($headers as $mail) {
            $flags = substr($mail, 0, 4);
            $isunr = (strpos($flags, "U") !== false);
            if ($isunr)
            $count++;
        }
    }
 
    imap_close($mbox);
    return $count;
}
 
$count = CountUnreadMail($hostname,$username,$password);
echo "<b>&#8226;</b> <a href='sentmail.php?action=main&amp;sid=$sid'>Compose Email</a><br/>";
echo "<b>&#8226;</b> <a href='mailbox.php?action=inbox&amp;sid=$sid'>Unread Emails</a> [$count]<br/>";
$totaleml = imap_num_msg($inbox);
echo "<b>&#8226;</b> <a href='mailbox.php?action=inbox&amp;sid=$sid'>All Email</a> [$totaleml]";
echo "</p>";
 
echo "<br/><p align=\"center\">";
echo "Script By : <a href=\"http://facebook.com/l33tbd\">Kafi</a><br/><br/>";
echo "<a href=\"home.php?action=main&amp;sid=$sid\"><img src=\"../avatars/home.gif\" alt=\"*\"/>";
echo "Home</a>";
  echo "</p></div>";
  echo "</body>";
  echo "</html>";
  exit();
 
}else if($action=="inbox"){
 
  addonline(getuid_sid($sid),"Email inbox","");
     echo "<head><title>$sitename E-Mail Service</title></head>";
    echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"email.css\" />";
    echo "<body>";
    echo "<div class=\"status\">";
  echo "<p align=\"center\">";
  echo "<b>My E-Mail INBOX</b><br/><br/>";
  echo "</p>";
   
/* for every emailâ€¦ */
foreach($emails as $email_number) {
 
$overview = imap_fetch_overview($inbox,$email_number,0);
 
if($overview[0]->seen==0){
$sid = mysql_real_escape_string($_GET["sid"]);
$output.= $overview[0]->seen ? '<b>Old</b>' : '<b>New!</b>';
$output.= '<br/><b>&#187; From: '.$overview[0]->from.'<br/>';
$output.= "&#187; Subject: <a href=\"mailbox.php?action=read&amp;id=".$overview[0]->uid."&amp;sid=$sid\">".$overview[0]->subject."</a></b><br/>-------<br/>";
}else{
$output.= $overview[0]->seen ? 'Old' : 'New';
 
  $frm = addslashes(strip_tags($overview[0]->from));
 
$output.= '<br/>&#187; From: '.$frm.'<br/>';
 
  $subjct = addslashes(strip_tags($overview[0]->subject));
 
$output.= "&#187; Subject: <a href=\"mailbox.php?action=read&amp;id=".$overview[0]->uid."&amp;sid=$sid\">".$subjct."</a><br/>--------<br/>";
}
 
}
 
echo "<p align=\"left\">";
echo $output;
  echo "</p><br/>";
 
  echo "<p align=\"center\">";
echo "<a href=\"home.php?action=main&amp;sid=$sid\"><img src=\"../avatars/home.gif\" alt=\"*\"/>";
echo "Home</a>";
echo '</p></div>';
echo '</body>';
echo '</html>';
exit();
}
else if($action=="unread"){
 
foreach($emails as $email_number) {
 
$overview = imap_fetch_overview($inbox,$email_number,0);
 
if($overview[0]->seen==0){
$output.= $overview[0]->seen ? '<b>Old</b>' : '<b>New!</b>';
 
  $frm = addslashes(strip_tags($overview[0]->from));
 
$output.= '<br/><b>&#187; From: '.$frm.'<br/>';
 
  $subjct = addslashes(strip_tags($overview[0]->subject));
 
$output.= '&#187; Subject: <a href="mailbox.php?action=read&amp;sid="'.$sid.'"&amp;id='.$overview[0]->uid.'">'.$subjct.'</a></b><br/>-------<br/>';
}
     echo "<head><title>$sitename E-Mail Service</title></head>";
    echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"email.css\" />";
    echo "<body>";
    echo "<div class=\"status\">";
  echo "<p align=\"left\">";
echo $output;
  echo "</p></div>";
  echo "</body>";
  echo "</html>";
  exit();
}
}else if($action=="replymail")
{
$to = mysql_real_escape_string($_POST["to"]);
$subject = mysql_real_escape_string($_POST["subject"]);
$message = mysql_real_escape_string($_POST["message"]);
$captcha = mysql_real_escape_string($_POST["captcha"]);
if($captcha!=$_SESSION["captcha_code"])
{
    echo "<b>Wrong Captcha Code!</b>";
    echo "<br/><br/><a href=\"index.php?action=main&amp;sid=$sid\"><img src=\"../avatars/home.gif\" alt=\"\"/>Home</a>";
echo "</center>";
echo "</body>";
echo "</html>";
exit();
}
$uid = mysql_fetch_array(mysql_query("SELECT name FROM ibwf_users WHERE id='".$uid."'"));
$emailid = strtolower($uid[0]);
$domain = ''; //DOmain
$headers = "From: $emailid@$domain\r\nReply-To: $emailid@$domain";
 
$mail_sent = @mail( $to, $subject, $message, $headers );
 
echo $mail_sent ? "Mail sent to <b>$to</b>" : "Mail sent failed";
echo "<br/><br/><a href=\"index.php?action=main&amp;sid=$sid\"><img src=\"../avatars/home.gif\" alt=\"\"/>Home</a>";
echo "</center>";
echo "</body>";
  echo "</html>";
  exit();
}
//////////////////
else if($action=="read"){
 
  addonline(getuid_sid($sid),"Reading emails","");
      echo "<head><title>$sitename E-Mail Service</title></head>";
    echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"email.css\" />";
    echo "<body>";
function Captcha(){
$addOne = rand(1,50);
$addTwo = rand(1,50);
$answer = $addOne+$addTwo;
$Question = "$addOne + $addTwo= ??";
$_SESSION['captcha_code'] = $answer;
$_SESSION['captchaAlt'] = $Question;
return true;
}
 
    echo "<div class=\"status\">";
  echo "<p align=\"center\">";
  echo "My Email Inbox<br/><br/></p>";
 
$uid = addslashes(strip_tags($_GET['id'])); //I won't validate this input, but you should
$overview = imap_fetch_overview($inbox, $uid, FT_UID);
$body = imap_body($inbox, $uid, FT_UID);
echo "<p align=\"left\">";
 
 
  $frm = addslashes(strip_tags($overview[0]->from));
 
  echo "From: <b>".$frm."</b><br/>";
 
 
 
  $ddt = addslashes(strip_tags($overview[0]->date));
 
  echo "Date: <b>".$ddt."</b><br/>";
  
 
 
  $subjct = addslashes(strip_tags($overview[0]->subject));
 
  echo "Subject: <b>".$subjct."</b>";
 
 
 
  echo "<br/><b><u>Massege:</u></b><br/><br/>";
   
  echo addslashes(strip_tags($body));
 
  echo "</p>";
   
  echo "<br/><hr/>";
   
  echo "<form action=\"mailbox.php?action=replymail&amp;sid=$sid\" method=\"post\">";
 
  echo "Reply To: <input name=\"to\" maxlength=\"50\" value=\"$frm\"/><br/>";
echo "Mail Subject: <input name=\"subject\" maxlength=\"50\" value=\"Re: $subjct\"/><br/>";
   
  echo "Mail Text: <textarea cols=\"13\" rows=\"2\" name=\"message\" maxlength=\"5000\"/></textarea><br/>";
   
  Captcha();
echo "Captcha Question: ".$_SESSION["captchaAlt"]."<br/><input name=\"captcha\" style=\"-wap-input-format: '*N'\" size=\"6\" maxlength=\"4\"/><br/>";
   
  echo "<input type=\"Submit\" name=\"mail\" Value=\"Reply\"></form><br/><br/>";
   
echo "<br/><p align=\"center\">";
echo "<a href=\"home.php?action=main&amp;sid=$sid\"><img src=\"../avatars/home.gif\" alt=\"*\"/>";
echo "Home</a>";
  echo "</p></div>";
  echo "</body>";
  echo "</html>";
  exit();
 
}
/* close the connection */
imap_close($inbox);
 
?>
 
</html>
 