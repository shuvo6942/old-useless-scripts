<?php
session_start();
include("config.php");
include("core.php");  
connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo '<head>'; 
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"title\" content=\"MyDhaka.Tk\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From MyDhaka: Don't Try To Hack OR else :P\">
<meta name=\"keywords\" content=\"Site Desined By MyDhaka :) :)\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/></head>";
echo "<body>";
$action = $_GET["action"]; 
$sid = $_SESSION["sid"];
$page = $_GET["page"];
$who = $_GET["who"];
$uid = getuid_sid($sid);
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();
////////////////Ip Banned By CJ UDAY :)	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
    echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
      echo "<br/>";
      echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
      $banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
      $remain =  $banto[0] - time();
      $rmsg = gettimemsg($remain);
      echo "<b>Time Remaining: $rmsg</b><br/>";
      $nick = getnick_uid($banto[2]);
       $text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
      echo "</p>";
    	echo "<form action=\"login.php\" method=\"get\"><p align=\"center\">";
    echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
    echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"center\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
$uid = getuid_sid($sid);
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time center: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please With Contact Us <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"center\"><a href=\"".$_SERVER['HTTP_REFFERER']."\">Back</a><br/><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"center\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "<p align=\"center\"><a href=\"".$_SERVER['HTTP_REFFERER']."\">Back</a><br/><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"center\"><a href=\"".$_SERVER['HTTP_REFFERER']."\">Back</a><br/><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
  include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
///////////////////Deactivated Account By CJ UDAY :)
          if(isdeactivated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  <b>Your Account Has Been Deactivated Forever.<br/>And It Will Be Never Activate!</b><br/><br/>";
echo "</div>";
echo "<p align=\"center\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
///////////////////Validation By CJ UDAY :)
					if(isvalidated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  You Are Not Validated!<br/>We are checking your ip and browser<br/>
	  This could take up to 15 munites pls be patient and try again soon<br/>Please try again later...<br/><b>Thank You</b><br/><br/>";
echo "</div>";
echo "<p align=\"center\"><a href=\"".$_SERVER['HTTP_REFFERER']."\">Back</a><br/><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
/////////////////////////////////Profile Updataed By CJ UDAY :)
if($action=="")
{
if((isignored($uid, $who)) || (isignored($who, $uid)))
{
$whnick = subnick(getnick_uid($uid));
    echo "<head>";
    echo "<title>$whnick@Viewing $whonick Basic Profile</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
						echo "<div class=\"header\" align=\"center\">";
echo "<b>$whnick</b><br/>";
		if($uid == $who)
        {
		echo "<small><a href=\"nickshop.php\"><font color=\"white\">[Change Display Name]</font></a></small><br/>";
		}
		echo "(".getstatus($who).")<br/>";
		echo "".getranking($who)."<br/>";
		echo "".gettitle($who)."<br/>";
		echo "</div>";
echo "<div class=\"penada\" align=\"center\">";
include("pm_by.php");
echo "<p align=\"center\">";
if(isignored($who, $uid))
{
$whnick = subnick(getnick_uid($uid));
}else if(isignored($uid, $who))
{
$whnick = subnick(getnick_uid($who));
}
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"><b>$whnick</b> has ignored you & you cannot see <b>$whnick's</b> profile!<br/>";
$ires = ignoreres($uid, $who);
if(isignored($who, $uid))
{
echo "<br/>&#187; <a href=\"ignore.php?action=del&amp;who=$who\">Remove from Ignore List</a><br/>";
}
echo "</p>";
echo "</div>";
echo "<p align=\"center\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
exit();
}
if($uid == $who)
        {
addonline(getuid_sid($sid),"Viewing My Basic Profile","profile.php?who=$who");
}else
{
addonline(getuid_sid($sid),"Viewing $whnick Basic Profile","profile.php?who=$who");
}

    echo "<head>";
			if($uid == $who)
        {
$whnick = subnick(getnick_uid($uid));
    echo "<title>$whnick@My Profile</title>";
	}else{
$whnick = subnick(getnick_uid($uid));
$whonick = subnick(getnick_uid($who));
	echo "<title>$whnick@$whonick Profile</title>";
	}
    echo "</head>";
    echo "<body>";
echo "<div class=\"\"align=\"center\">";
    //echo "<div class=\"header\"> <img src=\"FireBD.png\" alt=\"[$sitename]\" width=\"280\" height=\"55\"/><br/>";
						$infd = mysql_fetch_array(mysql_query("SELECT hiranick FROM ibwff_users WHERE id='".$who."'"));
		echo "<b>$infd[0]</b><br/>";
		if($uid == $who)
{
		echo "<small><a href=\"nickshop.php\"><font color=\"white\">[Change Display Name]</font></a></small><br/>";
		}
		$text = parsepm(getstatus($who), $sid);
		echo "($text)<br/>";
echo "".getranking($who)."<br/>";
if(getplusses($who)>".knightpoint().")
{
echo "".gettitle($who)."";
}
else
{
echo "";
}
		echo "</div>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
						
////////////////////////////security System Updated By CJ UDAY :)			
$inf1 = mysql_fetch_array(mysql_query("SELECT prof FROM ibwff_users WHERE id='".$who."'"));
			echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
$whonick = getnick_uid($who);
echo "<div class=\"\" align=\"right\">";
////////Cover Picture By CJ UDAY :)
$coverpiclnk = getcoverpic($who);
$cf = $coverpiclnk;
$id = mysql_fetch_array(mysql_query("SELECT id FROM ibwff_gallery WHERE itemurl='".$cf."'"));
if($coverpiclnk=="")
{
if($uid == $who)
{echo "[<a href=\"coverpic.php\">Upload Your Cover Picture</a>]<br/><br/>";}
}else{
    if($inf1[0]=='1')
    {
 if(($who==$uid)||(arebuds($uid, $who))||(ispu(getuid_sid($sid)))||(ismod(getuid_sid($sid)))||(isowner(getuid_sid($sid))))
    {
$id = mysql_fetch_array(mysql_query("SELECT id FROM ibwff_gallery WHERE itemurl='".$cf."'"));
echo "<a href=\"coverphoto.php?id=$id[0]\"><img src=\"$coverpiclnk\" alt=\"$coverpiclnk\" type=\"cover\" width=\"100%\" height=\"150\"/></a><br/>";
}else{
 echo "";
}
}else{
$id = mysql_fetch_array(mysql_query("SELECT id FROM ibwff_gallery WHERE itemurl='".$cf."'"));
echo "<a href=\"coverphoto.php?id=$id[0]\"><img src=\"$coverpiclnk\" alt=\"$coverpiclnk\" type=\"cover\" width=\"100%\" height=\"150\"/></a><br/>";
}
if($uid == $who)
{
echo "[<a href=\"coverpic.php\">Upload Your Cover Picture</a>]<br/><br/>";}
}
$item = mysql_fetch_array(mysql_query("SELECT profilemsg FROM ibwff_users WHERE id='".$who."'"));
$unick = getnick_uid($who);
$text = parsepm($item[0], $sid);
    if($inf1[0]=='1')
    {
 if(($who==$uid)||(arebuds($uid, $who))||(ispu(getuid_sid($sid)))||(ismod(getuid_sid($sid)))||(isowner(getuid_sid($sid))))
    {
echo "$text";
}else{
echo "";
}
}else{
echo "$text-<b>$unick</b><br/>";
}
if($whonick!="")
{
if($uid == $who)
{
echo "[<a href=\"setting.php?action=upfmsg\">Update Profile Message</a>]";
}
echo "</div>";
    if($inf1[0]=='1')
    {
 if(($who==$uid)||(arebuds($uid, $who))||(ispu(getuid_sid($sid)))||(ismod(getuid_sid($sid)))||(isowner(getuid_sid($sid))))
    {
}else{
	    $sql = "SELECT name FROM ibwff_users WHERE id=$who";
	    $sql2 = mysql_query($sql);
	    $item = mysql_fetch_array($sql2);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item[0]'"));
if($sex[0]=="M"){$usex = "him";}
if($sex[0]=="F"){$usex = "her";}
if($sex[0]==""){$usex = "";}
	    $sql2 = "SELECT name FROM ibwff_users WHERE id=$who";
	    $sql22 = mysql_query($sql2);
	    $item2 = mysql_fetch_array($sql22);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item2[0]'"));
if($sex[0]=="M"){$usex2 = "his";}
if($sex[0]=="F"){$usex2 = "her";}
if($sex[0]==""){$usex2 = "";}
echo "<b>[It's a security profile]</b><br/>";
echo "<b>[Only friends can access $usex2 profile]</b><br/>";
echo "<b>[You cannot see $usex2 profile untill you become a friend of $usex]</b>";
}
}
}
}else{
echo "<div class=\"div\" align=\"center\">";
echo "<b>Basic</b> |<a href=\"proadv.php?who=$who\">Advanced</a> | ";
echo "<a href=\"prohis.php?who=$who\">History</a> | ";
echo "<a href=\"proact.php?who=$who\">Activity</a> | ";
echo "<a href=\"prostat.php?who=$who\">Statistics</a> ";
echo "</div>";
}
if($uid == $who)
{
if($inf1[0]=='1')
{
 if(($who==$uid)||(arebuds($uid, $who))||(ispu(getuid_sid($sid)))||(ismod(getuid_sid($sid)))||(isowner(getuid_sid($sid))))
    {
echo "<div class=\"div\" align=\"center\">";
echo "<b>Basic</b> |<a href=\"proadv.php?who=$who\">Advanced</a> | ";
echo "<a href=\"prohis.php?who=$who\">History</a> | ";
echo "<a href=\"proact.php?who=$who\">Activity</a> | ";
echo "<a href=\"prostat.php?who=$who\">Statistics</a> ";
echo "</div>";
}else{
echo "";
}
}
echo "<div class=\"\" align=\"center\">";
echo "[<a href=\"setting.php?action=setting\">Update Your Profile</a>]<br/><br/>";
echo "[<b><a href=\"privacy.php\">Change Your privacy</a></b>]<br/>";
}
   if($inf1[0]=='1')
    {
	echo "<b>[It's a privacy profile]</b><br/>";
    }
if(ismod($uid))
{
echo "<div class=\"shout\" align=\"center\">";if($who==3)
{
echo "";
}else{
if(!isowner($uid))
{
if($uid!=$who)
{
echo "<a href=\"modcp.php?action=user&who=$who\"><font color=\"green\"><b>Staff Tools</b></a></font><hr>";
}else{
echo "";
}
}else{
echo "<a href=\"modcp.php?action=user&who=$who\"><font color=\"green\"><b>Staff Tools</b></a></font><hr>";
}
}
}
//////// *** Super Tools By CJ UDAY *** /////
///////////////////////////////////////Access By CJ UDAY :)
if(hirasuperboss(getuid_sid($sid)))
{
echo "<a href=\"powercp.php?action=user&who=$who\"><font color=\"green\"><b>System Tools</b></a></font>";
echo "</div>";
}

$whonick = getnick_uid($who);
$rate = mysql_fetch_array(mysql_query("SELECT warning FROM ibwff_users WHERE id='".$who."'"));
//echo "Warning Level: $rate[0]%<br/>";
  if($inf1[0]=='1')
    {
 if(($who==$uid)||(arebuds($uid, $who))||(ispu(getuid_sid($sid)))||(ismod(getuid_sid($sid)))||(isowner(getuid_sid($sid))))
    {
echo "<div class=\"div\" align=\"center\"><b>Basic Profile Of $whonick</b></div>";
$e = mysql_fetch_array(mysql_query("SELECT fn, ms, rg, lin, ht, sat, wat FROM ibwff_users WHERE id=$who"));
if($e[0]!="")
{
echo "<div class=\"mblock2\" align=\"right\">";
echo "<b><font color=\"purple\">$e[0]</font></b> Lives in <img src=\"home.gif\"><font color=\"purple\">$e[3]</font><br/>From <img src=\"hometown.png\"><font color=\"purple\">$e[4]</font><br/><img src=\"religion.png\"><font color=\"purple\">$e[1]</font> <img src=\"marriage.gif\"><font color=\"purple\">$e[2]</font><br/><img src=\"study.png\"><font color=\"purple\">$e[5]</font> <img src=\"work.png\"><font color=\"purple\">$e[6]</font></div>";
}
if($uid == $who)
{
echo "<a href=\"advance.php?who=$who\">[Update Basic Info Here]</a><br/>";
}
echo "</div>";
echo "<p align=\"center\">";
////////Profile Pics By CJ UDAY :)
$avlink = getavatar($who);
$xf = $avlink;
$id = mysql_fetch_array(mysql_query("SELECT id FROM ibwff_gallery WHERE itemurl='".$xf."'"));
if($avlink=="")
{
echo "<img src=\"../avatars/nopic.jpg\" type=\"picture\" alt=\"Nopic\"/>";
}else{
echo "<a href=\"profilepic.php?id=$id[0]\"><img src=\"$xf\" alt=\"$avlink\" type=\"avatar\" width=\"120\" height=\"135\"/></a>";
}
}else{
 echo "";
}
}else{
echo "<div class=\"div\" align=\"center\"><b>Basic Profile Of $whonick</b></div>";
$e = mysql_fetch_array(mysql_query("SELECT fn, mst, rg, lin, ht, sat, wat FROM ibwff_users WHERE id='".$who."'"));
if($e[0]!="")
{
echo "<div class=\"mblock2\" align=\"right\">";
echo "<b><font color=\"purple\">$e[0]</font></b> Lives in <img src=\"../avatars/home.gif\"><font color=\"purple\">$e[3]</font><br/>From <img src=\"hometown.png\"><font color=\"purple\">$e[4]</font><br/><img src=\"religion.png\"><font color=\"purple\">$e[2]</font> <img src=\"marriage.gif\"><font color=\"purple\">$e[1]</font><br/><img src=\"study.png\"><font color=\"purple\">$e[5]</font> <img src=\"work.png\"><font color=\"purple\">$e[6]</font></div>";
}
if($uid == $who)
{
echo "<div class=\"\" align=\"right\">";
echo "<a href=\"advance.php?who=$who\">[Update Basic Info Here]</a>";
echo "</div><br/>";
}
echo "</p>";
echo "<p align=\"center\">";
////////Profile Pics By CJ UDAY :)
$avlink = getavatar($who);
$xf = $avlink;
$id = mysql_fetch_array(mysql_query("SELECT id FROM ibwff_gallery WHERE itemurl='".$xf."'"));
if($avlink=="")
{
echo "<p align=\"center\">";
echo "<img src=\"../avatars/nopic.jpg\" type=\"picture\" alt=\"Nopic\" width=\"120\" height=\"135\"/>";
}else{
echo "<div class=\"\" align=\"center\">";
echo "<a href=\"profilepic.php?id=$id[0]\"><img src=\"$avlink\" alt=\"$avlink\" type=\"avatar\" width=\"200\" height=\"250\"/></a>";
echo "</div>";
}
}

if($uid == $who)
{
echo "[<a href=\"upavatar.php\">Upload Your Profile Picture</a>]<br/><br/>";
}
echo "<div class=\"block\" align=\"center\">";
    if($inf1[0]=='1')
    {
 if(($who==$uid)||(arebuds($uid, $who))||(ispu(getuid_sid($sid)))||(ismod(getuid_sid($sid)))||(isowner(getuid_sid($sid))))
    {
if(isonline($who))
{
echo "<small>$whonick is <font color=\"green\">0nline!</small></font><hr>";
}else{
echo "<small>$whonick is <font color=\"red\">0ffline!</small></font><hr>";
}
$lttime = mysql_fetch_array(mysql_query("SELECT plustime, onlinetoday FROM ibwff_users WHERE id='".$who."'"));
$idle = gettimemsg($lttime[0]);
$idle2 = gettimemsg($lttime[1]);
echo "<small><b>Online For:</b> $idle2</small><hr>";
$plc = mysql_fetch_array(mysql_query("SELECT place FROM ibwff_online WHERE userid='".$who."'"));
$ln5 = "<small><b>Location:</b>";
$go = mysql_fetch_array(mysql_query("SELECT placedet FROM ibwff_online WHERE userid='".$who."'"));
$uact .= "<a href=\"$go[0]&who=$who\">$plc[0]</a>";
echo "$ln5 $uact</small><hr>";
$noi = mysql_fetch_array(mysql_query("SELECT lastact FROM ibwff_users WHERE id='".$who."'"));
echo "<small><b>Idle For:</b> ";
$remain = time() - $noi[0];
$idle = gettimemsg($remain);
echo "$idle</small>";
}else{
 echo "";
}
}else{
if(isonline($who))
{
echo "<small>$whonick is <font color=\"green\">0nline!</small></font><hr>";
}else{
echo "<small>$whonick is <font color=\"red\">0ffline!</small></font><hr>";
}
$lttime = mysql_fetch_array(mysql_query("SELECT plustime, onlinetoday FROM ibwff_users WHERE id='".$who."'"));
$idle = gettimemsg($lttime[0]);
$idle2 = gettimemsg($lttime[1]);
echo "<small><b>Online For :</b> $idle2</small><hr>";
$plc = mysql_fetch_array(mysql_query("SELECT place FROM ibwff_online WHERE userid='".$who."'"));
$ln5 = "<small><b>Location:</b>";
$go = mysql_fetch_array(mysql_query("SELECT placedet FROM ibwff_online WHERE userid='".$who."'"));
$uact .= "<a href=\"$go[0]&who=$who\">$plc[0]</a>";
echo "$ln5 $uact</small><hr>";
$noi = mysql_fetch_array(mysql_query("SELECT lastact FROM ibwff_users WHERE id='".$who."'"));
echo "<small><b>Idle For:</b> ";
$remain = time() - $noi[0];
$idle = gettimemsg($remain);
echo "$idle</small>";
}
echo "</div>";
/////////////////Security Pm Hide By CJ UDAY
$whonick = getnick_uid($who);
if($who==3)
{
echo "<div class=\"div\" align=\"center\">";
 echo "<form action=\"chatbot.php?action=sendpm&who=3\" method=\"post\">";
 echo "Message: <input name=\"pmtext\" maxlength=\"500\"/>";
    echo "<input type=\"submit\" value=\"Send\"/>";
    echo "</form></div>";
}else{
$inf1 = mysql_fetch_array(mysql_query("SELECT pm FROM ibwff_users WHERE id='".$who."'"));
    if($inf1[0]=='1')
    {
    if((arebuds($uid, $who))||(ispu(getuid_sid($sid)))||(ismod(getuid_sid($sid)))||(isowner(getuid_sid($sid))))
    {
    if($who!==$uid)
  {
  echo "<div class=\"div\" align=\"center\">";
 echo "<form action=\"inbxproc.php?action=sendpm&who=$who\" method=\"post\">";
 echo "Message: <input name=\"pmtext\" maxlength=\"500\"/>";
    echo "<input type=\"submit\" value=\"Send\"/>";
    echo "</form></div>";
  }
}else{
	    $sql = "SELECT name FROM ibwff_users WHERE id=$who";
	    $sql2 = mysql_query($sql);
	    $item = mysql_fetch_array($sql2);
{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item[0]'"));
if($sex[0]=="M"){$usex = "him";}
if($sex[0]=="F"){$usex = "her";}
if($sex[0]==""){$usex = "";}
echo "<b>[Only friends can send $usex messeges.]</b>";
}
}
}else{
if($who!==$uid)
  {
  echo "<br/>";
    echo "<div class=\"div\" align=\"center\">";
 echo "<form action=\"inbxproc.php?action=sendpm&who=$who\" method=\"post\">";
 echo "Message: <input name=\"pmtext\" maxlength=\"500\"/>";
    echo "<input type=\"submit\" value=\"Send\"/>";
    echo "</form></div>";
}
}
}
if($uid == $who)
  {
    echo "<div class=\"div\" align=\"center\">";
 echo "<form action=\"inbxproc.php?action=sendpm&who=$who\" method=\"post\">";
 echo "Message: <input name=\"pmtext\" maxlength=\"500\"/>";
  echo "<input type=\"submit\" value=\"Send\"/>";
    echo "</form></div>";
 }
 }
$ju = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_relatives WHERE uid='".$who."' OR tid='".$who."', agreed='1' AND relation='Wife'"));
if($ju[0]>0)
{
if(g($who)=="M")
{
$s = "Wife";
$r = "Husband";
$n = "<font color=\"deeppink\"><b>".subnick(getnick_uid($who))."</b></font>";
$avt = "<img src=\"../avatars/female.gif\">";
}else if(g($who)=="F"){
$s = "Husband";
$r = "Wife";
$n = "<font color=\"blue\"><b>".subnick(getnick_uid($who))."</b></font>";
$avt = "<img src=\"../avatars/male.gif\">";
}
$lu = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_relatives WHERE uid='".$who."' AND relation='Wife'"));
if($lu[0]>0)
{
$h = mysql_fetch_array(mysql_query("SELECT tid FROM ibwf_relatives WHERE uid='".$who."' AND relation='Wife'"));
}else{
$h = mysql_fetch_array(mysql_query("SELECT uid FROM ibwf_relatives WHERE tid='".$who."' AND relation='Wife'"));
}
if(getavatar($h[0])=="")
{
$f = $avt;
}else{
$f = "<img src=\"".getavatar($h[0])."\">";
}
if(g($who)=="M")
{
$s = "Wife";
$r = "Husband";
$n = "<font color=\"deeppink\"><b>".subnick(getnick_uid($h[0]))."</b></font>";
$avt = "<img src=\"../avatars/female.gif\">";
}else if(g($who)=="F"){
$s = "Husband";
$r = "Wife";
$n = "<font color=\"blue\"><b>".subnick(getnick_uid($h[0]))."</b></font>";
$avt = "<img src=\"../avatars/male.gif\">";
}
echo "<div class=\"div\" align=\"center\">FirrBD $s : $f<a href=\"profile.php?who=$h[0]\">$n</a></div>";
}
$inf1 = mysql_fetch_array(mysql_query("SELECT prof FROM ibwff_users WHERE id='".$who."'"));
if($inf1[0]=='1')
{
 if(($who==$uid)||(arebuds($uid, $who))||(ispu(getuid_sid($sid)))||(ismod(getuid_sid($sid)))||(isowner(getuid_sid($sid))))
  {
////////////////////////////////Mind Status By CJ UDAY :)
$mind = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_mindstatus11 WHERE uid='".$who."'"));
  if($mind[0]>0)
  {
 echo "<p align=\"center\"><b> &#187; Mind Status &#171;</b><br/>";
  $status = mysql_fetch_array(mysql_query("SELECT uid, status, id FROM ibwff_mindstatus11 WHERE uid='".$who."' ORDER BY
lastupdate DESC LIMIT 0 , 1"));
if(ismod(getuid_sid($sid)))
{
$delnk = "[<a href=\"mindstatus.php?action=delstatus&id=".$status[2]."\">x</a>]";
}
$mitul = parsepm($status[1],$sid);
echo "$mitul $delnk<br/>";
$counts = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_statuslike WHERE statusid='".$status[2]."'"));
$counts1 = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_statusdislike WHERE statusid='".$status[2]."'"));
if($counts[0]>0){ $lyk = "<a href=\"statuslike.php?statusid=$status[2]\">$counts[0]</a>";
 }else{ $lyk = "<a href=\"statuslike.php?statusid=$status[2]\">$counts[0]</a>";
 }
if($counts1[0]>0){ $dislyk = "<a href=\"statusdislike.php?action=main&statusid=$status[2]&sid=$sid\">$counts1[0]</a>";
 }else{ $dislyk = "<a href=\"statusdislike.php?statusid=$status[2]\">$counts1[0]</a>";
 }
$comments = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_scomments WHERE statusid='".$status[2]."'"));
$comm = $comments[0];
echo "<div class=\"block\" align=\"center\">";
echo "<b>";
echo "<br/><br/><img src=\"comment.png\" alt=\"*\" /><a href=\"scomments.php?statusid=$status[2]\">Comments($comm)</a><hr>";
echo "<img src=\"like.png\" alt=\"*\" /><a href=\"mindstatus.php?action=like&id=".$status[2]."\">Like</a> ($lyk)  ";
echo "<hr><img src=\"dislike.png\" alt=\"*\" /><a href=\"mindstatus.php?action=dislike&id=".$status[2]."\">Dislike</a> ($dislyk)<br/><br/>";
echo "</b>";
$mitul = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_mindstatus11 WHERE uid='".$who."'"));
echo "</div>";
echo "<a href=\"mindstatus.php?action=usersupdates&who=$who\">More...[$mitul[0]]</a>";
}
}
}else{
$mind = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_mindstatus11 WHERE uid='".$who."'"));
  if($mind[0]>0)
  {
 echo "<p align=\"center\"><b> &#187; Mind Status &#171;</b><br/>";
  $status = mysql_fetch_array(mysql_query("SELECT uid, status, id FROM ibwff_mindstatus11 WHERE uid='".$who."' ORDER BY
lastupdate DESC LIMIT 0 , 1"));
if(ismod(getuid_sid($sid)))
{
$delnk = "[<a href=\"mindstatus.php?action=delstatus&id=".$status[2]."\">x</a>]";
}
$mitul = parsepm($status[1],$sid);
echo "$mitul $delnk<br/>";
$counts = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_statuslike WHERE statusid='".$status[2]."'"));
$counts1 = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_statusdislike WHERE statusid='".$status[2]."'"));
if($counts[0]>0){ $lyk = "<a href=\"statuslike.php?statusid=$status[2]\">$counts[0]</a>";
 }else{ $lyk = "<a href=\"statuslike.php?statusid=$status[2]\">$counts[0]</a>";
 }
if($counts1[0]>0){ $dislyk = "<a href=\"statusdislike.php?statusid=$status[2]\">$counts1[0]</a>";
 }else{ $dislyk = "<a href=\"statusdislike.php?statusid=$status[2]\">$counts1[0]</a>";
 }
$comments = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_scomments WHERE statusid='".$status[2]."'"));
$comm = $comments[0];
echo "<div class=\"block\" align=\"center\">";
echo "<b>";
echo "<img src=\"comment.png\" alt=\"*\" /><a href=\"scomments.php?statusid=$status[2]\">Comments($comm)</a><hr>";
echo "<img src=\"like.png\" alt=\"*\" /><a href=\"mindstatus.php?action=like&id=".$status[2]."\">Like</a> ($lyk)  <hr>";
echo "<img src=\"dislike.png\" alt=\"*\" /><a href=\"mindstatus.php?action=dislike&id=".$status[2]."\">Dislike</a> ($dislyk)";
echo "</b>";
echo "</div>";
$mitul = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_mindstatus11 WHERE uid='".$who."'"));
echo "<a href=\"mindstatus.php?action=usersupdates&who=$who\">More...[$mitul[0]]</a>";
}
}
if(getuid_sid($sid) == $who)
{
echo "<br/>[<a href=\"mindstatus.php\">Update Mind Status</a>]";
}
echo "<p align=\"left\">";
    if($inf1[0]=='1')
    {
 if(($who==$uid)||(arebuds($uid, $who))||(ispu(getuid_sid($sid)))||(ismod(getuid_sid($sid)))||(isowner(getuid_sid($sid))))
    {
$nopl = mysql_fetch_array(mysql_query("SELECT regdate, ptime FROM ibwff_users WHERE id='".$who."'"));
if(ispu($who)){
if(spu($who)) {$supr=='1';}
$ttm = date("l, dS F Y ", $nopl[1]);
echo "<a href=\"premium.php\"><img src=\"../avatars/premium.png\"> Premium user!</a>
<br/>Will Expire On: <b>$ttm</b><br/>";
}
}else{
 echo "";
}
}else{
$nopl = mysql_fetch_array(mysql_query("SELECT regdate, ptime FROM ibwff_users WHERE id='".$who."'"));
if(ispu($who)){
if(spu($who)) {$supr= "Super";}
$ttm = date("dS F Y", $nopl[1]);
echo "<a href=\"premium.php\"><img src=\"../avatars/spremium.png\" alt=\"Super Premium user!\"></a>
<br/><small>(Will Expire On: <u>$ttm</u>)</small><br/>";
}
}

$inf1 = mysql_fetch_array(mysql_query("SELECT prof FROM ibwff_users WHERE id='".$who."'"));
if($inf1[0]=='1')
{
 if(($who==$uid)||(arebuds($uid, $who))||(ispu(getuid_sid($sid)))||(ismod(getuid_sid($sid)))||(isowner(getuid_sid($sid))))
    {
echo "<b>ID: </b>$who<br/>";
	$whonick = getnick_uid($who);
$nl = mysql_fetch_array(mysql_query("SELECT rp FROM ibwff_users WHERE id='".$who."'"));
echo "<b>Username : $whonick</b><br/>";
echo "<b>Account Balance: </b>&#2547;$nl[0] Taka<br/><a href=\"balance.php\">[what is account balance?]</a><br/>";
$prof = mysql_fetch_array(mysql_query("SELECT views FROM ibwff_users WHERE id='".$who."'"));
if($uid != $who)
{
$vws = $prof[0]+1;
 mysql_query("UPDATE ibwff_users SET views='".$vws."'WHERE  id='".$who."'");
}
mysql_query("INSERT INTO ibwff_lastview SET whonick='".$whonick."', lastview ='".getnick_sid($sid)."', ltime='".time()."'");
$nopl = mysql_fetch_array(mysql_query("SELECT sex, birthday  FROM ibwff_users WHERE id='".$who."'"));
echo "<b>Star Sign: </b>".getstarsign($nopl[1])."<br/>";
$nopl = mysql_fetch_array(mysql_query("SELECT sex, birthday FROM ibwff_users WHERE id='".$who."'"));
$uage = getage($nopl[1]);
if($nopl[0]=='M')
{
$usex = "<img src=\"../avatars/male.gif\" alt=\"M\"/><font color=\"blue\"><b>Male</b></font>";
}else if($nopl[0]=='F'){
$usex = "<img src=\"../avatars/female.gif\" alt=\"M\"/><font color=\"deeppink\"><b>Female</b></font>";
}else{
$usex = "SheMale!";
}
$nopl[2] = htmlspecialchars($nopl[2]);
echo "<b>Age: </b>$uage<br/>";
echo "<b>Sex:</b>$usex<br/>";
$nopl = mysql_fetch_array(mysql_query("SELECT location FROM ibwff_users WHERE id='".$who."'"));
$text = parsepm($nopl[0], $sid);
echo "<b>Location: </b>$text<br/>";
/////////////////Register Date By CJ UDAY :)
$regd = mysql_fetch_array(mysql_query("SELECT regdate FROM ibwff_users WHERE id='".$who."'"));
$tmstamp = $regd[0];
$tremain = time()-$tmstamp;  
$tmdt = gettimemsg($tremain)." ago";
$remain = time() - $regd[0];
$reg = gettimemsg($remain);
$noi = mysql_fetch_array(mysql_query("SELECT regdate FROM ibwff_users WHERE id='".$who."'"));
$remain = time() - $noi[0];
$ile = gettimemsg($remain);
$shdt = date("H:i", $regd[0]);
$stime = $regd['regdate'];
$tremain = time()-$stime;
$tmdt = gettimemsg($tremain);
$ttt = date("h:i:s A",($shdt   (6 * 60 * 60)));
$regd = mysql_fetch_array(mysql_query("SELECT regdate FROM ibwff_users WHERE id='".$who."'"));
  $sage = time()-$regd[0];
  $rwage = ceil($sage/(24*60*60));
$tt2 = ("$tmdt");
echo "<b>Registered: </b> ".date("d F Y, l,h:i:s ",$regd[0])."<br/>($ile Ago)<br/>";
////////////Total Online Time By CJ UDAY :)
$sql= mysql_fetch_array(mysql_query("SELECT totaltime FROM ibwff_users WHERE id='".$who."'"));
$shdt =  date("H:i", $sql[0]);
$stime = $sql['totaltime'];
$tmdt = gettimemsg($stime);
 echo "<b>Total Online:</b>  $tmdt<br/>";
$tmsg = getpmcount(getuid_sid($sid));
$umsg = getunreadpm(getuid_sid(sid));
$noin = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_private WHERE touid='".$who."'"));
$nout = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_private WHERE byuid='".$who."'"));
$unpm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_private WHERE touid='".$who."' AND unread>0"));
$unread = mysql_fetch_array(mysql_query("SELECT COUNT(DISTINCT unread) FROM ibwff_private WHERE byuid='".$uid."' AND
touid='".$who."'"));
if($unpm[0]==0)
{
echo "<b>Unread Inbox: </b> 0<br/>(From You: 0)";
}else{
echo "<b>Unread Inbox: </b>$unpm[0]<br/>(From You: $unread[0])";
}
$cowc = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_clubs WHERE owner='".$who."'"));
if ($cowc[0]>0)
{
$uclubs = mysql_query("SELECT id, name FROM ibwff_clubs WHERE owner='".$who."'");
echo "<br/><b>Owner of:</b>";
while($club=mysql_fetch_array($uclubs))
{
echo " <img src=\"../avatars/clubs.gif\"> <a href=\"clubs.php?action=gocl&amp;clid=$club[0]\">$club[1]</a> Club";
}
}
$cowc = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_clubmembers WHERE uid='".$who."' AND power='1'"));
if ($cowc[0]>0)
{
$uclubs = mysql_query("SELECT clid FROM ibwff_clubmembers WHERE uid='".$who."' AND power='1'");
echo "<br/><b>Moderator of:</b> ";
while($club=mysql_fetch_array($uclubs))
{
$clubname = getclubname($club[0]);
echo "<a href=\"clubs.php?action=gocl&clid=$club[0]\">$clubname</a>, ";
}
}
$cowc = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_clubmembers WHERE uid='".$who."' AND vip='1'"));
if ($cowc[0]>0)
{
$uclubs = mysql_query("SELECT clid FROM ibwff_clubmembers WHERE uid='".$who."' AND vip='1'");
echo "<br/><b>VIP of:</b> ";
while($club=mysql_fetch_array($uclubs))
{
$clubname = getclubname($club[0]);
echo "<a href=\"clubs.php?action=gocl&clid=$club[0]\">$clubname</a>, ";
}
}
echo "<br/><b>Weekly Public Rating:</b> <a href=\"proproc.php?action=rater&who=$who\">".getwpfrting($who)."</a><br/>";
$nopl = mysql_fetch_array(mysql_query("SELECT plusses, totaltime FROM ibwff_users WHERE id='".$who."'"));
echo "<b>Points:</b> $nopl[0]<br/>";
$uall = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users"));
$nopm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE plusses>'$nopl[0]'"));
$nopmx=$nopm[0];
if($nopmx==0) {$nopmx="1";}
echo "<b>MyDhaka Rank: </b>$nopmx out of $uall[0] active members<br/>(MyDhaka ranking based on online time & points)<br/>";
$isallowed = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_givelove WHERE who='".$who."'"));
echo "<b>Love Points:</b> $isallowed[0]<br/>";
$lall = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users "));
$lpm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_givelove WHERE who<'{$isallowed[0]}'"));
$npx=$lpm[0];
if($npx==0) {$npx="1";}
echo "<b>Love Rank: </b>$npx out of $lall[0] active members<br/>";
$nopl = mysql_fetch_array(mysql_query("SELECT gplus FROM ibwff_users WHERE id='".$who."'"));
echo "<b>Game Points:</b> $nopl[0]<br/>";
$nopl = mysql_fetch_array(mysql_query("SELECT coins FROM ibwff_users WHERE id='".$who."'"));
echo "<b>Golden Coins: </b>$nopl[0] <br/>";
if(isowner(getuid_sid($sid)))
{
$nopl = mysql_fetch_array(mysql_query("SELECT phone FROM ibwff_users WHERE id='".$who."'"));
echo "<b>Phone Number: </b>$nopl[0]<br/>";
$nopl = mysql_fetch_array(mysql_query("SELECT email FROM ibwff_users WHERE id='".$who."'"));
echo "<b>Email: </b>$nopl[0]<br/>";
}
$nopl = mysql_fetch_array(mysql_query("SELECT country FROM ibwff_users WHERE id='".$who."'"));
echo "<b>Country: </b>$nopl[0]<br/>";
$re = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_diary WHERE bowner='".$who."'"));
echo "<b>Dairy : </b>$re[0]<br/>";
////////////////////By CJ UDAY :)
$nopl = mysql_fetch_array(mysql_query("SELECT original FROM ibwff_users WHERE id='".$who."'"));
if(ismod(getuid_sid($sid)))
{
echo "<b>Original Browser: </b>$nopl[0] <small>(<u><a href=\"vw.php?action=bybrw&sid=$sid\">Trace This Browser</a></u>)</small><br/>";
}else{
echo "<b>Original Browser: </b>$nopl[0]<br/>";
}
$nopl = mysql_fetch_array(mysql_query("SELECT browserm FROM ibwff_users WHERE id='".$who."'"));
echo "<b>Proxy Browser: </b>$nopl[0]<br/>";
$nopl = mysql_fetch_array(mysql_query("SELECT osmafia FROM ibwff_users WHERE id='".$who."'"));
echo "<b>Platform: </b>$nopl[0]<br/>"; 
$ip = mysql_fetch_array(mysql_query("SELECT ipadd FROM ibwff_users WHERE id='".$who."'"));
echo "<b>Network:</b> ".network($ip[0]);
echo"<br/>";
}else{
echo "";
}
}else{
echo "<b>ID: </b>$who<br/>";
	$whonick = getnick_uid($who);
echo "<b>Username: $whonick</b><br/>";
$nopl = mysql_fetch_array(mysql_query("SELECT rp FROM ibwff_users WHERE id='".$who."'"));
echo "<b>Account Balance: </b>&#2547;$nopl[0] Taka<br/><a href=\"balance.php\">[what is account balance?]</a><br/>";
$prof = mysql_fetch_array(mysql_query("SELECT views FROM ibwff_users WHERE id='".$who."'"));
if($uid != $who)
{
$vws = $prof[0]+1;
 mysql_query("UPDATE ibwff_users SET views='".$vws."'WHERE  id='".$who."'");
mysql_query("INSERT INTO ibwff_lastview SET whonick='".$whonick."', lastview ='".getnick_sid($sid)."', ltime='".time()."'");
}
$nopl = mysql_fetch_array(mysql_query("SELECT sex, birthday  FROM ibwff_users WHERE id='".$who."'"));
echo "<b>Star Sign: </b>".getstarsign($nopl[1])."<br/>";
$nopl = mysql_fetch_array(mysql_query("SELECT sex, birthday FROM ibwff_users WHERE id='".$who."'"));
$uage = getage($nopl[1]);
if($nopl[0]=='M'){
$usex = "<img src=\"../avatars/male.gif\" alt=\"M\"/><font color=\"blue\"><b>Male</b></font>";
}else if($nopl[0]=='F'){
$usex = "<img src=\"../avatars/female.gif\" alt=\"M\"/><font color=\"deeppink\"><b>Female</b></font>";
}
$nopl[2] = htmlspecialchars($nopl[2]);
echo "<b>Age: </b>$uage<br/>";
echo "<b>Sex:</b> $usex<br/>";
$nopl = mysql_fetch_array(mysql_query("SELECT location FROM ibwff_users WHERE id='".$who."'"));
$text = parsepm($nopl[0], $sid);
echo "<b>Location: </b>$text<br/>";
/////////////////Register Date By CJ UDAY :)
$regd = mysql_fetch_array(mysql_query("SELECT regdate FROM ibwff_users WHERE id='".$who."'"));
$tmstamp = $regd[0];
$tremain = time()-$tmstamp;  
$tmdt = gettimemsg($tremain)." ago";
$remain = time() - $regd[0];
$reg = gettimemsg($remain);
$noi = mysql_fetch_array(mysql_query("SELECT regdate FROM ibwff_users WHERE id='".$who."'"));
$shdt = date("H:i", $regd[0]);
$stime = $regd['regdate'];
$tremain = $stime;
$tmdt = gettimemsg($tremain);
$ttt = date("h:i:s A",($shdt + (6 * 60 * 60)));
$regd = mysql_fetch_array(mysql_query("SELECT regdate FROM ibwff_users WHERE id='".$who."'"));
$sage = time()-$regd[0];
$rwage = ceil($sage/(24*60*60));
$tt2 = ("$tmdt");
echo "<b>Registered: </b> ".date("l dS F Y l",$regd[0])."<br/>($reg Ago)<br/>";
$nopl = mysql_fetch_array(mysql_query("SELECT rp FROM ibwff_users WHERE id='".$who."'"));
$nopl = mysql_fetch_array(mysql_query("SELECT plusses FROM ibwff_users WHERE id='".$who."'"));
echo "<b>Points: </b>$nopl[0]<br/>";
$uall = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users "));
$nopm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE plusses>'{$nopl[0]}'"));
$nopmx=$nopm[0];
if($nopmx==0) {$nopmx="1";}
echo "<b>MyDhaka Rank: </b>$nopmx out of $uall[0] active members<br/>(MyDhaka ranking based on online time & points)<br/>";
////////////Total Online Time By CJ UDAY
$sql= mysql_fetch_array(mysql_query("SELECT totaltime FROM ibwff_users WHERE id='".$who."'"));
$shdt =  date("H:i", $sql[0]);
$stime = $sql['totaltime'];
$tmdt = gettimemsg($stime);
 echo "<b>Total Online: </b>$tmdt<br/>";
$tmsg = getpmcount(getuid_sid($sid));
$umsg = getunreadpm(getuid_sid($sid));
$noin = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_private WHERE touid='".$who."'"));
$nout = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_private WHERE byuid='".$who."'"));
$unpm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_private WHERE touid='".$who."' AND unread>0"));
$unread = mysql_fetch_array(mysql_query("SELECT COUNT(DISTINCT unread) FROM ibwff_private WHERE byuid='".$uid."' AND
touid='".$who."'"));
if($unpm[0]==0)
{
echo "<b>Unread Inbox: </b>0<br/>(<b>From You: </b>0)";
}else{
echo "<b>Unread Inbox:</b> $unpm[0] <br/>(<b>From You: </b>$unread[0])";
}
$cowc = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_clubs WHERE owner='".$who."'"));
if ($cowc[0]>0)
{
$uclubs = mysql_query("SELECT id, name FROM ibwff_clubs WHERE owner='".$who."'");
echo "<br/><b>Owner of:</b>";
while($club=mysql_fetch_array($uclubs))
{
echo "<img src=\"../avatars/clubs.gif\"> <a href=\"clubs.php?action=gocl&clid=$club[0]\">$club[1]</a> Club";
}
}
$cowc = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_clubmembers WHERE uid='".$who."' AND power='1'"));
if ($cowc[0]>0)
{
$uclubs = mysql_query("SELECT clid FROM ibwff_clubmembers WHERE uid='".$who."' AND power='1'");
echo "<br/><b>Moderator of:</b> ";
while($club=mysql_fetch_array($uclubs))
{
$clubname = getclubname($club[0]);
echo "<a href=\"clubs.php?action=gocl&clid=$club[0]\">$clubname</a>, ";
}
}
$cowc = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_clubmembers WHERE uid='".$who."' AND vip='1'"));
if ($cowc[0]>0)
{
$uclubs = mysql_query("SELECT clid FROM ibwff_clubmembers WHERE uid='".$who."' AND vip='1'");
//echo "<br/><b>VIP of:</b> ";
while($club=mysql_fetch_array($uclubs))
{
$clubname = getclubname($club[0]);
echo "<a href=\"clubs.php?action=gocl&clid=$club[0]\">$clubname</a>, ";
}
}
echo "<br/><b>Weekly Public Rating:</b> <a href=\"proproc.php?action=rater&who=$who\">".getwpfrting($who)."</a><br/>";
$isallowed = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_givelove WHERE who='".$who."'"));
echo "<b>Love Points: </b>$isallowed[0]<br/>";
$lall = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users "));
$lpm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_givelove WHERE who<'".$who."'"));
$npx=$lpm[0];
if($npx==0) {$npx="1";}
echo "<b>Love Rank: </b>$npx out of $lall[0] active members<br/>";
$nopl = mysql_fetch_array(mysql_query("SELECT gplus FROM ibwff_users WHERE id='".$who."'"));
//echo "<b>Game Points: </b>$nopl[0]<br/>";
$nopl = mysql_fetch_array(mysql_query("SELECT coins FROM ibwff_users WHERE id='".$who."'"));
echo "<b>Golden Coins: </b>$nopl[0] <br/>";
if(isowner(getuid_sid($sid)))
{
$nopl = mysql_fetch_array(mysql_query("SELECT phone FROM ibwff_users WHERE id='".$who."'"));
//echo "<b>Phone Number: </b>$nopl[0]<br/>";
$nopl = mysql_fetch_array(mysql_query("SELECT email FROM ibwff_users WHERE id='".$who."'"));
//echo "<b>Email: </b>$whonick@MyDhaka.Tk<br/>";
}
$nopl = mysql_fetch_array(mysql_query("SELECT country FROM ibwff_users WHERE id='".$who."'"));
echo "<b>Country: </b>$nopl[0]<br/>";
$re = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_diary WHERE bowner='".$who."'"));
echo "<b>Diary: </b>$re[0]<br/>";
////////////////////By CJ UDAY :)
$nopl = mysql_fetch_array(mysql_query("SELECT original FROM ibwff_users WHERE id='".$who."'"));
if(ismod(getuid_sid($sid)))
{
echo "<b>Original Browser: </b>$nopl[0] <small>(<u><a href=\"vw.php?who=$who&action=bybrw\">Trace This Browser</a></u>)</small><br/>";
}else{
echo "<b>Original Browser: </b>$nopl[0]<br/>";
}
$nopl = mysql_fetch_array(mysql_query("SELECT browserm FROM ibwff_users WHERE id='".$who."'"));
echo "<b>Proxy Browser: </b>$nopl[0]<br/>";
$nopl = mysql_fetch_array(mysql_query("SELECT osmafia FROM ibwff_users WHERE id='".$who."'"));
echo "<b>Platform: </b>$nopl[0]<br/>"; 
$ip = mysql_fetch_array(mysql_query("SELECT ipadd FROM ibwff_users WHERE id='".$who."'"));
echo "<b>Network:</b> ".network($ip[0]);
echo"<br/>";
}
if(ismod(getuid_sid($sid)))
{
$uipadd = mysql_fetch_array(mysql_query("SELECT ipadd FROM ibwff_users WHERE id='".$who."'"));
echo "<br/><b>Ip: </b><a href=\"vw.php?who=$who&action=byip\">$uipadd[0]</a><small><u> [<a href=\"http://whatismyipaddress.com/ip/$uipadd[0]\">Trace This Ip</a>]</u></small><br/>";
}
$item = mysql_fetch_array(mysql_query("SELECT interested FROM ibwff_users WHERE id='".$who."'"));
$text = parsepm($item[0], $sid);
    if($inf1[0]=='1')
    {
 if(($who==$uid)||(arebuds($uid, $who))||(ispu(getuid_sid($sid)))||(ismod(getuid_sid($sid)))||(isowner(getuid_sid($sid))))
    {
echo "<div class=\"div\" align=\"\"><b>About Me:</b><br/>$text</div>";
}else{
 echo "";
}
}else{
echo "<div class=\"div\" align=\"center\"><b>About Me:</b><br/>$text</div>";
}
echo "<div class=\"block\" align=\"left\">";
$diary = mysql_fetch_array(mysql_query("SELECT diary_uday FROM ibwff_users WHERE id='".$who."'"));
if($diary[0]=='1')
    {
 if($who==$uid)
    {
$re = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_diary WHERE bowner='".$who."'"));
echo "&#187; <a href=\"dairy.php?who=$who\"> Diary</a> [$re[0]]<hr>";
}else{
echo "";
}
}else{
$re = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_diary WHERE bowner='".$who."'"));
echo "&#187; <a href=\"dairy.php?who=$who\"> Diary</a> [$re[0]]<hr>";
}
$relp = mysql_fetch_array(mysql_query("SELECT frlist FROM ibwff_users WHERE id='".$who."'"));
if($relp[0]=='1')
    {
 if($who==$uid)
    {
$rel = getnrels($who);
echo "&#187; <a href=\"Relatives.php?action=relatives&who=$who\"> Relatives</a> [$rel]<hr>";
$frn = getnbuds($who);
echo "&#187; <a href=\"friends.php?action=friends&who=$who\"> Friends</a> [$frn]<hr>";
$re = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM uday_subus WHERE uid='".$who."'"));
echo "&#187; <a href=\"subscribe.php?who=$who\"> Subscribers</a> [$re[0]]<hr>";
$re = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM uday_memlike WHERE who='".$who."'"));
echo "&#187; <a href=\"memlike.php?action=list&who=$who\"> Profile Likers</a> [$re[0]]<hr>";
}else{
echo "";
}
}else{
$rel = getnrels($who);
echo "&#187; <a href=\"Relatives.php?action=relatives&who=$who\"> Relatives</a> [$rel]<hr>";
$frn = getnbuds($who);
echo "&#187; <a href=\"friends.php?action=friends&who=$who\"> Friends</a> [$frn]<hr>";
$re = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM uday_subus WHERE uid='".$who."'"));
echo "&#187; <a href=\"subscribe.php?who=$who\"> Subscribers</a> [$re[0]]<hr>";
$re = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM uday_memlike WHERE who='".$who."'"));
echo "&#187; <a href=\"memlike.php?action=list&who=$who\"> Profile Likers</a> [$re[0]]<hr>";
}
$whn = getnick_uid($who);
$sclp = time() - 24*60*60;
if(getuid_sid($sid)==$who)
{
$re = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_ignore WHERE name='".$who."'"));
echo "&#187; <a href=\"ignore.php?action=list&who=$who\"> Ignored</a> [$re[0]]<hr>";
}
$sclp = time() - 24*60*60;
$re = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_lastview WHERE whonick='".$whn."' AND ltime > '$sclp'"));
echo "&#187; <a href=\"lviewer.php?who=$who\"> Last Viewers</a> [$re[0]]<hr>";
if(g($who)=="M")
{
$f = "him";
}else if(g($who)=="F")
{
$f = "her";
}else{
$f = "";
}
if(getuid_sid($sid)!=$who)
{
echo "&#187; <a href=\"miss.php?who=$who\"> Miss $f</a><hr>";
echo "&#187; <a href=\"love.php?who=$who\"> Give Love</a><hr>";
}else{
echo "";
}
$sclp = time() - 24*60*60;
$re = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_givelove WHERE who='".$who."' AND date > '$sclp'"));
echo "&#187; <a href=\"love.php?action=list&who=$who\"> Love'rs Today</a> [$re[0]]<hr>";
$re = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_miss WHERE who='".$who."' AND date > '$sclp'"));
echo "&#187; <a href=\"miss.php?action=list&who=$who\"> Miss'ers Today</a> [$re[0]]<hr>";
if(getuid_sid($sid)!=$who)
{
echo "&#187; <a href=\"gifts.php?action=point&who=$who\"> Gift Points</a><hr>";
}else{
echo "";
}
$re = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_giftpointers61 WHERE who='".$who."'"));
echo "&#187; <a href=\"gifts.php?action=pntlists&who=$who\"> Gifts</a> [$re[0]]<hr>";
if(getuid_sid($sid)!=$who)
{
$re = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM uday_subus WHERE uid='".$who."' AND who='".getuid_sid($sid)."'"));
if($re[0]==0)
{
echo "&#187; <a href=\"subscribe.php?action=sub&who=$who\"> Subscribe</a><hr>";
}else{
echo "&#187; <a href=\"subscribe.php?action=unsub&who=$who\"> Unsubscribe</a><hr>";
}
}else{
echo "";
}
$re = mysql_fetch_array(mysql_query("SELECT relreq FROM ibwff_users WHERE id='".$who."'"));
if($re[0]=='1')
{
echo "<b>[You Can't Send A Relationship Request!]</b><hr>";
}else{
if(getuid_sid($sid)!=$who)
{
if(relres($who,getuid_sid($sid))==0)
{
echo "&#187; <a href=\"relativesproc.php?action=snreq&who=$who\"> Add To Relative List</a><hr>";
}else if(relres($who,getuid_sid($sid))==1)
{
echo "&#187; (Wating Relative Request)<hr>";
}else if(relres($who,getuid_sid($sid))==2)
{
echo "&#187; <a href=\"relativesproc.php?action=del&who=$who\"> Remove From Relative List</a><hr>";
}
}else{
echo "";
}
}
$re = mysql_fetch_array(mysql_query("SELECT frreq FROM ibwff_users WHERE id='".$who."'"));
if($re[0]=='1')
{
echo "<b>[You Can't Send A Friend Request!]</b><hr>";
}else{
if(getuid_sid($sid)!=$who)
{
if(budres($who,getuid_sid($sid))==0)
{
echo "&#187; <a href=\"friendsproc.php?action=add&who=$who\"> Add To Friend List</a><hr>";
}else if(budres($who,getuid_sid($sid))==1)
{
echo "&#187; (Wating Friend Request)<br/>";
}else if(budres($who,getuid_sid($sid))==2)
{
echo "&#187; <a href=\"friendsproc.php?action=del&who=$who\"> Remove From Friend List</a><hr>";
}
}else{
echo "";
}
}
if(getuid_sid($sid)!=$who)
{
if(ignoreres(getuid_sid($sid),$who)==1)
{
echo "&#187; <a href=\"ignore.php?action=add&who=$who\"> Add To Ignore List</a>";
}else if(ignoreres(getuid_sid($sid),$who)==2)
{
echo "&#187; <a href=\"ignore.php?action=del&who=$who\"> Remove From Ignore List</a>";
}
echo "</div>";
}else{
echo "";
echo "</div>";
}

$fx = mysql_query("SELECT id, itemurl FROM ibwff_gallery WHERE uid='".$who."' ORDER BY id DESC LIMIT 0,6");
if(mysql_num_rows($fx)>0)
{
echo "<br/><div class=\"forum\" align=\"left\">";
while($m = mysql_fetch_array($fx))
{
echo "<a href=\"galphoto.php?action=comments&gid=$m[0]\"><img src=\"$m[1]\" alt=\"$m[1]\" width=\"40\" height=\"55\"></a>";
}
echo "</div>";
}else{
echo "";
}
$fx = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_gallery WHERE uid='".$who."'"));
echo "<div class=\"shh\" align=\"left\">";
echo "-&#187; <a href=\"gallery.php?action=viewuser&who=$who\"> Album Photo</a> [$fx[0]]";
echo "</div>";
$sx = mysql_fetch_array(mysql_query("SELECT gbok FROM ibwff_users WHERE id='".$who."'"));
if($sx[0]=='1')
{
echo "";
}else{
  $gbook = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_gbook WHERE gbowner='".$who."'"));
  if($gbook[0]>0)
  {
echo "<div class=\"div\" align=\"center\"><b>Guestbook Messege</b></div>";
}
$items = mysql_query("SELECT gbowner, gbsigner, gbmsg, dtime, id FROM ibwff_gbook WHERE gbowner='".$who."' ORDER BY dtime DESC LIMIT 0, 1");
while ($item = mysql_fetch_array($items))
{
$n = subnick(getnick_uid($item[1]));
if(g($item[1])=="M")
{
$nick = "<font color=\"blue\"><b>$n</b></font>";
$usi = "<img src=\"../avatars/male.gif\">";
}else if(g($item[1])=="F")
{
$nick = "<font color=\"deeppink\"><b>$n</b></font>";
$usi = "<img src=\"../avatars/female.gif\">";
}else{
$nick = "";
$usi = "";
}
$avlink = getavatar($item[1]);
if($avlink=="")
{
 $avt =  "$usi";
}else{
 $avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"icon\" width=\"23\" height=\"18\"/>";
}
$lnk = "<a href=\"profile.php?who=$item[1]\"><b>$avt$nick</b></a>";
$text = parsepm($item[2], $sid);
echo "$lnk : $text<br/>";
}
if($gbook[0]>0)
{
echo "[<a href=\"gbook.php?action=gbook&who=$who\">$gbook[0] More</a>]";
}

if($uid != $who)
{
echo "<br/>&#187; <a href=\"gbook.php?action=signgb&who=$who\"> Sign Guestbook</a>";
}
}

$sx = mysql_fetch_array(mysql_query("SELECT ask FROM ibwff_users WHERE id='".$who."'"));
if($sx[0]=='1')
{
echo "";
}else{
  $gbook = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM uday_ask WHERE aown='".$who."'"));
  if($gbook[0]>0)
  {
echo "<div class=\"div\" align=\"center\"><b>AskME</b></div>";
}
$items = mysql_query("SELECT id, aown, asign, ques, ans, hide FROM uday_ask WHERE aown='".$who."' ORDER BY time DESC LIMIT 0, 1");
while ($item = mysql_fetch_array($items))
{
$n = subnick(getnick_uid($item[2]));
if(g($item[2])=="M")
{
$nick = "<font color=\"blue\"><b>$n</b></font>";
$usi = "<img src=\"../avatars/male.gif\">";
}else if(g($item[2])=="F")
{
$nick = "<font color=\"deeppink\"><b>$n</b></font>";
$usi = "<img src=\"../avatars/female.gif\">";
}else{
$nick = "";
$usi = "";
}
$avlink = getavatar($item[2]);
if($avlink=="")
{
 $avt =  "$usi";
}else{
 $avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"icon\" width=\"23\" height=\"18\"/>";
}
if($item[5]==0)
{
$lnk = "<a href=\"profile.php?who=$item[1]\"><b>$avt$nick</b></a>";
}else{
$lnk = "Q";
}
$text = parsepm($item[3], $sid);
$ans = parsepm($item[4], $sid);
echo "$lnk: $text<br/>A: $ans<br/>";
}
if($gbook[0]>0)
{
echo "[<a href=\"ask.php?action=list&who=$who\">$gbook[0] More</a>]<br/>";
}

if($uid != $who)
{
echo "<br/>&#187; <a href=\"ask.php?action=ask&who=$who\"> AskME</a><br/>";
}
}
$l = mysql_fetch_array(mysql_query("SELECT prof FROM ibwff_users WHERE id='".$who."'"));
if($who != $uid)
{
if($l[0]=='1')
{
if(arebuds($who, $uid))
{
$al = mysql_fetch_array(mysql_query("SELECT * FROM uday_memlike WHERE who='".$who."' AND uid='".$uid."'"));
if($al[0]==0)
{
echo "<img src=\"p.gif\"> <a href=\"memlike.php?who=$who\"> Like this profile</a>";
}else{
echo "";
}
}else{
echo "";
}
}else{
$al = mysql_fetch_array(mysql_query("SELECT * FROM uday_memlike WHERE who='".$who."' AND uid='".$uid."'"));
if($al[0]==0)
{
echo "<img src=\"p.gif\"> <a href=\"memlike.php?who=$who\"> Like this profile</a>";
}else{
echo "";
}
}
}else{
echo "";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</div>";
}
?>
</html>