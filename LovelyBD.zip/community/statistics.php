<?php
session_start();
include("config.php");
include("core.php");
connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo '<head>';
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"title\" content=\"firebd.net\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From Shahos: Don't Try To Hack OR else :P\">
<meta name=\"keywords\" content=\"Site Desined By Shahos :) :)\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/></head>";
echo "<body>";
$action = $_GET["action"]; $sid = $_SESSION["sid"];
$clid = $_GET["clid"]; $action = $_GET["action"];
$page = $_GET["page"];
$who = $_GET["who"];
$uid = getuid_sid($sid);
$brws = explode(" ",$HTTP_USER_AGENT);
$ubr = $brws[0];
$uip = getip();
////////////////Ip Banned By CJ UDAY :)
if(isipbanned($uip,$ubr))
{
if(!isshield(getuid_sid($sid)))
{
echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
echo "<br/>";
echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
$banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
$remain =  $banto[0] - time();
$rmsg = gettimemsg($remain);
echo "<b>Time Remaining: $rmsg</b><br/><br/>";
echo "</p>";
echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
exit();
}
}
//////////////////Banned System Updated By CJ UDAY :)
if(isbanned($uid))
{
echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please Contact <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(!isuser(getuid_sid($sid)))
{
echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<br/>This feature is unavailiable for guests.
So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
echo "<div class=\"div\" align=\"center\">";
echo "<b>USER ACCESS</b></div>";
echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";
echo "</form><br/><br/>";
echo "Not Registered Yet? ";
echo "<a href=\"register.php\">Register Now!</a>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(islogged($sid)==false)
{
echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
echo "<br/>For some security reasons,you are automatically logged out.<br/>
You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
Or, Please Login Again :-)<br/><br/>";
echo "<div class=\"div\" align=\"center\">";
echo "<b>USER ACCESS</b></div>";
echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
///////////////////Deactivated Account Created By CJ UDAY :)
if(isdeactivated(getuid_sid($sid), $uid))
{
echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
echo "<br/>
<b>Your Account Has Been Deactivated Forever.<br/>And It Will Be Never Activate!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
exit();
}
///////////////////Validation By CJ UDAY :)
if(isvalidated(getuid_sid($sid), $uid))
{
echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
echo "<br/>
You Are Not Validated!<br/>We are checking your ip and browser<br/>
This could take up to 15 munites pls be patient and try again soon<br/>Please try again later...<br/><b>Thank You</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
exit();
}
////////////////////////////Statistics Created By CJ UDAY :)
if($action=="")
{
addonline(getuid_sid($sid),"Viewing Statistics","statistics.php?action=$action");
echo "<head>";
echo "<title>View Statistics</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Statistics</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include ("pm_by.php");
$t = 24*60*60;
$o = time()-3600;
$f = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE cyberpowereragon>'0'"));
$a = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE cyberpowereragon>'0' AND lastact>'".$o."'"));
echo "<b><u>Staffs</u></b> [<a href=\"online.php?action=stfol\">$a[0]</a>/<a href=\"udays.php?action=stf&view=a\">$f[0]</a>]<br/>";
$f = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE pu>'0'"));
$o = time()-3600;
$a = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE pu>'0' AND lastact>'".$o."'"));
echo "<b><u>Premium Members</u></b> [$a[0]/$f[0]]<br/>";
$o = time()-3600;
$f = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE pu>'1'"));
$a = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE lastact>'".$o."' AND pu>'1'"));
echo "&#187; Super Premium Member [<a href=\"udays.php?action=spu&view=o\">$a[0]</a>/<a href=\"udays.php?action=spu&view=a\">$f[0]</a>]<br/>";
$f = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE pu='1'"));
$a = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE pu='1' AND lastact>'".$o."'"));
echo "&#187; General Premium Member [<a href=\"udays.php?action=pu&view=o\">$a[0]</a>/<a href=\"udays.php?action=pu&view=a\">$f[0]</a>]<br/>";
$f = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE vip>'0'"));
$o = time()-3600;
$a = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE vip>'0' AND lastact>'".$o."'"));
echo "<b><u>VIP</u></b> [$a[0]/$f[0]]<br/>";
$o = time()-3600;
$f = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE vip>'0' AND totaltime>'".junvip()."' AND totaltime<'".senvip()."'"));
$a = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE vip>'0' AND lastact>'".$o."'"));
echo "&#187; Junior Vip [<a href=\"udays.php?action=jv&view=o\">$a[0]</a>/<a href=\"udays.php?action=jv&view=a\">$f[0]</a>]<br/>";
$f = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE vip>'0' AND totaltime>".senvip().""));
$a = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE lastact>'".$o."' AND vip>'0'"));
echo "&#187; Senior Vip [<a href=\"udays.php?action=sv&view=o\">$a[0]</a>/<a href=\"udays.php?action=sv&view=a\">$f[0]</a>]<br/>";

echo "<b><u>Active Member</u></b><br/>";
$o = time()-3600;
$f = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE  totaltime>'".junmemberpoint()."' AND totaltime<'".senmemberpoint()."'"));
$a = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE totaltime>".junmemberpoint()." AND totaltime<'".senmemberpoint()."' AND lastact>'".$o."'"));
echo "&#187; Junior Member [<a href=\"udays.php?action=jm&view=o\">$a[0]</a>/<a href=\"udays.php?action=jm&view=a\">$f[0]</a>]<br/>";
$f = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE  totaltime>".senmemberpoint()." AND totaltime<".junvip()." AND id!=3 AND pu='0' AND cyberpowereragon='0'"));
$a = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE lastact>'".$o."' AND totaltime>".senmemberpoint()." AND totaltime<".junvip()." AND id!=3 AND pu='0' AND cyberpowereragon='0'"));
echo "&#187; Senior Member [<a href=\"udays.php?action=sm&view=o\">$a[0]</a>/<a href=\"udays.php?action=sm&view=a\">$f[0]</a>]<br/>";
$o = time()-3600;
$f = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE plusses>'".knightpoint()."'"));
$a = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE plusses>'".knightpoint()."' AND lastact>'".$o."'"));
echo "<b><u>Top Members</u></b> [$a[0]/$f[0]]<br/>";
$o = time()-3600;
$f = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE plusses>".kok().""));
$a = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE lastact>'".$o."' AND plusses>".kok().""));
echo "&#187; King Of The King [<a href=\"udaymo.php?action=mem&view=kok\">$a[0]</a>/<a href=\"udaym.php?action=mem&view=kok\">$f[0]</a>]<br/>";
$f =mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE plusses>".king()." AND plusses<'".kok()."'"));
$a = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE lastact>'".$o."' AND plusses>".king()." AND plusses<'".kok()."'"));
echo "&#187; MyDhaka King/Queen [<a href=\"udaymo.php?action=mem&view=k\">$a[0]</a>/<a href=\"udaym.php?action=mem&view=k\">$f[0]</a>]<br/>";
$f = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE plusses>".pppoint()." AND plusses<'".king()."'"));
$a = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE lastact>'".$o."' AND plusses>".pppoint()." AND plusses<'".king()."'"));
echo "&#187; MyDhaka Prince/Princess [<a href=\"udaymo.php?action=mem&view=p\">$a[0]</a>/<a href=\"udaym.php?action=mem&view=p\">$f[0]</a>]<br/>";
$f = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE plusses>".mrsmispoint()." AND plusses<'".pppoint()."'"));
$a = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE lastact>'".$o."' AND plusses>".mrsmispoint()." AND plusses<'".pppoint()."'"));
echo "&#187; MyDhaka Master [<a href=\"udaymo.php?action=mem&view=m\">$a[0]</a>/<a href=\"udaym.php?action=mem&view=m\">$f[0]</a>]<br/>";
$f = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE plusses>".expartpoint()." AND plusses<'".mrsmispoint()."'"));
$a = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE lastact>'".$o."' AND plusses>".expartpoint()." AND plusses<'".mrsmispoint()."'"));
echo "&#187; MyDhaka Expart [<a href=\"udaymo.php?action=mem&view=ex\">$a[0]</a>/<a href=\"udaym.php?action=mem&view=ex\">$f[0]</a>]<br/>";
$f = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE plusses>".expellerpoint()." AND plusses<'".expartpoint()."'"));
$a = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE lastact>'".$o."' AND plusses>".expellerpoint()." AND plusses<'".expartpoint()."'"));
echo "&#187; MyDhaka Expeller [<a href=\"udaymo.php?action=mem&view=ep\">$a[0]</a>/<a href=\"udaym.php?action=mem&view=ep\">$f[0]</a>]<br/>";
$f = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE plusses>".knightpoint()." AND plusses<'".expellerpoint()."'"));
$a = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE lastact>'".$o."' AND plusses>".knightpoint()." AND plusses<'".expellerpoint()."'"));
echo "&#187; MyDhaka Knight [<a href=\"udaymo.php?action=mem&view=kn\">$a[0]</a>/<a href=\"udaym.php?action=mem&view=kn\">$f[0]</a>]<br/>";
echo "<b><u>All Members:</u></b> [".getnumonline()."/".regmemcount()."]<br/>";
$norm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE sex='M'"));
$nrm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE sex='M' AND lastact>'".$o."'"));
echo "&#187; Male [<a href=\"online.php?action=monline\">$nrm[0]</a>/<a href=\"ulist.php?action=males\">$norm[0]</a>]<br/>";
$norm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE sex='F'"));
$nrm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE sex='F' AND lastact>'".$o."'"));
echo "&#187; Female [<a href=\"online.php?action=fonline\">$nrm[0]</a>/<a href=\"ulist2.php?action=females\">$norm[0]</a>]<br/>";
$nrm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE lastact>'".$t."'"));
echo "&#187; Regular [<a href=\"online.php?action=online\">".getnumonline()."</a>/<a href=\"memlist.php?action=members\">$nrm[0]</a>]<br/>";
$norm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE country='Bangladesh' AND lastact>'".$t."'"));
$nrm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE country='Bangladesh' AND lastact>'".$o."'"));
echo "&#187; Regular(Bangladesh) [<a href=\"online.php?action=bangladesh\">$nrm[0]</a>/<a href=\"memlist.php?action=members\">$norm[0]</a>]<br/>";
echo "<b><u>Members Toplist Categorys:</u></b><br/>";
echo "<a href=\"top1.php?action=tplovers\">&#187; Top Lovers</a><br/>";
echo "<a href=\"top1.php?action=tploved\">&#187; Top Loved</a><br/>";
echo "<a href=\"top1.php?action=tpmisses\">&#187; Top Missers</a><br/>";
echo "<a href=\"top1.php?action=tpmissed\">&#187; Top Missed</a><br/>";
echo "<a href=\"top1.php?action=tpgifters\">&#187; Top Gifters</a><br/>";
echo "<a href=\"top1.php?action=tpgifted\">&#187; Top Gifted</a><br/>";
echo "<a href=\"top2.php?action=topst\">&#187; Top Posters</a><br/>";
echo "<a href=\"top2.php?action=tpshout\">&#187; Top Shouters</a><br/>";
echo "<a href=\"top2.php?action=tpfvw\">&#187; Top Profile Views</a><br/>";
echo "<a href=\"top2.php?action=tppls\">&#187; Top Polls Creators</a><br/>";
echo "<a href=\"top2.php?action=tpblg\">&#187; Top Blogs Creators</a><br/>";
echo "<a href=\"top3.php?action=tpstatus\">&#187; Top Status Updater</a><br/>";
echo "<a href=\"top3.php?action=tpmsgsend&clid=$clid&who=$who\">&#187; Top Messages Senders</a><br/>";
echo "<a href=\"top3.php?action=tpmsgread\">&#187; Top Messages Readers</a><br/>";
echo "<a href=\"top3.php?action=tpshtcom\">&#187; Top Shout Commenters</a><br/>";
echo "<a href=\"top3.php?action=tpblgcom\">&#187; Top Blogs Commenters</a><br/>";
echo "<a href=\"top3.php?action=tptopic\">&#187; Top Topics Creators</a><br/>";
echo "<a href=\"top4.php?action=toplet\">&#187; Top Literature Creators</a><br/>";
echo "<a href=\"top4.php?action=tpgbsingned\">&#187; Top Guestbooks Singed</a><br/>";
echo "<a href=\"top4.php?action=tpgbsinger\">&#187; Top Guestbooks Singner</a><br/>";
echo "<a href=\"top4.php?action=tpgdcoin\">&#187; Top Golden Coin Grabbers</a><br/>";
echo "<a href=\"top4.php?action=tpfpiclike\">&#187; Top Profile Picture Likers</a><br/>";
echo "<a href=\"top4.php?action=tpcoverpiclike\">&#187; Top Cover Photo Likers</a><br/>";
echo "<a href=\"top5.php?action=topletpst\">&#187; Top Literature Commenters</a><br/>";
echo "<a href=\"top5.php?action=tpfpicom\">&#187; Top Profile Picture Commenters</a><br/>";
echo "<a href=\"top5.php?action=tpcoverpiccom\">&#187; Top Cover Photo Commenters</a><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
}
?>
</html>