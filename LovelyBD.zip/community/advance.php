<?php
session_start();
include("config.php");
include("core.php");  
connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo '<head>';
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"title\" content=\"FireBD.NeT\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From Megh: Don't Try To Hack OR else :P\">
<meta name=\"keywords\" content=\"Site Desined By Megh :) :)\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/></head>";
echo "<body>";
$action = $_GET["action"]; $sid = $_SESSION["sid"];
$page = $_GET["page"];
$who = $_GET["who"];
$uid = getuid_sid($sid);
$name = $_GET["name"];
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();
////////////////Ip Banned By CJ UDAY :)	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
    echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
	echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
      echo "<br/>";
      echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
      $banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
      $remain =  $banto[0] - time();
      $rmsg = gettimemsg($remain);
      echo "<b>Time Remaining: $rmsg</b><br/>";
      $nick = getnick_uid($banto[2]);
       $text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
      echo "</p>";
    	echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
    echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
    echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
//////////////////Banned System Updated By CJ UDAY :)
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please With Contact Us <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
 echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
///////////////////Validation By CJ UDAY :)
					if(isvalidated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
	echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  You Are Not Validated!<br/>We are checking your ip and browser<br/>
	  This could take up to 15 munites pls be patient and try again soon<br/>Please try again later...<br/><b>Thank You</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }

///////////////////Deactivated Account By CJ UDAY :)
          if(isdeactivated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  <b>Your Account Has Been Deactivated Forever.<br/>And It Will Be Never Activate!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
//////////////////////////////////ADVANCED PROFILE created By CJ UDAY :)
else if($action=="")
{
    addonline(getuid_sid($sid),"Updating Advance Profile","advance.php?action=$action");
	    echo "<head>";
    echo "<title>Update Advanced Profile</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
    echo "<div class=\"header\" align=\"center\">";
	echo "<b>Update Advanced Profile</b></div>";
	echo "<div class=\"shout2\" align=\"left\">";
    include("pm_by.php");
echo "&#187; <a href=\"advance.php?action=basic\"> Basic info</a><br/>";
echo "&#187; <a href=\"advance.php?action=app\"> Appearance</a><br/>";
echo "&#187; <a href=\"advance.php?action=int\"> Interests</a><br/>";
echo "&#187; <a href=\"advance.php?action=fav\"> Favourites</a><br/>";
echo "&#187; <a href=\"advance.php?action=mam\"> More About Me</a><br/>";
echo "<br/>&#171; <a href=\"settings.php?action=settings\"> Back to settings!</a><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php?\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
//Basic Info created by CJ UDAY
else if($action=="basic")
{
$fn = mysql_fetch_array(mysql_query("SELECT fn FROM ibwff_users WHERE id='".$uid."'"));
$sn = mysql_fetch_array(mysql_query("SELECT sn FROM ibwff_users WHERE id='".$uid."'"));
$nn = mysql_fetch_array(mysql_query("SELECT name FROM ibwff_users WHERE id='".$uid."'"));
$li = mysql_fetch_array(mysql_query("SELECT lin FROM ibwff_users WHERE id='".$uid."'"));
$ht = mysql_fetch_array(mysql_query("SELECT ht FROM ibwff_users WHERE id='".$uid."'"));
$sa = mysql_fetch_array(mysql_query("SELECT sat FROM ibwff_users WHERE id='".$uid."'"));
$wa = mysql_fetch_array(mysql_query("SELECT wat FROM ibwff_users WHERE id='".$uid."'"));
    addonline(getuid_sid($sid),"Updating Advance Profile","advance.php?action=$action");
	    echo "<head>";
    echo "<title>Update Basic Info</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
    echo "<div class=\"header\" align=\"center\">";
	echo "<b>Update Basic Info</b></div>";
	echo "<div class=\"shout2\" align=\"left\">";
    include("pm_by.php");
echo "<form action=\"advanceproc.php?action=basic\" method=\"post\">";
echo "<b>Full name:</b><br/><input name=\"fn\" value=\"$fn[0]\"><br/>";
echo "<b>Surname:</b><br/><input name=\"sn\" value=\"$sn[0]\"><br/>"; 
echo "<b>Nickname:</b><br/><input name=\"nn\" value=\"$nn[0]\"><br/>";
echo "<b>Marital status:</b><br/>
<select name=\"ms\">
<option value=\"Single\">Single</option>
<option value=\"In Relationship\">In Relationship</option>
<option value=\"Engaged\">Engaged</option>
<option value=\"Married\">Married</option>
<option value=\"Divorced\">Divorced</option>
<option value=\"Hide\">Hide</option>
</select><br/>";
echo "<b>Religion:</b><br/>
<select name=\"rg\">
<option value=\"Islam\">Islam</option>
<option value=\"Hindhism\">Hinduism</option>
<option value=\"Christian\">Christian</option>
<option value=\"Buddhism\">Buddhism</option>
<option value=\"Judaism\">Judaism</option>
<option value=\"Humanism\">Humanism</option>
<option value=\"Hide\">Hide</option>
</select><br/>";
echo "<b>Living in:</b><br/><input name=\"lin\" value=\"$li[0]\"><br/>";
echo "<b>Hometown:</b><br/><input name=\"ht\" value=\"$ht[0]\"><br/>";
echo "<b>Study at:</b><br/><input name=\"sa\" value=\"$sa[0]\"><br/>";
echo "<b>Work at:</b><br/><input name=\"wa\" value=\"$wa[0]\"><br/>";
echo "<input type=\"submit\" value=\"Save\">";
echo "</form>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
//Appearance created by CJ UDAY
else if($action=="app")
{
    addonline(getuid_sid($sid),"Updating Advance Profile","advance.php?action=$action");
	    echo "<head>";
    echo "<title>Update Appearence</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
    echo "<div class=\"header\" align=\"center\">";
	echo "<b>Update Appearence</b></div>";
	echo "<div class=\"shout2\" align=\"left\">";
    include("pm_by.php");
$h = mysql_fetch_array(mysql_query("SELECT height FROM ibwff_users WHERE id='".$uid."'"));
$w = mysql_fetch_array(mysql_query("SELECT weight FROM ibwff_users WHERE id='".$uid."' "));
$ha = mysql_fetch_array(mysql_query("SELECT hair FROM ibwff_users WHERE id='".$uid."'"));
echo "<form action=\"advanceproc.php?action=app\" method=\"post\">";
echo "<b>Height:</b><br/><input name=\"height\" value=\"$h[0]\"><br/>";
echo "<b>Weight:</b><br/><input name=\"weight\" value=\"$w[0]\"><br/>";
echo "<b>Body type:</b><br/>
<select name=\"body\">
<option value=\"Slim\">Slim</option>
<option value=\"Slim toned\">Slim toned</option>
<option value=\"Average\">Average</option>
<option value=\"Defined\">Defined</option>
<option value=\"Medium build\">Medium build</option>
<option value=\"Medium build, muscles\">Medium build, muscles</option>
<option value=\"Fuller figure\">Fuller figure</option>
</select><br/>";
echo "<b>Ethnic orgin:</b><br/>
<select name=\"orgin\">
<option value=\"Asian\">Asian</option>
<option value=\"South asian\">South asian</option>
<option value=\"Oriental\">Oriental</option>
<option value=\"Black\">Black</option>
<option value=\"Latin hispanic\">Latin hispanic</option>
<option value=\"Middle eastern\">Middle eastern</option>
<option value=\"Mixed race\">Mixed race</option>
<option value=\"Mixed european\">Mixed european</option>
<option value=\"White caucasian\">White caucasian</option>
<option value=\"African american\">African american</option>
<option value=\"American indian\">American indian</option>
<option value=\"African\">African</option>
<option value=\"Other\">Other</option>
</select><br/>";
echo "<b>Hair:</b><br/><input name=\"hair\" value=\"$ha[0]\"><br/>";
echo "<b>Eyes:</b><br/>
<select name=\"eye\">
<option value=\"Brown\">Brown</option>
<option value=\"Blue\">Blue</option>
<option value=\"Green\">Green</option>
<option value=\"Gray\">Gray</option>
<option value=\"Hazel\">Hazel</option>
<option value=\"Black\">Black</option>
</select><br/>";
echo "<input type=\"submit\" value=\"Save\">";
echo "</form>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
//Interests by CJ UDAY
else if($action=="int")
{
    addonline(getuid_sid($sid),"Updating Advance Profile","advance.php?action=$action");
	    echo "<head>";
    echo "<title>Update Interests</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
    echo "<div class=\"header\" align=\"center\">";
	echo "<b>Update Interests</b></div>";
	echo "<div class=\"shout2\" align=\"left\">";
    include("pm_by.php");
$mh = mysql_fetch_array(mysql_query("SELECT mh FROM ibwff_users WHERE id='".$uid."'"));
$ms = mysql_fetch_array(mysql_query("SELECT ms FROM ibwff_users WHERE id='".$uid."' "));
$ir = mysql_fetch_array(mysql_query("SELECT ir FROM ibwff_users WHERE id='".$uid."'"));
$pf = mysql_fetch_array(mysql_query("SELECT pf FROM ibwff_users WHERE id='".$uid."'"));
$bh = mysql_fetch_array(mysql_query("SELECT bh FROM ibwff_users WHERE id='".$uid."' "));
$gh = mysql_fetch_array(mysql_query("SELECT gh FROM ibwff_users WHERE id='".$uid."'"));
echo "<form action=\"advanceproc.php?action=int\" method=\"post\">";
echo "<b>Makes me happy:</b><br/><input name=\"mh\" value=\"$mh[0]\"><br/>";
echo "<b>Makes me sad:</b><br/><input name=\"ms\" value=\"$ms[0]\"><br/>";
echo "<b>Interests:</b><br/><input name=\"ir\" value=\"$ir[0]\"><br/>";
echo "<b>Profession:</b><br/><input name=\"pf\" value=\"$pf[0]\"><br/>";
echo "<b>Bad habits:</b><br/><input name=\"bh\" value=\"$bh[0]\"><br/>";
echo "<b>Good habits:</b><br/><input name=\"gh\" value=\"$gh[0]\"><br/>";
echo "<input type=\"submit\" value=\"Save\">";
echo "</form>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
//Favourites by CJ UDAY
else if($action=="fav")
{
    addonline(getuid_sid($sid),"Updating Advance Profile","advance.php?action=$action");
	    echo "<head>";
    echo "<title>Update Favourites</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
    echo "<div class=\"header\" align=\"center\">";
	echo "<b>Update Favourites</b></div>";
	echo "<div class=\"shout2\" align=\"left\">";
    include("pm_by.php");
$tm = mysql_fetch_array(mysql_query("SELECT teamx FROM ibwff_users WHERE id='".$uid."'"));
$bd = mysql_fetch_array(mysql_query("SELECT bandx FROM ibwff_users WHERE id='".$uid."' "));
$mc = mysql_fetch_array(mysql_query("SELECT musicx FROM ibwff_users WHERE id='".$uid."'"));
$ts = mysql_fetch_array(mysql_query("SELECT showx FROM ibwff_users WHERE id='".$uid."'"));
$fd = mysql_fetch_array(mysql_query("SELECT foodx FROM ibwff_users WHERE id='".$uid."' "));
$ar = mysql_fetch_array(mysql_query("SELECT athrx FROM ibwff_users WHERE id='".$uid."'"));
$mv = mysql_fetch_array(mysql_query("SELECT moviex FROM ibwff_users WHERE id='".$uid."'"));
$am = mysql_fetch_array(mysql_query("SELECT animalx FROM ibwff_users WHERE id='".$uid."' "));
$pl = mysql_fetch_array(mysql_query("SELECT placex FROM ibwff_users WHERE id='".$uid."'"));
$tg = mysql_fetch_array(mysql_query("SELECT thingx FROM ibwff_users WHERE id='".$uid."'"));
echo "<form action=\"advanceproc.php?action=fav\" method=\"post\">";
echo "<b>Taem:</b><br/><input name=\"tm\" value=\"$tm[0]\"><br/>";
echo "<b>Band:</b><br/><input name=\"bd\" value=\"$bd[0]\"><br/>";
echo "<b>Music:</b><br/><input name=\"mc\" value=\"$mc[0]\"><br/>";
echo "<b>Tv show:</b><br/><input name=\"ts\" value=\"$ts[0]\"><br/>";
echo "<b>Food:</b><br/><input name=\"fd\" value=\"$fd[0]\"><br/>";
echo "<b>Author:</b><br/><input name=\"ar\" value=\"$ar[0]\"><br/>";
echo "<b>Movie:</b><br/><input name=\"mv\" value=\"$mv[0]\"><br/>";
echo "<b>Animal:</b><br/><input name=\"am\" value=\"$am[0]\"><br/>";
echo "<b>Place:</b><br/><input name=\"pl\" value=\"$pl[0]\"><br/>";
echo "<b>Thing:</b><br/><input name=\"tg\" value=\"$tg[0]\"><br/>";
echo "<input type=\"submit\" value=\"Save\">";
echo "</form>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
//More about me created by CJ UDAY
else if($action="mam")
{
    addonline(getuid_sid($sid),"Updating Advance Profile","advance.php?action=$action");
	    echo "<head>";
    echo "<title>Update More about me</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
    echo "<div class=\"header\" align=\"center\">";
	echo "<b>Update More about me</b></div>";
	echo "<div class=\"shout2\" align=\"left\">";
    include("pm_by.php");
$mam = mysql_fetch_array(mysql_query("SELECT mamx FROM ibwff_users WHERE id='".$uid."'"));
echo "<form action=\"advanceproc.php?action=mam\" method=\"post\">";
echo "<b>More about me:</b><br/><input name=\"mam\" value=\"$mam[0]\"><br/>";
echo "<input type=\"submit\" value=\"Save\">";
echo "</form>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
?>
</html>