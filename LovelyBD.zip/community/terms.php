<?php
 include ("config.php"); 
include ("core.php");

echo("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD XHTML Mobile 1.0//EN\"". " \"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="StyleSheet" type="text/css" href="Styles.css" />
<title>Terms Of FireBD.NeT</title>
<meta forua="true" http-equiv="Cache-Control" content="no-cache"/>
<meta forua="true" http-equiv="Cache-Control" content="must-revalidate"/><?php 
if(!canreg())
{
}else{

?>
<div class="header" align="left"><img src="FireBD.png" alt="FireBD.NeT" width="240" height="50"><br/><b>FireBD.NeT - Terms Of Services (TOS)</b></div>
<div class="shout2" align="left"><div class="div" align="center"><b>UPLOADING:</b></div><br/><u>Shell uploads,illegal file and child porn upload attempts are logged in our server and it is strictly prohibited.</u><br/><br/><div class="div" align="center"><b>ONLINE COMMUNITY:</b></div><br/><u>Never give your username and password to anyone.<br/>Your personal data,password and inboxes are always safe if you don't spam else if your inboxes are not reported.<br/>Do not give your telephone number, home address or email address and please do not include postal addresses of any kind.<br/>If you receive abuse of any other members please contact an admin and do NOT retaliate.<br/>Faking your personal information (like age, sex, location etc..) just to gain access to hidden forums and other content in here,<br/>could result in you being banned, or getting a warning at least.<br/><br/>Posts containing slang,racism, spamming, flooding Or hacking Information will be deleted immediately,<br/>and the posters will get warned or banned.<br/>Harassment and racism will result in a ban, and an permanent IP-Ban if this behavior continues.<br/>ALL Bans are logged as are ALL pms with any form of website links in them,<br/>any pms sent containing weblinks will be moderated and may result in a ban for the sending user for an appropriate length of time...<br/>Registering more than one nickname, could result in all your accounts being deleted.<br/>Using bad usernames for registration will be a result of deletation.<br/><br/>As a member of FireBD you will receive emails for registration,forgot password,updating passwords,etc<br/>and of course special announcements and newsletters from FireBD.</u><br/><br/><div class="div" align="center"><b>HACKING ATTEMPT:</b></div><br/><u>The most important thing is that any kind of hacking attempts are logged in our server.<br/>We reserve the right to report to your I.S.P. as well as your hosting provider in case of hacking attempt.</u><br/><br/><div class="div" align="center"><b>RIGHTS:</b></div><u>We shall not be held liable for any damages incurred by yourself whilst using the site,<br/>nor do we accept responsibilty for any damages incurred from (and the quality of) sites you visit from links provided here.<br/>By using this site, and its database, all data you transmit will become property of FireBD.NeT<br/>and we have the right to access, edit or delete anything contained within our server or database.<br/>We reserve the right to modify the site and terms of usage as we see fit.</u><br/><br/><div class="div" align="center"><b>ABUSE:</b></div><br/><u>We reserve all data, backups, root IP addresses, user identifications very carefully.<br/>So, any kind of serious abuse may commit us to take legal actions against criminals.<br/>Please send any kind of abuse reports via email to: admin@FireBD.NeT<br/><br/>Please allow up to a week for an email response. Note that emailing your complaint to other parties such as our Internet Service Provider will not expedite your request and may result in a delayed response due to the complaint not being filed properly.</u><br/><br/><p align="center"><b>Again the most important rule is to have fun here and enjoy your stay ;)</b></p></div><p align="left"><img src="avatars/home.gif" alt=""><a href="http://FireBD.NeT/community/main.php">Home</a></p> <div class="footer" align="center">2014 <b><a href="http://FireBD.NeT/community/main.php">FireBD.NeT</a></b></div>
</div>





<?php
{

}


}

?>