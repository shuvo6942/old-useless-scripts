<?php
// password recovery
// by bashir
// for community script
// because i'm bored and i'm not in the mood for a movie :-"
// requirements: already build users table & PHP5 MySqLi
// passwords must be encoded
// fields: password varchar, email varchar, keycode varchar(70) it will hold text
// Logic: it will ask the user to enter his email
// he will receive an email with a confirm link valid 24h
// when he access that link he will be asked for a new pass


// settings
$login->host = 'localhost'; // db host
$login->dbname = 'meghwap_forum'; // db name
$login->user = 'meghwap_forum'; // db user
$login->pass = 'meghwap45'; // db pass
$filed->tbname = "ibwff_users"; // users table name
$filed->password = "pass"; // password column name
$filed->password_encode = "md5"; // password encoding: md5,sha1 or none available 
$filed->email = "email"; // email column name
$filed->keycode = "keycode"; // keycode column name
$admin->email = "admin@FireBD.NeT"; // send from email
//-----------------------------------------------------------

session_start();
$db = new mysqli($login->host,$login->user,$login->pass,$login->dbname);


if($_GET['act'] == 'send'){
	if($_POST['_t'] !== $_SESSION['_t'])
		die("Invalid session !");
	 session_destroy();
	if(!filter_var($_POST['email'],FILTER_VALIDATE_EMAIL))
		die('Invalid email');
	
	if($db->query("SELECT `$filed->email` FROM `$filed->tbname` WHERE `$filed->email`='".$db->real_escape_string($_POST['email'])."'")->num_rows == 0)
		die("Invalid email");
	$key[] = $_k = rand();
	$key[] = time();
	if($db->query("UPDATE `$filed->tbname` SET `$filed->keycode`='".serialize($key)."' WHERE `$filed->email`='".$db->real_escape_string($_POST['email'])."' LIMIT 1") !== true)
		die("error".$db->error);

	$link = $_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF']."?act=validate&email=".urlencode($_POST['email'])."&key=$_k";
	
	$to = $_POST['email'];
	$from = 'MIME-Version: 1.0' . "\r\n";
	$from .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
	$from .="From: ".$admin->email;
	$sub = "New Password !";
	$msg = "Hello Dear,<br> You requested for a new password. To confirm, Please <a href='http://$link'>Click Here</a>.<br>If you can't access this link than copy link from below & paste link to your browser & go...<br/><b>http://$link</b>	<br><br>Regards,<br>Administrator<br/><small>Note: Dont reply to this email. If you got this email by mistake then ignore this email.</small>";
	if(mail($to, $sub, $msg,$from))
		echo "An Email With a Confirmation Link Was Sent Successfully To Your Email !<br/><a href=\"main.php\">Back To Main</a>";
	else
		echo "Error with mail() function";
}elseif($_GET['act'] == 'validate'){
	if(!filter_var($_GET['email'],FILTER_VALIDATE_EMAIL))
		die('Invalid email');
	$_data = $db->query("SELECT `$filed->keycode` FROM `$filed->tbname` WHERE `$filed->email`='".$db->real_escape_string($_GET['email'])."'");
	if($_data->num_rows == 0)
		die("Invalid email");
	$_data = $_data->fetch_assoc();
	$_data = @unserialize($_data[$filed->keycode]);
	if(($_data[1] < (time() - (60*60*24))) OR !is_array($_data) OR ($_data[0] != (int)$_GET['key']))
		die("Expiered link");
	
	if(!$_POST){
		echo "<form action='?".$_SERVER["QUERY_STRING"]."' method='post'>
New Password: <input type='password' name='n'><br/>
ReType Password: <input type='password' name='n2'><br/>
<input type='submit' value='Save'>
</form>";
	}else{
		if($_POST['n'] !== $_POST['n2'])
			die("Passwords don't match");
		// update the pass in the db
		if($filed->password_encode == 'md5')
			$new_pass=md5($_POST['n']);
		elseif($filed->password_encode == 'sha1')
			$new_pass=sha1($_POST['n']);
		else
			$new_pass=trim($_POST['n']);
		if($db->query("UPDATE `$filed->tbname` SET `$filed->password`='".$new_pass."', `$filed->keycode`='0' WHERE `$filed->email`='".$db->real_escape_string($_GET['email'])."'") !== false){
			echo "Your New Password Updated Successfully !";
echo "<br/><a href=\"index.php\">Login Here</a>";
		}else{
			echo "Some error camed up while updating new password.";
echo "<br/><a href=\"index.php\">Login Here</a>";
		}
	}
	
}else {
	$_t = $_SESSION['_t'] = md5(rand());
	echo "Email (Your Registered Email In This Site): 
	<form action='?act=send' method='post'>
		<input type='text' name='email'> 
		<input type='submit' value='Recover'>
		<input type='hidden' name='_t' value='$_t'>
	</form><br/><a href=\"index.php\">Back To Main</a>";
}