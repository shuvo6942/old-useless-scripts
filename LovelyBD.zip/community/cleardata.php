<?php
session_start();
include("config.php");
include("core.php");  connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo "<head>";
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"title\" content=\"FireBD.NeT\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From Megh: Don't Try To Hack OR else :P\">
<meta name=\"keywords\" content=\"Site Desined By Megh :) :)\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/></head>";
echo "<body>";
$action = $_GET["action"]; $sid = $_SESSION["sid"];
$clid = $_GET["clid"]; 
$uid = getuid_sid($sid);
////////////////////////////////Data Clear Area By CJ UDAY :) Start\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
if($action=="")
{
echo "<head>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
			echo "<b>Clear Data</b></div>";	
						echo "<div class=\"shout2\" align=\"left\">";
	include("pm_by.php");
	echo "<a href=\"cleardata.php?action=delevt\">&#187;Delete Events(All)</a><br/>";
	echo "<a href=\"cleardata.php?action=delntf\">&#187;Delete Notifications(All)</a><br/>";
	echo "<a href=\"cleardata.php?action=delntfread\">&#187;Delete Notifications(Read)</a><br/>";
	echo "<a href=\"cleardata.php?action=delntfunread\">&#187;Delete Notifications(Unread)</a><br/>";
	echo "<a href=\"cleardata.php?action=delinbx\">&#187;Delete Inboxes(Full Clear)</a><br/>";
    echo "<a href=\"cleardata.php?action=delreadpms\">&#187;Delete Inboxes(Only Read)</a><br/>";
	echo "<a href=\"cleardata.php?action=delunrpms\">&#187;Delete Inboxes(Only Unread)</a><br/>";
    echo "<a href=\"cleardata.php?action=delacrpms\">&#187;Delete Inboxes(Only Acrived)</a><br/>";
    echo "<a href=\"cleardata.php?action=delrepms\">&#187;Delete Inboxes(Only Reported)</a><br/>";
	echo "<a href=\"cleardata.php?action=delinb\">&#187;Delete Inboxes(All Without Acrived)</a><br/>";
echo "<a href=\"cleardata.php?action=clrmlog\">&#187;Delete ModLogs(All)</a><br/>";
	echo "<a href=\"cleardata.php?action=clrlov\">&#187;Delete Lovers(Only For Today)</a><br/>";
	echo "<a href=\"cleardata.php?action=clrmis\">&#187;Delete Missers(Only For Today)</a><br/>";
    echo "<a href=\"cleardata.php?action=delsht\">&#187;Delete Old Shouts(5 Days Ago)</a><br/>";
    echo "<a href=\"cleardata.php?action=delchtpm\">&#187;Delete ChatGirls PM(Incoming)</a><br/>";
    echo "<a href=\"cleardata.php?action=delchtopm\">&#187;Delete ChatGirls PM(Outgoing)</a><br/>";
	echo "<a href=\"cleardata.php?action=delchtsht\">&#187;Delete Shouts(Only ChatGirls Shout)</a><br/>";
	echo "<a href=\"cleardata.php?action=dellstvw\">&#187;Delete Last Viewers(All LastViews)</a><br/>";
	echo "<a href=\"cleardata.php?action=delunvld\">&#187;Delete Members(Only Unvalidate Accounts)</a><br/>";
	echo "<a href=\"cleardata.php?action=deldecaco\">&#187;Delete Members(Only Deactivate Accounts)</a><br/>";   
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
	}
else if($action=="clrmlog")
{
	echo "<head>";
    echo "<title>Delete!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
 $res = mysql_query("DELETE FROM ibwff_mlog");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>All ModLogs Has Been Cleared Successfully!<br/>";
                $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
  mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/]All ModLogs Cleared By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!<br/>";
  }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
}
//////////////////////////clear all events By CJ UDAY :)//////////////////////////
else if($action=="delevt")
{
	echo "<head>";
    echo "<title>Delete!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
 $res = mysql_query("DELETE FROM ibwff_events");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>All Recently Event Has Been Cleared Successfully!<br/>";
              $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
  mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/]All Recently Event Cleared By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!<br/>";
  }
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
 $res = mysql_query("DELETE FROM ibwff_events");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>All Recently Event Has Been Cleared Successfully!<br/>";
              $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
  mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/]All Recently Event Cleared By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!<br/>";
  }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
}
//////////////////////////clear lovers today By CJ UDAY :)//////////////////////////
else if($action=="clrlov")
{
	echo "<head>";
    echo "<title>Delete!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
$a = time() - (24*60*60);
  $res = mysql_query("DELETE FROM ibwff_givelove WHERE date>'$a'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>All Lovers Today Has Been Cleared Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!<br/>";
  }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
}
/////////////////////////clear missers today By CJ UDAY :)//////////////////////////
else if($action=="clrmis")
{
	echo "<head>";
    echo "<title>Delete!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
$a = time() - (24*60*60); 
$res = mysql_query("DELETE FROM ibwff_miss WHERE date>'$a'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>All Missers Today Has Been Cleared Successfully!<br/>";
                }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!<br/>";
  }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
}
//////////////////////////clear inboxs repoted :)//////////////////////////
else if($action=="delrepms")
{
	echo "<head>";
    echo "<title>Delete!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
 $res = mysql_query("DELETE FROM ibwff_private WHERE reported='1'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>All Reported PM Has Been Deleted Sucessfully!<br/>";
          $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
  mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/]All Reported PM Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!<br/>";
  }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
}
//////////////////////////clear inboxs acrived :)//////////////////////////
else if($action=="delacrpms")
{
	echo "<head>";
    echo "<title>Delete!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
 $res = mysql_query("DELETE FROM ibwff_private WHERE starred='1'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>All Acrived PM Has Been Deleted Sucessfully!<br/>";
          $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
  mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/]All Acrived PM Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!<br/>";
  }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
}
//////////////////////////clear inboxs read :)//////////////////////////
else if($action=="delreadpms")
{
	echo "<head>";
    echo "<title>Delete!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
  $res = mysql_query("DELETE FROM ibwff_private WHERE unread='0'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>All Read PM Has Been Deleted Sucessfully!<br/>";
          $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
  mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/]All Read PM Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!<br/>";
  }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
}
//////////////////////////clear inboxs unread :)//////////////////////////
else if($action=="delunrpms")
{
	echo "<head>";
    echo "<title>Delete!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
 $res = mysql_query("DELETE FROM ibwff_private WHERE unread='1'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>All Unread PM Has Been Deleted Sucessfully!<br/>";
          $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
  mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/]All Unread PM Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!<br/>";
  }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
}
//////////////////////////clear all inboxes (without acrived) :)//////////////////////////
else if($action=="delinb")
{
	echo "<head>";
    echo "<title>Delete!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
 $res = mysql_query("DELETE FROM ibwff_private WHERE starred='0'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>All Inbox Messages (without acrived) Has Been Deleted Sucessfully!<br/>";
        $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
  mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/]All Inbox Messages (without acrived) Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!<br/>";
  }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
}
//////////////////////////clear all inboxes (full clear) :)//////////////////////////
else if($action=="delinbx")
{
	echo "<head>";
    echo "<title>Delete!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
  $res = mysql_query("DELETE FROM ibwff_private");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>All Inbox Messages (full cleared) Has Been Deleted Sucessfully!<br/>";
        $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
  mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/]All Inbox Messages (full cleared) Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!<br/>";
  }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
}
//////////////////////////clear notifications :)//////////////////////////
else if($action=="delntf")
{
	echo "<head>";
    echo "<title>Delete!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
  $res = mysql_query("DELETE FROM ibwff_notifications");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>All Notifications Has Been Deleted Sucessfully!<br/>";
      $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
  mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/]All Notifications Has Been Cleared By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!<br/>";
  }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php?action=main&sid=$sid\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
}
//////////////////////////clear read notifications :)//////////////////////////
else if($action=="delntfread")
{
	echo "<head>";
    echo "<title>Delete!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
 $res = mysql_query("DELETE FROM ibwff_notifications WHERE unread='0'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>All Read Notifications Has Been Deleted Sucessfully!<br/>";
      $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
  mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/]All Read Notifications Has Been Cleared By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!<br/>";
  }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
}
//////////////////////////clear unread notifications :)//////////////////////////
else if($action=="delntfunread")
{
	echo "<head>";
    echo "<title>Delete!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
 $res = mysql_query("DELETE FROM ibwff_notifications WHERE unread='1'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>All Unread Notifications Has Been Deleted Sucessfully!<br/>";
      $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
  mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/]All Unread Notifications Has Been Cleared By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!<br/>";
  }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
}
//////////////////////////clear shouts//////////////////////////
else if($action=="delsht")
{
	echo "<head>";
    echo "<title>Delete!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
 $altm = time()-(5*24*60*60);
  $res = mysql_query("DELETE FROM ibwff_shouts WHERE shtime<'".$altm."'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Shouts Older Than 5 Days Ago Deleted Sucessfully!<br/>";
          	$tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
  mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/]Shouts Older Than 5 Days Ago Cleared By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!<br/>";
  }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
}
//////////////////////////clear chat girls shout :)//////////////////////////
else if($action=="delchtsht")
{
	echo "<head>";
    echo "<title>Delete!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
  $res = mysql_query("DELETE FROM ibwff_shouts WHERE shouter='3'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>All ChatGirls Shouts Deleted Successfully!<br/>";
        	$tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
  mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/]All ChatGirls Shouts Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!<br/>";
  }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
}
//////////////////////////clear chat girls incoming pm :)//////////////////////////
else if($action=="delchtpm")
{
	echo "<head>";
    echo "<title>Delete!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
 $res = mysql_query("DELETE FROM ibwff_notifications WHERE byuid='3'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>All ChatGirls Incoming PM Deleted Successfully!<br/>";
        	$tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
  mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/]All ChatGirls Incoming PM Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!<br/>";
  }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
}
//////////////////////////clear chat girls outgoing pm :)//////////////////////////
else if($action=="delchtopm")
{
	echo "<head>";
    echo "<title>Delete!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
 $res = mysql_query("DELETE FROM ibwff_notifications WHERE touid='3'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>All ChatGirls Outgoing PM Deleted Successfully!<br/>";
        	$tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
  mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/]All ChatGirls Outgoing PM Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!<br/>";
  }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
}
//////////////////////////clear lastview :)//////////////////////////
else if($action=="dellstvw")
{
	echo "<head>";
    echo "<title>Delete!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
  $res = mysql_query("DELETE FROM ibwff_lastview");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>All LastViews Deleted Successfully!<br/>";
      	$tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
  mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/]All ChatGirls LastViews Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!<br/>";
  }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
}
//////////////////////////clear all unvalidated members :)//////////////////////////
else if($action=="delunvld")
{
	echo "<head>";
    echo "<title>Delete!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
 $res = mysql_query("DELETE FROM ibwff_users WHERE validated='0'");
 if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>All Unvalidate Accounts Deleted Successfully!<br/>";
    	$tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
  mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/]All Unvalidated Accounts Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!<br/>";
  }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
}
//////////////////////////clear all deactivated members  :)//////////////////////////
else if($action=="deldecaco")
{
	echo "<head>";
    echo "<title>Delete!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
 $res = mysql_query("DELETE FROM ibwff_users WHERE diactivate='1'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>All Deactivated Accounts Deleted Successfully!<br/>";
  	$tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
  mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/]All Deactivated Accounts Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!<br/>";
  }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
}
?>
</html>