<?php
$xid = getuid_sid($sid);
$umsg = getunreadpm(getuid_sid($sid));
$notify = notification(getuid_sid($sid));
$chs = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_chonline"));
echo "<b><a href=\"../community/main.php\">Menu</a> | ";
echo "<a href=\"../community/profile.php?who=$xid\">Profile</a> | ";
echo "<a href=\"../community/notification.php\">Notifications</a> ($notify) | ";
echo "<a href=\"../community/inbox.php\">Messages</a> ($umsg) | ";
echo "<a href=\"../community/ch@t.php?action=chat\">Chat</a> ($chs[0])</b><br/>";
?>