<?php
session_start();
include("config.php");
include("core.php");  connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo '<head>';
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"title\" content=\"Firebd.net\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From Shahos: Don't Try To Hack OR else :P\">
<meta name=\"keywords\" content=\"Site Desined By Shahos :) :)\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/></head>";
echo "<body>";
$action = $_GET["action"]; $sid = $_SESSION["sid"];
$clid = $_GET["clid"]; $page = $_GET["page"];
$who = $_GET["who"];
$uid = getuid_sid($sid);
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();
////////////////Ip Banned By CJ UDAY :)	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
    echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
echo "<br/>";
echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
$banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
$remain =  $banto[0] - time();
$rmsg = gettimemsg($remain);
echo "<b>Time Remaining: $rmsg</b><br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "</p>";
echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
/////////////////Banned System Updated By CJ UDAY :)
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please Contact <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
 echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
  include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
 echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
///////////////////Deactivated Account By CJ UDAY :)
          if(isdeactivated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  <b>Your Account Has Been Deactivated Forever.<br/>And It Will Be Never Activate!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
///////////////////Validation By CJ UDAY :)
					if(isvalidated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  You Are Not Validated!<br/>We are checking your ip and browser<br/>
	  This could take up to 15 munites pls be patient and try again soon<br/>Please try again later...<br/><b>Thank You</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
//////////////////Status Comments Updated By CJ UDAY :)
if($action=="")
{
  addonline(getuid_sid($sid),"Viewing Status Comments","scomments.php?action=$action");
	    echo "<head>";
    echo "<title>View Status Commnets</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
						echo "<div class=\"header\" align=\"center\">";
			echo "<b>Status Comment</b></div>";
  echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$statusid = $_GET['statusid'];
if($page=="" || $page<=0) {$page=1;}
$count = mysql_fetch_assoc(mysql_query("SELECT COUNT(*) page FROM ibwff_scomments WHERE statusid='".$statusid."'"));
$num_items = $count['page'];
$event_per_page= 7;
$num_pages = ceil($num_items/$event_per_page);
if(($page>$num_pages)&&$page!=1) {$page= $num_pages;}
$limit_start = ($page-1)*$event_per_page;
$status = mysql_fetch_array(mysql_query("SELECT status, uid FROM ibwff_mindstatus11 WHERE id='".$statusid."'"));
$shnick = subnick(getnick_uid($status[1]));
	    $sql = "SELECT name FROM ibwff_users WHERE id=$status[1]";
	    $sql2 = mysql_query($sql);
	    $item = mysql_fetch_array($sql2);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item[0]'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/>";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/>";}
if($sex[0]==""){$usersex = "";}
        		$avlink = getavatar($status[1]);
if($avlink=="")
{
 $avt =  "$usersex";
}else{
 $avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"icon\" width=\"23\" height=\"18\"/>";
}
	    $sql3 = "SELECT name FROM ibwff_users WHERE id=$status[1]";
	    $sql33 = mysql_query($sql3);
	    $item3 = mysql_fetch_array($sql33);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nicks = "<font color=\"blue\"><b>".$shnick."</b></font>";}
if($sex[0]=="F"){$nicks = "<font color=\"deeppink\"><b>".$shnick."</b></font>";}
if($sex[0]==""){$nicks = "";}
$text = parsepm($status[0],$sid);
echo '</p><p align="center">';
echo "<b>[<a href=\"profile.php?who=$status[1]\">".$avt."".$nicks."</a>]</b><br/>";
}
}
echo "$text<br/><br/><b>[Id:</b>$statusid<b>]</b><br/><br/>";
$counts = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_statuslike WHERE statusid='".$statusid."'"));
$counts1 = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_statusdislike WHERE statusid='".$statusid."'"));
if($counts[0]>0)
{
$lyk = "<a href=\"statuslike.php?who=$who&statusid=$statusid\">$counts[0]</a>";
}else{
$lyk = "<a href=\"statuslike.php?who=$who&statusid=$statusid\">$counts[0]</a>";
}
if($counts1[0]>0)
{
$dislyk = "<a href=\"statusdislike.php?who=$who&statusid=$statusid\">$counts1[0]</a>";
}else{
$dislyk = "<a href=\"statusdislike.php?who=$who&statusid=$statusid\">$counts1[0]</a>";
}
echo "<b>";
echo "<img src=\"like.png\" alt=\"*\" /><a href=\"mindstatus.php?action=like&who=$who&id=".$statusid."\">Like</a> ($lyk) ";
echo "<img src=\"dislike.png\" alt=\"*\" /><a href=\"mindstatus.php?action=dislike&who=$who&id=".$statusid."\">Dislike</a> ($dislyk)<br/><br/>";
echo "</b>";
echo "</p>";
echo "<p align=\"left\">";
$scomm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_scomments WHERE statusid='".$statusid."'"));
if($scomm[0]>0)
{
$scomment2 = "<b>Status Comments:</b><br/><br/>";
}else{
$scomment2 = "";
}
echo "$scomment2";
$results = mysql_query("SELECT * FROM ibwff_scomments WHERE statusid='".$statusid."' ORDER BY stime ASC LIMIT $limit_start, $event_per_page");
while ($event = mysql_fetch_assoc($results)){
$user = $event['uid'];
$unick = subnick(getnick_uid($user));
	    $sql = "SELECT name FROM ibwff_users WHERE id=$user";
	    $sql2 = mysql_query($sql);
	    $item = mysql_fetch_array($sql2);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item[0]'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/>";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/>";}
if($sex[0]==""){$usersex = "";}
        		$avlink = getavatar($user);
if($avlink=="")
{
 $avt =  "$usersex";
}else{
 $avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"icon\" width=\"23\" height=\"18\"/>";
}
	    $sql3 = "SELECT name FROM ibwff_users WHERE id=$user";
	    $sql33 = mysql_query($sql3);
	    $item3 = mysql_fetch_array($sql33);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nicks = "<font color=\"blue\"><b>$unick</b></font>";}
if($sex[0]=="F"){$nicks = "<font color=\"deeppink\"><b>$unick</b></font>";}
if($sex[0]==""){$nicks = "";}
echo "<a href=\"profile.php?who=$user\">$avt$nicks</a>: ";
}
}
echo getbbcode($event[scomments],$sid,1)."<br/>";
echo "<small>".gmstrftime("%d %B,%Y - %H:%M:%S %p",$event['stime'])."</small><br/>
--------------------<br/>";
}
$scomm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_scomments WHERE statusid='".$statusid."'"));
if($scomm[0]>0)
{
$scomment = "";
}else{
$scomment = "<b>Status Comments:</b><br/><img src=\"../avatars/notok.gif\" alt=\"X\">This status has no comment!";
}
echo "$scomment";
  echo "<form action=\"scomments.php?action=addcomm&who=$who&statusid=$statusid\" method=\"post\">";
 echo "<b>Comments:</b><br/>";
  echo "<input type=\"text\" name=\"scomments\"/>";
 echo "<input type=\"submit\" value=\"Add\"/>";
echo "</form>";
echo "</p><p align=\"center\">";
if($page>1)
    {
      $ppage = $page-1;
      echo "<a href=\"scomments.php?page=$ppage&who=$who&statusid=$statusid\">&#171;-Prev</a> ";
    }
    if($page<$num_pages)
    {
      $npage = $page+1;
      echo "<a href=\"scomments.php?page=$npage&who=$who&statusid=$statusid\">Next-&#187;</a>";
    }
    echo "<br/>Page - $page/$num_pages<br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
    }
//////////////////////////////Status Comments By CJ UDAY :)
else if($action=="addcomm")
{
  addonline(getuid_sid($sid),"Adding Status Comment","scomments.php?action=$action");
	    echo "<head>";
    echo "<title>Add Status Comments</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
						echo "<div class=\"header\" align=\"center\">";
			echo "<b>Add Status Comment</b></div>";
  echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$statusid = $_GET['statusid'];
$stext = $_POST['scomments'];
$user = getnick_uid($uid);
$stime = time();
$uid = getuid_sid($sid);
$status = mysql_fetch_array(mysql_query("SELECT status, uid FROM ibwff_mindstatus11 WHERE id='".$statusid."'"));
    $who = $_POST["$status[1]"];
    if(getplusses(getuid_sid($sid))<30)
    {
	$shout = 30 - getplusses($uid);
	echo "<p align=\"left\">";
        echo "<br/><img src=\"../avatars/notok.gif\">You Need $shout Points Add A Comment!<br/>
		<a href=\"forums.php?tid=2\">How To Get Points??</a><br/><br/></p>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
    exit();
    }
if(trim($stext)!="4" && strlen($stext) > "2"){
mysql_query("INSERT INTO ibwff_scomments SET statusid='".$statusid."', scomments='".$stext."', uid='".$uid."', stime='".$stime."'");
mysql_query("UPDATE ibwff_mindstatus11 SET lastupdate='".$stime."' WHERE id='".$statusid."'");
echo "<br/><img src=\"../avatars/ok.gif\" alt=\"O\"/>Status Comment Added Successfully!<br/><br/>";
$w3btime = time();
$user = getnick_uid($uid);
$status = mysql_fetch_array(mysql_query("SELECT statusid, uid FROM ibwff_mindstatus11 WHERE id='".$statusid."'"));
$who = parsepm($status[1],$sid);
$whonick = getnick_uid($who);
		$res2 = mysql_fetch_array(mysql_query("SELECT status,uid FROM ibwff_mindstatus11 WHERE id='".$statusid."'"));
	    $commenter = getnick_sid($sid);
		$stname = htmlspecialchars($res2[0]);
mysql_query("INSERT INTO ibwff_notifications SET text='Your Status [statuscom=$statusid]$stname"."[/statuscom] Has Been Commented By [user=$uid]$commenter"."[/user]', touid='".$res2[1]."', timesent='".time()."'");
} else {
echo "<br/><img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Status Comment Is Too Small<br/>Please Write 2 Or More Digits!<br/><br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
?>
</html>