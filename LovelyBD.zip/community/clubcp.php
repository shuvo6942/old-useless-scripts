<?php
session_start();
include("config.php");
include("core.php");  connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo '<head>';
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"title\" content=\"FireBD.NeT\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From Megh: Don't Try To Hack OR else :P\">
<meta name=\"keywords\" content=\"Site Desined By Megh :) :)\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/></head>";
echo "<body>";
$action = $_GET["action"]; $sid = $_SESSION["sid"];
$page = $_GET["page"];
$who = $_GET["who"];
$uid = getuid_sid($sid);
$name = $_GET["name"];
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();
////////////////Ip Banned By CJ UDAY :)	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
    echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
	echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
      echo "<br/>";
      echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
      $banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
      $remain =  $banto[0] - time();
      $rmsg = gettimemsg($remain);
      echo "<b>Time Remaining: $rmsg</b><br/>";
      $nick = getnick_uid($banto[2]);
       $text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
      echo "</p>";
    	echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
    echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
    echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
//////////////////Banned System Updated By CJ UDAY :)
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please With Contact Us <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
 echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
///////////////////Validation By CJ UDAY :)
					if(isvalidated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
	echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  You Are Not Validated!<br/>We are checking your ip and browser<br/>
	  This could take up to 15 munites pls be patient and try again soon<br/>Please try again later...<br/><b>Thank You</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }

///////////////////Deactivated Account By CJ UDAY :)
          if(isdeactivated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  <b>Your Account Has Been Deactivated Forever.<br/>And It Will Be Never Activate!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="accept")
{
$who = $_GET["who"];
$whn = subnick(getnick_uid($who));
$clid = $_GET["clid"];
    addonline(getuid_sid($sid),"Adding Club Members","");
   echo "<head>";
echo "<title>Accepting Club Join Request</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";				
include("header.php");
echo "</div>";  
echo "<div class=\"header\" align=\"center\">";
echo "<b>Accepting Join Request</b></div>";
						echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$uday = mysql_query("UPDATE ibwff_clubmembers SET accepted='1' WHERE uid='".$who."' AND clid='".$clid."'");
if($uday)
{
echo "<img src=\"ok.gif\" alt=\"O\"> $whn's request to join this club accepted successfully!";
//N0TIFICATION :-)
$a = getnick_sid($sid);
$f = "[b]Club Notification For Owner:[/b] ".$whn."s request to join ".getclubname($clid)." was accepted by ".$a."";
$x = mysql_fetch_array(mysql_query("SELECT owner FROM ibwff_clubs WHERE id='".$clid."'")); 
notify($f,$x[0]);
}else{
echo "<img src=\"../avatars/notok.gif\" alt=\"x\"> $whn's request to join this club cannot be accepted at this moment!";
} 
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
else if($action=="reject")
{
$who = $_GET["who"];
$whn = subnick(getnick_uid($who));
$clid = $_GET["clid"];
    addonline(getuid_sid($sid),"Cancelling Club Members","");
   echo "<head>";
echo "<title>Rejecting Club Join Request</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";				
include("header.php");
echo "</div>";  
echo "<div class=\"header\" align=\"center\">";
echo "<b>Rejecting Join Request</b></div>";
						echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$uday = mysql_query("DELETE FROM ibwff_clubmembers  WHERE accepted='0' AND uid='".$who."' AND clid='".$clid."'");
if($uday)
{
echo "<img src=\"ok.gif\" alt=\"O\"> $whn's request to join this club rejected successfully!";
//N0TIFICATION :-)
$a = getnick_sid($sid);
$f = "[b]Club Notification For Owner:[/b] ".$whn."s request to join ".getclubname($clid)." was rejcted by ".$a."";
$x = mysql_fetch_array(mysql_query("SELECT owner FROM ibwff_clubs WHERE id='".$clid."'")); 
notify($f,$x[0]);
}else{
echo "<img src=\"../avatars/notok.gif\" alt=\"x\"> $whn's request to join this club cannot be rejected at this moment!";
} 
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
else if($action=="acceptall")
{
$who = $_GET["who"];
$whn = subnick(getnick_uid($who));
$clid = $_GET["clid"];
    addonline(getuid_sid($sid),"Adding All Club Members","");
   echo "<head>";
echo "<title>Accepting All Club Join Request</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";				
include("header.php");
echo "</div>";  
echo "<div class=\"header\" align=\"center\">";
echo "<b>Accepting All Join Requests</b></div>";
						echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$uday = mysql_query("UPDATE ibwff_clubmembers SET accepted='1' WHERE clid='".$clid."' AND accepted='0'");
if($uday)
{
echo "<img src=\"ok.gif\" alt=\"O\"> All request to join this club rejected successfully!";
//N0TIFICATION :-)
$a = getnick_sid($sid);
$f = "[b]Club Notification For Owner:[/b] All request to join ".getclubname($clid)." was accepted by ".$a."";
$x = mysql_fetch_array(mysql_query("SELECT owner FROM ibwff_clubs WHERE id='".$clid."'")); 
notify($f,$x[0]);
}else{
echo "<img src=\"../avatars/notok.gif\" alt=\"x\"> All request to join this club cannot be accepted at this moment!";
} 
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
else if($action=="rejectall")
{
$who = $_GET["who"];
$whn = subnick(getnick_uid($who));
$clid = $_GET["clid"];
    addonline(getuid_sid($sid),"Canceling All Club Members","");
   echo "<head>";
echo "<title>Rejecting All Club Join Request</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";				
include("header.php");
echo "</div>";  
echo "<div class=\"header\" align=\"center\">";
echo "<b>Rejecting All Join Requests</b></div>";
						echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$uday = mysql_query("DELETE FROM ibwff_clubmembers  WHERE accepted='0' AND clid='".$clid."'");
if($uday)
{
echo "<img src=\"ok.gif\" alt=\"O\"> All request to join this club rejected successfully!";
//N0TIFICATION :-)
$a = getnick_sid($sid);
$f = "[b]Club Notification For Owner:[/b] All request to join ".getclubname($clid)." was rejcted by ".$a."";
$x = mysql_fetch_array(mysql_query("SELECT owner FROM ibwff_clubs WHERE id='".$clid."'")); 
notify($f,$x[0]);
}else{
echo "<img src=\"../avatars/notok.gif\" alt=\"x\"> $whn's request to join this club cannot be rejected at this moment!";
} 
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}

else if($action=="pointa")
{
$who = $_GET["who"];
$whn = subnick(getnick_uid($who));
$clid = $_GET["clid"];
    addonline(getuid_sid($sid),"Moderating Club Members","");
   echo "<head>";
echo "<title>Give Points</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";				
include("header.php");
echo "</div>";  
echo "<div class=\"header\" align=\"center\">";
echo "<b>Giving Points</b></div>";
						echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<p align=\"left\">";
echo "<form action=\"clubcp.php?action=paconf&who=$who&clid=$clid\" method=\"post\">";
echo "<b>Ammount Of Point:</b><br/><input name=\"udayp\" maxlength=\"4\">";
echo "<br/><input type=\"submit\" value=\"Give\">";
echo "</form>";
echo "<img src=\"p.gif\" alt=\"!\"> <b>Note:</b> Don't misuse or give club point to the user without any exact reason. If you do that, your club will deleted and you will be punished.";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
else if($action=="pointc")
{
$who = $_GET["who"];
$whn = subnick(getnick_uid($who));
$clid = $_GET["clid"];
    addonline(getuid_sid($sid),"Moderating Club Members","");
   echo "<head>";
echo "<title>Cut Points</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";				
include("header.php");
echo "</div>";  
echo "<div class=\"header\" align=\"center\">";
echo "<b>Cutting Points</b></div>";
						echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<p align=\"left\">";
echo "<form action=\"clubcp.php?action=pcconf&who=$who&clid=$clid\" method=\"post\">";
echo "<b>Ammount Of Point:</b><br/><input name=\"udayp\" maxlength=\"4\">";
echo "<br/><input type=\"submit\" value=\"Cut\">";
echo "</form>";
echo "<img src=\"p.gif\" alt=\"!\"> <b>Note:</b> Don't misuse or cut club point from the user without any exact reason. If you do that, your club will deleted and you will be punished.";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
else if($action=="ban")
{
$who = $_GET["who"];
$whn = subnick(getnick_uid($who));
$clid = $_GET["clid"];
    addonline(getuid_sid($sid),"Moderating Club Members","");
   echo "<head>";
echo "<title>Ban A Member</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";				
include("header.php");
echo "</div>";  
echo "<div class=\"header\" align=\"center\">";
echo "<b>Ban Member</b></div>";
						echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$uday = mysql_query("UPDATE ibwff_clubmembers SET banned='1' WHERE uid=$who AND clid=$clid");
if($uday)
{
echo "<img src=\"ok.gif\" alt=\"o\"> $whn banned successfully!";
$n = subnick(getnick_sid($sid));
$m = "[b]Club Notifications:[/b] [user=$who]".$whn."[/user] is now banned from ".getclubname($clid)." by ".$n."";
clubnot_uday($clid,$m);
$f = "[user=$who]".$whn."[/user] is now banned from ".getclubname($clid)." by ".$n."";
clubhis_uday($f,$clid);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> Cannot banned $whn at this moment.";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
else if($action=="unban")
{
$who = $_GET["who"];
$whn = subnick(getnick_uid($who));
$clid = $_GET["clid"];
    addonline(getuid_sid($sid),"Moderating Club Members","");
   echo "<head>";
echo "<title>Unban A Member</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";				
include("header.php");
echo "</div>";  
echo "<div class=\"header\" align=\"center\">";
echo "<b>Unban Member</b></div>";
						echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$uday = mysql_query("UPDATE ibwff_clubmembers SET banned='0' WHERE uid=$who AND clid=$clid");
if($uday)
{
echo "<img src=\"ok.gif\" alt=\"o\"> $whn unbanned successfully!";
$n = subnick(getnick_sid($sid));
$m = "[b]Club Notifications:[/b] [user=$who]".$whn."[/user] is now unbanned from ".getclubname($clid)." by ".$n."";
clubnot_uday($clid,$m);
$f = "[user=$who]".$whn."[/user] is now unbanned from ".getclubname($clid)." by ".$n."";
clubhis_uday($clid,$f);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> Cannot unbanned $whn at this moment.";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
else if($action=="mod")
{
$who = $_GET["who"];
$whn = subnick(getnick_uid($who));
$clid = $_GET["clid"];
    addonline(getuid_sid($sid),"Moderating Club Members","");
   echo "<head>";
echo "<title>Make Moderator</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";				
include("header.php");
echo "</div>";  
echo "<div class=\"header\" align=\"center\">";
echo "<b>Make Moderator</b></div>";
						echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$uday = mysql_query("UPDATE ibwff_clubmembers SET power='1' WHERE uid=$who AND clid=$clid");
if($uday)
{
echo "<img src=\"ok.gif\" alt=\"o\"> $whn make moderator successfully!";
$m = "[b]Club Notifications:[/b] [user=$who]".$whn."[/user] is now club moderator of ".getclubname($clid)."";
clubnot_uday($clid,$m);
$f = "[user=$who]".$whn."[/user] is now club moderator of ".getclubname($clid)."";
clubhis_uday($clid,$f);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> Cannot make $whn club moderator at this moment.";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
else if($action=="demod")
{
$who = $_GET["who"];
$whn = subnick(getnick_uid($who));
$clid = $_GET["clid"];
    addonline(getuid_sid($sid),"Moderating Club Members","");
   echo "<head>";
echo "<title>Remove From Moderator</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";				
include("header.php");
echo "</div>";  
echo "<div class=\"header\" align=\"center\">";
echo "<b>Remove From Moderator</b></div>";
						echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$uday = mysql_query("UPDATE ibwff_clubmembers SET power='0' WHERE uid=$who AND clid=$clid");
if($uday)
{
echo "<img src=\"ok.gif\" alt=\"o\"> $whn removed from moderator successfully!";
$m = "[b]Club Notifications:[/b] [user=$who]".$whn."[/user] is now remove from club moderator on ".getclubname($clid)."";
clubnot_uday($clid,$m);
$f = "[user=$who]".$whn."[/user] is now removed from club moderator on ".getclubname($clid)."";
clubhis_uday($clid,$f);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> Cannot remove $whn from club moderator at this moment.";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
else if($action=="vip")
{
$who = $_GET["who"];
$whn = subnick(getnick_uid($who));
$clid = $_GET["clid"];
    addonline(getuid_sid($sid),"Moderating Club Members","");
   echo "<head>";
echo "<title>Make Vip</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";				
include("header.php");
echo "</div>";  
echo "<div class=\"header\" align=\"center\">";
echo "<b>Make Vip</b></div>";
						echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$uday = mysql_query("UPDATE ibwff_clubmembers SET vip='1' WHERE uid=$who AND clid=$clid");
if($uday)
{
echo "<img src=\"ok.gif\" alt=\"o\"> $whn make vip successfully!";
$m = "[b]Club Notifications:[/b] [user=$who]".$whn."[/user] is now club vip of ".getclubname($clid)."";
clubnot_uday($clid,$m);
$f = "[user=$who]".$whn."[/user] is now club vip of ".getclubname($clid)."";
clubhis_uday($clid,$f);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> Cannot make $whn club vip at this moment.";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
else if($action=="unvip")
{
$who = $_GET["who"];
$whn = subnick(getnick_uid($who));
$clid = $_GET["clid"];
    addonline(getuid_sid($sid),"Moderating Club Members","");
   echo "<head>";
echo "<title>Make Normal</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";				
include("header.php");
echo "</div>";  
echo "<div class=\"header\" align=\"center\">";
echo "<b>Make Normal</b></div>";
						echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$uday = mysql_query("UPDATE ibwff_clubmembers SET vip='0' WHERE uid=$who AND clid=$clid");
if($uday)
{
echo "<img src=\"ok.gif\" alt=\"o\"> $whn make normal successfully!";
$m = "[b]Club Notifications:[/b] [user=$who]".$whn."[/user] is now normal from vip at ".getclubname($clid)."";
clubnot_uday($clid,$m);
$f = "[user=$who]".$whn."[/user] is now normal from vip at ".getclubname($clid)."";
clubhis_uday($clid,$f);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> Cannot make $whn normal at this moment.";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
else if($action=="delete")
{
$who = $_GET["who"];
$whn = subnick(getnick_uid($who));
$clid = $_GET["clid"];
    addonline(getuid_sid($sid),"Moderating Club Members","");
   echo "<head>";
echo "<title>Remove Member</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";				
include("header.php");
echo "</div>";  
echo "<div class=\"header\" align=\"center\">";
echo "<b>Remove Member</b></div>";
						echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$uday = mysql_query("DELETE FROM ibwff_clubmembers WHERE uid=$who AND clid=$clid");
if($uday)
{
echo "<img src=\"ok.gif\" alt=\"o\"> $whn removed successfully!";
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> Cannot remove $whn from club at this moment.";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
else if($action=="paconf")
{
$who = $_GET["who"];
$whn = subnick(getnick_uid($who));
$clid = $_GET["clid"];
    addonline(getuid_sid($sid),"Moderating Club Members","");
   echo "<head>";
echo "<title>Give Point</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";				
include("header.php");
echo "</div>";  
echo "<div class=\"header\" align=\"center\">";
echo "<b>Give Point</b></div>";
						echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$p = $_POST["udayp"];
$uday = mysql_query("UPDATE ibwff_clubmembers SET points=points+$p WHERE uid=$who AND clid=$clid");
if($uday)
{
echo "<img src=\"ok.gif\" alt=\"o\"> $p point was given to $whn successfully!";
mysql_query("UPDATE ibwff_clubs SET plusses=plusses+$p WHERE id='".$clid."'");
$x = mysql_fetch_array(mysql_query("SELECT owner FROM ibwff_clubs WHERE id='".$clid."'"));
$n = subnick(getnick_sid($sid));
$m = "[b]Club Notification For Owner:[/b] [user=$who]".$whn."[/user] got ".$p." points on ".getclubname($clid)." by ".$n."";
notify($m,$x[0]);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> Cannot give point to $whn at this moment.";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
else if($action=="pcconf")
{
$who = $_GET["who"];
$whn = subnick(getnick_uid($who));
$clid = $_GET["clid"];
    addonline(getuid_sid($sid),"Moderating Club Members","");
   echo "<head>";
echo "<title>Cut Point</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";				
include("header.php");
echo "</div>";  
echo "<div class=\"header\" align=\"center\">";
echo "<b>Cut Point</b></div>";
$n=subnick(getnick_sid($sid));
						echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$p = $_POST["udayp"];
$uday = mysql_query("UPDATE ibwff_clubmembers SET points=points-$p WHERE uid=$who AND clid=$clid");
if($uday)
{
echo "<img src=\"ok.gif\" alt=\"o\"> $p point was cutted from $whn successfully!";
mysql_query("UPDATE ibwff_clubs SET plusses=plusses-$p WHERE id='".$clid."'");
$x = mysql_fetch_array(mysql_query("SELECT owner FROM ibwff_clubs WHERE id='".$clid."'"));
$n = subnick(getnick_sid($sid));
$m = "[b]Club Notification For Owner:[/b] [user=$who]".$whn."[/user] lost ".$p." points on ".getclubname($clid)." cutted by ".$n."";
notify($m,$x[0]);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> Cannot cut point from $whn at this moment.";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
?>
</html>