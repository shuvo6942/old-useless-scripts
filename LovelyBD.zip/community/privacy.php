<?php
session_start();
include("config.php");
include("core.php");  connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo '<head>';
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"title\" content=\"firebd.net\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From Shahos: Don't Try To Hack OR else :P\">
<meta name=\"keywords\" content=\"Site Desined By Shahos :) :)\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/></head>";
echo "<body>";
$action = $_GET["action"]; $sid = $_SESSION["sid"];
$uid = getuid_sid($sid);
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();
////////////////Ip Banned By CJ UDAY :)	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
    echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
echo "<br/>";
echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
$banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
$remain =  $banto[0] - time();
$rmsg = gettimemsg($remain);
echo "<b>Time Remaining: $rmsg</b><br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "</p>";
echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
   }
//////////////////Banned System Updated By CJ UDAY :)
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please Contact <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
 echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
 echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some privacy reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");  
echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
///////////////////Validation By CJ UDAY :)
					if(isvalidated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  You Are Not Validated!<br/>We are checking your ip and browser<br/>
	  This could take up to 15 munites pls be patient and try again soon<br/>Please try again later...<br/><b>Thank You</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
////////////////////////Privacy By CJ UDAY :)
if($action=="")
{
  addonline(getuid_sid($sid),"Updating Profile Privacy","privacy.php?action=$action");
    echo "<head>";
    echo "<title>Update Profie Privacy</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
			echo "<b>Privacy Setting</b></div>";
			echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<form action=\"privacy.php?action=uday&sid=$sid\" method=\"post\">";
$uday = mysql_fetch_array(mysql_query("SELECT prof FROM ibwff_users WHERE id='".$uid."'"));
$uday2 = mysql_fetch_array(mysql_query("SELECT diary_uday FROM ibwff_users WHERE id='".$uid."'"));
$uday3 = mysql_fetch_array(mysql_query("SELECT pm FROM ibwff_users WHERE id='".$uid."'"));
$uday4 = mysql_fetch_array(mysql_query("SELECT conf FROM ibwff_users WHERE id='".$uid."'"));
$uday5 = mysql_fetch_array(mysql_query("SELECT relreq FROM ibwff_users WHERE id='".$uid."'"));
$uday6 = mysql_fetch_array(mysql_query("SELECT frreq FROM ibwff_users WHERE id='".$uid."'"));
$uday7 = mysql_fetch_array(mysql_query("SELECT frlist FROM ibwff_users WHERE id='".$uid."'"));
$uday8 = mysql_fetch_array(mysql_query("SELECT apics FROM ibwff_users WHERE id='".$uid."'"));
$uday9 = mysql_fetch_array(mysql_query("SELECT ask FROM ibwff_users WHERE id='".$uid."'"));
$uday10 = mysql_fetch_array(mysql_query("SELECT gbok FROM ibwff_users WHERE id='".$uid."'"));
$uday11 = mysql_fetch_array(mysql_query("SELECT sub FROM ibwff_users WHERE id='".$uid."'"));
$uday11 = mysql_fetch_array(mysql_query("SELECT privacy FROM ibwff_users WHERE id='".$uid."'"));
$prof = $uday[0];
$diary = $uday2[0];
$pm = $uday3[0];
$conf = $uday4[0];
$relreq = $uday5[0];
$frreq = $uday6[0];
$sub = $uday11[0];
$frlist = $uday7[0];
$apics = $uday8[0];
$ask = $uday9[0];
$gbook = $uday10[0];
$like = $uday11[0];
echo "<b>Profile Privacy Settings:</b><br/>";
echo "<onevent type=\"onenterforward\">";
echo "<refresh>
<setvar name=\"prof\" value=\"$prof\"/>
<setvar name=\"diary\" value=\"$diary\"/>
<setvar name=\"pm\" value=\"$pm\"/>
<setvar name=\"conf\" value=\"$conf\"/>
<setvar name=\"relreq\" value=\"$relreq\"/>
<setvar name=\"frreq\" value=\"$frreq\"/>
<setvar name=\"sub\" value=\"$sub\"/>
<setvar name=\"frlist\" value=\"$frlist\"/>
<setvar name=\"apics\" value=\"$apics\"/>
<setvar name=\"ask\" value=\"$ask\"/>
<setvar name=\"gbok\" value=\"$gbook\"/>
<setvar name=\"like\" value=\"$like\"/>
";
echo "</refresh></onevent>";
echo "Who Can See Your Profile?<br/>";
echo "<select name=\"prof\" value=\"$prof\"/>";
echo "<option value=\"0\">Everyone</option>
<option value=\"1\">Only Friends</option>";
echo "</select>";
echo "<br/>Who Can See Your Diary?<br/>";
echo "<select name=\"diary\" value=\"1\"/>";
echo "<option value=\"0\">Only Me</option>
<option value=\"1\">Everyone</option>";
echo "</select>";
echo "<br/>Who Can Send You Messages?<br/>";
echo "<select name=\"pm\" value=\"$pm\"/>";
echo "<option value=\"0\">Everyone</option>
<option value=\"1\">Only Friends</option>";
echo "</select>";
echo "<br/>Who Can Conferance With You?<br/>";
echo "<select name=\"conf\" value=\"$conf\">
<option value=\"0\">Everyone</option>
<option value=\"1\">Only Friends</option>";
echo "</select>";
echo "<br/>Who Can Send You A Reletionship Request?<br/>";
echo "<select name=\"relreq\" value=\"$relreq\">
<option value=\"0\">Only Friends</option>
<option value=\"1\">Everyone</option>";
echo "</select>";
echo "<br/>Who Can Send You Friend Request?<br/>";
echo "<select name=\"frreq\" value=\"$frreq\">
<option value=\"0\">Everyone</option>
<option value=\"1\">None, Only I Will Send</option>";
echo "</select>";
echo "<br/>Who Can Subscribe You?<br/>";
echo "<select name=\"sub\" value=\"$sub\">
<option value=\"0\">Everyone</option>
<option value=\"1\">Only Friends</option>";
echo "</select>";
echo "<br/><br/><b>Extra Privacy:</b>";
echo "<br/>Friend & Relative List:<br/>";
echo "<select name=\"frlist\" value=\"$frlist\">
<option value=\"0\">Open</option>
<option value=\"1\">Hide</option>";
echo "</select>";
echo "<br/>Download Of Album Pics:<br/>";
echo "<select name=\"apics\" value=\"$apics\">
<option value=\"0\">Enabled</option>
<option value=\"1\">Disabled</option>";
echo "</select>";
echo "<br/>AskME:<br/>";
echo "<select name=\"ask\" value=\"$ask\">
<option value=\"0\">Enabled</option>
<option value=\"1\">Disabled</option>";
echo "</select>";
echo "<br/>Guestbook:<br/>";
echo "<select name=\"gbok\" value=\"$gbook\">
<option value=\"0\">Enabled</option>
<option value=\"1\">Disabled</option>";
echo "</select>";
echo "<br/>Profile Can Be Liked By:<br/>";
echo "<select name=\"like\" value=\"$like\">
<option value=\"0\">Everyone</option>
<option value=\"1\">Only Friends</option>";
echo "</select>";
echo "<br/><input type=\"submit\" value=\"Update\">";
echo "</form>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
/////Privacy Updater By CJ UDAY :-)
else if($action=="uday")
{
addonline(getuid_sid($sid),"Updating Profile Privacy","privacy.php?action=$action");
    echo "<head>";
    echo "<title>Update Profie Privacy</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
			echo "<b>Privacy Setting</b></div>";
			echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$prof = $_POST["prof"];
$diary = $_POST["diary"];
$pm = $_POST["pm"];
$conf = $_POST["conf"];
$relreq = $_POST["relreq"];
$frreq = $_POST["frreq"];
$sub = $_POST["sub"];
$frlist = $_POST["frlist"];
$apics = $_POST["apics"];
$ask = $_POST["ask"];
$gbok = $_POST["gbok"];
$like = $_POST["like"];
$uday = mysql_query("UPDATE ibwff_users SET privacy='".$like."', prof='".$prof."', diary_uday='".$diary."', pm='".$pm."', conf='".$conf."', relreq='".$relreq."', frreq='".$frreq."', sub='".$sub."', frlist='".$frlist."', apics='".$apics."', ask='".$ask."', gbok='".$gbok."' WHERE id='".$who."'");
if($uday)
{
echo "<img src=\"ok.gif\" alt=\"O\"> Privacy Updated Successfully!";
}else{
echo "<img src=\"../avatars/notok.gif\" alt=\"x\"> Privacy Cannot Be Updated At This Moment!";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}