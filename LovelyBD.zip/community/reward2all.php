<?php
session_start();
include("config.php");
include("core.php");  
connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo '<head>';
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"title\" content=\"firebd.net\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From Shahos: Don't Try To Hack OR else :P\">
<meta name=\"keywords\" content=\"Site Desined By Shahos :) :)\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/></head>";
echo "<body>";
$action = $_GET["action"];
$sid = $_SESSION["sid"];
$who = $_GET["who"];
$whonick = getnick_uid($who);
$byuid = getuid_sid($sid);
$uid = getuid_sid($sid);
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();
////////////////Ip Banned By CJ UDAY :)	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
echo "<br/>";
echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
$banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
$remain =  $banto[0] - time();
$rmsg = gettimemsg($remain);
echo "<b>Time Remaining: $rmsg</b><br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "</p>";
echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
/////////////////Banned System Updated By CJ UDAY :)
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please Contact <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
 echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php"); 
echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
 echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
///////////////////Deactivated Account By CJ UDAY :)
          if(isdeactivated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  <b>Your Account Has Been Deactivated Forever.<br/>And It Will Be Never Activate!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
///////////////////Validation By CJ UDAY :)
					if(isvalidated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
           echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  You Are Not Validated!<br/>We are checking your ip and browser<br/>
	  This could take up to 15 munites pls be patient and try again soon<br/>Please try again later...<br/><b>Thank You</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
///////////////////////////////////////Reward To All By CJ UDAY :)

else if($action=="")
{
	    echo "<head>";
    echo "<title>Reward 2 All</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
				echo "<b>Reward 2 All</b></div>";
  echo "<div class=\"shout2\" align=\"left\">";
 echo "<form action=\"reward2all.php?action=setreward\" method=\"post\">";
  echo "<br/>Point:<input name=\"points\" maxlength=\"5\"/><br/>";
  echo "TO:<select name=\"who\">";
    echo "<option value=\"all\">All Members</option>";
  echo "<option value=\"online\">Online Members</option>";
  echo "<option value=\"vip\">VIP Members</option>";
  echo "<option value=\"premium\">Premium Members</option>";
  echo "<option value=\"staff\">Staff Team</option>";
 echo "<option value=\"owners\">Administrator</option>";
  echo "<option value=\"headadmin\">Head Moderators</option>";
 echo "<option value=\"admin\">Senior Moderatores</option>";
 echo "<option value=\"mods\">Junior Moderators</option>";
  echo "</select><br/>";
  echo "<input type=\"submit\" value=\"Reward\"/>";
  echo "</form>";
  echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
 }
/////////////////////////////////////////////reward 2 all All By CJ UDAY :)

  else if($action=="setreward")
{
	    echo "<head>";
    echo "<title>Reward 2 All Sucessfully SenT!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
				echo "<b>PM 2 All</b></div>";
			  echo "<div class=\"shout2\" align=\"center\">";
$who = $_POST["who"];
$points = $_POST["points"];
if ($who=="all")
{
$reciver = "All Members";
}
else if ($who=="online")
{
$reciver = "All Online Members";
}
else if ($who=="premium")
{
$reciver = "All Premium Members";
}
else if ($who=="vip")
{
$reciver = "All VIP Members";
}
else if ($who=="staff")
{
$reciver = "All Staffs";
}
else if ($who=="owners")
{
$reciver = "All Owners";
}
else if ($who=="headadmin")
{
$reciver = "All Head Moderators";
}
else if ($who=="mods")
{
$reciver = "All Moderators";
}
else if ($who=="admin")
{
$reciver = "All Senior Moderators";
}
$pmtou = "[b]".getnick_uid(getuid_sid($sid))."[/b] Update ".$points." Points Reward To ".$reciver." !";
$byuid = getuid_sid($sid);
$tm = time();
if($who=="all"){
$lastpm = mysql_fetch_array(mysql_query("SELECT MAX(timesent) FROM ibwff_private WHERE byuid='3'"));
echo "<br/><img src=\"../avatars/ok.gif\" alt=\"o\">All Members Has Been Send a Reward!<br/><br/>";
$tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($who);
  mysql_query("INSERT INTO ibwff_private SET text='[b]Special CID Report[/b][br/][b]".getnick_uid(getuid_sid($sid))."[/b] Make A Reward 2 All Members!', byuid='3', touid='1', timesent='".$tm."'");
$pms = mysql_query("SELECT id, name FROM ibwff_users WHERE validated=1");
$tm = time();
while($pm=mysql_fetch_array($pms))
{
mysql_query("INSERT INTO ibwff_private SET text='Public Reward:[br/]".$pmtou."[br/][br/][i]This Reward For All The Members Of FireBD![/i]', byuid='3', touid='".$pm[0]."', timesent='".$tm."'");
mysql_query("UPDATE ibwff_users SET plusses=plusses+'".$points."' WHERE id='".$pm[0]."'");
}
}
else if($who=="online"){
$lastpm = mysql_fetch_array(mysql_query("SELECT MAX(timesent) FROM ibwff_private WHERE byuid='3'"));
echo "<p align=\"center\">";
echo "<br/><img src=\"../avatars/ok.gif\" alt=\"o\">All Online Reward Has Been Send a Reward!<br/><br/>";
$tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($who);
  mysql_query("INSERT INTO ibwff_private SET text='[b]Special CID Report[/b][br/][b]".getnick_uid(getuid_sid($sid))."[/b] Make A Reward 2 All Online Members!', byuid='3', touid='1', timesent='".$tm."'");
$pms = mysql_query("SELECT userid FROM ibwff_online");
$tm = time();
while($pm=mysql_fetch_array($pms))
{
mysql_query("INSERT INTO ibwff_private SET text='[b]Online Reward:[/b][br/]".$pmtou."[br/][br/][i]This Reward For Online Members at this moment in FireBD![/i]', byuid='3', touid='".$pm[0]."', timesent='".$tm."'");
mysql_query("UPDATE ibwff_users SET plusses=plusses+'".$points."' WHERE id='".$pm[0]."'");
}
}
else if($who=="vip"){
$lastpm = mysql_fetch_array(mysql_query("SELECT MAX(timesent) FROM ibwff_private WHERE byuid='3'"));
echo "<br/><img src=\"../avatars/ok.gif\" alt=\"o\">All VIP Members Has Been Send a Reward!<br/><br/>";
$tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($who);
  mysql_query("INSERT INTO ibwff_private SET text='[b]Special CID Report[/b][br/][b]".getnick_uid(getuid_sid($sid))."[/b] Make A Reward 2 All Vip Members!', byuid='3', touid='1', timesent='".$tm."'");
$pms = mysql_query("SELECT id, name FROM ibwff_users WHERE vip=1");
$tm = time();
while($pm=mysql_fetch_array($pms))
{
mysql_query("INSERT INTO ibwff_private SET text='VIP Memebrs Reward:[br/]".$pmtou."[br/][br/][i]This Reward For VIP Members Of FireBD![/i]', byuid='3', touid='".$pm[0]."', timesent='".$tm."'");
mysql_query("UPDATE ibwff_users SET plusses=plusses+'".$points."' WHERE id='".$pm[0]."'");
}
}
else if($who=="premium"){
$lastpm = mysql_fetch_array(mysql_query("SELECT MAX(timesent) FROM ibwff_private WHERE byuid='3'"));
echo "<br/><img src=\"../avatars/ok.gif\" alt=\"o\">All Premium Members Has Been Send a Reward!<br/><br/>";
$tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($who);
  mysql_query("INSERT INTO ibwff_private SET text='[b]Special CID Report[/b][br/][b]".getnick_uid(getuid_sid($sid))."[/b] Make A PM 2 All Premium Members!', byuid='3', touid='1', timesent='".$tm."'");
$pms = mysql_query("SELECT id, name FROM ibwff_users WHERE pu=1");
$tm = time();
while($pm=mysql_fetch_array($pms))
{
mysql_query("INSERT INTO ibwff_private SET text='Premium Memebrs reward:[br/]".$pmtou."[br/][br/][i]This Reward ForPremium Members Of FireBD![/i]', byuid='3', touid='".$pm[0]."', timesent='".$tm."'");
mysql_query("UPDATE ibwff_users SET plusses=plusses+'".$points."' WHERE id='".$pm[0]."'");
}
}
else if($who=="staff"){
$lastpm = mysql_fetch_array(mysql_query("SELECT MAX(timesent) FROM ibwff_private WHERE byuid='3'"));
echo "<br/><img src=\"../avatars/ok.gif\" alt=\"o\">All Staffs Has Been Send a Reward!<br/><br/>";
$tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($who);
  mysql_query("INSERT INTO ibwff_private SET text='[b]Special CID Report[/b][br/][b]".getnick_uid(getuid_sid($sid))."[/b] Make A Reward 2 All Staffs!', byuid='3', touid='1', timesent='".$tm."'");
$pms = mysql_query("SELECT id, name FROM ibwff_users WHERE cyberpowereragon>'0'");
$tm = time();
while($pm=mysql_fetch_array($pms))
{
mysql_query("INSERT INTO ibwff_private SET text='Staffs Reward:[br/]".$pmtou."[br/][br/][i]This Reward for All Staff Of FireBD![/i]', byuid='3', touid='".$pm[0]."', timesent='".$tm."'");
mysql_query("UPDATE ibwff_users SET plusses=plusses+'".$points."' WHERE id='".$pm[0]."'");
}
}
else if($who=="owners"){
$lastpm = mysql_fetch_array(mysql_query("SELECT MAX(timesent) FROM ibwff_private WHERE byuid='3'"));
echo "<br/><img src=\"../avatars/ok.gif\" alt=\"o\">All Adminstrators Has Been Send a Reard!<br/><br/>";
$tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($who);
  mysql_query("INSERT INTO ibwff_private SET text='[b]Special CID Report[/b][br/][b]".getnick_uid(getuid_sid($sid))."[/b] Make A Reward 2 All Administrators!', byuid='3', touid='1', timesent='".$tm."'");
$pms = mysql_query("SELECT id, name FROM ibwff_users WHERE cyberpowereragon=4");
$tm = time();
while($pm=mysql_fetch_array($pms))
{
mysql_query("INSERT INTO ibwff_private SET text='Admininstrators Reward:[br/]".$pmtou."[br/][br/][i]This Reward for All Administrators Of FireBD![/i]', byuid='3', touid='".$pm[0]."', timesent='".$tm."'");
mysql_query("UPDATE ibwff_users SET plusses=plusses+'".$points."' WHERE id='".$pm[0]."'");
}
}
else if($who=="headadmin"){
$lastpm = mysql_fetch_array(mysql_query("SELECT MAX(timesent) FROM ibwff_private WHERE byuid='3'"));
echo "<br/><img src=\"../avatars/ok.gif\" alt=\"o\">All Head Moderatores Has Been Send a Reward!<br/><br/>";
$tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($who);
  mysql_query("INSERT INTO ibwff_private SET text='[b]Special CID Report[/b][br/][b]".getnick_uid(getuid_sid($sid))."[/b] Make A PM 2 All Head Moderatores!', byuid='3', touid='1', timesent='".$tm."'");
$pms = mysql_query("SELECT id, name FROM ibwff_users WHERE cyberpowereragon=3");
$tm = time();
while($pm=mysql_fetch_array($pms))
{
mysql_query("INSERT INTO ibwff_private SET text='Head Moderatores Reward:[br/]".$pmtou."[br/][br/][i]This Reward for All Head Moderatores Of FireBD![/i]', byuid='3', touid='".$pm[0]."', timesent='".$tm."'");
mysql_query("UPDATE ibwff_users SET plusses=plusses+'".$points."' WHERE id='".$pm[0]."'");
}
}
else if($who=="mods"){
$lastpm = mysql_fetch_array(mysql_query("SELECT MAX(timesent) FROM ibwff_private WHERE byuid='3'"));
echo "<br/><img src=\"../avatars/ok.gif\" alt=\"o\">All Moderatores Has Been Send a Reward!<br/><br/>";
$tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($who);
  mysql_query("INSERT INTO ibwff_private SET text='[b]Special CID Report[/b][br/][b]".getnick_uid(getuid_sid($sid))."[/b] Make A Reward 2 All Junior Moderatores!', byuid='3', touid='1', timesent='".$tm."'");
$pms = mysql_query("SELECT id, name FROM ibwff_users WHERE cyberpowereragon=1");
$tm = time();
while($pm=mysql_fetch_array($pms))
{
mysql_query("INSERT INTO ibwff_private SET text='Junior Moderators Reward:[br/]".$pmtou."[br/][br/][i]This Reward for All Junior Moderatores Of FireBD![/i]', byuid='3', touid='".$pm[0]."', timesent='".$tm."'");
mysql_query("UPDATE ibwff_users SET plusses=plusses+'".$points."' WHERE id='".$pm[0]."'");
}
}
else if($who=="admin"){
$lastpm = mysql_fetch_array(mysql_query("SELECT MAX(timesent) FROM ibwff_private WHERE byuid='3'"));
echo "<br/><img src=\"../avatars/ok.gif\" alt=\"o\">All Senior Moderatores Has Been Send a Reward!<br/><br/>";
$tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($who);
  mysql_query("INSERT INTO ibwff_private SET text='[b]Special CID Report[/b][br/][b]".getnick_uid(getuid_sid($sid))."[/b] Make A PM 2 All Senior Moderatores!', byuid='3', touid='1', timesent='".$tm."'");
$pms = mysql_query("SELECT id, name FROM ibwff_users WHERE cyberpowereragon=2");
$tm = time();
while($pm=mysql_fetch_array($pms))
{
mysql_query("INSERT INTO ibwff_private SET text='Senior Moderatores Reward:[br/]".$pmtou."[br/][br/][i]This Reward for All Senior Moderatores Of FireBD![/i]', byuid='3', touid='".$pm[0]."', timesent='".$tm."'");
mysql_query("UPDATE ibwff_users SET plusses=plusses+'".$points."' WHERE id='".$pm[0]."'");
}
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
?>