<?php
session_start();
include("config.php");
include("core.php");  connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo '<head>';
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"title\" content=\"firebd.net\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From Shahos: Don't Try To Hack OR else :P\">
<meta name=\"keywords\" content=\"Site Desined By Shahos :) :)\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/></head>";
echo "<body>";
$action = $_GET["action"]; $sid = $_SESSION["sid"];
$page = $_GET["page"];
$who = $_GET["who"];
$uid = getuid_sid($sid);
$name = $_GET["name"];
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();
////////////////Ip Banned By CJ UDAY :)	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
    echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
	echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
      echo "<br/>";
      echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
      $banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
      $remain =  $banto[0] - time();
      $rmsg = gettimemsg($remain);
      echo "<b>Time Remaining: $rmsg</b><br/>";
      $nick = getnick_uid($banto[2]);
       $text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
      echo "</p>";
    	echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
    echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
    echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
//////////////////Banned System Updated By CJ UDAY :)
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please With Contact Us <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
 echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
///////////////////Validation By CJ UDAY :)
					if(isvalidated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
	echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  You Are Not Validated!<br/>We are checking your ip and browser<br/>
	  This could take up to 15 munites pls be patient and try again soon<br/>Please try again later...<br/><b>Thank You</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }

///////////////////Deactivated Account By CJ UDAY :)
          if(isdeactivated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  <b>Your Account Has Been Deactivated Forever.<br/>And It Will Be Never Activate!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="gen")
{
if(!settingboss(getuid_sid($sid)))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  echo "permission Denied!<br/>";
  echo "<br/>You are not permited for this action...<br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
  echo "</html>";
  exit();
}
	echo "<head>";
    echo "<title>Site Settings</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Site Settings</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
    $xtm = getsxtm();
    $sitename = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='sitename'"));
    $sitenamex = $sitename[0];
    if(canreg())
    {
      $arv = "e";
    }else{
      $arv= "d";
    }
    if(validation())
    {
      $vldtn = "e";
    }else{
      $vldtn= "d";
    }
    if(fmvldtn())
    {
      $fmvldtn = "e";
    }else{
      $fmvldtn= "d";
}
    if(fmtvldtn())
    {
      $fmtvldtn = "e";
    }else{
      $fmtvldtn= "d";
}
 if(litcatvldtn())
    {
      $litcatvldtn = "e";
    }else{
      $litcatvldtn= "d";
    }
    if(litvldtn())
    {
      $litvldtn = "e";
    }else{
      $litvldtn= "d";
    }
    if(pollvldtn())
    {
      $pollvldtn = "e";
    }else{
      $pollvldtn= "d";
    }
		    if(blogvldtn())
    {
      $blogvldtn = "e";
    }else{
      $blogvldtn= "d";
    }
	$cpoint = cpoint();
	$spoint = spoint();
	$lpoint = lpoint();
	$mkfpoint = mkfpoint();
	$fcompoint = fcompoint();
	$litpoint = litpoint();
	$litcompoint = litcompoint();
	$blogcompoint = blogcompoint();
	$blogpoint = blogpoint();
        $pollpoint = poll_uday();
        $pvt = pollc_uday();
	$clpluss = clpluss();
	$nmpluss = nmpluss();
	$newclubpoint = newclubpoint();
echo "<onevent type=\"onenterforward\">";
  echo "<refresh>
  		<setvar name=\"sitename\" value=\"$sitename\"/>
        <setvar name=\"sesp\" value=\"$xtm\"/>
        <setvar name=\"areg\" value=\"$arv\"/>
        <setvar name=\"vldtn\" value=\"$vldtn\"/>
        <setvar name=\"litvldtn\" value=\"$litvldtn\"/>
        <setvar name=\"litcatvldtn\" value=\"$litcatvldtn\"/>
        <setvar name=\"pollvldtn\" value=\"$pollvldtn\"/>
        <setvar name=\"fmvldtn\" value=\"$fmvldtn\"/>
        <setvar name=\"fmtvldtn\" value=\"$fmtvldtn\"/>
        <setvar name=\"blogvldtn\" value=\"$blogvldtn\"/>";
		echo "
		<setvar name=\"cpoint\" value=\"$cpoint\"/>
		<setvar name=\"spoint\" value=\"$spoint\"/>
		<setvar name=\"lpoint\" value=\"$lpoint\"/>
		<setvar name=\"hpoint\" value=\"$hpoint\"/>
		<setvar name=\"mkfpoint\" value=\"$mkfpoint\"/>
		<setvar name=\"fcompoint\" value=\"$fcompoint\"/>
		<setvar name=\"litpoint\" value=\"$litpoint\"/>
		<setvar name=\"litcompoint\" value=\"$litcompoint\"/>
		<setvar name=\"blogpoint\" value=\"$blogpoint\"/>
		<setvar name=\"blogcompoint\" value=\"$blogcompoint\"/>
		<setvar name=\"fpluss\" value=\"$fpluss\"/>
		<setvar name=\"pp\" value=\"$pollpoint\"/>
		<setvar name=\"pvp\" value=\"$pvt\"/>
		<setvar name=\"clpluss\" value=\"$clpluss\"/>
		<setvar name=\"nmpluss\" value=\"$nmpluss\"/>
		<setvar name=\"newclubpoint\" value=\"$newclubpoint\"/>";
	$memberpoint = memberpoint();
	$junmemberpoint = junmemberpoint();
	$senmemberpoint = senmemberpoint();
        $junvippoint = junvip();
        $senvippoint = senvip();
	$knightpoint = knightpoint();
	$expartpoint = expartpoint();
	$expellerpoint = expellerpoint();
	$mrsmispoint = mrsmispoint();
	$pppoint = pppoint();
	$king = king();
	$kok = kok();
		echo "
		<setvar name=\"memberpoint\" value=\"$memberpoint\"/>
		<setvar name=\"junmemberpoint\" value=\"$junmemberpoint\"/>
		<setvar name=\"junvippoint\" value=\"$junvippoint\"/>
		<setvar name=\"senvippoint\" value=\"$senvippoint\"/>
		<setvar name=\"senmemberpoint\" value=\"$senmemberpoint\"/>
		<setvar name=\"knightpoint\" value=\"$knightpoint\"/>
		<setvar name=\"expellerpoint\" value=\"$expellerpoint\"/>
		<setvar name=\"expartpoint\" value=\"$expartpoint\"/>
		<setvar name=\"mrsmispoint\" value=\"$mrsmispoint\"/>
		<setvar name=\"pppoint\" value=\"$pppoint\"/>
		<setvar name=\"king\" value=\"$king\"/>
		<setvar name=\"kok\" value=\"$kok\"/>";
  echo "</refresh></onevent>";
echo "
  <form action=\"udayproc.php?action=general\" method=\"post\">";
echo "<b><u>Site Settings</u></b><br/>";
 echo "Site Name:";
 echo "<input name=\"sitename\" maxlength=\"255\" value=\"$sitenamex\"/>";
echo "<br/>Session Period: ";
  echo "<input name=\"sesp\" format=\"*N\" maxlength=\"3\" value=\"$xtm\" size=\"3\"/>";
  echo "<br/><b><u>Point System:-</u></b>";
    echo "<br/>Points per chat post: ";
  echo "<input name=\"cpoint\"  maxlength=\"3\" value=\"$cpoint\"/>";
      echo "<br/>Points cut for shout: ";
  echo "<input name=\"spoint\"  maxlength=\"3\" value=\"$spoint\"/>";
  echo "<br/>Points cut for givelove: ";
  echo "<input name=\"lpoint\"  maxlength=\"3\" value=\"$lpoint\"/>";
    echo "<br/>Points per forum topic create: ";
  echo "<input name=\"mkfpoint\"  maxlength=\"3\" value=\"$mkfpoint\"/>";
  echo "<br/>Points per forum topic post: ";
  echo "<input name=\"fcompoint\"  maxlength=\"3\" value=\"$fcompoint\"/>";
  echo "<br/>Points per Literature: ";
  echo "<input name=\"litpoint\"  maxlength=\"3\" value=\"$litpoint\"/>";
  echo "<br/>Points per Literature comment: ";
  echo "<input name=\"litcompoint\"  maxlength=\"3\" value=\"$litcompoint\"/>";
  echo "<br/>point for create a blog: ";
  echo "<input name=\"blogpoint\"  maxlength=\"3\" value=\"$blogpoint\"/>";
  echo "<br/>point per blog comment: ";
  echo "<input name=\"blogcompoint\"  maxlength=\"3\" value=\"$blogcompoint\"/>";
 echo "<br/>Points per club create: ";
  echo "<input name=\"clpluss\"  maxlength=\"3\" value=\"$clpluss\"/>";
echo "<br/>Points per name change: ";
  echo "<input name=\"nmpluss\"  maxlength=\"3\" value=\"$nmpluss\"/>";
  echo "<br/>Points add per create a new poll: ";
  echo "<input name=\"pp\"  maxlength=\"3\" value=\"$pollpoint\"/>";
  echo "<br/>Points add per vote on a poll: ";
  echo "<input name=\"pvp\"  maxlength=\"3\" value=\"$pvt\"/>";
  echo "<br/>Points need to create a club: ";
  echo "<input name=\"newclubpoint\"  maxlength=\"5\" value=\"$newclubpoint\"/>";
  echo "<br/><b><u>User Rank:</u></b><br/>";
echo "<font color=\"green\">Time (Seconds):</font><br/>";
  echo "Member:<input name=\"memberpoint\" format=\"*N\" value=\"$memberpoint\"/><br/>";
echo "Junior Member:<input name=\"junmemberpoint\" format=\"*N\" value=\"$junmemberpoint\"/><br/>";
echo "Senior Member:<input name=\"senmemberpoint\" format=\"*N\" value=\"$senmemberpoint\"/><br/>";
echo "Junior VIP:<input name=\"junvip\" format=\"*N\" value=\"$junvippoint\"/><br/>";
echo "Senior VIP:<input name=\"senvip\" format=\"*N\" value=\"$senvippoint\"/><br/>";
echo "<font color=\"green\">Points:</font><br/>";
  echo "Knight:<input name=\"knightpoint\" format=\"*N\" value=\"$knightpoint\"/><br/>";
  echo "Expeller:<input name=\"expellerpoint\" format=\"*N\" value=\"$expellerpoint\"/><br/>";
  echo "Expart:<input name=\"expartpoint\" format=\"*N\" value=\"$expartpoint\"/><br/>";
  echo "Master/Mistres:<input name=\"mrsmispoint\" format=\"*N\" value=\"$mrsmispoint\"/><br/>";
  echo "Prince/Princes:<input name=\"pppoint\" format=\"*N\" value=\"$pppoint\"/><br/>";
  echo "King/Queen:<input name=\"king\" format=\"*N\" value=\"$king\"/><br/>";
  echo "King Of King:<input name=\"kok\" format=\"*N\" value=\"$kok\"/><br/>";
  echo "<b><u>Validaty:-</u></b><br/>";
   echo "Registration: ";
  echo "<select name=\"areg\" value=\"$arv\">";
  echo "<option value=\"e\">Enable</option>";
  echo "<option value=\"d\">Disable</option>";
  echo "</select><br/>";
  echo "User Validation: <select name=\"vldtn\" value=\"$vldtn\">";
  echo "<option value=\"e\">Manual</option>";
  echo "<option value=\"d\">Auto</option>";
  echo "</select><br/>";
    echo "Forum Catagory Validation: <select name=\"fmvldtn\" value=\"$fmvldtn\">";
  echo "<option value=\"e\">Manual</option>";
  echo "<option value=\"d\">Auto</option>";
  echo "</select><br/>";
    echo "Topic Validation: <select name=\"fmtvldtn\" value=\"$fmtvldtn\">";
  echo "<option value=\"e\">Manual</option>";
  echo "<option value=\"d\">Auto</option>";
  echo "</select><br/>";
    echo "Article Catagory Validation: <select name=\"litcatvldtn\" value=\"$litcatvldtn\">";
  echo "<option value=\"e\">Manual</option>";
  echo "<option value=\"d\">Auto</option>";
  echo "</select><br/>";
    echo "Article Validation: <select name=\"litvldtn\" value=\"$litvldtn\">";
  echo "<option value=\"e\">Manual</option>";
  echo "<option value=\"d\">Auto</option>";
  echo "</select><br/>";
  echo "Poll Validation: <select name=\"pollvldtn\" value=\"$pollvldtn\">";
  echo "<option value=\"e\">Manual</option>";
  echo "<option value=\"d\">Auto</option>";
  echo "</select><br/>";
  echo "Blog Validation: <select name=\"blogvldtn\" value=\"$blogvldtn\">";
  echo "<option value=\"e\">Manual</option>";
  echo "<option value=\"d\">Auto</option>";
  echo "</select><br/>";
  echo "<br/><input type=\"submit\" value=\"Update\"/>
  </form>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="an")
{
if(!announcementboss(getuid_sid($sid)))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  echo "permission Denied!<br/>";
  echo "<br/>You are not permited for this action...<br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
  echo "</html>";
  exit();
}
	echo "<head>";
    echo "<title>Announcement Settings</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Announcement Settings</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$lnk = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='lnkmsg'"));
$cnt = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='cntmsg'"));
$ntb = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='ntcmsg'"));	
$ntb = htmlspecialchars($ntb[0]);
$cnt = htmlspecialchars($cnt[0]);
$lnkads = htmlspecialchars($lnk[0]);
$fmsg = htmlspecialchars(getfmsg());
$ntitle = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='ntitle'"));
$ntitle = $ntitle[0];
$cntitle = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='cntitle'"));
$cntitle = $cntitle[0];
$lnktitle = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='lnktitle'"));
$lnktitle = $lnktitle[0];
echo "<onevent type=\"onenterforward\">";
echo "<refresh>
<setvar name=\"fmsg\" value=\"$fmsg\"/>
<setvar name=\"ntb\" value=\"$ntb\"/>
<setvar name=\"cnt\" value=\"$cnt\"/>
<setvar name=\"lnkads\" value=\"$lnkads\"/>
<setvar name=\"ntitle\" value=\"$ntitle\"/>
<setvar name=\"cntitle\" value=\"$cntitle\"/>
<setvar name=\"lnktitle\" value=\"$lnktitle\"/>
";
  echo "</refresh></onevent>";
  echo "<form action=\"udayproc.php?action=an\" method=\"post\">
  Forum message:<br/>
 <input name=\"fmsg\"  maxlength=\"900\" value=\"$fmsg\"/>";
  echo "<br/><b><u>Announcement Messages:-</u></b> ";
  echo "<br/>Notice Board Title:<br/> ";
  echo "<input name=\"ntitle\" maxlength=\"250\" value=\"$ntitle\"/>";
    echo "<br/>Notice Board Message:<br/> ";
  echo "<input name=\"ntb\"  maxlength=\"10000\" value=\"$ntb\"/>";
 echo "<br/>Contest Box Title:<br/> ";
  echo "<input name=\"cntitle\" maxlength=\"250\" value=\"$cntitle\"/>";
 echo "<br/>Contest Box Message:<br/> ";
  echo "<input name=\"cnt\"  maxlength=\"10000\" value=\"$cnt\"/>";
echo "<br/>Offer Box Title:<br/> ";
  echo "<input name=\"lnktitle\" maxlength=\"250\" value=\"$lnktitle\"/>";
  echo "<br/>Offer Message:<br/> ";
  echo "<input name=\"lnkads\"  maxlength=\"10000\" value=\"$lnkads\"/>";
  echo "<br/><input type=\"submit\" value=\"Update\"/>
  </form><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
  echo "</html>";
  exit();
}
else if($action=="ins")
{
if(!instructionboss(getuid_sid($sid)))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  echo "permission Denied!<br/>";
  echo "<br/>You are not permited for this action...<br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
  echo "</html>";
  exit();
}
	echo "<head>";
    echo "<title>Instruction Settings</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Instruction Settings</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$institle = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='institle'"));
$institle = $institle[0];
$insmsg = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='insmsg'"));
$insmsg = $insmsg[0];
echo "<onevent type=\"onenterforward\">";
echo "<refresh>
<setvar name=\"institle\" value=\"$institle\"/>
<setvar name=\"insmsg\" value=\"$insmsg\"/>
";
  echo "</refresh></onevent>";
  echo "<form action=\"udayproc.php?action=ins\" method=\"post\">";
  echo "<br/><b><u>Instruction Messages:-</u></b> ";
  echo "<br/>Instruction Title:<br/> ";
  echo "<input name=\"institle\" maxlength=\"250\" value=\"$institle\"/>";
    echo "<br/>Instruction Message:<br/> ";
  echo "<input name=\"insmsg\"  maxlength=\"10000\" value=\"$insmsg\"/>";
   echo "<br/><input type=\"submit\" value=\"Update\"/>
  </form><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
  echo "</html>";
  exit();
}
else if($action=="forum")
{
if(!forumboss(getuid_sid($sid)))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  echo "permission Denied!<br/>";
  echo "<br/>You are not permited for this action...<br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
  echo "</html>";
  exit();
}
	echo "<head>";
    echo "<title>Forum Settings</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Forum Settings</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<a href=\"cjcp2.php?action=addfrm\">&#187;Add Forum</a><br/>";
echo "<a href=\"cjcp2.php?action=delfrm\">&#187;Delete Forum</a><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
  echo "</html>";
  exit();
}
else if($action=="fcat")
{
if(!forumboss(getuid_sid($sid)))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  echo "permission Denied!<br/>";
  echo "<br/>You are not permited for this action...<br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
  echo "</html>";
  exit();
}
	echo "<head>";
    echo "<title>Forum Catagory Settings</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Forum Catagory Settings</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<a href=\"cjcp2.php?action=addfc\">&#187;Add Forum Catagory</a><br/>";
echo "<a href=\"cjcp2.php?action=delfc\">&#187;Delete Forum Catagory</a><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
  echo "</html>";
  exit();
}
else if($action=="lit")
{
if(!literatureboss(getuid_sid($sid)))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  echo "permission Denied!<br/>";
  echo "<br/>You are not permited for this action...<br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
  echo "</html>";
  exit();
}
	echo "<head>";
    echo "<title>Literature Settings</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Literature Settings</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<a href=\"cjcp2.php?action=addlfrm\">&#187;Add Literature Forum</a><br/>";
echo "<a href=\"cjcp2.php?action=dellfrm\">&#187;Delete Literature Forum</a><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
  echo "</html>";
  exit();
}
else if($action=="litcat")
{
if(!literatureboss(getuid_sid($sid)))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  echo "permission Denied!<br/>";
  echo "<br/>You are not permited for this action...<br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
  echo "</html>";
  exit();
}
	echo "<head>";
    echo "<title>Literature Catagory Settings</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Literature Catagory Settings</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<a href=\"cjcp2.php?action=addlfc\">&#187;Add Literature Catagory</a><br/>";
echo "<a href=\"cjcp2.php?action=dellfc\">&#187;Delete Literature Catagory</a><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
  echo "</html>";
  exit();
}










else if($action=="asm")
{
if(!smiliesboss(getuid_sid($sid)))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  echo "permission Denied!<br/>";
  echo "<br/>You are not permited for this action...<br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
  echo "</html>";
  exit();
}
	echo "<head>";
    echo "<title>Add Smilies</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Add Smilies</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<br/>At 1st upload your smilies 
	 <a href=\"../smilies/index.php?action=upload\">&#8594; Here</a><br/><br/>";
    echo "<img src=\"p.gif\"/>Now code box e tomar icche moto jekono code dao,as like -wc- OR .wc.<br/>
	<img src=\"p.gif\"/>Then image source e ei code tuku bosao.<br/>
	../smilies/-wc-.gif<br/><img src=\"p.gif\"/>gif er jaygay tomar smilies er format name.I Mean format hobe jemon gif, jpg etc...<br/>
	<img src=\"p.gif\"/>Bhuleo source code e http use korba na. Nicher example dekho.&#8594; <br/><br/>";
echo "Code:-urfilename-<br/> ";
echo "Image Source: ../smilies/-urfilename-.jpg<br/> 0r, ";
echo "Image Source: ../smilies/-urfilename-.gif<br/><br/><br/>";
echo "<b><u>Add Smilies</u></b><br/><form action=\"udayproc.php?action=asm\" method=\"post\">";
echo "Code:<br/><input name=\"smlcde\" maxlength=\"30\"/><br/>";
echo "Image Source:<br/><input name=\"smlsrc\" maxlength=\"200\" value=\"../smilies/\"/><br/>";
echo "<input type=\"submit\" value=\"Add\"/></form>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
  echo "</html>";
  exit();
}
else if($action=="bsit")
{
if(!blocksiteboss(getuid_sid($sid)))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  echo "permission Denied!<br/>";
  echo "<br/>You are not permited for this action...<br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
  echo "</html>";
  exit();
}
	echo "<head>";
    echo "<title>Blocked Sites</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Blocked Sites</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
    echo "<a href=\"cjcp2.php?action=addsite\">&#187;Add Site</a><br/>";
    echo "<a href=\"cjcp2.php?action=viewsite\">&#187;View Sites</a><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
  echo "</html>";
  exit();
}
else if($action=="breg")
{
if(!bedregboss(getuid_sid($sid)))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  echo "permission Denied!<br/>";
  echo "<br/>You are not permited for this action...<br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
  echo "</html>";
  exit();
}
	echo "<head>";
    echo "<title>Block Bad Register</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Block Bad Register</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
    echo "<a href=\"cjcp2.php?action=addbreg\">&#187;Add Bad Register</a><br/>";
    echo "<a href=\"cjcp2.php?action=viewbreg\">&#187;View Bad Register</a><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
  echo "</html>";
  exit();
}
else if($action=="bnik")
{
if(!badnickboss(getuid_sid($sid)))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  echo "permission Denied!<br/>";
  echo "<br/>You are not permited for this action...<br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
  echo "</html>";
  exit();
}
	echo "<head>";
    echo "<title>Block Bad Nick</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Block Bad Register</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
    echo "<a href=\"cjcp2.php?action=addbnick\">&#187;Add Bad Nick</a><br/>";
    echo "<a href=\"cjcp2.php?action=viewbnick\">&#187;View Bad Nick</a><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
  echo "</html>";
  exit();
}
else if($action=="chat")
{
if(!chatboss(getuid_sid($sid)))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  echo "permission Denied!<br/>";
  echo "<br/>You are not permited for this action...<br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
  echo "</html>";
  exit();
}
	echo "<head>";
    echo "<title>Chatrooms</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Chatrooms</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
    echo "<a href=\"cjcp2.php?action=addch\">&#187;Add chatrooms</a><br/>";
    echo "<a href=\"cjcp2.php?action=viewch\">&#187;View chatrooms</a><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
  echo "</html>";
  exit();
}
else if($action=="logo")
{
echo "<head>";
    echo "<title>Logo</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Logo</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<b>LOGO will be added only if-</b><br/>* picture format is .jpg/.jpeg/.png<br/>* picture size is equal or less than <b>2MB</b>.<br/><b>Information that you should know..</b><br/>LOGO Change is a major style change of a site. You might have to clear your browser cache and wait for sometime to see the change.<br/>";
echo "<form enctype=\"multipart/form-data\" action=\"udayproc.php?action=logo\" method=\"post\">";
echo "<b>Choose logo:</b><br/> <input name=\"attach\" type=\"file\" accept=\"image/*\"/><br/>";
echo "<input type=\"submit\" value=\"Upload\"/></form>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
  echo "</html>";
  exit();
}
else if($action=="themes")
{
echo "<head>";
    echo "<title>Themes</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Themes</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<b>CSS will be added only if-</b><br/>* CSS format is .css<br/>* CSS must contain .header, .footer, body, .div, .mblock1, .likebox, hr.<br/><b>Information that you should know..</b><br/>CSS Change is a major style and color change of a site. You might have to clear your browser cache and wait for sometime to see the change.<br/>";
echo "<form enctype=\"multipart/form-data\" action=\"udayproc.php?action=theme\" method=\"post\">";
echo "<b>Choose theme:</b><br/> <input name=\"attach\" type=\"file\" accept=\"css/*\"/><br/>";
echo "<input type=\"submit\" value=\"Upload\"/></form>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
  echo "</html>";
  exit();
}
else if($action=="club")
{
echo "<head>";
    echo "<title>Club</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Club</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$clid = $_GET["clid"];
echo "&#187; <a href=\"cjcp.php?action=clpl&clid=$clid\"> Club Points</a><br/>";
echo "&#187; <a href=\"cjcp.php?action=dcl&clid=$clid\"> Delete Club</a><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
  echo "</html>";
  exit();
}
else if($action=="hso")
{
echo "<head>";
    echo "<title>Hide Online Settings</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Hide Online Settings</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<form action=\"udayproc.php?action=h\" method=\"post\">";
echo "Code:<br/><input name=\"uday\"><br/><input type=\"submit\" value=\"Update\"></form>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
  echo "</html>";
  exit();
}
?>
</html>