<?php
header("Content-type: text/vnd.wap.wml"); 
echo "<?xml version=\"1.0\"?>";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.1//EN\" \"http://www.wapforum.org/DTD/wml_1.1.xml\">"; 
$New_Time = time() + (0 * 60 * 60);
$time=date("H:i",$New_Time);
echo "<wml>"; 
?>
<card id="card1" title="time zones">
<p align="center">
<small>
<?
$gerNew_Time = time() + (0 * 60 * 60);
$gertime=date("H:i",$gerNew_Time);
echo "<br/>Berlin, Paris, Rome, Johhanesburg: $gertime";
$helNew_Time = time() + (1 * 60 * 60);
$heltime=date("H:i",$helNew_Time);
echo "<br/>Helsinki, Ankara, Capetown: $heltime";
$mosNew_Time = time() + (2 * 60 * 60);
$mostime=date("H:i",$mosNew_Time);
echo "<br/>Moscow, St. Petersburg, Baghdad: $mostime";
$banNew_Time = time() + (6 * 60 * 60);
$bantime=date("H:i",$banNew_Time);
echo "<br/>Bangkok, Jakarta: $bantime";
$bjinNew_Time = time() + (7 * 60 * 60);
$bjintime=date("H:i",$bjinNew_Time);
echo "<br/>Beijing: $bjintime";
$tokNew_Time = time() + (8 * 60 * 60);
$toktime=date("H:i",$tokNew_Time);
echo "<br/>Tokyo, Seoul: $toktime";
$sydNew_Time = time() + (9 * 60 * 60);
$sydtime=date("H:i",$sydNew_Time);
echo "<br/>Sydney: $sydtime";
$welNew_Time = time() + (11 * 60 * 60);
$weltime=date("H:i",$welNew_Time);
echo "<br/>Wellington, Auckland: $weltime";
$alsNew_Time = time() + (14 * 60 * 60);
$alstime=date("H:i",$alsNew_Time);
echo "<br/>Alaska: $alstime";
$seaNew_Time = time() + (15 * 60 * 60);
$seatime=date("H:i",$seaNew_Time);
echo "<br/>Seattle, San Fransisco, LA: $seatime";
$slcNew_Time = time() + (16 * 60 * 60);
$slctime=date("H:i",$slcNew_Time);
echo "<br/>SaltLake City, Phoenix, LA: $slctime";
$chicNew_Time = time() + (17 * 60 * 60);
$chictime=date("H:i",$chicNew_Time);
echo "<br/>Chicago, Dallas, Mexico LA: $chictime";
$nycNew_Time = time() + (18 * 60 * 60);
$nyctime=date("H:i",$nycNew_Time);
echo "<br/>New York, Miami, Quebec: $nyctime";
$bNew_Time = time() + (20 * 60 * 60);
$btime=date("H:i",$bNew_Time);
echo "<br/>Beunos Aires, Brasilia: $btime";
$hereNew_Time = time() + (23 * 60 * 60);
$heretime=date("H:i",$hereNew_Time);
echo "<br/>London, Dublin, Lisbon: $heretime";

//echo "<br/><br/><a href=\"main.php\"><img src=\"images/home.gif\" alt=\"*\"/>";
//echo "</a>";


?>
</small>
</p>
</card> 
</html>





