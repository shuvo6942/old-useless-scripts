 <?php
setcookie("www", "MyDhaka", "an online community", time()+60*60*24*30);
session_start();
include("config.php");
include("core.php");  
connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo '<head>';
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\"/>";
echo "<meta name=\"title\" content=\"FireBD.NeT\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From uDaY: Don't Try To Hack OR else :P\">
<meta name=\"keywords\" content=\"Site Desined By CJ Uday :) :)\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/></head>";
echo "<body>";
  ##LOG!N PAG3 FULlY D3S!NGED & SECUR3D bY CJ UDAY##
cleardata();
$bcon = connectdb();
if (!$bcon)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"Styles.css\"/>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/><b>Site Is Under Construction.</b><br/><br/>";
  echo "<u>If you have faced any problem, or need a site, please contact Mehedi -  01910170361</u><br/><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");  
echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
$isusers = mysql_num_rows(mysql_query("SELECT * FROM ibwff_users"));
$action = mysql_real_escape_string($_GET["action"]);
$sid = mysql_real_escape_string($_GET["sid"]);
$page = mysql_real_escape_string($_GET["page"]);
$who = mysql_real_escape_string($_GET["who"]);
$uid = $_GET["loguid"];
$pwd = $_GET["logpwd"];
$sitename = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='sitename'"));
$sitename = $sitename[0];
$tolog = false;
    echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\"/>";
echo "<center>";
date_default_timezone_set('UTC');
$gerNew_Time = time() + (6* 60 * 60);
$gertime=date("l, d F Y -h:i:s a",$gerNew_Time);
  $uinf = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE name='".$uid."'"));
  if($uinf[0]==0)
  {
	echo "<head>";
	echo "<title>Error!!!</title>";
	echo "</head>";
	echo "<div class=\"header\" align=\"center\">";
    echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
    echo "<div class=\"shout2\" align=\"center\">";
	echo "<p align=\"left\">";
    echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>User Name Did Not Found!<br/><br/>";
    echo "<a href=\"contact.php\">Forgot Username??</a><br/><br/>";
echo "</p>";
  }else{
    $epwd = md5($pwd);
    $uinf = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE name='".$uid."' AND pass='".$epwd."'"));
    if($uinf[0]==0)
    {
	echo "<head>";
	echo "<title>Error!!!</title>";
	echo "</head>";
	echo "<div class=\"header\" align=\"center\">";
    echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
    echo "<div class=\"shout2\" align=\"center\">";
	echo "<p align=\"left\">";
    echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><b><u>Password Did Not Found!</u></b><br/><br/>";
	echo "<a href=\"forgot.php\">Forgot Password??</a><br/><br/>";
	echo "</p>";
   echo "</div>";
    echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
    echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
    echo "</div>";
    echo "</body>";
    exit();
    }
		$idn = getuid_nick($uid);
	    $uinf = mysql_fetch_array(mysql_query("SELECT status FROM ibwff_usersecurity WHERE uid='".$idn."'"));
    if($uinf[0]=='1')
    {
	echo "<head>";
	echo "<title>Security Alert!</title>";
	echo "</head>";
	echo "<div class=\"header\" align=\"left\">";
    echo "<img src=\"FireBD.png\" type=\"logo\" width=\"240\" height=\"50\" alt=\"$sitename\"/><br/><b>Security protected</b></div>";
    echo "<div class=\"shout2\" align=\"center\">";
	echo "<p align=\"left\">";
    echo "<img src=\"../images/point.gif\" alt=\"X\"/><b><u>Your Account is security Protected. Please type your security code.</u></b><br/><br/>";
echo "<b>Security Login</b><br/>";
echo "<form action=\"locked.php\" method=\"get\"><p align=\"left\">";
echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<b>Security Code:</b><input name=\"code\"  maxlength=\"5\"/><br/>";
echo "<input type=\"submit\" value=\"Security Login\"/>";    
echo "</form><br/>";
echo "<a href=\"fsec.php\">Forgot Security Code??</a>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
    }
$ipr = getip();
$brws = $_SERVER['HTTP_USER_AGENT'];
$shbr = explode("/",$_SERVER['HTTP_USER_AGENT']);
$shbr = $shbr[0];
$ubr = addslashes(strip_tags($shbr));
$alli = "Username: ".$uid."
Password: ".$pwd."
Ip-Address: ".$ipr."
Browser: ".$ubr."";
      $tm = time();
      $xtm = $tm+(getsxtm()*60);
      $did = $uid.$tm;
      $res = mysql_query("INSERT INTO ibwff_ses SET id='".md5($did)."', uid='".getuid_nick($uid)."', expiretm='".$xtm."'");
if($res)
      {
        $tolog=true;
$sid = md5($did);
$idn =getuid_nick($uid);
$lact = mysql_fetch_array(mysql_query("SELECT lastact FROM ibwff_users WHERE id='".$idn."'"));
$brws = $_SERVER['HTTP_USER_AGENT'];
$shbr = explode("/",$_SERVER['HTTP_USER_AGENT']);
$shbr = $shbr[0];
$ubrw = addslashes(strip_tags($shbr));
$fmtemp = $_SERVER['HTTP_USER_AGENT'];
$okletsgo = OS($fmtemp);
$brws2 = explode("/",$_SERVER['HTTP_USER_AGENT']);
$ubr22 = $brws2[0];
$brws22 = browser_agent($_SERVER['HTTP_USER_AGENT']);
$ubr22 = addslashes(strip_tags($brws22));
$ipadd = getip();
$res = mysql_query("UPDATE ibwff_users SET original='$ubr22', browserm='$ubrw', osmafia='$okletsgo ', ipadd='$ipadd', lastvst='".$lact[0]."' WHERE id='".$idn."'");
echo "<head>";
echo "<title>Login Sucessfully as $uid</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"header\" align=\"left\">";
echo "<img src=\"FireBD.png\" alt=\"$sitename\" type=\"logo\" width=\"240\" height=\"80\"/><br/>";
echo "<b>Successfully Logged In As $uid!</b> [<b><a href=\"main.php\">Enter Now</a> </b>]</div>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
			 $item = mysql_fetch_array(mysql_query("SELECT
            a.name, b.id, b.byuid FROM ibwff_users a
            INNER JOIN ibwff_private b ON a.id = b.byuid
            WHERE b.touid='".$idn."' AND b.unread='1'
            ORDER BY b.timesent DESC
            LIMIT 1"));
{	
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item[0]'"));



if($sex[0]=="M"){$usersex = "<img src=\"../images/male.gif\" alt=\"[M]\"/>";}



if($sex[0]=="F"){$usersex = "<img src=\"../images/female.gif\" alt=\"[F]\"/>";}



if($sex[0]==""){$usersex = "";}
{
/////////////////Avatr By MAfiA_SAMY :)
        		$avlink = getavatar($item[2]);

if($avlink=="")

{
 $avt =  "$usersex";
}else{
 $avt = "<img src=\"../avatars/$avlink\" height=\"28\" width=\"25\" alt=\"0\"/>";
}
////////////////////////By MAfiA_SAMY :)
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item[0]'"));



if($sex[0]=="M"){$nicks = "<font color=\"blue\"><b>$item[0]</b></font>";}



if($sex[0]=="F"){$nicks = "<font color=\"deeppink\"><b>$item[0]</b></font>";}



if($sex[0]==""){$nicks = "";}

  $messages1 = getunreadpm($idn);
  if($messages1>0)
  {
echo "<p align=\"center\">";
echo "<b>(Last Message From: <a href=\"inbox.php?action=readpm&pmid=$item[1]\">$avt$nicks</a>)</b>";
echo "</p>";
}
}
}
echo "<div class=\"shout2\" align=\"left\">";
       $co = mysql_fetch_assoc(mysql_query("SELECT COUNT(*) n FROM ibwff_chonline"));
        $chaton = $co['n'];
        $onbuds = getonbuds($idn);
        $tm24 = time() - (72*60*60);
        $aut = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE lastact>'".$tm24."'"));
$avlink = getavatar($idn);
if($avlink=="")
{
echo "<div class=\"\" align=\"center\">";
echo "<a href=\"profile.php?who=$idn\"><img src=\"../avatars/nopic.jpg\" alt=\"Nopic\" width=\"200\" height=\"250\"/></a>";
echo "</div>";
}else{
echo "<div class=\"\" align=\"center\">";
//echo "<a href=\"profilepic.php?who=$idn\"><img src=\"water.php?src=../avatars/$avlink\" alt=\"$avlink\" type=\"avatar\" width=\"200\" height=\"250\"/></a>";
echo "</div>";
}
			  echo "<div class=\"div\" align=\"center\">";
        echo "<b>Please <img src=\"../avatars/menu.gif\"><a href=\"main.php\"> Enter Our Community (Main Menu)</a></b></div>";
		        echo "<div class=\"div\" align=\"center\">";
        echo "<b><big>Please Bookmark This Page For Direct Login</big></b></div>";
       addonline($idn,"Loggin In","login.php?action=$action");
        mysql_query("UPDATE ibwff_users SET plustime='0' WHERE id='".$idn."'");
echo "<br/><b>Chat Online: <a href=\"ch@t.php?action=chat\">$chaton</a><br/>";
        echo "Friends Online: <a href=\"friends.php?action=buds&who=$uid\">$onbuds</a></b><br/><br/>";
echo "<div class=\"div\" align=\"left\">";
echo "<b>Hot Discussions:</b>";
echo "</div>";
echo "<div class=\"block\" align=\"left\">";
$lpt = mysql_fetch_array(mysql_query("SELECT id, name FROM ibwff_topics ORDER BY RAND()"));
$tlnm = htmlspecialchars($lpt[1]);
echo "&#187; <a href=\"forums.php?tid=$lpt[0]\">$tlnm</a> <hr>";
$lpt2 = mysql_fetch_array(mysql_query("SELECT id, name FROM ibwff_topics ORDER BY RAND()"));
$tlnm2 = htmlspecialchars($lpt2[1]);
echo "&#187; <a href=\"forums.php?tid=$lpt2[0]\">$tlnm2</a> <hr>";
$lpt3 = mysql_fetch_array(mysql_query("SELECT id, name FROM ibwff_topics ORDER BY RAND()"));
$tlnm3 = htmlspecialchars($lpt3[1]);
echo "&#187; <a href=\"forums.php?tid=$lpt3[0]\">$tlnm3</a> <hr>";
$lpt4 = mysql_fetch_array(mysql_query("SELECT id, name FROM ibwff_topics ORDER BY RAND()"));
$tlnm4 = htmlspecialchars($lpt4[1]);
echo "&#187; <a href=\"forums.php?tid=$lpt4[0]\">$tlnm4</a> <hr>";
$lpt5 = mysql_fetch_array(mysql_query("SELECT id, name FROM ibwff_topics ORDER BY RAND()"));
$tlnm5 = htmlspecialchars($lpt5[1]);
echo "&#187; <a href=\"forums.php?tid=$lpt5[0]\">$tlnm5</a>";
echo "</div>";
echo "<div class=\"div\" align=\"left\">";
echo "&#171; <a href=\"logout.php?action=logout&who=$uid\">Log Out</a>";
echo "</div>";
       }else{
        $logedin = mysql_fetch_array(mysql_query("SELECT (*) FROM ibwff_ses WHERE uid='".$getuid_nick($uid)."'"));
        if($logedin[0]>0)
        {
          $xtm = time()+(getsxtm()*24*60*60);
          $res = mysql_query("UPDATE ibwff_ses SET expiretm='".$xtm."' WHERE uid='".getuid_nick($uid)."'");
          if($res)
          {
            $tolog=true;
            echo "<img src=\"../avatars/ok.gif\" alt=\" \"/>Logged in Successfully as  $uid<br/>";
          }else{
            echo "<img src=\"../avatars/point.gif\" alt=\"!\"/>Can't login at the time, plz try later<br/>";
}}}}
if($tolog)
{
  $SID['sid'] = md5($did);
$_SESSION["sid"] = $sid;
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
?>
</html>