<?php
session_start();
include("config.php");
include("core.php"); 
connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo "<head>";
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\"/>";
echo "<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG : Don't Try To Hack OR else :P\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"main,all,follow\"/></head>";
echo "<body>";
##FR!3NDS !S 100% CR3AT3D & D3SIGNED BY Shahos :-) ## 
$action = $_GET["action"]; $sid = $_SESSION["sid"];
$page = $_GET["page"];
$who = $_GET["who"];
$uid = getuid_sid($sid);
$sitename = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='sitename'"));
$sitename = $sitename[0];
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
echo "<br/>";
echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
$banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
$remain =  $banto[0] - time();
$rmsg = gettimemsg($remain);
echo "<b>Time Remaining: $rmsg</b><br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "</p>";
echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
$uid = getuid_sid($sid);
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
 echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");  
echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"left\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "<div class=\"div align=\"center\">Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");  
echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please Contact <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(isdeactivated(getuid_sid($sid), $uid))
{
echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<br/><b>Your Account Has Been Deactivated.<br/>And It Will Be Never Activated Again!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="reqs")
{
    addonline(getuid_sid($sid),"Viewing Friend Requests List","friends.php?action=$action");
	    echo "<head>";
    echo "<title>View Friend Requests List</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
    echo "<div class=\"header\" align=\"center\">";
	echo "<b>Friend Requests</b><br/>";
$uid = getuid_sid($sid);
$remp = $max_buds - getnbuds($uid);
    echo "You Have $remp Places left";
echo "</div>";
	echo "<div class=\"shout2\" align=\"left\">";
    global $max_buds;
    $uid = getuid_sid($sid);
    echo "The following members want you to add them to your buddy list.";
    if($page=="" || $page<=0)$page=1;
    $nor = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_buddies WHERE tid='".$uid."' AND agreed='0'"));
    $num_items = $nor[0]; $items_per_page= 7;
    $num_pages = ceil($num_items/$items_per_page);
    if(($page>$num_pages)&&$page!=1)$page= $num_pages;
    $limit_start = ($page-1)*$items_per_page;
        $sql = "SELECT uid  FROM ibwf_buddies WHERE tid='".$uid."' AND agreed='0' ORDER BY reqdt DESC LIMIT $limit_start, $items_per_page";
    echo "<p>";
    $items = mysql_query($sql);
    if(mysql_num_rows($items)>0)
    {
    while ($item = mysql_fetch_array($items))
    {
	    $sql2 = "SELECT name FROM ibwff_users WHERE id=$item[0]";
	    $sql22 = mysql_query($sql2);
	    $item2 = mysql_fetch_array($sql22);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item2[0]'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/>";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/>";}
if($sex[0]==""){$usersex = "";}
$avlink = getavatar($item[0]);
if($avlink=="")
{
 $avt =  "$usersex";
}else{
 $avt = "<img src=\"../avatars/$avlink\" alt=\"$avlink\" type=\"icon\" width=\"23\" hieght=\"18\"/>";
}
$noi = mysql_fetch_array(mysql_query("SELECT lastact FROM ibwff_users WHERE id='".$item[0]."'"));
$var1 = date("his",$noi[0]);
$var2 = time();
$rnick = getnick_uid($item[0]);
$sql3 = "SELECT name FROM ibwff_users WHERE id=$item[0]";
$sql33 = mysql_query($sql3);
$item3 = mysql_fetch_array($sql33);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nicks = "<font color=\"blue\"><b>$rnick</b></font>";}
if($sex[0]=="F"){$nicks = "<font color=\"deeppink\"><b>$rnick</b></font>";}
if($sex[0]==""){$nicks = "";}
      $lnk = "$avt<a href=\"profile.php?who=$item[0]\">$nicks</a> : <a href=\"friendsproc.php?action=add&who=$item[0]\">Accept</a>,<a href=\"friendsproc.php?action=del&who=$item[0]\">Deny</a>";
      echo "$lnk<br/>";
	}
	}
    }
    }
    if($page>1)
    {
      $ppage = $page-1;
      echo "<a href=\"friends.php?action=$action&page=$ppage&who=$who\">&#171;-Prev</a> ";
    }
    if($page<$num_pages)
    {
      $npage = $page+1;
      echo "<a href=\"friends.php?action=$action&page=$npage&who=$who\">Next-&#187;</a>";
    }
    echo "Page - $page/$num_pages<br/>";
    if($num_pages>2)
    {
			        $rets = "<form action=\"friends.php\" method=\"get\">";
        $rets .= "<input name=\"page\" style=\"-wap-input-format: '*N'\" size=\"2\"/>";
        $rets .= "<input type=\"hidden\" name=\"action\" value=\"$action\"/>";
        $rets .= "<input type=\"hidden\" name=\"sid\" value=\"$sid\"/>";
        $rets .= "<input type=\"submit\" value=\"Go To Page\"/>";
        $rets .= "</form>";
        echo $rets;
    }
echo "&#187; <a href=\"friendsproc.php?action=aall&who=$who\">Accept All Friend Requests</a><br/>&#187; <a href=\"friendsproc.php?action=dall&who=$who\">Deny All Friend Requests</a>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
//////////////////////////////////Friends Updated :)

else if($action=="buds")
{
    $who = $_GET["who"];
	$whonick = getnick_uid($who);
    addonline(getuid_sid($sid),"Viewing $whonick's Friends List","friends.php?action=buds");
	    echo "<head>";
    echo "<title>View $whonick's Friends Lists</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
$fxid = getuid_sid($sid);
$x = getonbuds($fxid);
			echo "<b>Online Friends $x</b></div>";
  echo "<div class=\"shout2\" align=\"left\">";
    include("pm_by.php");
    $uid = getuid_sid($sid);
$y = getnreqs($uid);
if($y > 0)
{
echo "<b>&#187;</b> <a href=\"friends.php?action=reqs&who=$who\"><b>$y Friend Requests Waiting!</b></a><br/>";
}
$z = getnbuds($fxid);
echo "&#187; <a href=\"friends.php?action=friends&who=$who\">All Friends</a> [$z]<br/><br/>";
$k = getonbuds($fxid);
if($k==0)
{
echo "No Friends Online!<br/>";
}else{    
   if($page=="" || $page<=0)$page=1;
    $num_items = getnbuds($uid); 
    $items_per_page= 7;
    $num_pages = ceil($num_items/$items_per_page);
    if(($page>$num_pages)&&$page!=1)$page= $num_pages;
    $limit_start = ($page-1)*$items_per_page;
$sql = "SELECT a.lastact, a.name, a.id, b.uid, b.tid, b.reqdt FROM ibwff_users a INNER JOIN ibwf_buddies b ON (a.id = b.uid) OR (a.id=b.tid) WHERE (b.uid='".$uid."' OR b.tid='".$uid."') AND b.agreed='1' AND a.id!='".$uid."' GROUP BY 1,2  ORDER BY a.lastact DESC LIMIT $limit_start, $items_per_page";
$items = mysql_query($sql);
if(mysql_num_rows($items)>0)
    {
    while ($item = mysql_fetch_array($items))
    {
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item[1]'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/> ";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/> ";}
if($sex[0]==""){$usersex = "";}
$avlink = getavatar($item[2]);
if($avlink=="")
{
 $avt =  "$usersex";
}else{
 $avt = "<img src=\"../avatars/$avlink\" alt=\"$avlink\" type=\"icon\" width=\"23\" hieght=\"18\"/>";
}
$noi = mysql_fetch_array(mysql_query("SELECT lastact FROM ibwff_users WHERE id='".$item[2]."'"));
$remain = time() - $noi[0];
$idle = gettimemsg($remain);
	    $sql3 = "SELECT name FROM ibwff_users WHERE id=$item[2]";
	    $sql33 = mysql_query($sql3);
	    $item3 = mysql_fetch_array($sql33);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nicks = "<font color=\"blue\"><b>$item[1]</b></font>";}
if($sex[0]=="F"){$nicks = "<font color=\"deeppink\"><b>$item[1]</b></font>";}
if($sex[0]==""){$nicks = "";}
if(isonline($item[2]))
  {
    $uact = "Location: ";
    $plc = mysql_fetch_array(mysql_query("SELECT place FROM ibwff_online WHERE userid='".$item[2]."'"));
    $uact .= $plc[0];
      $lnk = "<a href=\"profile.php?who=$item[2]\">$avt$nicks</a> &#187; $uact";
      echo "$lnk<br/>";
      echo "<small>Idle: $idle</small><br/>";
    }
    }
    }
    }
    }
  if($page>1)
    {
      $ppage = $page-1;
      echo "<a href=\"friends.php?action=buds&page=$ppage&who=$who\">&#171;-Prev</a> ";
    }
    if($page<$num_pages)
    {
      $npage = $page+1;
      echo "<a href=\"friends.php?action=buds&page=$npage&who=$who\">Next-&#187;</a>";
    }
    if($num_pages>2)
    {
			        $rets = "<form action=\"friends.php\" method=\"get\">";
        $rets .= "<input name=\"page\" style=\"-wap-input-format: '*N'\" size=\"2\"/>";
        $rets .= "<input type=\"hidden\" name=\"action\" value=\"$action\"/>";
        $rets .= "<input type=\"hidden\" name=\"sid\" value=\"$sid\"/>";
  $rets .= "<input type=\"submit\" value=\"Go To Page\"/>";
        $rets .= "</form>";
        echo $rets;
    }
echo "&#187; <a href=\"friendsproc.php?action=delall&who=$who\">Remove All Friends</a><br/>";
    echo "</div>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="friends")
{
$w = $_GET["who"];
$vn = getnick_uid($w);
    addonline(getuid_sid($sid),"Viewing $vn's Friend List","friends.php?action=$action");
	    echo "<head>";
    echo "<title>View $vn's Friends</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
    echo "<div class=\"header\" align=\"center\">";
	echo "<b>$vn's Friends</b></div>";
	echo "<div class=\"shout2\" align=\"left\">";
	include("pm_by.php");
	echo "<br/>";
    if($page=="" || $page<=0)$page=1;
    $noi = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_buddies WHERE (tid='".$w."' AND agreed='1') OR (uid='".$w."' AND agreed='1')"));
$num_items = $noi[0]; 
    $items_per_page= 10;
    $num_pages = ceil($num_items/$items_per_page);
    if(($page>$num_pages)&&$page!=1)$page= $num_pages;
    $limit_start = ($page-1)*$items_per_page;
 $sql = "SELECT a.lastact, a.name, a.id, b.uid, b.tid, b.reqdt FROM ibwff_users a INNER JOIN ibwf_buddies b ON (a.id = b.uid) OR (a.id=b.tid) WHERE (b.uid='".$uid."' OR b.tid='".$uid."') AND b.agreed='1' AND a.id!='".$uid."' GROUP BY 1,2  ORDER BY a.lastact DESC LIMIT $limit_start, $items_per_page";
 $items = mysql_query($sql);
    if(mysql_num_rows($items)>0)
    {
    while ($item = mysql_fetch_array($items))
    {
	    $sql2 = "SELECT name, birthday, location, sex FROM ibwff_users WHERE id=$item[2]";
	    $sql22 = mysql_query($sql2);
	    $item2 = mysql_fetch_array($sql22);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item2[0]'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/>";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/>";}
if($sex[0]==""){$usersex = "";}
          if(isonline($item[2]))
  {
    $iml = "<font color=\"green\">online!</font>";
  }else{
    $iml = "<font color=\"red\">0ffline!</font>";
  }
        		$avlink = getavatar($item[2]);
if($avlink=="")
{
 $avt =  "$usersex";
}else{
 $avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"icon\" width=\"23\" hieght=\"18\"/>";
}
$clnm = mysql_fetch_array(mysql_query("SELECT name FROM ibwff_users WHERE id='".$item[2]."'"));
	    $sql3 = "SELECT name FROM ibwff_users WHERE id=$item[2]";
	    $sql33 = mysql_query($sql3);
	    $item3 = mysql_fetch_array($sql33);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nicks = "<font color=\"blue\"><b>".htmlspecialchars($clnm[0])."</b></font>";}
if($sex[0]=="F"){$nicks = "<font color=\"deeppink\"><b>".htmlspecialchars($clnm[0])."</b></font>";}
if($sex[0]==""){$nicks = "";}
$noi = mysql_fetch_array(mysql_query("SELECT lastact FROM ibwff_users WHERE id='".$item[2]."'"));
$remain = time() - $noi[0];
$idle = gettimemsg($remain);
$t = $item[5] + (6*60*60);
$bs = date("h:i A, D d F y",$t);
$xz = getage($item2[1]);
      $lnk = "<a href=\"profile.php?who=$item[2]\">$avt$nicks</a>  ($xz / $item2[3] / $item2[2]) $iml<br/>Since: $bs<br/>Idle: $idle<br/>";
      echo "$lnk";
	  if($uid == $w)
      {
	  echo "<small><a href=\"friendsproc.php?action=del&who=$item[0]\">[Remove]</a></small><br/><br/>";
	  }
	}
	}
    }
    }else
	{
	echo "<img src=\"../avatars/notok.gif\" alt=\"X\"><b>No Friends Found!</b>";
	}
    if($page>1)
    {
      $ppage = $page-1;
      echo "<a href=\"friends.php?action=$action&page=$ppage&who=$who\">&#171;-Prev</a> ";
    }
    if($page<$num_pages)
    {
      $npage = $page+1;
      echo "<a href=\"friends.php?action=$action&page=$npage&who=$who\">Next-&#187;</a>";
    }
    echo "<br/>Page - $page/$num_pages<br/>";
    if($num_pages>2)
    {
			        $rets = "<form action=\"friends.php\" method=\"get\">";
        $rets .= "<input name=\"page\" style=\"-wap-input-format: '*N'\" size=\"2\"/>";
        $rets .= "<input type=\"hidden\" name=\"action\" value=\"$action\"/>";
        $rets .= "<input type=\"hidden\" name=\"sid\" value=\"$sid\"/>";
		$rets .= "<input type=\"hidden\" name=\"who\" value=\"$who\"/>";
   $rets .= "<input type=\"submit\" value=\"Go To Page\"/>";
        $rets .= "</form>";
        echo $rets;
    }
echo "&#171; <a href=\"profile.php?who=$who\">Back to Profile!</a>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
exit();
}
?>