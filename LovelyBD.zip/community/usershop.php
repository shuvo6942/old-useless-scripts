<?php
session_start();
include("config.php");
include("core.php");  connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo '<head>';
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"title\" content=\"Firebd.net\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From From Shahos: Don't Try To Hack OR else :P\">
<meta name=\"keywords\" content=\"Site Desined By Shahos :) :)\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/></head>";
echo "<body>";
$action = $_GET["action"];
$sid = $_SESSION["sid"];
$uid = getuid_sid($sid);
$brws = explode(" ",$HTTP_USER_AGENT);
$ubr = $brws[0];
$uip = getip();
////////////////Ip Banned By cJ UDAY :)	
if(isipbanned($uip,$ubr))
    {
      if(!isshield(getuid_sid($sid)))
      {
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
      echo "<br/>";
      echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
      $banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
      $remain =  $banto[0] - time();
      $rmsg = gettimemsg($remain);
      echo "<b>Time Remaining: $rmsg</b><br/><br/>";
      echo "</p>";
    	echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
    echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
    echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
//////////////////Banned System Updated By CJ UDAY :)
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please Contact <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(!isowner($uid))
{
if(!udaypu($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "You need to be a premium member before you can change your title name!!";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
}
/////////////////////System By CJ UDAY :)
  $point = mysql_fetch_array(mysql_query("SELECT plusses FROM ibwff_users WHERE id='".$uid."'"));
  $nmpluss = 500;
if($point[0]<$nmpluss)
  {
	    echo "<head>";
    echo "<title>Title Shop</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
			 echo "<div class=\"header\" align=\"center\">";
			  echo "<b>Display Shop</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
echo "<br/><b><img src=\"../avatars/notok.gif\">You Need At Least $nmpluss Points To Enter Title Shop! <img src=\"../avatars/notifi.gif\"></b><br/><br/>";
echo "<img src=\"../avatars/prev.gif\"><a href=\"profile.php?action=viewuser&who=$uid&sid=$sid\">Back to Profile</a><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php?action=main&sid=$sid\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
    exit();
    }
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
 include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
///////////////////Deactivated Account Created By CJ UDAY :)
          if(isdeactivated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  <b>Your Account Has Been Deactivated Forever.<br/>And It Will Be Never Activate!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
////////////////////////////////////////////User Shop Created By CJ UDAY :)
if($action=="")
{
    addonline(getuid_sid($sid),"Changing Title Name","titleshop.php?action=$action");
	echo "<head>";
    echo "<title>Username Shop</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
	echo "<div class=\"header\" align=\"center\">";
echo "<b>Username Shop</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
echo "<p align=\"left\">";
echo "<img src=\"../avatars/point.gif\" alt=\"!\"> You must spent 100 points to change your username<br/>";
echo "<img src=\"../avatars/point.gif\" alt=\"!\"> You must be at least a general premium member to change your username<br/>";
echo "<img src=\"../avatars/point.gif\" alt=\"!\"> Allowed characters in username are  A-Z, a-z, 0-9, and -_ and spaces<br/>";
echo "<img src=\"../avatars/point.gif\" alt=\"!\"> You can use capital letters and spaces in your title name<br/>";
echo "<img src=\"../avatars/point.gif\" alt=\"!\"> Username must contain at least 4 characters<br/>";
echo "<img src=\"../avatars/point.gif\" alt=\"!\"> Username must not begin with any symbols or numbers<br/>";
echo "<img src=\"../avatars/point.gif\" alt=\"!\"> Username must not be bad words<br/>";
echo "</p>";	
$nick = mysql_fetch_array(mysql_query("SELECT name FROM ibwff_users WHERE id='".$uid."'"));
echo "<p align=\"left\">";
echo "Current Username:";
echo "<b>$nick[0]</b>";
echo "<refresh>
<setvar name=\"nick\" value=\"$nick[0]\"/>
";
echo "</refresh></onevent>";
echo "<form action=\"usershop.php?action=confirm\" method=\"post\">"; 
echo "<p align=\"left\">";
echo "New username: <br/><input name=\"nick\" input type=\"nick Name\" maxlength=\"15\"/><br/>";
echo "<input type=\"submit\" value=\"Change\"/>";
echo "</form>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
exit();
}
/////////////////////////////////////Confirm User Name By CJ UDAY ;)
else if($action=="confirm")
{
 addonline(getuid_sid($sid),"Changing user Name","usershop.php");
    $nick = $_POST['nick'];
    	    echo "<head>";
    echo "<title>Change User Name</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
    echo "<div class=\"header\" align=\"center\">";
	echo "<b>Change Username</b></div>";
    echo "<div class=\"shout2\" align=\"center\">";
    include("pm_by.php");
   $dacaexista = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE name='".$nick."'"));
  if($nickprezent[0]!=$nick)
  {
      if($dacaexista[0]>0)
      {
	   echo "<p align=\"left\">";
        echo "<img src=\"../avatars/notok.gif\"><b>This username Already In Use!!<br/>Choose Another title Name!</b><br/>";
	echo "</p>";
	  }else if((strlen($nick)<4) || (strlen($nick)>15)){
	  echo "<p align=\"left\">";
  echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/><b>Your User Name Should Be Minimum 4 Characters And Maximum 15 Characters!</b><br/>";
		echo "</p>";
		$nmpluss = 800;
  }else if(getplusses(getuid_sid($sid))<$nmpluss)
    {
$remp = $nmpluss - getplusses($uid);
echo "<p align=\"left\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>You Need $remp Points To Change Your userame!<br/>";
echo "</p>";
}else if (isnickblocked($nick)){
echo "<p align=\"left\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/><b>This Name Is Blocked!Try Another Name!!</b><br/>";
echo "</p>";
}else{
   $cow = mysql_fetch_array(mysql_query("SELECT plusses FROM ibwff_users WHERE id='".$uid."'"));
$cow = $cow[0]-$nmpluss;
  $res = mysql_query("UPDATE ibwff_users SET name='$nick', plusses='".$cow."', lastplreas='Last Name Changed: $nick' WHERE id='".$uid."'");
  if($res)
  {
  $ibwff = time()+6*60*60;
$nick = getnick_uid($uid);
mysql_query("INSERT INTO ibwff_events (event,time) values ('<b>$nick</b> Change Her/Him Username','$ibwff')");
	    $sql = "SELECT name FROM ibwff_users WHERE id=$uid";
	    $sql2 = mysql_query($sql);
	    $item = mysql_fetch_array($sql2);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item[0]'"));
if($sex[0]=="M"){$gender = "His";}
if($sex[0]=="F"){$gender = "Her";}
if($sex[0]==""){$gender = "";}
mysql_query("INSERT INTO ibwff_mlog SET action='usename', details='<b>$nick</b> Changed $gender username'");
}
    echo "<img src=\"../avatars/ok.gif\" alt=\"o\"/>You Have Successfully Changed Your username As <b>$nick</b>!<br/><br/>";
  }else{
    echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/><b>Unknown Error!!!Please Try Again Later!!!</b><br/><br/>";
echo "</p><br/><br/>";
  }}}
	echo "<img src=\"../avatars/prev.gif\"><a href=\"usershop.php\">Back to User Shop</a>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
?>
</html>