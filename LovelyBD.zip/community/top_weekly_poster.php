<?php
    $weekago = time();
    $weekago -= 7*24*60*60;
        $sql = "SELECT uid, COUNT(*) as nops FROM ibwff_posts  WHERE dtpost>'".$weekago."'  GROUP BY uid ORDER BY nops LIMIT 1";
    $items = mysql_query($sql);    if(mysql_num_rows($items)>0)
    {
    while ($item = mysql_fetch_array($items))
    {
	    $sql2 = "SELECT name FROM ibwff_users WHERE id=$item[0]";
	    $sql22 = mysql_query($sql2);
	    $item2 = mysql_fetch_array($sql22);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item2[0]'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/> ";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/> ";}
if($sex[0]==""){$usersex = "";}
      		$avlink = getavatar($item[0]);
if($avlink=="")
{
 $avt =  "$usersex";
}else{
 $avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"icon\" width=\"23\" hieght=\"18\"/>";
}
        $unick = getnick_uid($item[0]);
$sql3 = "SELECT name FROM ibwff_users WHERE id=$item[0]";
	    $sql33 = mysql_query($sql3);
	    $item3 = mysql_fetch_array($sql33);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nicks = "<font color=\"blue\"><b>$unick</b></font>";}
if($sex[0]=="F"){$nicks = "<font color=\"deeppink\"><b>$unick</b></font>";}
if($sex[0]==""){$nicks = "";}
      $lnk = "$avt<a href=\"profile.php?who=$item[0]\">$nicks</a>($item[1])";
     }
	 echo "$lnk<br/>";
    }
    }
	}
?>