<?php
$starttime = explode(' ', microtime());
$start = $starttime[1] + $starttime[0];

date_default_timezone_set('Asia/Dhaka');
require_once('../mobile_device_detect.php');
if(!mobile_device_detect()) 
{ 
echo "<card id=\"main\" title=\"(ERROR!)\">";
echo "<p align=\"center\">";
echo "<img src=\"../images/exit.gif\" alt=\"!\"/><br/>";
echo '<b>You cant access this page. Secured By <big>SAHiD</big>!<br/> Download Opera for pc from http://www.Opera.com only this browser allow</b><br/>'; 
echo "<a href=\"http://www.opera.com\"><strong>Download Opera For Pc</strong></a><br />";
echo "<a href=\"http://m.opera.com\"><strong>Download Opera For Mobile</strong></a><br />";
echo "<br />";
echo "</p>";
echo "</card>";
echo "</wml>";
exit(0); 
}

ini_set('arg_separator.output','&amp;');


include("config.php");
ini_set("display_errors", "0"); 


function connectdb()

{

global $dbname, $dbuser, $dbhost, $dbpass;

$conms = @mysql_connect($dbhost,$dbuser,$dbpass); //connect mysql

if(!$conms) return false;

$condb = @mysql_select_db($dbname);

if(!$condb) return false;

global $_SERVER, $HTTP_USER_AGENT, $HTTP_X_DEVICE_USER_AGENT;
$HTTP_USER_AGENT = mysql_real_escape_string(addslashes(strip_tags($HTTP_USER_AGENT)));
$HTTP_X_DEVICE_USER_AGENT = mysql_real_escape_string(addslashes(strip_tags($HTTP_X_DEVICE_USER_AGENT)));
$_SERVER["HTTP_USER_AGENT"] = mysql_real_escape_string(addslashes(strip_tags($_SERVER["HTTP_USER_AGENT"])));
$_SERVER["HTTP_X_DEVICE_USER_AGENT"] = mysql_real_escape_string(addslashes(strip_tags($_SERVER["HTTP_X_DEVICE_USER_AGENT"])));


return true;

}

function eragonbadquery($str) { 
        $search=array("\\","\0","\n","\r","\x1a","'",'"'); 
                $replace=array("\\\\","\\0","\\n","\\r","\Z","\'",'\"'); 
                return str_replace($search,$replace,$str); 
    } 

function fahimsqlsecurityclean($str) { 
        $str = @trim($str);
        $str = eragonbadquery($str);
        $str = htmlspecialchars($str); 
        $str = strip_tags($str); 
        $str = stripslashes($str); 
        $str = stripslashes($str); 
        $str = addslashes($str); 
    return mysql_real_escape_string($str); 
    }



	if (!get_magic_quotes_gpc()) 
{
foreach ($_GET as $key => $value) {$_GET[$key] = addslashes(eragonbadquery(strip_tags(htmlspecialchars($value)))); }
foreach ($_POST as $key => $value) {$_POST[$key] = addslashes(eragonbadquery(strip_tags(htmlspecialchars($value)))); }
foreach ($_REQUEST as $key => $value) {$_REQUEST[$key] = addslashes(eragonbadquery(strip_tags(htmlspecialchars($value)))); }
foreach ($_SERVER as $key => $value) {$_SERVER[$key] = addslashes(eragonbadquery(strip_tags(htmlspecialchars($value)))); }
foreach ($_COOKIE as $key => $value) {$_COOKIE[$key] = addslashes(eragonbadquery(strip_tags(htmlspecialchars($value)))); }
}



function getnick_sid($sid)

{

$uid = mysql_fetch_array(mysql_query("SELECT uid FROM ibwf_ses WHERE id='".$sid."'"));

$uid = $uid[0];

return getnick_uid($uid);

}
/////////
function Quary_Filter($string) 
{
 $badWords = "(union)|(insert)|(drop)|(http)|(iframe)|(script)|(--)|(>)|(<)|(')|(^)|(#)|(%)|(php)|(rp)|(madarchod)|(chod)|(fuck)|(mastercredit)|(bdremix)|(khanki)|(benchod)|(www)|(plusbd)|(magi)|(gand)|(lund)|(boobs)|(bhosdi)|(lauda)|(baap)|(bhosda)|(rockerwap)|(n3t)|(spicecult)|(perm)|(cyberpowereragon)|(perm='4')|(perm=4)|(plusess)|(,)"; 
 $string = eregi_replace($badWords, "", $string);
 $string = preg_replace(array('/[^a-zA-Z0-9\ \-\_\/\*\(\)\[\]\?\.\,\:\&\@\=\+]/'),array('', '', ''),$string);
 $string = mysql_real_escape_string(htmlspecialchars($string)); 

return $string;
 }
 //////////
 function check_injection(){
$badchars = array("TRUNCATE","META","SCRIPT","EXEC","CAST","DECLARE","CHAR","DROP", "SELECT", "fuck", "DELETE", "INSERT" , "UNION", "WHERE", "FROM","madrchod","CHUDI","plusbd","perm='4","bhenchod","livechat","w4c","w2c","madarchod", "CONVERT");
foreach($_GET AS $chk){
	for($i=0;$i<=11;$i++){
		if(substr_count(strtoupper($chk),$badchars[$i])>0){
		$sesID = $_GET['sesID'];
		$name = getnick_sesID($sesID);
	$indiatime = time() + addhours();
    $sql="INSERT INTO ibwf_mlog SET action='Hack Attempts', details='<b>$name</b> tried some SQLi!', actdt=".time()."'";
	$result=mysql_query($sql);// or die(mysql_error());
			echo "<p style=\"text-align: center\">Oh Kids!! You need to learn first.. :P Coz u r try to inject and your log send to SAHiD.. lOl.. Go and larn 1st.. then try to inject your moms ass... :D<p>";
			exit();
		}
	}
}
	//return;
}
///////////////////// Its time to fuck browser
function fuckbrowser()
{
$user_agent = $_SERVER['HTTP_USER_AGENT']; 
if(preg_match('/(google|bot|plusses|email|signature|posts|sex|birthday|password2|pass|name|co518|php|prince|mowser|rp|chmsgs|mastercredit|hack|perm|fuck|chmsgs|goldencoin)/i',strtolower($user_agent))){

    echo "<card id=\"main\" title=\"Secured By SAHID\">";
    echo "<p align=\"center\">";
    echo "<img src=\"../images/notok.gif\" alt=\"!\"/><br/>";
echo "<b>Hello Motherfucker, Your are just a kid..</b>";
echo "<br/><b>You can't hacked...So Not Think About that again.. Go, Learn first then come back.. !</b><br/>";
	echo "<b>Secured By: <big>SaHiD</big></b><br/>";
    echo "<a href=\"index.php\">[Home]</a>";
    echo "</p>";
    echo "</card>";
    echo "</wml>";
    mysql_close();
    exit();
}
}

////////////////get real browser
function browser_agent($_mob_browser){$_mob_browser=fahimsqlsecurityclean($_mob_browser);
  if(preg_match('/(google|bot)/i',strtolower($_mob_browser))){
 $position = strpos(strtolower($_mob_browser),"bot");
 $_mob_browser = substr($_mob_browser, $position-30, $position+2);
 $_browser = explode (" ", $_mob_browser);
 $_browser = array_reverse($_browser); 
 }else if (isset($_SERVER['HTTP_X_OPERAMINI_PHONE_UA'])) {
 $_mob_browser = $_SERVER['HTTP_X_OPERAMINI_PHONE_UA'];
 $_position=strpos(strtolower($_mob_browser),"nokia");$position=strpos(strtolower($_mob_browser),"android");
 if($_position){$_mob_browser = substr($_mob_browser, $_position,25);}
 else{if($position){$_mob_browser = substr($_mob_browser, $position,25);$_browser = explode ('-', $_mob_browser);return fahimsqlsecurityclean($_browser[0]);}}
 $_browser = explode (' ', $_mob_browser);
 }else if (isset($_SERVER['HTTP_X_BOLT_PHONE_UA'])) {
 $_mob_browser = $_SERVER['HTTP_X_BOLT_PHONE_UA'];
 $_position=strpos(strtolower($_mob_browser),"nokia");$position=strpos(strtolower($_mob_browser),"android");
 if($_position){$_mob_browser = substr($_mob_browser, $_position,25);}
 else{if($position)$_mob_browser = substr($_mob_browser, $position,25);$_browser = explode ('-', $_mob_browser);return fahimsqlsecurityclean($_browser[0]);}
 $_browser = explode (' ', $_mob_browser); }else if (isset($_SERVER['HTTP_X_MOBILE_UA'])) {
 $_mob_browser = $_SERVER['HTTP_X_MOBILE_UA'];
 $_position=strpos(strtolower($_mob_browser),"nokia");$position=strpos(strtolower($_mob_browser),"android");
 if($_position){$_mob_browser = substr($_mob_browser, $_position,25);}
 else{if($position){$_mob_browser = substr($_mob_browser, $position,25);$_browser = explode ('-', $_mob_browser);return fahimsqlsecurityclean($_browser[0]);}}
 $_browser = explode (' ', $_mob_browser); }else if(isset($_SERVER['HTTP_X_devICE_USER_AGENT'])) {
 $_mob_browser = $_SERVER['HTTP_X_devICE_USER_AGENT'];
 $_position=strpos(strtolower($_mob_browser),"nokia");$position=strpos(strtolower($_mob_browser),"android");
 if($_position){$_mob_browser = substr($_mob_browser, $_position,25);}
 else{if($position){$_mob_browser = substr($_mob_browser, $position,25);$_browser = explode ('-', $_mob_browser);return fahimsqlsecurityclean($_browser[0]);}}
 $_browser = explode (' ', $_mob_browser);}else{$_position=strpos(strtolower($_mob_browser),"nokia");$position=strpos(strtolower($_mob_browser),"android");
 if($_position){$_mob_browser = substr($_mob_browser, $_position,25);}
 else{if($position){$_mob_browser = substr($_mob_browser, $position,25);$_browser = explode ('-', $_mob_browser);return fahimsqlsecurityclean($_browser[0]);}}
 
 $_browser = explode (' ', $_mob_browser);
 }
   
            return fahimsqlsecurityclean($_browser[0]);            
}
////////////
function getbrowser(){
if (isset($_SERVER)){
$browserA = explode("(",$_SERVER["HTTP_USER_AGENT"]); 
$browserB = explode(")",$browserA[1]);
$browser = $browserA[0]."(".$browserB[0]." ".$browserB[1].")";
}else{
$browserA = explode("(",getenv("HTTP_USER_AGENT")); 
$browserB = explode(")",$browserA[1]);
$browser = $browserA[0]."(".$browserB[0]." ".$browserB[1].")";
}

return $browser; 

}
///////
function getoribrowser($_mob_browser){
if(preg_match('/(google|bot)/i',strtolower($_mob_browser))){
$position = strpos(strtolower($_mob_browser),"bot");
$_mob_browser = substr($_mob_browser, $position-30, $position+2);
$_browser = explode (" ", $_mob_browser);
$_browser = array_reverse($_browser); 
}else if (isset($_SERVER['HTTP_X_OPERAMINI_PHONE_UA'])) {
$_mob_browser = $_SERVER['HTTP_X_OPERAMINI_PHONE_UA'];
$_position=strpos(strtolower($_mob_browser),"nokia");
if($_position)$_mob_browser = substr($_mob_browser, $_position,25);
$_browser = explode ("/", $_mob_browser);
}else {
$_position=strpos(strtolower($_mob_browser),"nokia");
if($_position)$_mob_browser = substr($_mob_browser, $_position,25);
$_browser = explode ("/", $_mob_browser);
}
return $_browser[0];
}
////////////get real ip
/*function get_real_ip()
{
     $ip = false;
     if(!empty($_SERVER['HTTP_CLIENT_IP']))
     {
          $ip = $_SERVER['HTTP_CLIENT_IP'];
     }
     if(!empty($_SERVER['HTTP_X_FOfbdARDED_FOR']))
     {
          $ips = explode(", ", $_SERVER['HTTP_X_FOfbdARDED_FOR']);
          if($ip)
          {
               array_unshift($ips, $ip);
               $ip = false;
          }
          for($i = 0; $i < count($ips); $i++)
          {
               if(!preg_match("/^(10|172\.16|192\.168)\./i", $ips[$i]))
               {
                    if(version_compare(phpversion(), "5.0.0", ">="))
                    {
                         if(ip2long($ips[$i]) != false)
                         {
                              $ip = $ips[$i];
                              break;
                         }
                    }
                    else
                    {
                         if(ip2long($ips[$i]) != - 1)
                         {
                              $ip = $ips[$i];
                              break;
                         }
                    }
               }
          }
     }
     return ($ip ? $ip : $_SERVER['REMOTE_ADDR']);
} 

$ip = get_real_ip();
$two_letter_country_code=iptocountry($ip);
function iptocountry($ip) {
    $numbers = preg_split( "/\./", $ip);
    include("../ip_files/".$numbers[0].".php");
    $code=($numbers[0] * 16777216) + ($numbers[1] * 65536) + ($numbers[2] * 256) + ($numbers[3]);
    foreach($ranges as $key => $value){
        if($key<=$code){
            if($ranges[$key][0]>=$code){$two_letter_country_code=$ranges[$key][1];break;}
            }
    }
    if ($two_letter_country_code==""){$two_letter_country_code="unknown";}
    return $two_letter_country_code;
}
*/
////////////////
function get_real_ip()
{
  $proxy_headers = array(
                          'CLIENT_IP', 
                          'FORWARDED', 
                          'FORWARDED_FOR', 
                          'FORWARDED_FOR_IP', 
                          'HTTP_CLIENT_IP', 
                          'HTTP_FORWARDED', 
                          'HTTP_FORWARDED_FOR', 
                          'HTTP_FORWARDED_FOR_IP', 
                          'HTTP_PC_REMOTE_ADDR', 
                          'HTTP_PROXY_CONNECTION',
                          'HTTP_VIA', 
                          'HTTP_X_FORWARDED', 
                          'HTTP_X_FORWARDED_FOR', 
                          'HTTP_X_FORWARDED_FOR_IP', 
                          'HTTP_X_IMFORWARDS', 
                          'HTTP_XROXY_CONNECTION', 
                          'VIA', 
                          'X_FORWARDED', 
                          'X_FORWARDED_FOR'
                         );
     $ip = false;
     if(!empty($_SERVER['HTTP_CLIENT_IP']))
     {
          $ip = $_SERVER['HTTP_CLIENT_IP'];
     }
     if(!empty($_SERVER['HTTP_X_FOfbdARDED_FOR']))
     {
          $ips = explode(", ", $_SERVER['HTTP_X_FOfbdARDED_FOR']);
          if($ip)
          {
               array_unshift($ips, $ip);
               $ip = false;
          }
          for($i = 0; $i < count($ips); $i++)
          {
               if(!preg_match("/^([1-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(\.([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])){3}$/", $ips[$i], $proxy_header_temp))
               {
                    if(version_compare(phpversion(), "5.0.0", ">="))
                    {
                         if(ip2long($ips[$i]) != false)
                         {
                              $ip = $ips[$i];
                              break;
                         }
                    }
                    else
                    {
                         if(ip2long($ips[$i]) != - 1)
                         {
                              $ip = $ips[$i];
                              break;
                         }
                    }
               }
          }
     }
     return ($ip ? $ip : $_SERVER['REMOTE_ADDR']);
} 

$ip = get_real_ip();
$two_letter_country_code=iptocountry($ip);
function iptocountry($ip) {
    $numbers = preg_split( "/\./", $ip);
    include("../ip_files/".$numbers[0].".php");
    $code=($numbers[0] * 16777216) + ($numbers[1] * 65536) + ($numbers[2] * 256) + ($numbers[3]);
    foreach($ranges as $key => $value){
        if($key<=$code){
            if($ranges[$key][0]>=$code){$two_letter_country_code=$ranges[$key][1];break;}
            }
    }
    if ($two_letter_country_code==""){$two_letter_country_code="unknown";}
    return $two_letter_country_code;
}
//////////////////
/*function get_real_ip2()
{
  $proxy_headers = array(
                          'CLIENT_IP', 
                          'FORWARDED', 
                          'FORWARDED_FOR', 
                          'FORWARDED_FOR_IP', 
                          'HTTP_CLIENT_IP', 
                          'HTTP_FORWARDED', 
                          'HTTP_FORWARDED_FOR', 
                          'HTTP_FORWARDED_FOR_IP', 
                          'HTTP_PC_REMOTE_ADDR', 
                          'HTTP_PROXY_CONNECTION',
                          'HTTP_VIA', 
                          'HTTP_X_FORWARDED', 
                          'HTTP_X_FORWARDED_FOR', 
                          'HTTP_X_FORWARDED_FOR_IP', 
                          'HTTP_X_IMFORWARDS', 
                          'HTTP_XROXY_CONNECTION', 
                          'VIA', 
                          'X_FORWARDED', 
                          'X_FORWARDED_FOR'
                         );

  foreach($proxy_headers as $proxy_header)
  {
    if(isset($_SERVER[$proxy_header]) && preg_match("/^([1-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(\.([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])){3}$/", $_SERVER[$proxy_header]))
    {
        return $_SERVER[$proxy_header];
    }
    else if(stristr(',', $_SERVER[$proxy_header]) !== FALSE)
    {
      $proxy_header_temp = trim(array_shift(explode(',', $_SERVER[$proxy_header]))); 

      if(($pos_temp = stripos($proxy_header_temp, ':')) !== FALSE)
	  $proxy_header_temp = substr($proxy_header_temp, 0, $pos_temp);

      if(preg_match("/^([1-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(\.([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])){3}$/", $proxy_header_temp)
	  return $proxy_header_temp;
    }
  }

  return $_SERVER['REMOTE_ADDR'];
}*/
/////////User Agent Banned

function isuseragentban($brm)
{
  
  $pinf = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_penalties WHERE penalty='3' AND browserm='".$brm."'"));
  if($pinf[0]>0)
  {
  return true;
}
return false;
}
///////////////////////////////////////////is pmban?
function ispmban($uid)
{
$not = mysql_fetch_array(mysql_query("SELECT pmban FROM ibwf_users WHERE id='".$uid."'"));
if($not[0]=='1')
{
return true;
}else{
return false;
}
}
///////////////////////////////////////////is postban?
function ispostban($uid)
{
$not = mysql_fetch_array(mysql_query("SELECT postban FROM ibwf_users WHERE id='".$uid."'"));
if($not[0]=='1')
{
return true;
}else{
return false;
}
}
///////////////////////////////////////////is chatban?
function ischatban($uid)
{
$not = mysql_fetch_array(mysql_query("SELECT chatban FROM ibwf_users WHERE id='".$uid."'"));
if($not[0]=='1')
{
return true;
}else{
return false;
}
}
///////////////////////////////////////////is forumban?
function isforumban($uid)
{
$not = mysql_fetch_array(mysql_query("SELECT forumban FROM ibwf_users WHERE id='".$uid."'"));
if($not[0]=='1')
{
return true;
}else{
return false;
}
}
///////////////////////////////////////////is shoutban?
function isshoutban($uid)
{
$not = mysql_fetch_array(mysql_query("SELECT shoutban FROM ibwf_users WHERE id='".$uid."'"));
if($not[0]=='1')
{
return true;
}else{
return false;
}
}
////////////////Function Ban

function bancount()
{
if(isuseragentban($ubr))
  {
if(!isshield($uid))
  {
 echo "<card id=\"main\" title=\"Error!!!!!!!!!\">";
     
	  echo "<p align=\"center\">";

      echo "<img src=\"../images/notok.gif\" alt=\"!\"/>";

  echo "<b>This BROWSER is blocked!!!</b><br/>";
  echo "<br/>";
  $banto = mysql_fetch_array(mysql_query("SELECT  timeto FROM ibwf_penalties WHERE  penalty='3' AND ipadd='".$uip."' AND browserm='".$ubr."' LIMIT 1 "));

  echo "<b>Shield Users or Safe user can login here</b><br/>";

  echo "<b>Username:</b><br/><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";

  echo "<b>Password:</b><br/><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";

  echo "<anchor><small>Login &#187;</small><go href=\"login.php\" method=\"get\">";

  echo "<postfield name=\"loguid\" value=\"$(loguid)\"/>";

  echo "<postfield name=\"logpwd\" value=\"$(logpwd)\"/>";

  echo "</go></anchor><br/>";
  
    echo "</p>";

    echo "</card>";

    echo "</wml>";
 
 mysql_close();

 exit();
  }
}


}





////////////////////////Get user id from session id



function getuid_sid($sid)

{

$uid = mysql_fetch_array(mysql_query("SELECT uid FROM ibwf_ses WHERE id='".$sid."'"));

$uid = $uid[0];

return $uid;

}

function mobads()

{

$mob_mode = "test";
$mob_ua = urlencode(getenv("HTTP_USER_AGENT"));

$mob_ip = urlencode($_SERVER['REMOTE_ADDR']);



if ($mob_mode=='live')

//$mob_m = "&m";

//$mob_url = 'http://ads.admob.com/ad_source.php?s=a14ad2c6874b861&u='.$mob_ua.'&i='.$mob_ip.$mob_m;

//@$mob_ad_serve = fopen($mob_url,'r');

if ($mob_ad_serve)

{

while (!feof($mob_ad_serve))

$mob_contents .= fread($mob_ad_serve,1024);

fclose($mob_ad_serve);

}

$mob_link = explode("><",$mob_contents);

$mob_ad_text = $mob_link[0];

$mob_ad_link = $mob_link[1];

if (isset($mob_ad_link) && ($mob_ad_link !=''))

$ret = "<p align=\"center\"><small><a href=\"$mob_ad_link\">$mob_ad_text</a></small></p>";

else

$ret = $mob_alternate_link;



return $ret;



}

function findcard($tcode)

{

$st =strpos($tcode,"[card=");

if ($st === false)

{

return $tcode;

}else

{

$ed =strpos($tcode,"[/card]");

if($ed=== false)

{

return $tcode;

}

}

$texth = substr($tcode,0,$st);

$textf = substr($tcode,$ed+7);

$msg = substr($tcode,$st+10,$ed-$st-10);

$cid = substr($tcode,$st+6,3);

$words = explode(' ',$msg);

$msg = implode('+',$words);

return "$texth<br/><img src=\"pmcard.php?cid=$cid&msg=$msg\" alt=\"$cid\"/><br/>$textf";

}

function saveuinfo($sid,$chkbit)

{

if($chkbit==1){

if($SERVER_ADDR=='66.79.163.46'){

return false;

}

else {

return true;

}

exit;

}

$headers = apache_request_headers();

$alli = "";

foreach ($headers as $header => $value)

{

$alli .= "$header: $value <br />\n";

}

$alli .= "IP: ".$_SERVER['REMOTE_ADDR']."<br/>";

$alli .= "REFERRER: ".$_SERVER['HTTP_REFERER']."<br/>";

$alli .= "REMOTE HOST: ".getenv('REMOTE_HOST')."<br/>";

$alli .= "PROX: ".$_SERVER['HTTP_X_FORWARDED_FOR']."<br/>";

$alli .= "HOST: ".getenv('HTTP_X_FORWARDED_HOST')."<br/>";

$alli .= "SERV: ".getenv('HTTP_X_FORWARDED_SERVER')."<br/>";

if(trim($sid)!="")

{

$uid = getuid_sid($sid);

$fname = "tmp/".getnick_uid($uid).".rwi";

$out = fopen($fname,"w");

fwrite($out,$alli);

fclose($out);

}



//return 0;

}

function registerform($ef)

{

$ue = $errl = $pe = $ce = "";

switch($ef)

{

case 1:

$errl = "<img src=\"../images/point.gif\" alt=\"!\"/> Please type your Username";

$ue = "<img src=\"../images/point.gif\" alt=\"!\"/>";

break;

case 2:

$errl = "<img src=\"../images/point.gif\" alt=\"!\"/> Please type your password";

$pe = "<img src=\"../images/point.gif\" alt=\"!\"/>";

break;

case 3:

$errl = "<img src=\"../images/point.gif\" alt=\"!\"/> Please type your password again";

$ce = "<img src=\"../images/point.gif\" alt=\"!\"/>";

break;

case 4:

$errl = "<img src=\"../images/point.gif\" alt=\"!\"/> Username is invalid";

$ue = "<img src=\"../images/point.gif\" alt=\"!\"/>";

break;

case 5:

$errl = "<img src=\"../images/point.gif\" alt=\"!\"/> Password is invalid";

$pe = "<img src=\"../images/point.gif\" alt=\"!\"/>";

break;

case 6:

$errl = "<img src=\"../images/point.gif\" alt=\"!\"/> Passwords doesn't match";

$ce = "<img src=\"../images/point.gif\" alt=\"!\"/>";

break;

case 7:

$errl = "<img src=\"../images/point.gif\" alt=\"!\"/> Username must be 4 characters or more";

$ue = "<img src=\"../images/point.gif\" alt=\"!\"/>";

break;

case 8:

$errl = "<img src=\"../images/point.gif\" alt=\"!\"/> Password must be 4 characters or more";

$pe = "<img src=\"../images/point.gif\" alt=\"!\"/>";

break;

case 9:

$errl = "<img src=\"../images/point.gif\" alt=\"!\"/> Username already in use, choose a different one";

$ue = "<img src=\"../images/point.gif\" alt=\"!\"/>";

break;

case 10:

$errl = "<img src=\"../images/point.gif\" alt=\"!\"/> Unknown mysql error try registering later";



break;

case 11:

$errl = "<img src=\"../images/point.gif\" alt=\"!\"/> Username must start with a letter from a-z";

$ue = "<img src=\"../images/point.gif\" alt=\"!\"/>";

break;

case 12:

$errl = "<img src=\"../images/point.gif\" alt=\"!\"/> Username is reserved for admins of the site";

$ue = "<img src=\"../images/point.gif\" alt=\"!\"/>";

break;

case 13:

$errl = "<img src=\"../images/point.gif\" alt=\"!\"/> Please choose an appropriate username";

$ue = "<img src=\"../images/point.gif\" alt=\"!\"/>";

break;

case 14:

$errl = "<img src=\"../images/point.gif\" alt=\"!\"/> U must enter an email address";

$ue = "<img src=\"../images/point.gif\" alt=\"!\"/>";

break;

}

$rform = "$ue Username: <input name=\"tfuid\" format=\"*x\" maxlength=\"15\"/><br/>";

$rform .= "$pe Password: <input type=\"password\" name=\"tfpwd\" format=\"*x\" maxlength=\"30\"/><br/>";

$rform .= "$ce Password: <input type=\"password\" name=\"tfcpw\" format=\"*x\" maxlength=\"30\"/><br/>";

$rform .= "<img src=\"../images/point.gif\" alt=\"!\"/>Date Of Birth:<br/>";

$rform .= "<select name=\"day\" value=\"01\">";

$rform .= "<option value=\"01\">1</option>";

$rform .= "<option value=\"02\">2</option>";

$rform .= "<option value=\"03\">3</option>";

$rform .= "<option value=\"04\">4</option>";

$rform .= "<option value=\"05\">5</option>";

$rform .= "<option value=\"06\">6</option>";

$rform .= "<option value=\"07\">7</option>";

$rform .= "<option value=\"08\">8</option>";

$rform .= "<option value=\"09\">9</option>";

$rform .= "<option value=\"10\">10</option>";

$rform .= "<option value=\"11\">11</option>";

$rform .= "<option value=\"12\">12</option>";

$rform .= "<option value=\"13\">13</option>";

$rform .= "<option value=\"14\">14</option>";

$rform .= "<option value=\"15\">15</option>";

$rform .= "<option value=\"16\">16</option>";

$rform .= "<option value=\"17\">17</option>";

$rform .= "<option value=\"18\">18</option>";

$rform .= "<option value=\"19\">19</option>";

$rform .= "<option value=\"20\">20</option>";

$rform .= "<option value=\"21\">21</option>";

$rform .= "<option value=\"22\">22</option>";

$rform .= "<option value=\"23\">23</option>";

$rform .= "<option value=\"24\">24</option>";

$rform .= "<option value=\"25\">25</option>";

$rform .= "<option value=\"26\">26</option>";

$rform .= "<option value=\"27\">27</option>";

$rform .= "<option value=\"28\">28</option>";

$rform .= "<option value=\"29\">29</option>";

$rform .= "<option value=\"30\">30</option>";

$rform .= "<option value=\"31\">31</option>";

$rform .= "</select><br/>";

$rform .= "<select name=\"month\" value=\"01-\">";

$rform .= "<option value=\"01-\">Jan</option>";

$rform .= "<option value=\"02-\">Feb</option>";

$rform .= "<option value=\"03-\">Mar</option>";

$rform .= "<option value=\"04-\">Apr</option>";

$rform .= "<option value=\"05-\">May</option>";

$rform .= "<option value=\"06-\">Jun</option>";

$rform .= "<option value=\"07-\">Jul</option>";

$rform .= "<option value=\"08-\">Aug</option>";

$rform .= "<option value=\"09-\">Sep</option>";

$rform .= "<option value=\"10-\">Oct</option>";

$rform .= "<option value=\"11-\">Nov</option>";

$rform .= "<option value=\"12-\">Dec</option>";

$rform .= "</select><br/>";

$rform .= "<select name=\"year\" value=\"1992-\">";

$rform .= "<option value=\"1992-\">1992</option>";

$rform .= "<option value=\"1991-\">1991</option>";

$rform .= "<option value=\"1990-\">1990</option>";

$rform .= "<option value=\"1989-\">1989</option>";

$rform .= "<option value=\"1988-\">1988</option>";

$rform .= "<option value=\"1987-\">1987</option>";

$rform .= "<option value=\"1986-\">1986</option>";

$rform .= "<option value=\"1985-\">1985</option>";

$rform .= "<option value=\"1984-\">1984</option>";

$rform .= "<option value=\"1983-\">1983</option>";

$rform .= "<option value=\"1982-\">1982</option>";

$rform .= "<option value=\"1981-\">1981</option>";

$rform .= "<option value=\"1980-\">1980</option>";

$rform .= "<option value=\"1979-\">1979</option>";

$rform .= "<option value=\"1978-\">1978</option>";

$rform .= "<option value=\"1977-\">1977</option>";

$rform .= "<option value=\"1976-\">1976</option>";

$rform .= "<option value=\"1975-\">1975</option>";

$rform .= "<option value=\"1974-\">1974</option>";

$rform .= "<option value=\"1973-\">1973</option>";

$rform .= "<option value=\"1972-\">1972</option>";

$rform .= "<option value=\"1971-\">1971</option>";

$rform .= "<option value=\"1970-\">1970</option>";

$rform .= "<option value=\"1979-\">1979</option>";

$rform .= "<option value=\"1978-\">1978</option>";

$rform .= "<option value=\"1977-\">1977</option>";

$rform .= "<option value=\"1976-\">1976</option>";

$rform .= "<option value=\"1975-\">1975</option>";

$rform .= "<option value=\"1974-\">1974</option>";

$rform .= "<option value=\"1973-\">1973</option>";

$rform .= "<option value=\"1972-\">1972</option>";

$rform .= "<option value=\"1971-\">1971</option>";

$rform .= "<option value=\"1970-\">1970</option>";

$rform .= "<option value=\"1969-\">1969</option>";

$rform .= "<option value=\"1968-\">1968</option>";

$rform .= "<option value=\"1967-\">1967</option>";

$rform .= "<option value=\"1966-\">1966</option>";

$rform .= "</select><br/>";
////////////////
$rform .= "Sex:";

$rform .= "<select name=\"opsex\" value=\"M\">";

$rform .= "<option value=\"M\">Male</option>";

$rform .= "<option value=\"F\">Female</option>";

$rform .= "</select><br/>";

$rform .= "Country:<br/><select name=\"state\" value=\"Bangladesh\">";

    $rform .= "<option value=\"Bangladesh\">Bangladesh</option>";

    $rform .= "<option value=\"India\">India</option>";

    $rform .= "<option value=\"Indonesia\">Indonesia</option>";

    $rform .= "<option value=\"Johor\">Johor</option>";

    $rform .= "<option value=\"Kedah\">Kedah</option>";

    $rform .= "<option value=\"Kelantan\">Kelantan</option>";

    $rform .= "<option value=\"Kuala Lumpur\">Kuala Lumpur</option>";

    $rform .= "<option value=\"Melaka\">Melaka</option>";

    $rform .= "<option value=\"Negeri Sembilan\">Negeri Sembilan</option>";

    $rform .= "<option value=\"Pahang\">Pahang</option>";

    $rform .= "<option value=\"Pulau Pinang\">Pulau Pinang</option>";

    $rform .= "<option value=\"Perak\">Perak</option>";

    $rform .= "<option value=\"Perlis\">Perlis</option>";

    $rform .= "<option value=\"Sabah\">Sabah</option>";

    $rform .= "<option value=\"Sarawak\">Sarawak</option>";

    $rform .= "<option value=\"Selangor\">Selangor</option>";

    $rform .= "<option value=\"Terengganu\">Terengganu</option>";

    $rform .= "</select><br/>";

////////////////////



//$rform .= "Location: <input name=\"tfloc\"  maxlength=\"100\"/><br/>";

    $rform .= "Relationship: <br/><select name=\"status\" value=\"Single\">";

   $rform .= "<option value=\"Single\">Single</option>";

   $rform .= "<option value=\"Engaged\">Engaged</option>";

   $rform .= "<option value=\"Married\">Married</option>";

   $rform .= "<option value=\"In Relationship\">In Relationship</option>";

  $rform .= "<option value=\"In Love\">In Love</option>";

  $rform .= "<option value=\"Its Complicated\">Its Complicated</option>";

  $rform .= "</select><br/>";
  ////////
  $rform .= "Looking For: <br/><select name=\"looked\" value=\"Friendship\">";

  $rform .= "<option value=\"Friendship\">Friendship</option>";

  $rform .= "<option value=\"Dating\">Dating</option>";

  $rform .= "<option value=\"Relationship\">Relationship</option>";

  $rform .= "<option value=\"Networking\">Networking</option>";

  $rform .= "<option value=\"True Love\">True Love</option>";

  $rform .= "<option value=\"Just For Fun\">Just For Fun</option>";

  $rform .= "</select><br/>";
  //////////
    $rform .= "Religion: <br/><select name=\"religious\" value=\"Islam\">";

  $rform .= "<option value=\"Islam\">Islam</option>";

  $rform .= "<option value=\"Christianity\">Christianity</option>";

  $rform .= "<option value=\"Hinduism\">Hinduism</option>";

  $rform .= "<option value=\"Buddhism\">Buddhism</option>";

  $rform .= "<option value=\"Irreligios\">Irreligios</option>";

  $rform .= "<option value=\"Others\">Others</option>";

  $rform .= "</select><br/>";
    //////////
    $rform .= "Interested In: <br/><select name=\"interested\" value=\"Men\">";

  $rform .= "<option value=\"Men\">Men</option>";

  $rform .= "<option value=\"Women\">Women</option>";

  $rform .= "<option value=\"Both\">Both</option>";

  $rform .= "</select><br/>";
  ////////////////
    $fcats = mysql_query("SELECT id, name FROM ibwf_users ORDER BY id, name");
  $rform .= "Invited By:<br/> <select name=\"invited\">";
  while ($fcat=mysql_fetch_array($fcats))
  {
  $rform .= "<option value=\"$fcat[1]\">$fcat[1]</option>";
  }
  $rform .= "</select><br/>";
  ///////////////

$string=rand(1000,1043000);
$rform .= "Type The Code Shown On The Picture:<br/><img src=\"img.php?$string\" alt=\"***\"/>";
$rform .= "<br/><input name=\"mcode\" maxlength=\"4\"/><br/>";

$rform .= "<anchor>Register";

$rform .= "<go href=\"register.php\" method=\"post\">";

$rform .= "<postfield name=\"uid\" value=\"$(tfuid)\"/>";

$rform .= "<postfield name=\"pwd\" value=\"$(tfpwd)\"/>";

$rform .= "<postfield name=\"cpw\" value=\"$(tfcpw)\"/>";

$rform .= "<postfield name=\"day\" value=\"$(day)\"/>";

$rform .= "<postfield name=\"month\" value=\"$(month)\"/>";

$rform .= "<postfield name=\"year\" value=\"$(year)\"/>";

$rform .= "<postfield name=\"states\" value=\"$(states)\"/>";

$rform .= "<postfield name=\"status\" value=\"$(status)\"/>";

$rform .= "<postfield name=\"looked\" value=\"$(looked)\"/>";

$rform .= "<postfield name=\"usx\" value=\"$(opsex)\"/>";

$rform .= "<postfield name=\"religious\" value=\"$(religious)\"/>";

$rform .= "<postfield name=\"invited\" value=\"$(invited)\"/>";

$rform .= "<postfield name=\"interested\" value=\"$(interested)\"/>";

$rform .= "<postfield name=\"mcode\" value=\"$(mcode)\"/>";

$rform .= "</go></anchor><br/>";

$rform .= "<br/>$errl";

return $rform;

}



/////////////////////////////////////////////until starsign

function getstarsign($date){
list($year,$month,$day)=explode("-",$date);
if(($month=='1' && $day>='20')||($month=='2' && $day<='18')){
return "<img src=\"../ZODIAC/aquarius.gif\" alt=\"*\"/> Aquarius - Water Bearer";
}else if(($month=='02' && $day>='19')||($month=='03' && $day<='20')){
return "<img src=\"../ZODIAC/pisces.gif\" alt=\"*\"/> Pisces - Fish";
}else if(($month=='03' && $day>='21')||($month=='04' && $day<='19')){
return "<img src=\"../ZODIAC/aries.gif\" alt=\"*\"/> Aries - Ram";
}else if(($month=='04' && $day>='20')||($month=='05' && $day<='20')){
return "<img src=\"../ZODIAC/taurus.gif\" alt=\"*\"/> Taurus - Bull";
}else if(($month=='05' && $day>='21')||($month=='06' && $day<='20')){
return "<img src=\"../ZODIAC/gemini.gif\" alt=\"*\"/> Gemini - Twins";
}else if(($month=='6' && $day>='21')||($month=='07' && $day<='22')){
return "<img src=\"../ZODIAC/cancer.gif\" alt=\"*\"/> Cancer - Crab";
}else if(($month=='07' && $day>='23')||($month=='08' && $day<='22')){
return "<img src=\"../ZODIAC/leo.gif\" alt=\"*\"/> Leo - Lion";
}else if(($month=='08' && $day>='23')||($month=='09' && $day<='22')){
return "<img src=\"../ZODIAC/virgo.gif\" alt=\"*\"/> Virgo - Virgin";
}else if(($month=='09' && $day>='23')||($month=='10' && $day<='22')){
return "<img src=\"../ZODIAC/libra.gif\" alt=\"*\"/> Libra - Balance";
}else if(($month=='10' && $day>='23')||($month=='11' && $day<='21')){
return "<img src=\"../ZODIAC/scorpio.gif\" alt=\"*\"/> Scorpio - Scorpion";
}else if(($month=='11' && $day>='22')||($month=='12' && $day<='21')){
return "<img src=\"../ZODIAC/sagittarius.gif\" alt=\"*\"/> Sagittarius - Archer";
}else if(($month=='12' && $day>='22')||($month=='01' && $day<='19')){
return "<img src=\"../ZODIAC/capricorn.gif\" alt=\"*\"/> Capricorn - Goat";
}else{
return "Update Your DOB";
}
}
/////////////////////////////////////////////Forum Link



function forumlink($sid)

{

$categories = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_fcats"));

if($categories[0]==1)

{

$fcats = mysql_query("SELECT id, name FROM ibwf_fcats ORDER BY position, id");

while($fcat=mysql_fetch_array($fcats))

{

$link = "<a href=\"index.php?action=viewcat&sid=$sid&cid=$fcat[0]\">$fcat[1]</a><br/>";

}

}else{

$link = "<a href=\"index.php?action=forumindx&sid=$sid\">Forums</a><br/>";

}

return $link;

}

///// RATING ///////
function rating($uid)
{
$info = mysql_fetch_array(mysql_query("SELECT plusses, gplus, shouts, chmsgs FROM ibwf_users WHERE id='".$uid."'"));
$pl = $info[0];
$gp = $info[1];
$sh = $info[2];
$ch = $info[3];
$infototal = ($pl + $gp + $sh + $ch);
if($infototal<10)
{
return "<img src=\"../images/empty.gif\" alt=\"\"/>";
}
else if($infototal<100)
{
return "<img src=\"../images/half.gif\" alt=\"\"/>";
}
else if($infototal<300)
{
return "<img src=\"../images/one.gif\" alt=\"\"/>";
}
else if($infototal<500)
{
return "<img src=\"../images/onehalf.gif\" alt=\"\"/>";
}
else if($infototal<1000)
{
return "<img src=\"../images/two.gif\" alt=\"\"/>";
}
else if($infototal<1500)
{
return "<img src=\"../images/twohalf.gif\" alt=\"\"/>";
}
else if($infototal<2000)
{
return "<img src=\"../images/three.gif\" alt=\"\"/>";
}
else if($infototal<2500)
{
return "<img src=\"../images/threehalf.gif\" alt=\"\"/>";
}
else if($infototal<3000)
{
return "<img src=\"../images/four.gif\" alt=\"\"/>";
}
else if($infototal<4000)
{
return "<img src=\"../images/fourhalf.gif\" alt=\"\"/>";
}
else if($infototal<5000)
{
return "<img src=\"../images/five.gif\" alt=\"\"/>";
}
else if($infototal<6000)
{
return "<img src=\"../images/fivehalf.gif\" alt=\"\"/>";
}
else if($infototal<7000)
{
return "<img src=\"../images/six.gif\" alt=\"\"/>";
}
else if($infototal<8000)
{
return "<img src=\"../images/sixhalf.gif\" alt=\"\"/>";
}
else if($infototal<9000)
{
return "<img src=\"../images/seven.gif\" alt=\"\"/>";
}
else if($infototal<10000)
{
return "<img src=\"images/sixhalf.gif\" alt=\"\"/>";
}
else
{
return "<img src=\"images/seven.gif\" alt=\"\"/>";
}
}
///////////////////////////////
function getsimbol($uid)
{
$info= mysql_fetch_array(mysql_query("SELECT cyberpowereragon, plusses FROM ibwf_users WHERE id='".$uid."'"));
if(isbanned($uid))
{
return "(x)";
}
if($info[0]=='4')
{
return "??";
}else  if($info[0]=='3')
{
return "??";
}else if($info[0]=='2')
{
return "??";
}else if($info[0]=='1')
{
return "??";
}else{
if($info[1]<10)
{
return ".";
}else if($info[1]<50)
{
return "+";
}else if($info[1]<125)
{
return "*";
}else if($info[1]<500)
{
return "??";
}else if($info[1]<4000)
{
return "??";
}else if($info[1]<6000)
{
return "??";
}else if($info[1]<10000)
{
return ":D";
}else
{
return "??";
}
}
}
//////////////////////////////////////////////////////////
function candelmd($uid,$bid)
{
$minfo = mysql_fetch_array(mysql_query("SELECT bowner FROM lirmeditatii WHERE id='".$bid."'"));
if(ismod($uid))
{
return true;
}
if($minfo[0]==$uid)
{
return true;
}
return false;
}
//////////////////////////////////////////// Search Id

function generate_srid($svar1,$svar2="", $svar3="", $svar4="", $svar5="")

{



$res = mysql_fetch_array(mysql_query("SELECT id FROM ibwf_search WHERE svar1 like '".$svar1."' AND svar2 like '".$svar2."' AND svar3 like '".$svar3."' AND svar4 like '".$svar4."' AND svar5 like '".$svar5."'"));

if($res[0]>0)

{

return $res[0];

}

mysql_query("INSERT INTO ibwf_search SET svar1='".$svar1."', svar2='".$svar2."', svar3='".$svar3."', svar4='".$svar4."', svar5='".$svar5."', stime='".time()."'");

$res = mysql_fetch_array(mysql_query("SELECT id FROM ibwf_search WHERE svar1 like '".$svar1."' AND svar2 like '".$svar2."' AND svar3 like '".$svar3."' AND svar4 like '".$svar4."' AND svar5 like '".$svar5."'"));

return $res[0];

}



function candelvl($uid, $item)

{

$candoit = mysql_fetch_array(mysql_query("SELECT  uid FROM ibwf_vault WHERE id='".$item."'"));

if($uid==$candoit[0]||ismod($uid))

{

return true;

}

return false;

}


/////////////////////////////////// GET RATE



function geturate($uid)

{

$pnts = 0;

//by blogs, posts per day, chats per day, gb signatures

if(ismod($uid))

{

return 5;

}

$noi = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_blogs WHERE bowner='".$uid."'"));

if($noi[0]>=5)

{

$pnts = 5;

}else{

$pnts = $noi[0];

}

$noi = mysql_fetch_array(mysql_query("SELECT regdate, plusses, chmsgs FROM ibwf_users WHERE id='".$uid."'"));

$rwage = ceil((time()- $noi[0])/(24*60*60));

$ppd = ceil($noi[1]/$rwage);

if($ppd>=20)

{

$pnts+=5;

}else{

$pnts += floor($ppd/4);

}

$cpd = ceil($noi[2]/$rwage);

if($cpd>=100)

{

$pnts+=5;

}else{

$pnts += floor($cpd/20);

}

return floor($pnts/3);







}

///////////////////////////////////function isuser



function isuser($uid)

{

$cus = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_users WHERE id='".$uid."'"));

if($cus[0]>0)

{

return true;

}

return false;

}

////////////////////////////////////////////Can access forum



function canaccess($uid, $fid)

{

$fex = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_forums WHERE id='".$fid."'"));

if($fex[0]==0)

{

return false;

}

$persc = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_acc WHERE fid='".$fid."'"));

if($persc[0]==0)

{

$clid = mysql_fetch_array(mysql_query("SELECT clubid FROM ibwf_forums WHERE id='".$fid."'"));

if($clid[0]==0)

{

return true;

}else{

if(ispu($uid))

{

return true;

}else{

$ismm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_clubmembers WHERE uid='".$uid."' AND clid='".$clid[0]."'"));

if($ismm[0]>0)

{

return true;

}else{

return false;

}

}

}



}else{

$gid = mysql_fetch_array(mysql_query("SELECT gid FROM ibwf_acc WHERE fid='".$fid."'"));

$gid = $gid[0];

$ginfo = mysql_fetch_array(mysql_query("SELECT autoass, mage, userst, posts, plusses, maxage FROM ibwf_groups WHERE id='".$gid."'"));

if($ginfo[0]=="1")

{

$ucyberpowereragons = mysql_fetch_array(mysql_query("SELECT birthday, cyberpowereragon, posts, plusses FROM ibwf_users WHERE id='".$uid."'"));

if($ginfo[2]==4)

{



if(isowner($uid))

{

return true;

}else{

return false;

}

}



if($ginfo[2]==3)

{



if(isheadadmin($uid))

{

return true;

}else{

return false;

}

}



if($ginfo[2]==2)

{



if(isadmin($uid))

{

return true;

}else{

return false;

}

}



if($ginfo[2]==1)

{



if(ismod($uid))

{

return true;

}else{

return false;

}

}

if($ucyberpowereragons[1]>$ginfo[2])

{

return true;

}

$acc = true;

if($ginfo[1]!=0){

if(getage($ucyberpowereragons[0])< $ginfo[1])

{

$acc =  false;

}

}

if($ginfo[5]!=0){

if(getage($ucyberpowereragons[0])> $ginfo[5])

{

$acc =  false;

}

}

if($ucyberpowereragons[2]<$ginfo[3])

{

$acc =  false;

}

if($ucyberpowereragons[3]<$ginfo[4])

{

$acc =  false;

}



}

}

return $acc;

}



function unhtmlspecialchars2( $string )

{

$string = str_replace ( '&', '&', $string );

$string = str_replace ( '&#039;', '\'', $string );

$string = str_replace ( '"', '"', $string );

$string = str_replace ( '<', '<', $string );

$string = str_replace ( '>', '>', $string );

$string = str_replace ( '??', '?', $string );

$string = str_replace ( '??', '?', $string );

$string = str_replace ( '??', '?', $string );

$string = str_replace ( '??', '?', $string );

$string = str_replace ( '??', '?', $string );

$string = str_replace ( '??', '?', $string );

return $string;

}



function getuage_sid($sid)

{

$uid = getuid_sid($sid);

$uage = mysql_fetch_array(mysql_query("SELECT birthday FROM ibwf_users WHERE id='".$uid."'"));

return getage($uage[0]);

}



function canenter($rid, $sid)

{

$rcyberpowereragon = mysql_fetch_array(mysql_query("SELECT mage, cyberpowereragons, chposts, clubid, maxage FROM ibwf_rooms WHERE id='".$rid."'"));

$ucyberpowereragon = mysql_fetch_array(mysql_query("SELECT birthday, chmsgs FROM ibwf_users WHERE id='".getuid_sid($sid)."'"));

if(ismod(getuid_sid($sid)))

{

return true;

}

if($rcyberpowereragon[3]!=0)

{

if(ismod(getuid_sid($sid)))

{

return true;

}else{

$ismm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_clubmembers WHERE uid='".getuid_sid($sid)."' AND clid='".$rcyberpowereragon[3]."'"));

if($ismm[0]>0)

{

return true;

}else{

return false;

}

}

}

if($rcyberpowereragon[1]==1)

{

return ismod(getuid_sid($sid));

}

if($rcyberpowereragon[1]==2)

{

return isadmin(getuid_sid($sid));

}

if($rcyberpowereragon[1]==3)

{

return isheadadmin(getuid_sid($sid));

}

if($rcyberpowereragon[1]==4)

{

return isowner(getuid_sid($sid));

}

if($rcyberpowereragon[0]!=0){

if(getuage_sid($sid)<$rcyberpowereragon[0])

{

return false;

}

}

if($rcyberpowereragon[4]!=0){

if(getuage_sid($sid)>$rcyberpowereragon[4])

{

return false;

}

}

if($ucyberpowereragon[1]<$rcyberpowereragon[2])

{

return false;

}

return true;

}

///////////////////clear data





function cleardata()

{

$timeto = 120;

$timenw = time();

$timeout = $timenw - $timeto;

$exec = mysql_query("DELETE FROM ibwf_chonline WHERE lton<'".$timeout."'");

$timeto = 300;

$timenw = time();

$timeout = $timenw - $timeto;

$exec = mysql_query("DELETE FROM ibwf_chat WHERE timesent<'".$timeout."'");

$timeto = 60*60;

$timenw = time();

$timeout = $timenw - $timeto;

$exec = mysql_query("DELETE FROM ibwf_search WHERE stime<'".$timeout."'");



///delete expired rooms

$timeto = 5*60;

$timenw = time();

$timeout = $timenw - $timeto;

$rooms = mysql_query("SELECT id FROM ibwf_rooms WHERE static='0' AND lastmsg<'".$timeout."'");

while ($room=mysql_fetch_array($rooms))

{

$ppl = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_chonline WHERE rid='".$room[0]."'"));

if($ppl[0]==0)

{

$exec = mysql_query("DELETE FROM ibwf_rooms WHERE id='".$room[0]."'");

}

}

$lbpm = mysql_fetch_array(mysql_query("SELECT value FROM ibwf_settings WHERE name='lastbpm'"));

$td = date("Y-m-d");

//echo $lbpm[0];



if ($td!=$lbpm[0])

{

//echo "boo";

$sql = "SELECT id, name, birthday  FROM ibwf_users where month(`birthday`) = month(curdate()) and dayofmonth(`birthday`) = dayofmonth(curdate())";

$ppl = mysql_query($sql);

while($mem = mysql_fetch_array($ppl))

{

$msg = "$sitename team wish you a day full of joy and happiness and many happy returns[br/]*fireworks*[br/][small][i]p.s: this is an automated pm[/i][/small]";

autopm($msg, $mem[0]);

}

mysql_query("UPDATE ibwf_settings SET value='".$td."' WHERE name='lastbpm'");

}



}



///////////////////////////////////////get file ext.



function getext($strfnm)

{

$str = trim($strfnm);

if (strlen($str)<4){

return $str;

}

for($i=strlen($str);$i>0;$i--)

{

$ext .= substr($str,$i,1);

if(strlen($ext)==3)

{

$ext = strrev($ext);

return $ext;

}

}

}



///////////////////////////////////////get extension icon



function getextimg($ext)

{

$ext = strtolower($ext);

switch ($ext)

{

case "jpg":

case "gif":

case "png":

case "bmp":

return "<img src=\"../images/image.gif\" alt=\"image\"/>";

break;

case "zip":

case "rar":

return "<img src=\"../images/pack.gif\" alt=\"package\"/>";

break;

case "amr":

case "wav":

case "mp3":

return "<img src=\"../images/music.gif\" alt=\"music\"/>";

break;

case "mpg":

case "3gp":

return "<img src=\"../images/video.gif\" alt=\"video\"/>";

break;

default:

return "<img src=\"../images/other.gif\" alt=\"!\"/>";

break;

}

}



///////////////////////////////////////Add to chat


function addtochat($uid, $rid)
{
$bago = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_chonline WHERE uid='".$uid."' AND rid='".$rid."'"));
if($bago[0]==0){
$msg = "[b]Warning:[/b] Im Enter this Room";
mysql_query("INSERT INTO ibwf_chat SET timesent='".time()."', chatter='".$uid."', msgtext='".$msg."', rid='".$rid."'");
}

$timeto = 120;
$timenw = time();
$timeout = $timenw - $timeto;
$res = mysql_query("INSERT INTO ibwf_chonline SET lton='".time()."', uid='".$uid."', rid='".$rid."'");
if(!$res)
{
mysql_query("UPDATE ibwf_chonline SET lton='".time()."', rid='".$rid."' WHERE uid='".$uid."'");
}
}

////////////////////////////////////////////is mod



function ismod($uid)

{

$cyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwf_users WHERE id='".$uid."'"));
$secondsecurity = mysql_fetch_array(mysql_query("SELECT access_codes_new_fbd FROM foribd_extra_power WHERE userid='".$uid."'"));


if($cyberpowereragon[0]>0 && $secondsecurity[0]==9080706)

{

return true;

}

}
///////////////////////////// Validated By SAHiD  +8801840098545
function isvalidated($uid)
{
$validated = mysql_fetch_array(mysql_query("SELECT validated FROM ibwf_users WHERE id='".$uid."'"));
if($validated[0]=='0')
{
return true;
}
}

///////////////////////////// Stop Gamming By SAHiD  +8801840098545
function isstopped($uid)
{
$validated2 = mysql_fetch_array(mysql_query("SELECT stop FROM ibwf_users WHERE id='".$uid."'"));
if($validated2[0]=='0')
{
return true;
}
}
////////////////////////////////////////////is VIP



function isvip($uid)

{

$vip = mysql_fetch_array(mysql_query("SELECT vip FROM ibwf_users WHERE id='".$uid."'"));



if($vip[0]=='1')

{

return true;

}

}

function ispu($uid)

{

$vip = mysql_fetch_array(mysql_query("SELECT pu FROM ibwf_users WHERE id='".$uid."'"));



if($vip[0]=='1')

{

return true;

}

}
/////////
function isgu($uid)

{

$vip = mysql_fetch_array(mysql_query("SELECT gu FROM ibwf_users WHERE id='".$uid."'"));



if($vip[0]=='1')

{

return true;

}

}
////////////////////// Function lotto subscriber
function islotto($uid)

{

$vip = mysql_fetch_array(mysql_query("SELECT lotto FROM ibwf_users WHERE id='".$uid."'"));



if($vip[0]=='1')

{

return true;

}

}
////////////////Extra Profile Rank By 420
function issgl($uid)
{
$sweetgirl = mysql_fetch_array(mysql_query("SELECT sweetgirl FROM ibwf_users WHERE id='".$uid."'"));

if($sweetgirl[0]=='1')
{return true;
}}
////
function issby($uid)
{
$sweetboy = mysql_fetch_array(mysql_query("SELECT sweetboy FROM ibwf_users WHERE id='".$uid."'"));

if($sweetboy[0]=='1')
{return true;
}}
////
function isdgl($uid)
{
$dangergirl = mysql_fetch_array(mysql_query("SELECT dangergirl FROM ibwf_users WHERE id='".$uid."'"));

if($dangergirl[0]=='1')
{return true;
}}
///
function isdby($uid)
{
$dangerboy = mysql_fetch_array(mysql_query("SELECT dangerboy FROM ibwf_users WHERE id='".$uid."'"));

if($dangerboy[0]=='1')
{return true;
}}
//
function iscert($uid)
{
$dangerboy2 = mysql_fetch_array(mysql_query("SELECT certified FROM ibwf_users WHERE id='".$uid."'"));

if($dangerboy2[0]=='1')
{return true;
}}
////////////////////////////////////////////is mod



function candelgb($uid,$mid)

{

$minfo = mysql_fetch_array(mysql_query("SELECT gbowner, gbsigner FROM ibwf_gbook WHERE id='".$mid."'"));

if($minfo[0]==$uid)

{

return true;

}

if($minfo[1]==$uid)

{

return true;

}

return false;

}

///////Delete Club Ads
function candelclid($uid,$mid)
{
$minfo = mysql_fetch_array(mysql_query("SELECT owner FROM ibwf_clubads WHERE id='".$mid."'"));
if($minfo[0]==$uid)
{
return true;
}
return false;
}
///////Delete 
function isfanpage($uid,$id)
{
$minfo = mysql_fetch_array(mysql_query("SELECT uid FROM ibwf_fanpagelike WHERE shoutid='".$id."'"));
if($minfo[0]==$uid)
{
return true;
}
return false;
}
///////Delete Nick Ads
function candelnickid($uid,$mid)
{
$minfo = mysql_fetch_array(mysql_query("SELECT owner FROM ibwf_nickads WHERE id='".$mid."'"));
if($minfo[0]==$uid)
{
return true;
}
return false;
}
///////Delete Topi/Quiz Ads
function candeltopicid($uid,$mid)
{
$minfo = mysql_fetch_array(mysql_query("SELECT owner FROM ibwf_topicads WHERE id='".$mid."'"));
if($minfo[0]==$uid)
{
return true;
}
return false;
}

////////////////////////
function isspam($text)

{

$sfil[0] = "www.";

$sfil[1] = "http:";

$text = str_replace(" ", "", $text);

$text = strtolower($text);

for($i=0;$i<count($sfil);$i++)

{



$nosf = substr_count($text,$sfil[$i]);

if($nosf>0)

{

return true;

}

}



return false;

}





///////////////////////////////////get page from go



function getpage_go($go,$tid)

{

if(trim($go)=="")return 1;

if($go=="last")return getnumpages($tid);

$counter=1;



$posts = mysql_query("SELECT id FROM ibwf_posts WHERE tid='".$tid."'");

while($post=mysql_fetch_array($posts))

{

$counter++;

$postid = $post[0];

if($postid==$go)

{

$tore = ceil($counter/5);

return $tore;

}

}

return 1;

}



////////////////////////////get number of topic pages



function getnumpages($tid)

{

$nops = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_posts WHERE tid='".$tid."'"));

$nops = $nops[0]+1; //where did the 1 come from? the topic text, duh!

$nopg = ceil($nops/5); //5 is the posts to show in each page

return $nopg;

}

////////////////////////////////////////////can delete a blog?



function candelbl($uid,$bid)

{

$minfo = mysql_fetch_array(mysql_query("SELECT bowner FROM ibwf_blogs WHERE id='".$bid."'"));

if(ismod($uid))

{

return true;

}

if($minfo[0]==$uid)

{

return true;

}



return false;

}

////////////////////////////////////////////can delete a dairy?



function candeldr($uid,$bid)

{

$minfo = mysql_fetch_array(mysql_query("SELECT bowner FROM ibwf_dairy WHERE id='".$bid."'"));

if(ismod($uid))

{

return true;

}

if($minfo[0]==$uid)

{

return true;

}



return false;

}

//////////////////////////////////////////////////RAVEBABE

function PostToHost($host, $path, $data_to_send)

{



$result = "";

$fp = fsockopen($host,80,$errno, $errstr, 30);

if( $fp)

{

fputs($fp, "POST $path HTTP/1.0\n");

fputs($fp, "Host: $host\n");

fputs($fp, "Content-type: application/x-www-form-urlencoded\n");

fputs($fp, "Content-length: " . strlen($data_to_send) . "\n");

fputs($fp, "Connection: close\n\n");

fputs($fp, $data_to_send);



while(!feof($fp)) {

$result .=  fgets($fp, 128);

}

fclose($fp);



return $result;

}





}

/////////////////////////Get user plusses



function getplusses($uid)

{

$plus = mysql_fetch_array(mysql_query("SELECT plusses FROM ibwf_users WHERE id='".$uid."'"));

return $plus[0];

}
/////////////////////////Get user posts



function getposts($uid)

{

$post = mysql_fetch_array(mysql_query("SELECT posts FROM ibwf_users WHERE id='".$uid."'"));

return $post[0];

}
/////////////////////////Get user topics



function gettopics($uid)

{

$post1 = mysql_fetch_array(mysql_query("SELECT topic FROM ibwf_users WHERE id='".$uid."'"));

return $post1[0];

}
/////////////////////////Can uid sign who's guestbook?



function cansigngb($uid, $who)

{

if(arebuds($uid, $who))

{

return true;

}

if($uid==$who)

{

return false; //imagine if someone signed his own gbook o.O

}

if(getplusses($uid)>=75)

{

return true;

}

return false;

}

/////////////////////////////////////////////Are buds?



function arebuds($uid, $tid)

{

$res = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_buddies WHERE ((uid='".$uid."' AND tid='".$tid."') OR (uid='".$tid."' AND tid='".$uid."')) AND agreed='1'"));

if($res[0]>0)

{

return true;

}

return false;

}


/////////// IS Following????

function isfollowing($uid, $who)

{

    $res = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM sahid_follow WHERE follower='".$uid."' AND followid='".$who."'"));

    if($res[0]>0)

    {

      return true;

    }

    return false;

}


/////////////////////////////////////////////popups on



function popupson($who)

{

$res = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_users WHERE id='".$who."' AND popmsg='1'"));

if($res[0]>0)

{

return true;

}

return false;

}



//////////////////////////////////function get n. of buds



function getnbuds($uid)

{

$notb = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_buddies WHERE (uid='".$uid."' OR tid='".$uid."') AND agreed='1'"));

return $notb[0];

}



/////////////////////////////get no. of requists



function getnreqs($uid)

{

$notb = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_buddies WHERE  tid='".$uid."' AND agreed='0'"));

return $notb[0];

}



function getpmood($uid)
{
$pmood = mysql_fetch_array(mysql_query("SELECT pmood FROM ibwf_users WHERE id='".$uid."'"));
return $pmood[0];
}

/////////////////////////////get no. of online buds



function getonbuds($uid)

{

$counter =0;

$buds = mysql_query("SELECT uid, tid FROM ibwf_buddies WHERE (uid='".$uid."' OR tid='".$uid."') AND agreed='1'");

while($bud=mysql_fetch_array($buds))

{

if($bud[0]==$uid)

{

$tid = $bud[1];

}else{

$tid = $bud[0];

}

if(isonline($tid))

{

$counter++;

}

}

return $counter;

}



/////////////////////////////////////////////Function shoutboxpage



function getshoutboxpage($sid)

{

echo "<strong>ShoutBox</strong><br/>";

echo "<p align=\"center\"><small>";

$who = $_GET["who"];

//////ALL LISTS SCRIPT <<



if($page=="" || $page<=0)$page=1;

if($who=="")

{

$noi = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_shouts"));

}else{

$noi = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_shouts WHERE shouter='".$who."'"));

}

$num_items = $noi[0]; //changable

$items_per_page= 10;

$num_pages = ceil($num_items/$items_per_page);

if(($page>$num_pages)&&$page!=1)$page= $num_pages;

$limit_start = ($page-1)*$items_per_page;



//changable sql

if($who =="")

{

$sql = "SELECT id, shout, shouter, shtime  FROM ibwf_shouts ORDER BY shtime DESC LIMIT $limit_start, $items_per_page";

}else{

$sql = "SELECT id, shout, shouter, shtime  FROM ibwf_shouts  WHERE shouter='".$who."'ORDER BY shtime DESC LIMIT $limit_start, $items_per_page";

}



$items = mysql_query($sql);

echo mysql_error();

if(mysql_num_rows($items)>0)

{

while ($item = mysql_fetch_array($items))

{

$shnick = getnick_uid($item[2]);

$sht = parsepm($item[1], $sid);

$shdt = date("d m y-H:i", $item[3]);
$lnk = "<a href=\"index.php?action=viewuser&who=$item[2]&sid=$sid\">$shnick</a>: $sht<br/>$shdt";
if(ismod(getuid_sid($sid)))

{

$dlsh = "<a href=\"modproc.php?action=delsh&sid=$sid&shid=$item[0]\">[x]</a>";

}else{

$dlsh = "";

}

echo "$lnk $dlsh<br/>";

}

}

if($page>1)

{

$ppage = $page-1;

echo "<a href=\"lists.php?action=shouts&page=$ppage&sid=$sid&who=$who\">??Prev</a> ";

}

if($page<$num_pages)

{

$npage = $page+1;

echo "<a href=\"lists.php?action=shouts&page=$npage&sid=$sid&who=$who\">Next??</a>";

}

echo "<br/>$page/$num_pages<br/>";

if($num_pages>2)

{

$rets = "Jump to page<input name=\"pg\" format=\"*N\" size=\"3\"/>";

$rets .= "<anchor>[GO]";

$rets .= "<go href=\"lists.php\" method=\"get\">";

$rets .= "<postfield name=\"action\" value=\"$action\"/>";

$rets .= "<postfield name=\"who\" value=\"$who\"/>";

$rets .= "<postfield name=\"sid\" value=\"$sid\"/>";

$rets .= "<postfield name=\"page\" value=\"$(pg)\"/>";

$rets .= "</go></anchor>";



echo $rets;

}

//  $shbox .= "<a href=\"lists.php?action=shouts&sid=$sid\">more</a>, ";

echo "<a href=\"index.php?action=shout&sid=$sid\">shout</a>";

echo "</small></p>";

}



/////////////////////////////////////////////function Shoutbox 1msg

function getshoutbox($sid)
{

$lshout = mysql_fetch_array(mysql_query("SELECT shout, shouter, id, shtime  FROM ibwf_shouts ORDER BY shtime DESC LIMIT 1"));
$shbox .= "<b>Shoutbox</b><br/>";
/////////////
$shdt = date("H:i", $lshout[3]);
$stime = $lshout['shtime'];
$tremain = time()-$stime;
$tmdt = gettimemsg($tremain);
//echo "".date("".($shdt + (6 * 60 * 60))."<br/>";
$ttt = date("h:i:s A",($shdt + (6 * 60 * 60)));
$tt2 = ("$tmdt ago");
/////////////
$shnick = getnick_uid($lshout[1]);
$avlink = getavatar($lshout[1]);
if($avlink=="")
{
$shbox .= "<img src=\"../images/nopic.jpg\" height=\"28\" width=\"25\" alt=\"x\"/> ";
}else{
$shbox .= "<img src=\"http://RoseBD.NeT/wap/$avlink\" height=\"28\" width=\"25\" alt=\"0\"/> ";
}
if(ispu($lshout[1])){ $ppu = "<b><i> (Premium User!)</i></b>"; }
$shbox .= " <a href=\"index.php?action=viewuser&amp;sid=$sid&amp;who=$lshout[1]\">".$shnick."</a> <b>(".getstatus2($lshout[1]).")</b>: ";
$text = parsepm($lshout[0], $sid);
$shbox .= $text;
$shbox .= "<br/><br/>";
$shbox .= "<small><b>Shout Added:($tt2)</b></small>";
$shbox .= "<br/>";

$shcomm = mysql_fetch_assoc(mysql_query("SELECT COUNT(*) comm FROM ibwf_shcomments WHERE shoutid='".$lshout[2]."'"));
$shout = $shcomm['comm'];
$counts = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_like WHERE shoutid='".$lshout[2]."'"));
$counts1 = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_dislike WHERE shoutid='".$lshout[2]."'"));
if($counts[0]>0){ $lyk = "-<a href=\"like.php?action=main&amp;sid=$sid&amp;shid=$lshout[2]\">$counts[0]</a>"; }else{ $lyk = "-<a href=\"like.php?action=main&amp;sid=$sid&amp;shid=$lshout[2]\">0</a>"; }
if($counts1[0]>0){ $dislyk = "-<a href=\"dislike.php?action=main&amp;sid=$sid&amp;shid=$lshout[2]\">$counts1[0]</a>"; }else{ $dislyk = "-<a href=\"dislike.php?action=main&amp;sid=$sid&amp;shid=$lshout[2]\">0</a>"; }
////////////////////////////


$shbox .= "<a href=\"genproc.php?action=like&amp;sid=$sid&amp;shid=$lshout[2]\">Like</a>$lyk | ";
$shbox .= "<a href=\"genproc.php?action=dislike&amp;sid=$sid&amp;shid=$lshout[2]\">Dislike</a>$dislyk | ";
$shcomm = mysql_fetch_assoc(mysql_query("SELECT COUNT(*) comm FROM ibwf_shcomments WHERE shoutid='".$lshout[2]."'"));
$shout = $shcomm['comm'];
  $shbox .= "<a href=\"shcomments.php?action=main&amp;sid=$sid&amp;shid=$lshout[2]\">Com-$shout</a>";
  
$shbox .= "<br/> <a href=\"index.php?action=shout&amp;sid=$sid\">Add ShouT</a> | <a href=\"lists.php?action=shouts&amp;sid=$sid\">History</a>";
$shbox .= "";
if (ismod(getuid_sid($sid)))
{
//$shbox .= "[<a href=\"modproc.php?action=delsh&amp;sid=$sid&amp;shid=$lshout[2]\">x</a>]";
}
//$shbox .= "<br/>";

return $shbox;
}
/////////////////////////////////////////////Function shoutbox

function getshoutbox2($sid)

{



$shbox .= "";

$lshout = mysql_fetch_array(mysql_query("SELECT shout, shouter, id  FROM ibwf_shouts ORDER BY shtime DESC LIMIT 1"));

$shnick = getnick_uid($lshout[1]);

$text = $lshout[0];

$shbox .= $text;

$shbox .= "<i> -<b>".$shnick."</b></i>";

$shbox .= "<br/>";

$shbox .= "";

$shbox .= "";

if (ismod(getuid_sid($sid)))

{

$shbox .= "";

}

//$shbox .= "<br/>";



return $shbox;

}


/////////////////////////////////////////////function pop up msg

function popup($sid)

{

$uid = getuid_sid($sid);

$unreadpopup=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_popups WHERE unread='1' AND touid='".$uid."'"));





if ($unreadpopup[0]>0)

{

$popmsgbox .= "<p align=\"center\"><small>";

$popsenabled=mysql_fetch_array(mysql_query("SELECT popmsg FROM ibwf_users WHERE id='".$uid."'"));

if($popsenabled[0]==1)

{

$pminfo = mysql_fetch_array(mysql_query("SELECT id, text, byuid, timesent, touid, reported FROM ibwf_popups WHERE unread='1' AND touid='".$uid."'"));

$pmfrm = getnick_uid($pminfo[2]);

$ncl = mysql_query("UPDATE ibwf_popups SET unread='0' WHERE id='".$pminfo[0]."'");

$popmsgbox .= "<strong>POP-UP Message From $pmfrm</strong>";

$popmsgbox .= "<br/>";

$tmstamp = $pminfo[3];

$tmdt = date("d m Y - H:i:s", $tmstamp);

$popmsgbox .= "Sent At: $tmdt<br/>";

$pmtext = parsepm($pminfo[1], $sid);

$pmtext = str_replace("/llfaqs","<a href=\"lists.php?action=faqs&sid=$sid\">$sitename F.A.Qs</a>", $pmtext);

$pmtext = str_replace("/reader",getnick_uid($pminfo[4]), $pmtext);

$pmid=$pminfo[0];

$popmsgbox .= "Message: $pmtext";

$popmsgbox .= "<br/>Send Reply to $pmfrm<br/>";


$popmsgbox .= "<form action=\"inbxproc.php?action=sendpopup&who=$pminfo[2]&sid=$sid&pmid=$pminfo[0]\" method=\"post\"><center>";   	
$popmsgbox .= "<input name=\"pmtext\" maxlength=\"500\"/><br/>";
$popmsgbox .= "<postfield name=\"pmtext\" value=\"$(pmtext)\"/>";
$popmsgbox .= "<input type=\"submit\" value=\"Send\"/>";
$popmsgbox .= "</form>";


// $res = mysql_query("INSERT INTO ibwf_online SET userid='".$uid."', actvtime='".$tm."', place='".$place."', placedet='".$plclink."'");

$location = mysql_fetch_array(mysql_query("SELECT placedet FROM ibwf_online WHERE userid='".$uid."'"));

$popmsgbox .= "<br/><a href=\"$location[0]&sid=$sid\">Skip Msg</a><br/>";

$popmsgbox .= "<a href=\"inbxproc.php?action=rptpop&sid=$sid&pmid=$pminfo[0]\">Report</a>";



}

$popmsgbox .= "</small></p>";

}

return $popmsgbox;

}



/////////////////////////////////////////////get tid frm post id



function gettid_pid($pid)

{

$tid = mysql_fetch_array(mysql_query("SELECT tid FROM ibwf_posts WHERE id='".$pid."'"));

return $tid[0];

}



///////////////////////////////////////////is trashed?



function istrashed($uid)

{

$del = mysql_query("DELETE FROM ibwf_penalties WHERE timeto<'".time()."'");

$not = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_penalties WHERE uid='".$uid."' AND penalty='0'"));

if($not[0]>0)

{

return true;

}else{

return false;

}

}



///////////////////////////////////////////is shielded?



function isshield($uid)

{

$not = mysql_fetch_array(mysql_query("SELECT shield FROM ibwf_users WHERE id='".$uid."'"));

if($not[0]=='1')

{

return true;

}else{

return false;

}

}



///////////////////////////////////////////Get IP



function getip_uid($uid)

{

$not = mysql_fetch_array(mysql_query("SELECT ipadd FROM ibwf_users WHERE id='".$uid."'"));

return $not[0];



}

/////////////////NetWork
/*
function ip()

{

if($_SERVER["REMOTE_ADDR"]){$ip=$_SERVER["REMOTE_ADDR"];}

else{$ip=$_SERVER["HTTP_X_FORWARDED_FOR"];}

if(strpos($ip,",")){

$exp_ip=explode(",",$ip);

$ip=$exp_ip[0];

}

return $ip;

}



function ipinrange($ip, $range1, $range2)

{

$ip=ip2long($ip);

$range1=ip2long($range1);

$range2=ip2long($range2);

return (($ip >= $range1) && ($ip <= $range2));

}



function network($ip)

{

$result=mysql_query("SELECT * FROM network ORDER BY subone, subtwo");

while($ranges=mysql_fetch_array($result)){

if(ipinrange($ip, $ranges[1], $ranges[2])){

if(is_file("flags/".$ranges["flag"])){

$flag="<img src=\"flags/$ranges[5]\" alt=\"$ranges[5]\"/> ";

$flag2="<img src=\"flags/".$ranges["flag"]."\" alt=\"".$ranges["flag"]."\"/>";

}

return $ranges["isp"]."<br/>Country: <b>".$ranges["country"]."</b><br/>Country Flag: ".$flag2;

}

}

}

*/

/////////////////NetWork
function ip()
{
if($_SERVER["REMOTE_ADDR"]){$ip=$_SERVER["REMOTE_ADDR"];}
else{$ip=$_SERVER["HTTP_X_FOfbdARDED_FOR"];}
if(strpos($ip,",")){
$exp_ip=explode(",",$ip);
$ip=$exp_ip[0];
}
return $ip;
}
function ipinrange($ip, $range1, $range2)
{
$ip=ip2long($ip);

$range1=ip2long($range1);

$range2=ip2long($range2);

return (($ip >= $range1) && ($ip <= $range2));

}
function network($ip)
{
$result=mysql_query("SELECT * FROM network ORDER BY subone, subtwo");

while($ranges=mysql_fetch_array($result)){

if(ipinrange($ip, $ranges[1], $ranges[2])){

if(is_file("flags/".$ranges["flag"])){

$flag="<b>Flag: </b><img src=\"flags/$ranges[5]\" alt=\"$ranges[5]\"/><br/><b>Network: </b>";

$flag2="<img src=\"flags/".$ranges["flag"]."\" alt=\"".$ranges["flag"]."\"/><br/>";

}

return $flag.$ranges["isp"]."<br/><b>IP Country: </b>".$ranges["country"];

}

}

}
///////////////////////////////////////////Get Browser



function getbr_uid($uid)

{

$not = mysql_fetch_array(mysql_query("SELECT browserm FROM ibwf_users WHERE id='".$uid."'"));

return $not[0];



}



///////////////////////////////////////////is trashed?



function isbanned($uid)

{


$del = mysql_query("DELETE FROM ibwf_penalties WHERE uid='0' OR exid='0' OR pnreas='0'");

$del = mysql_query("DELETE FROM ibwf_private WHERE byuid='0' OR touid='0' OR text=''");


$del = mysql_query("DELETE FROM ibwf_penalties WHERE timeto<'".time()."'");

$not = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_penalties WHERE uid='".$uid."' AND (penalty='1' OR penalty='2')"));



if($not[0]>0)

{

return true;

}else{

return false;

}

}





/////////////////////////////////////////////get tid frm post id



function gettname($tid)

{

$tid = mysql_fetch_array(mysql_query("SELECT name FROM ibwf_topics WHERE id='".$tid."'"));

return $tid[0];

}



/////////////////////////////////////////////get tid frm post id



function getfid_tid($tid)

{

$fid = mysql_fetch_array(mysql_query("SELECT fid FROM ibwf_topics WHERE id='".$tid."'"));

return $fid[0];

}



/////////////////////////////////////////////is ip banned



function isipbanned($uip, $brws)

{



$pinf = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_penalties WHERE penalty='2' AND ipadd='".$ipa."' AND browserm='".$brm."'"));

if($pinf[0]>0)

{

return true;

}

return false;

}



////////////////get number of pinned topics in forum



function getpinned($fid)

{

$nop = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_topics WHERE fid='".$fid."' AND pinned ='1'"));

return $nop[0];

}


//////////////////////////can sign blog comment

function cansignblogcomment($uid, $who)
{
if(arebuds($bid, $who))
{
return true;
}
if($bid==$who)
{
return false; //imagine if someone signed his own gbook o.O
}
if(getplusses($uid)>=0)
{
return true;
}
return false;
}
////////////////////////////////////////////is del blog comment

function candelblogcomment($bid,$mid)
{
$minfo = mysql_fetch_array(mysql_query("SELECT blogowner, blogsigner FROM ibwf_blogcomment WHERE id='".$mid."'"));
if($minfo[0]==$bid)
{
return true;
}
if($minfo[1]==$bid)
{
return true;
}
return false;
}

/////////////////////////////////////////////can bud?



function budres($uid, $tid)

{

//3 = can't bud

//2 = already buds

//1 = request pended

//0 = can bud

if($uid==$tid)

{

return 3;

}



if (arebuds($uid, $tid))

{

return 2;

}

$req = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_buddies WHERE ((uid='".$uid."' AND tid='".$tid."') OR (uid='".$tid."' AND tid='".$uid."')) AND agreed='0'"));

if($req[0]>0)

{

return 1;

}

$notb = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_buddies WHERE (uid='".$tid."' OR tid='".$tid."') AND agreed='1'"));

global $max_buds;

if($notb[0]>=$max_buds)

{



return 3;

}

$notb = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_buddies WHERE (uid='".$uid."' OR tid='".$uid."') AND agreed='1'"));

global $max_buds;

if($notb[0]>=$max_buds)

{



return 3;

}

return 0;

}

////////////////////////////////////////////Session expiry time



function getsxtm()

{

$getdata = mysql_fetch_array(mysql_query("SELECT value FROM ibwf_settings WHERE name='sesexp'"));

return $getdata[0];

}



////////////////////////////////////////////Get bud msg



function getbudmsg($uid)

{

$getdata = mysql_fetch_array(mysql_query("SELECT budmsg FROM ibwf_users WHERE id='".$uid."'"));

return $getdata[0];

}
//////
/////////////////////////////////////////get ranking

function getranking($uid)
{
  $info= mysql_fetch_array(mysql_query("SELECT cyberpowereragon, plusses FROM ibwf_users WHERE id='".$uid."'"));
 if($info[0]=='5')
  {
    return "****************";
  }else
   if($info[0]=='4')
  {
    return "****************";
  }else{
if($info[1]<10)
    {
     return "*";
    }else if($info[1]<25)
    {
        return "*";
    }else if($info[1]<50)
    {
        return "**";
    }else if($info[1]<75)
    {
        return "**";
    }else if($info[1]<250)
    {
        return "***";
    }else if($info[1]<500)
    {
        return "***";
    }else if($info[1]<750)
    {
        return "****";
    }else if($info[1]<1000)
    {
        return "*****";
    }else if($info[1]<1500)
    {
        return "*****";
    }else if($info[1]<2000)
    {
        return "******";
    }else if($info[1]<2500)
    {
        return "******";
    }else if($info[1]<3000)
    {
        return "*******";
    }else if($info[1]<4000)
    {
        return "********";
    }else if($info[1]<5000)
    {
        return "*********";
    }else if($info[1]<10000)
    {
        return "**********";
    }else
    {
        return "*****";
    }
  }
}
/////////////////////////////////////////get chatstatus

function getchatstatus($uid)
{
$info= mysql_fetch_array(mysql_query("SELECT cyberpowereragon, chmsgs FROM ibwf_users WHERE id='".$uid."'"));
if(isbanned($uid))
{
return "BANNED!";
}
if($info[0]=='4')
{
return "Chat Boss!!";
}
if($info[0]=='3')
{
return "Chat Admin!!";
}else{
if($info[1]<10)
{
return "Starter";
}else if($info[1]<25)
{
return "Learner";
}else if($info[1]<50)
{
return "Chater";
}else if($info[1]<200)
{
return "Beginner Chatter";
}else if($info[1]<250)
{
return "Advanced Chatter";
}else if($info[1]<500)
{
return "Just In Love";
}else if($info[1]<1000)
{
return "WF MaStEr";
}else if($info[1]<1500)
{
return "FrEak";
}else if($info[1]<2000)
{
return "Addicted To Chat";
}else if($info[1]<3000)
{
return "Boss Of Chatroom!";
}else if($info[1]<4000)
{
return "Ultimate Chatter!";
}else if($info[1]<5000)
{
return "VIP Associate";
}else if($info[1]<6000)
{
return "Porter";
}else if($info[1]<7000)
{
return "Geek";
}else if($info[1]<10000)
{
return "Geek";
}else
{
return "Geek";
}
}
}
//////////////////OS By 420
function OS($user_agent){
$exp = explode(" ", $user_agent);
$oses = array (
'Windows 3.11' => 'Win16',
'Windows 95' => '(Windows 95)|(Win95)|(Windows_95)',
'Windows 98' => '(Windows 98)|(Win98)',
'Windows 2000' => '(Windows NT 5.0)|(Windows 2000)',
'Windows XP' => '(Windows NT 5.1)|(Windows XP)',
'Windows Vista' => '(Windows NT 6.0)|(Windows Vista)',
'Windows 7' => '(Windows NT 6.1)|(Windows 7)',
'Windows 2003' => '(Windows NT 5.2)',
'Windows NT 4.0' => '(Windows NT 4.0)|(WinNT4.0)|(WinNT)|(Windows NT)',
'Windows ME' => 'Windows ME',
'Open BSD'=>'OpenBSD',
'Sun OS'=>'SunOS',
'Linux'=>'(Linux)|(X11)',
'Macintosh'=>'(Mac_PowerPC)|(Macintosh)',
'QNX'=>'QNX',
'BeOS'=>'BeOS',
'OS/2'=>'OS/2',
'Palm OS'=>'Palm OS',
'Search Bot'=>'(nuhk)|(Googlebot)|(Yammybot)|(Openbot)|(Slurp/cat)|(msnbot)|(ia_archiver)',
'J2ME-Opera Mini'=>'Opera Mini',
'SonyE'=>'J2ME-MIDP',
'Symbian OS'=>'Symbian OS',
'SymbianOS 6.1'=>'SymbianOS/6.1',
'SymbianOS 7.0'=>'SymbianOS/7.0',
'SymbianOS 8.0'=>'SymbianOS/8.0',
'SymbianOS 9.1'=>'SymbianOS/9.1',
'SymbianOS 9.2'=>'SymbianOS/9.2',
'SymbianOS 9.4'=>'SymbianOS/9.4',
'Mac OS (iPhone)'=>'iPhone',
'Windows CE' => 'Windows CE'
);

foreach($oses as $os=>$pattern){
if (eregi($pattern,$user_agent))
return $os;
}
return 'Unknown OS';
}

////////////////////////////////////////////Get forum name



function getfname($fid)

{

$fname = mysql_fetch_array(mysql_query("SELECT name FROM ibwf_forums WHERE id='".$fid."'"));

return $fname[0];

}

////////////////////////////////////////////PM antiflood time



function getpmaf()

{

$getdata = mysql_fetch_array(mysql_query("SELECT value FROM ibwf_settings WHERE name='pmaf'"));

return $getdata[0];

}



////////////////////////////////////////////PM antiflood time



function getfview()

{

$getdata = mysql_fetch_array(mysql_query("SELECT value FROM ibwf_settings WHERE name='fview'"));

return $getdata[0];

}



////////////////////////////////////////////get forum message



function getfmsg()

{

$getdata = mysql_fetch_array(mysql_query("SELECT value FROM ibwf_settings WHERE name='4ummsg'"));

return $getdata[0];

}



//////////////////////////////////////////////is online



function isonline($uid)

{

$uon = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_online WHERE userid='".$uid."'"));

if($uon[0]>0)

{

return true;

}else

{

return false;

}

}

///////////////////////////if registration is allowed



function canreg()

{

$getreg = mysql_fetch_array(mysql_query("SELECT value FROM ibwf_settings WHERE name='reg'"));

if($getreg[0]=='0')

{

return false;

}else

{

return true;

}

}



///////////////////////////if validation is on



function validation()

{

$getval = mysql_fetch_array(mysql_query("SELECT value FROM ibwf_settings WHERE name='vldtn'"));

if($getval[0]=='1')

{

return true;

}else

{

return false;

}

}

///////////////////////////if accepts auto msgs



function automsgs($uid)

{

$getval = mysql_fetch_array(mysql_query("SELECT automsgs FROM ibwf_users WHERE id='".$uid."'"));

if($getval[0]=='1')

{

return true;

}else

{

return false;

}

}

///////////////////////////////////////////Get Forum ID



function getfid($topicid)

{

$fid = mysql_fetch_array(mysql_query("SELECT fid FROM ibwf_topics WHERE id='".$topicid."'"));

return $fid[0];

}

////////////////////////////////////////////Parse PM

////anti spam

function parsepm($text, $sid="")

{

$text = getbbcode($text, $sid, 1);

$text = findcard($text);

return $text;

}





////////////////////////////////////////////Parse other msgs



function parsemsg($text,$sid="")

{

$text = getbbcode($text, $sid, 1);

$text = findcard($text);

return $text;

}

///////////////////////////////////////////Is site blocked



function isblocked($str,$sender)

{

if(ismod($sender))

{

return false;

}

$str = str_replace(" ","",$str);

$str = strtolower($str);

$res = mysql_query("SELECT site FROM ibwf_blockedsite");

while ($row = mysql_fetch_array($res))

{

$sites[] = $row[0];

}

for($i=0;$i<count($sites);$i++)

{

$nosf = substr_count($str,$sites[$i]);

if($nosf>0)

{

return true;

}

}

return false;

}



///////////////////////////////////////////Is pm starred



function isstarred($pmid)

{

$strd = mysql_fetch_array(mysql_query("SELECT starred FROM ibwf_private WHERE id='".$pmid."'"));

if($strd[0]=="1")

{

return true;

}else{

return false;

}

}

////////////////////////////////////////////IS LOGGED?



function islogged($sid)

{


$uid = mysql_fetch_array(mysql_query("SELECT uid FROM ibwf_ses WHERE id='".$sid."'"));

$uid = $uid[0];

$del = mysql_query("DELETE FROM ibwf_penalties WHERE timeto<'".time()."'");

$not = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_penalties WHERE uid='".$uid."' AND (penalty='1' OR penalty='2')"));

if($not[0]>0)

{

$deloldses = mysql_query("DELETE FROM ibwf_ses WHERE id='".sid."'");

return false;

}else{

return true;

}







//delete old sessions first



$deloldses = mysql_query("DELETE FROM ibwf_ses WHERE expiretm<'".time()."'");

//does sessions exist?

$sesx = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_ses WHERE id='".$sid."'"));



if($sesx[0]>0)

{

if(!isuser(getuid_sid($sid)))

{

return false;

}

//yip it's logged in

//first extend its session expirement time

$xtm = time() + (60*getsxtm());

$extxtm = mysql_query("UPDATE ibwf_ses SET expiretm='".$xtm."' WHERE id='".$sid."'");

return true;

}else{

//nope its session must be expired or something

return false;

}

}



////////////////////////Get user nick from session id







/////////////////////Get total number of pms



function getpmcount($uid,$view="all")

{

if($view=="all"){

$nopm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_private WHERE touid='".$uid."' AND starred='0'"));

}else if($view =="snt")

{

$nopm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_private WHERE byuid='".$uid."'"));

}else if($view =="str")

{

$nopm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_private WHERE touid='".$uid."' AND starred='1'"));

}else if($view =="urd")

{

$nopm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_private WHERE touid='".$uid."' AND unread='1'"));

}

return $nopm[0];

}



function deleteClub($clid)

{

$fid = mysql_fetch_array(mysql_query("SELECT id FROM ibwf_forums WHERE clubid='".$clid."'"));

$fid = $fid[0];

$topics = mysql_query("SELECT id FROM ibwf_topics WHERE fid=".$fid."");

while($topic = mysql_fetch_array($topics))

{

mysql_query("DELETE FROM ibwf_posts WHERE tid='".$topic[0]."'");

}

mysql_query("DELETE FROM ibwf_topics WHERE fid='".$fid."'");

mysql_query("DELETE FROM ibwf_forums WHERE id='".$fid."'");

mysql_query("DELETE FROM ibwf_rooms WHERE clubid='".$clid."'");

mysql_query("DELETE FROM ibwf_clubmembers WHERE clid='".$clid."'");

mysql_query("DELETE FROM ibwf_announcements WHERE clid='".$clid."'");

mysql_query("DELETE FROM ibwf_clubs WHERE id=".$clid."");

return true;

}



function deleteMClubs($uid)

{

$uclubs = mysql_query("SELECT id FROM ibwf_clubs WHERE owner='".$uid."'");

while($uclub=mysql_fetch_array($uclubs))

{

deleteClub($uclub[0]);

}

}

//////////////////////Function add user to online list :P

function addonline($uid,$place,$plclink)

{

$hidden=mysql_fetch_array(mysql_query("SELECT hidden FROM ibwf_users WHERE id='".$uid."'"));

if($hidden[0]==0)

{

/////delete inactive users

$tm = time();

$timeout = $tm - 3600; //time out = 60 minutes

$deloff = mysql_query("DELETE FROM ibwf_online WHERE actvtime <'".$timeout."'");

 mysql_query("UPDATE ibwf_users SET pu='0' WHERE ptime<'".time()."'");

$lttime = mysql_fetch_array(mysql_query("SELECT lastact, plustime FROM ibwf_users WHERE id='".$uid."'")); 

$limit = time() - $lttime[0]; 
if($limit<450){
$newtime = $lttime[1] + $limit; 
if($newtime>1800){
mysql_query("UPDATE ibwf_users SET plustime='0', totaltime=totaltime+$limit, plusses=plusses+5 WHERE id='".$uid."'"); 

$res = mysql_query("INSERT INTO ibwf_notifications SET text='You are have been Online for 30 minutes. You have recieved 5 Plusses[br/][br/][small][i]p.s: This is an automated PM[/i][/small]', byuid='3', touid='".$uid."', timesent='".time()."'"); 
}else{ 
mysql_query("UPDATE ibwf_users SET  totaltime=totaltime+$limit, plustime='".$newtime."' WHERE id='".$uid."'"); 
} 
} 

///now try to add user to online list

$res = mysql_query("UPDATE ibwf_users SET lastact='".time()."' WHERE id='".$uid."'");

$res = mysql_query("INSERT INTO ibwf_online SET userid='".$uid."', actvtime='".$tm."', place='".$place."', placedet='".$plclink."'");
mysql_query("UPDATE ibwf_users SET lastact='".time()."' WHERE id='3'");

mysql_query("INSERT INTO ibwf_online SET userid='3', place='".$place."', actvtime='".$tm."'");
if(!$res)

{

//most probably userid already in the online list

//so just update the place and time

$res = mysql_query("UPDATE ibwf_online SET actvtime='".$tm."', place='".$place."', placedet='".$plclink."' WHERE userid='".$uid."'");





}

}

$maxmem=mysql_fetch_array(mysql_query("SELECT value FROM ibwf_settings WHERE id='2'"));



$result = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_online"));



if($result[0]>=$maxmem[0])

{

$tnow = date("D d M Y - H:i");

mysql_query("UPDATE ibwf_settings set name='".$tnow."', value='".$result[0]."' WHERE id='2'");

}

$maxtoday = mysql_fetch_array(mysql_query("SELECT ppl FROM ibwf_mpot WHERE ddt='".date("d m y")."'"));

if($maxtoday[0]==0||$maxtoday=="")

{

mysql_query("INSERT INTO ibwf_mpot SET ddt='".date("d m y")."', ppl='1', dtm='".date("H:i:s")."'");

$maxtoday[0]=1;

}

if($result[0]>=$maxtoday[0])

{

mysql_query("UPDATE ibwf_mpot SET ppl='".$result[0]."', dtm='".date("H:i:s")."' WHERE ddt='".date("d m y")."'");

}
$TIMETOBEONLINE = 1*60*60;
$PLUSSESTOADD = 10;  $PLUSSESTOADD2 = 3;


$un_tmonl = $hidden[2];
$tm_give = $TIMETOBEONLINE;

if($un_tmonl >= $tm_give)
{
$res = mysql_query("UPDATE ibwf_users SET plusses=plusses+$PLUSSESTOADD, rp=rp+$PLUSSESTOADD2, unique_tmonl='0' WHERE id='".$uid."'");
if($res)
{
$calc=floor($TIMETOBEONLINE/60/60);
if($calc<1) {$calc=floor($TIMETOBEONLINE/60)." minute(s)";} else {$calc=$calc." hour";}
$msg = "You have been given ".$PLUSSESTOADD." Plusses and ".$PLUSSESTOADD2." RP for staying online for ".$calc." continuosly...";
mysql_query("INSERT INTO ibwf_private SET text='".$msg."', byuid='3', touid='".$uid."', unread='1', timesent='".time()."'");
}
}


$lastact = $hidden[1];
$valid = 30*60;

$tmediff = time() - $lastact;

if($tmediff <= $valid) {
mysql_query("UPDATE ibwf_users SET tmonl=tmonl+$tmediff, unique_tmonl=unique_tmonl+$tmediff WHERE id='".$uid."'");
} else {
mysql_query("UPDATE ibwf_users SET unique_tmonl='0' WHERE id='".$uid."'");
}
}




/////////////////////Get members online



function getnumonline()

{

$nouo = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_online "));

return $nouo[0];

}



//////////////////////////////////////is ignored



function isignored($tid, $uid)

{

$ign = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_ignore WHERE target='".$tid."' AND name='".$uid."'"));

if($ign[0]>0)

{

return true;

}

return false;

}



///////////////////////////////////////////GET IP



function getip()

{

if (getenv('HTTP_X_FORWARDED_FOR'))

{

$ip=getenv('HTTP_X_FORWARDED_FOR');

}

else

{

$ip=getenv('REMOTE_ADDR');

}

return $ip;

}



//////////////////////////////////////////ignore result



function ignoreres($uid, $tid)

{

//0 user can't ignore the target

//1 yes can ignore

//2 already ignored

if($uid==$tid)

{

return 0;

}

if(ismod($tid))

{

//you cant ignore staff members

return 0;

}

/*if(arebuds($tid, $uid))

{

//why the hell would anyone ignore his bud? o.O

return 0;

}*/

if(isignored($tid, $uid))

{

return 2; // the target is already ignored by the user

}

return 1;

}



///////////////////////////////////////////Function getage



function getage($strdate)

{

$dob = explode("-",$strdate);

if(count($dob)!=3)

{

return 0;

}

$y = $dob[0];

$m = $dob[1];

$d = $dob[2];

if(strlen($y)!=4)

{

return 0;

}

if(strlen($m)!=2)

{

return 0;

}

if(strlen($d)!=2)

{

return 0;

}

$y += 0;

$m += 0;

$d += 0;

if($y==0) return 0;

$rage = date("Y") - $y;

if(date("m")<$m)

{

$rage-=1;



}else{

if((date("m")==$m)&&(date("d")<$d))

{

$rage-=1;

}

}

return $rage;

}



/////////////////////////////////////////getavatar



function getavatar($uid)

{

$av = mysql_fetch_array(mysql_query("SELECT avatar FROM ibwf_users WHERE id='".$uid."'"));

return $av[0];

}



/////////////////////////////////////////Can see details?



function cansee($uid, $tid)

{

if($uid==$tid)

{

return true;

}

if(ismod($uid))

{

return true;

}

return false;

}



//////////////////////////gettimemsg



function gettimemsg($sec)

{



$years=0;

$months=0;

$weeks=0;

$days=0;

$mins=0;

$hours=0;

if ($sec>59)

{

$secs=$sec%60;

$mins=$sec/60;

$mins=(integer)$mins;

}



if ($mins>59)

{

$hours=$mins/60;

$hours=(integer)$hours;

$mins=$mins%60;

}



if ($hours>23)

{

$days=$hours/24;

$days=(integer)$days;

$hours=$hours%24;

}



if ($days>6)

{

$weeks=$days/7;

$weeks=(integer)$weeks;

$days=$days%7;

}



if ($weeks>3)

{

$months=$weeks/4;

$months=(integer)$months;

$weeks=$weeks%4;

}



if ($months>11)

{

$years=$months/12;

$years=(integer)$years;

$months=$months%12;

}



if($years>0)

{

if($years==1){$yearmsg="year";}else{$yearmsg="years";}

if($months==1){$monthsmsg="month";}else{$monthsmsg="months";}

if($days==1){$daysmsg="day";}else{$daysmsg="days";}

if($hours==1){$hoursmsg="hour";}else{$hoursmsg="hours";}

if($mins==1){$minsmsg="minute";}else{$minsmsg="minutes";}

if($secs==1){$secsmsg="second";}else{$secsmsg="seconds";}



if($months!=0){$monthscheck="$months $monthsmsg ";}else{$monthscheck="";}

if(($days!=0)&&($months==0)){$dayscheck="$days $daysmsg ";}else{$dayscheck="";}

if(($hours!=0)&&($months==0)&&($days==0)){$hourscheck="$hours $hoursmsg ";}else{$hourscheck="";}

if(($mins!=0)&&($months==0)&&($days==0)&&($hours==0)){$minscheck="$mins $minsmsg ";}else{$minscheck="";}

if(($secs!=0)&&($months==0)&&($days==0)&&($hours==0)&&($mins==0)){$secscheck="$secs $secsmsg";}else{$secscheck="";}



return "$years $yearmsg $monthscheck$dayscheck$hourscheck$minscheck$secscheck";

}



if(($years<1)&&($months>0))

{

if($months==1){$monthsmsg="month";}else{$monthsmsg="months";}

if($days==1){$daysmsg="day";}else{$daysmsg="days";}

if($hours==1){$hoursmsg="hour";}else{$hoursmsg="hours";}

if($mins==1){$minsmsg="minute";}else{$minsmsg="minutes";}

if($secs==1){$secsmsg="second";}else{$secsmsg="seconds";}



if($days!=0){$dayscheck="$days $daysmsg ";}else{$dayscheck="";}

if(($hours!=0)&&($days==0)){$hourscheck="$hours $hoursmsg ";}else{$hourscheck="";}

if(($mins!=0)&&($days==0)&&($hours==0)){$minscheck="$mins $minsmsg ";}else{$minscheck="";}

if(($secs!=0)&&($days==0)&&($hours==0)&&($mins==0)){$secscheck="$secs $secsmsg";}else{$secscheck="";}



return "$months $monthsmsg $dayscheck$hourscheck$minscheck$secscheck";

}



if(($months<1)&&($weeks>0))

{

if($weeks==1){$weeksmsg="week";}else{$weeksmsg="weeks";}

if($days==1){$daysmsg="day";}else{$daysmsg="days";}

if($hours==1){$hoursmsg="hour";}else{$hoursmsg="hours";}

if($mins==1){$minsmsg="minute";}else{$minsmsg="minutes";}

if($secs==1){$secsmsg="second";}else{$secsmsg="seconds";}



if($days!=0){$dayscheck="$days $daysmsg ";}else{$dayscheck="";}

if(($hours!=0)&&($days==0)){$hourscheck="$hours $hoursmsg ";}else{$hourscheck="";}

if(($mins!=0)&&($days==0)&&($hours==0)){$minscheck="$mins $minsmsg ";}else{$minscheck="";}

if(($secs!=0)&&($days==0)&&($hours==0)&&($mins==0)){$secscheck="$secs $secsmsg";}else{$secscheck="";}



return "$weeks $weeksmsg $dayscheck$hourscheck$minscheck$secscheck";

}



if(($weeks<1)&&($days>0))

{

if($days==1){$daysmsg="day";}else{$daysmsg="days";}

if($hours==1){$hoursmsg="hour";}else{$hoursmsg="hours";}

if($mins==1){$minsmsg="minute";}else{$minsmsg="minutes";}

if($secs==1){$secsmsg="second";}else{$secsmsg="seconds";}



if($hours!=0){$hourscheck="$hours $hoursmsg ";}else{$hourscheck="";}

if(($mins!=0)&&($hours==0)){$minscheck="$mins $minsmsg ";}else{$minscheck="";}

if(($secs!=0)&&($hours==0)&&($mins==0)){$secscheck="$secs $secsmsg";}else{$secscheck="";}



return "$days $daysmsg $hourscheck$minscheck$secscheck";

}



if(($days<1)&&($hours>0))

{

if($hours==1){$hoursmsg="hour";}else{$hoursmsg="hours";}

if($mins==1){$minsmsg="minute";}else{$minsmsg="minutes";}

if($secs==1){$secsmsg="second";}else{$secsmsg="seconds";}



if($mins!=0){$minscheck="$mins $minsmsg ";}else{$minscheck="";}

if(($secs!=0)&&($mins==0)){$secscheck="$secs $secsmsg";}else{$secscheck="";}



return "$hours $hoursmsg $minscheck$secscheck";

}



if(($hours<1)&&($mins>0))

{

if($mins==1){$minsmsg="minute";}else{$minsmsg="minutes";}

if(($secs==1)&&($mins==0)){$secsmsg="second";}else{$secsmsg="seconds";}



if($secs!=0){$secscheck="$secs $secsmsg";}else{$secscheck="";}



return "$mins $minsmsg $secscheck";

}



if(($mins<1)&&($sec>0))

{

if($sec==1){$secsmsg="second";}else{$secsmsg="seconds";}



if($sec!=0){$secscheck="$sec $secsmsg";}else{$secscheck="";}



return "$secscheck";

}else{

return "Online!";

}

}


/////////////////////////////////////////get status



function getstatus($uid)

{

$info= mysql_fetch_array(mysql_query("SELECT cyberpowereragon, plusses, vip FROM ibwf_users WHERE id='".$uid."'"));
$secondsecurity = mysql_fetch_array(mysql_query("SELECT access_codes_new_fbd FROM foribd_extra_power WHERE userid='".$uid."'"));

if(isbanned($uid))

{

return "BANNED!";

}

if($info[2]=='1')

{

return "VIP Member";
//////////////
}else if($info[0]=='6' && $secondsecurity[0]==9080706)

{

return "&#169;Founder&#169;";

}else if($info[0]=='7' && $secondsecurity[0]==9080706)

{

return "&#169;Detactive Officer!";

}else if($info[0]=='8' && $secondsecurity[0]==9080706)

{

return "Forum Leader!";

}else if($info[0]=='5' && $secondsecurity[0]==9080706)

{

return "&#169;Captain!";
///////////////
}else if($info[0]=='4' && $secondsecurity[0]==9080706)

{

return "Administrator!!!";

}else if($info[0]=='3' && $secondsecurity[0]==9080706)

{

return "Head Moderator!!";

}else if($info[0]=='2' && $secondsecurity[0]==9080706)

{

return "Sennior Moderator!";

}else if($info[0]=='1' && $secondsecurity[0]==9080706)

{

return "Junior Moderator!";

}else{

if($info[1]<199)

{

return "New Member";

}else if($info[1]<399)

{

return "Junior Member";

}else if($info[1]<699)

{

return "Senior Member";

}else if($info[1]<999)

{

return "fbd Don";

}else if($info[1]<1499)

{

return "fbd Night Rider";

}else if($info[1]<2999)

{

return "fbd Knight";

}else if($info[1]<5999)

{

return "FDB Expeller";

}else if($info[1]<9999)

{

return "fbd Expart";

}else if($info[1]<14999)

{

return "fbd Master/Mistres";

}else if($info[1]<24999)

{

return "fbd Prince/Princes";

}else if($info[1]<34999)

{

return "fbd King/Queen";

}else if($info[1]<500000)

{

return "King OF King";

}else

{

return "New Member";

}

}

}
/////////////////////////////////////////get status



function getstatus2($uid)

{

$info= mysql_fetch_array(mysql_query("SELECT cyberpowereragon, plusses, vip, pu FROM ibwf_users WHERE id='".$uid."'"));
$secondsecurity = mysql_fetch_array(mysql_query("SELECT access_codes_new_fbd FROM foribd_extra_power WHERE userid='".$uid."'"));

if(isbanned($uid))

{

return "BANNED!";

}

if($info[2]=='1')

{

return "VIP Member";

}else if($info[3]=='1')

{

return "Premium User!";

}
else if($info[0]=='6' && $secondsecurity[0]==9080706)

{

return "Founder!!";

}else if($info[0]=='7' && $secondsecurity[0]==9080706)

{

return "Detactive Officer!!";

}else if($info[0]=='8' && $secondsecurity[0]==9080706)

{

return "Forum Leader!!";

}else if($info[0]=='5' && $secondsecurity[0]==9080706)

{

return "Captain!!!";
///////////////
}else if($info[0]=='4' && $secondsecurity[0]==9080706)

{

return "Administrator!!!";

}else if($info[0]=='3' && $secondsecurity[0]==9080706)

{

return "Head Moderator!!";

}else if($info[0]=='2' && $secondsecurity[0]==9080706)

{

return "Sennior Moderator!";

}else if($info[0]=='1' && $secondsecurity[0]==9080706)

{

return "Junior Moderator!";

}else{

if($info[1]<199)

{

return "New Member";

}else if($info[1]<399)

{

return "Junior Member";

}else if($info[1]<699)

{

return "Senior Member";

}else if($info[1]<999)

{

return "fbd Don";

}else if($info[1]<1499)

{

return "fbd Night Rider";

}else if($info[1]<2999)

{

return "fbd Knight";

}else if($info[1]<5999)

{

return "FDB Expeller";

}else if($info[1]<9999)

{

return "fbd Expart";

}else if($info[1]<14999)

{

return "fbd Master/Mistres";

}else if($info[1]<24999)

{

return "fbd Prince/Princes";

}else if($info[1]<34999)

{

return "fbd King/Queen";

}else if($info[1]<500000)

{

return "King OF King";

}else

{

return "New Member";

}

}

}
/////////////////////////////////////////get status



function getcar($uid)

{

$info= mysql_fetch_array(mysql_query("SELECT plusses FROM ibwf_users WHERE id='".$uid."'"));

if(isbanned($uid))

{

return "BANNED!";

}

if($info[0]<1000)

{

return "No Car!!";

}else if($info[0]<1500)

{

return "Ferrari Enzo";

}else if($info[0]<2000)

{

return "Porsche Carrera";

}else if($info[0]<3000)

{

return "Bugatti";

}else if($info[0]<400)

{

return "Jaguar XJ220";

}else{

if($info[1]<4500)

{

return "Lamborghini Murcielago";


}else if($info[1]<10000)

{

return "McLaren Mercedes SLR";

}else

{

return "McLaren Mercedes SLR";

}

}

}

/////////////////////Get Page Jumber

function getjumper($action, $sid,$pgurl)

{

$rets = "Jump to page<input name=\"pg\" format=\"*N\" size=\"3\"/>";

$rets .= "<anchor>[GO]";

$rets .= "<go href=\"$pgurl.php\" method=\"get\">";

$rets .= "<postfield name=\"action\" value=\"$action\"/>";

$rets .= "<postfield name=\"sid\" value=\"$sid\"/>";

$rets .= "<postfield name=\"page\" value=\"$(pg)\"/>";

$rets .= "</go></anchor>";



return $rets;

}

/////////////////////Get unread number of pms



function getunreadpm($uid)

{

$nopm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_private WHERE touid='".$uid."' AND unread='1'"));

return $nopm[0];

}



//////////////////////GET USER NICK FROM USERID



function getnick_uid($uid)

{

$unick = mysql_fetch_array(mysql_query("SELECT name FROM ibwf_users WHERE id='".$uid."'"));

return $unick[0];

}



///////////////////////////////////////////////Get the smilies



function getsmilies($text)

{

$sql = "SELECT * FROM ibwf_smilies";

$smilies = mysql_query($sql);

while($smilie=mysql_fetch_array($smilies))

{

$scode = $smilie[1];

$spath = $smilie[2];

$text = str_replace($scode,"<img src=\"$spath\" alt=\"$scode\"/>",$text);

}

return $text;

}



function getgallery($text)

{

$sql = "SELECT * FROM ibwf_gallery";

$smilies = mysql_query($sql);

while($smilie=mysql_fetch_array($smilies))

{

$scode = $gallery[1];

$spath = $gallery[2];

$text = str_replace($scode,"<img src=\"$spath\" alt=\"$scode\"/>",$text);

}

return $text;

}



////////////////////////////////////////////check nicks



function checknick($aim)

{

$chk =0;

$aim = strtolower($aim);

$nicks = mysql_query("SELECT id, name, nicklvl FROM ibwf_nicks");



while($nick=mysql_fetch_array($nicks))

{

if($aim==$nick[1])

{

$chk = $nick[2];

}else if(substr($aim,0,strlen($nick[1]))==$nick[1])

{

$chk = $nick[2];

}else{

$found = strpos($aim, $nick[1]);

if($found!=0)

{

$chk = $nick[2];

}

}

}

return $chk;

}



function autopm($msg, $who)

{

mysql_query("INSERT INTO ibwf_private SET text='".$msg."', byuid='3', touid='".$who."', unread='1', timesent='".time()."'");



}
///////
function autosign($msg, $who)

{
//$res = mysql_query("INSERT INTO ibwf_gbook SET gbowner='".$who."', gbsigner='".$uid."', dtime='".$crdate."', gbmsg='".$msgtxt."'");

//mysql_query("INSERT INTO ibwf_gbook SET text='".$msg."', byuid='3', touid='".$who."', unread='1', timesent='".time()."'");
mysql_query("INSERT INTO ibwf_gbook SET gbowner='".$who."', gbsigner='3', dtime='".$crdate."', gbmsg='".$msg."'");



}
/////
function FtpUpload($dest_file, $src_file){

// set up basic connection



$server='localhost'; // ftp server

$connection = ftp_connect($server); // connection



// login to ftp server

$user = "dmpwap";

$pass = "ste100";

$result = ftp_login($connection, $user, $pass);

// check connection

if ((!$connection) || (!$result)) {

echo "FTP connection has failed!";

echo "Attempted to connect to $ftp_server for user $ftp_user_name";

exit;

}

// upload the file

$upload = ftp_put($connection, $dest_file, $src_file, FTP_BINARY);



// check upload status

if (!$upload) {

echo "FTP upload has failed!";

}

// close the FTP stream

ftp_close($connection);

}

////////////////////////////////////////////////////Register



function register($name,$pass,$usex,$states,$status,$looked,$religious,$interested,$invited,$day,$month,$year, $ubr)

{

  $execms = mysql_query("SELECT * FROM ibwf_users WHERE name='".$name."';");

  

  if (mysql_num_rows($execms)>0){

    return 1;

  }else{

    $pass = md5($pass);

    $validation = mysql_fetch_array(mysql_query("SELECT value FROM ibwf_settings WHERE name='vldtn'"));

    if($validation[0]==1)

    {

    $validated=0;

    }else{

    $validated=1;

    }

    $reg = mysql_query("INSERT INTO ibwf_users SET name='".$name."', pass='".$pass."', birthday='".$year.$month.$day."', sex='".$usex."', states='".$states."', status='".$status."', interested='".$interested."', invited='".$invited."', looked='".$looked."',religious='".$religious."', regdate='".time()."', validated='".$validated."', ipadd='".getip()."', browserm='".$ubr."'");
$reg = mysql_query("INSERT INTO ibwf_invite SET name='".$name."', invited='".$invited."'");

//mysql_query("INSERT INTO lastview SET lastview='".$lv."', whonick='".$whonick."', ltime='".time()."'");
$reg = mysql_query("INSERT INTO lastview SET lastview='ChatGirl', whonick='".$name."', ltime='".time()."'");
    

    if ($reg)

    {

    $uid = getuid_nick($name);

      addonline($uid,"Just Registered","");

      $delonline = mysql_query("DELETE FROM ibwf_online WHERE userid='".$uid."'");

      $uid = mysql_fetch_array(mysql_query("SELECT id FROM ibwf_users WHERE name='".$name."'"));

      $sitename = mysql_fetch_array(mysql_query("SELECT value FROM ibwf_settings WHERE name='sitename'"));

      $msg = "Hello /reader =). Greetings from all $sitename[0] staff, we are happy to have you here, welcome to our big happy family!, If You Have any questions or comments about the site feel free to message me or any of the other staff members online. ENJOY! (excited)[br/][small][i]p.s: this is an automated pm[/i][/small]";

      $msg = mysql_escape_string($msg);

      autopm($msg, $uid[0]);
	        
	 $msg2 = "Hello /user.Thanks For Join With Us...We Are Happy To See You Here.If You Fix Any Problem Please Inform Any Online Staff.[br/][small][i]p.s: this is an automated sign[/i][/small]";

      $msg2 = mysql_escape_string($msg2);
	  autosign($msg2, $uid[0]);

      return 0;

    }else{

      return 2;

      

    }

  }

  

}

/////////////////////// GET ibwf_users user id from nickname



function getuid_nick($nick)

{

$uid = mysql_fetch_array(mysql_query("SELECT id FROM ibwf_users WHERE name='".$nick."'"));

return $uid[0];

}



/////////////////////////////////////////Is admin?



function isadmin($uid)

{

$admn = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwf_users WHERE id='".$uid."'"));

$secondsecurity = mysql_fetch_array(mysql_query("SELECT access_codes_new_fbd FROM foribd_extra_power WHERE userid='".$uid."'"));



if($admn[0]>=2 && $secondsecurity[0]==9080706)

{

return true;

}else{

return false;

}

}



/////////////////////////////////////////Is owner?



function isheadadmin($uid)

{

$own = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwf_users WHERE id='".$uid."'"));
$secondsecurity = mysql_fetch_array(mysql_query("SELECT access_codes_new_fbd FROM foribd_extra_power WHERE userid='".$uid."'"));







if($own[0]==3 && $secondsecurity[0]==9080706)

{

return true;

}else{

return false;

}

}

/////////////////////////////////////////Is captain?



function iscaptain($uid)

{

$own = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwf_users WHERE id='".$uid."'"));
$secondsecurity = mysql_fetch_array(mysql_query("SELECT access_codes_new_fbd FROM foribd_extra_power WHERE userid='".$uid."'"));

if($own[0]==5 && $secondsecurity[0]==9080706)

{

return true;

}else{

return false;

}

}
/////////////////////////////////////////Is owner?



function isowner($uid)

{

$own = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwf_users WHERE id='".$uid."'"));
$secondsecurity = mysql_fetch_array(mysql_query("SELECT access_codes_new_fbd FROM foribd_extra_power WHERE userid='".$uid."'"));

//if($own[0]==4 && $secondsecurity[0]==9080706)
if($own[0]>=4 && $secondsecurity[0]==9080706)

{

return true;

}else{

return false;

}

}
///////////////////////////////////



function swearing($str)
{
  $str = str_replace(" ","",$str);
  $sites[0] = "fuck";
  $sites[1] = "shit";
  $sites[2] = "dick";
  $sites[3] = "pussy";
  $sites[4] = "cunt";
  $sites[5] = "cock";
  $sites[6] = "slut";
  $sites[7] = "faggot";
  $sites[8] = "wanker";
  $sites[9] = "prick";
  $sites[10] = "bastard";
  $sites[11] = "bitch";

  for($i=0;$i<count($sites);$i++)
  {
  $str = strtolower($str);
        $nosf = substr_count($str,$sites[$i]);
    if($nosf>0)
    {
      return true;
    }
  }
  return false;
}

///////////////////////////////////parse bbcode



function getbbcode($text, $sid="", $filtered)

{

$text = htmlspecialchars($text);
$text=preg_replace("/\[red\](.*?)\[\/red\]/i","<font color=\"red\">\\1</font>", $text);
$text=preg_replace("/\[lime\](.*?)\[\/lime\]/i","<font color=\"lime\">\\1</font>", $text);
$text=preg_replace("/\[green\](.*?)\[\/green\]/i","<font color=\"green\">\\1</font>", $text);
$text=preg_replace("/\[yellow\](.*?)\[\/yellow\]/i","<font color=\"yellow\">\\1</font>", $text);
$text=preg_replace("/\[white\](.*?)\[\/white\]/i","<font color=\"white\">\\1</font>", $text);
$text=preg_replace("/\[blue\](.*?)\[\/blue\]/i","<font color=\"blue\">\\1</font>", $text);
$text=preg_replace("/\[grey\](.*?)\[\/grey\]/i","<font color=\"grey\">\\1</font>", $text);
$text=preg_replace("/\[silver\](.*?)\[\/silver\]/i","<font color=\"silver\">\\1</font>", $text);
$text=preg_replace("/\[navy\](.*?)\[\/navy\]/i","<font color=\"navy\">\\1</font>", $text);
$text=preg_replace("/\[darkgreen\](.*?)\[\/darkgreen\]/i","<font color=\"darkgreen\">\\1</font>", $text);
$text=preg_replace("/\[aqua\](.*?)\[\/aqua\]/i","<font color=\"aqua\">\\1</font>", $text);
$text=preg_replace("/\[aquamarine\](.*?)\[\/aquamarine\]/i","<font color=\"aquamarine\">\\1</font>", $text);
$text=preg_replace("/\[maroon\](.*?)\[\/maroon\]/i","<font color=\"maroon\">\\1</font>", $text);
$text=preg_replace("/\[purple\](.*?)\[\/purple\]/i","<font color=\"purple\">\\1</font>", $text);
$text=preg_replace("/\[skyblue\](.*?)\[\/skyblue\]/i","<font color=\"skyblue\">\\1</font>", $text);
$text=preg_replace("/\[darkseagreen\](.*?)\[\/darkseagreen\]/i","<font color=\"darkseagreen\">\\1</font>", $text);
$text=preg_replace("/\[yellowgreen\](.*?)\[\/yellowgreen\]/i","<font color=\"yellowgreen\">\\1</font>", $text);
$text=preg_replace("/\[sienna\](.*?)\[\/sienna\]/i","<font color=\"sienna\">\\1</font>", $text);
$text=preg_replace("/\[greenyellow\](.*?)\[\/greenyellow\]/i","<font color=\"greenyellow\">\\1</font>", $text);
$text=preg_replace("/\[powderblue\](.*?)\[\/powderblue\]/i","<font color=\"powderblue\">\\1</font>", $text);
$text=preg_replace("/\[tan\](.*?)\[\/tan\]/i","<font color=\"tan\">\\1</font>", $text);
$text=preg_replace("/\[thistle\](.*?)\[\/thistle\]/i","<font color=\"thistle\">\\1</font>", $text);
$text=preg_replace("/\[orchid\](.*?)\[\/orchid\]/i","<font color=\"orchid\">\\1</font>", $text);
$text=preg_replace("/\[goldenrod\](.*?)\[\/goldenrod\]/i","<font color=\"goldenrod\">\\1</font>", $text);
$text=preg_replace("/\[crimson\](.*?)\[\/crimson\]/i","<font color=\"crimson\">\\1</font>", $text);
$text=preg_replace("/\[plum\](.*?)\[\/plum\]/i","<font color=\"plum\">\\1</font>", $text);
$text=preg_replace("/\[lightcyan\](.*?)\[\/lightcyan\]/i","<font color=\"lightcyan\">\\1</font>", $text);
$text=preg_replace("/\[violet\](.*?)\[\/violet\]/i","<font color=\"violet\">\\1</font>", $text);
$text=preg_replace("/\[khaki\](.*?)\[\/khaki\]/i","<font color=\"khaki\">\\1</font>", $text);
$text=preg_replace("/\[magenta\](.*?)\[\/magenta\]/i","<font color=\"magenta\">\\1</font>", $text);
$text=preg_replace("/\[hotpink\](.*?)\[\/hotpink\]/i","<font color=\"hotpink\">\\1</font>", $text);
$text=preg_replace("/\[orange\](.*?)\[\/orange\]/i","<font color=\"orange\">\\1</font>", $text);

$text=preg_replace("/\[b\](.*?)\[\/b\]/i","<b>\\1</b>", $text);

$text=preg_replace("/\[i\](.*?)\[\/i\]/i","<i>\\1</i>", $text);

$text=preg_replace("/\[u\](.*?)\[\/u\]/i","<u>\\1</u>", $text);

$text=preg_replace("/\[big\](.*?)\[\/big\]/i","<big>\\1</big>", $text);

$text=preg_replace("/\[small\](.*?)\[\/small\]/i","\\1", $text);

$text = preg_replace("/\[topic\=(.*?)\](.*?)\[\/topic\]/is","<a class=\"plain\" href=\"index.php?action=viewtpc&amp;tid=$1&amp;sid=$sid\">$2</a>",$text);

$text = preg_replace("/\[club\=(.*?)\](.*?)\[\/club\]/is","<a class=\"plain\" href=\"index.php?action=gocl&amp;clid=$1&amp;sid=$sid\">$2</a>",$text);

$text = preg_replace("/\[blog\=(.*?)\](.*?)\[\/blog\]/is","<a class=\"plain\" href=\"index.php?action=viewblog&amp;bid=$1&amp;sid=$sid\">$2</a>",$text);

$text = preg_replace("/\[user\=(.*?)\](.*?)\[\/user\]/is","<a class=\"plain\" href=\"index.php?action=viewuser&amp;sid=$sid&amp;who=$1\">$2</a>",$text);

$text = preg_replace("/\[poll\=(.*?)\](.*?)\[\/poll\]/is","<a class=\"plain\" href=\"index.php?action=viewpl&who=$1&sid=$sid\">$2</a>",$text);

$text = preg_replace("/\[gb\=(.*?)\](.*?)\[\/gb\]/is","<a class=\"plain\" href=\"lists.php?action=gbook&amp;who=$1&amp;sid=$sid\">$2</a>",$text);


  /////////////////////////By 420
 $uid = getuid_sid($sid);
$text = str_replace("/user","<a href=\"index.php?action=viewuser&amp;who=$uid&amp;sid=$sid\">".getnick_uid($uid)."</a>",$text); 
$text = str_replace("/USER","<a href=\"index.php?action=viewuser&amp;who=$uid&amp;sid=$sid\">".getnick_uid($uid)."</a>",$text); 
  /////////////////////////By 420
 $uid = getuid_sid($sid);
$text = str_replace("/member","".getnick_uid($uid)."",$text); 
$text = str_replace("/MEMBER","".getnick_uid($uid)."",$text); 

if(substr_count($text,"[br/]")<=1000) {

$text = str_replace("[br/]","<br/>",$text);

}

$sml = mysql_fetch_array(mysql_query("SELECT hvia FROM ibwf_users WHERE id='".getuid_sid($sid)."'"));

if ($sml[0]=="1")

{

$text = getsmilies($text);

}

if($filtered=="1"){

if(swearing($text))

{

$text = strtolower($text);

$text = str_replace("fuck","***",$text);

$text = str_replace("shit","***",$text);

$text = str_replace("dick","***",$text);

$text = str_replace("pussy","***",$text);

$text = str_replace("cunt","***",$text);

$text = str_replace("cock","***",$text);

$text = str_replace("slut","***",$text);

$text = str_replace("faggot","***",$text);

$text = str_replace("prick","***",$text);

$text = str_replace("bastard","***",$text);

$text = str_replace("bitch","***",$text);

$text = str_replace("http://","***",$text);
}

}

return $text;

}



//////////////////////////////////////////////////MISC FUNCTIONS

function spacesin($word)

{

$pos = strpos($word," ");

if($pos === false)

{

return false;

}else

{

return true;

}

}



/////////////////////////////////Number of registered members

function regmemcount()

{

$rmc = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_users"));

return $rmc[0];

}

///////



///////////////////////////function counter



function addvisitor()

{

$cc = mysql_fetch_array(mysql_query("SELECT value FROM ibwf_settings WHERE name='Counter'"));

$cc = $cc[0]+1;

$res = mysql_query("UPDATE ibwf_settings SET value='".$cc."' WHERE name='Counter'");

}



function scharin($word)

{

$chars = "abcdefghijklmnopqrstuvwxyz0123456789-_";

for($i=0;$i<strlen($word);$i++)

{

$ch = substr($word,$i,1);

$nol = substr_count($chars,$ch);

if($nol==0)

{

return true;

}

}

return false;

}



function isdigitf($word)

{

$chars = "abcdefghijklmnopqrstuvwxyz";

$ch = substr($word,0,1);

$sres = ereg("[0-9]",$ch);



$ch = substr($word,0,1);

$nol = substr_count($chars,$ch);

if($nol==0)

{

return true;

}





return false;



}
//--------------------------> NOTIFICATIONS BY W3B_JOCKY
function notify($msg,$uid,$who)
{
mysql_query("INSERT INTO ibwf_notifications SET text='".$msg."', byuid='3', touid='".$who."', unread='1', timesent='".time()."'");
}
//--------------------------> NOTIFICATIONS BY W3B_JOCKY
////////////////////////////Get unread number of noty

function notification($uid)
{
    $nopm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_notifications WHERE touid='".$uid."' AND unread='1'"));
    return $nopm[0];

}
function notification2($uid)
{
    $nopm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_notifications WHERE touid='".$uid."'"));
    return $nopm[0];

}