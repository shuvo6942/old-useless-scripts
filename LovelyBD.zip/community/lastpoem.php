<?php
$lpt = mysql_fetch_array(mysql_query("SELECT id, name FROM ibwff_storys WHERE type='Poem' ORDER BY crdate DESC LIMIT 0,1"));
$nops = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_storys"));
if($nops[0]==0)
{
 $pinfo = mysql_fetch_array(mysql_query("SELECT authorid FROM ibwff_storys WHERE type='Poem'"));
$tluid = $pinfo[0];
}else{
$pinfo = mysql_fetch_array(mysql_query("SELECT  authorid  FROM ibwff_storys WHERE type='Poem' ORDER BY crdate DESC LIMIT 0, 1"));
$tluid = $pinfo[0];
}
 $tlnm = htmlspecialchars($lpt[1]);
 $tlnick = subnick(getnick_uid($tluid));
$format_link = ucwords(strtolower($tlnm));
$tpclnk = "<a href=\"literature.php?clid=$clid&tid=$lpt[0]&go=last\">$format_link</a>";
	    $sql = "SELECT name FROM ibwff_users WHERE id=$pinfo[0]";
	    $sql2 = mysql_query($sql);
	    $item = mysql_fetch_array($sql2);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item[0]'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/>";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/>";}
$sql2 = "SELECT name FROM ibwff_users WHERE id=$pinfo[0]";
	    $sql22 = mysql_query($sql2);
	    $item2 = mysql_fetch_array($sql22);
		{		
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item2[0]'"));
if($sex[0]=="M"){$usersex2 = "<font color=\"blue\"><b>$tlnick</b></font>";}
if($sex[0]=="F"){$usersex2 = "<font color=\"deeppink\"><b>$tlnick</b></font>";}
if($sex[0]==""){$usersex2 = "$tlnick";}
	$avlink = getavatar($pinfo[0]);
if($avlink=="")
{
 $avt =  "$usersex";
}else{
 $avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"icon\" width=\"23\" height=\"18\"/>";
}
echo " $tpclnk ";
echo " <b>By</b> <a href=\"profile.php?who=$tluid\">$avt$usersex2</a><br/>";
}
}
echo "<small>&#187; <a href=\"literature.php?action=10poem\">Last 10 Poem</a></small><br/>";
?>