<?php
session_start();
include("config.php");
include("core.php");  connectdb();
header("Content-type: text/html; charset=utf-8");
echo "<?xml version=\"1.0\" encoding=\"utf-8\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo '<head>';
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"title\" content=\"FireBD.NeT\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From Shahos: Don't Try To Hack OR else :P\">
<meta name=\"keywords\" content=\"Site Desined By Shahos :) :)\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/></head>";
echo "<body>";
##P0L| !S 100% CR3AT3D & D3S!NG3D BY Shahos :-D
$action = $_GET["action"]; $sid = $_SESSION["sid"];
$clid = $_GET["clid"]; $page = $_GET["page"];
$who = $_GET["who"];
$uid = getuid_sid($sid);
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();
////////////////Ip Banned By CJ UDAY :)	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
    echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
echo "<br/>";
echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
$banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
$remain =  $banto[0] - time();
$rmsg = gettimemsg($remain);
echo "<b>Time Remaining: $rmsg</b><br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "</p>";
echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
$uid = getuid_sid($sid);
//////////////////Banned System Updated By CJ UDAY :)
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please Contact <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
/////////////////////Polls Ban By CJ UDAY :)
  $ban = mysql_fetch_array(mysql_query("SELECT pollban FROM ibwff_users WHERE id='".$uid."'"));
if($ban[0] > 0)
  {
	echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
			 echo "<div class=\"header\" align=\"center\">";
			  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
  echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
  echo "<br/><b><u><i>Can't ENTER To Poll<br/>";
  echo "You're Poll banned!</i></u></b><br/><br/>";
 echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php?action=main\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
    exit();
    }
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");  
echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
///////////////////Deactivated Account By CJ UDAY :)
          if(isdeactivated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  <b>Your Account Has Been Deactivated Forever.<br/>And It Will Be Never Activate!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
///////////////////Validation By CJ UDAY :)
					if(isvalidated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  You Are Not Validated!<br/>We are checking your ip and browser<br/>
	  This could take up to 15 munites pls be patient and try again soon<br/>Please try again later...<br/><b>Thank You</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
//////////////////////////////////Polls Updated By CJ UDAY :)
if($action=="polls")
{
    addonline(getuid_sid($sid),"Viewing Polls list","polls.php?action?action=$action");
	    echo "<head>";
    echo "<title>View Polls List</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
echo "<b>Polls</b></div>";
  echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$page = $_GET["page"];
   if($page=="" || $page<=0)$page=1;   
$clid = $_GET["clid"];
 $noi = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_polls WHERE clubid=$clid"));
    $num_items = $noi[0];
    $items_per_page= 10;
    $num_pages = ceil($num_items/$items_per_page);
    if(($page>$num_pages)&&$page!=1)$page= $num_pages;
    $limit_start = ($page-1)*$items_per_page;
if($clid>0)
{
$sql = "SELECT id, pqst, uid, pdt FROM ibwff_polls WHERE clubid=$clid ORDER BY pdt DESC LIMIT $limit_start, $items_per_page";
}else{
$sql = "SELECT id, pqst, uid, pdt FROM ibwff_polls ORDER BY pdt DESC LIMIT $limit_start, $items_per_page";
}   
$items = mysql_query($sql);
    if(mysql_num_rows($items)>0)
    {
    while ($item = mysql_fetch_array($items))
    {
$bonick = subnick(getnick_uid($item[2]));
	    $sql2 = "SELECT name FROM ibwff_users WHERE id=$item[2]";
	    $sql22 = mysql_query($sql2);
	    $item2 = mysql_fetch_array($sql22);
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item2[0]'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/>";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/>";}
if($sex[0]==""){$usersex = "";}
$avlink = getavatar($item[2]);
if($avlink=="")
{
 $avt =  "$usersex";
}else{
 $avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"icon\" width=\"23\" height=\"18\"/>";
}
	    $sql3 = "SELECT name FROM ibwff_users WHERE id=$item[2]";
	    $sql33 = mysql_query($sql3);
	    $item3 = mysql_fetch_array($sql33);
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nicks = "<font color=\"blue\"><b>$bonick</b></font>";}
if($sex[0]=="F"){$nicks = "<font color=\"deeppink\"><b>$bonick</b></font>";}
if($sex[0]==""){$nicks = "";}
	if(pollboss($uid))
{
        $delink = "[<a href=\"delete.php?action=poll&who=$item[0]\">x</a>]";
}
      echo "<p align=\"left\">";
	  if (polltval($item[0]))
	{
      echo "Poll Name: <img src=\"../avatars/polls.gif\"/><a href=\"polls.php?who=$item[0]\"><b>$item[1]</b></a><br/>";
	  echo "By: $avt<a href=\"profile.php?who=$item[2]\">$nicks</a> $delink<br/>";
	  }
	 else
	{
if(pollboss($uid))
	{
	echo "&#8226; Poll name: <b>$item[1]</b><br/>";
	    echo "&#8226; <a href=\"polls.php?who=$item[0]\"> Validate $item[1]</a><br/>";
	}	
	echo "-------<br/>";	
	}
}
	  }
	echo "<br/><br/><a href=\"polls.php?action=crpoll&clid=$clid\">&#187; <b>Create A New Poll</b></a><br/>";
    if($page>1)
    {
      $ppage = $page-1;
      echo "<a href=\"polls.php?action=$action&page=$ppage&clid=$clid\">&#171;-Prev</a> ";
    }
    if($page<$num_pages)
    {
      $npage = $page+1;
      echo "<a href=\"polls.php?action=$action&page=$npage&clid=$clid\">Next-&#187;</a>";
    }
    echo "<br/>Page - $page/$num_pages<br/>";
    if($num_pages>2)
    {
			        $rets = "<form action=\"polls.php\" method=\"get\">";
        $rets .= "<input name=\"page\" style=\"-wap-input-format: '*N'\" size=\"2\"/>";
        $rets .= "<input type=\"hidden\" name=\"action\" value=\"$action\"/>";
        $rets .= "<input type=\"hidden\" name=\"sid\" value=\"$sid\"/>";
		$rets .= "<input type=\"hidden\" name=\"who\" value=\"$who\"/>";
   $rets .= "<input type=\"submit\" value=\"Go To Page\"/>";
        $rets .= "</form>";
        echo $rets;
    }
    echo "</p>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="")
{
$whnick = getnick_uid($who);
$whonick = getuid_sid($sid);
addonline(getuid_sid($sid),"Viewing A Poll","polls.php?action=$action");
$pollid = mysql_fetch_array(mysql_query("SELECT id FROM ibwff_polls WHERE id='".$who."'"));
		if (!polltval($pollid[0]))
	{
		echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
  echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
      echo "<br/>
	  This Poll is waiting for validation!<br/>Please try again later...<br/><b>Thank You</b><br/><br/>";
if(pollboss($uid))
	{
	$fname = mysql_fetch_array(mysql_query("SELECT pqst, opt1, opt2, opt3, opt4, opt5 FROM ibwff_polls WHERE id='".$pollid[0]."'"));
	$name = $fname[0];
	if (!empty($fname[1]))
	{
	$option1 = "option1: $fname[1]<br/>";
	}
	if (!empty($fname[2]))
	{
	$option2 = "option2: $fname[2]<br/>";
	}
	if (!empty($fname[3]))
	{
	$option3 = "option3: $fname[3]<br/>";
	}
	if (!empty($fname[4]))
	{
	$option4 = "option4: $fname[4]<br/>";
	}
	if (!empty($fname[5]))
	{
	$option5 = "option5: $fname[5]<br/>";
	}
	echo "&#8226; Poll name: <b>$name</b><br/>$option1 $option2 $option3 $option4 $option5";
	    echo "&#8226; <a href=\"validate.php?action=poll&who=$pollid[0]\"> Validate $name</a><br/>";
	    echo "&#8226; <a href=\"delete.php?action=poll&who=$who\"> Delete $name</a><br/>";
	}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }   
	    echo "<head>";
    echo "<title>View A Poll</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
$pollid = mysql_fetch_array(mysql_query("SELECT id FROM ibwff_polls WHERE id='".$who."'"));
$polli = mysql_fetch_array(mysql_query("SELECT id, pqst, opt1, opt2, opt3, opt4, opt5, pdt, uid FROM ibwff_polls WHERE id='".$pollid[0]."'"));
if(trim($polli[1])!="")
{
$qst = parsepm($polli[1], $sid);								echo "<div class=\"header\" align=\"center\">";
	echo "<b>View $qst Poll</b></div>";
  echo "<div class=\"shout2\" align=\"left\">";
  include("pm_by.php");
echo "<p align=\"left\">";
echo "Poll Creator: <a href=\"profile.php?who=$polli[8]\"><b>".subnick(getnick_uid($polli[8]))."</b></a><br/>";
if ((getuid_sid($sid))==$polli[8]  || pollboss(getuid_sid($sid)))
{
echo "<br/>[<a href=\"edit.php?action=editpoll&pid=$pollid[0]\">Edit Poll</a>]<br/>";
}
$vdone = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_presults WHERE uid='".$uid."' AND pid='".$pollid[0]."'"));
$nov = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_presults WHERE pid='".$pollid[0]."'"));
$nov = $nov[0];
if($vdone[0]>0)
{
$voted= true;
}else{
$voted = false;
}
$opt1 = $polli[2];
if(trim($opt1)!="")
{
$opt1 = htmlspecialchars($opt1);
$nov1 = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_presults WHERE pid='".$pollid[0]."' AND ans='1'"));
$nov1 = $nov1[0];
if($nov>0)
{
$per = floor(($nov1/$nov)*100);
$rests = "Votes: $nov1($per%)";
}else{
$rests = "Votes: 0(0%)";
}
if($voted)
{
$lnk = "1.$opt1 <small>$rests</small><br/>";
}else{
$lnk = "1.<a href=\"pollproc.php?action=votepl&clid=$clid&who=$who&plid=$pollid[0]&ans=1\">$opt1</a> <small>$rests</small><br/>";
}
echo "$lnk";
}
$opt2 = $polli[3];
if(trim($opt2)!="")
{
$opt2 = htmlspecialchars($opt2);
$nov2 = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_presults WHERE pid='".$pollid[0]."' AND ans='2'"));
$nov2 = $nov2[0];
if($nov>0)
{
$per = floor(($nov2/$nov)*100);
$rests = "Votes: $nov2($per%)";
}else{
$rests = "Votes: 0(0%)";
}
if($voted)
{
$lnk = "2.$opt2 <small>$rests</small><br/>";
}else{
$lnk = "2.<a href=\"pollproc.php?action=votepl&clid=$clid&who=$who&plid=$pollid[0]&ans=2\">$opt2</a> <small>$rests</small><br/>";
}
echo "$lnk";
}
$opt3 = $polli[4];
if(trim($opt3)!="")
{
$opt3 = htmlspecialchars($opt3);
$nov3 = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_presults WHERE pid='".$pollid[0]."' AND ans='3'"));
$nov3 = $nov3[0];
if($nov>0)
{
$per = floor(($nov3/$nov)*100);
$rests = "Votes: $nov3($per%)";
}else{
$rests = "Votes: 0(0%)";
}
if($voted)
{
$lnk = "3.$opt3 <small>$rests</small><br/>";
}else{
$lnk = "3.<a href=\"pollproc.php?action=votepl&clid=$clid&who=$who&plid=$pollid[0]&ans=3\">$opt3</a> <small>$rests</small><br/>";
}
echo "$lnk";
}
$opt4 = $polli[5];
if(trim($opt4)!="")
{
$opt4 = htmlspecialchars($opt4);
$nov4 = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_presults WHERE pid='".$pollid[0]."' AND ans='4'"));
$nov4 = $nov4[0];
if($nov>0)
{
$per = floor(($nov4/$nov)*100);
$rests = "Votes: $nov4($per%)";
}else{
$rests = "Votes: 0(0%)";
}
if($voted)
{
$lnk = "4.$opt4 <small>$rests</small><br/>";
}else{
$lnk = "4.<a href=\"pollproc.php?action=votepl&clid=$clid&who=$who&plid=$pollid[0]&ans=4\">$opt4</a> <small>$rests</small><br/>";
}
echo "$lnk";
}
$opt5 = $polli[6];
if(trim($opt5)!="")
{
$opt5 = htmlspecialchars($opt5);
$nov5 = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_presults WHERE pid='".$pollid[0]."' AND ans='5'"));
$nov5 = $nov5[0];
if($nov>0)
{
$per = floor(($nov5/$nov)*100);
$rests = "Votes: $nov5($per%)";
}else{
$rests = "Votes: 0(0%)";
}
if($voted)
{
$lnk = "5.$opt5 <small>$rests</small><br/>";
}else{
$lnk = "5.<a href=\"pollproc.php?action=votepl&clid=$clid&who=$who&plid=$pollid[0]&ans=5\">$opt5</a> <small>$rests</small><br/>";
}
echo "$lnk";
}
}else{
echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>This Poll Does Not Exist!";
}
echo "</p>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="crpoll")
{
addonline(getuid_sid($sid),"Creating A New Poll","polls.php?action=$action");
    echo "<head>";
    echo "<title>Create A Poll</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
	echo "<b>Create A Poll</b></div>";
						echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
 echo "<form action=\"pollproc.php?action=crpoll&&clid=$clid&who=$uid\" method=\"post\">";   	echo"<p align=\"left\">";
echo "<b><big>Question:</b></big><br/><input name=\"pques\" maxlength=\"1500\"/><br/>";
echo "<b>Option 1:</b><br/><input name=\"opt1\" maxlength=\"100\"/><br/>";
echo "<b>Option 2:</b><br/><input name=\"opt2\" maxlength=\"100\"/><br/>";
echo "<b>Option 3:</b><br/><input name=\"opt3\" maxlength=\"100\"/><br/>";
echo "<b>Option 4:</b><br/><input name=\"opt4\" maxlength=\"100\"/><br/>";
echo "<b>Option 5:</b><br/><input name=\"opt5\" maxlength=\"100\"/><br/><br/>";
    echo "<input type=\"submit\" value=\"Create\"/>";
    echo "</form>";
echo "</p>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
?>
</html>