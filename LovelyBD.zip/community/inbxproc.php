<?php
session_start();
include("config.php");
include("core.php");  connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo '<head>';
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"title\" content=\"Firebd.net\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From CJ UDAY: Don't Try To Hack OR else :P\">
<meta name=\"keywords\" content=\"Site Created By CJ UDAY :)\"></head>";
echo "<body>";
##INB0X C0D3Z CR3AT3D & S3CUR3D BY CJ UDAY :-)
$action = $_GET["action"];
$sid = $_SESSION["sid"];
$pmtext = $_POST["pmtext"];
$who = $_GET["who"];
$lastloc=$_GET["lstloc"];
$sitename = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='sitename'"));
$sitename = $sitename[0];
if($lastloc=="cht"){
$rid= $_GET["rid"];
$rooms = mysql_fetch_array(mysql_query("SELECT id, name FROM ibwff_rooms WHERE id='".$rid."'"));
$rname = $rooms[1];
}
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();
////////////////Ip Banned By CJ UDAY :)	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
    echo "<head>";
    echo "<title>Error!</title>";
    echo "</head>";
    echo "<body>";
	echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
      echo "<br/>";
      echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
      $banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
      $remain =  $banto[0] - time();
      $rmsg = gettimemsg($remain);
      echo "<b>Time Remaining: $rmsg</b><br/>";
      $nick = getnick_uid($banto[2]);
       $text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
      echo "</p>";
    	echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
    echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
    echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
$uid = getuid_sid($sid);
//////////////////Banned System Updated By CJ UDAY :)
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please Contact <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
/////////////////////PM Ban By CJ UDAY :)
  $ban = mysql_fetch_array(mysql_query("SELECT pmban FROM ibwff_users WHERE id='".$uid."'"));
if($ban[0] > 0)
  {
	    echo "<head>";
    echo "<title>Error!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
			 echo "<div class=\"header\" align=\"center\">";
			  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!</div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/><b><u><i>Can't Send PM<br/>";
  echo "You're PM banned!</i></u></b><br/><br/>";
 echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php?action=main\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
    exit();
    }
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<postfield name=\"loguid\" value=\"$(loguid)\"/>";
  echo "<postfield name=\"logpwd\" value=\"$(logpwd)\"/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"forgot.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
///////////////////Deactivated Account By CJ UDAY :)
          if(isdeactivated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
	echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  <b>Your Account Has Been Deactivated Forever.<br/>And It Will Be Never Activate!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
///////////////////Validation By CJ UDAY :)
					if(isvalidated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  You Are Not Validated!<br/>We are checking your ip and browser<br/>
	  This could take up to 15 munites pls be patient and try again soon<br/>Please try again later...<br/><b>Thank You</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><a href=\"".$_SERVER['HTTP_REFFERER']."\">Back</a><br/><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
if($action=="sendpm")
{
if(strlen($pmtext)<2)
 {
    echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
       echo "<div class=\"header\" align=\"center\">";
	echo "<b>Blank Message</b></div>";
    echo "<div class=\"shout2\" align=\"left\">";
      echo "Blank Or Short Message!!!<br/><br/>";   
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
}
    echo "<head>";
    echo "<title>Sending Message</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
       echo "<div class=\"header\" align=\"center\">";
	echo "<b>Send Message</b></div>";
    echo "<div class=\"shout2\" align=\"left\">";
  $whonick = getnick_uid($who);
  $byuid = getuid_sid($sid);
  $uid = getuid_sid($sid);
  $tm = time();
  $lastpm = mysql_fetch_array(mysql_query("SELECT MAX(timesent) FROM ibwff_private WHERE byuid='".$byuid."'"));
  $pmfl = $lastpm[0]+getpmaf();
  if($byuid==1)$pmfl=0;
  if($pmfl>$tm)
  {
  $rema = $pmfl - $tm;
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>";
  echo "Flood control: $rema Seconds<br/><br/>";
    echo "</div>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
  exit();
  }
if(isignored($uid, $who))
    {
    echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>";
    echo "Failed Sending inbox To $whonick. $whonick have ignored you.<br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("header.php");
echo "</div>";
echo "</body>";
    exit();
    }
else if(isblocked($pmtext,$byuid))
  {
  echo "<p align=\"center\">";
    echo "<b><u><i>Can't Send PM!!!<br/><br/>";
   echo "You Just Tried To Spam In LovelyBD via Inbox<br/>So You Are Now Inbox Banned!<br/>If You Inbox Banned By Our Mistake or Want To Be Inbox Unban<br/>Then Please With Contact <a href=\"online.php?action=stfol\">Online FireBD Staffs</a></b></i></u><br/>";
        $user = getnick_sid($sid);
    mysql_query("UPDATE ibwff_users SET pmban='1' WHERE id='".$uid."'");
    mysql_query("INSERT INTO ibwff_private SET text='[b](forwarded spam via inbox)[/b][br/]".$pmtext."', byuid='".$byuid."', touid='1', timesent='".$tm."'");
	mysql_query("INSERT INTO ibwff_private SET text='[b](forwarded spam via inbox)[/b][br/]".$pmtext."', byuid='".$byuid."', touid='2', timesent='".$tm."'");
	mysql_query("INSERT INTO ibwff_private SET text='[b](forwarded spam via inbox)[/b][br/]".$pmtext."', byuid='".$byuid."', touid='4', timesent='".$tm."'");
	echo "</p>";
	echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      echo "</body>";
      echo "</html>";
      exit();
  }
                  $privacy = mysql_fetch_array(mysql_query("SELECT pm FROM ibwff_users WHERE id='".$who."'"));
            if($privacy[0]==0 || (arebuds($uid, $who)) || (ispu(getuid_sid($sid))) || (ismod(getuid_sid($sid))))
            {
$p = mysql_fetch_array(mysql_query("SELECT totaltime FROM ibwff_users WHERE id='".$uid."'"));
if($p[0]<300)
{
echo "[X] You need to stay online at least 5minutes to send a message!";
}
  $res = mysql_query("INSERT INTO ibwff_private SET text='".$pmtext."', byuid='".$byuid."', touid='".$who."', timesent='".$tm."'");
  if($res)
  {
      include("pm_by.php");
    echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>";
$avtr = getavatar($who);
    echo "Message Was Sent Successfully To <img src=\"$avtr\" alt=\"$avtr\" width=\"18\" height=\"23\"><a href=\"profile.php?who=$who\">$whonick</a>!<br/><br/>";
    $f = parsepm($pmtext, $sid);
	echo "<b>You Said:</b><br/>$f<br/><br/>";
$lastpm = mysql_fetch_array(mysql_query("SELECT byuid, text, timesent, id FROM ibwff_private WHERE byuid='".$uid."' AND touid='".$who."' ORDER BY timesent DESC LIMIT 0,1"));
	     echo "&#171;<a href=\"edit.php?action=pm&pmid=$lastpm[3]\">Edit PM</a><br/><br/>";
$unr = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_private WHERE (byuid='".$who."' AND touid='".$byuid."') AND unread='1'")); 
$ttl = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_private WHERE (byuid='".$byuid."' AND touid='".$who."') AND (byuid='".$who."' AND touid='".$byuid."') AND unread='0' AND unread='1'"));
    echo "&#187; <a href=\"inbox.php?action=conversation&who=$who\">Conversation</a> [$unr[0]/$ttl[0]]<br/><br/>";
	$tmsg = getpmcount(getuid_sid($sid));
    $umsg = getunreadpm(getuid_sid($sid));
    echo "<img src=\"../avatars/prev.gif\" alt=\"&#171;\"> <a href=\"inbox.php?view=all\">Inbox Messages</a> [$umsg/$tmsg]<br/><br/>";
}else{
    echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>";
    echo "Can't Send Inbox to $whonick<br/><br/>";
  }
  }
    else{
  echo "<img src=\"../images/notok.gif\" alt=\"x\"/>Only Friends can send pm $unick<br/><a href=\"friendsproc.php?action=add&who=$who\">Add Friend</a><br/>";
  }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
 }  
else if($action=="uday")
{
    echo "<head>";
    echo "<title>Sending Message</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
       echo "<div class=\"header\" align=\"center\">";
	echo "<b>Send Message</b></div>";
    echo "<div class=\"shout2\" align=\"left\">";
$pmtext = $_POST["pmtext"];
 $pmtou = $_POST["who"];
  $who = getuid_nick($pmtou);
    if($who==0)
    {
      echo "<img src=\"images/notok.gif\" alt=\"x\"/>User Does Not Exists!<br/>";
    }else{
$whonick = getnick_uid($who);
  $byuid = getuid_sid($sid);
  $tm = time();
  $lastpm = mysql_fetch_array(mysql_query("SELECT MAX(timesent) FROM ibwff_private WHERE byuid='".$byuid."'"));
  $pmfl = $lastpm[0]+getpmaf();
  if($pmfl<$tm)
  {
    if(!isblocked($pmtext,$byuid))
    {
    if((!isignored($byuid, $who))&&(!istrashed($byuid)))
    {
  $res = mysql_query("INSERT INTO ibwff_private SET text='".$pmtext."', byuid='".$byuid."', touid='".$who."', timesent='".$tm."'");
  }else{
    $res = true;
  }
  if($res)
  {
    echo "<img src=\"images/ok.gif\" alt=\"O\"/>";
$at = getavatar($who);
    echo "PM was sent successfully to <img src=\"$at\" alt=\"$at\"><a href=\"profile.php?who=$who\">$whonick</a><br/><br/>";
    $c = parsepm($pmtext, $sid);
echo "<b>You Said:</b><br/>$c<br/><br/>";
$lastpm = mysql_fetch_array(mysql_query("SELECT byuid, text, timesent, id FROM ibwff_private WHERE byuid='".$uid."' AND touid='".$who."' ORDER BY timesent DESC LIMIT 0,1"));
	     echo "&#171;<a href=\"edit.php?action=pm&pmid=$lastpm[3]\">Edit PM</a><br/><br/>";
$unr = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_private WHERE ((byuid='".$byuid."' AND touid='".$who."') OR (byuid='".$who."' AND touid='".$byuid."')) AND unread='1'")); 
$ttl = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_private WHERE ((byuid='".$byuid."' AND touid='".$who."') OR (byuid='".$who."' AND touid='".$byuid."')) AND unread='1' AND unread='0'"));
    echo "&#187; <a href=\"inbox.php?action=conversation&who=$who\">Conversation</a> [$unr[0]/$ttl[0]]<br/><br/>";
	$tmsg = getpmcount(getuid_sid($sid));
    $umsg = getunreadpm(getuid_sid($sid));
    echo "<img src=\"../avatars/prev.gif\" alt=\"&#171;\"> <a href=\"inbox.php?view=all\">Inbox Messages</a> [$umsg/$tmsg]<br/><br/>";
  }else{
    echo "<img src=\"images/notok.gif\" alt=\"X\"/>";
    echo "Can't Send PM to $whonick<br/><br/>";
  }
  }else{
   $bantime = time() + (7*24*60*60);
    echo "<img src=\"images/notok.gif\" alt=\"X\"/>";
    echo "Can't Send PM to $whonick<br/><br/>";
    echo "You just sent a link to one of the crapiest sites on earth<br/> The members of these sites spam here a lot, so go to that site and stay there if you don't like it here<br/> as a result of your stupid action:<br/>1. you have lost your sheild<br/>2. you have lost all your points<br/>3. You are BANNED!";
    mysql_query("INSERT INTO ibwff_penalties SET uid='".$byuid."', penalty='1', exid='1', timeto='".$bantime."', pnreas='Banned: Automatic Ban for spamming for a crap site'");
    mysql_query("UPDATE ibwff_users SET plusses='0', shield='0' WHERE id='".$byuid."'");
    mysql_query("INSERT INTO ibwff_private SET text='".$pmtext."', byuid='".$byuid."', touid='2', timesent='".$tm."', reported='1'");
  }
  }else{
    $rema = $pmfl - $tm;
    echo "<img src=\"images/notok.gif\" alt=\"X\"/>";
    echo "Flood control: $rema Seconds<br/><br/>";
  }
    }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
/////////////////////////////////Report Message By CJ UDAY :)
else if($action=="rept")
{
$pmid = $_GET["pmid"];
    echo "<head>";
    echo "<title>Reporting Message</title>";
       echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
			echo "<b>Report Message</b></div>";
		echo "<div class=\"shout2\" align=\"left\">";
          $rep = mysql_query("UPDATE ibwff_private SET reported='1' WHERE id='".$pmid."' ");
          if($rep)
          {
          echo "<br/><img src=\"../avatars/ok.gif\" alt=\"O\"/>Message Reported Successfully!<br/><br/>";
          }else{
		  echo "<br/><img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!<br/><br/>";
		  } 
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
/////////////////////////////////Delete Message By CJ UDAY :)
else if($action=="delpm")
{
$pmid = $_GET["pmid"];
    echo "<head>";
    echo "<title>Deleting Message</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
			echo "<b>Delete Message</b></div>";
		echo "<div class=\"shout2\" align=\"left\">";
          $del = mysql_query("DELETE FROM ibwff_private WHERE id='".$pmid."' ");
          if($del)
          {
          echo "<br/><img src=\"../avatars/ok.gif\" alt=\"O\"/>Message Deleted Successfully!<br/><br/>";
          }else{
		  echo "<br/><img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!<br/><br/>";
		  } 
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
/////////////////////////////////Archive Message By CJ UDAY :)
else if($action=="acr")
{
$pmid = $_GET["pmid"];
    echo "<head>";
    echo "<title>Archive Message</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
			echo "<b>Archive Message</b></div>";
		echo "<div class=\"shout2\" align=\"left\">";
          $acr = mysql_query("UPDATE ibwff_private SET starred='1' WHERE id='".$pmid."' ");
          if($acr)
          {
          echo "<br/><img src=\"../avatars/ok.gif\" alt=\"O\"/>Message archived Successfully!<br/><br/>";  
          }else{
		  echo "<br/><img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!<br/><br/>";
		  }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
/////////////////////////////////Unacrive Message By CJ UDAY :)
else if($action=="unacr")
{
$pmid = $_GET["pmid"];
    echo "<head>";
    echo "<title>Unarchive Message</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
			echo "<b>Unarchive Message</b></div>";
		echo "<div class=\"shout2\" align=\"left\">";
          $unacr = mysql_query("UPDATE ibwff_private SET starred='0' WHERE id='".$pmid."' ");
          if($unacr)
          {
          echo "<br/><img src=\"../avatars/ok.gif\" alt=\"O\"/>Message unarchived Successfully!<br/><br/>";
          }else{
		  echo "<br/><img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!<br/><br/>";
		  }  
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="all")
{
    echo "<head>";
    echo "<title>All Messages</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
			echo "<b>Delete All Messages</b></div>";
			echo "<div class=\"shout2\" align=\"left\">";
  $uid = getuid_sid($sid);
  $del = mysql_query("DELETE FROM ibwff_private WHERE byuid='".$uid."' AND touid='".$uid."' AND unread='0' AND unread='1' AND starred='0'");
  if($del)
  {
  echo "<br/><img src=\"../avatars/ok.gif\" alt=\"O\"/>All Messages Deleted Successfully!<br/><br/>";
  }else{
  echo "<br/><img src=\"../avatars/notok.gif\" alt=\"X\"/>Can't Delete All Messages At The Moment!<br/><br/>";
  }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="read")
{
    echo "<head>";
    echo "<title>Read Messages</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
			echo "<b>Delete Read Messages</b></div>";
			echo "<div class=\"shout2\" align=\"left\">";  
  $uid = getuid_sid($sid);
  $del = mysql_query("DELETE FROM ibwff_private WHERE touid='".$uid."' AND unread='0' AND starred='0'");
  if($del)
  {
  echo "<br/><img src=\"../avatars/ok.gif\" alt=\"O\"/>All Read Messages Deleted Successfully!<br/><br/>";
  }else{
  echo "<br/><img src=\"../avatars/notok.gif\" alt=\"X\"/>Can't Delete All Read Notfications At The Moment!<br/><br/>";
  }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="unread")
{
    echo "<head>";
    echo "<title>Unread Messages</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
			echo "<b>Delete Unread Messages</b></div>";
			echo "<div class=\"shout2\" align=\"left\">";
  $uid = getuid_sid($sid);
  $del = mysql_query("DELETE FROM ibwff_private WHERE touid='".$uid."' AND unread='1' AND starred='0'");
  if($del)
  {
  echo "<br/><img src=\"../avatars/ok.gif\" alt=\"O\"/>All Unead Messages Deleted Successfully!<br/><br/>";
  }else{
  echo "<br/><img src=\"../avatars/notok.gif\" alt=\"X\"/>Can't Delete All Unread Messages At The Moment!<br/><br/>";
  }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="forwordpm")
{
$name = $_POST["name"];
$pmid = $_GET["pmid"];
    echo "<head>";
    echo "<title>Forword Message</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
			echo "<b>Forwording Message</b></div>";
			echo "<div class=\"shout2\" align=\"left\">";
  $byuid = getuid_sid($sid);
  $who = getuid_nick($name);
$pminfo = mysql_fetch_array(mysql_query("SELECT text, byuid, timesent,touid, reported FROM ibwff_private WHERE id='".$pmid."'"));
$time = date("h:i:s a",($pminfo[2]+6*60*60));
$txt = "PM From ".getnick_uid($pminfo[1])." To ".getnick_uid($pminfo[3])." [br/] Time: ".date("h:i:s a",($pminfo[2]+6*60*60))." [br/] $pminfo[0] [br/] [Forwarded]";
if ($pminfo[1]==$uid || $pminfo[3]==$uid)
{
  $res = mysql_query("INSERT INTO ibwff_private SET text='".$txt."', byuid='".$byuid."', touid='".$who."', timesent='".time()."'");
  if($res)
  {
      include("pm_by.php");
    echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>";
    echo "Message Forworded Successfully To <a href=\"profile.php?who=$who\">$name</a>!<br/><br/>";
    echo parsepm($pmtext, $sid);
	echo "<br/><br/>";
  }else{
    echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>";
    echo "Can't Send Inbox to $name<br/><br/>";
  }
  }else{
    echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>";
    echo "this Pm is Not Your!<br/><br/>";
  }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
?>
</html>