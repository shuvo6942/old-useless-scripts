<?php
$start = microtime(true);
include("config.php");
include("core.php");
connectdb();
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
$a = $_GET["action"];
if($a=="")
{
	echo "<head>";
	echo "<title>Password Reset</title>";
	echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
	echo "</head>";
	echo "<body>";
echo "<div class=\"header\" align=\"center\">";
 echo "<b>Request a Password Reset</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
      echo "<img src=\"p.gif\"> <b>Please input email and username correctly!</b>";
 echo "<form action=\"forget.php?action=mypass\" method=\"post\">";
 echo "Username:<br/> <input name=\"name\" maxlength=\"20\"/><br/>";
echo "Email:<br/> <input name=\"email\" maxlength=\"30\"/><br/>";   
 echo "<input type=\"submit\" value=\"Reset\"/>";
  echo "</form>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
}else if($a=="mypass")
{
	echo "<head>";
	echo "<title>Password Reset</title>";
	echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
	echo "</head>";
	echo "<body>";
echo "<div class=\"header\" align=\"center\">";
 echo "<b>Request a Password Reset</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
$name = $_POST["name"];
$email = $_POST["email"];
     $ressend = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE email='".$email."'"));
          $ressend = $ressend[0];
                          $ok = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE name='".$name."'"));
               if($ressend>0)
                          {
$name = $_POST["name"];
$email = $_POST["email"];
$uinf = mysql_fetch_array(mysql_query("SELECT uday_pass FROM ibwff_users WHERE name='".$name."'"));
$brwsing = explode(" ",$_SERVER[HTTP_USER_AGENT] );
$brwsing = $brwsing[0];
$subject = "Request a Password Resend";
$hourdiff = "6";
$New_Time = time()+($hourdiff * 3600);
$flipdate = date("l, d F Y g:i a",time() + ($hourdiff * 3600));
$ip=getenv('REMOTE_ADDR');
$sitename = "LovelyBD.Com";
  $thanksko = "thank you very much for your request password at our site http://lovelybd.com";
$msg = "\n Hello $name, we have a password request by ip:$ip and browser:$brwsing
\n Your Password: ".reverse_md5('$uinf[0]')." 
 $thanksko. Done on this $flipdate.\n\n Thank You\n $sitename .";
$subj = "Password details for ".$sitename."";
$headers = 'From: passwordreset@lovelybd.com' . "\r\n" .
'Reply-To: passwordreset@lovelybd.com' . "\r\n" .
'X-Mailer: PHP/' . phpversion();
$ab = mail($email, $subj, $msg, $headers);
if($ab)
{
echo "<b>Mail sent to $email </b><br/>";
              }else{
echo "<b>Unable to sent mail to $email </b><br/>";
}
}else{
                    echo"No such email like $email";                   }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
}
?>
</html>