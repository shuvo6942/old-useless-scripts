<?php
session_start();
include("config.php");
include("core.php");
connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo "<head>";
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"Styles.css\" />";
echo "<body><meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG : Don't Try To Hack OR else :P\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"main,all,follow\"/></head>";
echo "<body>";
##SH0UTS IZ T0TALLY CR3AT3D & S3CUR3D BY Shahos :-)
$action = $_GET["action"]; $sid = $_SESSION["sid"];
$clid = $_GET["clid"]; $action = $_GET["action"];
$page = $_GET["page"];
$who = $_GET["who"];
$uid = getuid_sid($sid);
$sitename = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='sitename'"));
$sitename = $sitename[0];
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
echo "<head>";
echo "<title>Error!!!</title>";
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\"/>";
echo "</head>";
echo "<body>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
echo "<br/>";
echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
$banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
$remain =  $banto[0] - time();
$rmsg = gettimemsg($remain);
echo "<b>Time Remaining: $rmsg</b><br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "</p>";
echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
echo "<img src=\"../images/user.png\" alt=\"user\"><b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
echo "<img src=\"../images/pass.png\" alt=\"pass\"><b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\"/>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<img src=\"../images/user.png\" alt=\"user\"><b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<img src=\"../images/pass.png\" alt=\"pass\"><b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"left\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\"/>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"left\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<img src=\"../images/user.png\" alt=\"user\"><b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<img src=\"../images/pass.png\" alt=\"pass\"><b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "<div class=\"div align=\"center\">Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"Styles.css\"/>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please Contact <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(isdeactivated(getuid_sid($sid), $uid))
{
echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<br/><b>Your Account Has Been Deactivated.<br/>And It Will Be Never Activated Again!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
//////////////////////////////////More Shout Updated By CJ UDAY :)
else if($action=="shouts")
{
    addonline(getuid_sid($sid),"Viewing More Shouts","shouts.php?action=$action");
	    echo "<head>";
    echo "<title>View More Shouts</title>";
    echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\"/>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
           echo "</div>";
    echo "<div class=\"header\" align=\"center\">";
	echo "<b>More Shouts</b></div>";
	echo "<div class=\"shout2\" align=\"left\">";
echo "<center>";
if(getplusses(getuid_sid($sid))<50)
    {
	$shout = 50 - getplusses($uid);
        echo "You Need $shout Points To Add Shout!<br/>
		<a href=\"forums.php?tid=1\">How To Get Points??</a>";
    }else{
echo "<form action=\"shoutproc.php?action=shout&who=$who\" method=\"post\">";
  echo "ShoutBox Message:<br/><input name=\"shtxt\" maxlength=\"1000\"/><br/>";
  echo "<img src=\"../images/activity.jpg\" alt=\"activity\"><a href=\"activity.php\"><font color=\"grey\"><b>Activity</b></font></a> <input type=\"Submit\" name=\"shout\" Value=\"Post Shout\"> <img src=\"../images/attach.png\" alt=\"attach\"><a href=\"attach.php\"><font color=\"grey\"><b>Attach</b></font></a></form>";
            }    
echo "</center>";
if($page=="" || $page<=0)$page=1;
    if($who=="")
    {
    $noi = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_shouts"));
    }else{
    $noi = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_shouts WHERE shouter='".$who."'"));
    }
    $num_items = $noi[0];
    $items_per_page= 8;
    $num_pages = ceil($num_items/$items_per_page);
    if(($page>$num_pages)&&$page!=1)$page= $num_pages;
    $limit_start = ($page-1)*$items_per_page;
    if($clid>0)
    {
        $sql = "SELECT id, shout, shouter, shtime  FROM ibwff_shouts WHERE clubid=$clid ORDER BY shtime DESC LIMIT $limit_start, $items_per_page";
}else{
    $sql = "SELECT id, shout, shouter, shtime  FROM ibwff_shouts  WHERE clubid=0 ORDER BY shtime DESC LIMIT $limit_start, $items_per_page";
}
$items = mysql_query($sql);  if(mysql_num_rows($items)>0)
    {
    while ($item = mysql_fetch_array($items))
    {
	    $sql2 = "SELECT name FROM ibwff_users WHERE id=$item[2]";
	    $sql22 = mysql_query($sql2);
	    $item2 = mysql_fetch_array($sql22);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item2[0]'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/>";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/>";}
if($sex[0]==""){$usersex = "";}
        		$avlink = getavatar($item[2]);
if($avlink=="")
{
 $avt =  "$usersex";
}else{
 $avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"icon\" width=\"23\" hieght=\"18\"/>";
}
        $shnick = getnick_uid($item[2]);
	    $sql3 = "SELECT name FROM ibwff_users WHERE id=$item[2]";
	    $sql33 = mysql_query($sql3);
	    $item3 = mysql_fetch_array($sql33);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nicks = "<font color=\"blue\"><b>$shnick</b></font>";}
if($sex[0]=="F"){$nicks = "<font color=\"deeppink\"><b>$shnick</b></font>";}
if($sex[0]==""){$nicks = "";}
	  $sht2 = parsepm($item[1], $sid);
 $lnk = "<a href=\"profile.php?who=$item[2]\">$avt$nicks</a> (".getstatus($item[2]).")<br/> $sht2";
	  }
echo "<div class=\"shout\" align=\"left\">";
      if((ismod(getuid_sid($sid))) || (shoutboss($uid)))
      {
      $dlsh = "[<a href=\"modproc.php?action=delsh&shid=$item[0]\">Delete Shout</a>]";
      }else{
        $dlsh = "";
      }
      echo "$lnk<br/>";
	  }
	  $shcomm = mysql_fetch_assoc(mysql_query("SELECT COUNT(*) comm FROM ibwff_shcomments WHERE shoutid='".$item[0]."'"));
	  $shout = $shcomm['comm'];
$lstlike = mysql_fetch_array(mysql_query("SELECT uid FROM ibwff_like ORDER BY ltime DESC LIMIT 1"));
$lstdislike = mysql_fetch_array(mysql_query("SELECT uid FROM ibwff_dislike ORDER BY ltime DESC LIMIT 1"));
        $lnick = getnick_uid($lstlike[0]);
        $dlnick = getnick_uid($lstdislike[0]);
$counts = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_like WHERE shoutid='".$item[0]."'"));
$counts1 = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_dislike WHERE shoutid='".$item[0]."'"));
echo "<br/><div class=\"likebox\" align=\"center\">";
echo "<img src=\"comment.png\"><a href=\"shcomments.php?shid=$item[0]\">Comments($shout)</a>";
 echo "<hr><img src=\"like.png\"><a href=\"shoutproc.php?action=like&shid=$item[0]\">Like</a>(<a href=\"like.php?shid=$item[0]\">$counts[0]</a>)";
 echo "<hr><img src=\"dislike.png\"><a href=\"shoutproc.php?action=dislike&shid=$item[0]\">Dislike</a>(<a href=\"dislike.php?shid=$item[0]\">$counts1[0]</a>)<br/>";
echo '</div>';
echo "$dlsh";
echo "</div>";
   }
    }
    echo "<center>";
if(getplusses(getuid_sid($sid))<50)
    {
	$shout = 50 - getplusses($uid);
        echo "You Need $shout Points To Add Shout!<br/>
		<a href=\"forums.php?tid=1\">How To Get Points??</a>";
    }else{
echo "<form action=\"shoutproc.php?action=shout&who=$who\" method=\"post\">";
  echo "ShoutBox Message:<br/><input name=\"shtxt\" maxlength=\"1000\"/><br/>";
  echo "<img src=\"../images/activity.jpg\" alt=\"activity\"><a href=\"activity.php\"><font color=\"grey\"><b>Activity</b></font></a> <input type=\"Submit\" name=\"shout\" Value=\"Post Shout\"> <img src=\"../images/attach.png\" alt=\"attach\"><a href=\"attach.php\"><font color=\"grey\"><b>Attach</b></font></a></form>";
            }
			echo "</center>";
echo "<p align=\"left\">";
    if($page>1)
    {
      $ppage = $page-1;
      echo "<a href=\"shouts.php?action=shouts&page=$ppage\">&#171;-Prev</a> ";
    }
    if($page<$num_pages)
    {
      $npage = $page+1;
      echo "<a href=\"shouts.php?action=shouts&page=$npage\">Next-&#187;</a>";
    }
    echo "<br/>Page - $page/$num_pages<br/>";
  if($num_pages>2)
    {
			        $rets = "<form action=\"shouts.php\" method=\"get\">";
        $rets .= "<input name=\"page\" style=\"-wap-input-format: '*N'\" size=\"2\"/>";
        $rets .= "<input type=\"hidden\" name=\"action\" value=\"$action\"/>";
        $rets .= "<input type=\"hidden\" name=\"sid\" value=\"$sid\"/>";
        $rets .= "<input type=\"submit\" value=\"Go To Page\"/>";
        $rets .= "</form>";
        echo $rets;
    }
    echo "</p>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
exit();
}
?>