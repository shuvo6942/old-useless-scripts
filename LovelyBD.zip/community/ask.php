<?php
session_start();
include("config.php");
include("core.php");  connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo '<head>';
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"title\" content=\"FireBD.NeT\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From Megh: Don't Try To Hack OR else :P\">
<meta name=\"keywords\" content=\"Site Desined By Megh :) :)\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/></head>";
echo "<body>";
$action = $_GET["action"]; $sid = $_SESSION["sid"];
$page = $_GET["page"];
$who = $_GET["who"];
$uid = getuid_sid($sid);
$name = $_GET["name"];
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();
////////////////Ip Banned By CJ UDAY :)	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
    echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
	echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
      echo "<br/>";
      echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
      $banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
      $remain =  $banto[0] - time();
      $rmsg = gettimemsg($remain);
      echo "<b>Time Remaining: $rmsg</b><br/>";
      $nick = getnick_uid($banto[2]);
       $text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
      echo "</p>";
    	echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
    echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
    echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
//////////////////Banned System Updated By CJ UDAY :)
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please With Contact Us <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
 echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
///////////////////Validation By CJ UDAY :)
					if(isvalidated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
	echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  You Are Not Validated!<br/>We are checking your ip and browser<br/>
	  This could take up to 15 munites pls be patient and try again soon<br/>Please try again later...<br/><b>Thank You</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
///////////////////Deactivated Account By CJ UDAY :)
          if(isdeactivated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  <b>Your Account Has Been Deactivated Forever.<br/>And It Will Be Never Activate!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="ask")
{
$who=$_GET["who"];
addonline(getuid_sid($sid),"Signing AskME","profile.php?action=$action");
	$who = $_GET["who"];
$whnick = subnick(getnick_uid($who));
	    echo "<head>";
    echo "<title>Sign On $whnick's AskME</title>";
    echo "</head>";
    echo "<body>";
    echo "<div class=\"header\"> <img src=\"FireBD.png\" alt=\"[$sitename]\" width=\"280\" height=\"55\"/><br/>";
    echo "<b>Sign $whnick's AskME</b></div>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
  echo "<div class=\"shout2\" align=\"left\">";
if($uid == $who)
{
$sj = mysql_query("SELECT ques, id FROM uday_ask WHERE ans IS NULL");
while($q = mysql_fetch_array($sj))
{
echo "Q: ".parsepm($q[0])."<br/>";
echo "[<a href=\"ask.php?action=ans&aid=$q[1]\">Answer</a>]<br/>[<a href=\"ask.php?action=del&aid=$q[1]\">Delete</a>]<br/>";
}
}
 echo "<onevent type=\"onenterforward\">";
  echo "<refresh>
        <setvar name=\"msgtxt\" value=\"\"/>
   ";
  echo "</refresh></onevent>"; 
echo "<form action=\"askproc.php?action=ask&who=$who\" method=\"post\">";
    echo "Question:<br/><input name=\"msgtxt\" maxlength=\"500\"/>";
echo "<input type=\"hidden\" name=\"who\" value=\"$who\"/>";
echo "<br/>Hide Yourself: <select name=\"hide\">
<option value=\"y\">Yes</option>
<option value=\"n\">No</option>
</select><br/>";
 echo "<input type=\"submit\" value=\"Ask\"/>";    
    echo "</form>";
	echo "<br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
//////////////////////////////////AskME By CJ Uday :)
else if($action=="list")
{
	$whonick = $_GET["whonick"];
	$whnick = getnick_uid($who);
    addonline(getuid_sid($sid),"Viewing $whinck's AskME","ask.php?action=$action");
echo "<head>";
echo "<title>View $whnick's AskME</title>";
 echo "</head>"; 
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");  
         echo "</div>";
    echo "<div class=\"header\" align=\"center\">";
	echo "<b>AskME</b></div>";
	echo "<div class=\"shout2\" align=\"left\">";
    $uid = getuid_sid($sid);
   if($page=="" || $page<=0)$page=1;
    $noi = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM uday_ask WHERE aown='".$who."'"));
    $num_items = $noi[0];
    $items_per_page= 5;
    $num_pages = ceil($num_items/$items_per_page);
    if(($page>$num_pages)&&$page!=1)$page= $num_pages;
    $limit_start = ($page-1)*$items_per_page;
        $sql = "SELECT aown, asign, ques, ans, hide, id FROM uday_ask WHERE aown='".$who."' ORDER BY time DESC LIMIT $limit_start, $items_per_page";
    $items = mysql_query($sql);
    while ($item = mysql_fetch_array($items))
    {
	    $sql2 = "SELECT name FROM ibwff_users WHERE id=$item[1]";
	    $sql22 = mysql_query($sql2);
	    $item2 = mysql_fetch_array($sql22);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item2[0]'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/>";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/>";}
if($sex[0]==""){$usersex = "";}
        if(isonline($item[1]))
  {
    $iml = "<img src=\"../avatars/onl.gif\" alt=\" \"/>";
  }else{
    $iml = "<img src=\"../avatars/ofl.gif\" alt=\"-\"/>";
  }
        		$avlink = getavatar($item[1]);
if($avlink=="")
{
 $avt =  "$usersex";
}else{
 $avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"icon\" width=\"23\" height=\"18\"/>";
}
    $snick = subnick(getnick_uid($item[1]));
	    $sql3 = "SELECT name FROM ibwff_users WHERE id=$item[1]";
	    $sql33 = mysql_query($sql3);
	    $item3 = mysql_fetch_array($sql33);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nicks = "<font color=\"blue\"><b>$snick</b></font>";}
if($sex[0]=="F"){$nicks = "<font color=\"deeppink\"><b>$snick</b></font>";}
if($sex[0]==""){$nicks = "";}
if($item[4]==0)
{
      $lnk = "<a href=\"profile.php?who=$item[1]\">$avt$nicks</a>";
	  }else{ 
$lnk = "Q";
}
}
      $bs = date("d m y-H:i:s",$item[3]);
     $text = parsepm($item[2], $sid);
if($item[3]=='')
{
if($uid==$who)
{
$ans = "[<a href=\"ask.php?action=ans&aid=$item[5]\">Answer</a>]<br/>";
}else{
$ans = "This question is not answered yet.<br/>";
}
}else{
$ans = parsepm($item[3]);
}
if(ismod(getuid_sid($sid)))
{
$f = " [<a href=\"delete.php?action=ask&aid=$item[5]\">x</a>]";
}else{
$f = "";
}
      echo "$lnk:$text$f<br/>A: $ans<br/>$bs<br/>";
    }
    }
    if($page>1)
    {
      $ppage = $page-1;
      echo "<a href=\"ask.php?action=$action&amp;page=$ppage&who=$who\">&#171;-Prev</a> ";
    }
    if($page<$num_pages)
    {
      $npage = $page+1;
      echo "<a href=\"ask.php?action=$action&amp;page=$npage&who=$who\">Next-&#187;</a>";
    }
    echo "<br/>Page - $page/$num_pages<br/>";
  if($num_pages>2)
    {
			        $rets = "<form action=\"ask.php\" method=\"get\">";
        $rets .= "<input name=\"page\" style=\"-wap-input-format: '*N'\" size=\"2\"/>";
        $rets .= "<input type=\"hidden\" name=\"action\" value=\"$action\"/>";
        $rets .= "<input type=\"hidden\" name=\"sid\" value=\"$sid\"/>";
		$rets .= "<input type=\"hidden\" name=\"who\" value=\"$who\"/>";
   $rets .= "<input type=\"submit\" value=\"Go To Page\"/>";
        $rets .= "</form>";
        echo $rets;
    }
    echo "</p>";
   echo "<a href=\"ask.php?action=ask&who=$who\">AskME</a><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="ans")
{
addonline(getuid_sid($sid),"Answering AskME","profile.php?action=$action");
	    echo "<head>";
    echo "<title>Answer AskME</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
			echo "<b>Answer AskME</b></div>";
  echo "<div class=\"shout2\" align=\"left\">";
$a = $_GET["aid"];
$p = mysql_fetch_array(mysql_query("SELECT ques FROM uday_ask WHERE id='".$a."'"));
echo "Q: ".parsepm($p[0])."<br/>";
 echo "<onevent type=\"onenterforward\">";
  echo "<refresh>
        <setvar name=\"msgtxt\" value=\"\"/>
   ";
  echo "</refresh></onevent>"; 
echo "<form action=\"askproc.php?action=ans&aid=$a\" method=\"post\">";
    echo "Answer:<br/><input name=\"msgtxt\" maxlength=\"500\"/>";
echo "<input type=\"hidden\" name=\"who\" value=\"$who\"/>";
 echo "<input type=\"submit\" value=\"Answer\"/>";    
    echo "</form>";
	echo "<br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
?>