<?php 
$item = mysql_fetch_array(mysql_query("SELECT
            a.name, b.id, b.byuid FROM ibwff_users a
            INNER JOIN ibwff_private b ON a.id = b.byuid
            WHERE b.touid='".$uid."' AND b.unread='1'
            ORDER BY b.timesent DESC
            LIMIT 1"));
{	
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item[0]'"));



if($sex[0]=="M"){$usersex = "<img src=\"../images/male.gif\" alt=\"[M]\"/>";}



if($sex[0]=="F"){$usersex = "<img src=\"../images/female.gif\" alt=\"[F]\"/>";}



if($sex[0]==""){$usersex = "";}
{
/////////////////Avatr By Admin
        		$avlink = getavatar($item[2]);

if($avlink=="")

{
 $avt =  "$usersex";
}else{
 $avt = "<img src=\"../avatars/$avlink\" height=\"28\" width=\"25\" alt=\"0\"/>";
}
////////////////////////By Admin
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item[0]'"));



if($sex[0]=="M"){$nicks = "<font color=\"blue\"><b>$item[0]</b></font>";}



if($sex[0]=="F"){$nicks = "<font color=\"deeppink\"><b>$item[0]</b></font>";}



if($sex[0]==""){$nicks = "";}

  $messages1 = getunreadpm(getuid_sid($sid));
  if($messages1>0)
  {
  echo "</div>";
echo "<p align=\"center\">";
echo "<b>(Last Message From: <a href=\"inbox.php?action=readpm&pmid=$item[1]\">$avt$nicks</a>)</b>";
echo "</p>";
echo "<div class=\"shout2\" align=\"left\">";
  }
  }
  }
?>