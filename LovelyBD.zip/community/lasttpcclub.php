<?php
$lpt = mysql_fetch_array(mysql_query("SELECT id FROM ibwff_forums WHERE clubid='".$clid."'"));
$lpt = mysql_fetch_array(mysql_query("SELECT id, name, authorid FROM ibwff_topics WHERE fid='".$fid[0]."' ORDER BY crdate DESC LIMIT 0,1"));
$tluid = $lpt[2];
$pinfo[0] = $lpt[2];
 $tlnm = htmlspecialchars($lpt[1]);
 $tlnick = subnick(getnick_uid($tluid));
$format_link = ucwords(strtolower($tlnm));
$tpclnk = "<a href=\"forums.php?tid=$lpt[0]go=last\">$format_link</a>";
	    $sql = "SELECT name FROM ibwff_users WHERE id=$pinfo[0]";
	    $sql2 = mysql_query($sql);
	    $item = mysql_fetch_array($sql2);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item[0]'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/>";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/>";}
$sql2 = "SELECT name FROM ibwff_users WHERE id=$pinfo[0]";
	    $sql22 = mysql_query($sql2);
	    $item2 = mysql_fetch_array($sql22);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item2[0]'"));
if($sex[0]=="M"){$usersex2 = "<font color=\"blue\"><b>$tlnick</b></font>";}
if($sex[0]=="F"){$usersex2 = "<font color=\"deeppink\"><b>$tlnick</b></font>";}
if($sex[0]==""){$usersex2 = "$tlnick";}
	$avlink = getavatar($pinfo[0]);
if($avlink=="")
{
 $avt =  "$usersex";
}else{
 $avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"icon\" width=\"23\" height=\"18\"/>";
}
echo " $tpclnk ";
echo " <b>By</b> <a href=\"profile.php?who=$tluid\">$avt$usersex2</a><br/>";
}
}
?>