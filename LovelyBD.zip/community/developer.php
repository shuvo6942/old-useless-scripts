<?php
session_start();
include("config.php");
include("core.php");
connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo "<head>";
echo "<title>Developer's Details</title>";
echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"".bosshira_themes()."\">";
echo "<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG : Don't Try To Hack OR else :P\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/>";
echo "</head>";
echo "<body>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"FireBD.png\" type=\"logo\" height=\"100\" width=\"190\" alt=\"$sitename\">";
echo "<br/><b>Developer's Details</b>";
echo "</div>";
echo "<div class=\"shout2\" align=\"left\">";
echo "<p align=\"center\">";
echo "<b>Developer's Text:</b> Contact me anytime if you need your own site. I'm always ready!<br/><br/>";
echo "</p>";
echo "<b>Developer's Name:</b>m3ghdut<br/>";
echo "<b>Address:</b> Dhaka, Bangladesh<br>";
echo "<b>Contact Number:</b> 01687078024<br/>";
echo "<b>Facebook:</b> <a href=\"http://www.facebook.com/shah0s\">CJ UdaY</a><br/>";
echo "<b>E-mail:</b> m3ghdut@gmail.com<br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"> <a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
exit();
?>
</html>