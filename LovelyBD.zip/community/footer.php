<?php
$sitename = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='sitename'"));
$sitename = $sitename[0];
echo "<img src=\"favicon.ico\" type=\"icon\" alt=\"[+]\" width=\"15\" height=\"15\"><normal><a href=\"main.php\"><font color=\"white\"><b>$sitename</b></font></a>";
//$end = microtime(true);
//$time = number_format(($end - $start), 2);  
//echo " (".$time."s)</normal>";
echo "<b>(Classic | <a href=\"../mobile/main.php\"></b><font color=\"white\">Mobile</font></a>)";
///echo "<br/><b><a href=\"site.php\">[Get Your Own Community Site]</a></b>";
?>