<?php
session_start();
include("config.php");
include("core.php");  connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo '<head>';
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"title\" content=\"FireBD.NeT\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From Megh: Don't Try To Hack OR else :P\">
<meta name=\"keywords\" content=\"Site Desined By Megh :) :)\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/></head>";
echo "<body>";
$action = $_GET["action"]; $sid = $_SESSION["sid"];
$page = $_GET["page"];
$who = $_GET["who"];
$uid = getuid_sid($sid);
$name = $_GET["name"];
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();
////////////////Ip Banned By CJ UDAY :)	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
    echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
	echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
      echo "<br/>";
      echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
      $banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
      $remain =  $banto[0] - time();
      $rmsg = gettimemsg($remain);
      echo "<b>Time Remaining: $rmsg</b><br/>";
      $nick = getnick_uid($banto[2]);
       $text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
      echo "</p>";
    	echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
    echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
    echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
//////////////////Banned System Updated By CJ UDAY :)
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please With Contact Us <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
 echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
///////////////////Validation By CJ UDAY :)
					if(isvalidated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
	echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  You Are Not Validated!<br/>We are checking your ip and browser<br/>
	  This could take up to 15 munites pls be patient and try again soon<br/>Please try again later...<br/><b>Thank You</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }

///////////////////Deactivated Account By CJ UDAY :)
          if(isdeactivated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  <b>Your Account Has Been Deactivated Forever.<br/>And It Will Be Never Activate!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
if($_REQUEST['who'] =='1')
{
echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  echo "<b>Unknown Error!!!</b><br/>Unknown Security By CJ UDAY :)<br/><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
else if($_REQUEST['who'] =='2')
{
echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  echo "<b>Unknown Error!!!</b><br/>Unknown Security By Megh :)<br/><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
else if($_REQUEST['who'] =='3')
{
echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  echo "<b>Unknown Error!!!</b><br/>Unknown Security By Megh :)<br/><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
else if($_REQUEST['who'] =='4')
{
echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  echo "<b>Unknown Error!!!</b><br/>Unknown Security By Megh :)<br/><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
else if($action=="ban")
{
  $who = $_GET["who"];
echo "<head>";
    echo "<title>BANNED!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Ban!!!</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
  echo "<form action=\"banproc.php?action=udayban&who=$who\" method=\"post\">"; 
  echo "Reason: <br/><input name=\"pres\" maxlength=\"100\"/><br/>";
  echo "Days: <br/><input name=\"pds\" format=\"*N\" maxlength=\"4\"/><br/>";
  echo "Hours: <br/><input name=\"phr\" format=\"*N\" maxlength=\"4\"/><br/>";
  echo "Minutes: <br/><input name=\"pmn\" format=\"*N\" maxlength=\"2\"/><br/>";
  echo "Seconds: <br/><input name=\"psc\" format=\"*N\" maxlength=\"2\"/><br/>";
  echo "<input type=\"submit\" value=\"Ban\"/></form>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
else if($action=="ipban")
{
    $who = $_GET["who"];
echo "<head>";
    echo "<title>IP BAN!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<b>IP Ban!!!</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
    $unick = getnick_uid($who);
    echo "Reason:<form action=\"banproc.php?action=udayip&who=$who\" method=\"post\"> <input name=\"pres\" maxlength=\"100\"/><br/>";
    echo "Days: <br/><input name=\"pds\" format=\"*N\" maxlength=\"4\"/><br/>";
    echo "Hours: <br/><input name=\"phr\" format=\"*N\" maxlength=\"4\"/><br/>";
    echo "Minutes: <br/><input name=\"pmn\" format=\"*N\" maxlength=\"2\"/><br/>";
    echo "Seconds: <br/><input name=\"psc\" format=\"*N\" maxlength=\"2\"/><br/>";
    echo "<input type=\"submit\" value=\"IP Ban\"/></form>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
else if($action=="udayban")
{
  $who = $_REQUEST["who"];
  $pres = $_POST["pres"];
  $pds = $_POST["pds"];
  $phr = $_POST["phr"];
  $pmn = $_POST["pmn"];
  $psc = $_POST["psc"];
  $user = getnick_uid($who);
echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>BANNED!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $uid = getuid_sid($sid);
  $cyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE id='".$uid."'"));
  $trgtcyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE name='".$user."'"));

  if($trgtcyberpowereragon>$cyberpowereragon){ 
  echo "<b><img src=\"../avatars/notok.gif\" alt=\"x\"/><br/>Error!!!!!<br/>cyberpowereragonission Denied...</b><br/>";
  echo "<br/>U Cannot Ban $user<br/>";
  }else{
  echo "<br/>";
  if(trim($pres)=="")
  {
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>You must Specify a reason for punishing the user";
  }else{
  $timeto = $pds*24*60*60;
  $timeto += $phr*60*60;
  $timeto += $pmn*60;
  $timeto += $psc;
  $ptime = $timeto + time();
  $res = mysql_query("INSERT INTO ibwff_penalties SET uid='".$who."', penalty='1', exid='".getuid_sid($sid)."', timeto='".$ptime."', pnreas='".mysql_escape_string($pres)."', ipadd='', browserm=''");
  if($res)
  {
  $pmsg[1]="Banned";
  mysql_query("UPDATE ibwff_users SET lastbannedreason='".$pmsg[1].": ".mysql_escape_string($pres)."' WHERE id='".$who."'");
  mysql_query("INSERT INTO ibwff_mlog SET action='Banned', details='<b>".getnick_uid(getuid_sid($sid))."</b> Banned The user <b>".$user."</b> For ".gettimemsg($timeto)."', actdt='".time()."'");
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>$user banned Successfully!";
	$tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
        $user = getnick_uid($who);
 mysql_query("INSERT INTO ibwff_notifications SET text='You are now Banned By [b]Staff Team[/b]', touid='".$who."', timesent='".$tm."'");
  mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] is now Banned By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Error banning $user";
  }
  }
  }
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
else if($action=="udayip")
{
  $who = $_REQUEST["who"];
  $pres = $_POST["pres"];
  $pds = $_POST["pds"];
  $phr = $_POST["phr"];
  $pmn = $_POST["pmn"];
  $psc = $_POST["psc"];
  $user = getnick_uid($who);
echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>IP BANNED!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $uid = getuid_sid($sid);
  $cyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE id='".$uid."'"));
  $trgtcyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE name='".$user."'"));

  if($trgtcyberpowereragon>$cyberpowereragon){ 
  echo "<b><img src=\"../avatars/notok.gif\" alt=\"x\"/><br/>Error!!!!!<br/>cyberpowereragonission Denied...</b><br/>";
  echo "<br/>U Cannot IP Ban $user<br/>";
  }else{
  echo "<br/>";
  if(trim($pres)=="")
  {
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>You must Specify a reason for punishing the user";
  }else{
  $timeto = $pds*24*60*60;
  $timeto += $phr*60*60;
  $timeto += $pmn*60;
  $timeto += $psc;
  $ptime = $timeto + time();
  $res = mysql_query("INSERT INTO ibwff_penalties SET uid='".$who."', penalty='2', exid='".getuid_sid($sid)."', timeto='".$ptime."', pnreas='".mysql_escape_string($pres)."', ipadd='', browserm=''");
  if($res)
  {
  $pmsg[1]="IP Banned";
  mysql_query("UPDATE ibwff_users SET lastbannedreason='".$pmsg[1].": ".mysql_escape_string($pres)."' WHERE id='".$who."'");
  mysql_query("INSERT INTO ibwff_mlog SET action='IP Banned', details='<b>".getnick_uid(getuid_sid($sid))."</b> IP Banned The user <b>".$user."</b> For ".gettimemsg($timeto)."', actdt='".time()."'");
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>$user IP banned Successfully!";
	$tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
        $user = getnick_uid($who);
 mysql_query("INSERT INTO ibwff_notifications SET text='You are now IP Banned By [b]Staff Team[/b]', touid='".$who."', timesent='".$tm."'");
  mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] is now Ip Banned By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Error banning $user";
  }
  }
  }
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
else if($action=="unbn")
  {
$who = $_GET["who"];
addonline(getuid_sid($sid),"Unbanning User","main.php?action=$action");
	echo "<head>";
    echo "<title>Unban User</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Unban User</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$lname = getnick_uid($bid);
$uday = mysql_query("DELETE FROM ibwff_penalties WHERE (penalty='1' OR penalty='2') AND uid='".$who."'");
if($uday)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> <b>$lname</b> unbanned successfully!<br/>";
$validater = getnick_sid($sid);
$action = 'Unshield';
$msg = "[b]".$lname."[/b] is unbanned by [b]".$validater."[/b]";
adminnot($msg);
mlog($action, $msg);
$p = "You are now unbanned by [b]".$validater."[/b]";
notify($po, $who);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> <b>$lname</b> cannot be unbanned at this moment!<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="pmban")
  {
$who = $_GET["who"];
addonline(getuid_sid($sid),"Pm banning User","main.php?action=$action");
	echo "<head>";
    echo "<title>Pm ban User</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Pm ban User</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$lname = getnick_uid($who);
$uday = mysql_query("UPDATE ibwff_users SET pmban='1' WHERE id='".$who."'");
if($uday)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> <b>$lname</b> pm banned successfully!<br/>";
$validater = getnick_sid($sid);
$action = 'PM Ban';
$msg = "[b]".$lname."[/b] is pm banned by [b]".$validater."[/b]";
adminnot($msg);
mlog($action, $msg);
$p = "You are now pm banned by [b]".$validater."[/b]";
notify($po, $who);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> <b>$lname</b> cannot be pm banned at this moment!<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="pmunban")
  {
$who = $_GET["who"];
addonline(getuid_sid($sid),"Pm unbanning User","main.php?action=$action");
	echo "<head>";
    echo "<title>Pm unban User</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Pm unban User</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$lname = getnick_uid($who);
$uday = mysql_query("UPDATE ibwff_users SET pmban='0' WHERE id='".$who."'");
if($uday)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> <b>$lname</b> pm unbanned successfully!<br/>";
$validater = getnick_sid($sid);
$action = 'PM Unban';
$msg = "[b]".$lname."[/b] is pm unbanned by [b]".$validater."[/b]";
adminnot($msg);
mlog($action, $msg);
$p = "You are now pm banned by [b]".$validater."[/b]";
notify($po, $who);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> <b>$lname</b> cannot be pm unbanned at this moment!<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="forumban")
  {
$who = $_GET["who"];
addonline(getuid_sid($sid),"Forum banning User","main.php?action=$action");
	echo "<head>";
    echo "<title>Forum ban User</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Forum ban User</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$lname = getnick_uid($who);
$uday = mysql_query("UPDATE ibwff_users SET forumban='1' WHERE id='".$who."'");
if($uday)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> <b>$lname</b> forum banned successfully!<br/>";
$validater = getnick_sid($sid);
$action = 'Forum Ban';
$msg = "[b]".$lname."[/b] is forum banned by [b]".$validater."[/b]";
adminnot($msg);
mlog($action, $msg);
$p = "You are now forum banned by [b]".$validater."[/b]";
notify($po, $who);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> <b>$lname</b> cannot be forum banned at this moment!<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="forumunban")
  {
$who = $_GET["who"];
addonline(getuid_sid($sid),"Forum unbanning User","main.php?action=$action");
	echo "<head>";
    echo "<title>Forum unban User</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Forum unban User</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$lname = getnick_uid($who);
$uday = mysql_query("UPDATE ibwff_users SET forumban='0' WHERE id='".$who."'");
if($uday)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> <b>$lname</b> forum unbanned successfully!<br/>";
$validater = getnick_sid($sid);
$action = 'Forum Unban';
$msg = "[b]".$lname."[/b] is forum unbanned by [b]".$validater."[/b]";
adminnot($msg);
mlog($action, $msg);
$p = "You are now forum unbanned by [b]".$validater."[/b]";
notify($po, $who);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> <b>$lname</b> cannot be forum unbanned at this moment!<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="postban")
  {
$who = $_GET["who"];
addonline(getuid_sid($sid),"Forum banning User","main.php?action=$action");
	echo "<head>";
    echo "<title>Post ban User</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Post ban User</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$lname = getnick_uid($who);
$uday = mysql_query("UPDATE ibwff_users SET postban='1' WHERE id='".$who."'");
if($uday)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> <b>$lname</b> post banned successfully!<br/>";
$validater = getnick_sid($sid);
$action = 'Post Ban';
$msg = "[b]".$lname."[/b] is post banned by [b]".$validater."[/b]";
adminnot($msg);
mlog($action, $msg);
$p = "You are now post banned by [b]".$validater."[/b]";
notify($po, $who);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> <b>$lname</b> cannot be post banned at this moment!<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="postunban")
  {
$who = $_GET["who"];
addonline(getuid_sid($sid),"Post unbanning User","main.php?action=$action");
	echo "<head>";
    echo "<title>Post unban User</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Post unban User</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$lname = getnick_uid($who);
$uday = mysql_query("UPDATE ibwff_users SET postban='0' WHERE id='".$who."'");
if($uday)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> <b>$lname</b> post unbanned successfully!<br/>";
$validater = getnick_sid($sid);
$action = 'Post Unban';
$msg = "[b]".$lname."[/b] is post unbanned by [b]".$validater."[/b]";
adminnot($msg);
mlog($action, $msg);
$p = "You are now post unbanned by [b]".$validater."[/b]";
notify($po, $who);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> <b>$lname</b> cannot be post unbanned at this moment!<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="chatban")
  {
$who = $_GET["who"];
addonline(getuid_sid($sid),"Chat banning User","main.php?action=$action");
	echo "<head>";
    echo "<title>Chat ban User</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Chat ban User</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$lname = getnick_uid($who);
$uday = mysql_query("UPDATE ibwff_users SET chatban='1' WHERE id='".$who."'");
if($uday)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> <b>$lname</b> chat banned successfully!<br/>";
$validater = getnick_sid($sid);
$action = 'Chat Ban';
$msg = "[b]".$lname."[/b] is chat banned by [b]".$validater."[/b]";
adminnot($msg);
mlog($action, $msg);
$p = "You are now chat banned by [b]".$validater."[/b]";
notify($po, $who);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> <b>$lname</b> cannot be chat banned at this moment!<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="chatunban")
  {
$who = $_GET["who"];
addonline(getuid_sid($sid),"Chat unbanning User","main.php?action=$action");
	echo "<head>";
    echo "<title>Chat unban User</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>chat unban User</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$lname = getnick_uid($who);
$uday = mysql_query("UPDATE ibwff_users SET chatban='0' WHERE id='".$who."'");
if($uday)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> <b>$lname</b> chat unbanned successfully!<br/>";
$validater = getnick_sid($sid);
$action = 'Post Unban';
$msg = "[b]".$lname."[/b] is chat unbanned by [b]".$validater."[/b]";
adminnot($msg);
mlog($action, $msg);
$p = "You are now chat unbanned by [b]".$validater."[/b]";
notify($po, $who);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> <b>$lname</b> cannot be chat unbanned at this moment!<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="pollban")
  {
$who = $_GET["who"];
addonline(getuid_sid($sid),"Poll banning User","main.php?action=$action");
	echo "<head>";
    echo "<title>Poll ban User</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Poll ban User</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$lname = getnick_uid($who);
$uday = mysql_query("UPDATE ibwff_users SET pollban='1' WHERE id='".$who."'");;
if($uday)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> <b>$lname</b> poll banned successfully!<br/>";
$validater = getnick_sid($sid);
$action = 'Poll Ban';
$msg = "[b]".$lname."[/b] is poll banned by [b]".$validater."[/b]";
adminnot($msg);
mlog($action, $msg);
$p = "You are now poll banned by [b]".$validater."[/b]";
notify($po, $who);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> <b>$lname</b> cannot be chat banned at this moment!<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="pollunban")
  {
$who = $_GET["who"];
addonline(getuid_sid($sid),"Poll unbanning User","main.php?action=$action");
	echo "<head>";
    echo "<title>Poll unban User</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Poll unban User</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$lname = getnick_uid($who);
$uday = mysql_query("UPDATE ibwff_users SET pollban='0' WHERE id='".$who."'");
if($uday)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> <b>$lname</b> poll unbanned successfully!<br/>";
$validater = getnick_sid($sid);
$action = 'Post Unban';
$msg = "[b]".$lname."[/b] is poll unbanned by [b]".$validater."[/b]";
adminnot($msg);
mlog($action, $msg);
$p = "You are now poll unbanned by [b]".$validater."[/b]";
notify($po, $who);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> <b>$lname</b> cannot be poll unbanned at this moment!<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="blogban")
  {
$who = $_GET["who"];
addonline(getuid_sid($sid),"Blog banning User","main.php?action=$action");
	echo "<head>";
    echo "<title>Blog ban User</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Blog ban User</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$lname = getnick_uid($who);
$uday = mysql_query("UPDATE ibwff_users SET blogban='1' WHERE id='".$who."'");
if($uday)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> <b>$lname</b> blog banned successfully!<br/>";
$validater = getnick_sid($sid);
$action = 'Blog Ban';
$msg = "[b]".$lname."[/b] is blog banned by [b]".$validater."[/b]";
adminnot($msg);
mlog($action, $msg);
$p = "You are now blog banned by [b]".$validater."[/b]";
notify($po, $who);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> <b>$lname</b> cannot be blog banned at this moment!<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="blogunban")
  {
$who = $_GET["who"];
addonline(getuid_sid($sid),"Blog unbanning User","main.php?action=$action");
	echo "<head>";
    echo "<title>Blog unban User</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Blog unban User</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$lname = getnick_uid($who);
$uday = mysql_query("UPDATE ibwff_users SET blogban='0' WHERE id='".$who."'");;
if($uday)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> <b>$lname</b> blog unbanned successfully!<br/>";
$validater = getnick_sid($sid);
$action = 'Post Unban';
$msg = "[b]".$lname."[/b] is blog unbanned by [b]".$validater."[/b]";
adminnot($msg);
mlog($action, $msg);
$p = "You are now blog unbanned by [b]".$validater."[/b]";
notify($po, $who);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> <b>$lname</b> cannot be blog unbanned at this moment!<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="blogcomban")
  {
$who = $_GET["who"];
addonline(getuid_sid($sid),"Blog comment banning User","main.php?action=$action");
	echo "<head>";
    echo "<title>Blog ban User</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Blog comment ban User</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$lname = getnick_uid($who);
$uday = mysql_query("UPDATE ibwff_users SET blogcomban='1' WHERE id='".$who."'");
if($uday)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> <b>$lname</b> blog comment banned successfully!<br/>";
$validater = getnick_sid($sid);
$action = 'Blog Comment Ban';
$msg = "[b]".$lname."[/b] is blog comment banned by [b]".$validater."[/b]";
adminnot($msg);
mlog($action, $msg);
$p = "You are now blog comment banned by [b]".$validater."[/b]";
notify($po, $who);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> <b>$lname</b> cannot be blog comment banned at this moment!<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="blogcomunban")
  {
$who = $_GET["who"];
addonline(getuid_sid($sid),"Blog comment unbanning User","main.php?action=$action");
	echo "<head>";
    echo "<title>Blog comment unban User</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Blog comment unban User</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$lname = getnick_uid($who);
$uday = mysql_query("UPDATE ibwff_users SET blogcomban='0' WHERE id='".$who."'");
if($uday)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> <b>$lname</b> blog comment unbanned successfully!<br/>";
$validater = getnick_sid($sid);
$action = 'Post Unban';
$msg = "[b]".$lname."[/b] is blog comment unbanned by [b]".$validater."[/b]";
adminnot($msg);
mlog($action, $msg);
$p = "You are now blog comment unbanned by [b]".$validater."[/b]";
notify($po, $who);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> <b>$lname</b> cannot be blog comment unbanned at this moment!<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="shoutban")
  {
$who = $_GET["who"];
addonline(getuid_sid($sid),"Shout banning User","main.php?action=$action");
	echo "<head>";
    echo "<title>Shout ban User</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Shout ban User</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$lname = getnick_uid($who);
$uday = mysql_query("UPDATE ibwff_users SET shoutban='1' WHERE id='".$who."'");
if($uday)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> <b>$lname</b> shout banned successfully!<br/>";
$validater = getnick_sid($sid);
$action = 'Shout Ban';
$msg = "[b]".$lname."[/b] is shout banned by [b]".$validater."[/b]";
adminnot($msg);
mlog($action, $msg);
$p = "You are now shout banned by [b]".$validater."[/b]";
notify($po, $who);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> <b>$lname</b> cannot be shout banned at this moment!<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="shoutunban")
  {
$who = $_GET["who"];
addonline(getuid_sid($sid),"Shout unbanning User","main.php?action=$action");
	echo "<head>";
    echo "<title>Shout unban User</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Shout unban User</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$lname = getnick_uid($who);
$uday = mysql_query("UPDATE ibwff_users SET shoutban='0' WHERE id='".$who."'");
if($uday)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> <b>$lname</b> shout unbanned successfully!<br/>";
$validater = getnick_sid($sid);
$action = 'Shout Unban';
$msg = "[b]".$lname."[/b] is shout unbanned by [b]".$validater."[/b]";
adminnot($msg);
mlog($action, $msg);
$p = "You are now shout unbanned by [b]".$validater."[/b]";
notify($po, $who);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> <b>$lname</b> cannot be shout unbanned at this moment!<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="letban")
  {
$who = $_GET["who"];
addonline(getuid_sid($sid),"Literature banning User","main.php?action=$action");
	echo "<head>";
    echo "<title>Literature ban User</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Literature ban User</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$lname = getnick_uid($who);
$uday = mysql_query("UPDATE ibwff_users SET letban='1' WHERE id='".$who."'");
if($uday)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> <b>$lname</b> literature banned successfully!<br/>";
$validater = getnick_sid($sid);
$action = 'Literature Ban';
$msg = "[b]".$lname."[/b] is literature banned by [b]".$validater."[/b]";
adminnot($msg);
mlog($action, $msg);
$p = "You are now literature banned by [b]".$validater."[/b]";
notify($po, $who);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> <b>$lname</b> cannot be literature banned at this moment!<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
?>
</html>