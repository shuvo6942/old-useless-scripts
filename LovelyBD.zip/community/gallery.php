<?php
session_start();
include("config.php");
include("core.php");  
connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo '<head>';
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"title\" content=\"FireBD.NeT\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From Shahos: Don't Try To Hack OR else :P\">
<meta name=\"keywords\" content=\"Site Desined By Shahos :) :)\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/></head>";
echo "<body>";
$action = $_GET["action"]; 
$sid = $_SESSION["sid"];
$clid = $_GET["clid"];
$page = $_GET["page"];
$who = $_GET["who"];
$whonick = getnick_uid($who);
$byuid = getuid_sid($sid);
$uid = getuid_sid($sid);
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();
////////////////Ip Banned By CJ UDAY :)	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
echo "<br/>";
echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
$banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
$remain =  $banto[0] - time();
$rmsg = gettimemsg($remain);
echo "<b>Time Remaining: $rmsg</b><br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "</p>";
echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
/////////////////Banned System Updated By CJ UDAY :)
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please Contact <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
  include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
  include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
///////////////////Deactivated Account By CJ UDAY :)
          if(isdeactivated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/><b>Your Account Has Been Deactivated Forever.<br/>And It Will Be Never Activate!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
///////////////////Validation By CJ UDAY :)
					if(isvalidated(getuid_sid($sid), $uid))
  {
echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>You Are Not Validated!<br/>We are checking your ip and browser<br/>This could take up to 15 munites pls be patient and try again soon<br/>Please try again later...<br/><b>Thank You</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
////////////////////////Gallery Updated By CJ UDAY :)
if($action=="")
{
  addonline(getuid_sid($sid),"Viewing Gallery","gallery.php?action=$action");
echo "<head>";
echo "<title>Gallery</title>";
  echo "</head>"; 
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
         echo "</div>";
      echo "<div class=\"header\" align=\"center\">";
	echo "<b>MyDhaka Gallery</b>";
		if($clid>0)
	{
	$clname = getclubname($clid);
	echo "<br/><b>$clname</b> Clubs Gallery";
	}
	echo "</div>";
    echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
if($clid>0)
	{
$males = mysql_fetch_array(mysql_query("SELECT COUNT(DISTINCT uid) FROM ibwff_gallery WHERE sex='M' AND clubid='".$clid."'"));
echo "<a href=\"gallery.php?action=male&clid=$clid\"><img src=\"../avatars/male.gif\" alt=\"*\"/><font color=\"blue\">$clname Male Gallery</font></a> [$males[0]]<br/>";
$females = mysql_fetch_array(mysql_query("SELECT COUNT(DISTINCT uid) FROM ibwff_gallery WHERE sex='F' AND clubid='".$clid."'"));
echo "<a href=\"gallery.php?action=female&clid=$clid\"><img src=\"../avatars/female.gif\" alt=\"*\"/><font color=\"deeppink\">$clname Female Gallery</font></a> [$females[0]]<br/>";
}else{
$males = mysql_fetch_array(mysql_query("SELECT COUNT(DISTINCT uid) FROM ibwff_gallery WHERE sex='M' AND clubid='0'"));
echo "<a href=\"gallery.php?action=male&clid=$clid\"><img src=\"../avatars/male.gif\" alt=\"*\"/><font color=\"blue\">Male Gallery</font></a> [$males[0]]<br/>";
$females = mysql_fetch_array(mysql_query("SELECT COUNT(DISTINCT uid) FROM ibwff_gallery WHERE sex='F' AND clubid='0'"));
echo "<a href=\"gallery.php?action=female&clid=$clid\"><img src=\"../avatars/female.gif\" alt=\"*\"/><font color=\"deeppink\">Female Gallery</font></a> [$females[0]]<br/>";
}
   if(!($dp = opendir("../gallery/"))) die ("Cannot open ./");
$files = array(); 
while ($pics = readdir ($dp))
	{
	if(substr($pics,0,1) != '.' and $pics!= "main.php")
	{
		$files[] =  $pics;
		}
	}
$file_count = count ($files);
sort ($files);
  echo "</small></p>";
  echo "<p align=\"center\"><small>";
  if ($clid>0)
  {
  $clanme = getclubname($clid);
echo "<b>>></b> <a href=\"upload.php?clid=$clid\">Upload Your Pictures in $clname club</a><b><<</b><br/>";
}else{
echo "<b>>></b> <a href=\"upload.php\">Upload Your Pictures</a> <b><<</b><br/>";
}
   echo "</small></p></div>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="male")
{
      addonline(getuid_sid($sid),"Viewing Male Gallery","gallery.php?action=$action");
echo "<head>";
echo "<title>View Male Gallery</title>";
echo "</head>"; 
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
      echo "<div class=\"header\" align=\"center\">";
	echo "<b>Male Gallery</b>";
			if($clid>0)
	{
	$clname = getclubname($clid);
	echo "<br/><b>$clname</b> Clubs Male Gallery</div>";
	}
    echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
    if($page=="" || $page<=0)$page=1;
if($clid>0)
	{
    if($who!="")
    {
    $noi = mysql_fetch_array(mysql_query("SELECT COUNT(DISTINCT uid) FROM ibwff_gallery WHERE sex='M' AND clibid='".$clid."'"));
    }else{
    $noi = mysql_fetch_array(mysql_query("SELECT COUNT(DISTINCT uid) FROM ibwff_gallery WHERE sex='M' AND clubid='".$clid."'"));
    }
	}else{
    if($who!="")
    {
    $noi = mysql_fetch_array(mysql_query("SELECT COUNT(DISTINCT uid) FROM ibwff_gallery WHERE sex='M'"));
    }else{
    $noi = mysql_fetch_array(mysql_query("SELECT COUNT(DISTINCT uid) FROM ibwff_gallery WHERE sex='M'"));
    }
	}
    $num_items = $noi[0];
    $items_per_page= 7;
    $num_pages = ceil($num_items/$items_per_page);
    if(($page>$num_pages)&&$page!=1)$page= $num_pages;
    $limit_start = ($page-1)*$items_per_page;
$sql = "SELECT DISTINCT uid FROM ibwff_gallery WHERE sex='M' AND clubid='".$clid."' ORDER BY uid ASC LIMIT $limit_start, $items_per_page";
    $items = mysql_query($sql);
if(mysql_num_rows($items)>0)
    {
    while ($item = mysql_fetch_array($items))
    {
	    $sql2 = "SELECT name FROM ibwff_users WHERE id=$item[0]";
	    $sql22 = mysql_query($sql2);
	    $item2 = mysql_fetch_array($sql22);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item2[0]'"));
if($sex[0]=="M"){$usericon = "<img src=\"../avatars/male.gif\" alt=\"M\"/>";}
if($sex[0]=="F"){$usericon = "<img src=\"../avatars/female.gif\" alt=\"F\"/>o";}
if($sex[0]==""){$usericon = "";}
       		$avlink = getavatar($item[0]);
if($avlink=="")
{
 $avt =  "$usericon";
}else{
 $avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"icon\" width=\"23\" height=\"18\"/>";
}
$who = $item[0];
$user=getnick_uid($who);
        $countpics = mysql_fetch_array(mysql_query("SELECT COUNT(id) FROM ibwff_gallery WHERE uid='".$who."'"));
        $lnk = "$avt<a href=\"gallery.php?action=viewuser&clid=$clid&who=$who\"><font color=\"blue\">$user</font></a> [$countpics[0]]<br/>";
       echo "$lnk"; 
	 }
    }
    }else{
echo "<img src=\"../avatars/notok.gif\">Male Gallery Is Empty!";
}
    echo "</small></p>";
echo "<p align=\"center\"><small>";
    if($page>1)
    {
      $ppage = $page-1;
      echo "<a href=\"gallery.php?action=$action&page=$ppage&clid=$clid\">&#171;-Prev</a> ";
    }
    if($page<$num_pages)
    {
      $npage = $page+1;
      echo "<a href=\"gallery.php?action=$action&page=$npage&clid=$clid\">Next-&#187;</a>";
    }
    echo "<br/>Page - $page/$num_pages<br/>";
    if($num_pages>2)
    {
			        $rets = "<form action=\"gallery.php\" method=\"get\">";
        $rets .= "<input name=\"page\" style=\"-wap-input-format: '*N'\" size=\"2\"/>";
        $rets .= "<input type=\"hidden\" name=\"action\" value=\"$action\"/>";
        $rets .= "<input type=\"hidden\" name=\"sid\" value=\"$sid\"/>";
        $rets .= "<input type=\"submit\" value=\"Go To Page\"/>";
        $rets .= "</form>";
        echo $rets;
    }
   echo "</small></p></div>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="female")
{
     addonline(getuid_sid($sid),"Viewing Female Gallery","gallery.php?action=$action");
echo "<head>";
echo "<title>View Female Gallery</title>";
echo "</head>"; 
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
      echo "<div class=\"header\" align=\"center\">";
	echo "<b>Female Gallery</b>";
				if($clid>0)
	{
	$clname = getclubname($clid);
	echo "<br/><b>$clname</b> Clubs Female Gallery</div>";
	}
    echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
    if($page=="" || $page<=0)$page=1;
	if($clid>0)
	{
    if($who!="")
    {
    $noi = mysql_fetch_array(mysql_query("SELECT COUNT(DISTINCT uid) FROM ibwff_gallery WHERE sex='F' AND clubid='".$clid."'"));
    }else{
    $noi = mysql_fetch_array(mysql_query("SELECT COUNT(DISTINCT uid) FROM ibwff_gallery WHERE sex='F' AND clubid='".$clid."'"));
    }
	}else{
    if($who!="")
    {
    $noi = mysql_fetch_array(mysql_query("SELECT COUNT(DISTINCT uid) FROM ibwff_gallery WHERE sex='F'"));
    }else{
    $noi = mysql_fetch_array(mysql_query("SELECT COUNT(DISTINCT uid) FROM ibwff_gallery WHERE sex='F'"));
    }
	}
    $num_items = $noi[0];
    $items_per_page= 5;
    $num_pages = ceil($num_items/$items_per_page);
    if(($page>$num_pages)&&$page!=1)$page= $num_pages;
    $limit_start = ($page-1)*$items_per_page;
if($clid>0)
	{
$sql = "SELECT DISTINCT uid FROM ibwff_gallery WHERE sex='F' AND clubid='".$clid."' ORDER BY uid ASC LIMIT $limit_start, $items_per_page";
}else{
$sql = "SELECT DISTINCT uid FROM ibwff_gallery WHERE sex='F' ORDER BY uid ASC LIMIT $limit_start, $items_per_page";
}
    $items = mysql_query($sql);
    if(mysql_num_rows($items)>0)
    {
    while ($item = mysql_fetch_array($items))
    {
	    $sql2 = "SELECT name FROM ibwff_users WHERE id=$item[0]";
	    $sql22 = mysql_query($sql2);
	    $item2 = mysql_fetch_array($sql22);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item2[0]'"));
if($sex[0]=="M"){$usericon = "<img src=\"../avatars/male.gif\" alt=\"M\"/>";}
if($sex[0]=="F"){$usericon = "<img src=\"../avatars/female.gif\" alt=\"F\"/>";}
if($sex[0]==""){$usericon = "";}
        		$avlink = getavatar($item[0]);
if($avlink=="")
{
 $avt =  "$usericon";
}else{
 $avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"icon\" width=\"23\" height=\"18\"/>";
}
$who = $item[0];
$user=getnick_uid($who);
$countpics = mysql_fetch_array(mysql_query("SELECT COUNT(id) FROM ibwff_gallery WHERE uid='".$who."'"));
        $lnk = "$avt<a href=\"gallery.php?action=viewuser&clid=$clid&who=$who\"><font color=\"deeppink\">$user</a></font> [$countpics[0]]<br/>";  
echo "$lnk";
    }
    }
    }else{
echo "<img src=\"../avatars/notok.gif\">Female Gallery Is Empty!";
}
    echo "</small></p>";
echo "<p align=\"center\"><small>";
    if($page>1)
    {
      $ppage = $page-1;
      echo "<a href=\"gallery.php?action=$action&page=$ppage&clid=$clid\">&#171;-Prev</a> ";
    }
    if($page<$num_pages)
    {
      $npage = $page+1;
      echo "<a href=\"gallery.php?action=$action&page=$npage&clid=$clid\">Next-&#187;</a>";
    }
    echo "<br/>Page - $page/$num_pages<br/>";
    if($num_pages>2)
    {
			        $rets = "<form action=\"gallery.php\" method=\"get\">";
        $rets .= "<input name=\"page\" style=\"-wap-input-format: '*N'\" size=\"2\"/>";
        $rets .= "<input type=\"hidden\" name=\"action\" value=\"$action\"/>";
        $rets .= "<input type=\"hidden\" name=\"sid\" value=\"$sid\"/>";
        $rets .= "<input type=\"submit\" value=\"Go To Page\"/>";
        $rets .= "</form>";
        echo $rets;
    }
   echo "</small></p></div>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="viewuser")
{
      $who = $_GET["who"];
    addonline(getuid_sid($sid),"Viewing A Users Photos","gallery.php?action=$action");
echo "<head>";
echo "<title>Viewing A User Photo</title>";
 echo "</head>"; 
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
      echo "<div class=\"header\" align=\"center\">";
	echo "<b>FireBD Gallery</b></div>";
    echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
    if($page=="" || $page<=0)$page=1;
    if($who!="")
    {
    $noi = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_gallery WHERE uid='".$who."'"));
    }else{
    $noi = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_gallery"));
    }
    $num_items = $noi[0];
    $items_per_page= 5;
    $num_pages = ceil($num_items/$items_per_page);
    if(($page>$num_pages)&&$page!=1)$page= $num_pages;
    $limit_start = ($page-1)*$items_per_page;
    if($who!="")
    {
        $sql = "SELECT id, sex, itemurl FROM ibwff_gallery WHERE uid='".$who."' ORDER BY id DESC LIMIT $limit_start, $items_per_page";
        }else{
$sql = "SELECT id, sex, itemurl, uid FROM ibwff_gallery  ORDER BY id DESC LIMIT $limit_start, $items_per_page";
        }
$items = mysql_query($sql);
    if(mysql_num_rows($items)>0)
    {
    while ($item = mysql_fetch_array($items))
    {
      $id = $item[0];
    $img = $item[2];
$lnk = "<img src=\"$img\" alt=\"$id\" width=\"200\" height=\"250\"/><br/>";
$d = "ID : $id<br/>";
$gall = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_galcomments WHERE gid='".$id."'"));
$me = getuid_sid($sid);
     if(galleryboss($uid, $item[0]) || $me == $item[3])
      {
        $delnk = "<a href=\"galproc.php?action=delgal&clid=$clid&gid=$item[0]\">[Delete]</a>";
      }else{
        $delnk = "";
      }
      echo "$lnk$d<a href=\"$img\">Download Photo</a><br/>";
$like = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM uday_galpiclike12 WHERE gid='".$id."'"));
echo "<img src=\"like.png\" alt=\"*\"><a href=\"galproc.php?action=galphotolike&gid=$id\">Like</a>(<a href=\"galphotolike.php?action=main&who=$who&gid=$id\">$like[0]</a>)";
$dislike = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM uday_galpicdislike13 WHERE gid='".$id."'"));
echo "<img src=\"dislike.png\" alt=\"*\"><a href=\"galproc.php?action=galphotodislike&gid=$id\">Disike</a>(<a href=\"galphotodislike.php?action=main&who=$who&gid=$id\">$dislike[0]</a>)<br/>";
echo "<img src=\"comment.png\" alt=\"*\"><a href=\"galphoto.php?action=comments&who=$who&gid=$item[0]\">Comments($gall[0])</a><br/>";
if(ismod(getuid_sid($sid)))
{
echo "[<a href=\"galproc.php?action=delphoto&gid=$id\"><i>Delete This</i></a>]<br/>";
}
if(getuid_sid($sid) == $who)
{
echo "&#187; <a href=\"galproc.php?action=spp&id=$item[0]\">Set As Profile Picture</a><br/>&#187; <a href=\"galproc.php?action=scp&id=$item[0]\">Set As Cover Photo</a><br/>";
echo "&#187; <a href=\"galproc.php?action=delphoto&gid=$id\">Delete This Photo</a><br/><b>- - -</b><br/>";
}
}
}


    echo "</small></p>";
echo "<p align=\"center\"><small>";
    if($page>1)
    {
      $ppage = $page-1;
      echo "<a href=\"gallery.php?action=$action&page=$ppage&who=$uid\">&#171;-Prev</a> ";
    }
    if($page<$num_pages)
    {
      $npage = $page+1;
      echo "<a href=\"gallery.php?action=$action&page=$npage&who=$uid\">Next-&#187;</a>";
    }
    echo "<br/>Page - $page/$num_pages<br/>";
    if($num_pages>2)
    {
			        $rets = "<form action=\"gallery.php\" method=\"get\">";
        $rets .= "<input name=\"page\" style=\"-wap-input-format: '*N'\" size=\"2\"/>";
        $rets .= "<input type=\"hidden\" name=\"action\" value=\"$action\"/>";
        $rets .= "<input type=\"hidden\" name=\"sid\" value=\"$sid\"/>";
        $rets .= "<input type=\"submit\" value=\"Go To Page\"/>";
        $rets .= "</form>";
        echo $rets;
    }
if($uid == $who)
{
echo "<p align=\"left\">";
echo "[<a href=\"upavatar.php\">Upload Your Photo Here</a>]<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
?>
</html>