<?php
session_start();
include("config.php");
include("core.php");
connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo "<head>";
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"title\" content=\"FireBD.NeT\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From Shahos : Don't Try To Hack It. Is Protected By Shahos :P\">
<meta name=\"keywords\" content=\"Site Desined By Shahos\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/>";
echo "</head>";
echo "<body>";
$action = $_GET["action"]; $sid = $_SESSION["sid"];
$uid = getuid_sid($sid);
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();
////////////////Ip Banned By CJ UDAY :)	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../images/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
echo "<br/>";
echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
$banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
$remain =  $banto[0] - time();
$rmsg = gettimemsg($remain);
echo "<b>Time Remaining: $rmsg</b><br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "</p>";
echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../images/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../images/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");  
echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
//////////////////Banned System Updated By CJ UDAY :)
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../images/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please Contact <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
///////////////////Deactivated Account Created CJ UDAY :)
          if(isdeactivated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../images/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  <b>Your Account Has Been Deactivated Forever.<br/>And It Will Be Never Activate!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
////////////////////////////////////////S3CUR!TY CREADTED BY CJ UDAY :)
if($action=="")
{
addonline(getuid_sid($sid),"Security Option","usersecurity.php");
    echo "<head>";
    echo "<title>Security Option</title>";
   echo "</head>";
    echo "<body>";
echo "</div>";
  echo "<div class=\"header\" align=\"left\"><img src=\"FireBD.png\" alt=\"$sitename\" type=\"logo\" width=\"240\" height=\"50\"/><br/><b>Security settings</b></div>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
          
			echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "Please <b>secure</b> your MyDhaka account by following the steps below.<br/>";
echo "Otherwise, your account can be hacked and you may lose this account forever.<br/>";
  include ("user_sec.php"); 
echo "Your account security level <b>$src_complete%</b><br/>";
$info= mysql_fetch_array(mysql_query("SELECT location, email, phone FROM ibwff_users WHERE id='".$uid."'"));
if (empty($info[1]))
{
  echo "<b>&#8226;</b> <a href=\"setting.php?action=upf\">Please fill up your email.</a><br/>";
  $parcent = $src_complete+20;
  echo "(Your account security will be <b>$parcent</b> if you update your account.)<br/>";
  }else{
  echo "<b>&#8226; </b><font color=\"green\">Your email was Updated!</font><br/>";
  echo "your security was updated more <b>20%</b> by fill your email.<br/>";
  }
  if (empty($info[2]))
  if (empty($info[2]))
{
  echo "<b>&#8226;</b> <a href=\"setting.php?action=upf\">Please fill up your Phone Number.</a><br/>";
  $parcent = $src_complete+20;
  echo "(Your account security will be <b>$parcent</b> if you update your Phone Number.)<br/>";
  }else{
  echo "<b>&#8226; </b><font color=\"green\">Your Phone number was Updated!</font><br/>";
  echo "your security was updated more <b>20%</b> by fill your Phone number.<br/>";
  }
    $src_stat = mysql_fetch_array(mysql_query("SELECT status, browser, varcode FROM ibwff_usersecurity WHERE uid='".$uid."'"));
if ($src_stat[0]==0)
{   
   echo "<b>Security Status:</b> Your Account is <b>Unocked</b>!<br/>";
   }else{   
   echo "<b>Security Status:</b> Your Account is <b>Locked</b>!<br/>";
   }
   if ($src_stat[2]=="")
{ 
echo "<b>Security Code: <font color=\"red\">Not Set!</font></b><br/>";
}else{
echo "<b>Security Code: <font color=\"red\">$src_stat[2]</font></b><br/>";
}
  echo "<b>Security Level: </b><br/>";
  echo "&#8226; Email Update 20%.<br/>";
  echo "&#8226; Phone number Update 20%.<br/>";
  echo "&#8226; profile Update 20%.<br/>";
  echo "&#8226; lock account 20%.<br/>";
  echo "&#8226; Update security 20%.<br/>";   
	     $src_stat = mysql_fetch_array(mysql_query("SELECT status, browser, varcode FROM ibwff_usersecurity WHERE uid='".$uid."'"));
if ($src_stat[0]==0)
	{
   echo "<b>&#8226; </b><a href=\"usersecurity.php?action=settings\"><b>Click here to lock your account!</b></a><br/>";
	}
   else
	{
   echo "<b>&#8226; </b><a href=\"usersecurity.php?action=unlock\"><b>Click here to Unlock your account!</b></a><br/>";
	}
	echo "<b>1.Avoid Password leak:</b>(most important)<br/>";
	 echo "Do not share your password with others and dont use same password on any other site . 
	 do not login with your $shortsite account password to any other site listning from anyone.<br/>";
	 echo "Do not login to any site telling you to login with your FireBD password.<br/>";
	 echo "Do not belive any scam/crap news.It will only make you fool.<br/>";
	 echo "Stay away from spam links/message/photos. Report any kind of spam links to staffs.<br/>";
	 echo "<b>2. Secure your password :</b><br/>";
	 echo "Please update your alternative email address & phone number with the correct details.<br/>";
	 echo "Your email address will be used if you forget your password or security code.<br/>";
	   echo "<b>&#8226;</b> <a href=\"setting.php?action=upf\"><b>Update Account Details</b></a><br/>";
	echo "<b>4.Lock your Account:</b><br/>";
	$browser= mysql_fetch_array(mysql_query("SELECT browserm FROM ibwff_users WHERE id='".$uid."'"));
	echo "Usually you login from <b>($browser[0])</b> If you login from another device, we will ask the security code 
	to confirm your login and to protect untrusted login.<br/>";
	echo "Your security code is also very sensitive information like password. So keep it as safe as password.
	Do not share it with others.<br/>";
	   echo "If you forget it, you can not login from another device without a password reset by email. (Like password recover method)<br/>";
   echo "&#187; <a href=\"usersecurity.php?action=settings\"><b>Get Your Security Code &amp; Lock Account!</b></a><br/>";
echo "<b>&#8226; 2 steps to safe your account:</b><br/>";
echo "1.Update Your account.<br/>";
echo "2.Lock Your account.<br/>";
echo "if you follow all steps your account will be <b>100%</b> protected.<br/>";
echo "Otherwise we can not help you if your account will hack due to your fault/carelessness.<br/>";
echo "</div>";
 	echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="settings")
{
addonline(getuid_sid($sid),"Security Option","usersecurity.php");
    echo "<head>";
    echo "<title>Security Option</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"header\" align=\"left\"><img src=\"FireBD.png\" alt=\"$sitename\" type=\"logo\" width=\"240\" height=\"50\"/><br/><b>Lock Account</b></div>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
  
  echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$count = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_usersecurity WHERE uid='".$uid."'"));
if ($count[0]==0)
{
	   $set_src = substr(md5(time()),0,5);
	   mysql_query("INSERT INTO ibwff_usersecurity SET varcode='".$set_src."' , uid='".$uid."', browser='".$ubr."', time='".time()."'");
echo "&#8226; Your security code successfully added.<br/>";
echo "&#8226; Your code is <b><font color=\"green\">$set_src</font></b> <br/>";
  }
  $src_stat = mysql_fetch_array(mysql_query("SELECT status, browser, varcode FROM ibwff_usersecurity WHERE uid='".$uid."'"));
if ($src_stat[0]==0)
{   
   echo "<b>Security Status:</b> Your Account is <b>Unocked</b>!<br/>";
   }else{   
   echo "<b>Security Status:</b> Your Account is <b>Locked</b>!<br/>";
   }
   echo "<b>Your security code is:</b> <b>$src_stat[2]</b><br/>";
   echo "<b>Your current Browser:</b> $ubr.<br/>";
   echo "<b>Your permanent Browser:</b> $src_stat[1].<br/>";
   echo "if you lock your account and you login from another
   device, we will ask the security code to confirm your login and to protect untrusted login.<br/>";
   echo "Your security code is also very sensitive information like password.so keep it as safe as password.
   Please Do not share it with otheres.<br/>";
   echo "If you forget it, you can not login from another device without a password reset by email.(Like password recover method)<br/>";
     $src_stat = mysql_fetch_array(mysql_query("SELECT status, browser, varcode FROM ibwff_usersecurity WHERE uid='".$uid."'"));
if ($src_stat[0]==0)
	{
   echo "<b>&#8226; </b><a href=\"usersecurity.php?action=lock\"><b>Click here to lock your account!</b></a><br/>";
	}else{
   echo "<b>&#8226; </b><a href=\"usersecurity.php?action=unlock\"><b>Click here to Unlock your account!</b></a><br/>";
  }
	 echo "<b>&#8226; <a href=\"usersecurity.php?action=updatecode\">Update Security Code</a></b><br/>";
	 echo "<b>&#8226; <a href=\"usersecurity.php\">Security settings</a></b><br/>";
 	echo "</div>";
 	echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
///////////////////////////Lock///////////////////////////////
else if($action=="lock")
{
addonline(getuid_sid($sid),"Security Option","usersecurity.php");
    echo "<head>";
    echo "<title>Security Option</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
  echo "<div class=\"header\" align=\"center\"><b>Lock Account</b></div>";
	echo"<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
$q = mysql_query("UPDATE ibwff_usersecurity SET status='1' WHERE uid='".$uid."'");
if($q)
{
echo "<br/><img src=\"../images/ok.gif\">You have Successfully locked Your account.<br/>";
}else{
echo "Unknown Error!!!";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
///////////////////////////UnLock///////////////////////////////
else if($action=="unlock")
{
addonline(getuid_sid($sid),"Security Option","usersecurity.php?action=main");
    echo "<head>";
    echo "<title>Security Option</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
  echo "</div>";
  echo "<div class=\"header\" align=\"center\"><b>Lock Account</b></div>";
	echo"<div class=\"shout2\" align=\"center\">";
$q = mysql_query("UPDATE ibwff_usersecurity SET status='0' WHERE uid='".$uid."'");
if($q)
{
echo "<br/><img src=\"../images/ok.gif\">You have Successfully unlocked Your account.<br/>";
}else{
echo "Unknown Error!!!";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<p align=\"left\"><img src=\"../images/home.gif\"><a href=\"main.php\">Home</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
///////////////////////////Update code///////////////////////////////
else if($action=="updatecode")
{
addonline(getuid_sid($sid),"Security Option","usersecurity.php?action=main");
    echo "<head>";
    echo "<title>Security Option</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
  echo "<div class=\"header\" align=\"center\"><b>Lock Account</b></div>";
	echo"<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
	echo "<b>You can Update your Security Code from here.</b><br/>";
	     $src_stat = mysql_fetch_array(mysql_query("SELECT status, browser, varcode FROM ibwff_usersecurity WHERE uid='".$uid."'"));
echo "<onevent type=\"onenterforward\">";
$uid = getuid_sid($sid);
$varcode = mysql_fetch_array(mysql_query("SELECT varcode FROM ibwff_usersecurity WHERE uid='".$uid."'"));
echo "<refresh>
<setvar name=\"code\" value=\"$varcode[0]\"/>
";
echo "</refresh></onevent>";
    	echo "<form action=\"usersecurity.php?action=updatecodenow\" method=\"post\"><p align=\"left\">";
    echo "<b>Code:</b><input name=\"code\" format=\"*x\" value=\"$varcode[0]\" maxlength=\"5\"/><br/>";
echo "<input type=\"submit\" value=\"Update\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
///////////////////////////Update code///////////////////////////////
else if($action=="updatecodenow")
{
addonline(getuid_sid($sid),"Security Option","usersecurity.php?action=main");
    echo "<head>";
    echo "<title>Security Option</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
  echo "<div class=\"header\" align=\"center\"><b>Lock Account</b></div>";
	echo"<div class=\"shout2\" align=\"center\">";
include("pm_by.php");	
$code  = $_POST["code"];
	$leng = strlen($code);
	if ($leng!=5)
	{
	echo "<b>[X]</b> Security Code length should atleast 5 letters!";
	echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
exit();	
	}
$q = mysql_query("UPDATE ibwff_usersecurity SET varcode='".$code."', browser='".$ubr."', time='".time()."' WHERE uid='".$uid."'");
if($q)
{
echo "<br/><img src=\"../images/ok.gif\"> You have Successfully Update Your Security.<br/>";
}else{
echo "Unknown Error!!!";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
?>
</html>