<?php
session_start();
include("config.php");
include("core.php");  connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo '<head>';
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"title\" content=\"FireBD.NeT\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From CJ UDAY: Don't Try To Hack OR else :P\">
<meta name=\"keywords\" content=\"Site Desined By CJ UDAY :) :)\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/></head>";
echo "<body>";
$action = $_GET["action"]; $sid = $_SESSION["sid"];
$page = $_GET["page"];
$who = $_GET["who"];
$uid = getuid_sid($sid);
$name = $_GET["name"];
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();
////////////////Ip Banned By CJ UDAY :)	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
    echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
	echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
      echo "<br/>";
      echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
      $banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
      $remain =  $banto[0] - time();
      $rmsg = gettimemsg($remain);
      echo "<b>Time Remaining: $rmsg</b><br/>";
      $nick = getnick_uid($banto[2]);
       $text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
      echo "</p>";
    	echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
    echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
    echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
//////////////////Banned System Updated By CJ UDAY :)
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please With Contact Us <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
 echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
///////////////////Validation By CJ UDAY :)
					if(isvalidated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
	echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  You Are Not Validated!<br/>We are checking your ip and browser<br/>
	  This could take up to 15 munites pls be patient and try again soon<br/>Please try again later...<br/><b>Thank You</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }

///////////////////Deactivated Account By CJ UDAY :)
          if(isdeactivated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  <b>Your Account Has Been Deactivated Forever.<br/>And It Will Be Never Activate!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
if($action=="")
{
  addonline(getuid_sid($sid),"Gricket Game","cricket.php?action=$action");
	echo "<head>";
    echo "<title>Cricket</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<b>Cricket</b></div>";
echo "<div class=\"shout2\" align=\"center\">
South Africa vs Australia</b><br/>
Can Oz show their strength on Africa's earth?<br/>
Australia Tour of South Africa 2013-14<br/><br/>
<h2>
<div class=\"mblock1\">
&#187; Ur Bet: 100<br/>
&#187; Ur Score: 3<br/>
&#187; Target Score: 15<br/>
&#187; Remaining Balls: 6/6<br/><br/>
";
echo "<a href=\"crct.php?action=hit\">";
echo "Hit BaLL</a><br/></div>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
else if($action=="hit")
{
  addonline(getuid_sid($sid),"Cricket Game","crct.php");
	echo "<head>";
    echo "<title>Cricket</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<b>Cricket</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<b>
South Africa vs Australia</b><br/>
Can Oz show their strength on Africa's earth?<br/>
Australia Tour of South Africa 2013-14<br/><br/>
<h2>
<div class=\"mblock1\">
<img src=\"2.jpeg\" alt=\"\"/><br/>

You GoT <b>2 Runs</b><br/>
&#187; <a href=\"crct.php?action=hit2\">Fast Batting</a><br/><br/>
<b>[[ Score Board ]]</b><br/>
&#187; Ur Total Score: 5<br/>
&#187; Target Score: 15<br/>
&#187; Remaining Balls: 5/6<br/>
</div><br/>
";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
else if($action=="hit2")
{
  addonline(getuid_sid($sid),"Cricket Game","crct.php");
	echo "<head>";
    echo "<title>Cricket</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<b>Cricket</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<b>
South Africa vs Australia</b><br/>
<h2>
<div class=\"mblock1\">
<img src=\"4.jpeg\" alt=\"\"/><br/>
Nice Shot! You Got <b>Boundary (4 Runs)</b><br/>
&#187; <a href=\"crct.php?action=hit3\">Fast Batting</a><br/><br/>

<b>[[ Score Board ]]</b><br/>
&#187; Ur Total Score: 9<br/>
&#187; Target Score: 15<br/>
&#187; Remaining Balls: 4/6<br/>
</div><br/>
";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}

else if($action=="hit3")
{
  addonline(getuid_sid($sid),"Cricket Game","crct.php");
	echo "<head>";
    echo "<title>Cricket</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<b>Cricket</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<b>
South Africa vs Australia</b><br/>
<h2>
<div class=\"mblock1\">
<img src=\"11r.jpeg\" alt=\"\"/><br/>

You Got <b>1 Runs</b><br/>
&#187; <a href=\"crct.php?action=hit4\">Fast Batting</a><br/><br/>
<b>[[ Score Board ]]</b><br/>
&#187; Ur Total Score: 10<br/>
&#187; Target Score: 15<br/>
&#187; Remaining Balls: 3/6<br/>
</div><br/>
";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
else if($action=="hit4")
{
  addonline(getuid_sid($sid),"Cricket Game","crct.php");
	echo "<head>";
    echo "<title>Cricket</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<b>Cricket</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<b>
South Africa vs Australia</b><br/>
<h2>
<div class=\"mblock1\">
<img src=\"2r.jpeg\" alt=\"\"/><br/>

You Got <b>2 Runs</b><br/>
&#187; <a href=\"crct.php?action=hit5\">Fast Batting</a><br/><br/>

<b>[[ Score Board ]]</b><br/>
&#187; Ur Total Score: 12<br/>
&#187; Target Score: 15<br/>
&#187; Remaining Balls: 1/6<br/>
</div><br/>
";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
else if($action=="hit5")
{

 addonline(getuid_sid($sid),"Cricket Game","crct.php");
	echo "<head>";
    echo "<title>Cricket</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<b>Cricket</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<b>";


    $magicbox = rand(1, 4);

    if ($magicbox=="1")
    {
echo "<b>
South Africa vs Australia</b><br/><br/>
<h2>
<div class=\"mblock1\">
<img src=\"3.jpeg\" alt=\"\"/><br/>

Good Shot! You Got <b>6 Runs</b><br/>


<b>[[ Score Board ]]</b><br/>
&#187; Ur Total Score: 18<br/>
&#187; Target Score: 15<br/>
&#187; Remaining Balls: 0<br/>
<br/>
You Scored 18 Runs and Won the match by 0 Remaining Balls and won 100 Bet credits!<br/><br/>
<img src=\"cup.jpeg\" alt=\"\"/> Congrets You Win This Cup<br/><br/>

</div><br/>
";

    	$opl = mysql_fetch_array(mysql_query("SELECT plusses FROM ibwff_users WHERE id='".$uid."'"));
    	$pval = 100;
    	$npl = $opl[0] + $pval;
    	mysql_query("UPDATE ibwff_users SET plusses='".$npl."' WHERE id='".$uid."'");

    	$nam = mysql_fetch_array(mysql_query("SELECT name FROM ibwff_users WHERE id='".$uid."'"));
 mysql_query("INSERT INTO ibwff_events (event,time) values ('".$nam[0]." Win Cricket Game','$nowx')");


    }
    else if($magicbox=="2")
    {
echo "<b>
South Africa vs Australia</b><br/><br/>
<h2>
<div class=\"mblock1\">
<img src=\"4.jpeg\" alt=\"\"/><br/>

You Got <b>4 Runs</b><br/>
&#187; <a href=\"crct.php\">Play Again</a><br/><br/>

<b>[[ Score Board ]]</b><br/>
&#187; Ur Total Score: 16<br/>
&#187; Target Score: 15<br/>
&#187; Remaining Balls: 0<br/>
<br/>
You Scored 16 Runs and Won the match by 0 Remaining Balls and won 100 Bet credits!<br/><br/>
<img src=\"cup.jpeg\" alt=\"\"/> Congrets You Win This Cup<br/><br/>

</h2>
</div><br/>
";

    	$opl = mysql_fetch_array(mysql_query("SELECT plusses FROM ibwff_users WHERE id='".$uid."'"));
    	$pval = 100;
    	$npl = $opl[0] + $pval;
    	mysql_query("UPDATE ibwff_users SET plusses='".$npl."' WHERE id='".$uid."'");

    	$nam = mysql_fetch_array(mysql_query("SELECT name FROM ibwff_users WHERE id='".$uid."'"));
mysql_query("INSERT INTO ibwff_events (event,time) values ('".$nam[0]." Win Cricket Game','$nowx')");

    }
    else if($magicbox=="3")
    {
echo "<b>
South Africa vs Australia</b><br/><br/>
<h2>
<div class=\"mblock1\">
<img src=\"2.jpeg\" alt=\"\"/><br/>

You Got <b>2 Runs</b><br/>
&#187; <a href=\"crct.php\">Try Again</a><br/><br/>

<b>[[ Score Board ]]</b><br/>
&#187; Ur Total Score: 14<br/>
&#187; Target Score: 15<br/>
&#187; Remaining Balls: 0<br/>
<br/>
You Scored 14 Runs and Lose the match by 0 Remaining Balls and Lose 100 Bet credits!<br/><br/>
Try Next Thank You For Playing Cricket Game<br/><br/>
</h2>
</div><br/>
";

    	$opl = mysql_fetch_array(mysql_query("SELECT plusses FROM ibwff_users WHERE id='".$uid."'"));
    	$pval = 100;
    	$npl = $opl[0] - $pval;
    	mysql_query("UPDATE ibwff_users SET plusses='".$npl."' WHERE id='".$uid."'");

    	$nam = mysql_fetch_array(mysql_query("SELECT name FROM ibwff_users WHERE id='".$uid."'"));
 mysql_query("INSERT INTO ibwff_events (event,time) values ('".$nam[0]." lost Cricket Game','$nowx')");
    }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
?>
</html>