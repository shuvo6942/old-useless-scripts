<?php
session_start();
include("config.php");
include("core.php");
connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo "<head>";
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\"/>";
echo "<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG : Don't Try To Hack OR else :P\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"main,all,follow\"/></head>";
echo "<body>";
$action = $_GET["action"]; $sid = $_SESSION["sid"];
$who = $_GET["who"];
$uid = getuid_sid($sid);
$ubrw = $ubrw[0];
$ipad = getip();	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
echo "<br/>";
echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
$banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
$remain =  $banto[0] - time();
$rmsg = gettimemsg($remain);
echo "<b>Time Remaining: $rmsg</b><br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "</p>";
echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
$uid = getuid_sid($sid);
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"left\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "<div class=\"div align=\"center\">Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");  
echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please Contact <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(isdeactivated(getuid_sid($sid), $uid))
{
echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<br/><b>Your Account Has Been Deactivated.<br/>And It Will Be Never Activated Again!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>"; 
     exit();
  }
else if($action=="snreq")
{
  addonline(getuid_sid($sid),"Sending Request","relativesproc.php?action=$action");
echo "<head>";
echo "<title>Sending Request</title>";
 echo "</head>"; 
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
    echo "<div class=\"header\" align=\"center\">";
	echo "<b>Relative Request</b></div>";
    echo "<div class=\"shout2\" align=\"left\">";
$who = $_GET["who"];
include("pm_by.php");
echo "<b>Send A Relationship Request As Your:</b><br/>";
$sx = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE id='".$who."'"));
echo "<form action=\"relativesproc.php?action=snsta&who=$who\" method=\"post\">";
echo "<select name=\"rel\">";
if($sx[0]=="M")
{
echo "<option value=\"Husband\">Husband</option>";
echo "<option value=\"Wife\">Wife</option>";
echo "<option value=\"Boy Friend\">Boy Friend</option>";
echo "<option value=\"Best Friend\">Best Friend</option>";
echo "<option value=\"Old Friend\">Old Friend</option>";
echo "<option value=\"Cousin\">Cousin</option>";
echo "<option value=\"Brother-In-Law\">Brother-In-Law</option>";
echo "<option value=\"Father\">Father</option>"; 
echo "<option value=\"Son\">Son</option>";
echo "<option value=\"Father-In-Law\">Father-In-Law</option>";
echo "<option value=\"Son-In-Law\">Son-In-Law</option>";
echo "<option value=\"Grand-Father\">Grand-Father</option>";
echo "<option value=\"Grand-Son\">Grand-Son</option>";
echo "<option value=\"Uncle\">Uncle</option>";
echo "<option value=\"Nephew\">Nephew</option>";
echo "<option value=\"Classmate\">Classmate</option>";
echo "<option value=\"Family-Member\">Family-Member</option>";
}else if($sx[0]=="F")
{
echo "<option value=\"Wife\">Wife</option>";
echo "<option value=\"Girl Friend\">Girl Friend</option>";
echo "<option value=\"Best Friend\">Best Friend</option>";
echo "<option value=\"Old Friend\">Old-Friend</option>";
echo "<option value=\"Cousin\">Cousin</option>";
echo "<option value=\"Daughter-In-Law\">Daughter-In-Law</option>";
echo "<option value=\"Mother\">Mother</option>"; 
echo "<option value=\"Daughter\">Daughter</option>";
echo "<option value=\"Mother-In-Law\">Mother-In-Law</option>";
echo "<option value=\"Daughter-In-Law\">Daughter-In-Law</option>";
echo "<option value=\"Grand-Mother\">Grand-Mother</option>";
echo "<option value=\"Grand-Daughter\">Grand-Daughter</option>";
echo "<option value=\"Aunt\">Aunt</option>";
echo "<option value=\"Niece\">Niece</option>";
echo "<option value=\"Classmate\">Classmate</option>";
echo "<option value=\"Family-Member\">Family-Member</option>";
}
echo "</select><br/>";
echo "<input type=\"submit\" value=\"Send Request\">";
echo "</form>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
exit();
}
else if($action=="snsta")
{
  addonline(getuid_sid($sid),"Sending Relative Request","Relatives.php?action=$action");
echo "<head>";
echo "<title>Send Relative Request</title>";
 echo "</head>"; 
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
    echo "<div class=\"header\" align=\"center\">";
$tnick = subnick(getnick_uid($who));
	echo "<b>Relative Request Status</b></div>";
    echo "<div class=\"shout2\" align=\"left\">";
$who = $_GET["who"];
$uid = getuid_sid($sid);
$xef = $_POST["rel"];
$tm = time();
include("pm_by.php");
if(isignored($uid, $who))
    {
    echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>";
    echo "Cannot Send Relation Request To $tnick. You are on ignore List.<br/><br/>";
   }else if(arerels($uid,$who))
    {
      echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>$tnick is Already Your Relative.<br/><br/>";
    }else if(relres($uid, $who)==0)
    {
        $res = mysql_query("INSERT INTO ibwf_relatives SET uid='".$uid."', tid='".$who."', reqdt='".time()."', relation='$xef'");
		if($res)
        {
            echo "<br/><img src=\"../avatars/ok.gif\" alt=\"o\"/>A Relative Request As Your $xef Has Been Sent to $tnick<br/><br/>";
			 $nick = getnick_sid($sid);
           mysql_query("INSERT INTO ibwf_notifications SET text='[user=$uid]$nick"."[/user] Has Sent You a Relative Request As $rel"."![br/]Accept Or Reject It From The Relatives Menu On Main Menu', touid='".$who."', timesent='".time()."'");
        }else{
          echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>You can't add $tnick to your relative list<br/>";        
}
    }
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
exit();
 }
///////////////////////////////
else if($action=="add")
  {
  addonline(getuid_sid($sid),"Accepting Relative Request","Relatives.php?action=$action");
echo "<head>";
echo "<title>Relatives Requests</title>";
  echo "</head>"; 
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
    echo "<div class=\"header\" align=\"center\">";
	echo "<b>Relative Request Status</b></div>";
    echo "<div class=\"shout2\" align=\"left\">";
$who = $_GET["who"];
$uid = getuid_sid($sid);
$tnick = subnick(getnick_uid($uid));
        $res = mysql_query("UPDATE ibwf_relatives SET agreed='1' WHERE uid='".$who."' AND tid='".$uid."'");
        if($res)
        {
       echo "<br/><img src=\"../avatars/ok.gif\" alt=\"o\"/>$tnick Added to Your Relative List Successfully!<br/><br/>";
           mysql_query("INSERT INTO ibwf_notifications SET text='[user=$uid]$nick"."[/user] Confirmed You As Relative!', touid='".$who."', timesent='".time()."'");
	   }else{
          echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>You Can't Add $tnick to Your Relative List<br/>";
        }
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
exit();
}
else if($action="del")
  {
  addonline(getuid_sid($sid),"Deleting Relatives","friendsproc.php?action=$action");
echo "<head>";
echo "<title>Delete Relatives</title>";
  echo "</head>"; 
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
    echo "<div class=\"header\" align=\"center\">";
	echo "<b>Deleting Reletives</b></div>";
    echo "<div class=\"shout2\" align=\"left\">";
$tnick = subnick(getnick_uid($who));
      $res= mysql_query("DELETE FROM ibwf_relatives WHERE (uid='".$uid."' AND tid='".$who."') OR (uid='".$who."' AND tid='".$uid."') AND agreed='1'");
      if($res)
        {
            echo "<br/><img src=\"../avatars/ok.gif\" alt=\"o\"/>$tnick Removed From Your Relative List<br/><br/>";
			$nick = getnick_uid($uid);
mysql_query("INSERT INTO ibwf_notifications SET text='[user=$uid]$nick"."[/user] Has Removed You From Relative!', touid='".$who."', timesent='".time()."'");
        }else{
          echo "<br/><img src=\"../avatars/notok.gif\" alt=\"x\"/>Can't Remove $tnick From Your Relative List<br/><br/>";
        }
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
exit();
}
else if($action="aall")
  {
  addonline(getuid_sid($sid),"Accepting Friends Reletive List","Relatives.php?action=$action");
echo "<head>";
echo "<title>Relative Requests</title>";
 echo "</head>"; 
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
    echo "<div class=\"header\" align=\"center\">";
	echo "<b>Relatives Request Status</b></div>";
    echo "<div class=\"shout2\" align=\"left\">";
      $res= mysql_query("UPDATE ibwf_relatives SET agreed='1' WHERE tid='".$uid."' AND agreed='0'");
if($res)
{
       echo "<br/><img src=\"../avatars/ok.gif\" alt=\"o\"/>All The Relative Requests Accepted Successfully!<br/><br/>";
           mysql_query("INSERT INTO ibwf_notifications SET text='[user=$uid]$nick"."[/user] Confirmed You As A Relative!', touid='".$who."', timesent='".time()."'");
	   }else{
          echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>Can't Accept All The Requests At This Moment.<br/>";
        }
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
exit();
}
else if($action=="dall")
{
  addonline(getuid_sid($sid),"Denying Relatives Request List","relativesproc.php?action=$action");
echo "<head>";
echo "<title>Relative Requests</title>";
  echo "</head>"; 
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
    echo "<div class=\"header\" align=\"center\">";
	echo "<b>Relative Request Status</b></div>";
    echo "<div class=\"shout2\" align=\"left\">";
      $res= mysql_query("DELETE FROM ibwf_relatives WHERE agreed='0' AND tid='".$uid."'");
if($res){
          echo "<br/><img src=\"../avatars/ok.gif\" alt=\"o\"/>All The Relative Requests Denied Successfully!<br/><br/>";
	   }else{
          echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>Can't Deny All The Requests At This Moment.<br/>";
        }
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
exit();
}
?>
</html>