<?php
$info= mysql_fetch_array(mysql_query("SELECT location, email, phone FROM ibwff_users WHERE id='".$uid."'"));
$info1= mysql_fetch_array(mysql_query("SELECT browser, status FROM ibwff_usersecurity WHERE uid='".$uid."'"));
$counter = 0;
if (!empty($info[0]))
{

$com = $counter+20;
}
else
{
$com = $counter;
}
 if (!empty($info[1]))
{
$com1 = $com+20;
}
else
{
$com1 = $com;
}
 if (!empty($info[2]))
{
$com2 = $com1+20;
}
else
{
$com2 = $com1;
}
 if (!empty($info1[0]))
{
$com3 = $com2+20;
}
else
{
$com3 = $com2;
}
 if ($info1[1] !=0)
{
$com4 = $com3+20;
}
else
{
$com4 = $com3;
}
 if ($info[8]==2)
{
$com5 = $com4+15;
}
else
{
$com5 = $com4;
}
$vartime = 2*24*60*60;
 if ($info[7]>=$vartime)
{
$com6 = $com5+15;
}
else
{
$com6 = $com5;
}
 if ($info3[0]>0)
{
$com7 = $com6+10;
}
else
{
$com7 = $com6;
}
 if (!empty($info2[1]))
{
$com8 = $com7+1;
}
else
{
$com8 = $com7;
}
 if (!empty($info2[2]))
{
$com9 = $com8+1;
}
else
{
$com9 = $com8;
}
 if (!empty($info2[3]))
{
$com10 = $com9+1;
}
else
{
$com10 = $com9;
}
 if (!empty($info2[4]))
{
$com11 = $com10+1;
}
else
{
$com11 = $com10;
}
 if (!empty($info2[5]))
{
$com12 = $com11+1;
}
else
{
$com12 = $com11;
}
 if ($info5[0]>0)
{
$com13 = $com12+10;
}
else
{
$com13 = $com12;
}
 if ($info6[0]>=10)
{
$complete = $com13+5;
}
else
{
$src_complete = $com13;
}
?>