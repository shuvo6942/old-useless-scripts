<?php
 include ("config.php"); 
include ("core.php");

echo("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD XHTML Mobile 1.0//EN\"". " \"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="StyleSheet" type="text/css" href="Styles.css" />
<title>Cloudywap.Tk Production</title>
<meta forua="true" http-equiv="Cache-Control" content="no-cache"/>
<meta forua="true" http-equiv="Cache-Control" content="must-revalidate"/><?php 
if(!canreg())
{
}else{

?>
<div class="header" align="left">
<img src="FireBD.png" alt="[FireBD.NeT]" type="logo" width="240" height="50">
<br/><b>Cloudywap.Tk Production<br/>Create Your Own Online Community Site</b>
</div>

<div class="div" align="center"><b>WHY YOU BUY AN ONLINE COMMUNITY SITE FROM Cloudywap.Tk PRODUCTION?</b></div>
<div class="shout2" align="left"><br/>Cloudywap.Tk IS MOST POPULAR ONLINE COMMUNITY MOBILE SITE. Cloudywap.Tk WILL GIVE YOU TO A FULLY SECURED SITE WITHIN THE SHORTEST POSSIBLE TIME.<br/><br/>

</p><div class="div" align="center"><b>FEATURES</b></div>
<p align="left">
<br>* You will get a <b>full featured & secured</b> online community site just like the Cloudywap Online Community.
<br>* You will get the ownership of your online community site.
<br>* You will be able to configure your site according to your wish.
<br>* You will be able to design your site according to your wish.
<br>* You will be able to control your whole site according to your wish with the help of built in admin panel.
<br>* You will be able to control your whole site very easily from your mobile phone.You do not even need a computer for this.
<br>* Configurations & admin panels are made very easy to understand.
<br>* You will get all new updates of Cloudywap.Tk Production instantly for free.
<br>* You can also earn from the premium membership of your site.
<br>* Feature Demo Site: <a href="main.php">http://Cloudywap.Tk</a>
<br>
<br><big><b><u><span style="color:red;">WITH .tk DOMAIN</span></u></b></big>
<br><b><u>* One time payment for site creation:</u></b> <span style="color:green;"><b>&#2547;1000 TK</b></span>
<br>From 2nd Month, Monthly Hosting Cost : <span style="color:green;"><b>&#2547;50 TK</b></span>
<br><b><u>* Long term payment for site creation:</u></b> <span style="color:green;"><b>&#2547;1500 TK</b></span> [Total]
<br>- 1st Month: &#2547;600 TK (Monthly hosting cost: free)
<br>- 2nd Month: &#2547;400 TK (Including monthly hosting cost: &#2547;50 TK)
<br>- 3rd Month: &#2547;500 TK (Including monthly hosting cost: &#2547;50 TK)
<br>From 4th Month, Monthly Hosting Cost : <span style="color:green;"><b>&#2547;50 TK</b></span>
<br>
<br><big><b><u><span style="color:red;">WITH .com/.net/.org DOMAIN</span></u></b></big>
<br><b><u>* One time payment for site creation:</u></b> <span style="color:green;"><b>&#2547;3000 TK</b></span>
<br>From 2nd Month, Monthly Hosting Cost : <span style="color:green;"><b>&#2547;100 TK</b></span>
<br><b><u>* Long term payment for site creation:</u></b> <span style="color:green;"><b>&#2547;3500 TK</b></span> [Total]
<br>- 1st Month: &#2547;1200 TK (Monthly hosting cost: free)
<br>- 2nd Month: &#2547;1000 TK (Including monthly hosting cost: &#2547;100 TK)
<br>- 3rd Month: &#2547;800 TK (Including monthly hosting cost: &#2547;100 TK)
<br>- 4th Month: &#2547;500 TK (Including monthly hosting cost: &#2547;100 TK)
<br>From 5th Month, Monthly Hosting Cost : <span style="color:green;"><b>&#2547;100 TK</b></span>
<br>
<br><b><u>TERMS &amp; CONDITIONS</u></b>
<br>* You can not spam your site in Cloudywap.
<br>* Monthly hosting cost is free for the first month.
<br>* If you fail to pay monthly hosting cost/due, your site will be deactivated.
<br>* You can activate your deactivated site at anytime by paying monthly cost.
<br>* The rates & terms may change at anytime according to need.
<br>* If you do not maintain these terms & conditions, your site may be cancelled at anytime.
<br></p><div class="div" align="center"><b>PAYMENT PROCESS</b></div>
<p align="left">
<b><u>By bKash</u></b>
<br>* bKash <span style="color:green;"><b>&#2547;1500</b></span> TK to <span style="color:red;"><b>01910170361</b></span>.<br/>
<b><u>By Dutch Bangla Bank</u></b>
<br>* Dutch Bangla Bank <span style="color:green;"><b>&#2547;1500</b></span> TK to <span style="color:red;"><b>01910170361</b></span>.
<br>* Send your desired domain name (<a href="http://Cloudywap.Tk">make sure the domain is availiable</a>) and bKash/DBL sender/agent number via SMS to <span style="color:red;"><b>01910170361</b></span> from your mobile.
<br>* Within one hour you will get your site link, username & password of your (owner) account via SMS to your mobile.
<br>* The process is so simple. If you still have any confusion, feel free to contact Cloudywap.Tk Production:
<br>[ U Can call, or just SMS your question to <span style="color:red;"><b>+8801910170361</b></span>, we will contact you ]
<br></p><p align="left">* <a href="http://Cloudywap.Tk/wap/community/profile.php?who=2">Contact Mehedi For Further Details.</a></p></div><p align="left"><img src="avatars/home.gif" alt=""><a href="http://FireBD.NeT/community/main.php">Home</a></p> <div class="footer" align="center">2015 <b><a href="http:///community/main.php">FireBD.NeT</a></b></div>
</div>





<?php
{

}


}

?>