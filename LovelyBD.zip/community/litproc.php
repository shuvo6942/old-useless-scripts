<?php
session_start();
include("config.php");
include("core.php");
connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo "<head>";
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<body><meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG : Don't Try To Hack OR else :P\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"main,all,follow\"/></head>";
echo "<body>";
##L!TURATUR3 C0D3S AR FULLY CR3AT3D & S3CUR3D BY Shahos :-)
$action = $_GET["action"]; $sid = $_SESSION["sid"];
$clid = $_GET["clid"]; $page = $_GET["page"];
$who = $_GET["who"];
$uid = getuid_sid($sid);
$sitename = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='sitename'"));
$sitename = $sitename[0];
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
echo "<br/>";
echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
$banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
$remain =  $banto[0] - time();
$rmsg = gettimemsg($remain);
echo "<b>Time Remaining: $rmsg</b><br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "</p>";
echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
echo "<img src=\"../images/user.png\" alt=\"user\"><b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
echo "<img src=\"../images/pass.png\" alt=\"pass\"><b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
$uid = getuid_sid($sid);
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
 echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");  
echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
 echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "<div class=\"div align=\"center\">Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");  
echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please Contact <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(isdeactivated(getuid_sid($sid), $uid))
{
echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<br/><b>Your Account Has Been Deactivated.<br/>And It Will Be Never Activated Again!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
////////////////////////Updated :)
if($action=="newlitt")
{
  $fid = $_POST["fid"];
$uday = littyp_fid($fid);
  $ntitle = $_POST["ntitle"];
  $tpctxt = $_POST["tpctxt"];
$udy = $_POST["udaytag"];
if(istrashed(getuid_sid($sid)))
  {
	echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
  echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
      echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Unknown error cannot create literature!<br/>please try again later...<br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      echo "</html>";
      exit();
  }
  addonline(getuid_sid($sid),"Created New $uday","literature.php?action=$action");
	    echo "<head>";
    echo "<title>Create A New $uday</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
			echo "<b>Create $uday</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
      $crdate = time();
     $texst = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_storys WHERE name LIKE '".$ntitle."' AND fid='".$fid."'"));
      if($texst[0]==0)
      {
        $res = false;
        $ltopic = mysql_fetch_array(mysql_query("SELECT crdate FROM ibwff_storys WHERE authorid='".$uid."' ORDER BY crdate DESC LIMIT 1"));
        global $topic_af;
        $antiflood = time()-$ltopic[0];
        if($antiflood>$topic_af)
{
  if((trim($ntitle)!="")||(trim($tpctxt)!=""))
      {
    if(!isblocked($ntitle,$uid)&&!isblocked($tpctxt,$uid))
    {
$fx = litvldtn();
      $res = mysql_query("INSERT INTO ibwff_storys SET name='".$ntitle."', fid='".$fid."', authorid='".$uid."', text='".$tpctxt."', crdate='".$crdate."', lastpost='".$crdate."', type='".$uday."', validate='".$fx."', tags='".$udy."'");
    }else{
    echo "<b><u><i>Can't Create Article!!!<br/><br/>";
   echo "You Just Tried To Spam In FireBD via Article<br/>So You Are Now Article Banned!<br/>If You Article Banned By Our Mistake or Want To Be Article Unban<br/>Then Please Contact <a href=\"online.php?action=stfol\">Online Staffs</a></b></i></u><br/><br/>";
        $user = getnick_sid($sid);
    mysql_query("UPDATE ibwff_users SET letban='1' WHERE id='".$uid."'");
    mysql_query("INSERT INTO ibwff_private SET text='[b](forwarded spam via creating new article)[/b][br/]".$tpctxt."', byuid='".$uid."', touid='1', timesent='".$crdate."'");
	mysql_query("INSERT INTO ibwff_private SET text='[b](forwarded spam via creating new article)[/b][br/]".$tpctxt."', byuid='".$uid."', touid='2', timesent='".$crdate."'");
	mysql_query("INSERT INTO ibwff_private SET text='[b](forwarded spam via creating new article)[/b][br/]".$tpctxt."', byuid='".$uid."', touid='4', timesent='".$crdate."'");
	echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      echo "</body>";
      echo "</html>";
      exit();
  }
     }
       if($res)
      {
        $cow = mysql_fetch_array(mysql_query("SELECT storys,plusses FROM ibwff_users WHERE id='".$uid."'"));
        $utpc = $cow[0]+1;
$uday = litpoint();  
      $upl = $cow[1]+$uday;
        mysql_query("UPDATE ibwff_users SET storys='".$utpc."', plusses='".$upl."' WHERE id='".$uid."'");
        $tnm = htmlspecialchars($ntitle);
$ibwff = time()+6*60*60;
$user = getnick_uid($uid);
$who = getnick_uid($who);
mysql_query("insert into ibwff_events (event,time) values ('<b>$user</b> has created a new literature','$ibwff')");
        echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Article <b>$tnm</b> Created Successfully!";
        $tid = mysql_fetch_array(mysql_query("SELECT id FROM ibwff_storys WHERE name='".$ntitle."' AND fid='".$fid."'"));
        echo "<br/>&#8226;<a href=\"literature.php?clid=$clid&tid=$tid[0]\">";
echo "View Article</a><br/><br/>";
$clid = $_GET["clid"];
		if ($clid>0)
{
mysql_query("UPDATE ibwff_clubs SET plusses=plusses+6 WHERE id='".$clid."'");
mysql_query("UPDATE ibwff_clubmembers SET points=points+6 WHERE uid=$uid AND clid=$clid");
$name = getclubname($clid);
echo "<br/>Topic create under <b>$name</b> club!<br/>";
$msg = "[b]Club notification:[/b] A new article named [literature=$tid[0]]".$ntitle."[/topic] created in ".$name." club by [user=$uid]".$user."[/user]";
clubnot_uday($clid,$msg);
$history = "<b>$user</b> has created a new article <b>$ntitle</b>";
clubhis_uday($clid,$history);
}
      }else{
        echo "<br/><img src=\"../avatars/notok.gif\" alt=\"X\"/>Error Creating New Article!<br/>";
      }
      }else{
        $af = $topic_af -$antiflood;
        echo "<br/><img src=\"../avatars/notok.gif\" alt=\"X\"/>Flood Control: $af<br/><u>Please Wait A Few Seconds</u><br/><br/>";
      }
      }else{
        echo "<br/><img src=\"../avatars/notok.gif\" alt=\"X\"/>Article Name Already Exist!<br/>";
      }
      $fname = getlfname($fid);
      echo "<br/><br/><a href=\"literature.php?action=viewlitbox&clid=$clid&fid=$fid\">";
echo "$fname</a><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="comment")
{
 $ban = mysql_fetch_array(mysql_query("SELECT letcomban FROM ibwff_users WHERE id='".$uid."'"));
if($ban[0] > 0)
  {
	echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
			 echo "<div class=\"header\" align=\"center\">";
			  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
  echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
  echo "<br/><b><u><i>Can't Comment On Article<br/>";
  echo "You're Article Comment Banned!</i></u></b><br/><br/>";
 echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
    exit();
    }
    $tid = $_POST["tid"];
    $tfid = mysql_fetch_array(mysql_query("SELECT fid FROM ibwff_storys WHERE id='".$tid."'"));
if(istrashed(getuid_sid($sid)))
  {
	echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
			echo "<img src=\"../avatars/notok.gif\"><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");     
 echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Unknown error cannot comment! <br/>please try again later...<br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
      exit();
  }
  $reptxt = $_POST["reptxt"];
  addonline(getuid_sid($sid),"Posting A Comment","literature.php?action=viewlit");
	    echo "<head>";
    echo "<title>Post A Comment</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
			echo "<b>Post Comment</b></div>";
  echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
      $crdate = time();
      $res = false;
    if(ismod($uid))
      {
        $lpost = mysql_fetch_array(mysql_query("SELECT dtpost FROM ibwff_posts WHERE uid='".$uid."' ORDER BY dtpost DESC LIMIT 1"));
		$time = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_antifloods WHERE name='tpostaf'"));
        global $post_af;
        $antiflood = time()-$lpost[0];
        if($antiflood>$post_af)
{
  if(trim($reptxt)!="")
      {
    if(!isblocked($reptxt,$uid))
    {
      $postxt = parsepm($reptxt,$sid);
$nrom = substr_count($postxt,"<img src=");
    if($nrom>2){
      echo "<small>";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\">You can use just 2 smiles on post !!!<br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
    }
      $res = mysql_query("INSERT INTO ibwff_storyposts SET text='".$reptxt."', tid='".$tid."', uid='".$uid."', dtpost='".$crdate."'");
    }else{
    echo "<b><u><i>Can't Comment On Article!!!<br/><br/>";
   echo "You Just Tried To Spam In FireBD via Post Topic<br/>So You Are Now Article Comment Banned!<br/>If You Comment Banned By Our Mistake or Want To Be Post Unban<br/>Then Please Contact <a href=\"online.php?action=stfol\">Online Staffs</a></b></i></u><br/>";
        $user = getnick_sid($sid);
    mysql_query("UPDATE ibwff_users SET letcomban='1' WHERE id='".$uid."'");
    mysql_query("INSERT INTO ibwff_private SET text='[b](forwarded spam via literature comment)[/b][br/]".$reptxt."', byuid='".$uid."', touid='1', timesent='".$crdate."'");
	mysql_query("INSERT INTO ibwff_private SET text='[b](forwarded spam via literature comment)[/b][br/]".$reptxt."', byuid='".$uid."', touid='2', timesent='".$crdate."'");
	mysql_query("INSERT INTO ibwff_private SET text='[b](forwarded spam via literature comment)[/b][br/]".$reptxt."', byuid='".$uid."', touid='4', timesent='".$crdate."'");
	echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      echo "</body>";
      echo "</html>";
    exit();
  }
}
      if($res)
      {
        $cow = mysql_fetch_array(mysql_query("SELECT storyposts,plusses FROM ibwff_users WHERE id='".$uid."'"));
		$res2 = mysql_fetch_array(mysql_query("SELECT name,authorid FROM ibwff_storys WHERE id='".$tid."'"));
	    $replayer = getnick_sid($sid);
		$tname = htmlspecialchars($res2[0]);		 mysql_query("INSERT INTO ibwff_notifications SET text='Your Article [literature=$tid]$tname"."[/literature] Has Been Commented By [user=$uid]$replayer"."[/user]', touid='".$res2[1]."', timesent='".time()."'");

$a = mysql_fetch_array(mysql_query("SELECT * FROM uday_subtop WHERE uid='".$uid."' AND tid='".$tid."'"));
if($a[0]==0)
{
mysql_query("INSERT INTO uday_sublit SET uid='".$uid."', tid='".$tid."', time='".$tm."'");
}
//LITERATURE N0TIFICATI0N :-)
$msg = "[b]Article Notification[/b]: Your Subscribed Article [literature=$tid]".$tname."[/literature] Has Been Commented By [user=$uid]".$replayer."[/user]";
litnot_uday($tid,$msg);
////D0NE!
        $ups = $cow[0]+1;
$uday = litcompoint();  
      $upl = $cow[1]+$uday;
        mysql_query("UPDATE ibwff_users SET storyposts='".$ups."', plusses='".$upl."' WHERE id='".$uid."'");
        mysql_query("UPDATE ibwff_storys SET lastpost='".$crdate."' WHERE id='".$tid."'");
        echo "<br/><img src=\"../avatars/ok.gif\" alt=\"O\"/>Article Commented Successfully!";
        echo "<br/><a href=\"literature.php?clid=$clid&tid=$tid&amp;go=last\">";
echo "View Article</a><br/><br/>";
      }else{
        echo "<br/><img src=\"../avatars/notok.gif\" alt=\"X\"/>Error To Comment This Article<br/><br/>";
      }
      }else{
$af = $post_af -$antiflood;
        echo "<br/><img src=\"../avatars/notok.gif\" alt=\"X\"/>Antiflood Control: $af<br/><br/>";
      }
      }
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="rcom")
{
  $pid = $_GET["pid"];
  addonline(getuid_sid($sid),"Reporting Post","literature.php?action=Lite");
    	    echo "<head>";
    echo "<title>Report A Comment</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
			echo "<b>Report A Article Comment</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");  
$pinfo = mysql_fetch_array(mysql_query("SELECT reported FROM ibwff_storyposts WHERE id='".$pid."'"));
          if($pinfo[0]=="0")
          {
          $str = mysql_query("UPDATE ibwff_storyposts SET reported='1' WHERE id='".$pid."' ");
          if($str)
          {
            echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Comment reported to mods Successfully!";
          }else{
            echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Can't report comment at the moment";
          }
          }else{
            echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>This comment is already reported";
          }
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="rlit")
{
  $tid = $_GET["tid"];
  addonline(getuid_sid($sid),"Reporting Article","literature.php?action=Lite");
    	    echo "<head>";
    echo "<title>Report A Article</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
			echo "<b>Report A Article</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
  $pinfo = mysql_fetch_array(mysql_query("SELECT reported FROM ibwff_storys WHERE id='".$tid."'"));
          if($pinfo[0]=="0")
          {
          $str = mysql_query("UPDATE ibwff_storys SET reported='1' WHERE id='".$tid."' ");
          if($str)
          {
            echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Article reported to mods successfully!";
          }else{
            echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Can't report literature at the moment";
          }
          }else{
            echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>This literature is already reported";
          }
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="litrate")
{
     echo "<head>";
    echo "<title>Rating Article</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
						echo "<div class=\"header\" align=\"center\">";
			echo "<b>Rating A Article</b></div>";
						echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$tid = $_GET["tid"];
$rate = $_POST["rate"];
$tm = time();
$x = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM uday_litrate WHERE uid='".$uid."' AND tid='".$tid."'"));
if($x[0]==0)
{
$tid = $_GET["tid"];
$rate = $_POST["rate"];
$tm = time();
$rx = mysql_query("INSERT INTO uday_litrate SET uid='".$uid."', tid='".$tid."', rate='".$rate."', time='".time()."'");
if($rx)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> Article Rated Successfully!<br/>&#171;<a href=\"literature.php?tid=$tid\">View Article</a>";
//LITERATURE N0TIFICATION :-)
$tn = mysql_fetch_array(mysql_query("SELECT name FROM ibwff_storys WHERE id='".$tid."'"));
$tnm = htmlspecialchars($tn[0]);
$nick = getnick_sid($sid);
$msg = "[b]Article Notification[/b]: Your Subscribed Topic [topic=$tid]".$tnm."[/topic] Has Been Rated ".$rate." Out Of 5 By [user=$uid]".$nick."[/user]";
litnot_uday($tid,$msg);
//D0NE :-)
}else{
echo "<img src=\"../images/notok.gif\" alt=\"O\"> Article Cannot Be Rated At This Moment!<br/>&#171;<a href=\"literature.php?tid=$tid\">View Topic</a>";
}
}else{
echo "<img src=\"../images/notok.gif\" alt=\"O\"> You Have Already Rated This Article!<br/>&#171;<a href=\"literature.php?tid=$tid\">View Article</a>";
}
    echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="litsub")
{
  $who = $_GET["who"];
$tid = $_GET["tid"];
$tm = time();
     echo "<head>";
    echo "<title>Subscribing Article</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
						echo "<div class=\"header\" align=\"center\">";
			echo "<b>Subscribing A Article</b></div>";
						echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$uid = getuid_sid($sid);
$rx = mysql_query("INSERT INTO uday_sublit SET uid='".$uid."', tid='".$tid."', time='".$tm."'");
if($rx)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> Article Subscribed Successfully!<br/>&#171;<a href=\"literature.php?tid=$tid\">View Article</a>";
}else{
echo "<img src=\"../images/notok.gif\" alt=\"O\"> Article Cannot Be Subscribed At This Moment!<br/>&#171;<a href=\"literature.php?tid=$tid\">View Article</a>";
} 
    echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="litunsub")
{
$uid = getuid_sid($sid);
$tid = $_GET["tid"];
     echo "<head>";
    echo "<title>Unsubscribing Article</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
						echo "<div class=\"header\" align=\"center\">";
			echo "<b>Unsubscribing A Article</b></div>";
						echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$rx = mysql_query("DELETE FROM uday_sublit WHERE uid='".$uid."' AND tid='".$tid."'");
if($rx)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> Article Unsubscribed Successfully!<br/>&#171;<a href=\"literature.php?tid=$tid\">View Article</a>";
}else{
echo "<img src=\"../images/notok.gif\" alt=\"O\"> Article Cannot Be Unsubscribed At This Moment!<br/>&#171;<a href=\"literature.php?tid=$tid\">View Article</a>";
} 
    echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
?>
</html>