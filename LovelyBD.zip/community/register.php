<?php
$start = microtime(true);
include("core.php");
include("config.php");
	connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
	echo "<head>";
	echo "<title>Registration Center Of FireBD.NeT</title>";
	echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\"/>";
	echo "</head>";
	echo "<body>";
$brws = explode(" ",$HTTP_USER_AGENT);
	$ubr = mysql_real_escape_string($REQUEST["$brws[0]"]);
$ipr = getip();
$uip = explode(".",$ipr);
$sitename = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='sitename'"));
$sitename = $sitename[0];
$actime = mysql_fetch_array(mysql_query("SELECT regdate FROM ibwff_users ORDER BY regdate DESC LIMIT 1"));
    $timeout = $actime[0];
        if(time()<$timeout)
        {
  echo "<div class=\"header\" aling=\"center\"><img src=\"images/notok.gif\" alt=\"X\"/><br/><b>Error!<b></div><br/>";
echo "<div class=\"shout2\" align=\"left\">";
            $tm = time();
            $ramas = $timeout - $tm;
      $rmsg = gettimemsg($ramas);
            echo "<img src=\"p.gif\" alt=\"!\"/> <b>ANTIFLOOD CONTROL!</b><br/>
			<br/>Please wait for <b>$rmsg</b> <br/><br/><img src=\"../avatars/prev.gif\" alt=\"&#171\"> <a href=\"register.php\">Back To Registration</a><br/><br/>";
echo "</div>";
include("int.php");
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo  "</body>";
exit();
        }else{
if(!canreg())
{
    echo "<div class=\"header\" aling=\"center\"><img src=\"images/notok.gif\" alt=\"X\"/><br/><b>Error!<b></div><br/>";
echo "<div class=\"shout2\" align=\"left\">";
echo "Registration for this IP range is disabled at the moment, please check later.<br/><br/>";
echo "</div>";
include("int.php");
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo  "</body>";
exit();
}else{
if(!empty($_REQUEST['act']) && $_REQUEST['act'] == $_REQUEST['code'] && $_REQUEST['code'] !== "" ) {
echo "<div class=\"header\" align=\"center\"><img src=\"FireBD.png\" alt=\"$sitename\"><br/><b>Registration Center</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
$uid= mysql_real_escape_string($_POST['uid']);
$pwd= mysql_real_escape_string($_POST['pwd']);
$year= mysql_real_escape_string($_POST['year']);
$month= mysql_real_escape_string($_POST['month']);
$day= mysql_real_escape_string($_POST['day']);
$usx= mysql_real_escape_string($_POST['usx']);
$email = mysql_real_escape_string($_POST['email']);
$uloc= mysql_real_escape_string($_POST['uloc']);
$abtme = mysql_real_escape_string($_POST['abtme']);
$country = mysql_real_escape_string($_POST['country']);
$phone= mysql_real_escape_string($_POST['phone']);
if(trim($uid)=="")
{
    echo "<img src=\"p.gif\" alt=\"!\"> Username Empty. You Have Missed It Completely. Please Type Your Name.<br/><br/><img src=\"../avatars/prev.gif\" alt=\"&#171\"> <a href=\"register.php\">Back To Registration</a><br/><br/>";
}else if(trim($pwd)=="")
{
    echo "<img src=\"p.gif\" alt=\"!\"> Password Empty. You Have Missed It Completely. Please Type Your Name.<br/><br/><img src=\"../avatars/prev.gif\" alt=\"&#171\"> <a href=\"register.php\">Back To Registration</a><br/><br/>";
}else if(trim($pwd)=="")
{
   echo "<img src=\"p.gif\" alt=\"!\"> Password Is Empty. You Have Missed It Completely. Please Type Your Password.<br/><img src=\"../avatars/prev.gif\" alt=\"&#171\"> <a href=\"register.php\">Back To Registration</a><br/><br/>";
}else if(trim($email)=="")
{
   echo "<img src=\"p.gif\" alt=\"!\"> Email Empty. You Have Missed It Completely. Please Type Your Email Address.<br/><br/><img src=\"../avatars/prev.gif\" alt=\"&#171\"> <a href=\"register.php\">Back To Registration</a><br/><br/>";
}else if((isregblocked($uid)) || (isnickblocked($uid)) || (isspam($uid)))
{
   echo "<img src=\"p.gif\" alt=\"!\"> Username is not valid!<br/><br/><img src=\"../avatars/prev.gif\" alt=\"&#171\"> <a href=\"register.php\">Back To Registration</a><br/><br/>";
}else if(strlen($uid)<4)
{
    echo "<img src=\"p.gif\" alt=\"!\"> Username must be 4 characters or more.<br/><br/><img src=\"../avatars/prev.gif\" alt=\"&#171\"> <a href=\"register.php\">Back To Registration</a><br/><br/>";
}else if(strlen($pwd)<4)
{
   echo "<img src=\"p.gif\" alt=\"!\"> Password must be 4 characters or more.<br/><br/><img src=\"../avatars/prev.gif\" alt=\"&#171\"> <a href=\"register.php\">Back To Registration</a><br/><br/>";
}else if(checknick($uid)==1)
{
echo "<img src=\"p.gif\" alt=\"!\"> Username is reserved for Admins of the site.<br/><br/><img src=\"../avatars/prev.gif\" alt=\"&#171\"> <a href=\"register.php\">Back To Registration</a><br/><br/>";
}else if(checknick($uid)==2)
{
echo "<img src=\"p.gif\" alt=\"!\"> Please choose an appropriate username.<br/><br/><img src=\"../avatars/prev.gif\" alt=\"&#171\"> <a href=\"register.php\">Back To Registration</a><br/><br/>";
}else if(register($uid,$pwd,$year,$month,$day,$usx,$uloc,$email,$ubr,$abtme,$country,$phone)==1)
{
    echo "<img src=\"p.gif\" alt=\"!\"> Username already in use, choose a different one.<br/><br/><img src=\"../avatars/prev.gif\" alt=\"&#171\"> <a href=\"register.php\">Back To Registration</a><br/><br/>";
}else if(register($uid,$pwd,$year,$month,$day,$usx,$uloc,$email,$ubr,$abtme,$country,$phone)==2)
{
   echo "<img src=\"p.gif\" alt=\"!\"> Unknown mysql error. We will fix it as soon as we can. Please try again later.<br/><br/><img src=\"../avatars/prev.gif\" alt=\"&#171\"> <a href=\"register.php\">Back To Registration</a><br/><br/>";
}else{
echo "<div class=\"shout2\" align=\"left\">";
  echo "<img src=\"../images/ok.gif\" alt=\"o\"/> Registration Completed Successfully!<br/><br/>";
  echo "<br/><b>Username: </b>$uid<br/>";
  echo "<b>Password: </b>$pwd<br/>";
  echo "<a href=\"login.php?loguid=$uid&amp;logpwd=$pwd\"><img src=\"../avatars/next.gif\" alt=\"&#187;\"/>";
  echo "<b> Login Now</b></a><br/><br/>";
echo "<hr>";
echo "<img src=\"p.gif\" alt=\"!\"> You Are Now Registered Here. Hope You Are Agreed With The <a href=\"terms.php\">Terms Of Use</a><br/> Of LovelyBD.";
}
echo "</div>";
include("int.php");
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
}else{
?>
<?php
$start = microtime(true);
echo "<div class=\"header\" align=\"left\">";
echo "<img src=\"FireBD.png\" alt=\"[FireBD.NeT]\" width=\"240\" height=\"50\">";
echo "<br/><b>Registration Center </b> $sitename</center>";
echo "</div>";
echo "<div class=\"shout2\">";
echo "<center><b>Please <a href=\"main.php\">Login Here</a> If You Already Have An Account!</center></b><br/><br/><hr>";
echo "<img src=\"p.gif\" alt=\"*\"> 
Allowed characters in username and password  are a-z, 0-9, and -_ <br/>
<img src=\"p.gif\" alt=\"*\"> 
Username and Password must contain at least 4 characters<br/>
<img src=\"p.gif\" alt=\"*\"> 
Username must not begin with any symbols or numbers<br/>
<img src=\"p.gif\" alt=\"*\"> 
Username must not contain capitals<br/>
<img src=\"p.gif\" alt=\"*\"> 
Your alternative email will be used to reset password if you forget your password!<br/>";
echo "<hr>";
$code = substr(md5(time()),0,5);
echo "<div align=\"left\"><form action=\"register.php\" method=\"post\">
Username:<br/> <input name=\"uid\" format=\"*x\" maxlength=\"11\"/><br/>";
echo "Password:<br/> <input type=\"password\" name=\"pwd\" format=\"*x\" maxlength=\"20\"/><br/>";
echo "Date Of Birth:<br/>";
echo "<select name=\"day\" value=\"01\">";
echo "<option value=\"01\">1</option>";
echo "<option value=\"02\">2</option>";
echo "<option value=\"03\">3</option>";
echo "<option value=\"04\">4</option>";
echo "<option value=\"05\">5</option>";
echo "<option value=\"06\">6</option>";
echo "<option value=\"07\">7</option>";
echo "<option value=\"08\">8</option>";
echo "<option value=\"09\">9</option>";
echo "<option value=\"10\">10</option>";
echo "<option value=\"11\">11</option>";
echo "<option value=\"12\">12</option>";
echo "<option value=\"13\">13</option>";
echo "<option value=\"14\">14</option>";
echo "<option value=\"15\">15</option>";
echo "<option value=\"16\">16</option>";
echo "<option value=\"17\">17</option>";
echo "<option value=\"18\">18</option>";
echo "<option value=\"19\">19</option>";
echo "<option value=\"20\">20</option>";
echo "<option value=\"21\">21</option>";
echo "<option value=\"22\">22</option>";
echo "<option value=\"23\">23</option>";
echo "<option value=\"24\">24</option>";
echo "<option value=\"25\">25</option>";
echo "<option value=\"26\">26</option>";
echo "<option value=\"27\">27</option>";
echo "<option value=\"28\">28</option>";
echo "<option value=\"29\">29</option>";
echo "<option value=\"30\">30</option>";
echo "<option value=\"31\">31</option>";
echo "</select>";
echo "<select name=\"month\" value=\"01-\">";
echo "<option value=\"01-\">Jan</option>";
echo "<option value=\"02-\">Feb</option>";
echo "<option value=\"03-\">Mar</option>";
echo "<option value=\"04-\">Apr</option>";
echo "<option value=\"05-\">May</option>";
echo "<option value=\"06-\">Jun</option>";
echo "<option value=\"07-\">Jul</option>";
echo "<option value=\"08-\">Aug</option>";
echo "<option value=\"09-\">Sep</option>";
echo "<option value=\"10-\">Oct</option>";
echo "<option value=\"11-\">Nov</option>";
echo "<option value=\"12-\">Dec</option>";
echo "</select>";
echo "<select name=\"year\" value=\"2010-\">";
echo "<option value=\"2010-\">2010</option>";
echo "<option value=\"2009-\">2009</option>";
echo "<option value=\"2008-\">2008</option>";
echo "<option value=\"2007-\">2007</option>";
echo "<option value=\"2006-\">2006</option>";
echo "<option value=\"2005-\">2005</option>";
echo "<option value=\"2004-\">2004</option>";
echo "<option value=\"2003-\">2003</option>";
echo "<option value=\"2002-\">2002</option>";
echo "<option value=\"2001-\">2001</option>";
echo "<option value=\"2000-\">2000</option>";
echo "<option value=\"1999-\">1999</option>";
echo "<option value=\"1998-\">1998</option>";
echo "<option value=\"1997-\">1997</option>";
echo "<option value=\"1996-\">1996</option>";
echo "<option value=\"1995-\">1995</option>";
echo "<option value=\"1994-\">1994</option>";
echo "<option value=\"1993-\">1993</option>";
echo "<option value=\"1992-\">1992</option>";
echo "<option value=\"1991-\">1991</option>";
echo "<option value=\"1990-\">1990</option>";
echo "<option value=\"1989-\">1989</option>";
echo "<option value=\"1988-\">1988</option>";
echo "<option value=\"1987-\">1987</option>";
echo "<option value=\"1986-\">1986</option>";
echo "<option value=\"1985-\">1985</option>";
echo "<option value=\"1984-\">1984</option>";
echo "<option value=\"1983-\">1983</option>";
echo "<option value=\"1982-\">1982</option>";
echo "<option value=\"1981-\">1981</option>";
echo "<option value=\"1980-\">1980</option>";
echo "<option value=\"1979-\">1979</option>";
echo "<option value=\"1978-\">1978</option>";
echo "<option value=\"1977-\">1977</option>";
echo "<option value=\"1976-\">1976</option>";
echo "<option value=\"1975-\">1975</option>";
echo "<option value=\"1974-\">1974</option>";
echo "<option value=\"1973-\">1973</option>";
echo "<option value=\"1972-\">1972</option>";
echo "<option value=\"1971-\">1971</option>";
echo "<option value=\"1970-\">1970</option>";
echo "<option value=\"1969-\">1969</option>";
echo "<option value=\"1968-\">1968</option>";
echo "</select><br/>";
echo "Gender:<br/>";
echo "<select name=\"usx\" value=\"M\">";
echo "<option value=\"M\">Male</option>";
echo "<option value=\"F\">Female</option>";
echo "</select><br/>";
echo "Country:<br/><select name=\"country\" value=\"Bangladesh\">";
echo "<option value=\"Bangladesh\">Bangladesh</option>
<option value=\"India\">India</option><option value=\"Indonesia\">Indonesia</option>
<option value=\"Johor\">Johor</option>
<option value=\"Kedah\">Kedah</option>
<option value=\"Kelantan\">Kelantan</option>
<option value=\"Kuala Lumpur\">Kuala Lumpur</option>
<option value=\"Melaka\">Melaka</option>
<option value=\"Negeri Sembilan\">Negeri Sembilan</option>
<option value=\"Pahang\">Pahang</option>
<option value=\"Pulau Pinang\">Pulau Pinang</option>
<option value=\"Perak\">Perak</option>
<option value=\"Perlis\">Perlis</option>
<option value=\"Sabah\">Sabah</option>
<option value=\"Sarawak\">Sarawak</option>
<option value=\"Selangor\">Selangor</option>
<option value=\"Terengganu\">Terengganu</option>";
echo "</select><br/>";
echo "Location: <br/><input name=\"uloc\"  maxlength=\"100\"/><br/>";
echo "About me:<br/><input name=\"abtme\" maxlength=\"1000\"/><br/>";
echo "Email Address (Must Be Valid):<br/> <input name=\"email\"  maxlength=\"100\"/><br/>";
echo "Contact Number: (Optional, But Must Be Valid If Entered):<br/> <input name=\"phone\"  maxlength=\"100\"/><br/>";
echo "Registration Code: <b> $code</b><br/>";
echo "<input type='hidden' name=\"act\" value=\"$code\"/>";
echo "<input name=\"code\" type=\"text\" value=\"\"/><br/><br/>";
echo "<input type=\"submit\" value=\"Register\"></form><br/>";
echo "<hr>";
echo "<img src=\"p.gif\" alt=\"!\"> Register Only If You Agree With The <a href=\"terms.php\">Terms Of Use</a> Of $sitename."; 
echo "</div></div>";
include("int.php");
echo "<div class=\"shout2\" align=\"center\">";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "<br/>";
echo "</div>";
echo "</div>";
echo "</body>";
exit();
}}}
?>
</html>