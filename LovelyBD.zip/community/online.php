<?php
session_start();
include("config.php");
include("core.php");  connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo '<head>';
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"title\" content=\"FireBD.NeT\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From Shahos: Don't Try To Hack OR else :P\">
<meta name=\"keywords\" content=\"Site Desined By Shahos :) :)\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/></head>";
echo "<body>";
$action = $_GET["action"]; $sid = $_SESSION["sid"];
$page = $_GET["page"];
$who = $_GET["who"];
$uid = getuid_sid($sid);
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();
//////////////////Banned System Updated By CJ UDAY :)
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please With Contact Us <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "<p align=\"left\"><a href=\"".$_SERVER['HTTP_REFFERER']."\">Back</a><br/><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php"); 
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
///////////////////Deactivated Account By CJ UDAY :)
          if(isdeactivated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  <b>Your Account Has Been Deactivated Forever.<br/>And It Will Be Never Activate!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
///////////////////Validation By CJ UDAY :)
					if(isvalidated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  You Are Not Validated!<br/>We are checking your ip and browser<br/>
	  This could take up to 15 munites pls be patient and try again soon<br/>Please try again later...<br/><b>Thank You</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
/////////////////////////////Online List Updated By CJ UDAY :)
if($action=="online")
{
  addonline(getuid_sid($sid),"Viewing Online List","online.php?action=online");
  $wh = subnick(getnick_uid($uid));
    echo "<head>";
    echo "<title>$wh@View Online List</title>";
   echo "</head>";
    echo "<body>";
    echo "<div class=\"header\" align=\"left\">";
    echo "<img src=\"FireBD.png\" alt=\"$sitename\" type=\"logo\" width=\"240\" height=\"50\"/><br/>";
		echo "<b>View Online List</b></div>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
		echo "</div>";
		
						echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
    if($page=="" || $page<=0)$page=1;
    $num_items = getnumonline();
    $items_per_page= 10;
    $num_pages = ceil($num_items/$items_per_page);
    if($page>$num_pages)$page= $num_pages;
    $limit_start = ($page-1)*$items_per_page;
    $sql = "SELECT
            a.name,a.cyberpowereragon, b.place, b.userid, a.vip, a.profilemsg, b.placedet FROM ibwff_users a
            INNER JOIN ibwff_online b ON a.id = b.userid
            GROUP BY 1,2
            LIMIT $limit_start, $items_per_page
    ";
  echo "<p align=\"left\">";
  $items = mysql_query($sql);
    while ($item = mysql_fetch_array($items))
    {
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='".subnick($item[0])."'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/> ";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/> ";}
if($sex[0]==""){$usersex = "";}
	$avlink = getavatar($item[3]);
if($avlink=="")
{
 $avt =  "$usersex";
}else{
 $avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"icon\" width=\"23\" height=\"18\"/>";
}$noi = mysql_fetch_array(mysql_query("SELECT lastact FROM ibwff_users WHERE id='".$item[3]."'"));
$remain = time() - $noi[0];
$idle = gettimemsg($remain);
$text = parsepm($item[5], $sid);
	    $sql3 = "SELECT name FROM ibwff_users WHERE id=$item[3]";
	    $sql33 = mysql_query($sql3);
	    $item3 = mysql_fetch_array($sql33);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nicks = "<font color=\"blue\"><b>".subnick($item[0])."</b></font>";}
if($sex[0]=="F"){$nicks = "<font color=\"deeppink\"><b>".subnick($item[0])."</b></font>";}
if($sex[0]==""){$nicks = "";}
          $lnk ="<a href=\"profile.php?who=$item[3]\">$avt$nicks</a>";
    if($item[1]==0)
      {
	  $status = getstatus(getuid_nick($item[0]));
        $item[1] = "$status";
      }elseif($item[1]==1)
      {
        $item[1] = "Moderator!";
      }else if($item[1]==2)
      {
        $item[1] = "Junior Moderator!";
      }else if($item[1]==3)
      {
        $item[1] = "Senior Moderator!";
      }else if($item[1]==4)
      {
        $item[1] = "Head Moderator!";
      }else if($item[1]==5)
      {
        $item[1] = "Administrator!";
     }else if($item[1]==7)
      {
        $item[1] = "Advisor!";
     }else if($item[1]==6)
      {
        $item[1] = "Autobot!";      }
 if($item[4]=='1')
        {
          $item[1] = "VIP!";
        }
		if(isvalidated($item[3]))
		{
		echo "";
		}else{
 echo "$lnk <b>($item[1])</b> <a href=\"$item[6]\">&#187; $item[2]</a><br/><small>[Idle: $idle]</small><br/><br/>";
}
}
    }
   if($page>1)
    {
      $ppage = $page-1;
      echo "<a href=\"online.php?action=$action&page=$ppage\">&#171;-Prev</a> ";
    }
    if($page<$num_pages)
    {
      $npage = $page+1;
      echo "<a href=\"online.php?action=$action&page=$npage\">Next-&#187;</a>";
    }
        echo "<small><br/>Page - $page/$num_pages</small><br/>";
    if($num_pages>2)
    {
	    $rets = "<form action=\"online.php\" method=\"get\">";
		$rets .= "<p align=\"left\">";
        $rets .= "<input name=\"page\" style=\"-wap-input-format: '*N'\" size=\"2\"/>";
        $rets .= "<input type=\"hidden\" name=\"action\" value=\"$action\"/>";
        $rets .= "<input type=\"hidden\" name=\"sid\" value=\"$sid\"/>";
        $rets .= "<input type=\"submit\" value=\"Go To Page\"/>";
        $rets .= "</form>";
        echo $rets;
    }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
//////////////////////////////////////////////////////////////////Male Online by CJ UDAY :-)
else if($action=="monline")
{
  addonline(getuid_sid($sid),"Viewing Male Online List","online.php?action=$action");
  $wh = subnick(getnick_uid($uid));
    echo "<head>";
    echo "<title>$wh@View Male Online List</title>";
    echo "</head>";
    echo "<body>";
    echo "<div class=\"header\" align=\"left\">";
    echo "<img src=\"FireBD.png\" alt=\"$sitename\" type=\"logo\" width=\"240\" height=\"50\"/><br/>";
			echo "<b>View Male Online List</b></div>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
			
						echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
    if($page=="" || $page<=0)$page=1;
    $num_items = getnumonline();
    $items_per_page= 10;
    $num_pages = ceil($num_items/$items_per_page);
    if($page>$num_pages)$page= $num_pages;
    $limit_start = ($page-1)*$items_per_page;    $sql = "SELECT
            a.name,b.place, b.userid, sex, cyberpowereragon, b.placedet FROM ibwff_users a
            INNER JOIN ibwff_online b ON a.id = b.userid WHERE a.sex='M'
            GROUP BY 1,2
            LIMIT $limit_start, $items_per_page
    ";
    $items = mysql_query($sql);
while ($item = mysql_fetch_array($items))
    {
      if ($item[3]=="M"){
      $icon = "<img src=\"../avatars/male.gif\" alt=\"M\"/>";
      }else
      if ($item[3]=="F"){
      $icon = "<img src=\"../avatars/female.gif\" alt=\"F\"/>";
      }
	$avlink = getavatar($item[2]);
if($avlink=="")
{
 $avt =  "$icon";
}else{
 $avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"avatar\" width=\"18\" height=\"23\"/>";
}
$noi = mysql_fetch_array(mysql_query("SELECT lastact FROM ibwff_users WHERE id='".$item[2]."'"));
$remain = time() - $noi[0];
$idle = gettimemsg($remain);
         $lnk ="<a href=\"profile.php?who=$item[2]\">$avt<font color=\"blue\"><b>".subnick($item[0])."</b></font></a>";
		if(isvalidated($item[2]))
		{
		echo "";
		}else{
  echo "$lnk  <b>(".getstatus($item[2]).")</b> &#187; <a href=\"$item[5]\"> $item[1] </a> <br/><small>[Idle :$idle]</small><br/><br/>";
}
    }
    if($page>1)
    {
      $ppage = $page-1;
      echo "<a href=\"online.php?action=monline&page=$ppage\">&#171;-Prev</a> ";
    }
    if($page<$num_pages)
    {
      $npage = $page+1;
      echo "<a href=\"online.php?action=monline&page=$npage\">Next-&#187;</a>";
    }
echo "<small><br/>Page - $page/$num_pages</small><br/>";
    if($num_pages>2)
    {
	    $rets = "<form action=\"online.php\" method=\"get\">";
		$rets .= "<p align=\"left\">";
        $rets .= "<input name=\"page\" style=\"-wap-input-format: '*N'\" size=\"2\"/>";
        $rets .= "<input type=\"hidden\" name=\"action\" value=\"$action\"/>";
        $rets .= "<input type=\"hidden\" name=\"sid\" value=\"$sid\"/>";
   $rets .= "<input type=\"submit\" value=\"Go To Page\"/>";
        $rets .= "</form>";
        echo $rets;
    }
    echo "</small></p>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
////////////////////////////////////Female Online By CJ UDAY :)
else if($action=="fonline")
{
   addonline(getuid_sid($sid),"Viewing Female Online List","online.php?action=$action");
   $wh = subnick(getnick_uid($uid));
    echo "<head>";
    echo "<title>$wh@View Female List</title>";
   echo "</head>";
    echo "<body>";
    echo "<div class=\"header\" align=\"left\">";
    echo "<img src=\"FireBD.png\" alt=\"$sitename\" type=\"logo\" width=\"240\" height=\"50\"/><br/>";
			echo "<b>View Female Online List</b></div>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
						
						echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
   if($page=="" || $page<=0)$page=1;
    $num_items = getnumonline();
    $items_per_page= 10;
    $num_pages = ceil($num_items/$items_per_page);
    if($page>$num_pages)$page= $num_pages;
    $limit_start = ($page-1)*$items_per_page;
    $sql = "SELECT
            a.name, b.place, b.userid, sex, cyberpowereragon FROM ibwff_users a
            INNER JOIN ibwff_online b ON a.id = b.userid WHERE a.sex='F'
            GROUP BY 1,2
            LIMIT $limit_start, $items_per_page
    ";
    $items = mysql_query($sql);
while ($item = mysql_fetch_array($items))
    {
      if ($item[3]=="M"){
      $icon = "<img src=\"../avatars/male.gif\" alt=\"M\"/>";
      }else
      if ($item[3]=="F"){
      $icon = "<img src=\"../avatars/female.gif\" alt=\"F\"/>";
      }
	$avlink = getavatar($item[2]);
if($avlink=="")
{
 $avt =  "$icon";
}else{
 $avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"avatar\" width=\"30\"/>";
}
$noi = mysql_fetch_array(mysql_query("SELECT lastact FROM ibwff_users WHERE id='".$item[2]."'"));
$remain = time() - $noi[0];
$idle = gettimemsg($remain);
         $lnk ="<a href=\"profile.php?who=$item[2]\">$avt<font color=\"deeppink\"><b>".subnick($item[0])."</b></font></a>";
		if(isvalidated($item[2]))
		{
		echo "";
		}else{
  echo "$lnk <b>(".getstatus($item[2]).")</b> &#187; <a href=\"$item[5]\"> $item[1] </a> <br/><small>[Idle :$idle]</small><br/><br/>";
    }
    }
    if($page>1)
    {
      $ppage = $page-1;
      echo "<a href=\"online.php?action=fonline&page=$ppage\">&#171;-Prev</a> ";
    }
    if($page<$num_pages)
    {
      $npage = $page+1;
      echo "<a href=\"online.php?action=fonline&page=$npage\">Next-&#187;</a>";
    }
        echo "<small><br/>Page - $page/$num_pages</small><br/>";
    if($num_pages>2)
    {
	    $rets = "<form action=\"online.php\" method=\"get\">";
		$rets .= "<p align=\"left\">";
        $rets .= "<input name=\"page\" style=\"-wap-input-format: '*N'\" size=\"2\"/>";
        $rets .= "<input type=\"hidden\" name=\"action\" value=\"$action\"/>";
        $rets .= "<input type=\"hidden\" name=\"sid\" value=\"$sid\"/>";
        $rets .= "<input type=\"submit\" value=\"Go To Page\"/>";
        $rets .= "</form>";
        echo $rets;
    }
    echo "</small></p>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
/////////////////////////////////Staff Online By CJ UDAY :)
else if($action=="stfol")
{
  addonline(getuid_sid($sid),"Viewing Staff Online list","online.php?action=$action");
  $wh = subnick(getnick_uid($uid));
    echo "<head>";
    echo "<title>$wh@View Staff Online List</title>";
    echo "</head>";
    echo "<body>";
    echo "<div class=\"header\" align=\"left\">";
    echo "<img src=\"FireBD.png\" alt=\"$sitename\" type=\"logo\" width=\"240\" height=\"50\"/><br/>";
			echo "<b>View Staff Online List</b></div>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							
						echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
   echo "<p align=\"left\">";
$timeon = time() - 3600;
    if($page=="" || $page<=0)$page=1;
  $noi = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE showonline>'0' AND cyberpowereragon>'0' AND lastact>'".$timeon."'"));
    $num_items = $noi[0];
    $items_per_page= 10;
    $num_pages = ceil($num_items/$items_per_page);
    if($page>$num_pages)$page= $num_pages;
    $limit_start = ($page-1)*$items_per_page;
    if($limit_start<0)$limit_start=0;
   $sql = "
    SELECT name, cyberpowereragon, id, showonline FROM ibwff_users WHERE lastact>'".$timeon."' AND cyberpowereragon>'0' AND cyberpowereragon<'5'
           ORDER BY cyberpowereragon DESC LIMIT $limit_start, $items_per_page
    ";
    $items = mysql_query($sql);
    while ($item = mysql_fetch_array($items))
    {
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='".subnick($item[0])."'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/> ";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/> ";}
if($sex[0]==""){$usersex = "";}
	$avlink = getavatar($item[2]);
if($avlink=="")
{
 $avt =  "$usersex";
}else{
 $avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"icon\" width=\"23\" height=\"18\"/>";
}
$noi = mysql_fetch_array(mysql_query("SELECT lastact FROM ibwff_users WHERE id='".$item[2]."'"));
$remain = time() - $noi[0];
$idle = gettimemsg($remain);
	    $sql2 = "SELECT userid, place , placedet FROM ibwff_online WHERE userid=$item[2]";
	    $sql22 = mysql_query($sql2);
	    $item2 = mysql_fetch_array($sql22);
 	    $sql3 = "SELECT name FROM ibwff_users WHERE id=$item[2]";
	    $sql33 = mysql_query($sql3);
	    $item3 = mysql_fetch_array($sql33);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nicks = "<font color=\"blue\"><b>".subnick($item[0])."</b></font>";}
if($sex[0]=="F"){$nicks = "<font color=\"deeppink\"><b>".subnick($item[0])."</b></font>";}
if($sex[0]==""){$nicks = "";}
      $lnk = "<a href=\"profile.php?who=$item[2]\">$avt$nicks</a>";
if($item[1]==1)
{      $item[1] = "<b>Moderator!</b>";
      }if($item[1]==2)
      {
        $item[1] = "<b>Junior Moderator!</b>";
      }else if($item[1]==3)
      {
        $item[1] = "<b>Senior Moderator!</b>";
      }else if($item[1]==4)
      {
        $item[1] = "<b>Head Moderator!</b>";
      }else if($item[1]==5)
      {
        $item[1] = "<b>Administrator!</b>";
    }else if($item[1]==6)
      {
        $item[1] = "<b>Autobot!</b>";
      }
echo "$lnk <b>($item[1])</b> &#187; <a href=\"$item2[2]\"> $item2[1] </a> <br/><small>[Idle :$idle]</small><br/><br/>";
	}
	}
    if($page>1)
    {
      $ppage = $page-1;
      echo "<a href=\"online.php?action=stfol&page=$ppage\">&#171;-Prev</a> ";
    }
    if($page<$num_pages)
    {
      $npage = $page+1;
      echo "<a href=\"online.php?action=stfol&page=$npage\">Next-&#187;</a>";
    }
       echo "<small><br/>Page - $page/$num_pages</small><br/>";
if($num_pages>2)
    {
	    $rets = "<form action=\"online.php\" method=\"get\">";
		$rets .= "<p align=\"left\">";
        $rets .= "<input name=\"page\" style=\"-wap-input-format: '*N'\" size=\"2\"/>";
        $rets .= "<input type=\"hidden\" name=\"action\" value=\"$action\"/>";
        $rets .= "<input type=\"hidden\" name=\"sid\" value=\"$sid\"/>";
	$rets .= "<input type=\"submit\" value=\"Go To Page\"/>";
        $rets .= "</form>";
        echo $rets;
    }
    echo "</small></p>";
echo "</div></div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
/////////////////////////////////Vip Updated By CJ UDAY :)
else if($action=="vipol")
{
  addonline(getuid_sid($sid),"Viewing VIP Online List","online.php?action=$action");
  $wh = subnick(getnick_uid($uid));
    echo "<head>";
    echo "<title>$wh@View VIP Online List</title>";
    echo "</head>";
    echo "<body>";
    echo "<div class=\"header\" align=\"left\">";
    echo "<img src=\"FireBD.png\" alt=\"$sitename\" type=\"logo\" width=\"240\" height=\"50\"/><br/>";
			echo "<b>View VIP Online List</b></div>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
						
						echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");	
    if($page=="" || $page<=0)$page=1;
  $timeon = time() - 3600;
  $Voi = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE vip>'0' AND lastact>'".$timeon."'"));
    $num_items = $Voi[0];
    $items_per_page= 10;
    $num_pages = ceil($num_items/$items_per_page);
    if($page>$num_pages)$page= $num_pages;
    $limit_start = ($page-1)*$items_per_page;
    if($limit_start<0)$limit_start=0;
    $sql = "
    SELECT name, cyberpowereragon, id , validated FROM ibwff_users WHERE vip>'0' AND lastact>'".$timeon."'
            LIMIT $limit_start, $items_per_page
    ";
    $items = mysql_query($sql);
    while ($item = mysql_fetch_array($items))
    {
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='".subnick($item[0])."'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/> ";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/> ";}
if($sex[0]==""){$usersex = "";}
	$avlink = getavatar($item[2]);
if($avlink=="")
{
 $avt =  "$usersex";
}else{
 $avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"avatar\" width=\"30\"/>";
}
$noi = mysql_fetch_array(mysql_query("SELECT lastact FROM ibwff_users WHERE id='".$item[2]."'"));
$remain = time() - $noi[0];
$idle = gettimemsg($remain);
  $sql2 = "SELECT userid, place , placedet FROM ibwff_online WHERE userid=$item[2]";
	    $sql22 = mysql_query($sql2);
	    $item2 = mysql_fetch_array($sql22);
	    $sql3 = "SELECT name FROM ibwff_users WHERE id=$item[2]";
	    $sql33 = mysql_query($sql3);
	    $item3 = mysql_fetch_array($sql33);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nick = "<font color=\"blue\"><b>".subnick($item[0])."</b></font>";}
if($sex[0]=="F"){$nick = "<font color=\"deeppink\"><b>".subnick($item[0])."</b></font>";}
if($sex[0]==""){$nick = "";}
       $lnk = "<a href=\"profile.php?who=$item[2]\">$avt$nick</a>";
 echo "$lnk <b>(".getstatus($item[2]).")</b> &#187; <a href=\"$item2[2]\"> $item2[1] </a> <br/><small>[Idle :$idle]</small><br/><br/>";
	   }
       }
    if($page>1)
    {
      $ppage = $page-1;
      echo "<a href=\"online.php?action=vipol&page=$ppage\">&#171;-Prev</a> ";
    }
    if($page<$num_pages)
    {
      $npage = $page+1;
      echo "<a href=\"onilne.php?action=vipol&page=$npage\">Next-&#187;</a>";
    }
        echo "<small><br/>Page - $page/$num_pages</small><br/>";
    if($num_pages>2)
    {
	    $rets = "<form action=\"online.php\" method=\"get\">";
		$rets .= "<p align=\"left\">";
        $rets .= "<input name=\"page\" style=\"-wap-input-format: '*N'\" size=\"2\"/>";
        $rets .= "<input type=\"hidden\" name=\"action\" value=\"$action\"/>";
        $rets .= "<input type=\"hidden\" name=\"sid\" value=\"$sid\"/>";
        $rets .= "<input type=\"submit\" value=\"Go To Page\"/>";
        $rets .= "</form>";
        echo $rets;
    }
echo "</small>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
/////////////////////////////////Premium User Updated BY CJ UDAY :)
else if($action=="puol")
{
  addonline(getuid_sid($sid),"Viewing Premium Online List","online.php?action=$action");
  $wh = subnick(getnick_uid($uid));
    echo "<head>";
    echo "<title>$wh@View Premium Online List</title>";
   echo "</head>";
    echo "<body>";
    echo "<div class=\"header\" align=\"left\">";
    echo "<img src=\"FireBD.png\" alt=\"$sitename\" type=\"logo\" width=\"240\" height=\"50\"/><br/>";
			echo "<b>View Premium Online List</b></div>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
						
						echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");	
    if($page=="" || $page<=0)$page=1;
  $timeon = time() - 3600;
  $Voi = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE pu>'0' AND lastact>'".$timeon."'"));
    $num_items = $Voi[0];
    $items_per_page= 10;
    $num_pages = ceil($num_items/$items_per_page);
    if($page>$num_pages)$page= $num_pages;
    $limit_start = ($page-1)*$items_per_page;
    if($limit_start<0)$limit_start=0;
    $sql = "
    SELECT name, cyberpowereragon, id FROM ibwff_users WHERE pu>'0' AND lastact>'".$timeon."'
            LIMIT $limit_start, $items_per_page
    ";
    $items = mysql_query($sql);
    while ($item = mysql_fetch_array($items))
    {
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='".subnick($item[0])."'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/> ";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/> ";}
if($sex[0]==""){$usersex = "";}
	$avlink = getavatar($item[2]);
if($avlink=="")
{
 $avt =  "$usersex";
}else{
 $avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"avatar\" width=\"30\"/>";
}
$noi = mysql_fetch_array(mysql_query("SELECT lastact FROM ibwff_users WHERE id='".$item[2]."'"));
$remain = time() - $noi[0];
$idle = gettimemsg($remain);
  $sql2 = "SELECT userid, place , placedet FROM ibwff_online WHERE userid=$item[2]";
	    $sql22 = mysql_query($sql2);
	    $item2 = mysql_fetch_array($sql22);
	    $sql3 = "SELECT name FROM ibwff_users WHERE id=$item[2]";
	    $sql33 = mysql_query($sql3);
	    $item3 = mysql_fetch_array($sql33);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nicks = "<font color=\"blue\"><b>".subnick($item[0])."</b></font>";}
if($sex[0]=="F"){$nicks = "<font color=\"deeppink\"><b>".subnick($item[0])."</b></font>";}
if($sex[0]==""){$nicks = "";}
       $lnk = "<a href=\"profile.php?who=$item[2]\">$avt$nicks</a>";
       echo "$lnk <b>(Premium Memeber!)</b> &#187; <a href=\"$item2[2]\"> $item2[1] </a> <br/><small>[Idle :$idle]</small><br/><br/>";
	   }
       }
    if($page>1)
    {
      $ppage = $page-1;
      echo "<a href=\"online.php?action=poul&page=$ppage\">&#171;-Prev</a> ";
    }
    if($page<$num_pages)
    {
      $npage = $page+1;
      echo "<a href=\"onilne.php?action=poul&page=$npage\">Next-&#187;</a>";
    }
    echo "<small><br/>Page - $page/$num_pages</small><br/>";
    if($num_pages>2)
    {
	    $rets = "<form action=\"online.php\" method=\"get\">";
		$rets .= "<p align=\"left\">";
        $rets .= "<input name=\"page\" style=\"-wap-input-format: '*N'\" size=\"2\"/>";
        $rets .= "<input type=\"hidden\" name=\"action\" value=\"$action\"/>";
        $rets .= "<input type=\"hidden\" name=\"sid\" value=\"$sid\"/>";
        $rets .= "<input type=\"submit\" value=\"Go To Page\"/>";
        $rets .= "</form>";
        echo $rets;
    }
echo "</small>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
/////////////////////////////////Top Online By CJ UDAY :)
else if($action=="toponl")
{
  addonline(getuid_sid($sid),"Viewing Top Members Online List","online.php?action=$action");
  $wh = subnick(getnick_uid($uid));
	    echo "<head>";
    echo "<title>$wh@View Top Members Online List</title>";
   echo "</head>";
    echo "<body>";
    echo "<div class=\"header\" align=\"left\">";
    echo "<img src=\"FireBD.png\" alt=\"$sitename\" type=\"logo\" width=\"240\" height=\"50\"/><br/>";
			echo "<b>Top Members Online List</b></div>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
						
  echo "<div class=\"shout2\" align=\"left\">";
  include("pm_by.php");
    if($page=="" || $page<=0)$page=1;
    $timeout = 3600;
  $timeon = time() - $timeout;
 $Voi = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE lastact>'".$timeon."' AND plusses>'".knightpoint()."'"));
	$num_items = $Voi[0];
    $items_per_page= 10;
    $num_pages = ceil($num_items/$items_per_page);
    if($page>$num_pages)$page= $num_pages;
    $limit_start = ($page-1)*$items_per_page;
    if($limit_start<0)$limit_start=0;
 $sql = "
SELECT name, cyberpowereragon, id FROM ibwff_users WHERE plusses>'".knightpoint()."' AND lastact>'".$timeon."'
 ORDER BY id LIMIT $limit_start, $items_per_page";
    $items = mysql_query($sql);
   while ($item = mysql_fetch_array($items))
    {
  $sql2 = "SELECT userid, place FROM ibwff_online WHERE userid=$item[2]";
	    $sql22 = mysql_query($sql2);
	    $item2 = mysql_fetch_array($sql22);
{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='".subnick($item[0])."'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/> ";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/> ";}
if($sex[0]==""){$usersex = "";}
	$avlink = getavatar($item[2]);
if($avlink=="")
{
 $avt =  "$usersex";
}else{
 $avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"avatar\" width=\"30\"/>";
}
$noi = mysql_fetch_array(mysql_query("SELECT lastact FROM ibwff_users WHERE id='".$item[2]."'"));
$remain = time() - $noi[0];
$idle = gettimemsg($remain);
  $sql2 = "SELECT userid, place , placedet FROM ibwff_online WHERE userid=$item[2]";
	    $sql22 = mysql_query($sql2);
	    $item2 = mysql_fetch_array($sql22);
	    $sql3 = "SELECT name FROM ibwff_users WHERE id=$item[2]";
	    $sql33 = mysql_query($sql3);
	    $item3 = mysql_fetch_array($sql33);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nicks = "<font color=\"blue\"><b>".subnick($item[0])."</b></font>";}
if($sex[0]=="F"){$nicks = "<font color=\"deeppink\"><b>".subnick($item[0])."</b></font>";}
if($sex[0]==""){$nicks = "";}
       $lnk = "<a href=\"profile.php?who=$item[2]\">$avt$nicks</a>";	   
       echo "$lnk &#187; <a href=\"$item2[2]\"> $item2[1] </a> <br/><small>[Idle :$idle]<br/><b>++ Level: ".gettitle($item2[0])." ++</b></small><br/><br/>";
	   }
       }

       }
    if($page>1)
    {
      $ppage = $page-1;
      echo "<a href=\"online.php?action=$action&page=$ppage\">&#171;-Prev</a> ";
    }
    if($page<$num_pages)
    {
      $npage = $page+1;
      echo "<a href=\"onilne.php?action=$action&page=$npage\">Next-&#187;</a>";
    }
    echo "<small><br/>Page - $page/$num_pages</small><br/>";
if($num_pages>2)
    {
	    $rets = "<form action=\"online.php\" method=\"get\">";
		$rets .= "<p align=\"left\">";
        $rets .= "<input name=\"page\" style=\"-wap-input-format: '*N'\" size=\"2\"/>";
        $rets .= "<input type=\"hidden\" name=\"action\" value=\"$action\"/>";
        $rets .= "<input type=\"hidden\" name=\"sid\" value=\"$sid\"/>";
   $rets .= "<input type=\"submit\" value=\"Go To Page\"/>";
        $rets .= "</form>";
        echo $rets;
    }
echo "<p align=\"left\">";
echo "* Top Online Depends On Members Online Time & Points!<br/>";
echo "</p>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
/////////////////////////////////From Bangladesh Onliners By CJ UDAY :)
else if($action=="bangladesh")
{
  addonline(getuid_sid($sid),"Viewing Regular Members(Bangladesh ) Online List","online.php?action=$action");

$wh = subnick(getnick_uid($uid));
	    echo "<head>";
    echo "<title>$wh@View Regular Members(Bangladesh) Online List</title>";
    echo "</head>";
    echo "<body>";
    echo "<div class=\"header\" align=\"left\">";
    echo "<img src=\"FireBD.png\" alt=\"$sitename\" type=\"logo\" width=\"240\" height=\"50\"/><br/>";
			echo "<b>Regular Members (Bangladesh) Online List</b></div>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
						
  echo "<div class=\"shout2\" align=\"left\">";
  include("pm_by.php");
    if($page=="" || $page<=0)$page=1;
    $timeout = 3600;
  $timeon = time()-$timeout;
  $count = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE country='Bangladesh' AND lastact>'".$timeon."'"));
    $num_items = $count[0] ;
    $items_per_page= 10;
    $num_pages = ceil($num_items/$items_per_page);
    if($page>$num_pages)$page= $num_pages;
    $limit_start = ($page-1)*$items_per_page;
    if($limit_start<0)$limit_start=0;
 $sql = "
SELECT name, cyberpowereragon, id, country FROM ibwff_users WHERE country='Bangladesh' AND lastact>'".$timeon."'
 LIMIT $limit_start, $items_per_page";
    $items = mysql_query($sql);
    while ($item = mysql_fetch_array($items))
    {
  $sql2 = "SELECT userid, place FROM ibwff_online WHERE userid=$item[2]";
	    $sql22 = mysql_query($sql2);
	    $item2 = mysql_fetch_array($sql22);
{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='".subnick($item[0])."'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/> ";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/> ";}
if($sex[0]==""){$usersex = "";}
	$avlink = getavatar($item[2]);
if($avlink=="")
{
 $avt =  "$usersex";
}else{
 $avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"avatar\" width=\"30\"/>";
}
$noi = mysql_fetch_array(mysql_query("SELECT lastact FROM ibwff_users WHERE id='".$item[2]."'"));
$remain = time() - $noi[0];
$idle = gettimemsg($remain);
  $sql2 = "SELECT userid, place , placedet FROM ibwff_online WHERE userid=$item[2]";
	    $sql22 = mysql_query($sql2);
	    $item2 = mysql_fetch_array($sql22);
	    $sql3 = "SELECT name FROM ibwff_users WHERE id=$item[2]";
	    $sql33 = mysql_query($sql3);
	    $item3 = mysql_fetch_array($sql33);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nicks = "<font color=\"blue\"><b>".subnick($item[0])."</b></font>";}
if($sex[0]=="F"){$nicks = "<font color=\"deeppink\"><b>".subnick($item[0])."</b></font>";}
if($sex[0]==""){$nicks = "";}
       $lnk = "<a href=\"profile.php?who=$item[2]\">$avt$nicks</a>";	   		if(isvalidated($item[2]))
		{
		echo "";
		}else{	
       echo "$lnk <b>(".getstatus($item2[0]).")</b> &#187; <a href=\"$item2[2]\"> $item2[1] </a> <br/><small>[Idle :$idle]</small><br/><br/>";
       }
	   }
       }
       }
if($page>1)
    {
      $ppage = $page-1;
      echo "<a href=\"online.php?action=$action&page=$ppage\">&#171;-Prev</a> ";
    }
    if($page<$num_pages)
    {
      $npage = $page+1;
      echo "<a href=\"onilne.php?action=$action&page=$npage\">Next-&#187;</a>";
    }
    echo "<small><br/>Page - $page/$num_pages</small><br/>";
    if($num_pages>2)
    {
	    $rets = "<form action=\"online.php\" method=\"get\">";
		$rets .= "<p align=\"left\">";
        $rets .= "<input name=\"page\" style=\"-wap-input-format: '*N'\" size=\"2\"/>";
        $rets .= "<input type=\"hidden\" name=\"action\" value=\"$action\"/>";
        $rets .= "<input type=\"hidden\" name=\"sid\" value=\"$sid\"/>";
        $rets .= "<input type=\"submit\" value=\"Go To Page\"/>";
        $rets .= "</form>";
        echo $rets;
    }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
//////////////////////Active User Today By CJ UDAY :)
else if($action=="actmem")
{
addonline(getuid_sid($sid),"Viewing Active Today","online.php?action=$action");
$wh = subnick(getnick_uid($uid));
    echo "<head>";
    echo "<title>$wh@View Active Today</title>";
    echo "</head>";
    echo "<body>";
    echo "<div class=\"header\" align=\"left\">";
    echo "<img src=\"FireBD.png\" alt=\"$sitename\" type=\"logo\" width=\"240\" height=\"50\"/><br/>";
			echo "<b>View Active Members List</b></div>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
		echo "</div>";
					
	echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
 $tm24 = time() - (24*60*60);
            $aut = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE lastact>'".$tm24."'"));
    if($page=="" || $page<=0)$page=1;
    $num_items = $aut[0];
    $items_per_page= 20;
    $num_pages = ceil($num_items/$items_per_page);
    if($page>$num_pages)$page= $num_pages;
    $limit_start = ($page-1)*$items_per_page;
    $sql = "SELECT name, sex, lastact, id FROM ibwff_users WHERE lastact>'".$tm24."' ORDER BY lastact DESC LIMIT $limit_start, $items_per_page";
$items = mysql_query($sql);
    while ($item = mysql_fetch_array($items))
    {
     if($item[1]==M)
  {
    $usex = "<img src=\"../avatars/male.gif\" alt=\"M\"/>";
  }else if($item[1]==F){
    $usex = "<img src=\"../avatars/female.gif\" alt=\"F\"/>";
  }
	    $sql2 = "SELECT name FROM ibwff_users WHERE id=$item[3]";
	    $sql22 = mysql_query($sql2);
	    $item2 = mysql_fetch_array($sql22);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item2[0]'"));
if($sex[0]=="M"){$usersex2 = "<font color=\"blue\"><b>".subnick($item[0])."</b></font>";}
if($sex[0]=="F"){$usersex2 = "<font color=\"deeppink\"><b>".subnick($item[0])."</b></font>";}
if($sex[0]==""){$usersex2 = "";}
if(isonline($item[3]))
    {
      $iml = "<font color=\"green\"/>online!</font>";
    }else{
        $iml = "<font color=\"red\"/>offline!</font>";
    }
$avlink = getavatar($item[3]);
if($avlink=="")
{
 $avt =  "$usex";
}else{
 $avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"icon\" width=\"23\" height=\"18\"/>";
}
$noi = mysql_fetch_array(mysql_query("SELECT lastact FROM ibwff_users WHERE id='".$item[3]."'"));
$remain = time() - $noi[0];
$idle = gettimemsg($remain);
   $lnk = "<a href=\"profile.php?who=$item[3]\">$avt$usersex2</a>";
   }
		if(isvalidated($item[3]))
		{
		echo "";
		}else{
              echo "$lnk <b>(".getstatus($item[3]).")</b> &#187; ".date("D d M y - H:i:s a", $item[2])." <small>$iml</small><br/>";
}
}
    if($page>1)
    {
      $ppage = $page-1;
      echo "<a href=\"online.php?action=actmem&page=$ppage\">&#171;-Prev</a> ";
    }
    if($page<$num_pages)
    {
      $npage = $page+1;
      echo "<a href=\"online.php?action=actmem&page=$npage\">Next-&#187;</a>";
    }
       echo "<small><br/>Page - $page/$num_pages</small><br/>";
if($num_pages>2)
    {
	    $rets = "<form action=\"online.php\" method=\"get\">";
		$rets .= "<p align=\"left\">";
        $rets .= "<input name=\"page\" style=\"-wap-input-format: '*N'\" size=\"2\"/>";
        $rets .= "<input type=\"hidden\" name=\"action\" value=\"$action\"/>";
        $rets .= "<input type=\"hidden\" name=\"sid\" value=\"$sid\"/>";
	$rets .= "<input type=\"submit\" value=\"Go To Page\"/>";
        $rets .= "</form>";
        echo $rets;
    }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
//////////////////////////////////Junior Member Online By CJ UDAY :)
else if($action=="jumem")
{
  addonline(getuid_sid($sid),"Viewing Junior Member Online list","online.php?action=$action");
  $wh = subnick(getnick_uid($uid));
    echo "<head>";
    echo "<title>$wh@View Junior Member Online List</title>";
    echo "</head>";
    echo "<body>";
    echo "<div class=\"header\" align=\"left\">";
    echo "<img src=\"FireBD.png\" alt=\"$sitename\" type=\"logo\" width=\"240\" height=\"50\"/><br/>";
			echo "<b>View Junior Member Online List</b></div>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							
						echo "<div class=\"shout2\" align=\"center\">";
			include("pm_by.php");	
	$memberpoint = memberpoint();
	$junmemberpoint = junmemberpoint();
	$senmemberpoint = senmemberpoint();
echo "<p align=\"left\">";
    if($page=="" || $page<=0)$page=1;
 $timeout = 3600;
  $timeon = time()-$timeout;
  $noi = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE totaltime>'".$junmemberpoint."' AND totaltime<'".$senmemberpoint."' AND lastact>'".$timeon."'"));
    $num_items = $noi[0];
    $items_per_page= 10;
    $num_pages = ceil($num_items/$items_per_page);
    if($page>$num_pages)$page= $num_pages;
    $limit_start = ($page-1)*$items_per_page;
    if($limit_start<0)$limit_start=0;
   $sql = "
    SELECT name, cyberpowereragon, id, showonline FROM ibwff_users WHERE lastact>'".$timeon."' AND totaltime>'".$junmemberpoint."' AND totaltime<'".$senmemberpoint."'
           ORDER BY plusses LIMIT $limit_start, $items_per_page
    ";
    $items = mysql_query($sql);
    while ($item = mysql_fetch_array($items))
    {
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='".subnick($item[0])."'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/> ";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/> ";}
if($sex[0]==""){$usersex = "";}
	$avlink = getavatar($item[2]);
if($avlink=="")
{
 $avt =  "$usersex";
}else{
 $avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"icon\" width=\"23\" height=\"18\"/>";
}
$noi = mysql_fetch_array(mysql_query("SELECT lastact FROM ibwff_users WHERE id='".$item[2]."'"));
$remain = time() - $noi[0];
$idle = gettimemsg($remain);
	    $sql2 = "SELECT userid, place , placedet FROM ibwff_online WHERE userid=$item[2]";
	    $sql22 = mysql_query($sql2);
	    $item2 = mysql_fetch_array($sql22);
	    $sql3 = "SELECT name FROM ibwff_users WHERE id=$item[2]";
	    $sql33 = mysql_query($sql3);
	    $item3 = mysql_fetch_array($sql33);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nicks = "<font color=\"blue\"><b>".subnick($item[0])."</b></font>";}
if($sex[0]=="F"){$nicks = "<font color=\"deeppink\"><b>".subnick($item[0])."</b></font>";}
if($sex[0]==""){$nicks = "";}
      $lnk = "<a href=\"profile.php?who=$item[2]\">$avt$nicks</a>";
    if($item[1]==0)
      {
	  $status = getstatus(getuid_nick($item[0]));
        $item[1] = "$status";
 }else if($item[1]==1)
      {
$lnk="";
        $item[1] = "<b>Junior Moderator!</b>";
      }else if($item[1]==2)
      {
$lnk="";
        $item[1] = "<b>Senior Moderator!</b>";
      }else if($item[1]==3)
      {
$lnk="";
        $item[1] = "<b>Head Moderator!</b>";
      }else if($item[1]==4)
      {
$lnk = "";
        $item[1] = "<b>Administrator!</b>";
    }else if($item[1]==6)
      {
$lnk = "";
        $item[1] = "<b>Autobot!</b>";
      }
 if($item[4]=='1')
        {
$lnk="";
          $item[1] = "VIP!";
        }
				if(isvalidated($item[2]) || isvip($item[2]) || ispu($item[2]) || ismod($item[2]) || isspu($item[2]))
		{
		echo "";
		}else{
    echo "$lnk <b>($item[1])</b> &#187; <a href=\"$item2[2]\"> $item2[1] </a> <br/><small>[Idle :$idle]</small><br/><br/>";
    }
	}
	}
    if($page>1)
    {
      $ppage = $page-1;
      echo "<a href=\"online.php?action=jumem&page=$ppage\">&#171;-Prev</a> ";
    }
    if($page<$num_pages)
    {
      $npage = $page+1;
      echo "<a href=\"online.php?action=jumem&page=$npage\">Next-&#187;</a>";
    }
       echo "<small><br/>Page - $page/$num_pages</small><br/>";
if($num_pages>2)
    {
	    $rets = "<form action=\"online.php\" method=\"get\">";
		$rets .= "<p align=\"left\">";
        $rets .= "<input name=\"page\" style=\"-wap-input-format: '*N'\" size=\"2\"/>";
        $rets .= "<input type=\"hidden\" name=\"action\" value=\"$action\"/>";
        $rets .= "<input type=\"hidden\" name=\"sid\" value=\"$sid\"/>";
   $rets .= "<input type=\"submit\" value=\"Go To Page\"/>";
        $rets .= "</form>";
        echo $rets;
    }
    echo "</small></p>";
echo "</div></div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
?>
</html>