<?php
session_start();
include("config.php");
include("core.php");  connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo '<head>';
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"title\" content=\"firebd.net\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From Shahos: Don't Try To Hack OR else :P\">
<meta name=\"keywords\" content=\"Site Desined By Shahos :) :)\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/></head>";
echo "<body>";
$action = $_GET["action"]; $sid = $_SESSION["sid"];
$uid = getuid_sid($sid);
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();
////////////////Ip Banned By CJ UDAY :)	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
    echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
echo "<br/>";
echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
$banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
$remain =  $banto[0] - time();
$rmsg = gettimemsg($remain);
echo "<b>Time Remaining: $rmsg</b><br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "</p>";
echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
//////////////////Banned System Updated By CJ UDAY :)
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please Contact <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
 echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
 echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
///////////////////Deactivated Account By CJ UDAY :)
          if(isdeactivated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  <b>Your Account Has Been Deactivated Forever.<br/>And It Will Be Never Activate!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
///////////////////Validation By CJ UDAY :)
					if(isvalidated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");  
        echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  You Are Not Validated!<br/>We are checking your ip and browser<br/>
	  This could take up to 15 munites pls be patient and try again soon<br/>Please try again later...<br/><b>Thank You</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
//////////////////////////////////Setting Created By CJ UDAY :)
if($action=="setting")
{
$uid = getuid_sid($sid);
addonline(getuid_sid($sid),"Viewing Account Setting","setting.php?action=$action");
    echo "<head>";
    echo "<title>View Account Setting</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
			echo "<b>Account Setting</b></div>";
			echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "&#187; <a href=\"setting.php?action=upf\">Update Basic Profile</a><br/>";
echo "&#187; <a href=\"advance.php\">Update Advance Profile</a><br/>";
echo "&#187; <a href=\"balance.php\">Update Account Balance</a><br/>";
echo "&#187; <a href=\"upavatar.php\">Upload Profile Picture</a><br/>";
echo "&#187; <a href=\"coverpic.php\">Upload Cover Picture</a><br/>";
echo "&#187; <a href=\"upload.php\">Upload Album Photo</a><br/>";
echo "&#187; <a href=\"setting.php?action=upfmsg\">Update Profile Message</a><br/>";
echo "&#187; <a href=\"mindstatus.php\">Update Mind Status</a><br/>";
echo "&#187; <a href=\"nickshop.php\">Update Display Name</a><br/>";
echo "&#187; <a href=\"titleshop.php\">Update Title Name</a><br/>";
echo "&#187; <a href=\"usershop.php\">Update Username</a><br/>";
echo "&#187; <a href=\"setting.php?action=chngpass\">Update Password</a><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
//Change Password CJ UDAY :-)
else if($action=="chngpass")
{
addonline(getuid_sid($sid),"Changing Password","setting.php?action=setting");
    echo "<head>";
    echo "<title>Update Password</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
			echo "<b>Update Password</b></div>";
			echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<form action=\"userproc.php?action=upwd\" method=\"post\">"; 
echo "<b>Old Password:</b><br/><input type=\"password\" name=\"opwd\" format=\"*x\" maxlength=\"15\"/><br/>";
echo "<b>New Password:</b><br/><input type=\"password\" name=\"npwd\" format=\"*x\" maxlength=\"15\"/><br/>";
echo "<b>Confirm Password:</b><br/><input type=\"password\" name=\"cpwd\" format=\"*x\" maxlength=\"15\"/><br/>";
echo "<input type=\"submit\" value=\"Change\"/>";
echo "</form>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
//////////////////////////////////////////By CJ UDAY :)
else if($action=="upfmsg")
{
addonline(getuid_sid($sid),"Updating Profile Messege","setting.php?action=$action");
    echo "<head>";
    echo "<title>Update Profile Messege</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Profile Message</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$pfmsg = mysql_fetch_array(mysql_query("SELECT profilemsg FROM ibwff_users WHERE id='".$uid."'"));
echo "<form action=\"setting.php?action=upolm\" method=\"post\">";
echo "<b>Profile Message:</b><br/> <input name=\"message\" maxlength=\"200\" value=\"$pfmsg[0]\"/><br/>";
echo "<input type=\"submit\" value=\"Update\"/>";
echo "</form>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
//////////////////////////////////////////Update Profile Messege By CJ UDAY :)
else if($action=="upolm")
{
addonline(getuid_sid($sid),"Updating Profile Messege","setting.php?action=$action");
$message = $_POST["message"];
echo "<head>";
    echo "<title>Updating Profile Messege</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
						echo "<div class=\"header\" align=\"center\">";
			echo "<b>Profile Message</b></div>";
						echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$res = mysql_query("UPDATE ibwff_users SET profilemsg='".$message."' WHERE id='".$uid."'");
if($res)
{
echo "<br/><img src=\"../avatars/ok.gif\" alt=\"o\"/>Your Profile Messege Updated Successfully!<br/><br/>";
$f = "[b]Subscribe Notification:[/b] ".subnick(getnick_uid($uid))." have updated profile message.";
subnot_uday($uid, $f);
}else{
echo "<br/><img src=\"../avatars/notok.gif\" alt=\"x\"/>Unknown Error<br/><br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
///////////////////////////////////Update Profile By CJ UDAY :)
else if($action=="upf")
{
addonline(getuid_sid($sid),"Updating $whonick Account","setting.php?action=$action");
    echo "<head>";
    echo "<title>Update Basic Profile</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
			echo "<b>Update Basic Profile</b></div>";
						echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<img src=\"../avatars/point.gif\" alt=\"!\"> Your E-mail address and contact number(s) will not be exposed!<br/>";
echo "<img src=\"../avatars/point.gif\" alt=\"!\"> Your E-mail will be used to reset password if you forget your password or security code!";						
echo "<onevent type=\"onenterforward\">";
$bdy = mysql_fetch_array(mysql_query("SELECT birthday FROM ibwff_users WHERE id='".$uid."'"));
$country = mysql_fetch_array(mysql_query("SELECT country FROM ibwff_users WHERE id='".$uid."'"));
$sx = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE id='".$uid."'"));
$loca = mysql_fetch_array(mysql_query("SELECT location FROM ibwff_users WHERE id='".$uid."'"));
$bdmg = mysql_fetch_array(mysql_query("SELECT interested FROM ibwff_users WHERE id='".$uid."'"));
$email = mysql_fetch_array(mysql_query("SELECT email FROM ibwff_users WHERE id='".$uid."'"));
$phone = mysql_fetch_array(mysql_query("SELECT phone FROM ibwff_users WHERE id='".$uid."'"));
echo "<refresh>
<setvar name=\"day\" value=\"$bdy[0]\"/>
<setvar name=\"month\" value=\"$bdy[0]\"/>
<setvar name=\"year\" value=\"$bdy[0]\"/>
<setvar name=\"cnt\" value=\"$country[0]\"/>
<setvar name=\"sx\" value=\"$sx[0]\"/>
<setvar name=\"loc\" value=\"$loca[0]\"/>
<setvar name=\"inf\" value=\"$bdmg[0]\"/>
<setvar name=\"semail\" value=\"$email[0]\"/>
<setvar name=\"phn\" value=\"$phone[0]\"/>
";
echo "</refresh></onevent>";
echo "<form action=\"userproc.php?action=uprof\" method=\"post\">"; 
echo "<p align=\"left\">";
echo "Email: <input name=\"eml\" input type=\"email\" maxlength=\"30\" value=\"$email[0]\"/><br/>";
echo "Phone: <input name=\"phn\" maxlength=\"15\" value=\"$phone[0]\"/><br/>";
echo "Birthday:";
echo "<select name=\"day\">";
echo "<option value=\"01\" selected=\"selected\">1</option>";
echo "<option value=\"02\">2</option>";
echo "<option value=\"03\">3</option>";
echo "<option value=\"04\">4</option>";
echo "<option value=\"05\">5</option>";
echo "<option value=\"06\">6</option>";
echo "<option value=\"07\">7</option>";
echo "<option value=\"08\">8</option>";
echo "<option value=\"09\">9</option>";
echo "<option value=\"10\">10</option>";
echo "<option value=\"11\">11</option>";
echo "<option value=\"12\">12</option>";
echo "<option value=\"13\">13</option>";
echo "<option value=\"14\">14</option>";
echo "<option value=\"15\">15</option>";
echo "<option value=\"16\">16</option>";
echo "<option value=\"17\">17</option>";
echo "<option value=\"18\">18</option>";
echo "<option value=\"19\">19</option>";
echo "<option value=\"20\">20</option>";
echo "<option value=\"21\">21</option>";
echo "<option value=\"22\">22</option>";
echo "<option value=\"23\">23</option>";
echo "<option value=\"24\">24</option>";
echo "<option value=\"25\">25</option>";
echo "<option value=\"26\">26</option>";
echo "<option value=\"27\">27</option>";
echo "<option value=\"28\">28</option>";
echo "<option value=\"29\">29</option>";
echo "<option value=\"30\">30</option>";
echo "<option value=\"31\">31</option>";
echo "</select>";
echo "<select name=\"month\">";
echo "<option value=\"01\" selected=\"selected\">Jan</option>";
echo "<option value=\"02-\">Feb</option>";
echo "<option value=\"03-\">Mar</option>";
echo "<option value=\"04-\">Apr</option>";
echo "<option value=\"05-\">May</option>";
echo "<option value=\"06-\">Jun</option>";
echo "<option value=\"07-\">Jul</option>";
echo "<option value=\"08-\">Aug</option>";
echo "<option value=\"09-\">Sep</option>";
echo "<option value=\"10-\">Oct</option>";
echo "<option value=\"11-\">Nov</option>";
echo "<option value=\"12-\">Dec</option>";
echo "</select>";
echo "<select name=\"year\">";
echo "<option value=\"2000-\" selected=\"selected\">2000</option>";
echo "<option value=\"2000-\">2000</option>";
echo "<option value=\"1999-\">1999</option>";
echo "<option value=\"1998-\">1998</option>";
echo "<option value=\"1997-\">1997</option>";
echo "<option value=\"1996-\">1996</option>";
echo "<option value=\"1995-\">1995</option>";
echo "<option value=\"1994-\">1994</option>";
echo "<option value=\"1993-\">1993</option>";
echo "<option value=\"1992-\">1992</option>";
echo "<option value=\"1991-\">1991</option>";
echo "<option value=\"1990-\">1990</option>";
echo "<option value=\"1989-\">1989</option>";
echo "<option value=\"1988-\">1988</option>";
echo "<option value=\"1987-\">1987</option>";
echo "<option value=\"1986-\">1986</option>";
echo "<option value=\"1985-\">1985</option>";
echo "<option value=\"1984-\">1984</option>";
echo "<option value=\"1983-\">1983</option>";
echo "<option value=\"1982-\">1982</option>";
echo "<option value=\"1981-\">1981</option>";
echo "<option value=\"1980-\">1980</option>";
echo "<option value=\"1979-\">1979</option>";
echo "<option value=\"1978-\">1978</option>";
echo "<option value=\"1977-\">1977</option>";
echo "<option value=\"1976-\">1976</option>";
echo "<option value=\"1975-\">1975</option>";
echo "<option value=\"1974-\">1974</option>";
echo "<option value=\"1973-\">1973</option>";
echo "<option value=\"1972-\">1972</option>";
echo "<option value=\"1971-\">1971</option>";
echo "<option value=\"1970-\">1970</option>";
echo "<option value=\"1979-\">1979</option>";
echo "<option value=\"1978-\">1978</option>";
echo "</select><br/>";
echo "Location: <input name=\"loc\" maxlength=\"100\" value=\"$loca[0]\"/><br/>";
echo "About Me: <input name=\"inf\" maxlength=\"100\" value=\"$bdmg[0]\"/><br/>";
echo "<input type=\"submit\" value=\"Update\"/>";
echo "</form>";
echo "</p>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
?>
</html>