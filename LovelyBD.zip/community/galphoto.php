<?php
session_start();
include("config.php");
include("core.php");  connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo '<head>';
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"title\" content=\"FireBD.NeT\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From CJ UDAY: Don't Try To Hack OR else :P\">
<meta name=\"keywords\" content=\"Site Desined By CJ UDAY :) :)\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/></head>";
echo "<body>";
$action = $_GET["action"]; $sid = $_SESSION["sid"];
$page = $_GET["page"];
$who = $_GET["who"];
$id = $_GET["id"];
$uid = getuid_sid($sid);
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();
////////////////Ip Banned By CJ UDAY :)	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
        echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
      echo "<br/>";
      echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
      $banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
      $remain =  $banto[0] - time();
      $rmsg = gettimemsg($remain);
      echo "<b>Time Remaining: $rmsg</b><br/>";
      $nick = getnick_uid($banto[2]);
       $text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
      echo "</p>";
    	echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
    echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
    echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
$uid = getuid_sid($sid);
//////////////////Banned System Updated By CJ UDAY :)
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please With Contact Us <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
///////////////////Deactivated Account By CJ UDAY :)
          if(isdeactivated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  <b>Your Account Has Been Deactivated Forever.<br/>And It Will Be Never Activate!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
///////////////////Validation By CJ UDAY :)
					if(isvalidated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  You Are Not Validated!<br/>We are checking your ip and browser<br/>
	  This could take up to 15 munites pls be patient and try again soon<br/>Please try again later...<br/><b>Thank You</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
////////////////////Gallery Photo Comments Updated By CJ UDAY :)
if($action=="comments")
{
$whonick = getnick_uid($who);
  addonline(getuid_sid($sid),"Viewing $whonick's Gallery Photo Comments","gallery.php?action=$action");
	    echo "<head>";
    echo "<title>View Gallery Photo Commnets</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
						echo "<div class=\"header\" align=\"center\">";
$whonick = getnick_uid($fm[0]);
			echo "<b>$whonick's Gallery Photo Comment</b></div>";
  echo "<div class=\"shout2\" align=\"left\">";
 include("pm_by.php");
$gid = $_GET["gid"];
if($page=="" || $page<=0) {$page=1;}
$count = mysql_fetch_assoc(mysql_query("SELECT COUNT(*) page FROM  ibwff_galcomments WHERE gid='".$gid."'"));
$num_items = $count['page'];
$event_per_page= 8;
$num_pages = ceil($num_items/$event_per_page);
if(($page>$num_pages)&&$page!=1) {$page= $num_pages;}
$limit_start = ($page-1)*$event_per_page;
$com = mysql_fetch_array(mysql_query("SELECT galcomments FROM ibwff_galcomments WHERE gid='".$gid."'"));
$shnick = subnick(getnick_uid($com[1]));
echo "<p align=\"center\">";
////////////////////////////////Gallery Photo By CJ UDAY :)
$uday = mysql_fetch_array(mysql_query("SELECT itemurl FROM ibwff_gallery WHERE id='".$gid."'"));
if($uday=="")
{
echo "";
}else{
$r = mysql_fetch_array(mysql_query("SELECT apics FROM ibwff_users WHERE id='".$who."'"));
if($r[0]>0)
{
echo "<a href=\"uday.php?action=cvpr&id=$gid\"><img src=\"$uday[0]\" alt=\"$uday[0]\" type=\"gallery\" width=\"100%\" height=\"250\"/></a>";
}else{
echo "<a href=\"$uday[0]\"><img src=\"$uday[0]\" alt=\"$uday[0]\" type=\"gallery\" width=\"100%\" height=\"250\"/></a>";
}
}
$like = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM uday_galpiclike12 WHERE gid='".$gid."'"));
echo "<br/><br/><b><img src=\"like.png\" alt=\"*\"><a href=\"galproc.php?action=galphotolike&gid=$gid\">Like</a>(<a href=\"galphotolike.php?action=main&who=$who&gid=$gid\">$like[0]</a>)";
$dislike = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM uday_galpicdislike13 WHERE gid='".$gid."'"));
echo "<img src=\"dislike.png\" alt=\"*\"><a href=\"galproc.php?action=galphotodislike&gid=$gid\">Disike</a>(<a href=\"galphotodislike.php?action=main&who=$who&gid=$gid\">$dislike[0]</a>)</b><br/>";
echo "<br/>ID: $gid";
echo "<br/>Name: $uday[0]<br/>Description: $uday[1]";
echo "<br/><br/>";
echo "</p>";
$covercomm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_galcomments WHERE gid='".$gid."'"));
if($covercomm[0]>0)
{
$covercomment2 = "<b>Gallery Photo Comments:</b><br/><br/>";
}else{
$covercomment2 = "";
}
echo "$covercomment2";
$results = mysql_query("SELECT * FROM ibwff_galcomments WHERE gid='".$gid."' ORDER BY btime ASC LIMIT $limit_start, $event_per_page");
while ($event = mysql_fetch_assoc($results)){
$user = $event['uid'];
$unick = subnick(getnick_uid($user));
	    $sql = "SELECT name FROM ibwff_users WHERE id=$user";
	    $sql2 = mysql_query($sql);
	    $item = mysql_fetch_array($sql2);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item[0]'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/>";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/>";}
if($sex[0]==""){$usersex = "";}
        		$avlink = getavatar($user);
if($avlink=="")
{
 $avt =  "$usersex";
}else{
 $avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"icon\" width=\"23\" height=\"18\"/>";
}
	    $sql3 = "SELECT name FROM ibwff_users WHERE id=$user";
	    $sql33 = mysql_query($sql3);
	    $item3 = mysql_fetch_array($sql33);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nicks = "<font color=\"blue\"><b>$unick</b></font>";}
if($sex[0]=="F"){$nicks = "<font color=\"deeppink\"><b>$unick</b></font>";}
if($sex[0]==""){$nicks = "";}
echo "<a href=\"profile.php?who=$user\">$avt$nicks</a>: ";
}
}
echo getbbcode($event[galcomments],$sid,1)."<br/>";
echo "<small>".gmstrftime("%d %B,%Y - %H:%M:%S %p",$event['btime'])."</small><br/>";
$event5 = $event['galcomments'];
$r0man = mysql_fetch_array(mysql_query("SELECT id FROM ibwff_galcomments WHERE galcomments='".$event5."'"));
if((getuid_sid($sid)==$who) || galleryboss(getuid_sid($sid)))
{
echo "<a href=\"galproc.php?action=delgalcom&gcid=$r0man[0]\"><img src=\"../images/notok.gif\"></a><br/>";
}
}
$covercomm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_galcomments WHERE gid='".$gid."'"));
if($covercomm[0]>0)
{
$covercomment = "";
}else{
$covercomment = "<b>Gallery Photo Comments:</b><br/><img src=\"../avatars/notok.gif\" alt=\"X\">This gallery photo has no comment!<br/>";
}
echo "$covercomment";
  echo "<br/><b>Comment:</b>";
  echo "<form action=\"galproc.php?action=commentadd&gid=$gid\" method=\"post\">";
  echo "<input type=\"text\" name=\"comments\"/>";
  echo "<br/>";
  echo "<input type=\"submit\" value=\"Add Comment\"/>";
  echo "</form>";
  echo "<br/>";
  echo "<img src=\"../avatars/prev.gif\" alt=\"&#171;\"><a href=\"profile.php?who=$who\">Back to Profile</a>";
echo "</p><p align=\"center\">";
if($page>1)
    {
      $ppage = $page-1;
      echo "<a href=\"galphoto.php?action=$action&amp;page=$ppage&who=$who\">&#171;-Prev</a> ";
    }
    if($page<$num_pages)
    {
      $npage = $page+1;
      echo "<a href=\"galphoto.php?action=$action&page=$npage&who=$who\">Next-&#187;</a>";
    }
    echo "<br/>Page - $page/$num_pages<br/>";
    if($num_pages>2)
    {
			        $rets = "<form action=\"galphoto.php\" method=\"get\">";
        $rets .= "<input name=\"page\" style=\"-wap-input-format: '*N'\" size=\"2\"/>";
        $rets .= "<input type=\"hidden\" name=\"action\" value=\"$action\"/>";
        $rets .= "<input type=\"hidden\" name=\"sid\" value=\"$sid\"/>";
   $rets .= "<input type=\"submit\" value=\"Go To Page\"/>";
        $rets .= "</form>";
        echo $rets;
    }
	echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
    }
?>
</html>