<?php
session_start();
include("config.php");
include("core.php");
connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo "<head>";
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG : Don't Try To Hack OR else :P\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"main,all,follow\"/></head>";
echo "<body>";
##FRIN3D LIST'S AlL C0D3, DES!GN AND SECUR!TY PR0V!D3D BY Shahos :-) ##
$action = $_GET["action"]; $sid = $_SESSION["sid"];
$page = $_GET["page"];
$who = $_GET["who"];
$uid = getuid_sid($sid);
$sitename = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='sitename'"));
$sitename = $sitename[0];
$ubrw = $ubrw[0];
$ipad = getip();	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
echo "<head>";
echo "<title>Error!!!</title>";
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\"/>";
echo "</head>";
echo "<body>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
echo "<br/>";
echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
$banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
$remain =  $banto[0] - time();
$rmsg = gettimemsg($remain);
echo "<b>Time Remaining: $rmsg</b><br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "</p>";
echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
$uid = getuid_sid($sid);
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\"/>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");  
echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\"/>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "<div class=\"div align=\"center\">Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");  
echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\"/>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please Contact <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(isdeactivated(getuid_sid($sid), $uid))
{
echo "<head>";
echo "<title>Error!!!</title>";
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\"/>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<br/><b>Your Account Has Been Deactivated.<br/>And It Will Be Never Activated Again!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
///////////////////////////////
else if($action=="add")
  {
  addonline(getuid_sid($sid),"Accepting Friends Request List","friends.php?action=$action");
echo "<head>";
echo "<title>Friend Requests</title>";
  echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"".bosshira_themes()."\">";
  echo "</head>"; 
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
    echo "<div class=\"header\" align=\"center\">";
	echo "<b>Friends Request Status</b></div>";
    echo "<div class=\"shout2\" align=\"left\">";
$who = $_GET["who"];
$uid = getuid_sid($sid);
$tnick = getnick_uid($who);
if(isignored($uid, $who))
    {
    echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>";
    echo "Cannot buddy $tnick. You are on ignore List.<br/><br/>";
   }else if(budres($uid,$who)!=3){
    if(arebuds($uid,$who))
    {
      echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>$tnick is Already Your Friend<br/><br/>";
    }else if(budres($uid, $who)==0)
    {
        $res = mysql_query("INSERT INTO ibwf_buddies SET uid='".$uid."', tid='".$who."', agreed='0', reqdt='".time()."'");
		if($res)
        {
            echo "<br/><img src=\"../avatars/ok.gif\" alt=\"o\"/>A Friend Request Has Been Sent to $tnick<br/><br/>";
			 $nick = getnick_sid($sid);
           mysql_query("INSERT INTO ibwff_notifications SET text='[user=$uid]$nick"."[/user] Has Sent You a Friend Request![br/][[reqaccept=$uid]Accept"."[/reqaccept]] Or [[reqdecline=$uid]Decline"."[/reqdecline]]', touid='".$who."', timesent='".time()."'");
        }else{
          echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>You can't add $tnick to your buddy list<br/>";
        }
    }
else if(budres($uid, $who)==1)
    {
$security = mysql_fetch_array(mysql_query("SELECT reqdt FROM ibwf_buddies WHERE id='$reqid'"));
$security = $security[0];
 if ($captcha==$security)  
 {
 }else{
 echo "Something went wrong . Please contact with Admin";
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
 }
        $res = mysql_query("UPDATE ibwf_buddies SET agreed='1' WHERE uid='".$who."' AND tid='".$uid."'");
        if($res)
        {
		$ibwf = time()+6*60*60;
$nick = getnick_uid($uid);
mysql_query("insert into ibwff_events (event,time) values ('<b>$nick</b>  is now friend with <b>$tnick</b>','$ibwf')");
            echo "<br/><img src=\"../avatars/ok.gif\" alt=\"o\"/>$tnick Added to Your Friend List Successfully!<br/><br/>";
           mysql_query("INSERT INTO ibwff_notifications SET text='[user=$uid]$nick"."[/user] Confirmed You As Friend!', touid='".$who."', timesent='".time()."'");
	   }else{
          echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>You Can't Add $tnick to Your Friend List<br/>";
        }
    }
    else{
        echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>You Can't Add $tnick to Your Friend List<br/><br/>";
    }
    }else{
        echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>You Can't Add $tnick to Your Friend List<br/><br/>";
    }
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}else if($action="del")
  {
  addonline(getuid_sid($sid),"Rejecting Friends Request List","friendsproc.php?action=$action");
echo "<head>";
echo "<title>Friend Requests</title>";
  echo "</head>"; 
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
    echo "<div class=\"header\" align=\"center\">";
	echo "<b>Friends Request Status</b></div>";
    echo "<div class=\"shout2\" align=\"left\">";
      $res= mysql_query("DELETE FROM ibwf_buddies WHERE (uid='".$uid."' AND tid='".$who."') OR (uid='".$who."' AND tid='".$uid."')");
      if($res)
        {
            echo "<br/><img src=\"../avatars/ok.gif\" alt=\"o\"/>$tnick Removed From Your Friend List<br/><br/>";
        }else{
          echo "<br/><img src=\"../avatars/notok.gif\" alt=\"x\"/>Can't Remove $tnick From Your Friend List<br/><br/>";
        }
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action="aall")
  {
  addonline(getuid_sid($sid),"Accepting Friends Request List","friendsproc.php?action=$action");
echo "<head>";
echo "<title>Friend Requests</title>";
  echo "</head>"; 
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
    echo "<div class=\"header\" align=\"center\">";
	echo "<b>Friends Request Status</b></div>";
    echo "<div class=\"shout2\" align=\"left\">";
      $res= mysql_query("UPDATE ibwf_buddies SET agreed='1' WHERE tid='".$uid."' AND agreed='0'");
if($res)
{
		$ibwf = time()+6*60*60;
$nick = getnick_uid($uid);
mysql_query("insert into ibwf_events (event,time) values ('<b>$nick</b>  just accepted all friend requests','$ibwf')");
            echo "<br/><img src=\"../avatars/ok.gif\" alt=\"o\"/>All The Friend Requests Accepted Successfully!<br/><br/>";
           mysql_query("INSERT INTO ibwff_notifications SET text='[user=$uid]$nick"."[/user] Confirmed You As Friend!', touid='".$who."', timesent='".time()."'");
	   }else{
          echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>Can't Accept All The Requests At This Moment.<br/>";
        }
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="dall")
{
  addonline(getuid_sid($sid),"Accepting Friends Request List","friends.php?action=$action");
echo "<head>";
echo "<title>Friend Requests</title>";
  echo "</head>"; 
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
    echo "<div class=\"header\" align=\"center\">";
	echo "<b>Friends Request Status</b></div>";
    echo "<div class=\"shout2\" align=\"left\">";
      $res= mysql_query("DELETE FROM ibwf_buddies WHERE agreed='0' AND tid='".$uid."'");
if($res)
{
$ibwf = time()+6*60*60;
$nick = getnick_uid($uid);
mysql_query("insert into ibwf_events (event,time) values ('<b>$nick</b>  just denied all friend requests','$ibwf')");
            echo "<br/><img src=\"../avatars/ok.gif\" alt=\"o\"/>All The Friend Requests Denied Successfully!<br/><br/>";
           mysql_query("INSERT INTO ibwff_notifications SET text='[user=$uid]$nick"."[/user] Confirmed You As Friend!', touid='".$who."', timesent='".time()."'");
	   }else{
          echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>Can't Deny All The Requests At This Moment.<br/>";
        }
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="delall")
{
addonline(getuid_sid($sid),"Removing Friends From List","friends.php?action=$action");
echo "<head>";
echo "<title>Friend Requests</title>";
  echo "</head>"; 
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
    echo "<div class=\"header\" align=\"center\">";
	echo "<b>Friends Request Status</b></div>";
    echo "<div class=\"shout2\" align=\"left\">";
      $res= mysql_query("DELETE FROM ibwf_buddies WHERE (agreed='1' AND tid='".$uid."') OR (agreed='1' AND uid='".$uid."')");
if($res)
{
echo "<br/><img src=\"../avatars/ok.gif\" alt=\"o\"/>All Friends Deleted Successfully!<br/><br/>";
	   }else{
          echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>Can't Delete All Friends At This Moment.<br/>";
        }
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
?>