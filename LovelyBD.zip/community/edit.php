<?php
session_start();
include("config.php");
include("core.php");  connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo '<head>';
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"title\" content=\"FireBD.NeT\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From CJ UDAY: Don't Try To Hack OR else :P\">
<meta name=\"keywords\" content=\"Site Desined By CJ UDAY :) :)\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/></head>";
echo "<body>";
$action = $_GET["action"]; $sid = $_SESSION["sid"];
$page = $_GET["page"];
$who = $_GET["who"];
$uid = getuid_sid($sid);
$name = $_GET["name"];
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();
////////////////Ip Banned By CJ UDAY :)	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
    echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
	echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
      echo "<br/>";
      echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
      $banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
      $remain =  $banto[0] - time();
      $rmsg = gettimemsg($remain);
      echo "<b>Time Remaining: $rmsg</b><br/>";
      $nick = getnick_uid($banto[2]);
       $text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
      echo "</p>";
    	echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
    echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
    echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
//////////////////Banned System Updated By CJ UDAY :)
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please With Contact Us <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
 echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
///////////////////Validation By CJ UDAY :)
					if(isvalidated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
	echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  You Are Not Validated!<br/>We are checking your ip and browser<br/>
	  This could take up to 15 munites pls be patient and try again soon<br/>Please try again later...<br/><b>Thank You</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }

///////////////////Deactivated Account By CJ UDAY :)
          if(isdeactivated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  <b>Your Account Has Been Deactivated Forever.<br/>And It Will Be Never Activate!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="topic")
{
  $tid = $_GET["tid"];
  $ttext = $_POST["ttext"];
  $fid = getfid_tid($tid);
	echo "<head>";
    echo "<title>Edit</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<b>Edit topic</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $res = mysql_query("UPDATE ibwff_topics SET text='".$ttext."' WHERE id='".$tid."'");
  if($res)
          {
            mysql_query("INSERT INTO ibwff_mlog SET action='Topics', details='<b>".getnick_uid(getuid_sid($sid))."</b> Edited The Text Of The Thread ".mysql_escape_string(gettname($tid))." at The forum ".getfname($fid)."', actdt='".time()."'");
            echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Topic Message Edited Sucessfully!";
		 }else{
            echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
          }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
else if($action=="article")
{
  $tid = $_GET["tid"];
  $ttext = $_POST["ttext"];
	echo "<head>";
    echo "<title>Edit</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<b>Edit article</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $res = mysql_query("UPDATE ibwff_storys SET text='".$ttext."' WHERE id='".$tid."'");
  if($res)
          {
            mysql_query("INSERT INTO ibwff_mlog SET action='Article', details='<b>".getnick_uid(getuid_sid($sid))."</b> Edited The Text Of an article , actdt='".time()."'");
            echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Article Message Edited Sucessfully!";
		 }else{
            echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
          }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
else if($action=="p")
{
  $pmid = $_GET["pmid"];
  $ttext = $_POST["ttext"];
	echo "<head>";
    echo "<title>Edit</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<b>Edit message</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $res = mysql_query("UPDATE ibwff_private SET text='".$ttext."' WHERE id='".$pmid."'");
  if($res)
          {
            echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Message Edited Sucessfully!";
		 }else{
            echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
          }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
else if($action=="blog")
{
  $pmid = $_GET["pmid"];
  $ttext = $_POST["ttext"];
	echo "<head>";
    echo "<title>Edit</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<b>Edit blog</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $res = mysql_query("UPDATE ibwff_blogs SET btext='".$ttext."' WHERE id='".$bid."'");
  if($res)
          {
            echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Blog Message Edited Sucessfully!";
		 }else{
            echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
          }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
else if($action=="sht")
{
  $pmid = $_GET["shid"];
  $ttext = $_POST["ttext"];
	echo "<head>";
    echo "<title>Edit</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<b>Edit shout</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $res = mysql_query("UPDATE ibwff_shouts SET shout='".$ttext."' WHERE id='".$pmid."'");
  if($res)
          {
            echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Shout Message Edited Sucessfully!";
		 }else{
            echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
          }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
else if($action=="post")
{
  $pmid = $_GET["pid"];
  $ttext = $_POST["ptext"];
	echo "<head>";
    echo "<title>Edit</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<b>Edit post</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $res = mysql_query("UPDATE ibwff_posts SET text='".$ttext."' WHERE id='".$pmid."'");
  if($res)
          {
            echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Topic Post Edited Sucessfully!";
		 }else{
            echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
          }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
else if($action=="artcom")
{
  $pmid = $_GET["pid"];
  $ttext = $_POST["ptext"];
	echo "<head>";
    echo "<title>Edit</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<b>Edit comment</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $res = mysql_query("UPDATE ibwff_storyposts SET text='".$ttext."' WHERE id='".$pmid."'");
  if($res)
          {
            echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Article Comment Edited Sucessfully!";
		 }else{
            echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
          }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
else if($action=="rentpc")
{
  $pmid = $_GET["tid"];
  $ttext = $_POST["tname"];
	echo "<head>";
    echo "<title>Edit</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<b>Rename topic</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $res = mysql_query("UPDATE ibwff_topics SET name='".$ttext."' WHERE id='".$pmid."'");
  if($res)
          {
            echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Topic Renamed Sucessfully!";
		 }else{
            echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
          }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
else if($action=="renlit")
{
  $pmid = $_GET["tid"];
  $ttext = $_POST["tname"];
	echo "<head>";
    echo "<title>Edit</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<b>Rename article</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $res = mysql_query("UPDATE ibwff_storys SET name='".$ttext."' WHERE id='".$pmid."'");
  if($res)
          {
            echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>article renamed sucessfully!";
		 }else{
            echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
          }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
else if($action=="renblg")
{
  $pmid = $_GET["bid"];
  $ttext = $_POST["tname"];
	echo "<head>";
    echo "<title>Edit</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<b>Rename blogs</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $res = mysql_query("UPDATE ibwff_blogs SET bname='".$ttext."' WHERE id='".$pmid."'");
  if($res)
          {
            echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Blog Renamed Sucessfully!";
		 }else{
            echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
          }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
else if($action=="shout")
{
  $pmid = $_GET["shid"];
	echo "<head>";
    echo "<title>Edit</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<b>Edit shout</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$ttext = mysql_fetch_array(mysql_query("SELECT shout FROM ibwff_shouts WHERE id='".$pmid."'"));
echo "<form action=\"edit.php?action=sht&clid=$clid&shid=$pmid&sid=$sid\" method=\"post\">";
echo "<b>Shout Text:</b> <input name=\"ttext\" value=\"$ttext[0]\" maxlength=\"300\"/>";
echo "<input type=\"submit\" value=\"Edit\"/>";
echo "</form>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
else if($action=="pm")
{
  $pmid = $_GET["pmid"];
	echo "<head>";
    echo "<title>Edit</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<b>Edit message</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$ttext = mysql_fetch_array(mysql_query("SELECT text FROM ibwff_private WHERE id='".$pmid."'"));
echo "<form action=\"edit.php?action=p&clid=$clid&pmid=$pmid\" method=\"post\">";
echo "<b>PM Text:</b> <input name=\"ttext\" value=\"$ttext[0]\" maxlength=\"300\"/>";
echo "<input type=\"submit\" value=\"Edit\"/>";
echo "</form>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
else if($action=="editpoll")
{
  $pmid = $_GET["who"];
	echo "<head>";
    echo "<title>Edit</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<b>Edit poll</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
 
$opt = mysql_fetch_array(mysql_query("SELECT pqst, opt1, opt2, opt3, opt4, opt5, uid FROM ibwff_polls WHERE id='".$shid."'"));
 echo "<form action=\"edit.php?action=pl&pid=$pmid\" method=\"post\">";
echo "<b><big>Question:</b></big><br/><input name=\"pques\" maxlength=\"1500\"  value=\"$opt[0]\"/><br/>";
echo "<b>Option 1:</b><br/><input name=\"opt1\" maxlength=\"100\" value=\"$opt[1]\"/><br/>";
echo "<b>Option 2:</b><br/><input name=\"opt2\" maxlength=\"100\" value=\"$opt[2]\"/><br/>";
echo "<b>Option 3:</b><br/><input name=\"opt3\" maxlength=\"100\" value=\"$opt[3]\"/><br/>";
echo "<b>Option 4:</b><br/><input name=\"opt4\" maxlength=\"100\" value=\"$opt[4]\"/><br/>";
echo "<b>Option 5:</b><br/><input name=\"opt5\" maxlength=\"100\" value=\"$opt[5]\"/><br/><br/>";
    echo "<input type=\"submit\" value=\"Edit\"/>";
    echo "</form>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
else if($action=="pl")
{
  $pmid = $_GET["pid"];
          $pques = $_POST["pques"];
          $opt1 = $_POST["opt1"];
          $opt2 = $_POST["opt2"];
          $opt3 = $_POST["opt3"];
          $opt4 = $_POST["opt4"];
          $opt5 = $_POST["opt5"];
	echo "<head>";
    echo "<title>Edit</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<b>Edit poll</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $res = mysql_query("UPDATE ibwff_polls SET pqst='".$pques."', opt1='".$opt1."', opt2='".$opt2."', opt3='".$opt3."', opt4='".$opt4."', opt5='".$opt5."' WHERE id='".$pmid."'");
if($res)
          {
            echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/> Poll Edited Sucessfully!";
		 }else{
            echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
          }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
?>
</html>