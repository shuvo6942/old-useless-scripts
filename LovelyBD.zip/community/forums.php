<?php
session_start();
include("config.php");
include("core.php");
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
connectdb();
echo '<head>';
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\"/>";
$tid = $_GET["tid"];
			$pm = mysql_fetch_array(mysql_query("SELECT name, tags FROM ibwff_topics WHERE id='".$tid."'"));
echo "<meta name=\"keywords\" content=\"$pm[1]\">";
echo "<meta name=\"description\" content=\"$pm[0]\">";
echo "<meta name=\"messgeses\" content=\"MSG : Don't Try To Hack OR else :P\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/></head>";
echo "<body>";
/*F0RUM IZ FULLY CR3AT3D & D3SIGNED BY Shahos*/
$action = $_GET["action"]; $sid = $_SESSION["sid"];
$clid = $_GET["clid"];
$page = $_GET["page"];
$who = $_GET["who"];
$whonick = getnick_uid($who);
$byuid = getuid_sid($sid);
$uid = getuid_sid($sid);
$sitename = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='sitename'"));
$sitename = $sitename[0];
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();
////////////////Ip Ban By CJ UDAY :)
if(isipbanned($ipad,$ubrw))
{
if(!isshield(getuid_sid($sid)))
{
echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
echo "<br/>";
echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
$banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
$remain =  $banto[0] - time();
$rmsg = gettimemsg($remain);
echo "<b>Time Remaining: $rmsg</b><br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "</p>";
echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
exit();
}
}
$uid = getuid_sid($sid);
//////////////////Ban System Updated By CJ UDAY :)
if(isbanned($uid))
{
echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please Contact <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
/////////////////////Forum Ban By CJ UDAY :)
$ban = mysql_fetch_array(mysql_query("SELECT forumban FROM ibwfff_users WHERE id='".$uid."'"));
if($ban[0] > 0)
{
echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<br/><b><u><i>Can't Enter To Forums<br/>";
echo "You're Forum banned!</u></i></b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(!isuser(getuid_sid($sid)))
{
echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<br/>This feature is unavailiable for guests.
So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
echo "<div class=\"div\" align=\"center\">";
echo "<b>USER ACCESS</b></div>";
echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";
echo "</form><br/><br/>";
echo "Not Registered Yet?<br/>";
echo "<a href=\"register.php\">Register Now!</a>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(islogged($sid)==false)
{
echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<br/>For some security reasons,you are automatically logged out.<br/>
You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
Or, Please Login Again :-)<br/><br/>";
echo "<div class=\"div\" align=\"center\">";
echo "<b>USER ACCESS</b></div>";
echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
///////////////////Deactivated Account :)
if(isdeactivated(getuid_sid($sid), $uid))
{
echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<br/>
<b>Your Account Has Been Deactivated.<br/>And It Will Be Never Activated Again!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
exit();
}
///////////////////Validation By CJ UDAY :)
if(isvalidated(getuid_sid($sid), $uid))
{
echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<br/>
You Are Not Validated!<br/>We are checking your ip and browser<br/>
This could take up to 15 munites pls be patient and try again soon<br/>Please try again later...<br/><b>Thank You</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
exit();
}
//////////////////////////////////Forums Updated By CJ UDAY :)
if($action=="forums")
{
addonline(getuid_sid($sid),"Viewing Forums","forums.php?action=$action");
echo "<head>";
echo "<title>View Forums</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Forums</b><br/>Forums Categories</div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<b>Top Forum Poster Of The Day:</b><br/>";
include("topposter.php");
echo "<b>Top Forum Poster Of The Week:</b><br/>";
include("top_weekly_poster.php");
echo "<p align=\"left\"><b>Last Forum Topic:</b><br/>";
include("lasttpc.php");
echo "<br/><b>Last Forum Post:</b><br/>";
include("lastpost.php");
echo "</p>";
$fcats = mysql_query("SELECT id, name FROM ibwff_fcats ORDER BY position, id");
$iml = "<img src=\"../avatars/forums.gif\" alt=\"*\">";
while($fcat=mysql_fetch_array($fcats))
{
$catlink = "$fcat[1]";
echo "<p align=\"left\"><b>$catlink</b><br/>";
$forums = mysql_query("SELECT id, name FROM ibwff_forums WHERE cid='".$fcat[0]."' AND clubid='0' ORDER BY position, id, name");
while($forum=mysql_fetch_array($forums))
{
$notp = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_topics WHERE fid='".$forum[0]."'"));
$nops = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_posts a INNER JOIN ibwff_topics b ON a.tid = b.id WHERE b.fid='".$forum[0]."'"));
if(fmtval($forum[0]))
{
echo "<a href=\"forums.php?action=viewtopicbox&fid=$forum[0]\">$iml$forum[1] $notp[0]/$nops[0]</a><br/>";
    }
	else{
if(forumboss($uid))
{
echo "&#8226; Forum name: <b>$forum[1]</b><br/>";
echo "&#8226; <a href=\"validate.php?action=valfrm&fid=$forum[0]\"> Validate $forum[1]</a>";
}	
echo "-------<br/>";
}
}
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
exit();
}
else if($action=="")
{
$tid = $_GET["tid"];
$go = $_GET["go"];
$clid = $_GET["clid"]; $action = $_GET["action"];
$tinfo = mysql_fetch_array(mysql_query("SELECT name, text, authorid, crdate, views, fid, pollid from ibwff_topics WHERE id='".$tid."'"));
addonline(getuid_sid($sid),"Viewing $tinfo[0] Topic","forums.php?tid=$tid");
$tfid = mysql_fetch_array(mysql_query("SELECT fid FROM ibwff_topics WHERE id='".$tid."'"));
$cfrm = mysql_fetch_array(mysql_query("SELECT clubid FROM ibwff_forums WHERE id='".$tfid[0]."'"));
if(!canaccess(getuid_sid($sid), $tfid[0]))
{
echo "<head>";
echo "<title>View $tinfo[0] Topic</title>";
$uday = mysql_query("SELECT tags FROM uday_ftags WHERE tid='".$tid."'");
while($cj = mysql_fetch_array($uday))
{
echo "<meta name=\"descriptions\" content=\"$cj\">";
}
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "View $tinfo[0] Topic</div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<br/><img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!<br/>Permission Denied...</b><br/>You Don't Have A Permission To View The Contents Of This Forum!<br/><br/>";
echo "Please <a href=\"clubproc.php?action=join&clid=$clid\">Join ".getclubname($clid)." Club</a> to view the contents of this forum!<br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
exit();
}
$tinfo = mysql_fetch_array(mysql_query("SELECT name, text, authorid, crdate, views, fid, pollid from ibwff_topics WHERE id='".$tid."'"));
$tnm = htmlspecialchars($tinfo[0]);
if(!tpcvld_uday($tid))
{
echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\"
align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\"
align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<br/>This Topic is waiting for validation!<br/>Please try again later...<br/><b>Thank You</b><br/><br/>";
if(forumboss($uid) || isownerclub($uid, $clid)=="1" || isclubmod($uid, $clid)=="1")
{
$fname = mysql_fetch_array(mysql_query("SELECT name, text FROM ibwff_topics WHERE id='".$tid."'"));
$tname = $fname[0];
$text = $fname[1];
echo "&#8226; Topic name: <b>$tname</b><br/>";
echo "&#8226; Topic Text:<br/>".getbbcode($text,$sid)."<br/>";
echo "&#8226; <a href=
\"validate.php?action=valtpc&tid=$tid\">Validate $tname</a><br/>";
echo "&#8226; <a href=
\"forums.php?action=tpcopt&tid=$tid\"> Edit $tname</a><br/>";
echo "&#8226; <a href=
\"delete.php?action=delt&tid=$tid\"> Delete $tname</a><br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a
href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
exit();
}
$wh = subnick(getnick_uid($uid));
echo "<head>";
echo "<title>$wh@Viewing $tinfo[0] Topic</title>";
$uday = mysql_query("SELECT tags FROM ibwff_topics WHERE id='".$tid."'");
$cj = mysql_fetch_array($uday);
echo "<meta name=\"descriptions\" content=\"$cj[0]\">";
echo "</head>";
echo "<body>";
echo "<div class=\"header\" align=\"left\">";
echo "<img src=\"FireBD.png\" alt=\"$sitename\" type=\"logo\" width=\"240\" height=\"50\"/><br/>";
echo "<b>Viewing $tinfo[0] Topic</b></div>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";	

echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$num_pages = getnumpages($tid);
if($page==""||$page<1)$page=1;
if($go!="")$page=getpage_go($go,$tid);
$posts_per_page = 5;
if($page>$num_pages)$page=$num_pages;
$limit_start = $posts_per_page *($page-1);
echo "&#187; <a href=\"forums.php?action=post&clid=$clid&tid=$tid\">Post Reply</a><br/>";
$lastlink = "&#187; <a href=\"forums.php?action=$action&tid=$tid&;go=last\"> Last Page</a><br/>";
$firstlink = "&#171; <a href=\"forums.php?action=$action&tid=$tid&page=1\">First Page</a><br/>";
$golink = "";
if($page>1)
{
$golink = $firstlink;
}
if($page<$num_pages)
{
$golink .= $lastlink;
}
if($golink !="")
{
echo "$golink";
}
$vws = $tinfo[4]+1;
$tid = $_GET["tid"];
$sub = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM uday_subtop WHERE tid='".$tid."'"));
$rpls = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_posts WHERE tid='".$tid."'"));
$type = mysql_fetch_array(mysql_query("SELECT type FROM ibwff_topics WHERE id='".$tid."'"));
echo "ID: $tid<br/>";
echo "Type : $type[0]<br/>";
echo "Subscriber: $sub[0]<br/>";
echo "Replies: $rpls[0] - ";
echo "Views: $vws<br/>";
$tfid = mysql_fetch_array(mysql_query("SELECT fid FROM ibwff_topics WHERE id='".$tid."'"));
$uday = mysql_fetch_array(mysql_query("SELECT uday_tag FROM ibwff_topics WHERE id='".$tid."'"));
echo "<b>Tags:</b> $uday[0]<br/>";
$cfrm = mysql_fetch_array(mysql_query("SELECT clubid FROM ibwff_forums WHERE id='".$tfid[0]."'"));
if ($cfrm[0]>0)
{
$cname = getclubname($cfrm[0]);
echo "Club Name: <b>$cname</b><br/>";
}
$suscriber = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM uday_subtop WHERE uid='".$uid."' AND tid='".$tid."'"));
if($suscriber[0]>0)
{
echo"<img src=\"../images/unsub.png\" alt=\"-\"> <a href=\"forumsproc.php?action=tpcunsub&tid=$tid\">Unsubscribe Topic</a>";
}else{
echo "<img src=\"../images/sub.png\" alt=\"-\"> <a href=\"forumsproc.php?action=tpcsub&tid=$tid\">Subscribe Topic</a>";
}
echo "<br/>";
$hdd = mysql_fetch_array(mysql_query("SELECT udayhide FROM ibwff_topics WHERE id='".$tid."'"));
if(forumboss($uid))
{
if($hdd[0]==1)
{
echo"<b>Topic:</b> <a href=\"forums.php?action=showtopic&tid=$tid\">Show</a> / ";
echo"<b>Hide</b>";
}else{
echo"<br/><b>Topic:</b> <b>Show</b> / ";
echo"<a href=\"forums.php?action=hidetopic&tid=$tid\">Hide</a>";
}
echo "<br/>";
}
if($page==1)
{
$posts_per_page=4;
mysql_query("UPDATE ibwff_topics SET views='".$vws."' WHERE  id='".$tid."'");
$ttext = mysql_fetch_array(mysql_query("SELECT authorid, text, crdate, pollid FROM ibwff_topics WHERE id='".$tid."'"));
$unick = subnick(getnick_uid($ttext[0]));
$sql = "SELECT name FROM ibwff_users WHERE id=$ttext[0]";
$sql2 = mysql_query($sql);
$item = mysql_fetch_array($sql2);
{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item[0]'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/>";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/>";}
if($sex[0]==""){$usersex = "";}      if(isonline($ttext[0]))
{
$iml = "<img src=\"../avatars/onl.gif\" alt=\" \"/>";
}else{
$iml = "<img src=\"../avatars/ofl.gif\" alt=\"-\"/>";
}
$avlink = getavatar($ttext[0]);
if($avlink=="")
{
$avt =  "$usersex";
}else{
$avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"avatar\" width=\"23\" height=\"18\"/>";
}
$sql3 = "SELECT name FROM ibwff_users WHERE id=$ttext[0]";
$sql33 = mysql_query($sql3);
$item3 = mysql_fetch_array($sql33);
{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nicks = "<font color=\"blue\"><b>$unick</b></font>";}
if($sex[0]=="F"){$nicks = "<font color=\"deeppink\"><b>$unick</b></font>";}
if($sex[0]==""){$nicks = "";}
$usl = "<div class=\"forum\" align=\"left\">$iml$avt<a href=\"profile.php?who=$ttext[0]\">$nicks</a>";
}
$topt = "<a href=\"forums.php?action=tpcopt&clid=$clid&tid=$tid\">[+]</a>";
}
if($go==$tid)
{
$fli = "<img src=\"../avatars/flag.gif\" alt=\"!\"/>";
}else{
$fli ="";
}
$pst = parsemsg($ttext[1],$sid);
$dtot = date("h:i:s A D d M y",$ttext[2]);
echo "$usl:<br/>(".getstatus($ttext[0]).")<br/><small>$dtot</small><br/><br/>";
echo "$fli$pst";
echo "<br/></div>";
echo "<p align=\"left\">";    if($ttext[3]>0)
{
echo "<a href=\"polls.php?clid=$clid&who=$tid\">POLL</a><br/>";
echo"</p>";
}
echo "$topt<br/>";
echo "<b>Topic Ratings:</b><br/>";
$rtr = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM uday_tpcrate WHERE tid='".$tid."'"));
$rate = gettpcrate($uid, $tid);
echo "$rate(<a href=\"forums.php?action=raters&tid=$tid\">$rtr[0]</a>)<br/>";
$vb = mysql_fetch_array(mysql_query("SELECT rate FROM uday_tpcrate WHERE uid='".$uid."' AND tid='".$tid."'"));
echo "<form action=\"forumsproc.php?action=tpcrate&tid=$tid\" method=\"post\">";
echo "<select name=\"rate\" value=\"$vb[0]\">";
echo "<option value=\"5\">Very Good</option>";
echo "<option value=\"4\">Good</option>";
echo "<option value=\"3\">Ok</option>";
echo "<option value=\"2\">Nice</option>";
echo "<option value=\"1\">Poor</option>";
echo "</select>";
echo "<input type=\"hidden\" name=\"system\" value=\"topic\"/>";
echo "<input type=\"submit\" value=\"Rate\"/>";
echo "</form>";
}
if($page>1)
{
$limit_start--;
}
$sql = "SELECT id, text, uid, dtpost, quote FROM ibwff_posts WHERE tid='".$tid."' ORDER BY dtpost LIMIT $limit_start, $posts_per_page";
$posts = mysql_query($sql);
while($post = mysql_fetch_array($posts))
{
$unick = subnick(getnick_uid($post[2]));
$sql2 = "SELECT name FROM ibwff_users WHERE id=$post[2]";
$sql22 = mysql_query($sql2);
$item2 = mysql_fetch_array($sql22);
{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item2[0]'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/>";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/>";}
if($sex[0]==""){$usersex = "";}
if(isonline($post[2]))
{
$iml = "<img src=\"../avatars/onl.gif\" alt=\" \"/>";
}else{
$iml = "<img src=\"../avatars/ofl.gif\" alt=\"-\"/>";
}
$avlink = getavatar($post[2]);
if($avlink=="")
{
$avt =  "$usersex";
}else{
$avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"avatar\" width=\"23\" height=\"18\"/>";
}
$sql3 = "SELECT name FROM ibwff_users WHERE id=$post[2]";
$sql33 = mysql_query($sql3);
$item3 = mysql_fetch_array($sql33);
{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nick = "<font color=\"blue\"><b>$unick</b></font>";}
if($sex[0]=="F"){$nick = "<font color=\"deeppink\"><b>$unick</b></font>";}
if($sex[0]==""){$nick = "";}
$usl = "<br/>$iml$avt<a href=\"profile.php?who=$post[2]\">$nick<br/></a>(".getstatus($post[2]).")<br/>";
}
}
$pst = parsemsg($post[1], $sid);
$topt = "<a href=\"forums.php?action=pstopt&clid=$clid&who=$who&pid=$post[0]&page=$page&fid=$tinfo[5]\">[+]</a>";
if($go==$post[0])
{
$fli = "<img src=\"../avatars/flag.gif\" alt=\"!\"/>";
}else{
$fli ="";
}
$ttt = getuid_sid($sid);
if($hdd[0]==1 && $ttt!=$ttext[0])
{
$fid = $tinfo[5];
$fname = getfname($fid);
$cid = mysql_fetch_array(mysql_query("SELECT cid FROM ibwff_forums WHERE id='".$fid."'"));
$cinfo = mysql_fetch_array(mysql_query("SELECT name FROM ibwff_fcats WHERE id='".$fid."'"));
$cname = $cinfo[0];
$cid = mysql_fetch_array(mysql_query("SELECT cid FROM ibwff_forums WHERE id='".$fid."'"));
$fname = htmlspecialchars($fname);
die("<p align=\"center\"><br/><b>&#187;<font color=\"red\">Posts Of This Topic Are Now Hidden</font>&#171;</b><br/>
<form action=\"forumsproc.php?action=post&clid=$clid\" method=\"post\">
<input name=\"reptxt\" maxlength=\"1000\"/><br/>
<input type=\"hidden\" name=\"tid\" value=\"$tid\"/>
<input type=\"submit\" value=\"Add Reply\"/><br/><br/>
</form>
<p align=\"left\">
<b><a href=\"forums.php?action=forums&clid=$clid\">Forums</a>&#187;<a href=\"forums.php?action=viewtopicbox&clid=$clid&fid=$fid\">$fname</a>&#187;$tinfo[0]</b>
</p><br/>
</div>
<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>
<div class=\"footer\" align=\"center\">
&#169; <img src=\"fire.ico\" type=\"icon\" alt=\"[ ]\" width=\"15\" height=\"17\"><normal><a href=\"main.php\"><b>$sitename</b></a> (0.06s)</normal>
</div>
</body>
");
}

$dtot = date("H:i:s A d D m y",$post[3]);
echo "$usl $dtot<br/>$fli$pst";
echo "<br/><br/>$topt";
echo "<br/>";
}
echo "<p align=\"left\">";
if($page>1)
{
$ppage = $page-1;
echo "<a href=\"forums.php?page=$ppage&clid=$clid&tid=$tid\">&#171;-Prev</a> ";
}
if($page<$num_pages)
{
$npage = $page+1;
echo "<a href=\"forums.php?page=$npage&clid=$clid&tid=$tid\">Next-&#187;</a>";
}
if($num_pages>2)
{
$rets = "<form action=\"forums.php\" method=\"get\">";
$rets .= "<p align=\"left\">";
$rets .= "<input name=\"page\" style=\"-wap-input-format: '*N'\" size=\"2\"/>";
$rets .= "<input type=\"hidden\" name=\"action\" value=\"$action\"/>";
$rets .= "<input type=\"hidden\" name=\"sid\" value=\"$sid\"/>";
$rets .= "<input type=\"hidden\" name=\"tid\" value=\"$tid\"/>";
$rets .= "<input type=\"submit\" value=\"Go To Page\"/>";
$rets .= "</p>";
$rets .= "</form>";
echo $rets;
}
echo "<br/>Page - $page/$num_pages<br/>";
echo "<br/>";
echo "<form action=\"forumsproc.php?action=post&clid=$clid\" method=\"post\">";
echo "<input name=\"reptxt\" maxlength=\"200\"/><br/>";
echo "<input type=\"hidden\" name=\"tid\" value=\"$tid\"/>";
echo "<input type=\"submit\" value=\"Add Reply\"/>";
echo "</form>";
echo "<p align=\"left\">";
$px = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_posts WHERE tid='".$tid."'"));
if($px[0]>0)
{
echo "<b>Currently Discussing:</b><br/>";
$sql = "SELECT DISTINCT(uid) FROM ibwff_posts WHERE tid='".$tid."'";
$psts = mysql_query($sql);
while($pst = mysql_fetch_array($psts))
{
$unick = subnick(getnick_uid($pst[0]));
$sql2 = "SELECT name FROM ibwff_users WHERE id=$pst[0]";
$sql22 = mysql_query($sql2);
$item2 = mysql_fetch_array($sql22);
{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item2[0]'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/>";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/>";}
if($sex[0]==""){$usersex = "";}
$avlink = getavatar($pst[0]);
if($avlink=="")
{
$avt =  "$usersex";
}else{
$avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"avatar\" width=\"18\" hieght=\"23\"/>";
}
$sql3 = "SELECT name FROM ibwff_users WHERE id=$pst[0]";
$sql33 = mysql_query($sql3);
$item3 = mysql_fetch_array($sql33);
{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nick = "<font color=\"blue\"><b>$unick</b></font>";}
if($sex[0]=="F"){$nick = "<font color=\"deeppink\"><b>$unick</b></font>";}
if($sex[0]==""){$nick = "";}
$usl = "$avt<a href=\"profile.php?who=$pst[0]\">$nick</a>";
}
}
echo "$usl ,";
}
}
$fid = $tinfo[5];
$fname = getfname($fid);
$cid = mysql_fetch_array(mysql_query("SELECT cid FROM ibwff_forums WHERE id='".$fid."'"));
$cinfo = mysql_fetch_array(mysql_query("SELECT name FROM ibwff_fcats WHERE id='".$fid."'"));
$cname = $cinfo[0];
$cid = mysql_fetch_array(mysql_query("SELECT cid FROM ibwff_forums WHERE id='".$fid."'"));
$fname = htmlspecialchars($fname);
echo "<br/><br/><a href=\"forums.php?action=forums&clid=$clid\">Forums</a>&#187;<a href=\"forums.php?action=viewtopicbox&clid=$clid&fid=$fid\">$fname</a> &#187;$tinfo[0]";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
//////////////////////////////////View Forum Updated :)
else if($action=="viewtopicbox")
{
$fid = mysql_real_escape_string($_GET["fid"]);
$view = mysql_real_escape_string($_GET["view"]);
if(!canaccess(getuid_sid($sid), $fid))
{
addonline(getuid_sid($sid),"Viewing Topics Box","forums.php?action=$action");
echo "<head>";
echo "<title>View Topic Box</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<br/>You Don't Have A permission To View The Contents Of This Forum!<br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
$finfo = mysql_fetch_array(mysql_query("SELECT name from ibwff_forums WHERE id='".$fid."'"));
$fnm = htmlspecialchars($finfo[0]);
addonline(getuid_sid($sid),"View $finfo[0] Forums","forums.php?action=viewtopicbox&clid=$clid&fid=$fid");
echo "<head>";
echo "<title>View $finfo[0] Forums</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>View $finfo[0] Forums</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
echo "<form action=\"forums.php\" method=\"get\"><center>";
echo "View: <select name=\"view\">";
echo "<option value=\"all\">All</option>";
echo "<option value=\"new\">Since Last Visit</option>";
echo "<option value=\"myps\">I posted In</option>";
echo "</select>";
echo "<input type=\"submit\" value=\"Go\"/>";
echo "<input type=\"hidden\" name=\"action\" value=\"$action\"/>";
echo "<input type=\"hidden\" name=\"fid\" value=\"$fid\"/>";
echo "<input type=\"hidden\" name=\"sid\"  value=\"$sid\"/>";
echo "</form>";
echo "<br/>";
if($view=="new")
{
echo "Viewing Topics that has no new posts since your last visit";
}else if($view=="myps")
{
echo "Viewing Topics contain posts by you";
}else {
echo "Viewing All Topics";
}
echo "<p align=\"left\">";
if($page=="" || $page<=0)$page=1;
if($page==1)
{
echo "&#187; <a href=\"forums.php?action=newtopic&clid=$clid&fid=$fid\"><big>New Topic</big></a><br/>";
$topics = mysql_query("SELECT id, name, closed, views, pollid FROM ibwff_topics WHERE fid='".$fid."' AND pinned='1' ORDER BY lastpost DESC, name, id LIMIT 0,5");
while($topic = mysql_fetch_array($topics))
{
$iml = "<img src=\"../avatars/normal.gif\" alt=\"*\"/>";
$iml = "*";
$atxt ="";
if($topic[2]=='1')
{
$atxt = "(X)";
}
if($topic[4]>0)
{
$pltx = "(P)";
}else{
$pltx = "";
}
$tnm = htmlspecialchars($topic[1]);
$nop = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_posts WHERE tid='".$topic[0]."'"));
if(tpcvld_uday($topic[0]))
{
echo "<a href=\"forums.php?clid=$clid&tid=$topic[0]\">$iml$pltx$tnm($nop[0])$atxt</a><br/>";
    }else{
if(forumboss($uid) || isownerclub($uid, $clid)=="1" || isclubmod($uid, $clid)=="1")
{
echo "&#8226; Topic name: <b>$tnm</b><br/>";
echo "&#8226; <a href=\"forums.php?tid=$topic[0]&clid=$clid\"> Validate $tnm</a><br/>&#8226; <a href=\"delete.php?action=topic&tid=$topic[0]clid=$clid\"> Delete $tnm</a><br/>";
}	
echo "-------<br/>";
}
}
}
$uid = getuid_sid($sid);
if($view=="new")
{
$ulv = mysql_fetch_array(mysql_query("SELECT lastvst FROM ibwff_users WHERE id='".$uid."'"));
$noi = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_topics WHERE fid='".$fid."' AND pinned='0' AND lastpost >='".$ulv[0]."'"));
}
else if($view=="myps")
{
$noi = mysql_fetch_array(mysql_query("SELECT COUNT(DISTINCT a.id) FROM ibwff_topics a INNER JOIN ibwff_posts b ON a.id = b.tid WHERE a.fid='".$fid."' AND a.pinned='0' AND b.uid='".$uid."'"));
}else{
$noi = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_topics WHERE fid='".$fid."' AND pinned='0'"));
}
$num_items = $noi[0];
$items_per_page= 10;
$num_pages = ceil($num_items/$items_per_page);
if($page>$num_pages)$page= $num_pages;
$limit_start = ($page-1)*$items_per_page;
if($limit_start<0)$limit_start=0;
if($view=="new")
{
$ulv = mysql_fetch_array(mysql_query("SELECT lastvst FROM ibwff_users WHERE id='".$uid."'"));
$topics = mysql_query("SELECT id, name, closed, views, moved, pollid FROM ibwff_topics WHERE fid='".$fid."' AND pinned='0' AND lastpost >='".$ulv[0]."' ORDER BY lastpost DESC, name, id LIMIT $limit_start, $items_per_page");
}
else if($view=="myps"){
$topics = mysql_query("SELECT a.id, a.name, a.closed, a.views, a.moved, a.pollid FROM ibwff_topics a INNER JOIN ibwff_posts b ON a.id = b.tid WHERE a.fid='".$fid."' AND a.pinned='0' AND b.uid='".$uid."' GROUP BY a.id ORDER BY a.lastpost DESC, a.name, a.id LIMIT $limit_start, $items_per_page");
}else{
$topics = mysql_query("SELECT id, name, closed, views, moved, pollid FROM ibwff_topics WHERE fid='".$fid."' AND pinned='0' ORDER BY lastpost DESC, name, id LIMIT $limit_start, $items_per_page");
}
while($topic = mysql_fetch_array($topics))
{
$nop = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_posts WHERE tid='".$topic[0]."'"));
$iml = "<img src=\"../avatars/normal.gif\" alt=\"*\"/>";
if($nop[0]>24)
{
$iml = "<img src=\"../avatars/hot.gif\" alt=\"*\"/>";
}
if($topic[4]=='1')
{
$iml = "<img src=\"../avatars/moved.gif\" alt=\"*\"/>";
}
if($topic[2]=='1')
{
$iml = "<img src=\"../avatars/closed.gif\" alt=\"*\"/>";
}
if($topic[5]>0)
{
$iml = "<img src=\"../avatars/poll.gif\" alt=\"*\"/>";
}
$atxt ="";
if($topic[2]=='1')
{
$atxt = "(X)";
}
$tnm = htmlspecialchars($topic[1]);
if(tpcvld_uday($topic[0]))
{
echo "<a href=\"forums.php?clid=$clid&tid=$topic[0]\">$iml$tnm($nop[0])$atxt</a><br/>";
    }else{
if(forumboss($uid) || isownerclub($uid, $clid)=="1" || isclubmod($uid, $clid)=="1")
{
echo "&#8226; Topic name: <b>$tnm</b><br/>";
echo "&#8226; <a href=\"forums.php?&clid=$clid&tid=$topic[0]\"> Validate $tnm</a><br/>&#8226; <a href=\"delete.php?action=topic&clid=$clid&tid=$topic[0]\"> Delete $tnm</a><br/>";
}	
echo "-------<br/>";
}
}
echo "</p>";
echo "<p align=\"center\">";
if($page>1)
{
$ppage = $page-1;
echo "<a href=\"forums.php?action=viewtopicbox&amp;page=$ppage&clid=$clid&fid=$fid&view=$view\">&#171;-Prev</a> ";
}
if($page<$num_pages)
{
$npage = $page+1;
echo "<a href=\"forums.php?action=viewtopicbox&page=$npage&clid=$clid&fid=$fid&view=$view\">Next&#8594;</a>";
}
if($num_pages>2)
{
$rets = "<form action=\"forums.php\" method=\"get\">";
$rets .= "<input name=\"page\" style=\"-wap-input-format: '*N'\" size=\"2\"/>";
$rets .= "<input type=\"hidden\" name=\"action\" value=\"$action\"/>";
$rets .= "<input type=\"hidden\" name=\"sid\" value=\"$sid\"/>";
$rets .= "<input type=\"hidden\" name=\"fid\" value=\"$fid\"/>";
$rets .= "<input type=\"hidden\" name=\"view\" value=\"$view\"/>";
$rets .= "<input type=\"submit\" value=\"Go To Page\"/>";
$rets .= "</form>";
echo $rets;
}
echo "<p align=\"left\">";
echo "<br/><br/>&#187; <a href=\"forums.php?action=newtopic&clid=$clid&fid=$fid\"><big>New Topic</big></a>";
echo "<br/>Page - $page/$num_pages<br/>";
echo "</p>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
//////////////////////////////////New Topic
else if($action=="newtopic")
{
$fid = mysql_real_escape_string($_GET["fid"]);
addonline(getuid_sid($sid),"Creating A New topic","forums.php?action=$action");
echo "<head>";
echo "<title>Create A New Topic</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";					echo "<div class=\"header\" align=\"center\">";
echo "<b>Create A New Topic</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include ("pm_by.php");
echo "<form action=\"forumsproc.php?action=newtopic&clid=$clid&who=$who\" method=\"post\">";
echo "<p align=\"left\">";
echo "<big><b>Topic Title:</b></big><br/><input name=\"ntitle\" maxlength=\"250\"/><br/>";
echo "<big><b>Topic Text:</b></big><br/><input name=\"tpctxt\" maxlength=\"10000\"/><br/>";
echo "<input type=\"hidden\" name=\"fid\" value=\"$fid\"/>";
echo "<big><b>Topic Type:</b></big><br/> <select name=\"type\" value=\"Forum\">";
echo "<option value=\"Forum\">Forum</option>";
echo "<option value=\"Discussion\">Discussion</option>";
echo "<option value=\"General Talk\">General Talk</option>";
echo "<option value=\"Adda\">Adda</option>";
echo "<option value=\"Fun\">Fun</option>";
echo "</select><br/>";
echo "<big><b>Topic Tags:</b></big><br/><input name=\"tpctag\" maxlength=\"1000\"/><br/>";
echo "<input type=\"submit\" value=\"Create\"/>";
echo "</form>";
echo "</p>";
echo "<a href=\"forums.php?action=viewtopicbox&fid=$fid\">";
$fname = getfname($fid);
echo "<b>$fname</b></a>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
//////////////////////////////////////////Post reply
else if($action=="post")
{
$tid = mysql_real_escape_string($_GET["tid"]);
$tfid = mysql_fetch_array(mysql_query("SELECT fid FROM ibwff_topics WHERE id='".$tid."'"));
$fid = $tfid[0];
if(!canaccess(getuid_sid($sid), $fid))
{
echo "<head>";
echo "<title>Post A Reply</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Post Reply</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<br/>You Don't Have A permission To View The Contents Of This Forum<br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
addonline(getuid_sid($sid),"Posting Reply","forums.php?action=$action");
$tinfo = mysql_fetch_array(mysql_query("SELECT name from ibwff_topics WHERE id='".$tid."'"));
echo "<head>";
echo "<title>Post A Reply</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Post Reply</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<onevent type=\"onenterforward\">";
echo "<refresh>
<setvar name=\"reptxt\" value=\"\"/>
";
echo "</refresh></onevent>";
echo "<b>Topic Reply:</b> <br/><form action=\"forumsproc.php?action=post&clid=$clid\" method=\"post\">";
echo "<input name=\"reptxt\" maxlength=\"10000\"/><br/>";
echo "<input type=\"hidden\" name=\"tid\" value=\"$tid\"/>";
echo "<input type=\"submit\" value=\"Post\"/>";
echo "</form>";
echo "<br/><br/>";
echo "<img src=\"../avatars/prev.gif\"><a href=\"forums.php?page=$page&clid=$clid&tid=$tid\">Back to $tinfo[0] Topic</a>";
echo "<br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="hidetopic")
{
$who = mysql_real_escape_string($_GET["who"]);
$user = getnick_uid($who);
$tid =mysql_real_escape_string($_GET['tid']);
echo "<head>";
echo "<title>Hide Topic</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Hide Topic</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
$tinfo = mysql_fetch_array(mysql_query("SELECT name, text, authorid, crdate, views, fid, pollid from ibwff_topics WHERE id='".$tid."'"));
$tnm = htmlspecialchars($tinfo[0]);
echo "<br/>";
$res = mysql_query("UPDATE ibwff_topics SET udayhide='1' WHERE id='".$tid."'");
if($res)
{
mysql_query("INSERT INTO ibwff_mlog SET action='Hide Topic', details='<b>".getnick_uid(getuid_sid($sid))."</b> Hide The Topic<b> ".htmlspecialchars($tinfo[0])."</b>', actdt='".time()."'");
echo "<br/><img src=\"../avatars/ok.gif\" alt=\"O\"/>Topic Hidden Successfully!<br/><br/>";
}else{
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="showtopic")
{
$who = mysql_real_escape_string($_GET["who"]);
$user = getnick_uid($who);
$tid = mysql_real_escape_string($_GET['tid']);
echo "<head>";
echo "<title>Show Topic</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Show Topic</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
$tinfo = mysql_fetch_array(mysql_query("SELECT name, text, authorid, crdate, views, fid, pollid from ibwff_topics WHERE id='".$tid."'"));
$tnm = htmlspecialchars($tinfo[0]);
echo "<br/>";
$res = mysql_query("UPDATE ibwff_topics SET udayhide='0' WHERE id='".$tid."'");
if($res)
{
mysql_query("INSERT INTO ibwff_mlog SET action='Show Topic', details='<b>".getnick_uid(getuid_sid($sid))."</b> Show The Topic<b> ".htmlspecialchars($tinfo[0])."</b>', actdt='".time()."'");
echo "<br/><img src=\"../avatars/ok.gif\" alt=\"O\"/>Topic Showed Successfully!<br/><br/>";
}else{
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
/////////////////////Topic Options :)
else if($action=="tpcopt"){
$tid = $_GET["tid"];
addonline(getuid_sid($sid),"Viewing Topic Options","forums.php?action=$action");
$tinfo= mysql_fetch_array(mysql_query("SELECT name, fid, authorid, text, pinned, closed, ttyp FROM ibwff_topics WHERE id='".$tid."'"));
$trid = $tinfo[2];
$ttext = htmlspecialchars($tinfo[3]);
$tname = htmlspecialchars($tinfo[0]);
echo "<head>";
echo "<title>View Topic Option</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Topic Option</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<onevent type=\"onenterforward\">";
echo "<refresh>
<setvar name=\"ttext\" value=\"$ttext\"/>
<setvar name=\"tname\" value=\"$tname\"/>";
echo "</refresh></onevent>";
echo "Topic ID: <b>$tid</b><br/>";
$trnick = subnick(getnick_uid($tinfo[2]));
echo "<img src=\"../images/next.gif\" alt=\">\"><a href=\"profile.php?who=$trid\">View $trnick's Profile</a><br/>";
$plid = mysql_fetch_array(mysql_query("SELECT pollid FROM ibwff_topics WHERE id='".$tid."'"));
echo "<img src=\"../images/next.gif\" alt=\">\"><a href=\"forumsproc.php?action=rtpc&clid=$clid&tid=$tid\">Report this Topic</a><br/>";
$tfid = mysql_fetch_array(mysql_query("SELECT fid FROM ibwff_topics WHERE id='".$tid."'"));
$cfrm = mysql_fetch_array(mysql_query("SELECT clubid FROM ibwff_forums WHERE id='".$tfid[0]."'"));
if ($cfrm[0]>0)
{
$cname = getclubname($cfrm[0]);
echo "Club Name: <b>$cname</b><br/>";
}
$clid = $_GET["clid"];
if(forumboss($uid) || $tinfo[2]==$uid || isclubmod($uid,$clid)=="1" || isownerclub($uid,$clid)=="1")
{
echo "<form action=\"edit.php?action=rentpc&clid=$clid&tid=$tid\" method=\"post\">";
echo "<b>Topic Title:</b> <input name=\"tname\" value=\"$tname\" maxlength=\"300\"/>";
echo "<input type=\"submit\" value=\"Rename\"/>";
echo "</form>";
echo "<form action=\"edit.php?action=topic&clid=$clid&tid=$tid\" method=\"post\">";
echo "<b>Topic Text:</b> <input name=\"ttext\" value=\"$ttext\" maxlength=\"10000\"/>";
echo "<input type=\"submit\" value=\"Edit\"/>";
echo "</form>";
}
if(forumboss($uid))
{
if(!tpcvld_uday($tid))
{
echo "&#187; <a href=\"validate.php?action=valtpc&clid=$clid&tid=$tid\"><b>Validate $tname</b></a><br/>";
}
echo "<b>Move to:</b><br/>";
$forums = mysql_query("SELECT id, name FROM ibwff_forums WHERE clubid='0'");
echo "<form action=\"move.php?action=mvt&tid=$tid\" method=\"post\"><select id=\"inputText\" name=\"mtf\">";
while ($forum = mysql_fetch_array($forums)){
echo "<option value=\"$forum[0]\">".htmlspecialchars($forum[1])."</option>";
}
echo "</select><br/>";
echo "<input id=\"inputButton\" type=\"submit\" value=\"Move\"/>";
echo "</form>";
echo "<img src=\"../images/next.gif\" alt=\">\"><a href=\"delete.php?action=topic&clid=$clid&tid=$tid\">Delete</a><br/>";
if($tinfo[5]=='1')
{
$ctxt = "Open";
$cact = "0";
}else{
$ctxt = "Close";
$cact = "1";
}
echo "<img src=\"../images/next.gif\" alt=\">\"><a href=\"forumsproc.php?action=clot&clid=$clid&tid=$tid&tdo=$cact\">$ctxt</a><br/>";
if($tinfo[4]=='1')
{
$ptxt = "Unpin";
$pact = "0";
}else{
$ptxt = "Pin";
$pact = "1";
}
echo "<img src=\"../images/next.gif\" alt=\">\"><a href=\"modproc.php?action=pint&clid=$clid&tid=$tid&tdo=$pact\">$ptxt</a><br/>";
if($tinfo[6]=='1')
{
echo "<img src=\"../images/next.gif\" alt=\">\"><a href=\"forumsproc.php?action=upt&clid=$clid&tid=$tid\">Unlimited Post Topic</a><br/>";
}else{
echo "<img src=\"../images/next.gif\" alt=\">\"><a href=\"forumsproc.php?action=opt&clid=$clid&tid=$tid\">One Post Topic</a><br/>";
}
}
echo "&#171;<a href=\"forums.php?clid=$clid&tid=$tid\">Back to topic!</a><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
//////////////////////////////////////////Post Options :)
else if($action=="pstopt")
{
$pid = $_GET["pid"];
$page = $_GET["page"];
$fid = $_GET["fid"];
addonline(getuid_sid($sid),"Viewing Topics Post Options","forums.php?action=$action");
$pinfo= mysql_fetch_array(mysql_query("SELECT uid,tid, text  FROM ibwff_posts WHERE id='".$pid."'"));
$trid = $pinfo[0];
$tid = $pinfo[1];
$ptext = htmlspecialchars($pinfo[2]);
$trnick = subnick(getnick_uid($trid));
echo "<head>";
echo "<title>View $trnick Topic Post Option</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>$trnick Topics Post Option</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<onevent type=\"onenterforward\">";
echo "<refresh>
<setvar name=\"ptext\" value=\"$ptext\"/>";
echo "</refresh></onevent>";
echo "Topics Post ID: <b>$pid</b><br/>";
echo "<img src=\"../images/next.gif\" alt=\">\"><a href=\"profile.php?who=$trid\">View $trnick's Profile</a><br/>";
echo "<img src=\"../images/next.gif\" alt=\">\"><a href=\"forumsproc.php?action=rpost&clid=$clid&pid=$pid\">Report $trnick Posts</a><br/>";
echo "<img src=\"../images/next.gif\" alt=\">\"><a href=\"delete.php?action=post&clid=$clid&pid=$pid\">Delete This Post</a><br/>";
if((forumboss(getuid_sid($sid))) || ($trid==getuid_sid($sid)))
{
echo "<form action=\"edit.php?action=post&clid=$clid&pid=$pid\" method=\"post\">";
echo "<b>$trnick Post:</b> <input name=\"ptext\" value=\"$ptext\" maxlength=\"10000\"/>";
echo "<input type=\"submit\" value=\"Edit\"/>";
echo "</form>";
}
echo "<a href=\"forums.php?clid=$clid&tid=$tid&page=$page\">&#171;Back to topic</a><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
}
else if($action=="10posts")
{
echo "<head>";
echo "<title>Last Forum Post</title>";
echo "</head>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Last Forum Post</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
$sql = "SELECT a.name, b.uid, b.tid
FROM ibwff_topics a
INNER JOIN ibwff_posts b ON a.id = b.tid
ORDER BY b.id DESC
LIMIT 0 , 10";
$items = mysql_query($sql);
while ($item = mysql_fetch_array($items))
{
$sql2 = "SELECT name FROM ibwff_users WHERE id=$item[1]";
$sql22 = mysql_query($sql2);
$item2 = mysql_fetch_array($sql22);
{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item2[0]'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/>";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/>";}
if($sex[0]==""){$usersex = "";}
$avlink = getavatar($item[1]);
if($avlink=="")
{
$avt =  "$usersex";
}else{
$avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"icon\" width=\"23\" hieght=\"18\"/>";
}
$a = htmlspecialchars($item[0]);
$b = subnick(getnick_uid($item[1]));
$sql3 = "SELECT name FROM ibwff_users WHERE id=$item[1]";
$sql33 = mysql_query($sql3);
$item3 = mysql_fetch_array($sql33);
{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nicks = "<font color=\"blue\"><b>$b</b></font>";}
if($sex[0]=="F"){$nicks = "<font color=\"deeppink\"><b>$b</b></font>";}
if($sex[0]==""){$nicks = "";}
$c = "<a href=\"forums.php?clid=$clid&tid=$item[2]&go=last\">$a</a></b> ";
$d = "<a href=\"profile.php?who=$item[1]\"> $avt$nicks</a></b> ";
}
echo "<img src=\"../avatars/forums.gif\">$c By <b>$d</b><br/>";
}
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="10tpc")
{
addonline(getuid_sid($sid),"Viewing Last Forum Topics","forums.php?action=$action");
echo "<head>";
echo "<title>Last Forum Topics</title>";
echo "</head>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Last Forum Topics</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$sql = "SELECT name, authorid, fid
FROM ibwff_topics
ORDER BY id DESC
LIMIT 0 , 10";
$items = mysql_query($sql);
while ($item = mysql_fetch_array($items))
{
$sql2 = "SELECT name FROM ibwff_users WHERE id=$item[1]";
$sql22 = mysql_query($sql2);
$item2 = mysql_fetch_array($sql22);
{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item2[0]'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/>";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/>";}
if($sex[0]==""){$usersex = "";}
$avlink = getavatar($item[1]);
if($avlink=="")
{
$avt =  "$usersex";
}else{
$avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"icon\" width=\"23\" hieght=\"18\"/>";
}
$xT = htmlspecialchars($item[0]);
$b = subnick(getnick_uid($item[1]));
$sql3 = "SELECT name FROM ibwff_users WHERE id=$item[1]";
$sql33 = mysql_query($sql3);
$item3 = mysql_fetch_array($sql33);
{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nick = "<font color=\"blue\"><b>$b</b></font>";}
if($sex[0]=="F"){$nick = "<font color=\"deeppink\"><b>$b</b></font>";}
if($sex[0]==""){$nick = "";}
$c = "<a href=\"forums.php?clid=$clid&tid=$item[2]&go=last\">$item[0]</a>";
$d = "<a href=\"profile.php?who=$item[1]\">$avt$nick</a>";
}
echo "<img src=\"../avatars/forums.gif\">$c By <b>$d</b><br/>";
}
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="raters")
{
$tid = $_GET["tid"];
$t = mysql_fetch_array(mysql_query("SELECT name FROM ibwff_topics WHERE id='".$tid."'"));
$tname = htmlspecialchars($t[0]);
echo "<head>";
echo "<title>$tname Rater</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Viewing $tname Raters</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$c = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM uday_tpcrate WHERE tid='".$tid."'"));
if($c[0]<=0)
{
echo "<br/><img src=\"../images/notok.gif\" alt=\"x\">No Topic Raters Found!";
}else{
$sql = "SELECT uid FROM uday_tpcrate WHERE tid='".$tid."'";
$rate = mysql_query($sql);
while($rater = mysql_fetch_array($rate))
{
$unick = subnick(getnick_uid($rater[0]));
$sql2 = "SELECT name FROM ibwff_users WHERE id=$rater[0]";
$sql22 = mysql_query($sql2);
$item2 = mysql_fetch_array($sql22);
{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item2[0]'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/>";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/>";}
if($sex[0]==""){$usersex = "";}
if(isonline($rater[0]))
{
$iml = "<font color=\"green\">online!</font>";
}else{
$iml = "<font color=\"red\">offline!</font>";
}
$avlink = getavatar($rater[0]);
if($avlink=="")
{
$avt =  "$usersex";
}else{
$avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"icon\" width=\"23\" hieght=\"18\"/>";
}
$sql3 = "SELECT name FROM ibwff_users WHERE id=$rater[0]";
$sql33 = mysql_query($sql3);
$item3 = mysql_fetch_array($sql33);
{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nick = "<font color=\"blue\"><b>$unick</b></font>";}
if($sex[0]=="F"){$nick = "<font color=\"deeppink\"><b>$unick</b></font>";}
if($sex[0]==""){$nick = "";}
$a = mysql_fetch_array(mysql_query("SELECT rate, time FROM uday_tpcrate WHERE uid='".$rater[0]."' AND tid='".$tid."'"));
$bdt = $a[1] + (6*60*60);
$time = date("h:i A, D d M y",$bdt);
$ra = "<b>Rates: ($a[0]/5)</b>";
$usl = "<br/>$avt<a href=\"profile.php?who=$rater[0]\">$nick</a> $iml &#187; $time<br/>$ra";
}
}
echo "$usl<br/>";
}
}
echo "<br/><br/>";
echo "<img src=\"../images/prev.gif\" alt=\"<\"><a href=\"forums.php?clid=$clid&tid=$tid\"><b>Back To $tname Topic</b></a><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
?>
</html>