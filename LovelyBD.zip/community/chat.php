<?php
session_start();
include("config.php");
include("core.php");  connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo '<head>';
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"title\" content=\"FireBD.NeT\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From Megh: Don't Try To Hack OR else :P\">
<meta name=\"keywords\" content=\"Site Desined By Megh :) :)\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/></head>";
echo "<body>";
$action = $_GET["action"]; $sid = $_SESSION["sid"];
$id = $_GET["id"];
$clid = $_GET["clid"]; 
$rid = $_GET["rid"];
$rpw = $_GET["rpw"];
$uid = getuid_sid($sid);
$who = $_GET["who"];
$uexist = isuser($uid);
echo "<meta http-equiv=\"refresh\" content=\"50\"; url=\chat.php?clid=$clid&amp;rid=$rid\"/>";
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();
////////////////Ip Banned By CJ UDAY :)	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
    	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
echo "<br/>";
echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
$banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
$remain =  $banto[0] - time();
$rmsg = gettimemsg($remain);
echo "<b>Time Remaining: $rmsg</b><br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "</p>";
echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
$uid = getuid_sid($sid);
//////////////////Banned System Updated By CJ UDAY :)
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please Contact <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
/////////////////////Chat Ban By CJ UDAY :)
  $ban = mysql_fetch_array(mysql_query("SELECT chatban FROM ibwff_users WHERE id='".$uid."'"));
if($ban[0] > 0)
  {
	echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
        echo "</div>";
			 echo "<div class=\"header\" align=\"center\">";
			  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/><b><u><i>Can't ENTER To Chat Room<br/>";
  echo "You're Chat banned!</i></u></b><br/><br/>";
 echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php?action=main&sid=$sid\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
    exit();
    }
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
 echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
///////////////////Deactivated Account By CJ UDAY :)
          if(isdeactivated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  <b>Your Account Has Been Deactivated Forever.<br/>And It Will Be Never Activate!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
///////////////////Validation By CJ UDAY :)
					if(isvalidated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  You Are Not Validated!<br/>We are checking your ip and browser<br/>
	  This could take up to 15 munites pls be patient and try again soon<br/>Please try again later...<br/><b>Thank You</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
/////////////////////System By CJ UDAY :)
$uid=getuid_sid($sid);
  $total = mysql_fetch_array(mysql_query("SELECT totaltime,pu,cyberpowereragon FROM ibwff_users WHERE id='".$uid."'"));
if($total[0]<10800 && $total[1]<0 && $total[2]<0)
  {
$wh = subnick(getnick_uid($uid));
	    echo "<head>";
    echo "<title>$wh@Chat Room</title>";
    echo "</head>";
    echo "<body>";
echo "</div>";
echo "<div class=\"header\" align=\"left\">";
echo "<img src=\"FireBD.png\" alt=\"$sitename\" type=\"logo\" width=\"240\" height=\"50\"/><br/>";
			  echo "<b>Chat Room</b></div>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            
  echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
  echo "<br/><b>You Can't Enter To Chat Room</b><br/>";
  echo "Stay online for 3 hours to enter any Chat room!<br/><br/>";
 echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
    exit();
    }
$isroom = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_rooms WHERE id='".$rid."'"));
if($isroom[0]==0)
{
	echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
		echo "<div class=\"header\" align=\"center\">";
			echo "<b>Chat Menu</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
echo "<br/>Unknown Error !<br/>";
echo "Please Come Back Later :)<br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
$passworded = mysql_fetch_array(mysql_query("SELECT pass FROM ibwff_rooms WHERE id='".$rid."'"));
$rooms = mysql_fetch_array(mysql_query("SELECT id, name FROM ibwff_rooms WHERE id='".$rid."'"));
$rname = $rooms[1];
if($passworded[0]!="")
{
if($rpw!=$passworded[0])
{
    echo "<head>";
    echo "<title>$rname</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"header\" align=\"left\">";
echo "<img src=\"FireBD.png\" alt=\"$sitename\" type=\"logo\" width=\"240\" height=\"50\"/><br/>";
echo "<b>$rname</b></div>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";		
			
						echo "<div class=\"shout2\" align=\"left\">";
	include("pm_by.php");
echo "<b>Enter Password!</b><br/><br/>";
echo "<b>Room Name:</b><br/>";
echo "$rname<br/>";
echo "<form action=\"chat.php&sid=$sid\" method=\"get\">";
echo "<b>Password:</b><br/><input type=\"rpw\" name=\"rpw\"  maxlength=\"10\"/><br/>";
echo "<input type=\"submit\" value=\"Enter\"/>";  
echo "</form>";  
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
exit();
}
}
$staff = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_rooms WHERE id='".$rid."'"));
if($staff[0]==1)
{
if(!ismod(getuid_sid($sid)))
{
$rooms = mysql_fetch_array(mysql_query("SELECT name FROM ibwff_rooms WHERE id='".$rid."'"));
$rname = $rooms[0];
	    echo "<head>";
    echo "<title>$rname</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";		echo "<div class=\"header\" align=\"center\">";
			echo "<b>$rname</b></div>";
  echo "<div class=\"shout2\" align=\"left\">";
echo "<br/><img src=\"../avatars/notok.gif\"><b>Only Staffs Can Enter This Room!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
}
$staff = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_rooms WHERE id='".$rid."'"));
if($staff[0]==2)
{
if(!ispu(getuid_sid($sid)) && !ismod(getuid_sid($sid)))
{
$rooms = mysql_fetch_array(mysql_query("SELECT name FROM ibwff_rooms WHERE id='".$rid."'"));
$rname = $rooms[0];
	    echo "<head>";
    echo "<title>$rname</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
	echo "<div class=\"header\" align=\"center\">";
			echo "<b>$rname</b></div>";
  echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<br/><img src=\"../avatars/notok.gif\"><b>Only Premium Members Can Enter This Room!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
}
$vip = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_rooms WHERE id='".$rid."'"));
if($vip[0]==3)
{
if(!isvip(getuid_sid($sid)) && !ismod(getuid_sid($sid)))
{
$rooms = mysql_fetch_array(mysql_query("SELECT name FROM ibwff_rooms WHERE id='".$rid."'"));
$rname = $rooms[0];
	    echo "<head>";
    echo "<title>$rname</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";							echo "<div class=\"header\" align=\"center\">";
			echo "<b>$rname</b></div>";
  echo "<div class=\"shout2\" align=\"left\">";
echo "<br/><img src=\"../avatars/notok.gif\"><b>Only Vip Members Can Enter This Room!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
}
addtochat($uid, $rid);
$timeto = 900;
$timenw = time();
$timeout = $timenw-$timeto;
$deleted = mysql_query("DELETE FROM ibwff_chat WHERE timesent<".$timeout."");
if($action=="")
{
$rooms = mysql_fetch_array(mysql_query("SELECT id, name, pass FROM ibwff_rooms WHERE id='".$rid."'"));
$rname = $rooms[1];
    echo "<head>";
    echo "<title>Chating In $rname</title>";
    echo "</head>";
    echo "<body>";
		echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Chating In $rname</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
$rooms = mysql_fetch_array(mysql_query("SELECT id, name FROM ibwff_rooms WHERE id='".$rid."'"));
$rname = $rooms[1];
addonline($uid,"Chating in <b>$rname</b>","chat.php?clid=$clid&amp;rid=$rid");
$lnk2 = date('dmHis');
include("pm_by.php");
echo "<b>Message:</b>";
echo "<form action=\"chat.php?clid=$clid&rid=$rid&rpw=$rpw\" method=\"post\">";
echo "<input name=\"message\" type=\"text\" maxlength=\"500\"/>";
echo "<input type=\"submit\" value=\"Send\"/>";    
echo "</form>";
echo "<a href=\"chat.php?time=$lnk2&clid=$clid&who=$who&rid=$rid&rpw=$rpw\">Refresh</a>";
$message=mysql_real_escape_string($_POST["message"]);
$who = mysql_real_escape_string($_GET["who"]);
$rinfo = mysql_fetch_array(mysql_query("SELECT censord, freaky FROM ibwff_rooms WHERE id='".$rid."'"));
if(trim($message) != "")
{
$nosm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_chat WHERE msgtext='".$message."'"));
if($nosm[0]==0){
if(strlen($message)>0) {
$chatok = mysql_query("INSERT INTO ibwff_chat SET  chatter='".$uid."', who='".$who."', timesent='".time()."', msgtext='".$message."', rid='".$rid."';");
if($chatok) {
 $cow = mysql_fetch_array(mysql_query("SELECT plusses FROM ibwff_users WHERE id='".$uid."'"));
 $cpoint = cpoint();
$upl = $cow[0]+$cpoint;
 mysql_query("UPDATE ibwff_users SET plusses='".$upl."' WHERE id='".$uid."'");
 $cli = mysql_fetch_array(mysql_query("SELECT clubid FROM ibwff_rooms WHERE id='".$rid."'"));
$clid = $cli[0];
if ($clid>0)
{
mysql_query("UPDATE ibwff_clubs SET plusses=plusses+1 WHERE id='".$clid."'");
mysql_query("UPDATE ibwff_clubmembers SET points=points+1 WHERE uid='".$uid."', clid='".$clid."'");
$name = getclubname($clid);
}
		}
}
$lstmsg = mysql_query("UPDATE ibwff_rooms SET lastmsg='".time()."' WHERE id='".$rid."'");
$hehe=mysql_fetch_array(mysql_query("SELECT chmsgs,plusses FROM ibwff_users WHERE id='".$uid."'"));
$totl = $hehe[0]+1;
$msgst= mysql_query("UPDATE ibwff_users SET chmsgs='".$totl."' WHERE id='".$uid."'");
if($rinfo[1]==2)
{
$botid = "adc8c4b82e36a644";
$hostname = "www.pandorabots.com";
$hostpath = "/pandora/talk-xml";
$sendData = "botid=".$botid."&input=".urlencode($message)."&custid=".$custid;
$result = PostToHost($hostname, $hostpath, $sendData);
$pos = strpos($result, "custid=\"");
$pos = strpos($result, "<that>");
if ($pos === false) {
$reply = "";
} else {
$pos += 32;
$endpos = strpos($result, "</that>", $pos);
$reply = unhtmlspecialchars2(substr($result, $pos, $endpos - $pos));
$reply = mysql_escape_string($reply);
}
$chatok = mysql_query("INSERT INTO ibwff_chat SET  chatter='3', who='', timesent='".time()."', msgtext='".$reply." @".getnick_uid($uid)."', rid='".$rid."';");
}
}
$message = "";
}
$chats = mysql_query("SELECT chatter, who, timesent, msgtext, exposed FROM ibwff_chat WHERE rid='".$rid."' ORDER BY timesent DESC, id DESC");
$counter=0;
while($chat = mysql_fetch_array($chats))
{
$canc = true;
if($counter<20)
{
if(istrashed($chat[0])){
if($uid!=$chat[0])
{
$canc = false;
}
}
if(isignored($chat[0],$uid)){
$canc = false;
}
if($chat[0]!=$uid)
{
if($chat[1]!=0)
{
if($chat[1]!=$uid)
{
$canc = false;
}
}
}
if($chat[4]=='1' && ismod($uid))
{
$canc = true;
}
if($canc)
{
$cmid = mysql_fetch_array(mysql_query("SELECT  chmood FROM ibwff_users WHERE id='".$chat[0]."'"));
$iml = "";
if(($cmid[0]!=0))
{
$mlnk = mysql_fetch_array(mysql_query("SELECT img, text FROM ibwff_moods WHERE id='".$cmid[0]."'"));
$iml = "<img src=\"$mlnk[0]\" alt=\"$mlnk[1]\"/>";
}
	    $sql = "SELECT name FROM ibwff_users WHERE id=$chat[0]";
	    $sql2 = mysql_query($sql);
	    $item = mysql_fetch_array($sql2);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item[0]'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/>";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/>";}
if($sex[0]==""){$usersex = "";}
        		$avlink = getavatar($chat[0]);
if($avlink=="")
{
 $avt =  "$usersex";
}else{
 $avt = "<img src=\"../avatars/$avlink\" alt=\"$avlink\" type=\"icon\" width=\"23\" height=\"18\"/>";
}
$chnick = subnick(getnick_uid($chat[0]));
	    $sql3 = "SELECT name FROM ibwff_users WHERE id=$chat[0]";
	    $sql33 = mysql_query($sql3);
	    $item3 = mysql_fetch_array($sql33);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nicks = "<font color=\"blue\"><b>$chnick</b></font>";}
if($sex[0]=="F"){$nicks = "<font color=\"deeppink\"><b>$chnick</b></font>";}
if($sex[0]==""){$nicks = "";}
$optlink = $avt.$nicks;
}
}
if(($chat[1]!=0)&&($chat[0]==$uid)|| ($chat[1]!=0)&&chatboss(getuid_sid($sid)))
{
$iml = "<img src=\"../moods/out.gif\" alt=\"!\"/>";
$chnick = getnick_uid($chat[1]);
$optlink = $iml."PM to ".$chnick;
}
if($chat[1]==$uid || ($chat[1]!=0)&&chatboss(getuid_sid($sid)))
{
$iml = "<img src=\"../moods/in.gif\" alt=\"!\"/>";
$chnick = getnick_uid($chat[0]);
$optlink = $iml."PM by ".$chnick;
}
if($chat[4]=='1')
{
$iml = "<img src=\"../moods/points.gif\" alt=\"!\"/>";
$chnick = getnick_uid($chat[0]);
$tonick = getnick_uid($chat[1]);
$optlink = "$iml by ".$chnick." to ".$tonick;
}
$ds= date("H.i.s", $chat[2]);
$text = parsepm($chat[3], $sid);
$nos = substr_count($text,"<img src=");
if(isspam($text))
{
$chnick = getnick_uid($chat[0]);
}
else if($nos>2){
$chnick = getnick_uid($chat[0]);
}else{
$sres = substr($chat[3],0,3);
if($sres == "/asdhi")
{
$chco = strlen($chat[3]);
$goto = $chco - 3;
$rest = substr($chat[3],3,$goto);
$tosay = parsepm($rest, $sid);
echo "<b><i>*$chnick $tosay*</i></b><br/>";
}else{
$tosay = parsepm($chat[3], $sid);
if($rinfo[0]==1)
{
$tosay = str_replace("l0tir","**BAN**",$tosay);
$tosay = str_replace("kanki","**BAN**",$tosay);
$tosay = str_replace("l0ti","**BAN**",$tosay);
$tosay = str_replace("cudi","**BAN**",$tosay);
$tosay = str_replace("madarcod","**BAN**",$tosay);
$tosay = str_replace("khanki","**BAN**",$tosay);
$tosay = str_replace("loti","**BAN**",$tosay);
$tosay = str_replace("lotir","**BAN**",$tosay);
$tosay = str_replace("codo","**BAN**",$tosay);
$tosay = str_replace("chodamu","**BAN**",$tosay);
$tosay = str_replace("chodbo","**BAN**",$tosay);
$tosay = str_replace("boob","**BAN**",$tosay);
$tosay = str_replace("sex","**BAN**",$tosay);
$tosay = str_replace("magi","**BAN**",$tosay);
$tosay = str_replace("pola","**BAN**",$tosay);
$tosay = str_replace("kutta","**BAN**",$tosay);
$tosay = str_replace("bonke","**BAN**",$tosay);
$tosay = str_replace("makee","**BAN**",$tosay);
$tosay = str_replace("chudi","**BAN**",$tosay);
$tosay = str_replace("cudi","**BAN**",$tosay);
$tosay = str_replace("motherchod","**BAN**",$tosay);
$tosay = str_replace("bowke","**BAN**",$tosay);
$tosay = str_replace("boke","**BAN**",$tosay);
$tosay = str_replace("ChUdi","**BAN**",$tosay);
$tosay = str_replace("mafia","****",$tosay);
$tosay = str_replace("onibbd","****",$tosay);
$tosay = str_replace("mycitywap","****",$tosay);
$tosay = str_replace("tufanbd","****",$tosay);
$tosay = str_replace("rockerwap","****",$tosay);
$tosay = str_replace("friendsdiary","****",$tosay);
$tosay = str_replace("fr1endsd1ary","****",$tosay);
$tosay = str_replace("frLendsdLary","****",$tosay);
$tosay = str_replace("dewb","****",$tosay);
$tosay = str_replace("FestalBD","****",$tosay);
$tosay = str_replace("rosebd","****",$tosay);
$tosay = str_replace("cyberlife","****",$tosay);
$tosay = str_replace("cyberwap24","****",$tosay);
$tosay = str_replace("dhakawap","****",$tosay);
$tosay = str_replace("bdforum","****",$tosay);
$tosay = str_replace("fusiounbd","****",$tosay);
$tosay = str_replace("SuperBD","****",$tosay);
$tosay = str_replace("lavawap","****",$tosay);
$tosay = str_replace("mygx4","****",$tosay);
$tosay = str_replace("aponworld","****",$tosay);
$tosay = str_replace("ApOn","****",$tosay);
$tosay = str_replace("Combondhu","****",$tosay);
$tosay = str_replace("groupCombd","****",$tosay);
$tosay = str_replace("bondhunir","****",$tosay);
$tosay = str_replace("bondhuwap","****",$tosay);
$tosay = str_replace("dreamsea","****",$tosay);
$tosay = str_replace("remixchat","****",$tosay);
$tosay = str_replace("remixwap","****",$tosay);
$tosay = str_replace("cybers","****",$tosay);
$tosay = str_replace("bdforum","****",$tosay);
$tosay = str_replace("dhakawap","****",$tosay);
$tosay = str_replace("bondhujogot","****",$tosay);
$tosay = str_replace("bdcircle","****",$tosay);
$tosay = str_replace("chatbd24","****",$tosay);
$tosay = str_replace("icforum","****",$tosay);
$tosay = str_replace("onlinebd24","****",$tosay);
$tosay = str_replace("peacefulbd","****",$tosay);
$tosay = str_replace("com","****",$tosay);
$tosay = str_replace(".Com","****",$tosay);
$tosay = str_replace("tk","****",$tosay);
$tosay = str_replace("wapka","****",$tosay);
$tosay = str_replace("wap","****",$tosay);
$tosay = str_replace("web","****",$tosay);
$tosay = str_replace("bd","**",$tosay);
$tosay = str_replace("mobi","****",$tosay);
}
if($rinfo[1]==1)
{
$tosay = htmlspecialchars($chat[3]);
$tosay = strrev($tosay);
}
echo "<br/><a href=\"chat.php?action=say2&who=$chat[0]&amp;rid=$rid&amp;rpw=$rpw&sid=$sid\">$optlink</a> -";
echo $tosay."";
}
}
$counter++;
}
}
}
echo "<br/>";
echo "</small>
<a href=\"chat.php?time=$lnk2&clid=$clid&who=$who&rid=$rid&rpw=$rpw\">Refresh</a>";
echo "<br/>";
echo "<b>Message:</b>";
echo "<form action=\"chat.php?clid=$clid&rid=$rid&rpw=$rpw\" method=\"post\">";
echo "<input name=\"message\" type=\"text\" maxlength=\"500\"/>";
echo "<input type=\"submit\" value=\"Send\"/>";    
echo "</form>";
echo "<br/>";
echo "<small>";
echo "<big><b>Chat Online</b></big> : <br/>";
$inside=mysql_query("SELECT DISTINCT * FROM ibwff_chonline WHERE rid='".$rid."' and uid IS NOT NULL");
while($ins=mysql_fetch_array($inside))
{
$unick = getnick_uid($ins[1]);
	    $sql = "SELECT name FROM ibwff_users WHERE id=$ins[1]";
	    $sql2 = mysql_query($sql);
	    $item = mysql_fetch_array($sql2);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item[0]'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/>";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/>";}
if($sex[0]==""){$usersex = "";}
        		$avlink = getavatar($ins[1]);
if($avlink=="")
{
 $avt =  "$usersex";
}else{
 $avt = "<img src=\"../avatars/$avlink\" alt=\"$avlink\" type=\"icon\" width=\"23\" height=\"18\"/>";
}
	    $sql3 = "SELECT name FROM ibwff_users WHERE id=$ins[1]";
	    $sql33 = mysql_query($sql3);
	    $item3 = mysql_fetch_array($sql33);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nick = "<font color=\"blue\"><b>$unick</b></font>";}
if($sex[0]=="F"){$nick = "<font color=\"deeppink\"><b>$unick</b></font>";}
if($sex[0]==""){$nick = "";}
$userl = "<a href=\"chat.php?action=say2&clid=$clid&who=$ins[1]&rid=$rid&rpw=$rpw\">$nick</a> ,";
echo "$userl";
}}}
echo"<br/><br/>
<img src=\"../avatars/smilies.gif\" alt=\":)\" type=\"icon\"><a href=\"smilies.php?action=smilies\">Smilies List</a><br/>
<img src=\"../avatars/chat.gif\" alt=\"!\" type=\"icon\"><a href=\"ch@t.php?action=chat\">Chat Rooms</a><br/>
<img src=\"../avatars/credit.png\" alt=\"*\" type=\"icon\"><a href=\"online.php?action=stfol\">Staffs Online</a><br/>";
echo "<small>[N.B: Use Mobile To Avoid Auto Refresh!]</small>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
/////////////////////////////////////////////////////SAY By CJ UDAY :-)
else if ($action=="say2")   
             {
echo "<head>";
    echo "<title>Chating Members Options</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
						echo "<div class=\"header\" align=\"center\">";
			echo "<b>Chating Member's Option</b></div>";
						echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
   echo "<div align=\"left\">";
$unick = getnick_uid($who);
echo "<b>Chat Msg to $unick</b>";
echo "</small></p>";
addonline($uid,"Writing Chat Message","main.php?action=chat");
$rname = mysql_fetch_array(mysql_query("SELECT name FROM ibwff_rooms WHERE id='".$rid."'"));
echo "Message:<form action=\"chat.php?clid=$clid&rid=$rid&rpw=$rpw&who=$who\" method=\"post\">";
   echo "<input name=\"message\" type=\"text\" maxlength=\"500\"/><br/>";
echo "<input type=\"submit\" value=\"Send\"/>";    
echo "</form><br/>";
echo "<a href=\"chat.php?clid=$clid&rid=$rid&rpw=$rpw\">Back To $rname[0]</a></small></p>";
echo "<a href=\"profile.php?who=$who\">&#187; View $unick's Profile</a><br/>";
echo "<a href=\"chat.php?action=expose&clid=$clid&who=$who&rid=$rid&rpw=$rpw\">&#187; Expose $unick</a><br/>";
echo "</div></div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if ($action=="expose")           
{
addonline($uid,"Exposing A Member Chat Message","chat.php?action=$action");
    echo "<head>";
    echo "<title>Expose A Member Message</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
						echo "<div class=\"header\" align=\"center\">";
			echo "<b>Exposed A Member Chat Message</b></div>";
						echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
mysql_query("UPDATE ibwff_chat SET exposed='1' WHERE chatter='".$who."' AND who='".$uid."'");
$unick = getnick_uid($who);
echo "$unick Messages to you have been exposed to staff!";
echo "<br/><br/>";
echo "<a href=\"chat.php?clid=$clid&rid=$rid&rpw=$rpw\">&#171;Chatroom</a><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
?>
</html>