<?php
$start = microtime(true);
include("config.php");
include("core.php");
connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo "<head>";
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG : Don't Try To Hack OR else :P\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"main,all,follow\"/></head>";
echo "<body>";
$action = $_GET["action"]; $sid = $_GET["sid"];
$page = $_GET["page"];
$who = $_GET["who"];
$uid = getuid_sid($sid);
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
echo "<br/>";
echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
$banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
$remain =  $banto[0] - time();
$rmsg = gettimemsg($remain);
echo "<b>Time Remaining: $rmsg</b><br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "</p>";
echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
 echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");  
echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"left\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "<div class=\"div align=\"center\">Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");  
echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please Contact <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(isdeactivated(getuid_sid($sid), $uid))
{
echo "<head>";
echo "<title>Error!!!</title>";
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"Styles.css\"/>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<br/><b>Your Account Has Been Deactivated.<br/>And It Will Be Never Activated Again!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="reqs")
{
    addonline(getuid_sid($sid),"Viewing Relative Requests List","Relatives.php?action=$action");
	    echo "<head>";
    echo "<title>View Relative Requests List</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
    echo "<div class=\"header\" align=\"center\">";
	echo "<b>Relative Requests</b><br/>";
$uid = getuid_sid($sid);
$remp = 50 - getnrels($uid);
    echo "You Have $remp Places left";
echo "</div>";
	echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
   echo "The following members want you to add them to your relative list.";
    if($page=="" || $page<=0)$page=1;
    $nor = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_relatives WHERE tid='".$uid."' AND agreed='0'"));
    $num_items = $nor[0]; $items_per_page= 7;
    $num_pages = ceil($num_items/$items_per_page);
    if(($page>$num_pages)&&$page!=1)$page= $num_pages;
    $limit_start = ($page-1)*$items_per_page;
        $sql = "SELECT uid, relation  FROM ibwf_relatives WHERE tid='".$uid."' AND agreed='0' ORDER BY reqdt DESC LIMIT $limit_start, $items_per_page";
    echo "<p>";
    $items = mysql_query($sql);
    if(mysql_num_rows($items)>0)
    {
    while ($item = mysql_fetch_array($items))
    {
	    $sql2 = "SELECT name FROM ibwff_users WHERE id=$item[0]";
	    $sql22 = mysql_query($sql2);
	    $item2 = mysql_fetch_array($sql22);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item2[0]'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/>";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/>";}
if($sex[0]==""){$usersex = "";}
$avlink = getavatar($item[0]);
if($avlink=="")
{
 $avt =  "$usersex";
}else{
 $avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"icon\" width=\"23\" height=\"18\"/>";
}
$noi = mysql_fetch_array(mysql_query("SELECT lastact FROM ibwf_users WHERE id='".$item[0]."'"));
$rnick = subnick(getnick_uid($item[0]));
$sql3 = "SELECT name FROM ibwff_users WHERE id=$item[0]";
$sql33 = mysql_query($sql3);
$item3 = mysql_fetch_array($sql33);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nicks = "<font color=\"blue\"><b>$rnick</b></font>";}
if($sex[0]=="F"){$nicks = "<font color=\"deeppink\"><b>$rnick</b></font>";}
if($sex[0]==""){$nicks = "";}
      $lnk = "$avt<a href=\"profile.php?action=viewuser&amp;who=$item[0]&sid=$sid\">$nicks</a><br/>Relation: <b>$item[1]</b> : <a href=\"relativesproc.php?action=add&amp;who=$item[0]&sid=$sid\">Accept</a>,<a href=\"relativesproc.php?action=del&amp;who=$item[0]&sid=$sid\">Deny</a>";
      echo "$lnk<br/>";
	}
	}
    }
    }
    if($page>1)
    {
      $ppage = $page-1;
      echo "<a href=\"Relatives.php?action=$action&amp;page=$ppage&who=$who&sid=$sid\">&#171;-Prev</a> ";
    }
    if($page<$num_pages)
    {
      $npage = $page+1;
      echo "<a href=\"Relatives.php?action=$action&amp;page=$npage&who=$who&sid=$sid\">Next-&#187;</a>";
    }
    echo "Page - $page/$num_pages<br/>";
    if($num_pages>2)
    {
			        $rets = "<form action=\"Relatives.php&sid=$sid\" method=\"get\">";
        $rets .= "<input name=\"page\" style=\"-wap-input-format: '*N'\" size=\"2\"/>";
        $rets .= "<input type=\"hidden\" name=\"action\" value=\"$action\"/>";
        $rets .= "<input type=\"hidden\" name=\"sid\" value=\"$sid\"/>";
	  $rets .= "<input type=\"submit\" value=\"Go To Page\"/>";
        $rets .= "</form>";
        echo $rets;
    }
echo "&#187; <a href=\"relativesproc.php?action=aall&who=$who&sid=$sid\">Accept All Relation Requests</a><br/>&#187; <a href=\"relativesproc.php?action=dall&who=$who&sid=$sid\">Deny All Relation Requests</a>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php?action=main&sid=$sid\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
//////////////////////////////////Relatives Updated by CJ UDAY:)
else if($action=="main")
{
    $who = $_GET["who"];
	$whonick = subnick(getnick_uid($uid));
    addonline(getuid_sid($sid),"Viewing $whonick's Relatives List","Relatives.php?action=main");
	    echo "<head>";
    echo "<title>View $whonick's Relatives Lists</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
$fxid = getuid_sid($sid);
$x = getonrels($fxid);
			echo "<b>Online Relatives $x</b></div>";
  echo "<div class=\"shout2\" align=\"left\">";
    include("pm_by.php");
    $uid = getuid_sid($sid);
$y = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_relatives WHERE tid='".$uid."' AND agreed=0"));
if($y[0] > 0)
{
echo "<b>&#187;</b> <a href=\"Relatives.php?action=reqs&who=$who&sid=$sid\"><b>$y[0] Relatives Requests Waiting!</b></a><br/>";
}
$z = getnrels($fxid);
echo "<b>&#187;</b> <a href=\"Relatives.php?action=relatives&sid=$sid&who=$uid&sid=$sid\"><b>All Relatives</b></a> <b>[$z]</b><br/>";
    if($page=="" || $page<=0)$page=1;
    $num_items = getnrels($uid); 
    $items_per_page= 7;
    $num_pages = ceil($num_items/$items_per_page);
    if(($page>$num_pages)&&$page!=1)$page= $num_pages;
    $limit_start = ($page-1)*$items_per_page;
$sql = "SELECT a.lastact, a.name, a.id, b.uid, b.tid, b.reqdt FROM ibwf_users a INNER JOIN ibwf_relatives b ON (a.id = b.uid) OR (a.id=b.tid) WHERE (b.uid='".$uid."' OR b.tid='".$uid."') AND b.agreed='1' AND a.id!='".$uid."' GROUP BY 1,2  ORDER BY a.lastact DESC LIMIT $limit_start, $items_per_page";
$items = mysql_query($sql);
if(mysql_num_rows($items)>0)
    {
    while ($item = mysql_fetch_array($items))
    {
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item[1]'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/> ";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/> ";}
if($sex[0]==""){$usersex = "";}
$avlink = getavatar($item[2]);
if($avlink=="")
{
 $avt =  "$usersex";
}else{
 $avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"icon\" width=\"23\" height=\"18\"/>";
}
$noi = mysql_fetch_array(mysql_query("SELECT lastact FROM ibwff_users WHERE id='".$item[2]."'"));
$remain = time() - $noi[0];
$idle = gettimemsg($remain);
	    $sql3 = "SELECT name FROM ibwff_users WHERE id=$item[2]";
	    $sql33 = mysql_query($sql3);
	    $item3 = mysql_fetch_array($sql33);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nicks = "<font color=\"blue\"><b>$item[1]</b></font>";}
if($sex[0]=="F"){$nicks = "<font color=\"deeppink\"><b>$item[1]</b></font>";}
if($sex[0]==""){$nicks = "";}
$uid = getuid_sid($sid);
$k = getonrels($uid);
if($k<=0)
{
echo "No Relatives Online!<br/>";
}else{    if(isonline($item[2]))
  {
    $uact = "Location: ";
    $plc = mysql_fetch_array(mysql_query("SELECT place FROM ibwff_online WHERE userid='".$item[2]."'"));
    $uact .= $plc[0];
      $lnk = "<a href=\"profile.php?action=viewuser&amp;who=$item[2]&sid=$sid\">$avt$nicks</a> &#187; $uact";
      echo "$lnk<br/>";
      echo "<small>Idle: $idle</small><br/>";
    }
    }
    }
    }
    }
  if($page>1)
    {
      $ppage = $page-1;
      echo "<a href=\"Relatives.php?action=main&amp;page=$ppage&who=$who&sid=$sid\">&#171;-Prev</a> ";
    }
    if($page<$num_pages)
    {
      $npage = $page+1;
      echo "<a href=\"Relatives.php?action=main&amp;page=$npage&who=$who&sid=$sid\">Next-&#187;</a>";
    }
    if($num_pages>2)
    {
			        $rets = "<form action=\"Relatives.php&sid=$sid\" method=\"get\">";
        $rets .= "<input name=\"page\" style=\"-wap-input-format: '*N'\" size=\"2\"/>";
        $rets .= "<input type=\"hidden\" name=\"action\" value=\"$action\"/>";
        $rets .= "<input type=\"hidden\" name=\"sid\" value=\"$sid\"/>";
		$rets .= "<input type=\"submit\" value=\"Go To Page\"/>";
        $rets .= "</form>";
        echo $rets;
    }
echo "&#187; <a href=\"Relatives.php?action=reall&who=$who&sid=$sid\">Remove All Relatives</a><br/>";
    echo "</div>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php?action=main&sid=$sid\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="relatives")
{
$w = $_GET["who"];
$vn = subnick(getnick_uid($w));
    addonline(getuid_sid($sid),"Viewing $vn's Relative List","Relatives.php?action=$action");
	    echo "<head>";
    echo "<title>View $vn's Relatives</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
    echo "<div class=\"header\" align=\"center\">";
	echo "<b>$vn's Relatives</b></div>";
	echo "<div class=\"shout2\" align=\"left\">";
	include("pm_by.php");
	echo "<br/>";
    if($page=="" || $page<=0)$page=1;
    $noi = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_relatives WHERE (tid='".$w."' AND agreed='1') OR (uid='".$w."' AND agreed='1')"));
$num_items = $noi[0]; 
    $items_per_page= 10;
    $num_pages = ceil($num_items/$items_per_page);
    if(($page>$num_pages)&&$page!=1)$page= $num_pages;
    $limit_start = ($page-1)*$items_per_page;
 
 $sql = "SELECT a.lastact, a.name, a.id, a.totaltime, b.uid, b.tid, b.reqdt, b.relation FROM ibwff_users a INNER JOIN ibwf_relatives b ON (a.id = b.uid) OR (a.id=b.tid) WHERE (b.uid='".$w."' OR b.tid='".$w."') AND b.agreed='1' AND a.id!='".$w."' GROUP BY 1,2  ORDER BY a.lastact DESC LIMIT $limit_start, $items_per_page";
    $items = mysql_query($sql);
    if(mysql_num_rows($items)>0)
    {
    while ($item = mysql_fetch_array($items))
    {
	    $sql2 = "SELECT name, birthday, location, sex FROM ibwff_users WHERE id=$item[2]";
	    $sql22 = mysql_query($sql2);
	    $item2 = mysql_fetch_array($sql22);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item2[0]'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/>";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/>";}
if($sex[0]==""){$usersex = "";}
          if(isonline($item[2]))
  {
    $iml = "<font color=\"green\">online!</font>";
  }else{
    $iml = "<font color=\"red\">0ffline!</font>";
  }
        		$avlink = getavatar($item[2]);
if($avlink=="")
{
 $avt =  "$usersex";
}else{
 $avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"icon\" width=\"23\" height=\"18\"/>";
}
$clnm = mysql_fetch_array(mysql_query("SELECT name FROM ibwff_users WHERE id='".$item[2]."'"));
	    $sql3 = "SELECT name FROM ibwff_users WHERE id=$item[2]";
	    $sql33 = mysql_query($sql3);
	    $item3 = mysql_fetch_array($sql33);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nicks = "<font color=\"blue\"><b>".htmlspecialchars($clnm[0])."</b></font>";}
if($sex[0]=="F"){$nicks = "<font color=\"deeppink\"><b>".htmlspecialchars($clnm[0])."</b></font>";}
if($sex[0]==""){$nicks = "";}
$noi = mysql_fetch_array(mysql_query("SELECT lastact FROM ibwff_users WHERE id='".$item[2]."'"));
$remain = time() - $noi[0];
$idle = gettimemsg($remain);
$bs = date("h:i A, D d F y",$item[0]);
$xz = getage($item2[1]);
$d = mysql_fetch_array(mysql_query("SELECT relation FROM ibwf_relatives WHERE (uid='".$uid."' AND tid='".$w."') OR (uid='".$w."' AND tid='".$uid."') AND agreed='1'"));
      $lnk = "<a href=\"profile.php?action=viewuser&amp;who=$item[2]&amp;sid=$sid\">$avt$nicks</a>  ($xz / $item2[3] / $item2[2]): 
<b>$item[7]</b> $iml<br/>Since: $bs<br/>Idle: $idle<br/>";
      echo "$lnk";
	  if($uid == $w)
      {
	  echo "<small><a href=\"relativesproc.php?action=del&amp;who=$item[2]&sid=$sid\">[Remove]</a></small><br/>";
	  }
	}
	}
    }
    }else{
	echo "<img src=\"../avatars/notok.gif\" alt=\"X\"><b>No Relatives Found!</b>";
	}
    if($page>1)
    {
      $ppage = $page-1;
      echo "<a href=\"Relatives.php?action=$action&amp;page=$ppage&who=$who&sid=$sid\">&#171;-Prev</a> ";
    }
    if($page<$num_pages)
    {
      $npage = $page+1;
      echo "<a href=\"Relatives.php?action=$action&amp;page=$npage&who=$who&sid=$sid\">Next-&#187;</a>";
    }
    echo "<br/>Page - $page/$num_pages<br/>";
    if($num_pages>2)
    {
			        $rets = "<form action=\"Relatives.php&sid=$sid\" method=\"get\">";
        $rets .= "<input name=\"page\" style=\"-wap-input-format: '*N'\" size=\"2\"/>";
        $rets .= "<input type=\"hidden\" name=\"action\" value=\"$action\"/>";
        $rets .= "<input type=\"hidden\" name=\"sid\" value=\"$sid\"/>";
		$rets .= "<input type=\"hidden\" name=\"who\" value=\"$who\"/>";
		$rets .= "<input type=\"submit\" value=\"Go To Page\"/>";
        $rets .= "</form>";
        echo $rets;
    }
echo "&#171; <a href=\"profile.php?action=viewuser&amp;who=$who&sid=$sid\">Back to Profile!</a>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php?action=main&sid=$sid\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
exit();
}
else if($action=="reall")
{
addonline(getuid_sid($sid),"Removing Relatives From List","relativesproc.php?action=$action");
echo "<head>";
echo "<title>Relatives</title>";
  echo "</head>"; 
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
    echo "<div class=\"header\" align=\"center\">";
	echo "<b>Friends Status</b></div>";
    echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
      $res= mysql_query("DELETE FROM ibwf_relatives WHERE (agreed='1' AND tid='".$uid."') OR (agreed='1' AND uid='".$uid."')");
if($res)
{
echo "<br/><img src=\"../avatars/ok.gif\" alt=\"o\"/>All Relatives Deleted Successfully!<br/><br/>";
           mysql_query("INSERT INTO ibwf_notifications SET text='[user=$uid]$nick"."[/user] Removed You From Relative!', touid='".$who."', timesent='".time()."'");
	   }else{
          echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>Can't Delete All Relative At This Moment.<br/>";
        }
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php?action=main&sid=$sid\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
exit();
}
?>
</html>