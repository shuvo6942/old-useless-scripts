<?php
define('PHP_FIREWALL_REQUEST_URI', strip_tags( $_SERVER['REQUEST_URI'] ) );
define('PHP_FIREWALL_ACTIVATION', true );
if ( is_file( @dirname(__FILE__).'/php-firewall/firewall.php' ) )
	include_once( @dirname(__FILE__).'/php-firewall/firewall.php' );

$start = microtime(true);
ini_set('arg_separator.output','&');
ini_set('display_errors','0');
function eragonbadquery($str) { 
        $search=array("\\","\0","\n","\r","\x1a","'",'"'); 
                $replace=array("\\\\","\\0","\\n","\\r","\Z","\'",'\"'); 
                return str_replace($search,$replace,$str); 
    } 
function eragonsqlsecurityclean($str) { 
        $str = @trim($str);
        $str = eragonbadquery($str);
        $str = htmlspecialchars($str); 
        $str = strip_tags($str); 
        $str = stripslashes($str); 
        $str = stripslashes($str); 
        $str = addslashes($str); 
    return mysql_real_escape_string($str); 
    }
	if (!get_magic_quotes_gpc()) 
{
foreach ($_GET as $key => $value) {$_GET[$key] = addslashes(eragonbadquery(strip_tags(htmlspecialchars($value)))); }
foreach ($_POST as $key => $value) {$_POST[$key] = addslashes(eragonbadquery(strip_tags(htmlspecialchars($value)))); }
foreach ($_REQUEST as $key => $value) {$_REQUEST[$key] = addslashes(eragonbadquery(strip_tags(htmlspecialchars($value)))); }
foreach ($_SERVER as $key => $value) {$_SERVER[$key] = addslashes(eragonbadquery(strip_tags(htmlspecialchars($value)))); }
foreach ($_COOKIE as $key => $value) {$_COOKIE[$key] = addslashes(eragonbadquery(strip_tags(htmlspecialchars($value)))); }
}
function Quary_Filter($string) 
{
 $badWords = "(union)|(insert)|(drop)|(http)|(iframe)|(script)|(--)|(>)|(<)|(')|(^)|(#)|(%)|(php)|(rp)|(madarchod)|(chod)|(fuck)|(mastercredit)|(bdremix)|(khanki)|(benchod)|(www)|(plusbd)|(magi)|(gand)|(lund)|(boobs)|(bhosdi)|(lauda)|(baap)|(bhosda)|(rockerwap)|(r0ck)|(n3t)|(spicecult)|(perm)|(cyberpowereragon='7')|(perm='4')|(perm=4)|(plusess)|(,)|(rosebd)|(dewb)|(friendsdiary)|(rockerwap)|(aponworld)|(mysuperwap)|(cooldhaka)|(chatbookbd)|(peacefulbd)"; 
 $string = eregi_replace($badWords, "", $string);
 $string = preg_replace(array('/[^a-zA-Z0-9\ \-\_\/\*\(\)\[\]\?\.\,\:\&\@\=\ ]/'),array('', '', ''),$string);
 $string = mysql_real_escape_string(htmlspecialchars($string)); 
return $string;
 }
//////////Can't Inject A injection! By CJ UDAY :)
 function injecter(){
$badchars = array("TRUNCATE","META","SCRIPT","EXEC","CAST","DECLARE","CHAR","DROP", "SELECT", "fuck", "DELETE", "INSERT" , "UNION", "WHERE", "FROM","madrchod","CHUDI","plusbd","perm='4","bhenchod","livechat","w4c","w2c","madarchod", "CONVERT");
foreach($_GET AS $chk){
	for($i=0;$i<=11;$i++){
		if(substr_count(strtoupper($chk),$badchars[$i])>0){
		$sesID = $_SESSION['sid'];
		$name = getnick_sid($sesID);
	$indiatime = time() + addhours();
    $sql="INSERT INTO ibwff_mlog SET action='Hack Attempts', details='<b>$name</b> tried some SQLi!', actdt=".time()."'";
	$result=mysql_query($sql);
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\"/>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
		}
	}
}
}
///////////////////// Can't Change To Bad Browser! By CJ UdaY :)
function badbrowser()
{
$user_agent = $_SERVER['HTTP_USER_AGENT']; 
if(preg_match('/(google|bot|plusses|email|signature|posts|sex|birthday|pass|pass|name|co518|php|prince|mowser|rp|mastercredit|hack|perm|fuck|pfmsgs|goldencoin|by|cyberpowereragon|phone|country|location|ipadd|info|osmafia|validated|mafia|team|chudi|choda|motherchod|mothercod|samy|rokon|kutta|friendsdiary|rockerwap|chatbookbd|peacefulbd|proudbd|mycitywap|pornbd|cyberlife|icforum|cyberwap24|groupnetbd|onibbd|tufanbd|slannger|spam|bd|com|net|tk|wap|mobi|wapka)/i',strtolower($user_agent))){
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\"/>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php"); 
 echo "</div>";
  echo "</body>";
  echo "</html>";
    exit();
}
}

function connectdb()
{
global $dbname, $dbuser, $dbhost, $dbpass;
$conms = @mysql_connect($dbhost,$dbuser,$dbpass); 
if(!$conms) return false;
$condb = @mysql_select_db($dbname);
if(!$condb) return false;
return true;
}

function getnick_sid($sid)
{
$uid = mysql_fetch_array(mysql_query("SELECT uid FROM ibwff_ses WHERE id='".$sid."'"));
$uid = $uid[0];
return getnick_uid($uid);
}
///////////////////////////////////////////is pmban?
function ispmban($uid)
{
$not = mysql_fetch_array(mysql_query("SELECT pmban FROM ibwff_users WHERE id='".$uid."'"));
if($not[0]=='1')
{
return true;
}else{
return false;
}
}
///////////////////////////////////////////is postban?
function ispostban($uid)
{
$not = mysql_fetch_array(mysql_query("SELECT postban FROM ibwff_users WHERE id='".$uid."'"));
if($not[0]=='1')
{
return true;
}else{
return false;
}
}
///////////////////////////////////////////is chatban?
function ischatban($uid)
{
$not = mysql_fetch_array(mysql_query("SELECT chatban FROM ibwff_users WHERE id='".$uid."'"));
if($not[0]=='1')
{
return true;
}else{
return false;
}
}
///////////////////////////////////////////is forumban?
function isforumban($uid)
{
$not = mysql_fetch_array(mysql_query("SELECT forumban FROM ibwff_users WHERE id='".$uid."'"));
if($not[0]=='1')
{
return true;
}else{
return false;
}
}
///////////////////////////////////////////is shoutban?
function isshoutban($uid)
{
$not = mysql_fetch_array(mysql_query("SELECT shoutban FROM ibwff_users WHERE id='".$uid."'"));
if($not[0]=='1')
{
return true;
}else{
return false;
}
}
///////////////////////////////////////////is literatureban?
function isliteratureban($uid)
{
$not = mysql_fetch_array(mysql_query("SELECT letban FROM ibwff_users WHERE id='".$uid."'"));
if($not[0]=='1')
{
return true;
}else{
return false;
}
}
///////////////////////////////////////////is blogban?
function isblogsban($uid)
{
$not = mysql_fetch_array(mysql_query("SELECT blogban FROM ibwff_users WHERE id='".$uid."'"));
if($not[0]=='1')
{
return true;
}else{
return false;
}
}
///////////////////////////////////////////is blogcomban?
function isblogscomban($uid)
{
$not = mysql_fetch_array(mysql_query("SELECT blogcomban FROM ibwff_users WHERE id='".$uid."'"));
if($not[0]=='1')
{
return true;
}else{
return false;
}
}
///////////////////////////////////////////is pollban?
function ispollsban($uid)
{
$not = mysql_fetch_array(mysql_query("SELECT pollban FROM ibwff_users WHERE id='".$uid."'"));
if($not[0]=='1')
{
return true;
}else{
return false;
}
}
////////////////////////////////////////////can delete a dairy?
function candeldr($uid,$bid)
{
$minfo = mysql_fetch_array(mysql_query("SELECT bowner FROM ibwff_dairy WHERE id='".$bid."'"));
if(ismod($uid))
{
return true;
}
if($minfo[0]==$uid)
{
return true;
}
return false;
}
function bosshira_themes()
{
$thm = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='themes'"));
return $thm[0];
}
function getuid_sid($sid)
{
$uid = mysql_fetch_array(mysql_query("SELECT uid FROM ibwff_ses WHERE id='".$sid."'"));
$uid = $uid[0];
return $uid;
}
function getsname($fid)
{
  $stname = mysql_fetch_array(mysql_query("SELECT name FROM ibwff_literature WHERE id='".$fid."'"));
  return $stname[0];
}
function getstarsign($date){
list($year,$month,$day)=explode("-",$date);
if(($month=='1' && $day>='20')||($month=='2' && $day<='18')){
return "<img src=\"../ZODIAC/aquarius.gif\" alt=\"*\"/> Aquarius - Water Bearer";
}else if(($month=='02' && $day>='19')||($month=='03' && $day<='20')){
return "<img src=\"../ZODIAC/pisces.gif\" alt=\"*\"/> Pisces - Fish";
}else if(($month=='03' && $day>='21')||($month=='04' && $day<='19')){
return "<img src=\"../ZODIAC/aries.gif\" alt=\"*\"/> Aries - Ram";
}else if(($month=='04' && $day>='20')||($month=='05' && $day<='20')){
return "<img src=\"../ZODIAC/taurus.gif\" alt=\"*\"/> Taurus - Bull";
}else if(($month=='05' && $day>='21')||($month=='06' && $day<='20')){
return "<img src=\"../ZODIAC/gemini.gif\" alt=\"*\"/> Gemini - Twins";
}else if(($month=='6' && $day>='21')||($month=='07' && $day<='22')){
return "<img src=\"../ZODIAC/cancer.gif\" alt=\"*\"/> Cancer - Crab";
}else if(($month=='07' && $day>='23')||($month=='08' && $day<='22')){
return "<img src=\"../ZODIAC/leo.gif\" alt=\"*\"/> Leo - Lion";
}else if(($month=='08' && $day>='23')||($month=='09' && $day<='22')){
return "<img src=\"../ZODIAC/virgo.gif\" alt=\"*\"/> Virgo - Virgin";
}else if(($month=='09' && $day>='23')||($month=='10' && $day<='22')){
return "<img src=\"../ZODIAC/libra.gif\" alt=\"*\"/> Libra - Balance";
}else if(($month=='10' && $day>='23')||($month=='11' && $day<='21')){
return "<img src=\"../ZODIAC/scorpio.gif\" alt=\"*\"/> Scorpio - Scorpion";
}else if(($month=='11' && $day>='22')||($month=='12' && $day<='21')){
return "<img src=\"../ZODIAC/sagittarius.gif\" alt=\"*\"/> Sagittarius - Archer";
}else if(($month=='12' && $day>='22')||($month=='01' && $day<='19')){
return "<img src=\"../ZODIAC/capricorn.gif\" alt=\"*\"/> Capricorn - Goat";
}else{
return "Update Your D.O.B!";
}
}
/////////////////OS By CJ UDAY :)
function OS($user_agent){
$exp = explode(" ", $user_agent);
$oses = array (
'Windows 3.11' => 'Win16',
'Windows 95' => '(Windows 95)|(Win95)|(Windows_95)',
'Windows 98' => '(Windows 98)|(Win98)',
'Windows 2000' => '(Windows NT 5.0)|(Windows 2000)',
'Windows XP' => '(Windows NT 5.1)|(Windows XP)',
'Windows Vista' => '(Windows NT 6.0)|(Windows Vista)',
'Windows 7' => '(Windows NT 6.1)|(Windows 7)',
'Windows 8' => '(Windows NT 8.0)|(Windows 8)',
'Windows 2003' => '(Windows NT 5.2)',
'Windows NT 4.0' => '(Windows NT 4.0)|(WinNT4.0)|(WinNT)|(Windows NT)',
'Windows ME' => 'Windows ME',
'Open BSD'=>'OpenBSD',
'Sun OS'=>'SunOS',
'Linux'=>'(Linux)|(X11)',
'Macintosh'=>'(Mac_PowerPC)|(Macintosh)',
'QNX'=>'QNX',
'BeOS'=>'BeOS',
'OS/2'=>'OS/2',
'Palm OS'=>'Palm OS',
'Search Bot'=>'(nuhk)|(Googlebot)|(Yammybot)|(Openbot)|(Slurp/cat)|(msnbot)|(ia_archiver)',
'J2ME-Opera Mini'=>'Opera Mini',
'Java'=>'Java',
'SonyE'=>'J2ME-MIDP',
'Symbian'=>'Symbian OS',
'SymbianOS 6.1'=>'SymbianOS/6.1',
'SymbianOS 7.0'=>'SymbianOS/7.0',
'SymbianOS 8.0'=>'SymbianOS/8.0',
'SymbianOS 9.1'=>'SymbianOS/9.1',
'SymbianOS 9.2'=>'SymbianOS/9.2',
'SymbianOS 9.4'=>'SymbianOS/9.4',
'Mac OS (iPhone)'=>'iPhone',
'Windows CE' => 'Windows CE'
);
foreach($oses as $os=>$pattern){
if (eregi($pattern,$user_agent))
return $os;
}
return 'Unknown OS!';
}
/////////////////////////////////////////get ranking by CJ UDAY :-)
function getranking($who)
{
  $info= mysql_fetch_array(mysql_query("SELECT cyberpowereragon, plusses, vip, pu FROM ibwff_users WHERE id='".$who."'"));
 if($info[0]=='4' || spu($uid) || ispu($uid))
  {
    return "<img src=\"../avatars/5-star.gif\" alt=\"*****\"/>";
  }else
   if($info[0]>'0')
  {
    return "<img src=\"../avatars/5-star.gif\" alt=\"*****\"/>";
  }else
   if($info[2]=='1')
  {
    return "<img src=\"../avatars/5-star.gif\" alt=\"*****\"/>";
  }else
   if($info[3]=='1')
  {
    return "<img src=\"../avatars/5-star.gif\" alt=\"*****\"/>";
  }else{
if($info[1]<200)
    {
     return "<img src=\"../avatars/half-star.gif\" alt=\"*\"/>";
    }else if($info[1]>700)
    {
        return "<img src=\"../avatars/1-star.gif\" alt=\"*\"/>";
    }else if($info[1]>1500)
    {
        return "<img src=\"../avatars/1half-star.gif\" alt=\"**\"/>";
    }else if($info[1]>2200)
    {
        return "<img src=\"../avatars/2-star.gif\" alt=\"**\"/>";
    }else if($info[1]>2800)
    {
        return "<img src=\"../avatars/2half-star.gif\" alt=\"***\"/>";
    }else if($info[1]>3500)
    {
        return "<img src=\"../avatars/3-star.gif\" alt=\"***\"/>";
    }else if($info[1]>4200)
    {
        return "<img src=\"../avatars/3half-star.gif\" alt=\"****\"/>";
    }else if($info[1]>5300)
    {
        return "<img src=\"../avatars/4-star.gif\" alt=\"****\"/>";
    }else if($info[1]>7900)
    {
        return "<img src=\"../avatars/4half-star.gif\" alt=\"****\"/>";
    }else if($info[1]>9990)
    {
        return "<img src=\"../avatars/5-star.gif\" alt=\"*****\"/>";
    }else{
        return "<img src=\"../avatars/5-star.gif\" alt=\"*****\"/>";
    }
  }
}
/////////////////////////////////////////get ranking by CJ UDAY :-)
function getclubranking($clid)
{
  $info= mysql_fetch_array(mysql_query("SELECT id, plusses FROM ibwff_clubs WHERE id='".$clubid."'"));
 if($info[1]<2500)
    {
        return "<img src=\"../avatars/1-star.gif\" alt=\"*\"/>";
    }else if($info[1]<3500)
    {
        return "<img src=\"../avatars/1half-star.gif\" alt=\"**\"/>";
    }else if($info[1]<4500)
    {
        return "<img src=\"../avatars/2-star.gif\" alt=\"**\"/>";
    }else if($info[1]<5500)
    {
        return "<img src=\"../avatars/2half-star.gif\" alt=\"***\"/>";
    }else if($info[1]<6500)
    {
        return "<img src=\"../avatars/3-star.gif\" alt=\"***\"/>";
    }else if($info[1]<8000)
    {
        return "<img src=\"../avatars/3half-star.gif\" alt=\"****\"/>";
    }else if($info[1]<9000)
    {
        return "<img src=\"../avatars/4-star.gif\" alt=\"****\"/>";
    }else if($info[1]<10000)
    {
        return "<img src=\"../avatars/4half-star.gif\" alt=\"****\"/>";
    }else if($info[1]<11000)
    {
        return "<img src=\"../avatars/5-star.gif\" alt=\"*****\"/>";
    }else if($info[1]<15000)
    {
        return "<img src=\"../avatars/5-star.gif\" alt=\"*****\"/>";
    }else if($info[1]<20000)
    {
        return "<img src=\"../avatars/5-star.gif\" alt=\"*****\"/>";
    }else
    {
        return "<img src=\"../avatars/5-star.gif\" alt=\"*****\"/>";
    }
  }
   function getclubrank($clid)
 {
 $ttl = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_clubmembers WHERE clid='".$clid."' "));
 $ttl = mysql_fetch_array(mysql_query("SELECT id FROM ibwff_clubs WHERE id='".$clid."'"));
 $most = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_clubs"));
$rate = "$ttl[0] out of $most[0]";
 return $rate;
 }
///////////////////////////////////////Title Name By CJ UDAY :)
function gettitle($uid)
{
  $info= mysql_fetch_array(mysql_query("SELECT id , plusses, vip, pu ,cyberpowereragon, sex FROM ibwff_users WHERE id='".$uid."'"));
$infototal = $info[1];

if($infototal<1400)
{
return "";
}else
if($infototal<1500)
{
return "[MyDhaka Knight!]";
}
else if($infototal<3000)
{
return "[MyDhaka Expeller!]";
}else if($infototal<6000)
{
return "[MyDhaka Expart!]";
}else if($infototal<12000)
{
return "[MyDhaka Master!]";
}else if($infototal<18000)
{
return "[MyDhaka Legend!]";
/* }
else if($infototal==0)
{
return "";
}else if($infototal==0)
{
return ""; */
}else if($infototal<22000)
{
////////////////////////By MAfiA_SAMY
$sql = "SELECT name FROM ibwff_users WHERE id=$uid";
$sql2 = mysql_query($sql);
$item = mysql_fetch_array($sql2);
{
/////////////////////By MAfiA_SAMY
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users
WHERE name='$item[0]'"));
if($sex[0]=="M"){$nick = "Prince!";}
if($sex[0]=="F"){$nick = "Princess!";}
if($sex[0]==""){$nick = "";}
return "[MyDhaka $nick]";
}
/*
}else if($infototal<22000)
{
////////////////////////By MAfiA_SAMY
$sql = "SELECT name FROM WHERE id=$uid";
$sql2 = mysql_query($sql);
$item = mysql_fetch_array($sql2);
{
/////////////////////By MAfiA_SAMY
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM
WHERE name='$item[0]'"));
if($sex[0]=="M"){$nick = "Prince!";}
if($sex[0]=="F"){$nick = "Princess!";}
}
}
}else if($infototal<25000)
{
////////////////////////By MAfiA_SAMY
$sql = "SELECT name FROM ibwff_users WHERE id=$uid";
$sql2 = mysql_query($sql);
$item = mysql_fetch_array($sql2);
{
/////////////////////By MAfiA_SAMY
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users
WHERE name='$item[0]'"));
if($sex[0]=="M"){$nick = "MyDhaka King!";}
if($sex[0]=="F"){$nick = "MyDhaka Queen!";}
if($sex[0]==""){$nick = "";}
return "[$nick]";
}
/*
}else if($infototal<25000)
{
////////////////////////By MAfiA_SAMY
$sql = "SELECT name FROM WHERE id=$uid";
$sql2 = mysql_query($sql);
$item = mysql_fetch_array($sql2);
{
/////////////////////By MAfiA_SAMY
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM
WHERE name='$item[0]'"));
if($sex[0]=="M"){$nick = "King!";}
if($sex[0]=="F"){$nick = "Queen!";}
if($sex[0]==""){$nick = "";}
return "[$nick]";
}
*/
}else if($infototal>50000)
{
////////////////////////By MAfiA_SAMY
$sql = "SELECT name FROM ibwff_users WHERE id=$uid";
$sql2 = mysql_query($sql);
$item = mysql_fetch_array($sql2);
{
/////////////////////By MAfiA_SAMY
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users
WHERE name='$item[0]'"));
if($sex[0]=="M"){$nick = "King Of The King!";}
if($sex[0]=="F"){$nick = "Queen Of The Queen!";}
if($sex[0]==""){$nick = "";}
return "[$nick]";
}
}
else
{
////////////////////////By MAfiA_SAMY
$sql = "SELECT name FROM ibwff_users WHERE id=$uid";
$sql2 = mysql_query($sql);
$item = mysql_fetch_array($sql2);
{
/////////////////////By MAfiA_SAMY
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users
WHERE name='$item[0]'"));
if($sex[0]=="M"){$nick = "King Of The King!";}
if($sex[0]=="F"){$nick = "Queen Of The Queen!";}
if($sex[0]==""){$nick = "";}
return "[$nick]";
}
}
}
  
/////////////////////////Weekly Profile Rating By CJ UDAY :)
function getwpfrting($uid)
{
$fa = time()-7*24*60*60;
$infototal = mysql_fetch_array(mysql_query("SELECT SUM(rates) FROM uday_usrate WHERE tid='".$uid."' AND time>'$fa'"));
$infototal = $infototal[0];
if($infototal<2)
{
return "<img src=\"../avatars/half-star.gif\" alt=\"*\"/>";
}
else if($infototal<5)
{
return "<img src=\"../avatars/1-star.gif\" alt=\"*\"/>";
}
else if($infototal<9)
{
return "<img src=\"../avatars/1half-star.gif\" alt=\"*\"/>";
}
else if($infototal<13)
{
return "<img src=\"../avatars/2-star.gif\" alt=\"**\"/>";
}
else if($infototal<19)
{
return "<img src=\"../avatars/2half-star.gif\" alt=\"**\"/>";
}
else if($infototal<23)
{
return "<img src=\"../avatars/3-star.gif\" alt=\"**\"/>";
}
else if($infototal<29)
{
return "<img src=\"../avatars/3half-star.gif\" alt=\"***\"/>";
}
else if($infototal<33)
{
return "<img src=\"../avatars/4-star.gif\" alt=\"***\"/>";
}
else if($infototal<39)
{
return "<img src=\"../avatars/4half-star.gif\" alt=\"****\"/>";
}
else if($infototal<45)
{
return "<img src=\"../avatars/5-star.gif\" alt=\"****\"/>";
}
else if($infototal<50)
{
return "<img src=\"../avatars/5-star.gif\" alt=\"*****\"/>";
}
else if($infototal<55)
{
return "<img src=\"../avatars/5-star.gif\" alt=\"*****\"/>";
}else{
return "<img src=\"../avatars/5-star.gif\" alt=\"****\"/>";
}
}
//////////////////////////////////////////// Search Id by CJ UDAY :-)
function generate_srid($svar1,$svar2="", $svar3="", $svar4="", $svar5="")
{
$res = mysql_fetch_array(mysql_query("SELECT id FROM ibwff_search WHERE svar1 like '".$svar1."' AND svar2 like '".$svar2."' AND svar3 like '".$svar3."' AND svar4 like '".$svar4."' AND svar5 like '".$svar5."'"));
if($res[0]>0)
{
return $res[0];
}
mysql_query("INSERT INTO ibwff_search SET svar1='".$svar1."', svar2='".$svar2."', svar3='".$svar3."', svar4='".$svar4."', svar5='".$svar5."', stime='".time()."'");
$res = mysql_fetch_array(mysql_query("SELECT id FROM ibwff_search WHERE svar1 like '".$svar1."' AND svar2 like '".$svar2."' AND svar3 like '".$svar3."' AND svar4 like '".$svar4."' AND svar5 like '".$svar5."'"));
return $res[0];
}
function isuser($uid)
{
$cus = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE id='".$uid."'"));
if($cus[0]>0)
{
return true;
}
return false;
}
function canaccess($uid, $fid)
{
$fex = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_forums WHERE id='".$fid."'"));
if($fex[0]==0)
{
return false;
}
$persc = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_acc WHERE fid='".$fid."'"));
if($persc[0]==0)
{
$clid = mysql_fetch_array(mysql_query("SELECT clubid FROM ibwff_forums WHERE id='".$fid."'"));
if($clid[0]==0 || ispu($uid) || spu($uid))
{
return true;
}else{
if(ismod($uid))
{
return true;
}else{
$ismm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_clubmembers WHERE uid='".$uid."' AND clid='".$clid[0]."'"));
if($ismm[0]>0)
{
return true;
}else{
return false;
}
}
}
}else{
$gid = mysql_fetch_array(mysql_query("SELECT gid FROM ibwff_acc WHERE fid='".$fid."'"));
$gid = $gid[0];
$ginfo = mysql_fetch_array(mysql_query("SELECT autoass, mage, userst, posts, plusses, maxage FROM ibwff_groups WHERE id='".$gid."'"));
if($ginfo[0]=="1")
{
$ucyberpowereragons = mysql_fetch_array(mysql_query("SELECT birthday, cyberpowereragon, posts, plusses FROM ibwff_users WHERE id='".$uid."'"));
if($ginfo[2]==4)
{
if(isowner($uid))
{
return true;
}else{
return false;
}
}
if($ginfo[2]==3)
{
if(isheadadmin($uid))
{
return true;
}else{
return false;
}
}
if($ginfo[2]==2)
{
if(isadmin($uid))
{
return true;
}else{
return false;
}
}
if($ginfo[2]==1)
{
if(ismod($uid))
{
return true;
}else{
return false;
}
}
if($ucyberpowereragons[1]>$ginfo[2])
{
return true;
}
$acc = true;
if($ginfo[1]!=0){
if(getage($ucyberpowereragons[0])< $ginfo[1])
{
$acc =  false;
}
}
if($ginfo[5]!=0){
if(getage($ucyberpowereragons[0])> $ginfo[5])
{
$acc =  false;
}
}
if($ucyberpowereragons[2]<$ginfo[3])
{
$acc =  false;
}
if($ucyberpowereragons[3]<$ginfo[4])
{
$acc =  false;
}
}
}
return $acc;
}
function getuage_sid($sid)
{
$uid = getuid_sid($sid);
$uage = mysql_fetch_array(mysql_query("SELECT birthday FROM ibwff_users WHERE id='".$uid."'"));
return getage($uage[0]);
}
function canenter($rid, $sid)
{
$rcyberpowereragon = mysql_fetch_array(mysql_query("SELECT mage, cyberpowereragons, chposts, clubid, maxage FROM ibwff_rooms WHERE id='".$rid."'"));
$ucyberpowereragon = mysql_fetch_array(mysql_query("SELECT birthday, chatposts FROM ibwff_users WHERE id='".getuid_sid($sid)."'"));
if(ismod(getuid_sid($sid)))
{
return true;
}
if($rcyberpowereragon[3]!=0)
{
if(ismod(getuid_sid($sid)))
{
return true;
}else{
$ismm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_clubmembers WHERE uid='".getuid_sid($sid)."' AND clid='".$rcyberpowereragon[3]."'"));
if($ismm[0]>0)
{
return true;
}else{
return false;
}
}
}
if($rcyberpowereragon[1]==1)
{
return ismod(getuid_sid($sid));
}
if($rcyberpowereragon[1]==2)
{
return isadmin(getuid_sid($sid));
}
if($rcyberpowereragon[1]==3)
{
return isheadadmin(getuid_sid($sid));
}
if($rcyberpowereragon[1]==4)
{
return isowner(getuid_sid($sid));
}
if($rcyberpowereragon[0]!=0){
if(getuage_sid($sid)<$rcyberpowereragon[0])
{
return false;
}
}
if($rcyberpowereragon[4]!=0){
if(getuage_sid($sid)>$rcyberpowereragon[4])
{
return false;
}
}
if($ucyberpowereragon[1]<$rcyberpowereragon[2])
{
return false;
}
return true;
}
function cleardata()
{
$timeto = 120;
$timenw = time();
$timeout = $timenw - $timeto;
$exec = mysql_query("DELETE FROM ibwff_chonline WHERE lton<'".$timeout."'");
$timeto = 120;
$timenw = time();
$timeout = $timenw - $timeto;
$exec = mysql_query("DELETE FROM ibwff_tpconline WHERE lton<'".$timeout."'");
$timeto = 300;
$timenw = time();
$timeout = $timenw - $timeto;
$exec = mysql_query("DELETE FROM ibwff_chat WHERE timesent<'".$timeout."'");
$timeto = 60*60;
$timenw = time();
$timeout = $timenw - $timeto;
$exec = mysql_query("DELETE FROM ibwff_search WHERE stime<'".$timeout."'");
$timeto = 5*60;
$timenw = time();
$timeout = $timenw - $timeto;
$rooms = mysql_query("SELECT id FROM ibwff_rooms WHERE static='0' AND lastmsg<'".$timeout."'");
while ($room=mysql_fetch_array($rooms))
{
$ppl = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_chonline WHERE rid='".$room[0]."'"));
if($ppl[0]==0)
{
$exec = mysql_query("DELETE FROM ibwff_rooms WHERE id='".$room[0]."'");
}
}
}
///////////////////////////////////////Add to chat by CJ UDAY :-)
function addtochat($uid, $rid)
{
$timeto = 80;
$timenw = time();
$timeout = $timenw - $timeto;
$res = mysql_query("INSERT INTO ibwff_chonline SET lton='".time()."', uid='".$uid."', rid='".$rid."'");
if(!$res)
{
mysql_query("UPDATE ibwff_chonline SET lton='".time()."', rid='".$rid."' WHERE uid='".$uid."'");
}
}
/////////////////////////////////Deactivated Account Created By CJ UDAY :)
function isdeactivated($uid)
{
$Deactivated = mysql_fetch_array(mysql_query("SELECT diactivate FROM ibwff_users WHERE id='".$uid."'"));
if($Deactivated[0]=='1')
{
return true;
}
}
function ismod($uid)
{
$cyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE id='".$uid."'"));
if($cyberpowereragon[0]>0)
{
return true;
}
}
function isvalidated($uid)
{
$validated = mysql_fetch_array(mysql_query("SELECT validated FROM ibwff_users WHERE id='".$uid."'"));
if($validated[0]=='0')
{
return true;
}
}
function isvip($uid)
{
$vip = mysql_fetch_array(mysql_query("SELECT vip FROM ibwff_users WHERE id='".$uid."'"));
if($vip[0]=='1')
{
return true;
}
}
function ispu($uid)
{
$vip2 = mysql_fetch_array(mysql_query("SELECT pu FROM ibwff_users WHERE id='".$uid."'"));
if($vip2[0]>0)
{
return true;
}
}
function spu($uid)
{
$vip2 = mysql_fetch_array(mysql_query("SELECT pu FROM ibwff_users WHERE id='".$uid."'"));
if($vip2[0]=="2")
{
return true;
}
}
function islotto($uid)
{
$vip2 = mysql_fetch_array(mysql_query("SELECT lotto FROM ibwff_users WHERE id='".$uid."'"));
if($vip2[0]=='1')
{
return true;
}
}
////////////////////////////////////////////is mod? By CJ UDAY :-)
function candelgb($uid,$mid)
{
$minfo = mysql_fetch_array(mysql_query("SELECT gbowner, gbsigner FROM ibwff_gbook WHERE id='".$mid."'"));
if($minfo[0]==$uid)
{
return true;
}
if($minfo[1]==$uid)
{
return true;
}
return false;
}
////////////////////////////////////////////Spam filter By CJ UDAY :)
function isspam($text)
{
$sfil[0] = "www.";
$sfil[1] = "http:";
$sfil[2] = ".com";
$sfil[3] = ".net";
$sfil[4] = ".tk";
$sfil[5] = ".wapka";
$sfil[6] = ".mobi";
$sfil[7] = "wap";
$sfil[8] = "bd";
$text = str_replace(" ", "", $text);
$text = strtolower($text);
for($i=0;$i<count($sfil);$i++)
{
$nosf = substr_count($text,$sfil[$i]);
if($nosf>0)
{
return true;
}
}
return false;
}
///////////////////////////////////get page from go by CJ UDAY :-)
function getpage_go($go,$tid)
{
if(trim($go)=="")return 1;
if($go=="last")return getnumpages($tid);
$counter=1;
$posts = mysql_query("SELECT id FROM ibwff_posts WHERE tid='".$tid."'");
while($post=mysql_fetch_array($posts))
{
$counter++;
$postid = $post[0];
if($postid==$go)
{
$tore = ceil($counter/5);
return $tore;
}
}
return 1;
}
////////////////////////////get number of topic pages by CJ UDAY :-)
function getnumpages($tid)
{
$nops = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_posts WHERE tid='".$tid."'"));
$nops = $nops[0]+1; 
$nopg = ceil($nops/5);
return $nopg;
}
function candelbl($uid,$bid)
{
$minfo = mysql_fetch_array(mysql_query("SELECT bowner FROM ibwff_blogs WHERE id='".$bid."'"));
if(ismod($uid))
{
return true;
}
if($minfo[0]==$uid)
{
return true;
}
return false;
}
function candelcl($uid,$clid)
{
$minfo = mysql_fetch_array(mysql_query("SELECT owner FROM ibwff_clubs WHERE id='".$clid."'"));
if(ismod($uid))
{
return true;
}
if($minfo[0]==$uid)
{
return true;
}
return false;
}
function candelst($uid,$statusid)
{
$minfo = mysql_fetch_array(mysql_query("SELECT uid FROM ibwff_status WHERE id='".$statusid."'"));
if(ismod($uid))
{
return true;
}
if($minfo[0]==$uid)
{
return true;
}
return false;
}
function candelpl($uid,$who)
{
$minfo = mysql_fetch_array(mysql_query("SELECT uid FROM ibwff_polls WHERE id='".$who."'"));
if(ismod($uid))
{
return true;
}
if($minfo[0]==$uid)
{
return true;
}
return false;
}
function PostToHost($host, $path, $data_to_send)
{
$fp = fsockopen($host,80,$errno, $errstr, 30);
if($fp)
{
fputs($fp, "POST $path HTTP/1.0\n");
fputs($fp, "Host: $host\n");
fputs($fp, "Content-type: application/x-www-form-urlencoded\n");
fputs($fp, "Content-length: " . strlen($data_to_send) . "\n");
fputs($fp, "Connection: close\n\n");
fputs($fp, $data_to_send);
while(!feof($fp)) {
$result .=  fgets($fp, 128);
}
fclose($fp);
return $result;
}
}
/////////////////////////Get User Points by CJ UDAY :-)
function getplusses($uid)
{
$plus = mysql_fetch_array(mysql_query("SELECT plusses FROM ibwff_users WHERE id='".$uid."'"));
return $plus[0];
}
/////////////////////////Get Gifter Points
function getgifterpoint($who)
{
$point = mysql_fetch_array(mysql_query("SELECT plusses FROM ibwff_users WHERE id='".$who."'"));
return $point[0];
}
/////////////////////////Can uid sign who's guestbook by CJ UDAY?
function cansigngb($uid, $who)
{
if(arebuds($uid, $who))
{
return true;
}
if($uid==$who)
{
return false;
}
if(getplusses($uid)>=75)
{
return true;
}
return false;
}
/////////////////////////////////////////////Are buds by CJ Uday?
function arebuds($uid, $tid)
{
$res = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_buddies WHERE ((uid='".$uid."' AND tid='".$tid."') OR (uid='".$tid."' AND tid='".$uid."')) AND agreed='1'"));
if($res[0]>0)
{
return true;
}
return false;
}
////////////////get real browser by CJ Uday :-)
function browser_agent($_mob_browser){$_mob_browser=eragonsqlsecurityclean($_mob_browser);
  if(preg_match('/(google|bot)/i',strtolower($_mob_browser))){
 $position = strpos(strtolower($_mob_browser),"bot");
 $_mob_browser = substr($_mob_browser, $position-30, $position+2);
 $_browser = explode (" ", $_mob_browser);
 $_browser = array_reverse($_browser); 
 }else if (isset($_SERVER['HTTP_X_OPERAMINI_PHONE_UA'])) {
 $_mob_browser = $_SERVER['HTTP_X_OPERAMINI_PHONE_UA'];
 $_position=strpos(strtolower($_mob_browser),"nokia");$position=strpos(strtolower($_mob_browser),"android");
 if($_position){$_mob_browser = substr($_mob_browser, $_position,25);}
 else{if($position){$_mob_browser = substr($_mob_browser, $position,25);$_browser = explode ('-', $_mob_browser);return eragonsqlsecurityclean($_browser[0]);}}
 $_browser = explode (' ', $_mob_browser);
 }else if (isset($_SERVER['HTTP_X_BOLT_PHONE_UA'])) {
 $_mob_browser = $_SERVER['HTTP_X_BOLT_PHONE_UA'];
 $_position=strpos(strtolower($_mob_browser),"nokia");$position=strpos(strtolower($_mob_browser),"android");
 if($_position){$_mob_browser = substr($_mob_browser, $_position,25);}
 else{if($position)$_mob_browser = substr($_mob_browser, $position,25);$_browser = explode ('-', $_mob_browser);return eragonsqlsecurityclean($_browser[0]);}
 $_browser = explode (' ', $_mob_browser); }else if (isset($_SERVER['HTTP_X_MOBILE_UA'])) {
 $_mob_browser = $_SERVER['HTTP_X_MOBILE_UA'];
 $_position=strpos(strtolower($_mob_browser),"nokia");$position=strpos(strtolower($_mob_browser),"android");
 if($_position){$_mob_browser = substr($_mob_browser, $_position,25);}
 else{if($position){$_mob_browser = substr($_mob_browser, $position,25);$_browser = explode ('-', $_mob_browser);return eragonsqlsecurityclean($_browser[0]);}}
 $_browser = explode (' ', $_mob_browser); }else if(isset($_SERVER['HTTP_X_devICE_USER_AGENT'])) {
 $_mob_browser = $_SERVER['HTTP_X_devICE_USER_AGENT'];
 $_position=strpos(strtolower($_mob_browser),"nokia");$position=strpos(strtolower($_mob_browser),"android");
 if($_position){$_mob_browser = substr($_mob_browser, $_position,25);}
 else{if($position){$_mob_browser = substr($_mob_browser, $position,25);$_browser = explode ('-', $_mob_browser);return eragonsqlsecurityclean($_browser[0]);}}
 $_browser = explode (' ', $_mob_browser);}else{$_position=strpos(strtolower($_mob_browser),"nokia");$position=strpos(strtolower($_mob_browser),"android");
 if($_position){$_mob_browser = substr($_mob_browser, $_position,25);}
 else{if($position){$_mob_browser = substr($_mob_browser, $position,25);$_browser = explode ('-', $_mob_browser);return eragonsqlsecurityclean($_browser[0]);}}
 $_browser = explode (' ', $_mob_browser);
 }
   return "Opera 9.80";         
}
//////////////////////////////////function get n. of buds by CJ UDAY :-)
function getnbuds($uid)
{
$notb = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_buddies WHERE (uid='".$uid."' OR tid='".$uid."') AND agreed='1'"));
return $notb[0];
}
function getnbuds2($who)
{
$notb = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_buddies WHERE (uid='".$who."' OR tid='".$who."') AND agreed='1'"));
return $notb[0];
}
/////////////////////////////get no. of requests by CJ UDAY :-)
function getnreqs($uid)
{
$notb = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_buddies WHERE  tid='".$uid."' AND agreed='0'"));
return $notb[0];
}
/////////////////////////////get no. of online buds by CJ UDAY :-)
function getonbuds($uid)
{
$counter+=0;
$buds = mysql_query("SELECT uid, tid FROM ibwf_buddies WHERE (uid='".$uid."' OR tid='".$uid."') AND agreed='1'");
while($bud=mysql_fetch_array($buds))
{
if($bud[0]==$uid)
{
$tid = $bud[1];
}else{
$tid = $bud[0];
}
if(isonline($tid))
{
$counter++;
}
}
return $counter;
}
/////////////////////////////////////////////function Shoutbox 1msg By CJ UdaY :)
$tm = time();
function getshoutbox($sid)
{
$lshout = mysql_fetch_array(mysql_query("SELECT shout, shouter, id, shtime, act_uday  FROM ibwff_shouts WHERE clubid=0 ORDER BY shtime DESC LIMIT 1"));

$shdt = date("H:i", $lshout[3]);
$stime = $lshout['shtime'];
$tremain = time()-$stime;
$tmdt = gettimemsg($tremain);
$ttt = date("h:i:s A",($shdt + (6 * 60 * 60)));
$tt2 = ("$tmdt ago");



if(g($lshout[1])=="F") {$clr="red";} else {$clr="";}
$shnick = subnick(getnick_uid($lshout[1]));
if($lshout[4]!="")
{
$f = "<font color=\"gray\">is $lshout[4]</font>";
}else{
$f = "";
}
$avlink = getavatar($lshout[1]);
if($avlink=="")
{
$shbox .= "[<img src=\"../avatars/nopic.jpg\" height=\"22\" width=\"18\" alt=\"x\"/> ";
}else{
$shbox .= "[<img src=\"$avlink\" height=\"20\" width=\"18\" alt=\"0\"/> ";
}
$shbox .= " <a style=\"color:{$clr}\" href=\"profile.php?who=$lshout[1]\">".$shnick."</a> $f] <br/> ";
$text = parsepm($lshout[0], $sid);
$shbox .= $text;
$shbox .= "<br/><br/>";
$shcomm = mysql_fetch_assoc(mysql_query("SELECT COUNT(*) comm FROM ibwff_shcomments WHERE shoutid='".$lshout[2]."'"));
$shout = $shcomm['comm'];
$counts = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_like WHERE shoutid='".$lshout[2]."'"));
$counts1 = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_dislike WHERE shoutid='".$lshout[2]."'"));
if($counts[0]>0){ $lyk = "(<a href=\"like.php?shid=$lshout[2]\">$counts[0]</a>)";
 }else{ 
 $lyk = "(<a href=\"like.php?shid=$lshout[2]\">0</a>)"; }
if($counts1[0]>0){ $dislyk = "(<a href=\"dislike.php?shid=$lshout[2]\">$counts1[0]</a>)";
 }else{ 
 $dislyk = "(<a href=\"dislike.php?shid=$lshout[2]\">0</a>)"; }
$shcomm = mysql_fetch_assoc(mysql_query("SELECT COUNT(*) comm FROM ibwff_shcomments WHERE shoutid='".$lshout[2]."'"));
$shout = $shcomm['comm'];
$shbox .= "<div class=\"likebox\" align=\"center\">";
  $shbox .= "<img src=\"comment.png\" alt=\"\"><a href=\"shcomments.php?shid=$lshout[2]\">Comments($shout)</a>";
$shbox .= "<hr><img src=\"like.png\" alt=\"\"><a href=\"shoutproc.php?action=like&who=$who&shid=$lshout[2]\">Agree</a>$lyk";
$shbox .= "<hr><img src=\"dislike.png\" alt=\"\"><a href=\"shoutproc.php?action=dislike&who=$who&shid=$lshout[2]\">Disagree</a>$dislyk ";
$shbox .= "</div>";
$shbox .= "<center>$tt2</center><hr/>";
$a = udaypu(getuid_sid($sid));
if (shoutboss(getuid_sid($sid)) || ismod(getuid_sid($sid)) || $a==$lshout[1])
{
$shbox .= "[<a href=\"edit.php?action=shout&shid=$lshout[2]\">Edit</a>]";
}
if (shoutboss(getuid_sid($sid)) || ismod(getuid_sid($sid)))
{
$shbox .= "[<a href=\"delete.php?action=shout&shid=$lshout[2]\">Delete Shout</a>]";
}
return $shbox;
}
function getshoutboxclub($clid, $sid)
{
if(g($lshout[1])=="F") {$clr="red";} else {$clr="";}
$clid=(int) $clid;
$lshout = mysql_fetch_array(mysql_query("SELECT shout, shouter, id, shtime, act_uday  FROM ibwff_shouts WHERE clubid={$clid} ORDER BY shtime DESC LIMIT 1"));
$shnick = subnick(getnick_uid($lshout[1]));
if($lshout[4]!="")
{
$f = "<font color=\"gray\">is $lshout[4]</font>";
}else{
$f = "";
}
$avlink = getavatar($lshout[1]);
if($avlink=="")
{
$shbox .= "[<img src=\"../avatars/nopic.jpg\" height=\"20\" width=\"18\" alt=\"x\"/> ";
}else{
$shbox .= "[<img src=\"$avlink\" height=\"20\" width=\"18\" alt=\"0\"/> ";
}
$shbox .= " <a style=\"{$clr}\" href=\"profile.php?who=$lshout[1]\"><font color=\"\">".$shnick."</font></a> $f] <br/> ";
$text = parsepm($lshout[0], $sid);
$shbox .= $text;
$shbox .= "<br/><br/>";
$shcomm = mysql_fetch_assoc(mysql_query("SELECT COUNT(*) comm FROM ibwff_shcomments WHERE shoutid='".$lshout[2]."'"));
$shout = $shcomm['comm'];
$counts = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_like WHERE shoutid='".$lshout[2]."'"));
$counts1 = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_dislike WHERE shoutid='".$lshout[2]."'"));
if($counts[0]>0){ $lyk = "(<a style=\"color:#336699\" href=\"like.php?shid=$lshout[2]\"><font color=\"#336699\">$counts[0]</font></a>)";
 }else{ 
 $lyk = "(<a style=\"color:#336699\" href=\"like.php?shid=$lshout[2]\"><font color=\"#336699\">0</font></a>)"; }
if($counts1[0]>0){ $dislyk = "(<a style=\"color:#336699\" href=\"dislike.php?shid=$lshout[2]\"><font color=\"#336699\">$counts1[0]</font></a>)";
 }else{ 
 $dislyk = "(<a style=\"color:#336699\" href=\"dislike.php?shid=$lshout[2]\"><font color=\"#336699\">0</font></a>)"; }
$shcomm = mysql_fetch_assoc(mysql_query("SELECT COUNT(*) comm FROM ibwff_shcomments WHERE shoutid='".$lshout[2]."'"));
$shout = $shcomm['comm'];
$shbox .= "<div class=\"likebox\" align=\"center\">";
  $shbox .= "<img src=\"comment.png\" alt=\"\" /><a href=\"shcomments.php?shid=$lshout[2]\"><font color=\"#336699\">Comments</font>(<font color=\"#336699\">$shout</font>)</a> ";
$shbox .= "<hr><img src=\"like.png\" alt=\"\" /><a href=\"shoutproc.php?action=like&clid=$clid&who=$who&shid=$lshout[2]\"><font color=\"#336699\">Agree</font></a>$lyk ";
$shbox .= "<hr><img src=\"dislike.png\" alt=\"\" /><a href=\"shoutproc.php?action=dislike&clid=$clid&who=$who&shid=$lshout[2]\"><font color=\"#336699\">Disagree</font></a>$dislyk</div>";
if ((getuid_sid($sid))==$lshout[1])
{
$shbox .= "[<a href=\"edit.php?action=shout&shid=$lshout[2]\">Edit</a>]";
}
if (isclubmod(getuid_sid($sid),$clid)=="1" || isownerclub(getuid_sid($sid),$clid)=="1")
{
$shbox .= "[<a href=\"delete.php?action=shout&clid=$clid&shid=$lshout[2]\">Delete Shout</a>]<br/>";
}                     
return $shbox;
}
function getshoutbox3club($clid, $sid)
{
$clid=(int) $clid;
$lshout = mysql_fetch_array(mysql_query("SELECT shout, shouter, id, shtime, act_uday  FROM ibwff_shouts WHERE clubid={$clid} ORDER BY shtime DESC LIMIT 1,1"));
if(g($lshout[1])=="F") {$clr="red";} else {$clr="";}
$shnick = subnick(getnick_uid($lshout[1]));
$avlink = getavatar($lshout[1]);
if($avlink=="")
{
$shbox .= "[<img src=\"../avatars/nopic.jpg\" height=\"28\" width=\"25\" alt=\"x\"/> ";
}else{
$shbox .= "[<img src=\"../avatars/$avlink\" height=\"28\" width=\"25\" alt=\"0\"/> ";
}
if($lshout[4]!="")
{
$f = "<font color=\"gray\">is $lshout[4]</font>";
}else{
$f = "";
}
$shbox .= " <a style=\"color:{$clr}\" href=\"profile.php?who=$lshout[1]\"><font color=\"\">".$shnick."</font></a> $f] <br/> ";
$text = parsepm($lshout[0], $sid);
$shbox .= $text;
$shbox .= "<br/><br/>";
$shcomm = mysql_fetch_assoc(mysql_query("SELECT COUNT(*) comm FROM ibwff_shcomments WHERE shoutid='".$lshout[2]."'"));
$shout = $shcomm['comm'];
$counts = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_like WHERE shoutid='".$lshout[2]."'"));
$counts1 = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_dislike WHERE shoutid='".$lshout[2]."'"));
if($counts[0]>0){ $lyk = "(<a style=\"color:#336699\" href=\"like.php?shid=$lshout[2]\"><font color=\"#336699\">$counts[0]</font></a>)";
 }else{ 
 $lyk = "(<a style=\"color:#336699\" href=\"like.php?shid=$lshout[2]\"><font color=\"#336699\">0</font></a>)"; }
if($counts1[0]>0){ $dislyk = "(<a style=\"color:#336699\" href=\"dislike.php?shid=$lshout[2]\"><font color=\"#336699\">$counts1[0]</font></a>)";
 }else{ 
 $dislyk = "(<a style=\"color:#336699\" href=\"dislike.php?shid=$lshout[2]\"><font color=\"#336699\">0</font></a>)"; }
$shcomm = mysql_fetch_assoc(mysql_query("SELECT COUNT(*) comm FROM ibwff_shcomments WHERE shoutid='".$lshout[2]."'"));
$shout = $shcomm['comm'];
$shbox .= "<div class=\"likebox\" align=\"center\">";
  $shbox .= "<img src=\"comment.png\" alt=\"\" /><a href=\"shcomments.php?shid=$lshout[2]\"><font color=\"#336699\">Comments</font>(<font color=\"#336699\">$shout</font>)</a> ";
$shbox .= "<hr><img src=\"like.png\" alt=\"\" /><a href=\"shoutproc.php?action=like&who=$who&shid=$lshout[2]\"><font color=\"#336699\">Agree</font></a>$lyk ";
$shbox .= "<hr><img src=\"dislike.png\" alt=\"\" /><a href=\"shoutproc.php?action=dislike&who=$who&shid=$lshout[2]\"><font color=\"#336699\">Disagree</font></a>$dislyk<br/></div>";
if ((getuid_sid($sid))==$lshout[1])
{
$shbox .= "[<a href=\"edit.php?action=shout&shid=$lshout[2]\">Edit</a>]";
}
if (isclubmod(getuid_sid($sid),$clid)=="1" || isownerclub(getuid_sid($sid),$clid)=="1")
{
$shbox .= "[<a href=\"delete.php?action=shout&shid=$lshout[2]\">Delete Shout</a>]<br/>";
}
return $shbox;
}
/////////////////////////////////////////////Function shoutbox
function g($a) {
$a=(int) $a;
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE id=$a"));
return $sex[0];
}
function getshoutbox3($sid)
{
$lshout = mysql_fetch_array(mysql_query("SELECT shout, shouter, id, shtime, act_uday FROM ibwff_shouts WHERE clubid=0 ORDER BY shtime DESC LIMIT 1,1"));

$shdt = date("H:i", $lshout[3]);
$stime = $lshout['shtime'];
$tremain = time()-$stime;
$tmdt = gettimemsg($tremain);
$ttt = date("h:i:s A",($shdt + (6 * 60 * 60)));
$tt2 = ("$tmdt ago");

if(g($lshout[1])=="F") {$clr="red";} else {$clr="";}
$shnick = subnick(getnick_uid($lshout[1]));
$avlink = getavatar($lshout[1]);
if($avlink=="")
{
$shbox .= "[<img src=\"../avatars/nopic.jpg\" height=\"28\" width=\"25\" alt=\"x\"/> ";
}else{
$shbox .= "[<img src=\"$avlink\" height=\"28\" width=\"25\" alt=\"0\"/> ";
}
if($lshout[4]!="")
{
$f = "<font color=\"gray\">is $lshout[4]</font>";
}else{
$f = "";
}
$shbox .= " <a style=\"color:{$clr}\" href=\"profile.php?who=$lshout[1]\"><font color=\"\">".$shnick."</font></a> $f] <br/> ";
$text = parsepm($lshout[0], $sid);
$shbox .= "$text<br/><br/>";
$shcomm = mysql_fetch_assoc(mysql_query("SELECT COUNT(*) comm FROM ibwff_shcomments WHERE shoutid='".$lshout[2]."'"));
$shout = $shcomm['comm'];
$counts = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_like WHERE shoutid='".$lshout[2]."'"));
$counts1 = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_dislike WHERE shoutid='".$lshout[2]."'"));
if($counts[0]>0){ $lyk = "(<a style=\"color:#336699\" href=\"like.php?shid=$lshout[2]\"><font color=\"#336699\">$counts[0]</font></a>)";
 }else{ 
 $lyk = "(<a style=\"color:#336699\" href=\"like.php?shid=$lshout[2]\"><font color=\"#336699\">0</font></a>)"; }
if($counts1[0]>0){ $dislyk = "(<a style=\"color:#336699\" href=\"dislike.php?shid=$lshout[2]\"><font color=\"#336699\">$counts1[0]</font></a>)";
 }else{ 
 $dislyk = "(<a style=\"color:#336699\" href=\"dislike.php?shid=$lshout[2]\"><font color=\"#336699\">0</font></a>)"; }
$shcomm = mysql_fetch_assoc(mysql_query("SELECT COUNT(*) comm FROM ibwff_shcomments WHERE shoutid='".$lshout[2]."'"));
$shout = $shcomm['comm'];
$shbox .= "<div class=\"likebox\" align=\"center\">";
  $shbox .= "<img src=\"comment.png\" alt=\"\"><a href=\"shcomments.php?shid=$lshout[2]\">Comments($shout)</a>";
$shbox .= "<hr><img src=\"like.png\" alt=\"\"><a href=\"shoutproc.php?action=like&who=$who&shid=$lshout[2]\">Agree</a>$lyk";
$shbox .= "<hr><img src=\"dislike.png\" alt=\"\"><a href=\"shoutproc.php?action=dislike&who=$who&shid=$lshout[2]\">Disagree</a>$dislyk <br/> ";
$shbox .= "</div>";
$shbox .= "<center>$tt2</center><hr/>";
$a = udaypu(getuid_sid($sid));

if (shoutboss(getuid_sid($sid)) || ismod(getuid_sid($sid)) || $a==$lshout[1])
{
$shbox .= "[<a href=\"edit.php?action=shout&shid=$lshout[2]\">Edit</a>]";
}
if(ismod(getuid_sid($sid)) || shoutboss(getuid_sid($sid)))
{
$shbox .= "[<a href=\"delete.php?action=shout&shid=$lshout[2]\">Delete Shout</a>]";
}
return $shbox;

}
function gettid_pid($pid)
{
$tid = mysql_fetch_array(mysql_query("SELECT tid FROM ibwff_posts WHERE id='".$pid."'"));
return $tid[0];
}


///////////////////////////////////////////is trashed by CJ UDAY?
function istrashed($uid)
{
$del = mysql_query("DELETE FROM ibwff_penalties WHERE timeto<'".time()."'");
$not = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='0'"));
if($not[0]>0)
{
return true;
}else{
return false;
}
}
///////////////////////////////////////////is shielded by CJ UDAY?
function isshield($uid)
{
$not = mysql_fetch_array(mysql_query("SELECT shield FROM ibwff_users WHERE id='".$uid."'"));
if($not[0]=='1')
{
return true;
}else{
return false;
}
}
/////////////////////////////////////////getclublogo By CJ UDAY :)
function getclubslogo($clid)
{
$logo = mysql_fetch_array(mysql_query("SELECT logo FROM ibwff_clubs WHERE id='".$clid."'"));
return $logo[0];
}
/////////////////NetWork by CJ UDAY :-) 
function ip()
{
if($_SERVER["REMOTE_ADDR"]){$ip=$_SERVER["REMOTE_ADDR"];}
else{$ip=$_SERVER["HTTP_X_FORWARDED_FOR"];}
if(strpos($ip,",")){
$exp_ip=explode(",",$ip);
$ip=$exp_ip[0];
}
return $ip;
}
function ipinrange($ip, $range1, $range2)
{
$ip=ip2long($ip);
$range1=ip2long($range1);
$range2=ip2long($range2);
return (($ip >= $range1) && ($ip <= $range2));
}
function network($ip)
{
$result=mysql_query("SELECT * FROM network ORDER BY subone, subtwo");
while($ranges=mysql_fetch_array($result)){
if(ipinrange($ip, $ranges[1], $ranges[2])){
if(is_file("flags/".$ranges["flag"])){
$flag="<img src=\"flags/$ranges[5]\" alt=\"$ranges[5]\"/> ";
}
return $flag.$ranges["isp"];
}
}
}
function isbanned($uid)
{
$del = mysql_query("DELETE FROM ibwff_penalties WHERE timeto<'".time()."'");
$not = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_penalties WHERE uid='".$uid."' AND (penalty='1' OR penalty='2')"));
if($not[0]>0)
{
return true;
}else{
return false;
}
}
function gettname($tid)
{
$tid = mysql_fetch_array(mysql_query("SELECT name FROM ibwff_topics WHERE id='".$tid."'"));
return $tid[0];
}
function getfid_tid($tid)
{
$fid = mysql_fetch_array(mysql_query("SELECT fid FROM ibwff_topics WHERE id='".$tid."'"));
return $fid[0];
}
function isipbanned($ipa, $brm)
{  
  $pinf = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_penalties WHERE penalty='2' AND ipadd='".$ipa."' AND browserm='".$brm."'"));
  if($pinf[0]>0)
  {
  return true;
}
return false;
}
function getpinned($fid)
{
$nop = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_topics WHERE fid='".$fid."' AND pinned ='1'"));
return $nop[0];
}
function candelblogcomment($bid,$mid)
{
$minfo = mysql_fetch_array(mysql_query("SELECT blogowner, blogsigner FROM ibwff_blogcomment WHERE id='".$mid."'"));
if($minfo[0]==$bid)
{
return true;
}
if($minfo[1]==$bid)
{
return true;
}
return false;
}
/////////////////////////////////////////////can bud?
function budres($uid, $tid)
{
if($uid==$tid)
{
return 3;
}
if(arebuds($uid, $tid))
{
return 2;
}
$req = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_buddies WHERE ((uid='".$uid."' AND tid='".$tid."') OR (uid='".$tid."' AND tid='".$uid."')) AND agreed='0'"));
if($req[0]>0)
{
return 1;
}
$notb = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_buddies WHERE (uid='".$tid."' OR tid='".$tid."') AND agreed='1'"));
global $max_buds;
if($notb[0]>=$max_buds)
{
return 3;
}
$notb = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_buddies WHERE (uid='".$uid."' OR tid='".$uid."') AND agreed='1'"));
global $max_buds;
if($notb[0]>=$max_buds)
{
return 3;
}
return 0;
}

////////////////////////////////////////////Session expiry time by CJ UDAY :-)
function getsxtm()
{
$getdata = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='sesexp'"));
return $getdata[0];
}
////////////////////////////////////////////Get forum name
function getfname($fid)
{
$fname = mysql_fetch_array(mysql_query("SELECT name FROM ibwff_forums WHERE id='".$fid."'"));
return $fname[0];
}
////////////////////////////////////////////Get literature name
function getletname($fid)
{
$fname = mysql_fetch_array(mysql_query("SELECT name FROM ibwff_literatures WHERE id='".$fid."'"));
return $fname[0];
}
////////////////////////////////////////////antiflood time by CJ UDAY :-)
function getpmaf()
{
$getdata = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='pmaf'"));
return $getdata[0];
}
function getshoutaf()
{
$getdata = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='shoutaf'"));
return $getdata[0];
}
function getregaf()
{
$getdata = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='regaf'"));
return $getdata[0];
}
////////////////////////////////////////////Point stystem by CJ UDAY :-)
function cpoint()
{
$getdata = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='cpoint'"));
return $getdata[0];
}
function spoint()
{
$getdata = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='spoint'"));
return $getdata[0];
}
function lpoint()
{
$getdata = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='lpoint'"));
return $getdata[0];
}
function hpoint()
{
$getdata = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='hpoint'"));
return $getdata[0];
}
function mkfpoint()
{
$getdata = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='mkfpoint'"));
return $getdata[0];
}
function fcompoint()
{
$getdata = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='fcompoint'"));
return $getdata[0];
}
function litpoint()
{
$getdata = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='litpoint'"));
return $getdata[0];
}
function litcompoint()
{
$getdata = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='litcompoint'"));
return $getdata[0];
}
function blogcompoint()
{
$getdata = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='blogcompoint'"));
return $getdata[0];
}
function blogpoint()
{
$getdata = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='blogpoint'"));
return $getdata[0];
}
function fpluss()
{
$getdata = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='fpluss'"));
return $getdata[0];
}
function clpluss()
{
$getdata = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='clpluss'"));
return $getdata[0];
}
function nmpluss()
{
$getdata = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='nmpluss'"));
return $getdata[0];
}
function newclubpoint()
{
$getdata = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='newclubpoint'"));
return $getdata[0];
}
/////////////////// member status By CJ UDAY :-)
function memberpoint()
{
$getdata = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='memberpoint'"));
return $getdata[0];
}
function junmemberpoint()
{
$getdata = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='junmemberpoint'"));
return $getdata[0];
}
function senmemberpoint()
{
$getdata = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='senmemberpoint'"));
return $getdata[0];
}
function knightpoint()
{
$getdata = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='knightpoint'"));
return $getdata[0];
}
function expartpoint()
{
$getdata = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='expartpoint'"));
return $getdata[0];
}
function expellerpoint()
{
$getdata = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='expellerpoint'"));
return $getdata[0];
}
function mrsmispoint()
{
$getdata = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='mrsmispoint'"));
return $getdata[0];
}
function pppoint()
{
$getdata = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='pppoint'"));
return $getdata[0];
}
function king()
{
$getdata = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='king'"));
return $getdata[0];
}
function kok()
{
$getdata = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='kok'"));
return $getdata[0];
}
function getfmsg()
{
$getdata = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='4ummsg'"));
return $getdata[0];
}
function isonline($uid)
{
$uon = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_online WHERE userid='".$uid."'"));
if($uon[0]>0)
{
return true;
}else{
return false;
}
}
function canreg()
{
$getreg = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='reg'"));
if($getreg[0]=='0')
{
return false;
}else{
return true;
}
}
function validation()
{
$getval = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='vldtn'"));
if($getval[0]=='1')
{
return true;
}else{
return false;
}
}
function fmvldtn()
{
$getval = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='fmvldtn'"));
if($getval[0]=='1')
{
return true;
}else{
return false;
}
}function fmtvldtn()
{
$getval = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='tpcval'"));
if($getval[0]=='1')
{
return true;
}else{
return false;
}
}
function litcatvldtn()
{
$getval = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='artval'"));
if($getval[0]=='1')
{
return true;
}else{
return false;
}
}
function litvldtn()
{
$getval = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='litvldtn'"));
if($getval[0]=='1')
{
return true;
}else{
return false;
}
}
function pollvldtn()
{
$getval = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='pollvldtn'"));
if($getval[0]=='1')
{
return true;
}else{
return false;
}
}
function blogvldtn()
{
$getval = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='blogvldtn'"));
if($getval[0]=='1')
{
return true;
}else{
return false;
}
}
//////////////////////////////////////////Is Blocked 2 CJ UDAY :)
function isgiftblocked($str,$sender)
{
if(ismod($sender))
{
return false;
}
$str = str_replace(" ","",$str);
$str = strtolower($str);
$res = mysql_query("SELECT name FROM ibwff_giftblocked11");
while ($row = mysql_fetch_array($res))
{
$sites[] = $row[0];
}
for($i=0;$i<count($sites);$i++)
{
$nosf = substr_count($str,$sites[$i]);
if($nosf>0)
{
return true;
}
}
return false;
}
///////////////////////////////////////////Register Blocked By CJ UdaY :)
function isregblocked($str,$sender)
{
if(ismod($sender))
{
return false;
}
$str = str_replace(" ","",$str);
$str = strtolower($str);
$res = mysql_query("SELECT name FROM ibwff_regblock65");
while ($row = mysql_fetch_array($res))
{
$sites[] = $row[0];
}
for($i=0;$i<count($sites);$i++)
{
$nosf = substr_count($str,$sites[$i]);
if($nosf>0)
{
return true;
}
}
return false;
}
///////////////////////////////////////////Blocked Bad Nick Names By CJ UDAY :)
function isnickblocked($str,$sender)
{
if(ismod($sender))
{
return false;
}
$str = str_replace(" ","",$str);
$str = strtolower($str);
$res = mysql_query("SELECT nick FROM ibwff_nickblock88");
while ($row = mysql_fetch_array($res))
{
$sites[] = $row[0];
}
for($i=0;$i<count($sites);$i++)
{
$nosf = substr_count($str,$sites[$i]);
if($nosf>0)
{
return true;
}
}
return false;
}
function isstarred($pmid)
{
$strd = mysql_fetch_array(mysql_query("SELECT starred FROM ibwff_private WHERE id='".$pmid."'"));
if($strd[0]=="1")
{
return true;
}else{
return false;
}
}
function islogged($sid)
{
$deloldses = mysql_query("DELETE FROM ibwff_ses WHERE expiretm<'".time()."'");
$sesx = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_ses WHERE id='".$sid."'"));
if($sesx[0]>0)
{
if(!isuser(getuid_sid($sid)))
{
return false;
}
$xtm = time() + (60*getsxtm());
$extxtm = mysql_query("UPDATE ibwff_ses SET expiretm='".$xtm."' WHERE id='".$sid."'");
return true;
}else{
return false;
}
}
/////////////////////Get total number of pms by CJ UDAY :-)
function getpmcount($uid,$view="all")
{
if($view=="all"){
$nopm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_private WHERE touid='".$uid."' AND starred='0'"));
}else if($view =="snt")
{
$nopm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_private WHERE byuid='".$uid."'"));
}else if($view =="str")
{
$nopm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_private WHERE touid='".$uid."' AND starred='1'"));
}else if($view =="urd")
{
$nopm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_private WHERE touid='".$uid."' AND unread='1'"));
}
return $nopm[0];
}
function deleteClub($clid)
{
$fid = mysql_fetch_array(mysql_query("SELECT id FROM ibwff_forums WHERE clubid='".$clid."'"));
$fid = $fid[0];
$topics = mysql_query("SELECT id FROM ibwff_topics WHERE fid=".$fid."");
while($topic = mysql_fetch_array($topics))
{
mysql_query("DELETE FROM ibwff_posts WHERE tid='".$topic[0]."'");
}
mysql_query("DELETE FROM ibwff_topics WHERE fid='".$fid."'");
mysql_query("DELETE FROM ibwff_forums WHERE id='".$fid."'");
mysql_query("DELETE FROM ibwff_rooms WHERE clubid='".$clid."'");
mysql_query("DELETE FROM ibwff_clubmembers WHERE clid='".$clid."'");
mysql_query("DELETE FROM ibwff_announcements WHERE clid='".$clid."'");
mysql_query("DELETE FROM ibwff_clubs WHERE id='".$clid."'");
return true;
}

//////////////////////Function add user to online list :P By CJ UdaY :)
function addonline($uid,$place,$plclink)
{
$hidden=mysql_fetch_array(mysql_query("SELECT hidden FROM ibwff_users WHERE id='".$uid."'"));
if($hidden[0]==0)
{
$tm = time();
$timeout = $tm - 3600; 
$deloff = mysql_query("DELETE FROM ibwff_online WHERE actvtime <'".$timeout."'");
 mysql_query("UPDATE ibwff_users SET pu='0' WHERE ptime<'".time()."'");
$lttime = mysql_fetch_array(mysql_query("SELECT lastact, plustime, onlinetoday FROM ibwff_users WHERE id='".$uid."'")); 
$limit = time() - $lttime[0]; 
    date_default_timezone_set('UTC');
    $New_Time = time() + (6 * 60 * 60);
    $Hour = date("G",$New_Time);
	if($limit<450)
	{
	$newtime = $lttime[2] + $limit; 
    if($Hour == 00)
	{
	mysql_query("UPDATE ibwff_users SET onlinetoday='0'"); 
	}
	else
	{
 mysql_query("UPDATE ibwff_users SET onlinetoday='".$newtime."' WHERE id='".$uid."'"); 
}
}
if($limit<450){
$newtime = $lttime[1] + $limit; 
if($newtime>3600){
mysql_query("UPDATE ibwff_users SET plustime='0', totaltime=totaltime+$limit, plusses=plusses+5 WHERE id='".$uid."'"); 
$res = mysql_query("INSERT INTO ibwff_notifications SET text='5 points added to your profile for stying online 1 hour through -up-', touid='".$uid."', timesent='".time()."'"); 
}else{ 
mysql_query("UPDATE ibwff_users SET  totaltime=totaltime+$limit, plustime='$newtime' WHERE id='".$uid."'"); 
} 
} 
$res = mysql_query("UPDATE ibwff_users SET lastact='".time()."' WHERE id='".$uid."'");
$res = mysql_query("INSERT INTO ibwff_online SET userid='".$uid."', actvtime='".$tm."', place='".$place."', placedet='".$plclink."'");
mysql_query("UPDATE ibwff_users SET lastact='".time()."' WHERE id='3'");
mysql_query("INSERT INTO ibwff_online SET userid='3', place='".$place."', actvtime='".$tm."'");
if(!$res)
{
$res = mysql_query("UPDATE ibwff_online SET actvtime='".$tm."', place='".$place."', placedet='".$plclink."' WHERE userid='".$uid."'");





}

}

$maxmem=mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE id='2'"));



$result = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_online"));



if($result[0]>=$maxmem[0])

{

$tnow = date("D d M Y - H:i");

mysql_query("UPDATE ibwff_settings set name='".$tnow."', value='".$result[0]."' WHERE id='2'");

}

$maxtoday = mysql_fetch_array(mysql_query("SELECT ppl FROM ibwff_mpot WHERE ddt='".date("d m y")."'"));

if($maxtoday[0]==0||$maxtoday=="")

{

mysql_query("INSERT INTO ibwff_mpot SET ddt='".date("d m y")."', ppl='1', dtm='".date("H:i:s")."'");

$maxtoday[0]=1;

}

if($result[0]>=$maxtoday[0])

{

mysql_query("UPDATE ibwff_mpot SET ppl='".$result[0]."', dtm='".date("H:i:s")."' WHERE ddt='".date("d m y")."'");

}
$TIMETOBEONLINE = 1*60*60;
$PLUSSESTOADD = 10;  $PLUSSESTOADD2 = 3;
$un_tmonl = $hidden[2];
$tm_give = $TIMETOBEONLINE;
if($un_tmonl >= $tm_give)
{
$res = mysql_query("UPDATE ibwff_users SET plusses=plusses+$PLUSSESTOADD, rp=rp+$PLUSSESTOADD2, unique_tmonl='0' WHERE id='".$uid."'");
if($res)
{
$calc=floor($TIMETOBEONLINE/60/60);
if($calc<1) {$calc=floor($TIMETOBEONLINE/60)." minute(s)";} else {$calc=$calc." hour";}
$msg = "You have been given ".$PLUSSESTOADD." Points and ".$PLUSSESTOADD2." RP for staying online for ".$calc." continuosly...";
mysql_query("INSERT INTO ibwff_private SET text='".$msg."', byuid='3', touid='".$uid."', unread='1', timesent='".time()."'");
}
}
$lastact = $hidden[1];
$valid = 30*60;
$tmediff = time() - $lastact;
if($tmediff <= $valid) {
mysql_query("UPDATE ibwff_users SET tmonl=tmonl+$tmediff, unique_tmonl=unique_tmonl+$tmediff WHERE id='".$uid."'");
} else {
mysql_query("UPDATE ibwff_users SET unique_tmonl='0' WHERE id='".$uid."'");
}
}
/////////////////////Get members online by CJ UDAY :-)
function getnumonline()
{
$nouo = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_online "));
return $nouo[0];
}
function isignored($tid, $uid)
{
$ign = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_ignore WHERE target='".$tid."' AND name='".$uid."'"));
if($ign[0]>0 && !ismod($uid))
{
return true;
}
return false;
}
//////////////////////////////////////////GET IP
function getip(){
if (isset($_SERVER)){
if(isset($_SERVER["HTTP_X_FORWARDED_FOR"])){
$ip = $_SERVER["HTTP_X_FORWARDED_FOR"];
if(strpos($ip,",")){
$exp_ip = explode(",",$ip);
$ip = $exp_ip[0];
}
}else if(isset($_SERVER["HTTP_CLIENT_IP"])){
$ip = $_SERVER["HTTP_CLIENT_IP"];
}else{
$ip = $_SERVER["REMOTE_ADDR"];
}
}else{
if(getenv('HTTP_X_FORWARDED_FOR')){
$ip = getenv('HTTP_X_FORWARDED_FOR');
if(strpos($ip,",")){
$exp_ip=explode(",",$ip);
$ip = $exp_ip[0];
}
}else if(getenv('HTTP_CLIENT_IP')){
$ip = getenv('HTTP_CLIENT_IP');
}else {
$ip = getenv('REMOTE_ADDR');
}
}
return $ip; 
}
//////////////////////////////////////////ignore result by CJ UDAY :-)
function ignoreres($uid, $tid)
{
if($uid==$tid)
{
return 0;
}
if(ismod($tid))
{
return 0;
}
if(isignored($tid, $uid))
{
return 2;
}
return 1;
}
///////////////////////////////////////////Function getage by CJ UDAY :-)
function getage($strdate)
{
$dob = explode("-",$strdate);
if(count($dob)!=3)
{
return 0;
}
$y = $dob[0];
$m = $dob[1];
$d = $dob[2];
if(strlen($y)!=4)
{
return 0;
}
if(strlen($m)!=2)
{
return 0;
}
if(strlen($d)!=2)
{
return 0;
}
$y += 0;
$m += 0;
$d += 0;
if($y==0) return 0;
$rage = date("Y") - $y;
if(date("m")<$m)
{
$rage-=1;
}else{
if((date("m")==$m)&&(date("d")<$d))
{
$rage-=1;
}
}
return $rage;
}
/////////////////////////////////////////Avatar By CJ UdaY :)
function getavatar($uid)
{
$av = mysql_fetch_array(mysql_query("SELECT avatar FROM ibwff_users WHERE id='".$uid."'"));
return $av[0];
}
/////////////////////////////////////////Coverpic By CJ UDAY :)
function getcoverpic($uid)
{
$cv = mysql_fetch_array(mysql_query("SELECT coverpic FROM ibwff_users WHERE id='".$uid."'"));
return $cv[0];
}
/////////////////////////////////////////getclublogo By CJ UDAY :)
function getclublogo($clid)
{
$av = mysql_fetch_array(mysql_query("SELECT logo FROM ibwff_clubs WHERE id='".$clid."'"));
return $av[0];
}
/////////////////////////////////////////Can see details?
function cansee($uid, $tid)
{
if($uid==$tid)
{
return true;
}
if(ismod($uid))
{
return true;
}
return false;
}
//////////////////////////gettimemsg by CJ UDAY :-)
function gettimemsg($sec)
{
$years=0;
$months=0;
$weeks=0;
$days=0;
$mins=0;
$hours=0;
if ($sec>59)
{
$secs=$sec%60;
$mins=$sec/60;
$mins=(integer)$mins;
}
if ($mins>59)
{
$hours=$mins/60;
$hours=(integer)$hours;
$mins=$mins%60;
}
if ($hours>23)
{
$days=$hours/24;
$days=(integer)$days;
$hours=$hours%24;
}
if ($days>6)
{
$weeks=$days/7;
$weeks=(integer)$weeks;
$days=$days%7;
}
if ($weeks>3)
{
$months=$weeks/4;
$months=(integer)$months;
$weeks=$weeks%4;
}
if ($months>11)
{
$years=$months/12;
$years=(integer)$years;
$months=$months%12;
}
if($years>0)
{
if($years==1){$yearmsg="year";}else{$yearmsg="years";}
if($months==1){$monthsmsg="month";}else{$monthsmsg="months";}
if($days==1){$daysmsg="day";}else{$daysmsg="days";}
if($hours==1){$hoursmsg="hour";}else{$hoursmsg="hours";}
if($mins==1){$minsmsg="minute";}else{$minsmsg="minutes";}
if($secs==1){$secsmsg="second";}else{$secsmsg="seconds";}
if($months!=0){$monthscheck="$months $monthsmsg ";}else{$monthscheck="";}
if(($days!=0)&&($months==0)){$dayscheck="$days $daysmsg ";}else{$dayscheck="";}
if(($hours!=0)&&($months==0)&&($days==0)){$hourscheck="$hours $hoursmsg ";}else{$hourscheck="";}
if(($mins!=0)&&($months==0)&&($days==0)&&($hours==0)){$minscheck="$mins $minsmsg ";}else{$minscheck="";}
if(($secs!=0)&&($months==0)&&($days==0)&&($hours==0)&&($mins==0)){$secscheck="$secs $secsmsg";}else{$secscheck="";}
return "$years $yearmsg $monthscheck$dayscheck$hourscheck$minscheck$secscheck";
}
if(($years<1)&&($months>0))
{
if($months==1){$monthsmsg="month";}else{$monthsmsg="months";}
if($days==1){$daysmsg="day";}else{$daysmsg="days";}
if($hours==1){$hoursmsg="hour";}else{$hoursmsg="hours";}
if($mins==1){$minsmsg="minute";}else{$minsmsg="minutes";}
if($secs==1){$secsmsg="second";}else{$secsmsg="seconds";}
if($days!=0){$dayscheck="$days $daysmsg ";}else{$dayscheck="";}
if(($hours!=0)&&($days==0)){$hourscheck="$hours $hoursmsg ";}else{$hourscheck="";}
if(($mins!=0)&&($days==0)&&($hours==0)){$minscheck="$mins $minsmsg ";}else{$minscheck="";}
if(($secs!=0)&&($days==0)&&($hours==0)&&($mins==0)){$secscheck="$secs $secsmsg";}else{$secscheck="";}
return "$months $monthsmsg $dayscheck$hourscheck$minscheck$secscheck";
}
if(($months<1)&&($weeks>0))
{
if($weeks==1){$weeksmsg="week";}else{$weeksmsg="weeks";}
if($days==1){$daysmsg="day";}else{$daysmsg="days";}
if($hours==1){$hoursmsg="hour";}else{$hoursmsg="hours";}
if($mins==1){$minsmsg="minute";}else{$minsmsg="minutes";}
if($secs==1){$secsmsg="second";}else{$secsmsg="seconds";}
if($days!=0){$dayscheck="$days $daysmsg ";}else{$dayscheck="";}
if(($hours!=0)&&($days==0)){$hourscheck="$hours $hoursmsg ";}else{$hourscheck="";}
if(($mins!=0)&&($days==0)&&($hours==0)){$minscheck="$mins $minsmsg ";}else{$minscheck="";}
if(($secs!=0)&&($days==0)&&($hours==0)&&($mins==0)){$secscheck="$secs $secsmsg";}else{$secscheck="";}
return "$weeks $weeksmsg $dayscheck$hourscheck$minscheck$secscheck";
}
if(($weeks<1)&&($days>0))
{
if($days==1){$daysmsg="day";}else{$daysmsg="days";}
if($hours==1){$hoursmsg="hour";}else{$hoursmsg="hours";}
if($mins==1){$minsmsg="minute";}else{$minsmsg="minutes";}
if($secs==1){$secsmsg="second";}else{$secsmsg="seconds";}
if($hours!=0){$hourscheck="$hours $hoursmsg ";}else{$hourscheck="";}
if(($mins!=0)&&($hours==0)){$minscheck="$mins $minsmsg ";}else{$minscheck="";}
if(($secs!=0)&&($hours==0)&&($mins==0)){$secscheck="$secs $secsmsg";}else{$secscheck="";}
return "$days $daysmsg $hourscheck$minscheck$secscheck";
}
if(($days<1)&&($hours>0))
{
if($hours==1){$hoursmsg="hour";}else{$hoursmsg="hours";}
if($mins==1){$minsmsg="minute";}else{$minsmsg="minutes";}
if($secs==1){$secsmsg="second";}else{$secsmsg="seconds";}
if($mins!=0){$minscheck="$mins $minsmsg ";}else{$minscheck="";}
if(($secs!=0)&&($mins==0)){$secscheck="$secs $secsmsg";}else{$secscheck="";}
return "$hours $hoursmsg $minscheck$secscheck";
}
if(($hours<1)&&($mins>0))
{
if($mins==1){$minsmsg="minute";}else{$minsmsg="minutes";}
if(($secs==1)&&($mins==0)){$secsmsg="second";}else{$secsmsg="seconds";}
if($secs!=0){$secscheck="$secs $secsmsg";}else{$secscheck="";}
return "$mins $minsmsg $secscheck";
}
if(($mins<1)&&($sec>0))
{
if($sec==1){$secsmsg="second";}else{$secsmsg="seconds";}
if($sec!=0){$secscheck="$sec $secsmsg";}else{$secscheck="";}
return "$secscheck";
}else{
return "0 Seconds!";
}
}
////////////////////// Golden Lotto by CJ UDAY :-)
$nowx = time();
$lttime = mysql_fetch_array(mysql_query("SELECT lastact, plustime, onlinetoday FROM ibwff_users WHERE id='".$uid."'")); 
$limit = time() - $lttime[0]; 
    date_default_timezone_set('UTC');
    $New_Time = time() + (6 * 60 * 60);
    $Hour = date("G",$New_Time);
	if($limit<450)
	{
	$newtime = $lttime[2] + $limit; 
    if($Hour == 00)
	{
	mysql_query("UPDATE ibwff_users SET onlinetoday='0'"); 
	}
	else
	{
 mysql_query("UPDATE ibwff_users SET onlinetoday='".$newtime."' WHERE id='".$uid."'"); 
}
}
if($limit<450){
$newtime = $lttime[1] + $limit;
$mastercredit = mysql_fetch_array(mysql_query("SELECT lotto FROM ibwff_users WHERE id='$uid'"));
if($mastercredit[0]>0)
{
if($newtime>3600){
mysql_query("UPDATE ibwff_users SET newtime='0', totaltime=totaltime+$limit, plusses=plusses+15 WHERE id='$uid'");
$ms = "You have been Online for 1 hour. You have received 15 credits as a [b]Golden Lotto Subscriber![/b]";
notify($msg, $uid);
}else{
mysql_query("UPDATE ibwff_users SET  totaltime=totaltime+$limit, newtime='".$newtime."' WHERE id='".$uid."'");
}
}
}
////////////Golden Lotto TIME EXPIRE By CJ UDAY :-)
$nowx = time();
$data = mysql_fetch_array(mysql_query("SELECT lottotime FROM ibwff_user WHERE id='".$uid."'"));
$expire = $data[0];
if($nowx>$expire){
mysql_query("UPDATE ibwff_user SET lottotime='0', lotto='0' WHERE id='".$uid."'");
}
/////////////////////////////////////////get status by CJ UDAY :-)
function getstatus($uid)
{
$info= mysql_fetch_array(mysql_query("SELECT cyberpowereragon, plusses, vip, pu, totaltime FROM ibwff_users WHERE id='".$uid."'"));
	$memberpoint = memberpoint();
	$junmemberpoint = junmemberpoint();
	$senmemberpoint = senmemberpoint();
	$knightpoint = knightpoint();
	$expartpoint = expartpoint();
	$expellerpoint = expellerpoint();
	$mrsmispoint = mrsmispoint();
	$pppoint = pppoint();
	$king = king();
	$kok = kok();
$hour = $info[4];
if(isbanned($uid))
{
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$d = $banto[0] - time();
return "BANNED : $banto[1] || Time To Finish Penalty: ".gettimemsg($d)."";
}
$f = mysql_fetch_array(mysql_query("SELECT title_uday FROM ibwff_users WHERE id='".$uid."'"));
if($f[0]!="")
{
return $f[0];
}else
   if($info[3]>'0')
  {
    return "Premium Member!";
  }else if($info[0]=='5')
{
return "Administrator!";
}else if($info[0]=='7')
{
return "Advisor!";
}else if($info[0]=='4')
{
return "Head Moderator!";
}else if($info[0]=='3')
{
return "Senior Moderator!";
}
else if($info[0]=='2')
{
return "Junior Moderator!";
}else if($info[0]=='1')
{
return "Moderator!";
}else{
if($info[4]<$memberpoint)
{
return "New Member!";
}
else if($info[4]>$memberpoint && $info[4]<$junmemberpoint)
{
return "Member!";
}
else if($info[4]>$junmemberpoint && $info[4]<$senmemberpoint)
{
return "Junior Member!";
}else if($info[4]>$senmemberpoint && $info[4]<".junvip().")
{
return "Senior Member!";
}else if($info[4]>".junvip()." && $info[4]<".senvip().")
{
if(!isvip($uid))
{
return "Senior Member!";
}else{
return "Junior VIP!";
}
}else if($info[4]>".senvip().")
{
if(!isvip($uid))
{
return "Senior Member!";
}else{
return "Senior VIP!";
}
}else if($info[1]>".knightpoint().")
{
return "MyDhaka Knight!";
}else if($info[1]>".expellerpoint().")
{
return "MyDhaka Expeller!";
}else if($info[1]>$expartpoint)
{
return "MyDhaka Expart!";
}else if($info[1]>$mrsmispoint)
{
return "MyDhaka Master/Mistres!";
}else if($info[1]>$pppoint)
{
return "MyDhaka Prince/Princes!";
}else if($info[1]>$king)
{
return "MyDhaka King/Queen!";
}else if($info[1]>$kok)
{
return "King of the King!";
}else{
return "New Member!";
}
}
}
function getunreadpm($uid)
{
$nopm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_private WHERE touid='".$uid."' AND unread='1'"));
return $nopm[0];
}
function getunreadmms($uid)
{
$nopm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_mms WHERE touid='".$uid."' AND unread='1'"));
return $nopm[0];
}
////////////////////////////////Mind Status By CJ UdaY :)
function getmindstatus($uid)
{
$nopm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_mindstatus11 WHERE uid='".$uid."'"));
return $nopm[0];
}
function getguestbook($uid)
{
$nopm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_gbook WHERE gbsigner='".$uid."'"));
return $nopm[0];
}
function getnick_uid($uid)
{
$unick = mysql_fetch_array(mysql_query("SELECT name FROM ibwff_users WHERE id='".$uid."'"));
return $unick[0];
}
function subnick($a)
{
$unick = mysql_fetch_array(mysql_query("SELECT hiranick, name FROM ibwff_users WHERE name='".$a."'"));
if(trim($unick[0]=="")) {
return $unick[1];
} else {
return $unick[0];
}
}
function getsmilies($text)
{
$sql = "SELECT * FROM ibwff_smilies";
$smilies = mysql_query($sql);
while($smilie=mysql_fetch_array($smilies))
{
$scode = $smilie[1];
$spath = $smilie[2];
$text = str_replace($scode,"<img src=\"$spath\" alt=\"$scode\"/>",$text);
}
return $text;
}
function getgallery($text)
{
$sql = "SELECT * FROM ibwff_gallery";
$smilies = mysql_query($sql);
while($smilie=mysql_fetch_array($smilies))
{
$scode = $gallery[1];
$spath = $gallery[2];
$text = str_replace($scode,"<img src=\"$spath\" alt=\"$scode\"/>",$text);
}
return $text;
}
function checknick($aim)
{
$chk =0;
$aim = strtolower($aim);
$nicks = mysql_query("SELECT id, name, nicklvl FROM ibwff_nicks");
while($nick=mysql_fetch_array($nicks))
{
if($aim==$nick[1])
{
$chk = $nick[2];
}else if(substr($aim,0,strlen($nick[1]))==$nick[1])
{
$chk = $nick[2];
}else{
$found = strpos($aim, $nick[1]);
if($found!=0)
{
$chk = $nick[2];
}
}
}
return $chk;
}
function autopm($msg, $who)
{
mysql_query("INSERT INTO ibwff_private SET text='".$msg."', byuid='3', touid='".$who."', unread='1', timesent='".time()."'");
}
////////////////////////////////////////////////////Register

function register($name,$pass,$year,$month,$day,$usex,$uloc,$email,$ubr,$abtme,$country,$phone)
{
$name=strtolower($name);
  $execms = mysql_query("SELECT * FROM ibwff_users WHERE lower(name)='".$name."';");
  if (mysql_num_rows($execms)>0){
    return 1;
  }else{
$validation = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='vldtn'"));
if($validation[0]==1)
{
$validated=1;
}else{
$validated=0;
}
    $pass2 = md5($pass);
    $regx = mysql_query("INSERT INTO ibwff_users SET name='".$name."', pass='".$pass2."', birthday='".$year.$month.$day."', sex='".$usex."', location='".$uloc."', email='".$email."', browserm='".$ubr."', regdate='".time()."', ipadd='".getip()."', validated='".$validated."', interested='".$abtme."', country='".$country."', phone='".$phone."', hiranick='".$name."'");
    if ($regx)
    {
      $uid = mysql_fetch_array(mysql_query("SELECT id FROM ibwff_users WHERE lower(name)='".$name."'"));
      $msg = "Hello /reader,[br/][br/]Welcome to our small happy family![br/][br/]If you have any questions or comments about the site feel free to message any of the staff member from the online list.[br/]You can gain points by posting in forums,literatures,blogs,polls,contests which will unlock other parts of this great site!-flower-[br/][small][i]p.s: this is an automated sign[/i][/small]";
      $msg = mysql_real_escape_string($msg);
      autopm($msg, $uid[0]);
	   $msg2 = "Hello /reader,[br/][br/]Welcome to our small happy family![br/][br/]If you have any questions or comments about the site feel free to message any of the staff member from the online list.[br/]You can gain points by posting in forums,literatures,blogs,polls,contests which will unlock other parts of this great site!-flower-[br/][small][i]p.s: this is an automated sign from MyDhaka![/i][/small]";
      $msg2 = mysql_real_escape_string($msg2);
	        $msg2 = mysql_real_escape_string($msg2);
	  notify($msg2, $uid[0]);
      return 0;
    }else{
      return 2;
    }
  }
}
function getuid_nick($nick)
{
$uid = mysql_fetch_array(mysql_query("SELECT id FROM ibwff_users WHERE name='".$nick."'"));
return $uid[0];
}
function isadmin($uid)
{
$admn = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE id='".$uid."'"));
if($admn[0]>=3)
{
return true;
}else{
return false;
}
}
function isheadadmin($uid)
{
$own = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE id='".$uid."'"));
if($own[0]==4)
{
return true;
}else{
return false;
}
}
function isowner($uid)
{
$own = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE id='".$uid."'"));
if($own[0]>=5)
{
return true;
}else{
return false;
}
}
function topnot_uday($tid,$msg)
{
$pms = mysql_query("SELECT uid FROM uday_subtop WHERE tid='".$tid."'");
$tm = time();
while($pm=mysql_fetch_array($pms))
{
mysql_query("INSERT INTO ibwff_notifications SET text='".$msg."', byuid='3', touid='".$pm[0]."', timesent='".$tm."', sub='1'");
}
}
/////// Club Functions By CJ UdaY
function getclubname($club)
{
$name=mysql_fetch_array(mysql_query("SELECT name FROM ibwff_clubs WHERE id=$club"));
return $name[0];
}
function clubnot_uday($club,$msg)
{
$pms = mysql_query("SELECT uid FROM ibwff_clubmembers WHERE accepted='1' AND clid='".$club."'");
$tm = time();
while($pm=mysql_fetch_array($pms))
{
mysql_query("INSERT INTO ibwff_notifications SET text='".$msg."', byuid='3', touid='".$pm[0]."', timesent='".$tm."'");
}
}
function clubpmall($club,$msg)
{
$pms = mysql_query("SELECT uid, points FROM ibwff_clubmembers WHERE accepted='1' AND clid='".$club."'");
$tm = time();
while($pm=mysql_fetch_array($pms))
{
mysql_query("INSERT INTO ibwff_private SET text='Pm2all Club members:[br/] ".$msg." [br/][b]This Message Send From [u]".getclubname($club)."[/u] Club![/b]', byuid='3', touid='".$pm[0]."', timesent='".$tm."'");
}
}
function clubhis_uday($club,$msg)
{
mysql_query("INSERT INTO ibwff_events SET event='".$msg."', clubid='".$club."', time='".$tm."'");
}
function isbanclub($a,$b) {
$a=(int) $a;
$b=(int) $b;
$po=mysql_fetch_array(mysql_query("SELECT banned FROM ibwff_clubmembers WHERE uid=$a AND clid=$b"));
if ($po[0]==1)
{
return true;
}else{
return false;
}
}
function isclubmember($uid,$club) {
$uid=(int) $uid;
$club=(int) $club;
$po=mysql_fetch_array(mysql_query("SELECT accepted FROM ibwff_clubmembers WHERE uid=$uid AND clid=$club"));
if ($po[0]==1)
{
return true;
}
else
{
return false;
}
}

function canenterclub($uid,$club) {
if (isclubmember($uid,$club))
{
return true;
}
else
if (isownerclub($uid,$club))
{
return true;
}
else
if (ispu($uid))
{
return true;
}
else
if (spu($uid))
{
return true;
}
else
if (isowner($uid))
{
return true;
}
else
if (ismod($uid))
{
return true;
}
else
if(isvip($uid))
{
return true;
}
else
{
return false;
}
}
function isownerclub($a,$b) {
$a=(int) $a;
$b=(int) $b;
$po=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_clubs WHERE owner=$a AND id=$b "));
return $po[0];
}
function isclubmod($a,$b) {
$a=(int) $a;
$b=(int) $b;
$po=mysql_fetch_array(mysql_query("SELECT power FROM ibwff_clubmembers WHERE uid=$a AND clid=$b"));
if ($po[0]==1)
{
return true;
}else{
return false;
}
}
function isclubvip($a,$b) {
$a=(int) $a;
$b=(int) $b;
$po=mysql_fetch_array(mysql_query("SELECT vip FROM ibwff_clubmembers WHERE uid=$a AND clid=$b"));
if ($po[0]==1)
{
return true;
}else{
return false;
}
}
function clubowner($b) {
$a=(int) $a;
$b=(int) $b;
$po=mysql_fetch_array(mysql_query("SELECT owner FROM ibwff_clubs WHERE id=$b "));
return $po[0];
}
function clubmods($b) {
$a=(int) $a;
$b=(int) $b;
$po=mysql_fetch_array(mysql_query("SELECT uid FROM ibwff_clubmembers WHERE clid=$b"));
return $po[0];
}
//////////=> This All Super Bosses Pow3r Added by CJ UdaY :p :p
function bootboss($uid)
{
$own = mysql_fetch_array(mysql_query("SELECT bootpbyhira FROM ibwff_users WHERE id='".$uid."'"));
if($own[0]==1)
{
return true;
}else{
return false;
}
}
function banboss($uid)
{
$own = mysql_fetch_array(mysql_query("SELECT banpbyhira FROM ibwff_users WHERE id='".$uid."'"));
if($own[0]==1)
{
return true;
}else{
return false;
}
}
function ipbanboss($uid)
{
$own = mysql_fetch_array(mysql_query("SELECT ipbanpbyhira FROM ibwff_users WHERE id='".$uid."'"));
if($own[0]==1)
{
return true;
}else{
return false;
}
}
function profileboss($uid)
{
$own = mysql_fetch_array(mysql_query("SELECT profilepbyhira FROM ibwff_users WHERE id='".$uid."'"));
if($own[0]==1)
{
return true;
}else{
return false;
}
}
function readboss($uid)
{
$own = mysql_fetch_array(mysql_query("SELECT readpbyhira FROM ibwff_users WHERE id='".$uid."'"));
if($own[0]==1)
{
return true;
}else{
return false;
}
}
function shoutboss($uid)
{
$own = mysql_fetch_array(mysql_query("SELECT shoutpbyhira FROM ibwff_users WHERE id='".$uid."'"));
if($own[0]==1)
{
return true;
}else{
return false;
}
}
function chatboss($uid)
{
$own = mysql_fetch_array(mysql_query("SELECT chatpbyhira FROM ibwff_users WHERE id='".$uid."'"));
if($own[0]==1)
{
return true;
}else{
return false;
}
}
function forumboss($uid)
{
$own = mysql_fetch_array(mysql_query("SELECT forumpbyhira FROM ibwff_users WHERE id='".$uid."'"));
if($own[0]==1)
{
return true;
}else{
return false;
}
}
function literatureboss($uid)
{
$own = mysql_fetch_array(mysql_query("SELECT literaturepbyhira FROM ibwff_users WHERE id='".$uid."'"));
if($own[0]==1)
{
return true;
}else{
return false;
}
}
function blogboss($uid)
{
$own = mysql_fetch_array(mysql_query("SELECT blogpbyhira FROM ibwff_users WHERE id='".$uid."'"));
if($own[0]==1)
{
return true;
}else{
return false;
}
}
function pollboss($uid)
{
$own = mysql_fetch_array(mysql_query("SELECT pollpbyhira FROM ibwff_users WHERE id='".$uid."'"));
if($own[0]==1)
{
return true;
}else{
return false;
}
}
function galleryboss($uid)
{
$own = mysql_fetch_array(mysql_query("SELECT gallerypbyhira FROM ibwff_users WHERE id='".$uid."'"));
if($own[0]==1)
{
return true;
}else{
return false;
}
}
function announcementboss($uid)
{
$own = mysql_fetch_array(mysql_query("SELECT announcementpbyhira FROM ibwff_users WHERE id='".$uid."'"));
if($own[0]==1)
{
return true;
}else{
return false;
}
}
function settingboss($uid)
{
$own = mysql_fetch_array(mysql_query("SELECT settingpbyhira FROM ibwff_users WHERE id='".$uid."'"));
if($own[0]==1)
{
return true;
}else{
return false;
}
}
function instructionboss($uid)
{
$own = mysql_fetch_array(mysql_query("SELECT instructionpbyhira FROM ibwff_users WHERE id='".$uid."'"));
if($own[0]==1)
{
return true;
}else{
return false;
}
}
function smiliesboss($uid)
{
$own = mysql_fetch_array(mysql_query("SELECT smiliespbyhira FROM ibwff_users WHERE id='".$uid."'"));
if($own[0]==1)
{
return true;
}else{
return false;
}
}
function blocksiteboss($uid)
{
$own = mysql_fetch_array(mysql_query("SELECT blocksitepbyhira FROM ibwff_users WHERE id='".$uid."'"));
if($own[0]==1)
{
return true;
}else{
return false;
}
}
function bedregboss($uid)
{
$own = mysql_fetch_array(mysql_query("SELECT bedregpbyhira FROM ibwff_users WHERE id='".$uid."'"));
if($own[0]==1)
{
return true;
}else{
return false;
}
}
function badnickboss($uid)
{
$own = mysql_fetch_array(mysql_query("SELECT badnickpbyhira FROM ibwff_users WHERE id='".$uid."'"));
if($own[0]==1)
{
return true;
}else{
return false;
}
}
function cleardataboss($uid)
{
$own = mysql_fetch_array(mysql_query("SELECT cleardatapbyhira FROM ibwff_users WHERE id='".$uid."'"));
if($own[0]==1)
{
return true;
}else{
return false;
}
}
function pm2allboss($uid)
{
$own = mysql_fetch_array(mysql_query("SELECT pm2allpbyhira FROM ibwff_users WHERE id='".$uid."'"));
if($own[0]==1)
{
return true;
}else{
return false;
}
}
function hirasuperboss($uid)
{
$own = mysql_fetch_array(mysql_query("SELECT superpbyhira FROM ibwff_users WHERE id='".$uid."'"));
if($own[0]==1)
{
return true;
}else{
return false;
}
}
function pointboss($uid)
{
$own = mysql_fetch_array(mysql_query("SELECT pointpbyuday FROM ibwff_users WHERE id='".$uid."'"));
if($own[0]==1)
{
return true;
}else{
return false;
}
}
function blncboss($uid)
{
$own = mysql_fetch_array(mysql_query("SELECT balancepbyuday FROM ibwff_users WHERE id='".$uid."'"));
if($own[0]==1)
{
return true;
}else{
return false;
}
}
function gpboss($uid)
{
$own = mysql_fetch_array(mysql_query("SELECT gppbyuday FROM ibwff_users WHERE id='".$uid."'"));
if($own[0]==1)
{
return true;
}else{
return false;
}
}
function gcboss($uid)
{
$own = mysql_fetch_array(mysql_query("SELECT gcpbyuday FROM ibwff_users WHERE id='".$uid."'"));
if($own[0]==1)
{
return true;
}else{
return false;
}
}
function wrboss($uid)
{
$own = mysql_fetch_array(mysql_query("SELECT wrpbyuday FROM ibwff_users WHERE id='".$uid."'"));
if($own[0]==1)
{
return true;
}else{
return false;
}
}
function clubboss($uid)
{
$own = mysql_fetch_array(mysql_query("SELECT clubpbyhira FROM ibwff_users WHERE id='".$uid."'"));
if($own[0]==1)
{
return true;
}else{
return false;
}
}
function rewardboss($uid)
{
$own = mysql_fetch_array(mysql_query("SELECT rewardpbyhira FROM ibwff_users WHERE id='".$uid."'"));
if($own[0]==1)
{
return true;
}else{
return false;
}
}
function deacboss($uid)
{
$own = mysql_fetch_array(mysql_query("SELECT depbyuday FROM ibwff_users WHERE id='".$uid."'"));
if($own[0]==1)
{
return true;
}else{
return false;
}
}
function shieldboss($uid)
{
$own = mysql_fetch_array(mysql_query("SELECT sdpbyuday FROM ibwff_users WHERE id='".$uid."'"));
if($own[0]==1)
{
return true;
}else{
return false;
}
}
function pmboss($uid)
{
$own = mysql_fetch_array(mysql_query("SELECT pmpbyuday FROM ibwff_users WHERE id='".$uid."'"));
if($own[0]==1)
{
return true;
}else{
return false;
}
}
function addpboss($uid)
{
$own = mysql_fetch_array(mysql_query("SELECT addpbyhira FROM ibwff_users WHERE id='".$uid."'"));
if($own[0]==1)
{
return true;
}else{
return false;
}
}
function editpboss($uid)
{
$own = mysql_fetch_array(mysql_query("SELECT editpbyhira FROM ibwff_users WHERE id='".$uid."'"));
if($own[0]==1)
{
return true;
}else{
return false;
}
}
function vippboss($uid)
{
$own = mysql_fetch_array(mysql_query("SELECT vippbyhira FROM ibwff_users WHERE id='".$uid."'"));
if($own[0]==1)
{
return true;
}else{
return false;
}
}
//////////=> This All Super Bosses Pow3r Added by CJ UdaY :p :p
function swearing($str)
{
$str = str_replace(" ","",$str);
$sites[0] = ".n3t";
for($i=0;$i<count($sites);$i++)
{
$str = strtolower($str);
$nosf = substr_count($str,$sites[$i]);
if($nosf>0)
{
return true;
}
}
return false;
}
///////////////////////////////////Parse bbcodes Updated By CJ UdaY :)

function getbbcode($text, $sid="", $filtered)
{
$text = htmlspecialchars($text);
$text=preg_replace("/\[red\](.*?)\[\/red\]/i","<font color=\"red\">\\1</font>", $text);
$text=preg_replace("/\[white\](.*?)\[\/white\]/i","<font color=\"white\">\\1</font>", $text);
$text=preg_replace("/\[lime\](.*?)\[\/lime\]/i","<font color=\"lime\">\\1</font>", $text);
$text=preg_replace("/\[green\](.*?)\[\/green\]/i","<font color=\"green\">\\1</font>", $text);
$text=preg_replace("/\[yellow\](.*?)\[\/yellow\]/i","<font color=\"yellow\">\\1</font>", $text);
$text=preg_replace("/\[white\](.*?)\[\/white\]/i","<font color=\"white\">\\1</font>", $text);
$text=preg_replace("/\[blue\](.*?)\[\/blue\]/i","<font color=\"blue\">\\1</font>", $text);
$text=preg_replace("/\[black\](.*?)\[\/black\]/i","<font color=\"black\">\\1</font>", $text);
$text=preg_replace("/\[teal\](.*?)\[\/teal\]/i","<font color=\"teal\">\\1</font>", $text);
$text=preg_replace("/\[deepskyblue\](.*?)\[\/deepskybluel\]/i","<font color=\"deepskyteal\">\\1</font>", $text);
$text=preg_replace("/\[orangered\](.*?)\[\/orangered\]/i","<font color=\"orangered\">\\1</font>", $text);
$text=preg_replace("/\[grey\](.*?)\[\/grey\]/i","<font color=\"grey\">\\1</font>", $text);
$text=preg_replace("/\[silver\](.*?)\[\/silver\]/i","<font color=\"silver\">\\1</font>", $text);
$text=preg_replace("/\[navy\](.*?)\[\/navy\]/i","<font color=\"navy\">\\1</font>", $text);
$text=preg_replace("/\[litegreen\](.*?)\[\/litegreen\]/i","<font color=\"litegreen\">\\1</font>", $text);
$text=preg_replace("/\[darkgreen\](.*?)\[\/darkgreen\]/i","<font color=\"darkgreen\">\\1</font>", $text);
$text=preg_replace("/\[lightgreen\](.*?)\[\/lightgreen\]/i","<font color=\"lightgreen\">\\1</font>", $text);
$text=preg_replace("/\[palegreen\](.*?)\[\/palegreen\]/i","<font color=\"palegreen\">\\1</font>", $text);
$text=preg_replace("/\[lightseagreen\](.*?)\[\/lightseagreen\]/i","<font color=\"lightseagreen\">\\1</font>", $text);
$text=preg_replace("/\[mediumturquiose\](.*?)\[\/mediumturquiose\]/i","<font color=\"mediumturquiose\">\\1</font>", $text);
$text=preg_replace("/\[aqua\](.*?)\[\/aqua\]/i","<font color=\"aqua\">\\1</font>", $text);
$text=preg_replace("/\[aquamarine\](.*?)\[\/aquamarine\]/i","<font color=\"aquamarine\">\\1</font>", $text);
$text=preg_replace("/\[maroon\](.*?)\[\/maroon\]/i","<font color=\"maroon\">\\1</font>", $text);
$text=preg_replace("/\[purple\](.*?)\[\/purple\]/i","<font color=\"purple\">\\1</font>", $text);
$text=preg_replace("/\[skyteal\](.*?)\[\/skyteal\]/i","<font color=\"skyteal\">\\1</font>", $text);
$text=preg_replace("/\[darkseagreen\](.*?)\[\/darkseagreen\]/i","<font color=\"darkseagreen\">\\1</font>", $text);
$text=preg_replace("/\[yellowgreen\](.*?)\[\/yellowgreen\]/i","<font color=\"yellowgreen\">\\1</font>", $text);
$text=preg_replace("/\[sienna\](.*?)\[\/sienna\]/i","<font color=\"sienna\">\\1</font>", $text);
$text=preg_replace("/\[greenyellow\](.*?)\[\/greenyellow\]/i","<font color=\"greenyellow\">\\1</font>", $text);
$text=preg_replace("/\[powderteal\](.*?)\[\/powderteal\]/i","<font color=\"powderteal\">\\1</font>", $text);
$text=preg_replace("/\[tan\](.*?)\[\/tan\]/i","<font color=\"tan\">\\1</font>", $text);
$text=preg_replace("/\[thistle\](.*?)\[\/thistle\]/i","<font color=\"thistle\">\\1</font>", $text);
$text=preg_replace("/\[orchid\](.*?)\[\/orchid\]/i","<font color=\"orchid\">\\1</font>", $text);
$text=preg_replace("/\[goldenrod\](.*?)\[\/goldenrod\]/i","<font color=\"goldenrod\">\\1</font>", $text);
$text=preg_replace("/\[crimson\](.*?)\[\/crimson\]/i","<font color=\"crimson\">\\1</font>", $text);
$text=preg_replace("/\[plum\](.*?)\[\/plum\]/i","<font color=\"plum\">\\1</font>", $text);
$text=preg_replace("/\[lightcyan\](.*?)\[\/lightcyan\]/i","<font color=\"lightcyan\">\\1</font>", $text);
$text=preg_replace("/\[deeppink\](.*?)\[\/deeppink\]/i","<font color=\"deeppink\">\\1</font>", $text);
$text=preg_replace("/\[violet\](.*?)\[\/violet\]/i","<font color=\"violet\">\\1</font>", $text);
$text=preg_replace("/\[khaki\](.*?)\[\/khaki\]/i","<font color=\"khaki\">\\1</font>", $text);
$text=preg_replace("/\[magenta\](.*?)\[\/magenta\]/i","<font color=\"magenta\">\\1</font>", $text);
$text=preg_replace("/\[hotpink\](.*?)\[\/hotpink\]/i","<font color=\"hotpink\">\\1</font>", $text);
$text=preg_replace("/\[orange\](.*?)\[\/orange\]/i","<font color=\"orange\">\\1</font>", $text);

/////////////////////////By hira :)
$text=preg_replace("/\[b\](.*?)\[\/b\]/i","<b>\\1</b>", $text);
$text=preg_replace("/\[code\](.*?)\[\/code\]/i","<input name=\"bbcode\" value=\"\\1\"/>", $text);
$text=preg_replace("/\[i\](.*?)\[\/i\]/i","<i>\\1</i>", $text);
$text=preg_replace("/\[u\](.*?)\[\/u\]/i","<u>\\1</u>", $text);
$text=preg_replace("/\[big\](.*?)\[\/big\]/i","<big>\\1</big>", $text);
$text=preg_replace("/\[small\](.*?)\[\/small\]/i","<small>\\1</small>", $text);
$text=preg_replace("/\[blink\](.*?)\[\/blink\]/i","<blink>\\1</blink>", $text);
$text=preg_replace("/\[del\](.*?)\[\/del\]/i","<del>\\1</del>", $text);
$text=preg_replace("/\[center\](.*?)\[\/center\]/i","<p align=\"center\">\\1</p>", $text);
$text=preg_replace("/\[left\](.*?)\[\/left\]/i","<p align=\"left\">\\1</p>", $text);
$text=preg_replace("/\[right\](.*?)\[\/right\]/i","<p align=\"right\">\\1</p>", $text);
$text = preg_replace("/\[topic\=(.*?)\](.*?)\[\/topic\]/is","<a class=\"plain\" href=\"forums.php?tid=$1\">$2</a>",$text);
$text = preg_replace("/\[notice\](.*?)\[\/notice\]/i","<a class=\"plain\" href=\"announcements.php?action=notice\">$1</a>",$text);
$text = preg_replace("/\[contest\](.*?)\[\/contest\]/i","<a class=\"plain\" href=\"announcements.php?action=contest\">$1</a>",$text);
$text = preg_replace("/\[lnkad\](.*?)\[\/lnkad\]/i","<a class=\"plain\" href=\"announcements.php?action=linkads\">$1</a>",$text);
$text = preg_replace("/\[ramdan\](.*?)\[\/ramdan\]/i","<a class=\"plain\" href=\"ramdan.php\">$1</a>",$text);
$text = preg_replace("/\[instractions\](.*?)\[\/instractions\]/i","<a class=\"plain\" href=\"annoucements.php?action=ins\">$1</a>",$text);
$text = preg_replace("/\[likemem\](.*?)\[\/likemem\]/i","<a class=\"plain\" href=\"profile.php?who=$uid\">$1</a>",$text);
$text = preg_replace("/\[pflike\=(.*?)\](.*?)\[\/pflike\]/is","<a class=\"plain\" href=\"profile.php?action=pflikers&id=$1\">$2</a>",$text);
$text = preg_replace("/\[profilepic\=(.*?)\](.*?)\[\/profilepic\]/is","<a class=\"plain\" href=\"profilepic.php?who=$1\">$2</a>",$text);
$text = preg_replace("/\[profilepicture\=(.*?)\](.*?)\[\/profilepicture\]/is","<a class=\"plain\" href=\"profilepic.php?id=$1\">$2</a>",$text);
$text = preg_replace("/\[pfpiclike\=(.*?)\](.*?)\[\/pfpiclike\]/is","<a class=\"plain\" href=\"pfpiclike.php?id=$1\">$2</a>",$text);
$text = preg_replace("/\[pfpicdislike\=(.*?)\](.*?)\[\/pfpicdislike\]/is","<a class=\"plain\" href=\"pfpicdislike.php?id=$1\">$2</a>",$text);
$text = preg_replace("/\[coverphoto\=(.*?)\](.*?)\[\/coverphoto\]/is","<a class=\"plain\" href=\"coverphoto.php?id=$1\">$2</a>",$text);
$text = preg_replace("/\[cvphotolike\=(.*?)\](.*?)\[\/cvphotolike\]/is","<a class=\"plain\" href=\"coverphotolike.php?id=$1\">$2</a>",$text);
$text = preg_replace("/\[cvphotodislike\=(.*?)\](.*?)\[\/cvphotodislike\]/is","<a class=\"plain\" href=\"coverphotodislike.php?id=$1\">$2</a>",$text);
$text = preg_replace("/\[literature\=(.*?)\](.*?)\[\/literature\]/is","<a class=\"plain\" href=\"literature.php?tid=$1\">$2</a>",$text);
$text = preg_replace("/\[statuscom\=(.*?)\](.*?)\[\/statuscom\]/is","<a class=\"plain\" href=\"scomments.php?statusid=$1\">$2</a>",$text);
$text = preg_replace("/\[mindstatus\=(.*?)\](.*?)\[\/mindstatus\]/is","<a class=\"plain\" href=\"scomments.php?statusid=$1\">$2</a>",$text);
$text = preg_replace("/\[statuslik\=(.*?)\](.*?)\[\/statuslik\]/is","<a class=\"plain\" href=\"statuslike.php?statusid=$1\">$2</a>",$text);
$text = preg_replace("/\[statusdislik\=(.*?)\](.*?)\[\/statusdislik\]/is","<a class=\"plain\" href=\"statusdislike.php?statusid=$1\">$2</a>",$text);
$text = preg_replace("/\[shoutcom\=(.*?)\](.*?)\[\/shoutcom\]/is","<a class=\"plain\" href=\"shcomments.php?shid=$1\">$2</a>",$text);
$text = preg_replace("/\[shout\=(.*?)\](.*?)\[\/shout\]/is","<a class=\"plain\" href=\"shcomments.php?shid=$1\">$2</a>",$text);
$text = preg_replace("/\[sphoto\=(.*?)\]/is","<img src=\"$1\" alt=\"$1\"/>",$text);
$text = preg_replace("/\[shoutlik\=(.*?)\](.*?)\[\/shoutlik\]/is","<a class=\"plain\" href=\"like.php?shid=$1\">$2</a>",$text);
$text = preg_replace("/\[shoutdislik\=(.*?)\](.*?)\[\/shoutdislik\]/is","<a class=\"plain\" href=\"dislike.php?shid=$1\">$2</a>",$text);
$text = preg_replace("/\[club\=(.*?)\](.*?)\[\/club\]/is","<a class=\"plain\" href=\"clubs.php?action=gocl&clid=$1\">$2</a>",$text);
$text = preg_replace("/\[blog\=(.*?)\](.*?)\[\/blog\]/is","<a class=\"plain\" href=\"blogs.php?bid=$1\">$2</a>",$text);
$text = preg_replace("/\[user\=(.*?)\](.*?)\[\/user\]/is","<a class=\"plain\" href=\"profile.php?who=$1\">$2</a>",$text);
$text = preg_replace("/\[reqaccept\=(.*?)\](.*?)\[\/reqaccept\]/is","<a class=\"plain\" href=\"friendsproc.php?action=add&who=$1\">$2</a>",$text);
$text = preg_replace("/\[reqdecline\=(.*?)\](.*?)\[\/reqdecline\]/is","<a class=\"plain\" href=\"friendsproc.php?action=del&who=$1\">$2</a>",$text);
$text = preg_replace("/\[gcmembers\](.*?)\[\/gcmembers\]/i","<a class=\"plain\" href=\"profile.php?who=$lstall[1]\">$1</a>",$text);
$text = preg_replace("/\[poll\=(.*?)\](.*?)\[\/poll\]/is","<a class=\"plain\" href=\"polls.php?pid=$1\">$2</a>",$text);
$text = preg_replace("/\[gb\=(.*?)\](.*?)\[\/gb\]/is","<a class=\"plain\" href=\"gbook.php?who=$1\">$2</a>",$text);
$text = preg_replace("/\[guestbook\=(.*?)\](.*?)\[\/guestbook\]/is","<a class=\"plain\" href=\"gbook.php?who=$1\">$2</a>",$text);
$text = preg_replace("/\[color\=(.*?)\](.*?)\[\/color\]/is","<font color=\"$1\">$2</font>",$text);
$text = preg_replace("/\[page\=(.*?)\](.*?)\[\/page\]/is","<a class=\"plain\" href=\"$1\">$2</a>",$text);
$uid = getuid_sid($sid);
$text = str_replace("/view","<a href=\"profile.php?who=$uid\"><b>".getnick_uid($uid)."</b></a>",$text); 
$text = str_replace("@view","<a href=\"profile.php?who=$uid\"><b>".getnick_uid($uid)."</b></a>",$text); 
$uid = getuid_sid($sid);
$text = str_replace("@allmember@","".getnick_uid($uid)."",$text); 
$text = str_replace("@ALLMEMBER@","".getnick_uid($uid)."",$text); 

////////////////////Spamming And Slaging Security By CJ UdaY :)
$text = str_replace("sexy","****",$text);
$text = str_replace("boob","****",$text); 
$text = str_replace("kutta","****",$text); 
$text = str_replace("januar","****",$text); 
$text = str_replace("peacefulbd","****",$text); 
$text = str_replace("chatbookbd","****",$text);
$text = str_replace("www","****",$text); 
$text = str_replace(".com","****",$text); 
$text = str_replace(".tk","****",$text); 
$text = str_replace(".wapka","****",$text); 
$text = str_replace(".mobi","****",$text); 
$text = str_replace("tufanbd","****",$text); 
$text = str_replace("friendsdiary","****",$text); 
$text = str_replace("onibbd","****",$text); 
$text = str_replace("proudbd","****",$text); 
$text = str_replace("bondhujogot","****",$text); 
$text = str_replace("bondhunir","****",$text); 
$text = str_replace("bondhuadda","****",$text); 
$text = str_replace("dostibd","****",$text); 
$text = str_replace("rosebd","****",$text); 
$text = str_replace("myg4x","****",$text); 
$text = str_replace("netbondhu","****",$text); 
$text = str_replace("dhakawap","****",$text); 
$text = str_replace("aponworld","****",$text); 
$text = str_replace("mothercod","****",$text); 
$text = str_replace("motherchod","****",$text);
$text = str_replace("fuck","****",$text); 
$text = str_replace("magi","****",$text); 
$text = str_replace("baccha","****",$text); 
$text = str_replace("khanki","****",$text); 
if(substr_count($text,"[br/]")<=10000){
$text = str_replace("[br/]","<br/>",$text);
}
$text = getsmilies($text);
if($filtered=="1"){
if(swearing($text))
{
$text = strtolower($text);
$text = str_replace(".n3t",".....net",$text);
}
}
return $text;
}
//////////////////////////////////////////////////MISC FUNCTIONS
function spacesin($word)
{
$pos = strpos($word," ");
if($pos === false)
{
return false;
}else{
return true;
}
}
function regmemcount()
{
$rmc = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users"));
return $rmc[0];
}
function addvisitor()
{
$cc = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='Counter'"));
$cc = $cc[0]+1;
$res = mysql_query("UPDATE ibwff_settings SET value='".$cc."' WHERE name='Counter'");
}
function scharin($word)
{
$chars = "abcdefghijklmnopqrstuvwxyz0123456789'-_";
for($i=0;$i<strlen($word);$i++)
{
$ch = substr($word,$i,1);
$nol = substr_count($chars,$ch);
if($nol==0)
{
return true;
}
}
return false;
}
function isdigitf($word)
{
$chars = "abcdefghijklmnopqrstuvwxyz কখগঘঙচছজঝঞটঠডড়ঢণতথদধনপফবভমযয়রলশষসহৎযঅআইঈউঊঋএঐওঔািীুূৃেৈোৌ";
$ch = substr($word,0,1);
$sres = ereg("[0-9]",$ch);
$ch = substr($word,0,1);
$nol = substr_count($chars,$ch);
if($nol==0)
{
return true;
}
return false;
}
///////////////////////////////////Unread Notifications Codes By CJ UdaY :)
function getunreadnt($uid)
{
    $nopm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_notifications WHERE touid='".$uid."' AND unread='1'"));
    return $nopm[0];
}
///////////////////////////////////Notifications Codes By CJ UdaY :)
function getreadnt($uid)
{
    $nopm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_notifications WHERE touid='".$uid."' AND unread='0'"));
    return $nopm[0];
}
///////////////////////////////////Notifications Codes By CJ UdaY :)
function notify($msg,$who)
{
mysql_query("INSERT INTO ibwff_notifications SET text='".$msg."', touid='".$who."', unread='1', timesent='".time()."', sub='1'");
}
function adminnot($msg)
{
$uday = mysql_query("SELECT id FROM ibwff_users WHERE cyberpowereragon='4'");
while($cj = mysql_fetch_array($uday)){
 mysql_query("INSERT INTO ibwff_notifications SET text='".$msg."', touid='".$cj[0]."', unread='1', timesent='".time()."', sub='1'");
}
}
///////////////////////////////////Notifications Codes By CJ UdaY :)
function notification($uid)
{
    $nopm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_notifications WHERE touid='".$uid."' AND unread='1'"));
    return $nopm[0];
}
///////////////////////////////////Notifications Codes By CJ UdaY :)
function notification2($uid)
{
    $nopm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_notifications WHERE touid='".$uid."'"));
    return $nopm[0];
}
//Relative Functions By CJ UdaY :-)
function getonrels($uid)
{
$counter+=0;
$relss = mysql_query("SELECT uid, tid FROM ibwf_relatives WHERE (uid='".$uid."' OR tid='".$uid."') AND valid='1'");
while($rel=mysql_fetch_array($rels))
{
if($rel[0]==$uid)
{
$tid = $rel[1];
}else{
$tid = $rel[0];
}
if(isonline($tid))
{
$counter++;
}
}
return $counter;
}
function getnrels($uid)
{
$a = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_relatives WHERE ((uid='".$uid."') OR (tid='".$uid."')) AND agreed='1'"));
return $a[0];
}

////////////////////////////////////////////Parse PM

////anti spam

function parsepm($text, $sid="")
{
$text = getbbcode($text, $sid, 1);
return $text;
}
////////////////////////////////////////////Parse other msgs
function parsemsg($text,$sid="")
{
$text = getbbcode($text, $sid, 1);
return $text;
}

/////////////////////////////////////// Update All Functions By CJ UDAY :)
function updateall($uid)
{
$brws = $_SERVER['HTTP_USER_AGENT'];
$shbr = explode("/",$_SERVER['HTTP_USER_AGENT']);
$shbr = $shbr[0];
$ubrw = addslashes(strip_tags($shbr));
$fmtemp = $_SERVER['HTTP_USER_AGENT'];
$okletsgo = OS($fmtemp);
$brws2 = explode("/",$_SERVER['HTTP_USER_AGENT']);
$ubr = $brws2[0];
$brws22 = browser_agent($_SERVER['HTTP_USER_AGENT']);
$ubr = addslashes(strip_tags($brws22));
$ipadd = getip();
$res = mysql_query("UPDATE
ibwff_users SET original='$ubr', browserm='$ubrw', osmafia='$okletsgo', ipadd='$ipadd' WHERE id='".$uid."'");
}
function
error_access_programmer($idn,$super_sec)
{
if($idn==1 && $super_sec!="power_programmer_login")
{
echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<div class=\"header\" align=\"center\">";
echo "Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<br/><b>Password Did Not Found!</b><br/><br/>";
echo "&#187; <a href=\"forgot.php\">Forgot
Password??</a>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a
href=\"main.php\">Menu</a></p>";
include("footer.php");
echo "</div>";
echo "</body>";
exit();
}
}
function isblocked($str,$sender)
{
if(ismod($sender))
{
return false;
}
$str = str_replace(" ","",$str);
$str = strtolower($str);
$res = mysql_query("SELECT site
FROM ibwff_blockedsite");
while ($row = mysql_fetch_array
($res))
{
$sites[] = $row[0];
}
for($i=0;$i<count($sites);$i++)
{
$nosf = substr_count($str,$sites
[$i]);
if($nosf>0)
{
return true;
}
}
return false;
}
//topic rate :-)
function gettpcrate($uid, $tid)
{
$tid = $_GET["tid"];
$x = mysql_fetch_array(mysql_query("SELECT rate FROM uday_tpcrate WHERE uid='".$uid."' AND tid='".$tid."'"));
if($x[0]==0)
{
return "<img src=\"../avatars/half-star.gif\" alt=\"*\">";
}else if($x[0]==1)
{
return "<img src=\"../avatars/1-star.gif\" alt=\"*\">";
}else if($x[0]==2)
{
return "<img src=\"../avatars/2-star.gif\" alt=\"*\">";
}else if($x[0]==3)
{
return "<img src=\"../avatars/3-star.gif\" alt=\"*\">";
}else if($x[0]==4)
{
return "<img src=\"../avatars/4-star.gif\" alt=\"*\">";
}else if($x[0]==5)
{
return "<img src=\"../avatars/5-star.gif\" alt=\"*\">";
}else{
return "<img src=\"../avatars/5-star.gif\" alt=\"*\">";
}
break;
}
function getblgrate($uid, $bid)
{
$bid = $_GET["bid"];
$x = mysql_fetch_array(mysql_query("SELECT rate FROM uday_blgrate WHERE uid='".$uid."' AND tid='".$bid."'"));
if($x[0]==0)
{
return "<img src=\"../avatars/half-star.gif\" alt=\"*\">";
}else if($x[0]==1)
{
return "<img src=\"../avatars/1-star.gif\" alt=\"*\">";
}else if($x[0]==2)
{
return "<img src=\"../avatars/2-star.gif\" alt=\"*\">";
}else if($x[0]==3)
{
return "<img src=\"../avatars/3-star.gif\" alt=\"*\">";
}else if($x[0]==4)
{
return "<img src=\"../avatars/4-star.gif\" alt=\"*\">";
}else if($x[0]==5)
{
return "<img src=\"../avatars/5-star.gif\" alt=\"*\">";
}else{
return "<img src=\"../avatars/5-star.gif\" alt=\"*\">";
}
break;
}
function getlitrate($uid, $tid)
{
$tid = $_GET["tid"];
$x = mysql_fetch_array(mysql_query("SELECT rate FROM uday_litrate WHERE uid='".$uid."' AND tid='".$tid."'"));
if($x[0]==0)
{
return "<img src=\"../avatars/half-star.gif\" alt=\"*\">";
}else if($x[0]==1)
{
return "<img src=\"../avatars/1-star.gif\" alt=\"*\">";
}else if($x[0]==2)
{
return "<img src=\"../avatars/2-star.gif\" alt=\"*\">";
}else if($x[0]==3)
{
return "<img src=\"../avatars/3-star.gif\" alt=\"*\">";
}else if($x[0]==4)
{
return "<img src=\"../avatars/4-star.gif\" alt=\"*\">";
}else if($x[0]==5)
{
return "<img src=\"../avatars/5-star.gif\" alt=\"*\">";
}else{
return "<img src=\"../avatars/5-star.gif\" alt=\"*\">";
}
break;
}
function littyp_tid($tid)
{
$u = mysql_fetch_array(mysql_query("SELECT fid FROM ibwff_storys WHERE id='".$tid."'"));
$d = mysql_fetch_array(mysql_query("SELECT cid FROM ibwff_literatures WHERE id='".$u[0]."'"));
$a = mysql_fetch_array(mysql_query("SELECT name FROM ibwff_letcats WHERE id='".$d[0]."'"));
return $a[0];
}
function littyp_fid($fid)
{
$u = mysql_fetch_array(mysql_query("SELECT cid FROM ibwff_literatures WHERE id='".$fid."'"));
$d = mysql_fetch_array(mysql_query("SELECT name FROM ibwff_letcats WHERE id='".$u[0]."'"));
return $d[0];
}
function litnot_uday($tid,$msg)
{
$tid = $_GET["tid"];
$tm = time();
$mem = mysql_query("SELECT uid FROM uday_sublit WHERE tid='".$tid."'");
while($flw = mysql_fetch_array($mem))
{
mysql_query("INSERT INTO ibwff_notifications SET text='".$msg."', byuid='3', touid='".$flw[0]."', timesent='".$tm."', sub='1'");
}
}
function getlfname($fid)
{
$uday = mysql_fetch_array(mysql_query("SELECT name FROM ibwff_literatures WHERE id='".$fid."'"));
return $uday[0];
}
function tpcvld_uday($tid)
{
$uday = mysql_fetch_array(mysql_query("SELECT uday_vld FROM ibwff_topics WHERE id='".$tid."'"));
if($uday[0]>0)
{
return true;
}else{
return false;
}
break;
}
function litcatval_uday($tid)
{
$uday = mysql_fetch_array(mysql_query("SELECT validate FROM ibwff_literatures WHERE id='".$tid."'"));
if($uday[0]>0)
{
return true;
}else{
return false;
}
break;
}
function fmtval($fid)
{
$uday = mysql_fetch_array(mysql_query("SELECT validate FROM ibwff_forums WHERE id='".$fid."'"));
if($uday[0]>0)
{
return true;
}else{
return false;
}
break;
}
function litval($tid)
{
$uday = mysql_fetch_array(mysql_query("SELECT validate FROM ibwff_storys WHERE id='".$tid."'"));
if($uday[0]>0)
{
return true;
}else{
return false;
}
break;
}
function blogtval($bid)
{
$uday = mysql_fetch_array(mysql_query("SELECT validate FROM ibwff_blogs WHERE id='".$bid."'"));
if($uday[0]>0)
{
return true;
}else{
return false;
}
break;
}
function polltval($tid)
{
$uday = mysql_fetch_array(mysql_query("SELECT validate FROM ibwff_polls WHERE id='".$tid."'"));
if($uday[0]>0)
{
return true;
}else{
return false;
}
break;
}
function poll_uday()
{
$uday = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='poll_uday'"));
return $uday[0];
}
function pollc_uday()
{
$uday = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='pollc_uday'"));
return $uday[0];
}
function junvip()
{
$uday = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='junvip_uday'"));
return $uday[0];
}
function senvip()
{
$uday = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='senvip_uday'"));
return $uday[0];
}
function udaypu($who)
{
$uday = mysql_fetch_array(mysql_query("SELECT pu FROM ibwff_users WHERE id='".$who."'"));
if($uday[0]>0)
{
return true;
}else{
return false;
}
break;
}
function getcvid_name($name)
{
$f = getcoverpic($who);
$g = "../coverpics/$f";
$uday = mysql_fetch_array(mysql_query("SELECT id FROM ibwff_gallery WHERE itemurl='".$g."'"));
return $uday[0];
}
function getpfid_name($name)
{
$f = getavatar($who);
$g = "../avatars/$f";
$uday = mysql_fetch_array(mysql_query("SELECT id FROM ibwff_gallery WHERE itemurl='".$g."'"));
return $uday[0];
}
function getunvalcl_uday($clid)
{
$fid = mysql_fetch_array(mysql_query("SELECT id FROM ibwff_forums WHERE clubid='".$clid."'"));
$tpc = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_topics WHERE fid='".$fid[0]."' AND uday_vld='0'"));
$lfid = mysql_fetch_array(mysql_query("SELECT id FROM ibwff_literatures WHERE clubid='".$clid."'"));
$lit = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_storys WHERE fid='".$lfid[0]."' AND validate='0'"));
$blg = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_blogs WHERE clubid='".$clid."' AND validate='0'"));
$pol = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_polls WHERE clubid='".$clid."' AND validate='0'"));
$uday = $tpc[0] + $lit[0] + $blg[0] + $pol[0];
return $uday;
}
/////////////////////////////////////////////Are rels by CJ Uday?
function arerels($uid,$tid)
{
$res = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_relatives WHERE ((uid='".$uid."' AND tid='".$tid."') OR (uid='".$tid."' AND tid='".$uid."')) AND agreed='1'"));
if($res[0]>0)
{
return true;
}
return false;
}
function relres($uid, $tid)
{
if($uid==$tid)
{
return 3;
}
if(arerels($uid, $tid))
{
return 2;
}
$req = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_relatives WHERE ((uid='".$uid."' AND tid='".$tid."') OR (uid='".$tid."' AND tid='".$uid."')) AND agreed='0'"));
if($req[0]>0)
{
return 1;
}
$notb = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_relatives WHERE (uid='".$tid."' OR tid='".$tid."') AND agreed='1'"));
$max_buds = 50;
if($notb[0]>=$max_buds)
{
return 3;
}
$notb = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_relatives WHERE (uid='".$uid."' OR tid='".$uid."') AND agreed='1'"));
$max_buds = 50;
if($notb[0]>=$max_buds)
{
return 3;
}
return 0;
}
function vld_uday()
{
$u = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE validated='0'"));
$fm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_forums WHERE validate='0'"));
$fm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_literatures WHERE validate='0'"));
$fid = mysql_fetch_array(mysql_query("SELECT id FROM ibwff_forums WHERE clubid='0'"));
$f = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_forums WHERE validate='0'"));
$tpc = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_topics WHERE fid='".$fid[0]."' AND uday_vld='0'"));
$lfid = mysql_fetch_array(mysql_query("SELECT id FROM ibwff_literatures WHERE clubid='0'"));
$lf = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_literatures WHERE uday_vld='0'"));
$lit = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_storys WHERE fid='".$lfid[0]."' AND validate='0'"));
$blg = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_blogs WHERE clubid='0' AND validate='0'"));
$pol = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_polls WHERE clubid='0' AND validate='0'"));
$uday = $u[0] + $fm[0] + $tpc[0] + $lfm[0] + $lit[0] + $blg[0] + $pol[0] + $lf[0] + $f[0];
return $uday;
}
function mlog($action, $msg)
{
mysql_query("INSERT INTO ibwff_mlog SET action='".$action."', details='".$msg."', actdt='".time()."'");
}
function subnot_uday($who, $msg)
{
$who = $_GET["who"];
$tm = time();
$mem = mysql_query("SELECT who FROM uday_subus WHERE uid='".$who."'");
while($flw = mysql_fetch_array($mem))
{
mysql_query("INSERT INTO ibwff_notifications SET text='".$msg."', byuid='3', touid='".$flw[0]."', timesent='".$tm."', sub='1'");
}
}