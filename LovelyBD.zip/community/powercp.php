<?php
session_start();
include("config.php");
include("core.php");  connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo '<head>';
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"title\" content=\"FireBD.NeT\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From Shahos: Don't Try To Hack OR else :P\">
<meta name=\"keywords\" content=\"Site Desined By Shahos :) :)\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/></head>";
echo "<body>";
$action = $_GET["action"]; 
$sid = $_SESSION["sid"];
$page = $_GET["page"];
$who = $_GET["who"];
$uid = getuid_sid($sid);
$name = $_GET["name"];
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();
////////////////Ip Banned By CJ UDAY :)	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
    echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
	echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
      echo "<br/>";
      echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
      $banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
      $remain =  $banto[0] - time();
      $rmsg = gettimemsg($remain);
      echo "<b>Time Remaining: $rmsg</b><br/>";
      $nick = getnick_uid($banto[2]);
       $text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
      echo "</p>";
    	echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
    echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
    echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
//////////////////Banned System Updated By CJ UDAY :)
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please With Contact Us <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
 echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
///////////////////Validation By CJ UDAY :)
					if(isvalidated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
	echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  You Are Not Validated!<br/>We are checking your ip and browser<br/>
	  This could take up to 15 munites pls be patient and try again soon<br/>Please try again later...<br/><b>Thank You</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
///////////////////Deactivated Account By CJ UDAY :)
          if(isdeactivated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  <b>Your Account Has Been Deactivated Forever.<br/>And It Will Be Never Activate!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
if(!hirasuperboss(getuid_sid($sid)))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
  echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
  echo "<br/>Unknown Error!!!<br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">"; 
include("footer.php");
echo "</div>";
  exit();
}
/////////////////////////////////SUPER Tools Upgraded By CJ UDAY :)
if($action=="user")
{
	echo "<head>";
    echo "<title>Super Tools</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
		$unick = subnick(getnick_uid($who));		
echo "<b>Edit $unick's Permissions</b></div>";
    $point = mysql_fetch_array(mysql_query("SELECT pointpbyuday FROM ibwff_users WHERE id='".$who."'"));
	$point = $point[0];
$warn = mysql_fetch_array(mysql_query("SELECT wrpbyuday FROM ibwff_users WHERE id='".$who."'"));
	$warn = $warn[0];     
    $balance = mysql_fetch_array(mysql_query("SELECT balancepbyuday FROM ibwff_users WHERE id='".$who."'"));
	$balance = $balance[0];
$gp = mysql_fetch_array(mysql_query("SELECT gppbyuday FROM ibwff_users WHERE id='".$who."'"));
	$gp = $gp[0];
$gc = mysql_fetch_array(mysql_query("SELECT gcpbyuday FROM ibwff_users WHERE id='".$who."'"));
	$gc = $gc[0];
$deac = mysql_fetch_array(mysql_query("SELECT depbyuday FROM ibwff_users WHERE id='".$who."'"));
	$deac = $deac[0];
$shld = mysql_fetch_array(mysql_query("SELECT sdpbyuday FROM ibwff_users WHERE id='".$who."'"));
	$shld = $shld[0];
$boot = mysql_fetch_array(mysql_query("SELECT bootpbyhira FROM ibwff_users WHERE id='".$who."'"));
	$boot = $boot[0];
	$ban = mysql_fetch_array(mysql_query("SELECT banpbyhira FROM ibwff_users WHERE id='".$who."'"));
	$ban = $ban[0];
	$ipban = mysql_fetch_array(mysql_query("SELECT ipbanpbyhira FROM ibwff_users WHERE id='".$who."'"));
	$ipban = $ipban[0];
	$pm = mysql_fetch_array(mysql_query("SELECT pmpbyuday FROM ibwff_users WHERE id='".$who."'"));
	$pm = $pm[0];
	$profile = mysql_fetch_array(mysql_query("SELECT profilepbyhira FROM ibwff_users WHERE id='".$who."'"));
	$profile = $profile[0];
	$read = mysql_fetch_array(mysql_query("SELECT readpbyhira FROM ibwff_users WHERE id='".$who."'"));
	$read = $read[0];
	$shout = mysql_fetch_array(mysql_query("SELECT shoutpbyhira FROM ibwff_users WHERE id='".$who."'"));
	$shout = $shout[0];
	$chat = mysql_fetch_array(mysql_query("SELECT chatpbyhira FROM ibwff_users WHERE id='".$who."'"));
	$chat = $chat[0];
	$forum = mysql_fetch_array(mysql_query("SELECT forumpbyhira FROM ibwff_users WHERE id='".$who."'"));
	$forum = $forum[0];
	$literature = mysql_fetch_array(mysql_query("SELECT literaturepbyhira FROM ibwff_users WHERE id='".$who."'"));
	$literature = $literature[0];
	$blog = mysql_fetch_array(mysql_query("SELECT blogpbyhira FROM ibwff_users WHERE id='".$who."'"));
	$blog = $blog[0];
	$poll = mysql_fetch_array(mysql_query("SELECT pollpbyhira FROM ibwff_users WHERE id='".$who."'"));
	$poll = $poll[0];
	$gallery = mysql_fetch_array(mysql_query("SELECT gallerypbyhira FROM ibwff_users WHERE id='".$who."'"));
	$gallery = $gallery[0];
	$announcement = mysql_fetch_array(mysql_query("SELECT announcementpbyhira FROM ibwff_users WHERE id='".$who."'"));
	$announcement = $announcement[0];
	$setting = mysql_fetch_array(mysql_query("SELECT settingpbyhira FROM ibwff_users WHERE id='".$who."'"));
	$setting = $setting[0];
	$instruction = mysql_fetch_array(mysql_query("SELECT instructionpbyhira FROM ibwff_users WHERE id='".$who."'"));
	$instruction = $instruction[0];
	$smilies = mysql_fetch_array(mysql_query("SELECT smiliespbyhira FROM ibwff_users WHERE id='".$who."'"));
	$smilies = $smilies[0];
	$blocksite = mysql_fetch_array(mysql_query("SELECT blocksitepbyhira FROM ibwff_users WHERE id='".$who."'"));
	$blocksite = $blocksite[0];
	$bedreg = mysql_fetch_array(mysql_query("SELECT bedregpbyhira FROM ibwff_users WHERE id='".$who."'"));
	$bedreg = $bedreg[0];
	$badnick = mysql_fetch_array(mysql_query("SELECT badnickpbyhira FROM ibwff_users WHERE id='".$who."'"));
	$badnick = $badnick[0];
	$cleardata = mysql_fetch_array(mysql_query("SELECT cleardatapbyhira FROM ibwff_users WHERE id='".$who."'"));
	$cleardata = $cleardata[0];
	$pm2all = mysql_fetch_array(mysql_query("SELECT pm2allpbyhira FROM ibwff_users WHERE id='".$who."'"));
	$pm2all = $pm2all[0];
	$super = mysql_fetch_array(mysql_query("SELECT superpbyhira FROM ibwff_users WHERE id='".$who."'"));
	$super = $super[0];
	$club = mysql_fetch_array(mysql_query("SELECT clubpbyhira FROM ibwff_users WHERE id='".$who."'"));
	$club = $club[0];
	$reward = mysql_fetch_array(mysql_query("SELECT rewardpbyhira FROM ibwff_users WHERE id='".$who."'"));
	$reward = $reward[0];
	$addp = mysql_fetch_array(mysql_query("SELECT addpbyhira FROM ibwff_users WHERE id='".$who."'"));
	$addp = $addp[0];
	$editp = mysql_fetch_array(mysql_query("SELECT editpbyhira FROM ibwff_users WHERE id='".$who."'"));
	$editp = $editp[0];
	$vipp = mysql_fetch_array(mysql_query("SELECT vippbyhira FROM ibwff_users WHERE id='".$who."'"));
	$vipp = $vipp[0];
echo "<onevent type=\"onenterforward\">";
echo "<refresh>";
echo "
         <setvar name=\"point\" value=\"$point\"/>
         <setvar name=\"warn\" value=\"$warn\"/>
         <setvar name=\"balance\" value=\"$balance\"/>
         <setvar name=\"gp\" value=\"$gp\"/>
         <setvar name=\"gc\" value=\"$gc\"/> 
         <setvar name=\"deac\" value=\"$deac\"/>  
         <setvar name=\"shld\" value=\"$shld\"/>       
         <setvar name=\"boot\" value=\"$boot\"/>
         <setvar name=\"ban\" value=\"$ban\"/>
         <setvar name=\"ipban\" value=\"$ipban\"/>
         <setvar name=\"pm\" value=\"$pm\"/>
         <setvar name=\"profile\" value=\"$profile\"/>
         <setvar name=\"read\" value=\"$read\"/>
         <setvar name=\"shout\" value=\"$shout\"/>
         <setvar name=\"chat\" value=\"$chat\"/>
         <setvar name=\"forum\" value=\"$forum\"/>
         <setvar name=\"literature\" value=\"$literature\"/>
         <setvar name=\"blog\" value=\"$blog\"/>
         <setvar name=\"poll\" value=\"$poll\"/>
         <setvar name=\"gallery\" value=\"$gallery\"/>
         <setvar name=\"announcement\" value=\"$announcement\"/>
         <setvar name=\"setting\" value=\"$setting\"/>
         <setvar name=\"instruction\" value=\"$instruction\"/>
         <setvar name=\"smilies\" value=\"$smilies\"/>
         <setvar name=\"blocksite\" value=\"$blocksite\"/>
         <setvar name=\"bedreg\" value=\"$bedreg\"/>
         <setvar name=\"badnick\" value=\"$badnick\"/>
         <setvar name=\"cleardata\" value=\"$cleardata\"/>
         <setvar name=\"pm2all\" value=\"$pm2all\"/>
         <setvar name=\"super\" value=\"$super\"/>
         <setvar name=\"club\" value=\"$club\"/>
         <setvar name=\"reward\" value=\"$reward\"/>
         <setvar name=\"addp\" value=\"$addp\"/>
         <setvar name=\"editp\" value=\"$editp\"/>
         <setvar name=\"vipp\" value=\"$vipp\"/>
   ";
  echo "</refresh></onevent>";
  echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
    echo "<p><form action=\"powercp.php?action=usp&who=$who\" method=\"post\">";
	switch ($point)
	{
	case "1";
	echo "Point Power: <font color=\"green\"><b>Permited</b></font><br/>";
	break;
	default: 
	echo "Point Power: <font color=\"red\"><b>Not Permited</b></font><br/>";
	break;
	}
    echo " <select name=\"point\" value=\"$point\">";
    echo "<option value=\"1\">Yes</option>";
    echo "<option value=\"0\">No</option>";
    echo "</select><br/>";
switch ($warn)
	{
	case "1";
	echo "Warning Power: <font color=\"green\"><b>Permited</b></font><br/>";
	break;
	default: 
	echo "Warning Power: <font color=\"red\"><b>Not Permited</b></font><br/>";
	break;
	}
    echo " <select name=\"wr\" value=\"$warn\">";
    echo "<option value=\"1\">Yes</option>";
    echo "<option value=\"0\">No</option>";
    echo "</select><br/>";
	switch ($balance)
	{
	case "1";
	echo "Balance Power: <font color=\"green\"><b>Permited</b></font><br/>";
	break;
	default: 
	echo "Balance Power: <font color=\"red\"><b>Not Permited</b></font><br/>";
	break;
	}
    echo " <select name=\"balance\" value=\"$balance\">";
    echo "<option value=\"1\">Yes</option>";
    echo "<option value=\"0\">No</option>";
    echo "</select><br/>";
switch ($gp)
	{
	case "1";
	echo "Game Point Power: <font color=\"green\"><b>Permited</b></font><br/>";
	break;
	default: 
	echo "Game Point Power: <font color=\"red\"><b>Not Permited</b></font><br/>";
	break;
	}
    echo " <select name=\"gp\" value=\"$gc\">";
    echo "<option value=\"1\">Yes</option>";
    echo "<option value=\"0\">No</option>";
    echo "</select><br/>";
switch ($gc)
	{
	case "1";
	echo "Golden Coin Power: <font color=\"green\"><b>Permited</b></font><br/>";
	break;
	default: 
	echo "Golden Coin Power: <font color=\"red\"><b>Not Permited</b></font><br/>";
	break;
	}
    echo " <select name=\"gc\" value=\"$gc\">";
    echo "<option value=\"1\">Yes</option>";
    echo "<option value=\"0\">No</option>";
    echo "</select><br/>";
switch ($deac)
	{
	case "1";
	echo "Deactivate Power: <font color=\"green\"><b>Permited</b></font><br/>";
	break;
	default: 
	echo "Deactivate Power: <font color=\"red\"><b>Not Permited</b></font><br/>";
	break;
	}
    echo " <select name=\"deac\" value=\"$deac\">";
    echo "<option value=\"1\">Yes</option>";
    echo "<option value=\"0\">No</option>";
    echo "</select><br/>";
	switch ($shld)
	{
	case "1";
	echo "Shield Power: <font color=\"green\"><b>Permited</b></font><br/>";
	break;
	default: 
	echo "Shield Power: <font color=\"red\"><b>Not Permited</b></font><br/>";
	break;
	}
    echo " <select name=\"shld\" value=\"$shld\">";
    echo "<option value=\"1\">Yes</option>";
    echo "<option value=\"0\">No</option>";
    echo "</select><br/>";
switch ($boot)
	{
	case "1";
	echo "Boot/unboot Power: <font color=\"green\"><b>Permited</b></font><br/>";
	break;
	default: 
	echo "Boot/unboot Power: <font color=\"red\"><b>Not Permited</b></font><br/>";
	break;
	}
    echo " <select name=\"boot\" value=\"$boot\">";
    echo "<option value=\"1\">Yes</option>";
    echo "<option value=\"0\">No</option>";
    echo "</select><br/>";
	switch ($ban)
	{
	case "1";
	echo "Ban/Unban Power: <font color=\"green\"><b>Permited</b></font><br/>";
	break;
	default: 
	echo "Ban/Unban Power: <font color=\"red\"><b>Not Permited</b></font><br/>";
	break;
	}
	echo "<select name=\"ban\" value=\"$ban\">";
    echo "<option value=\"1\">Yes</option>";
    echo "<option value=\"0\">No</option>";
    echo "</select><br/>";
	switch ($ipban)
	{
	case "1";
	echo "IpBan/IpUnban Power: <font color=\"green\"><b>Permited</b></font><br/>";
	break;
	default: 
	echo "IpBan/IpUnban Power: <font color=\"red\"><b>Not Permited</b></font><br/>";
	break;
	}
	echo " <select name=\"ipban\" value=\"$ipban\">";
    echo "<option value=\"1\">Yes</option>";
    echo "<option value=\"0\">No</option>";
    echo "</select><br/>";
	switch ($pm)
	{
	case "1";
	echo "Pm Ban/Unban Power: <font color=\"green\"><b>Permited</b></font><br/>";
	break;
	default: 
	echo "Pm Ban/Unban Power: <font color=\"red\"><b>Not Permited</b></font><br/>";
	break;
	}
	echo " <select name=\"pm\" value=\"$pm\">";
    echo "<option value=\"1\">Yes</option>";
    echo "<option value=\"0\">No</option>";
    echo "</select><br/>";
	switch ($profile)
	{
	case "1";
	echo "Profile Edit Power: <font color=\"green\"><b>Permited</b></font><br/>";
	break;
	default: 
	echo "Profile Edit Power: <font color=\"red\"><b>Not Permited</b></font><br/>";
	break;
	}
	echo " <select name=\"profile\" value=\"$profile\">";
    echo "<option value=\"1\">Yes</option>";
    echo "<option value=\"0\">No</option>";
    echo "</select><br/>";
	switch ($read)
	{
	case "1";
	echo "User Read Power: <font color=\"green\"><b>Permited</b></font><br/>";
	break;
	default: 
	echo "User Read Power: <font color=\"red\"><b>Not Permited</b></font><br/>";
	break;
	}
	echo " <select name=\"read\" value=\"$read\">";
    echo "<option value=\"1\">Yes</option>";
    echo "<option value=\"0\">No</option>";
    echo "</select><br/>";
		switch ($shout)
	{
	case "1";
	echo "Shout Power: <font color=\"green\"><b>Permited</b></font><br/>";
	break;
	default: 
	echo "Shout Power: <font color=\"red\"><b>Not Permited</b></font><br/>";
	break;
	}
	echo " <select name=\"shout\" value=\"$shout\">";
    echo "<option value=\"1\">Yes</option>";
    echo "<option value=\"0\">No</option>";
    echo "</select><br/>";
	switch ($chat)
	{
	case "1";
	echo "Chat Power: <font color=\"green\"><b>Permited</b></font><br/>";
	break;
	default: 
	echo "Chat Power: <font color=\"red\"><b>Not Permited</b></font><br/>";
	break;
	}
    echo " <select name=\"chat\" value=\"$chat\">";
    echo "<option value=\"1\">Yes</option>";
    echo "<option value=\"0\">No</option>";
    echo "</select><br/>";
	switch ($forum)
	{
	case "1";
	echo "Forum Power: <font color=\"green\"><b>Permited</b></font><br/>";
	break;
	default: 
	echo "Forum Power: <font color=\"red\"><b>Not Permited</b></font><br/>";
	break;
	}
	echo " <select name=\"forum\" value=\"$forum\">";
    echo "<option value=\"1\">Yes</option>";
    echo "<option value=\"0\">No</option>";
    echo "</select><br/>";
	switch ($literature)
	{
	case "1";
	echo "Literature Power: <font color=\"green\"><b>Permited</b></font><br/>";
	break;
	default: 
	echo "Literature Power: <font color=\"red\"><b>Not Permited</b></font><br/>";
	break;
	}
	echo " <select name=\"literature\" value=\"$literature\">";
    echo "<option value=\"1\">Yes</option>";
    echo "<option value=\"0\">No</option>";
    echo "</select><br/>";
	switch ($blog)
	{
	case "1";
	echo "Blog Power: <font color=\"green\"><b>Permited</b></font><br/>";
	break;
	default: 
	echo "Blog Power: <font color=\"red\"><b>Not Permited</b></font><br/>";
	break;
	}
	echo " <select name=\"blog\" value=\"$blog\">";
    echo "<option value=\"1\">Yes</option>";
    echo "<option value=\"0\">No</option>";
    echo "</select><br/>";
	switch ($poll)
	{
	case "1";
	echo "Poll Power: <font color=\"green\"><b>Permited</b></font><br/>";
	break;
	default: 
	echo "Poll Power: <font color=\"red\"><b>Not Permited</b></font><br/>";
	break;
	}
	echo " <select name=\"poll\" value=\"$poll\">";
    echo "<option value=\"1\">Yes</option>";
    echo "<option value=\"0\">No</option>";
    echo "</select><br/>";
	switch ($gallery)
	{
	case "1";
	echo "Gallery Power: <font color=\"green\"><b>Permited</b></font><br/>";
	break;
	default: 
	echo "Gallery Power: <font color=\"red\"><b>Not Permited</b></font><br/>";
	break;
	}
	echo " <select name=\"gallery\" value=\"$gallery\">";
    echo "<option value=\"1\">Yes</option>";
    echo "<option value=\"0\">No</option>";
    echo "</select><br/>";
	switch ($announcement)
	{
	case "1";
	echo "Announcement Power: <font color=\"green\"><b>Permited</b></font><br/>";
	break;
	default: 
	echo "Announcement Power: <font color=\"red\"><b>Not Permited</b></font><br/>";
	break;
	}
	echo " <select name=\"announcement\" value=\"$announcement\">";
    echo "<option value=\"1\">Yes</option>";
    echo "<option value=\"0\">No</option>";
    echo "</select><br/>";
	switch ($setting)
	{
	case "1";
	echo "Setting Power: <font color=\"green\"><b>Permited</b></font><br/>";
	break;
	default: 
	echo "Setting Power: <font color=\"red\"><b>Not Permited</b></font><br/>";
	break;
	}
	echo " <select name=\"setting\" value=\"$setting\">";
    echo "<option value=\"1\">Yes</option>";
    echo "<option value=\"0\">No</option>";
    echo "</select><br/>";
	switch ($instruction)
	{
	case "1";
	echo "Instruction Power: <font color=\"green\"><b>Permited</b></font><br/>";
	break;
	default: 
	echo "Instruction Power: <font color=\"red\"><b>Not Permited</b></font><br/>";
	break;
	}
	echo " <select name=\"instruction\" value=\"$instruction\">";
    echo "<option value=\"1\">Yes</option>";
    echo "<option value=\"0\">No</option>";
    echo "</select><br/>";
	switch ($smilies)
	{
	case "1";
	echo "Smilies Power: <font color=\"green\"><b>Permited</b></font><br/>";
	break;
	default: 
	echo "Smilies Power: <font color=\"red\"><b>Not Permited</b></font><br/>";
	break;
	}
	echo " <select name=\"smilies\" value=\"$smilies\">";
    echo "<option value=\"1\">Yes</option>";
    echo "<option value=\"0\">No</option>";
    echo "</select><br/>";
	switch ($blocksite)
	{
	case "1";
	echo "Blocksite Power: <font color=\"green\"><b>Permited</b></font><br/>";
	break;
	default: 
	echo "Blocksite Power: <font color=\"red\"><b>Not Permited</b></font><br/>";
	break;
	}
	echo " <select name=\"blocksite\" value=\"$blocksite\">";
    echo "<option value=\"1\">Yes</option>";
    echo "<option value=\"0\">No</option>";
    echo "</select><br/>";
	switch ($bedreg)
	{
	case "1";
	echo "Bad Register Power: <font color=\"green\"><b>Permited</b></font><br/>";
	break;
	default: 
	echo "Bad Register Power: <font color=\"red\"><b>Not Permited</b></font><br/>";
	break;
	}
	echo " <select name=\"bedreg\" value=\"$bedreg\">";
    echo "<option value=\"1\">Yes</option>";
    echo "<option value=\"0\">No</option>";
    echo "</select><br/>";
	switch ($badnick)
	{
	case "1";
	echo "Bad Nick Power: <font color=\"green\"><b>Permited</b></font><br/>";
	break;
	default: 
	echo "Bad Nick Power: <font color=\"red\"><b>Not Permited</b></font><br/>";
	break;
	}
	echo " <select name=\"badnick\" value=\"$badnick\">";
    echo "<option value=\"1\">Yes</option>";
    echo "<option value=\"0\">No</option>";
    echo "</select><br/>";
	switch ($cleardata)
	{
	case "1";
	echo "Cleardata Power: <font color=\"green\"><b>Permited</b></font><br/>";
	break;
	default: 
	echo "Cleardata Power: <font color=\"red\"><b>Not Permited</b></font><br/>";
	break;
	}
	echo " <select name=\"cleardata\" value=\"$cleardata\">";
    echo "<option value=\"1\">Yes</option>";
    echo "<option value=\"0\">No</option>";
    echo "</select><br/>";
	switch ($pm2all)
	{
	case "1";
	echo "Pm2All Power: <font color=\"green\"><b>Permited</b></font><br/>";
	break;
	default: 
	echo "Pm2All Power: <font color=\"red\"><b>Not Permited</b></font><br/>";
	break;
	}
	echo " <select name=\"pm2all\" value=\"$pm2all\">";
    echo "<option value=\"1\">Yes</option>";
    echo "<option value=\"0\">No</option>";
    echo "</select><br/>";
	switch ($super)
	{
	case "1";
	echo "Super Power: <font color=\"green\"><b>Permited</b></font><br/>";
	break;
	default: 
	echo "Super Power: <font color=\"red\"><b>Not Permited</b></font><br/>";
	break;
	}
	echo " <select name=\"super\" value=\"$super\">";
    echo "<option value=\"1\">Yes</option>";
    echo "<option value=\"0\">No</option>";
    echo "</select><br/>";
	switch ($club)
	{
	case "1";
	echo "Club Power: <font color=\"green\"><b>Permited</b></font><br/>";
	break;
	default: 
	echo "Club Power: <font color=\"red\"><b>Not Permited</b></font><br/>";
	break;
	}
	echo " <select name=\"club\" value=\"$club\">";
    echo "<option value=\"1\">Yes</option>";
    echo "<option value=\"0\">No</option>";
    echo "</select><br/>";
	switch ($reward)
	{
	case "1";
	echo "Reward2All Power: <font color=\"green\"><b>Permited</b></font><br/>";
	break;
	default: 
	echo "Reward2All Power: <font color=\"red\"><b>Not Permited</b></font><br/>";
	break;
	}
	echo " <select name=\"reward\" value=\"$reward\">";
    echo "<option value=\"1\">Yes</option>";
    echo "<option value=\"0\">No</option>";
    echo "</select><br/>";
	switch ($addp)
	{
	case "1";
	echo "Power Add Power: <font color=\"green\"><b>Permited</b></font><br/>";
	break;
	default: 
	echo "Power Add Power: <font color=\"red\"><b>Not Permited</b></font><br/>";
	break;
	}
	echo " <select name=\"addp\" value=\"$addp\">";
    echo "<option value=\"1\">Yes</option>";
    echo "<option value=\"0\">No</option>";
    echo "</select><br/>";
	switch ($editp)
	{
	case "1";
	echo "Power Edit Power: <font color=\"green\"><b>Permited</b></font><br/>";
	break;
	default: 
	echo "Power Edit Power: <font color=\"red\"><b>Not Permited</b></font><br/>";
	break;
	}
	echo " <select name=\"editp\" value=\"$editp\">";
    echo "<option value=\"1\">Yes</option>";
    echo "<option value=\"0\">No</option>";
    echo "</select><br/>";
	switch ($vipp)
	{
	case "1";
	echo "ViP Power: <font color=\"green\"><b>Permited</b></font><br/>";
	break;
	default: 
	echo "ViP Edit Power: <font color=\"red\"><b>Not Permited</b></font><br/>";
	break;
	}
	echo " <select name=\"vipp\" value=\"$vipp\">";
    echo "<option value=\"1\">Yes</option>";
    echo "<option value=\"0\">No</option>";
    echo "</select><br/>";
    echo "<input type=\"submit\" value=\"Set Power\"/></form>";
   echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
}
else if($action=="usp")
{
$who = $_GET["who"];
$point = $_POST["point"];
$wr = $_POST["wr"];
$balance = $_POST["balance"];
$gp = $_POST["gp"];
$gc = $_POST["gc"];
$deac = $_POST["deac"];
$sd = $_POST["shld"];
  $boot = $_POST["boot"];
  $ban = $_POST["ban"];
  $ipban = $_POST["ipban"];
$pm = $_POST["pm"];
  $profile = $_POST["profile"];
  $read = $_POST["read"];
  $shout = $_POST["shout"];
  $chat = $_POST["chat"];
  $forum = $_POST["forum"];
  $literature = $_POST["literature"];
  $blog = $_POST["blog"];
  $gallery = $_POST["gallery"];
  $announcement = $_POST["announcement"];
  $setting = $_POST["setting"];
  $instruction = $_POST["instruction"];
  $smilies = $_POST["smilies"];
  $blocksite = $_POST["blocksite"];
  $bedreg = $_POST["bedreg"];
  $badnick = $_POST["badnick"];
  $cleardata = $_POST["cleardata"];
  $pm2all = $_POST["pm2all"];
  $super = $_POST["super"];
  $club = $_POST["club"];
  $reward = $_POST["reward"];
  $addp = $_POST["addp"];
  $editp = $_POST["editp"];
  $vipp = $_POST["vipp"];
  $user = subnick(getnick_uid($who));
  	echo "<head>";
    echo "<title>Update Super Tools</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
		$unick = subnick(getnick_uid($who));					
echo "<b>Super Power Of $unick</b></div>";
							echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$pointres = mysql_query("UPDATE ibwff_users SET pointpbyuday='".$point."' WHERE id='".$who."'");
$wrnres = mysql_query("UPDATE ibwff_users SET wrpbyuday='".$wr."' WHERE id='".$who."'");
$blncres = mysql_query("UPDATE ibwff_users SET balancepbyuday='".$balance."' WHERE id='".$who."'");
$gpres = mysql_query("UPDATE ibwff_users SET gppbyuday='".$gp."' WHERE id='".$who."'");
$gcres = mysql_query("UPDATE ibwff_users SET gcpbyuday='".$gc."' WHERE id='".$who."'");
$deacres = mysql_query("UPDATE ibwff_users SET depbyuday='".$deac."' WHERE id='".$who."'");
$sdres = mysql_query("UPDATE ibwff_users SET sdpbyuday='".$sd."' WHERE id='".$who."'");
$bootres = mysql_query("UPDATE ibwff_users SET bootpbyhira='".$boot."' WHERE id='".$who."'");
$banres = mysql_query("UPDATE ibwff_users SET banpbyhira='".$ban."' WHERE id='".$who."'");
$ipbanres = mysql_query("UPDATE ibwff_users SET ipbanpbyhira='".$ipban."' WHERE id='".$who."'");
$pmres = mysql_query("UPDATE ibwff_users SET pmpbyuday='".$pm."' WHERE id='".$who."'");
$profileres = mysql_query("UPDATE ibwff_users SET profilepbyhira='".$profile."' WHERE id='".$who."'");
$readres = mysql_query("UPDATE ibwff_users SET readpbyhira='".$read."' WHERE id='".$who."'");
$shoutres = mysql_query("UPDATE ibwff_users SET shoutpbyhira='".$shout."' WHERE id='".$who."'");
$chatres = mysql_query("UPDATE ibwff_users SET chatpbyhira='".$chat."' WHERE id='".$who."'");
$forumres = mysql_query("UPDATE ibwff_users SET forumpbyhira='".$forum."' WHERE id='".$who."'");
$literatureres = mysql_query("UPDATE ibwff_users SET literaturepbyhira='".$literature."' WHERE id='".$who."'");
$blogres = mysql_query("UPDATE ibwff_users SET blogpbyhira='".$blog."' WHERE id='".$who."'");
$pollres = mysql_query("UPDATE ibwff_users SET pollpbyhira='".$gallery."' WHERE id='".$who."'");
$galleryres = mysql_query("UPDATE ibwff_users SET gallerypbyhira='".$gallery."' WHERE id='".$who."'");
$announcementres = mysql_query("UPDATE ibwff_users SET announcementpbyhira='".$announcement."' WHERE id='".$who."'");
$settingres = mysql_query("UPDATE ibwff_users SET settingpbyhira='".$setting."' WHERE id='".$who."'");
$instructionres = mysql_query("UPDATE ibwff_users SET instructionpbyhira='".$instruction."' WHERE id='".$who."'");
$smiliesres = mysql_query("UPDATE ibwff_users SET smiliespbyhira='".$smilies."' WHERE id='".$who."'");
$blocksiteres = mysql_query("UPDATE ibwff_users SET blocksitepbyhira='".$blocksite."' WHERE id='".$who."'");
$bedregres = mysql_query("UPDATE ibwff_users SET bedregpbyhira='".$bedreg."' WHERE id='".$who."'");
$badnickres = mysql_query("UPDATE ibwff_users SET badnickpbyhira='".$badnick."' WHERE id='".$who."'");
$cleardatares = mysql_query("UPDATE ibwff_users SET cleardatapbyhira='".$cleardata."' WHERE id='".$who."'");
$pm2allres = mysql_query("UPDATE ibwff_users SET pm2allpbyhira='".$pm2all."' WHERE id='".$who."'");
$superres = mysql_query("UPDATE ibwff_users SET superpbyhira='".$super."' WHERE id='".$who."'");
$clubres = mysql_query("UPDATE ibwff_users SET clubpbyhira='".$club."' WHERE id='".$who."'");
$rewardres = mysql_query("UPDATE ibwff_users SET rewardpbyhira='".$reward."' WHERE id='".$who."'");
$addpres = mysql_query("UPDATE ibwff_users SET addpbyhira='".$editp."' WHERE id='".$who."'");
$editpres = mysql_query("UPDATE ibwff_users SET editpbyhira='".$addp."' WHERE id='".$who."'");
$vippres = mysql_query("UPDATE ibwff_users SET vippbyhira='".$vipp."' WHERE id='".$who."'");
 if($pointres)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"o\"/>$unick's Point Power  Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>Error updating $unick's Point Power! <br/>"; 
}
 if($wrnres)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"o\"/>$unick's Warning Power  Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>Error updating $unick's Warning Power! <br/>"; 
}
 if($blncres)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"o\">$unick's Balance Power Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"x\">Error updating $unick's Balance Power! <br/>";
  }
 if($gpres)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"o\">$unick's Game Point Power Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>Error updating $unick's Game Point Power! <br/>";
  }
 if($gcres)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"o\"/>$unick's Golden Coin Power Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>Error updating $unick's Golden Coin Power! <br/>";
  }
if($deacres)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"o\"/>$unick's Deactivate Power  Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>Error updating $unick's Deactivate Power! <br/>"; 
}
if($sdres)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"o\"/>$unick's Shield Power  Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>Error updating $unick's Shield Power! <br/>"; 
}
 if($bootres)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"o\"/>$unick's Boot Power Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>Error updating $unick's Boot Power! <br/>";
  }
 if($banres)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"o\"/>$unick's Ban Power  Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>Error updating $unick's Ban Power! <br/>";
  }
  if($ipbanres)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"o\"/>$unick's IpBan Power  Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>Error updating $unick's IpBan Power! <br/>";
  }
if($pmres)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"o\"/>$unick's Pm ban Power  Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>Error updating $unick's Pm ban Power! <br/>";
  }
  if($profileres)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"o\"/>$unick's Profile edit Power  Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>Error updating $unick's Profile edit Power! <br/>";
  }
  if($readres)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"o\"/>$unick's Read User Power  Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>Error updating $unick's Read User Power! <br/>";
  }
  if($shoutres)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"o\"/>$unick's Shout Power  Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>Error updating $unick's Shout Power! <br/>";
  }
  if($chatres)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"o\"/>$unick's Chat Power  Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>Error updating $unick's Chat Power! <br/>";
  }
  if($forumres)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"o\"/>$unick's Forum Power  Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>Error updating $unick's Forum Power! <br/>";
  }
  if($literatureres)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"o\"/>$unick's Liturature Power  Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>Error updating $unick's Liturature Power! <br/>";
  }
  if($blogres)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"o\"/>$unick's Blog Power  Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>Error updating $unick's Blog Power! <br/>";
  }
  if($pollres)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"o\"/>$unick's Poll Power  Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>Error updating $unick's Poll Power! <br/>";
  }
  if($galleryres)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"o\"/>$unick's Gallery Power  Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>Error updating $unick's Gallery Power! <br/>";
  }
  if($announcementres)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"o\"/>$unick's Announcement Power  Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>Error updating $unick's Announcement Power! <br/>";
  }
  if($settingres)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"o\"/>$unick's Settings Power  Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>Error updating $unick's Settings Power! <br/>";
  }
  if($instructionres)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"o\"/>$unick's Instruction Power  Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>Error updating $unick's Instruction Power! <br/>";
  }
  if($smiliesres)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"o\"/>$unick's Smilies Power  Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>Error updating $unick's Smilies Power! <br/>";
  }
  if($blocksiteres)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"o\"/>$unick's Block Site edit Power  Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>Error updating $unick's Block Site edit Power! <br/>";
  }
  if($bedregres)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"o\"/>$unick's Bad Register Power  Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>Error updating $unick's Bad Register Power! <br/>";
  }
  if($badnickres)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"o\"/>$unick's Bad Nick Power Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>Error updating $unick's Bad Nick Power! <br/>";
  }
  if($cleardatares)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"o\"/>$unick's Data Clear Power  Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>Error updating $unick's Data Clear Power! <br/>";
  }
  if($pm2allres)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"o\"/>$unick's Pm2All Power  Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>Error updating $unick's Pm2All Power! <br/>";
  }
  if($superres)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"o\"/>$unick's Super Power  Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>Error updating $unick's Super Power! <br/>";
  }
  if($clubres)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"o\"/>$unick's Club Power  Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>Error updating $unick's Club Power! <br/>";
  }
  if($rewardres)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"o\"/>$unick's Rewerd2all Power  Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>Error updating $unick's Rewerd2all Power! <br/>";
  }
  if($addpres)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"o\"/>$unick's Power Add Power  Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>Error updating $unick's Power Add Power! <br/>";
  }
  if($editpres)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"o\"/>$unick's Power Edit Power  Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>Error updating $unick's Power Edit Power! <br/>";
  }
  if($vippres)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"o\"/>$unick's ViP Power  Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>Error updating $unick's ViP Power! <br/>";
  }
 echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";  
  }
?>
</html>