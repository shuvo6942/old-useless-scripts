<?php
session_start();
include("config.php");
include("core.php");  connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo '<head>';
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"title\" content=\"FireBD.NeT\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From Shahos: Don't Try To Hack OR else :P\">
<meta name=\"keywords\" content=\"Site Desined By Shahos :) :)\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/></head>";
echo "<body>";
$action = $_GET["action"]; 
$sid = $_SESSION["sid"];
$who = $_GET["who"];
$uid = getuid_sid($sid);
$name = $_GET["name"];
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();
////////////////Ip Banned By CJ UDAY :)	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
    echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
	echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
      echo "<br/>";
      echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
      $banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
      $remain =  $banto[0] - time();
      $rmsg = gettimemsg($remain);
      echo "<b>Time Remaining: $rmsg</b><br/>";
      $nick = getnick_uid($banto[2]);
       $text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
      echo "</p>";
    	echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
    echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
    echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
//////////////////Banned System Updated By CJ UDAY :)
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please With Contact Us <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
 echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
///////////////////Validation By CJ UDAY :)
					if(isvalidated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
	echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  You Are Not Validated!<br/>We are checking your ip and browser<br/>
	  This could take up to 15 munites pls be patient and try again soon<br/>Please try again later...<br/><b>Thank You</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }

///////////////////Deactivated Account By CJ UDAY :)
          if(isdeactivated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  <b>Your Account Has Been Deactivated Forever.<br/>And It Will Be Never Activate!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="vallit")
  {
$lfid = $_GET["fid"];
addonline(getuid_sid($sid),"Validating Article Catagory","literature.php?action=Lite");
	echo "<head>";
    echo "<title>Validate Article Catagory</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<b>Validate Article Catagory</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
if(!literatureboss($uid))
{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> You are not permitted to validate article catagories!<br/>";
}else{
$lcname = mysql_fetch_array(mysql_query("SELECT name FROM ibwff_letcats WHERE id='".$lfid."'"));
$uday = mysql_query("UPDATE ibwff_literatures SET validate='1' WHERE id='".$lfid."'");
if($uday)
{
$lcname = mysql_fetch_array(mysql_query("SELECT name FROM ibwff_letcats WHERE id='".$lfid."'"));
echo "<img src=\"../images/ok.gif\" alt=\"O\"> Article catagory <b>$lcname[0]</b> validated successfully!<br/>";
$validater = getnick_sid($sid);
$text = "[b]".$lcname[0]."[/b] Article catagory is validated by [b]".$validater."[/b]";
adminnot($text);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> Article catagory <b>$lcname[0]</b> cannot be validated at this moment!<br/>";
}
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="valart")
  {
$ltid = $_GET["tid"];
addonline(getuid_sid($sid),"Validating Article","literature.php?action=Lite");
	echo "<head>";
    echo "<title>Validate Article</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<b>Validate Article</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$lname = mysql_fetch_array(mysql_query("SELECT name FROM ibwff_storys WHERE id='".$ltid."'"));
$uday = mysql_query("UPDATE ibwff_storys SET validate='1' WHERE id='".$ltid."'");
if($uday)
{
$lname = mysql_fetch_array(mysql_query("SELECT name FROM ibwff_storys WHERE id='".$ltid."'"));
echo "<img src=\"../images/ok.gif\" alt=\"O\"> Article <b>$lname[0]</b> validated successfully!<br/>";
$validater = getnick_sid($sid);
$owner = mysql_fetch_array(mysql_query("SELECT authorid FROM ibwff_storys WHERE id='".$ltid."'"));
$msg = "[b]".$lname[0]."[/b] Article is validated by [b]".$validater."[/b]";
adminnot($msg);
$msg= "Your article [b]".$lname[0]."[/b] is validated by [b]".$validater."[/b]";
notify($msg, $owner[0]);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> Article <b>$lname[0]</b> cannot be validated at this moment!<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="valtpc")
  {
$ltid = $_GET["tid"];
addonline(getuid_sid($sid),"Validating topic","forums.php?action=Forum");
	echo "<head>";
    echo "<title>Validate topic</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<b>Validate Topic</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$lname = mysql_fetch_array(mysql_query("SELECT name FROM ibwff_topics WHERE id='".$ltid."'"));
$uday = mysql_query("UPDATE ibwff_topics SET uday_vld='1' WHERE id='".$ltid."'");
if($uday)
{
$lname = mysql_fetch_array(mysql_query("SELECT name FROM ibwff_topics WHERE id='".$ltid."'"));
echo "<img src=\"../images/ok.gif\" alt=\"O\"> Topic <b>$lname[0]</b> validated successfully!<br/>";
$validater = getnick_sid($sid);
$owner = mysql_fetch_array(mysql_query("SELECT authorid FROM ibwff_topics WHERE id='".$ltid."'"));
$msg = "[b]".$lname[0]."[/b] topic is validated by [b]".$validater."[/b]";
adminnot($msg);
$msg= "Your topic [b]".$lname[0]."[/b] is validated by [b]".$validater."[/b]";
notify($msg, $owner[0]);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> Topic <b>$lname[0]</b> cannot be validated at this moment!<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="valfrm")
  {
$lfid = $_GET["fid"];
addonline(getuid_sid($sid),"Validating Forum Catagory","forums.php?action=Forums");
	echo "<head>";
    echo "<title>Validate Forum Catagory</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<b>Validate Forum Catagory</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
if(!forumboss($uid))
{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> You are not permitted to validate forum catagories!<br/>";
}else{
$lcname = mysql_fetch_array(mysql_query("SELECT name FROM ibwff_forums WHERE id='".$lfid."'"));
$uday = mysql_query("UPDATE ibwff_forums SET validate='1' WHERE id='".$lfid."'");
if($uday)
{
$lcname = mysql_fetch_array(mysql_query("SELECT name FROM ibwff_forums WHERE id='".$lfid."'"));
echo "<img src=\"../images/ok.gif\" alt=\"O\"> Forum catagory <b>$lcname[0]</b> validated successfully!<br/>";
$validater = getnick_sid($sid);
$text = "[b]".$lcname[0]."[/b] forum catagory is validated by [b]".$validater."[/b]";
adminnot($text);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> Forum catagory <b>$lcname[0]</b> cannot be validated at this moment!<br/>";
}
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="blog")
  {
$bid = $_GET["bid"];
addonline(getuid_sid($sid),"Validating Blog","blogs.php?action=allbl");
	echo "<head>";
    echo "<title>Validate Blog</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<b>Validate Blog</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$lname = mysql_fetch_array(mysql_query("SELECT name FROM ibwff_blogs WHERE id='".$bid."'"));
$uday = mysql_query("UPDATE ibwff_blogs SET validate='1' WHERE id='".$bid."'");
if($uday)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> Blog <b>$lname[0]</b> validated successfully!<br/>";
$validater = getnick_sid($sid);
$owner = mysql_fetch_array(mysql_query("SELECT bowner FROM ibwff_blogs WHERE id='".$bid."'"));
$msg = "[b]".$lname[0]."[/b] Blog is validated by [b]".$validater."[/b]";
adminnot($msg);
$msg= "Your blog [b]".$lname[0]."[/b] is validated by [b]".$validater."[/b]";
notify($msg, $owner[0]);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> Blog <b>$lname[0]</b> cannot be validated at this moment!<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="poll")
  {
$bid = $_GET["who"];
addonline(getuid_sid($sid),"Validating Poll","polls.php?action=$action");
	echo "<head>";
    echo "<title>Validate Poll</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<b>Validate Poll</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$lname = mysql_fetch_array(mysql_query("SELECT pqst FROM ibwff_polls WHERE id='".$bid."'"));
$uday = mysql_query("UPDATE ibwff_polls SET validate='1' WHERE id='".$bid."'");
if($uday)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> poll <b>$lname[0]</b> validated successfully!<br/>";
$validater = getnick_sid($sid);
$owner = mysql_fetch_array(mysql_query("SELECT uid FROM ibwff_polls WHERE id='".$bid."'"));
$msg = "[b]".$lname[0]."[/b] poll is validated by [b]".$validater."[/b]";
adminnot($msg);
$msg= "Your poll [b]".$lname[0]."[/b] is validated by [b]".$validater."[/b]";
notify($msg, $owner[0]);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> Poll <b>$lname[0]</b> cannot be validated at this moment!<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="user")
  {
$bid = $_GET["who"];
addonline(getuid_sid($sid),"Validating User","polls.php?action=$action");
	echo "<head>";
    echo "<title>Validate User</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<b>Validate User</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$lname = getnick_uid($bid);
$uday = mysql_query("UPDATE ibwff_users SET validated='1' WHERE id='".$bid."'");
if($uday)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> <b>$lname</b> validated successfully!<br/>";
$validater = getnick_sid($sid);
$msg = "[b]".$lname."[/b] is validated by [b]".$validater."[/b]";
adminnot($msg);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> <b>$lname</b> cannot be validated at this moment!<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="unuser")
  {
$bid = $_GET["who"];
addonline(getuid_sid($sid),"Unvalidating User","polls.php?action=$action");
	echo "<head>";
    echo "<title>Unvalidate User</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<b>Unvalidate User</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$lname = getnick_uid($bid);
$uday = mysql_query("UPDATE ibwff_users SET validated='0' WHERE id='".$bid."'");
if($uday)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> <b>$lname</b> unvalidated successfully!<br/>";
$validater = getnick_sid($sid);
$msg = "[b]".$lname."[/b] is validated by [b]".$validater."[/b]";
adminnot($msg);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> <b>$lname</b> cannot be unvalidated at this moment!<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
?>
</html>