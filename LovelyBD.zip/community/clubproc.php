<?php
session_start();
include("config.php");
include("core.php");  connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo '<head>';
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"title\" content=\"FireBD.NeT\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From CJ UDAY: Don't Try To Hack OR else :P\">
<meta name=\"keywords\" content=\"Site Desined By CJ UDAY :) :)\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/></head>";
echo "<body>";
$action = $_GET["action"]; $sid = $_SESSION["sid"];
$who = $_GET["who"];
$uid = getuid_sid($sid);
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();
////////////////Ip Banned By CJ UDAY :)	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
    echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
	echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
      echo "<br/>";
      echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
      $banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
      $remain =  $banto[0] - time();
      $rmsg = gettimemsg($remain);
      echo "<b>Time Remaining: $rmsg</b><br/>";
      $nick = getnick_uid($banto[2]);
       $text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
      echo "</p>";
    	echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
    echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
    echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
//////////////////Banned System Updated By CJ UDAY :)
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please With Contact Us <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
 echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
///////////////////Validation By CJ UDAY :)
					if(isvalidated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
	echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  You Are Not Validated!<br/>We are checking your ip and browser<br/>
	  This could take up to 15 munites pls be patient and try again soon<br/>Please try again later...<br/><b>Thank You</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }

///////////////////Deactivated Account By CJ UDAY :)
          if(isdeactivated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  <b>Your Account Has Been Deactivated Forever.<br/>And It Will Be Never Activate!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="sub")
{
$clid = $_GET["clid"];
    addonline(getuid_sid($sid),"Subscribing A Club","");
   echo "<head>";
echo "<title>Subscribing Club</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";				
include("header.php");
echo "</div>";  
echo "<div class=\"header\" align=\"center\">";
echo "<b>Subscribing Club</b></div>";
						echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
    $uday = mysql_query("UPDATE ibwff_clubmembers SET subscriber='1' WHERE uid=$uid AND clid=$clid");
if($uday)
{
echo "<img src=\"ok.gif\"> You have successfully subscribed to ".getclubname($clid)." Club!";
}else{
echo "<img src=\"../images/notok.gif\"> Cannot subscribe to ".getclubname($clid)." at this moment!";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
else if($action=="unsub")
{
$clid = $_GET["clid"];
    addonline(getuid_sid($sid),"Unsubscribing A Club","");
   echo "<head>";
echo "<title>Unsubscribing Club</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";				
include("header.php");
echo "</div>";  
echo "<div class=\"header\" align=\"center\">";
echo "<b>Unsubscribing Club</b></div>";
						echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
    $uday = mysql_query("UPDATE ibwff_clubmembers SET subscriber='0' WHERE uid=$uid AND clid=$clid");
if($uday)
{
echo "<img src=\"ok.gif\"> You have successfully unsubscribed from ".getclubname($clid)." Club!";
}else{
echo "<img src=\"../images/notok.gif\"> Cannot unsubscribe from ".getclubname($clid)." at this moment!";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
else if($action=="join")
{
$clid = $_GET["clid"];
    addonline(getuid_sid($sid),"Joining A Club","");
   echo "<head>";
echo "<title>Joining Club</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";				
include("header.php");
echo "</div>";  
echo "<div class=\"header\" align=\"center\">";
echo "<b>Joining Club</b></div>";
						echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$uid = getuid_sid($sid);
$cj = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_clubmembers WHERE uid='".$uid."' AND clid='".$clid."'"));
if($cj[0]==0)
{
    $uday = mysql_query("INSERT INTO ibwff_clubmembers SET uid=".$uid.", clid=".$clid.", points='0', accepted='0' AND joined='".time()."'");
if($uday)
{
echo "<img src=\"ok.gif\"> You have successfully sent a request to join ".getclubname($clid)." Club!";
}else{
echo "<img src=\"../images/notok.gif\"> Cannot send join request to ".getclubname($clid)." at this moment!";
}
}else{
echo "<img src=\"../images/notok.gif\"> You cannot send join request to ".getclubname($clid)." more than once!";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
else if($action=="unjoin")
{
$clid = $_GET["clid"];
    addonline(getuid_sid($sid),"Unjoining A Club","");
   echo "<head>";
echo "<title>Unjoining Club</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";				
include("header.php");
echo "</div>";  
echo "<div class=\"header\" align=\"center\">";
echo "<b>Unjoining Club</b></div>";
						echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$uid = getuid_sid($sid);
$cj = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_clubmembers WHERE uid='".$uid."' AND clid='".$clid."'"));
if($cj[0]==0)
{
    $uday = mysql_query("DELETE FROM ibwff_clubmembers WHERE uid=".$uid.", clid=".$clid."");
if($uday)
{
echo "<img src=\"ok.gif\"> You have successfully unjoin ".getclubname($clid)." Club!";
}else{
echo "<img src=\"../images/notok.gif\"> Cannot unjoin ".getclubname($clid)." at this moment!";
}
}else{
echo "<img src=\"../images/notok.gif\"> You cannot unjoin ".getclubname($clid)."! ";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
else if($action=="addcl")
{
$clnm = trim($_POST["clnm"]);
$clnm = str_replace("$", "", $clnm);
$clds = trim($_POST["clds"]);
$clds = str_replace("$", "", $clds);
$clrl = trim($_POST["clrl"]);
$clrl = str_replace("$", "", $clrl);
    echo "<head>";
    echo "<title>Add A Club</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
						echo "<div class=\"header\" align=\"center\">";
			echo "<b>Add Club</b></div>";
						echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$uid = getuid_sid($sid);
$cows = newclubpoint();
if(getplusses($uid)>=$cows || spu($uid) || ispu($uid) || isvip($uid))
{
$noi = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_clubs WHERE owner='".$uid."'"));
if($noi[0]<1)
{
if(($clnm=="")||($clds=="")||($clrl==""))
{
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Please be sure to fill, Club name, Description and Rules";
}else{
$nmex = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_clubs WHERE name LIKE '".$clnm."'"));
if($nmex[0]>0)
{
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Club Name Already Exist!";
}else{
$res = mysql_query("INSERT INTO ibwff_clubs SET name='".$clnm."', owner='".$uid."', description='".$clds."', rules='".$clrl."', plusses='0', created='".time()."'");
if($res)
{

$ups = getplusses($uid);
if(isvip($uid)){
$ups = $ups-0;
}else if(spu($uid)) {
$ups = $ups-0;
} else if(spu($uid)) {
$ups=$ups-0;
} else {
$ups = $ups-$cows;
}
$ibwf = time()+6*60*60;
$nick = getnick_uid($uid);
mysql_query("insert into ibwff_events (event,time) values ('<b>$nick</b> Create a new club','$ibwf')");
$clid = mysql_fetch_array(mysql_query("SELECT id FROM ibwff_clubs WHERE owner='".$uid."' AND name='".$clnm."'"));
echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Congratulations! you have your own club, your own rules, chatroom!";
mysql_query("INSERT INTO ibwff_clubmembers SET uid='".$uid."', clid='".$clid[0]."', accepted='1', points='200', joined='".time()."', subscriber='1'");
mysql_query("UPDATE ibwff_users SET plusses='".$ups."' WHERE id='".$uid."'");
$fnm = $clnm;
$cnm = $clnm;
mysql_query("INSERT INTO ibwff_forums SET name='".$fnm."', position='0', cid='0', clubid='".$clid[0]."'");
mysql_query("INSERT INTO ibwff_literatures SET name='".$fnm."', position='0', cid='0', clubid='".$clid[0]."'");
mysql_query("INSERT INTO ibwff_rooms SET name='".$cnm."', pass='', static='1', mage='0', chposts='0', cyberpowereragon='0', censord='0', freaky='0', lastmsg='".time()."', clubid='".$clid[0]."'");
}else{
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!!";
}
}
}
}else{
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>You already have a club!";
}
}else{
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>You can't add club!";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
exit();
}
//////////////////////////////////Top clubs By CJ UDAY :)
else if($action=="top")
{
    addonline(getuid_sid($sid),"Viewing Clubs By Popularity Lists","clubproc.php?action=$action");
	    echo "<head>";
    echo "<title>View Clubs By top Lists</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
    echo "<div class=\"header\" align=\"center\">";
	echo "<b>Top Clubs</b></div>";
	echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
    if($page=="" || $page<=0)$page=1;
    $noi = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_clubs"));
    $num_items = $noi[0];
    $items_per_page= 5;
    $num_pages = ceil($num_items/$items_per_page);
    if(($page>$num_pages)&&$page!=1)$page= $num_pages;
    $limit_start = ($page-1)*$items_per_page;
    $sql = "SELECT id, plusses as notl FROM ibwff_clubs GROUP BY id ORDER BY notl DESC LIMIT $limit_start, $items_per_page";
    $items = mysql_query($sql);
    if(mysql_num_rows($items)>0)
    {
    while ($item = mysql_fetch_array($items))
   {
        $clnm = mysql_fetch_array(mysql_query("SELECT name, description,owner FROM ibwff_clubs WHERE id='".$item[0]."'"));
$owner = subnick(getnick_uid($clnm[2]));
$lnk = "<img src=\"../avatars/clubs.gif\"><a href=\"clubs.php?action=gocl&clid=$item[0]\">".htmlspecialchars($clnm[0])."</a>($item[1])<br/> Owned By: <a href=\"profile.php?who=$who\">$owner</a><br/>&#187;<b>Description:</b> ".htmlspecialchars($clnm[1])."<br/>-------<br/>";
      echo $lnk;
    }
    }
    if($page>1)
    {
      $ppage = $page-1;
      echo "<a href=\"clubproc.php?action=$action&amp;page=$ppage\">&#171;-Prev</a> ";
    }
    if($page<$num_pages)
    {
      $npage = $page+1;
      echo "<a href=\"clubproc.php?action=$action&amp;page=$npage\">Next-&#187;</a>";
    }
    if($num_pages>1){
    echo "<br/>Page - $page/$num_pages<br/>";
    }
    if($num_pages>2)
    {
	$rets = "<form action=\"clubproc.php\" method=\"get\">";
        $rets .= "<input name=\"page\" style=\"-wap-input-format: '*N'\" size=\"2\"/>";
        $rets .= "<input type=\"hidden\" name=\"action\" value=\"$action\"/>";
        $rets .= "<input type=\"hidden\" name=\"sid\" value=\"$sid\"/>";
	$rets .= "<input type=\"hidden\" name=\"who\" value=\"$who\"/>";
        $rets .= "<input type=\"submit\" value=\"Go To Page\"/>";
        $rets .= "</form>";
        echo $rets;
    }
    echo "</p>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
exit();
}
//////////////////////////////////New clubs by CJ UDAY :)
else if($action=="new")
{
    addonline(getuid_sid($sid),"Viewing New Clubs Lists","clubproc.php?action=$action");
	    echo "<head>";
    echo "<title>View New Club Lists</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
			echo "<b>New Club</b></div>";
  echo "<div class=\"shout2\" align=\"left\">";
    include("pm_by.php");
    $sql = "SELECT id, name, description, created, owner FROM ibwff_clubs ORDER BY created DESC LIMIT 8";
    $items = mysql_query($sql);
    if(mysql_num_rows($items)>0)
    {
    while ($item = mysql_fetch_array($items))
    {
$lnk = "<img src=\"../avatars/clubs.gif\"> <a href=\"clubs.php?action=gocl&clid=$item[0]\">".htmlspecialchars($item[1])."</a><br/><b>&#187; Owner:</b> <a href=\"profile.php?who=$item[4]\">".subnick(getnick_uid($item[4]))."</a><br/>&#187; <b>Description:</b> ".htmlspecialchars($item[2])."<br/><b>&#187; Created On:</b> ".date("h:i a, d M y", $item[3]+(6*60*60))."<br/><br/>";
      echo $lnk;
    }
    }
    if($page>1)
    {
      $ppage = $page-1;
      echo "<a href=\"clubproc.php?action=$action&amp;page=$ppage\">&#171;-Prev</a> ";
    }
    if($page<$num_pages)
    {
      $npage = $page+1;
      echo "<a href=\"clubproc.php?action=$action&amp;page=$npage\">Next-&#187;</a>";
    }
    echo "<br/>Page - $page/$num_pages<br/>";
    if($num_pages>2)
    {
	$rets = "<form action=\"clubproc.php\" method=\"get\">";
        $rets .= "<input name=\"page\" style=\"-wap-input-format: '*N'\" size=\"2\"/>";
        $rets .= "<input type=\"hidden\" name=\"action\" value=\"$action\"/>";
        $rets .= "<input type=\"hidden\" name=\"sid\" value=\"$sid\"/>";
	$rets .= "<input type=\"hidden\" name=\"who\" value=\"$who\"/>";
        $rets .= "<input type=\"submit\" value=\"Go To Page\"/>";
        $rets .= "</form>";
        echo $rets;
    }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
exit();
}
//////////////////////////////////All clubs by CJ UDAY :)
else if($action=="clubs")
{
    addonline(getuid_sid($sid),"Viewing All Clubs Lists","clubproc.php?action=$action");
	    echo "<head>";
    echo "<title>View New Club Lists</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
			echo "<b>All Club</b></div>";
  echo "<div class=\"shout2\" align=\"left\">";
    include("pm_by.php");
    $sql = "SELECT id, name, description, created, owner FROM ibwff_clubs ORDER BY created DESC LIMIT 8";
    $items = mysql_query($sql);
    if(mysql_num_rows($items)>0)
    {
    while ($item = mysql_fetch_array($items))
    {
$lnk = "<img src=\"../avatars/clubs.gif\"> <a href=\"clubs.php?action=gocl&amp;clid=$item[0]\">".htmlspecialchars($item[1])."</a><br/><b>&#187; Owner:</b> <a href=\"profile.php?who=$item[4]\">".subnick(getnick_uid($item[4]))."</a><br/>&#187; <b>Description:</b> ".htmlspecialchars($item[2])."<br/><b>&#187; Created On:</b> ".date("h:i a, d M y", $item[3]+(6*60*60))."<br/><br/>";
      echo $lnk;
    }
    }
    if($page>1)
    {
      $ppage = $page-1;
      echo "<a href=\"clubproc.php?action=$action&amp;page=$ppage\">&#171;-Prev</a> ";
    }
    if($page<$num_pages)
    {
      $npage = $page+1;
      echo "<a href=\"clubproc.php?action=$action&amp;page=$npage\">Next-&#187;</a>";
    }
    if($num_pages>1){
    echo "<br/>Page - $page/$num_pages<br/>";
    }
    if($num_pages>2)
    {
	$rets = "<form action=\"clubproc.php\" method=\"get\">";
        $rets .= "<input name=\"page\" style=\"-wap-input-format: '*N'\" size=\"2\"/>";
        $rets .= "<input type=\"hidden\" name=\"action\" value=\"$action\"/>";
        $rets .= "<input type=\"hidden\" name=\"sid\" value=\"$sid\"/>";
	$rets .= "<input type=\"hidden\" name=\"who\" value=\"$who\"/>";
        $rets .= "<input type=\"submit\" value=\"Go To Page\"/>";
        $rets .= "</form>";
        echo $rets;
    }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
exit();
}
?>
</html>