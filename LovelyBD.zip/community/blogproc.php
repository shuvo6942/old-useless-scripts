<?php
session_start();
include("config.php");
include("core.php");
connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo "<head>";
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<body><meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG : Don't Try To Hack OR else :P\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"main,all,follow\"/></head>";
echo "<body>";
##L!TURATUR3 C0D3S AR FULLY CR3AT3D & S3CUR3D BY Megh :-)
$action = $_GET["action"]; $sid = $_SESSION["sid"];
$clid = $_GET["clid"]; $page = $_GET["page"];
$who = $_GET["who"];
$uid = getuid_sid($sid);
$sitename = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='sitename'"));
$sitename = $sitename[0];
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
echo "<br/>";
echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
$banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
$remain =  $banto[0] - time();
$rmsg = gettimemsg($remain);
echo "<b>Time Remaining: $rmsg</b><br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "</p>";
echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
echo "<img src=\"../images/user.png\" alt=\"user\"><b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
echo "<img src=\"../images/pass.png\" alt=\"pass\"><b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
$uid = getuid_sid($sid);
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
 echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");  
echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
 echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "<div class=\"div align=\"center\">Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");  
echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please Contact <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(isdeactivated(getuid_sid($sid), $uid))
{
echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<br/><b>Your Account Has Been Deactivated.<br/>And It Will Be Never Activated Again!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
////////////////////////Updated :)
if($action=="addblg")
{
$btitle = $_POST["btitle"];
  $btxt = $_POST["msgtxt"];
$buday = $_POST["udaytag"];
$udayt = $_POST["udayx"];
if(istrashed(getuid_sid($sid)))
  {
	echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
  echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
      echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Unknown error cannot create Blog!<br/>please try again later...<br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      echo "</html>";
      exit();
  }
  addonline(getuid_sid($sid),"Created New Blog","blogproc.php?action=$action");
	    echo "<head>";
    echo "<title>Create A New Blog</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
			echo "<b>Create Blog</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
      $crdate = time();
     $texst = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_blogs WHERE name LIKE '".$btitle."'"));
      if($texst[0]==0)
      {
        $res = false;
  if((trim($btitle)!="")||(trim($btxt)!=""))
      {
    if(!isblocked($btitle,$uid)&&!isblocked($btxt,$uid))
    {
$a = blogvldtn();
$res = mysql_query("INSERT INTO ibwff_blogs SET bowner='".$uid."', bname='".$btitle."', bgdate='".$crdate."', btext='".$btxt."', clubid='".$clid."', validate='".$a."', tags='".$buday."', uday_cat='".$udayt."'");
    }else{
    echo "<b><u><i>Can't Create Blog!!!<br/><br/>";
   echo "You Just Tried To Spam In FireBD via Blog!<br/>So You Are Now Blog Banned!<br/>If You Blog Banned By Our Mistake or Want To Be Blog Unban<br/>Then Please Contact <a href=\"online.php?action=stfol\">Online Staffs</a></b></i></u><br/><br/>";
        $user = getnick_sid($sid);
    mysql_query("UPDATE ibwff_users SET blogban='1' WHERE id='".$uid."'");
    mysql_query("INSERT INTO ibwff_private SET text='[b](forwarded spam via creating new blog)[/b][br/]".$btxt."', byuid='".$uid."', touid='1', timesent='".$crdate."'");
	mysql_query("INSERT INTO ibwff_private SET text='[b](forwarded spam via creating new blog)[/b][br/]".$btxt."', byuid='".$uid."', touid='2', timesent='".$crdate."'");
	mysql_query("INSERT INTO ibwff_private SET text='[b](forwarded spam via creating new blog)[/b][br/]".$btxt."', byuid='".$uid."', touid='4', timesent='".$crdate."'");
	echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      echo "</body>";
      echo "</html>";
      exit();
  }
     }
       if($res)
      {
        $cow = mysql_fetch_array(mysql_query("SELECT plusses FROM ibwff_users WHERE id='".$uid."'"));
$uday = blogpoint();  
      $upl = $cow[0]+$uday;
        mysql_query("UPDATE ibwff_users SET plusses='".$upl."' WHERE id='".$uid."'");
        $tnm = htmlspecialchars($btitle);
$ibwff = time()+6*60*60;
$user = getnick_uid($uid);
$who = getnick_uid($who);
mysql_query("insert into ibwff_events (event,time) values ('<b>$user</b> has created a new blog','$ibwff')");
        echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Blog <b>$tnm</b> Created Successfully!";
        $bid = mysql_fetch_array(mysql_query("SELECT id FROM ibwff_blogs WHERE bname='".$btitle."'"));
        echo "<br/>&#8226;<a href=\"blogs.php?clid=$clid&bid=$bid[0]\">";
echo "View Blog</a><br/><br/>";
if($clid>0)
{
mysql_query("UPDATE ibwff_clubs SET plusses=plusses+5 WHERE id=$clid");
mysql_query("UPDATE ibwff_clubmembers SET points=points+5 WHERE id=$clid");
$f = getclubname($clid);
echo "<b>$f</b>";
//club notification ;-)
$msg = "[b]Club Notification:[/b] ".getnick_sid($sid)." Just Created A Blog Named [blog=$bid[0]]".$tnm."[/blog] Under [club=$clid]".$f."[/club]!";
clubnot_uday($clid, $msg);
$ms2 = "".getnick_sid($sid)." created a blog named ".$tnm."!";
clubhis_uday($clid, $ms2);
}
      }else{
        echo "<br/><img src=\"../avatars/notok.gif\" alt=\"X\"/>Error Creating New Blog!<br/>";
      }
     }else{
        echo "<br/><img src=\"../avatars/notok.gif\" alt=\"X\"/>Blog Name Already Exists!<br/>";
      }
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="blgrate")
{
     echo "<head>";
    echo "<title>Rating Blog</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
						echo "<div class=\"header\" align=\"center\">";
			echo "<b>Rating A Blog</b></div>";
						echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$bid = $_GET["bid"];
$rate = $_POST["rate"];
$tm = time();
$x = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM uday_blgrate WHERE uid='".$uid."' AND tid='".$bid."'"));
if($x[0]==0)
{
$rx = mysql_query("INSERT INTO uday_blgrate SET uid='".$uid."', tid='".$bid."', rate='".$rate."', time='".time()."'");
if($rx)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> Blog Rated Successfully!<br/>";
}else{
echo "<img src=\"../images/notok.gif\" alt=\"O\"> Blog Cannot Be Rated At This Moment!<br/>";
}
}else{
echo "<img src=\"../images/notok.gif\" alt=\"O\"> You Have Already Rated This Blog!<br/>";
}
echo "&#171;<a href=\"blogs.php?bid=$bid\">View Blog</a>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
?>
</html>