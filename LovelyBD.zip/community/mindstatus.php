<?php
session_start();
include("config.php");
include("core.php");  connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo '<head>';
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"title\" content=\"FireBD.NeT\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From Megh: Don't Try To Hack OR else :P\">
<meta name=\"keywords\" content=\"Site Desined By Megh :) :)\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/></head>";
echo "<body>";
$action = $_GET["action"]; $sid = $_SESSION["sid"];
$page = $_GET["page"];
$who = $_GET["who"];
$uid = getuid_sid($sid);
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();
////////////////Ip Banned By CJ UDAY :)	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
    echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
echo "<br/>";
echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
$banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
$remain =  $banto[0] - time();
$rmsg = gettimemsg($remain);
echo "<b>Time Remaining: $rmsg</b><br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "</p>";
echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
//////////////////Banned System Updated By CJ UDAY :)
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please Contact <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
 echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
 echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");  
echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
///////////////////Deactivated Account By CJ UDAY :)
          if(isdeactivated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  <b>Your Account Has Been Deactivated Forever.<br/>And It Will Be Never Activate!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
///////////////////Validation By CJ UDAY :)
					if(isvalidated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  You Are Not Validated!<br/>We are checking your ip and browser<br/>
	  This could take up to 15 munites pls be patient and try again soon<br/>Please try again later...<br/><b>Thank You</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
////////////////Status Updates Created By CJ UDAY :) 
if($action=="")
{
addonline(getuid_sid($sid),"Updating Mind Status","mindstatus.php?action=$action");
echo "<head>";
echo "<title>Update Mind Status</title>";
  echo "</head>"; 
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
			echo "<b>Mind Status</b></div>";
  echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<b>Your Mind Status:</b><br/>";
	echo "<form action=\"mindstatus.php?action=update\" method=\"post\">";
	echo "<input type=\"text\" name=\"status\" maxlength=\"500\"/>";
echo "<input type=\"submit\" value=\"Update\"/>";    
echo "</form>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
exit();
}
//////////////////////////Like Mind Status By CJ UDAY :)
else if($action=="like")
{
$who = $_GET["who"];
$id = $_GET['id'];
$statusid = $_GET['statusid'];
$stime = time();
$nn = getnick_uid($uid);
addonline(getuid_sid($sid),"Liking Mind Status","mindstatus.php?action=$action");
echo "<head>";
echo "<title>Like A Mind Status</title>";
  echo "</head>"; 
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
			echo "<b>Like Mind Status</b></div>";
  echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$who = $_GET["who"];
$id = $_GET['id'];
$statusid = $_GET['statusid'];
$nn = subnick(getnick_uid($uid));
$vb = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_statuslike WHERE uid='".$uid."' AND statusid='".$id."'"));
if($vb[0]==0)
{
$res = mysql_query("INSERT INTO ibwff_statuslike SET uid='".$uid."', statusid='".$id."', ltime='".time()."'");
if($res)
{
  $res2 = mysql_fetch_array(mysql_query("SELECT status,uid FROM ibwff_status WHERE id='".$statusid."'"));
  $liker = getnick_sid($sid);
  $stname = htmlspecialchars($res2[0]);
echo "<br/><img src=\"../avatars/ok.gif\" alt=\"o\"/>Status Liked Successfully!<br/><br/>";
 mysql_query("INSERT INTO ibwff_notifications SET text='Your Status [statuslik=$id]$stname"."[/statuslik] Has Been Liked By [user=$uid]$liker"."[/user]', touid='".$res2[1]."', timesent='".time()."'");
}else{
echo "<br/><img src=\"../avatars/notok.gif\" alt=\"x\"/>Unknown Error!!!<br/><br/>";
}
}else{
echo "<br/><img src=\"../avatars/notok.gif\" alt=\"x\"/>You have already liked this status!<br/><br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
//////////////////////////Dislike Mind Status By CJ UDAY :)
else if($action=="dislike")
{
$who = $_GET["who"];
$id = $_GET['id'];
$statusid = $_GET['statusid'];
$stime = time();
$nn = getnick_uid($uid);
addonline(getuid_sid($sid),"Disliking Mind Status","mindstatus.php?action=$action");
echo "<head>";
echo "<title>Dislike A Mind Status</title>";
  echo "</head>"; 
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
			echo "<b>Dislike Mind Status</b></div>";
  echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$vb = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_statusdislike WHERE uid='".$uid."' AND statusid='".$id."'"));
if($vb[0]==0)
{
$res = mysql_query("INSERT INTO ibwff_statusdislike SET uid='".$uid."', statusid='".$id."', ltime='".time()."'");
if($res)
{
  $res2 = mysql_fetch_array(mysql_query("SELECT status,uid FROM ibwff_status WHERE id='".$id."'"));
  $disliker = getnick_sid($sid);
  $stname = htmlspecialchars($res2[0]);
echo "<br/><img src=\"../avatars/ok.gif\" alt=\"o\"/>Status Disliked Successfully!<br/><br/>";
 mysql_query("INSERT INTO ibwff_notifications SET text='Your Status [statusdislik=$id]$stname"."[/statusdislik] Has Been Disliked By [user=$uid]$disliker"."[/user]', touid='".$res2[1]."', timesent='".time()."'");
}else{
echo "<br/><img src=\"../avatars/notok.gif\" alt=\"x\"/>Unknown Error!!!<br/><br/>";
}
}else{
echo "<br/><img src=\"../avatars/notok.gif\" alt=\"x\"/>You have already disliked this status!<br/><br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
///////////////////////////////Delete Mind Status By CJ UDAY :)
else if($action=="delstatus")
{
$id = $_GET["id"];
echo "<head>";
echo "<title>Delete A Mind Status</title>";
  echo "</head>"; 
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
			echo "<b>Delete Mind Status</b></div>";
  echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
if(ismod(getuid_sid($sid)))
{
$res = mysql_query("DELETE FROM ibwff_mindstatus11 WHERE id='".$id."'");
if($res)
{
echo "<br/><img src=\"../avatars/ok.gif\" alt=\"o\"/>Status Update Deleted Sucessfully!<br/><br/>";
}else{
echo "<br/><img src=\"../avatars/notok.gif\" alt=\"x\"/>Unknown Error!!!<br/><br/>";
}
}else{
echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>You dont have permission to use this tool!!!<br/><br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
//////////////////////////////Update Status By CJ UDAY :)
else if($action=="update")
{
addonline(getuid_sid($sid),"Updating Mind Status","mindstatus.php?action=view&who=$who");
echo "<head>";
echo "<title>Updatate Mind Status</title>";
  echo "</head>"; 
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
			echo "<b>Update Mind Status</b></div>";
  echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$whonick = subnick(getnick_uid($who));
  $byuid = getuid_sid($sid);
  $uid = getuid_sid($sid);
  $status = $_POST['status'];
$shtime = time();
    $tm = time();
if(isblocked($status,$byuid)){
    echo "<b><u><i>Can't Update Status!!!<br/><br/>";
   echo "You Just Tried To Spam In FireBD via Update Status<br/>So You Are Now Status Banned!<br/>If You Status Banned By Our Mistake or Want To Be Status Unban<br/>Then Please With Contact <a href=\"online.php?action=stfol\">Online FireBD Staffs</a></b></i></u><br/>";
        $user = getnick_sid($sid);
    mysql_query("UPDATE ibwff_users SET postban='1' WHERE id='".$uid."'");
    mysql_query("INSERT INTO ibwff_private SET text='[b](forwarded spam via updating status)[/b][br/]".$status."', byuid='".$byuid."', touid='1', timesent='".$shtm."'");
	mysql_query("INSERT INTO ibwff_private SET text='[b](forwarded spam via updating status)[/b][br/]".$status."', byuid='".$byuid."', touid='2', timesent='".$shtm."'");
	mysql_query("INSERT INTO ibwff_private SET text='[b](forwarded spam via updating status)[/b][br/]".$status."', byuid='".$byuid."', touid='4', timesent='".$shtm."'");
	echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      echo "</body>";
      echo "</html>";
    exit();
  }
$status = $_POST['status'];
$stime = time();
$uid = getuid_sid($sid);
$res = mysql_query("INSERT INTO ibwff_mindstatus11 SET uid='".$uid."', status='".$status."', time='".$stime."', lastupdate='".$stime."'");
if($res)
{
$f = "[b]Subscribe Notification:[/b] ".subnick(getnick_uid($uid))." have updated mind status.";
subnot_uday($uid, $f);
echo "<br/><img src=\"../avatars/ok.gif\" alt=\"O\"/>Status Updated Successfully!<br/><br/>";
}else
{
echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>Unknown Error!!!<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
////////////////////////////////////Users Updates (Mind Status) By CJ UDAY :)
else if($action=="usersupdates")
{
$whnick = subnick(getnick_uid($who));
addonline(getuid_sid($sid),"Viewing $whnick Updates Mind Status","mindstatus.php?action=$action");
echo "<head>";
echo "<title>View $whnick Update Mind Status</title>";
  echo "</head>"; 
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
			echo "<b>$whnick Mind Status</b></div>";
  echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$uid = getuid_sid($sid);
$unick = subnick(getnick_uid($uid));
echo '</p><p align="left">';
echo "-----------<br/>";
if($page=="" || $page<=0) {$page=1;}
$count = mysql_fetch_assoc(mysql_query("SELECT COUNT(*) page FROM ibwff_mindstatus11 WHERE uid='".$who."'"));
$num_items = $count['page'];
$event_per_page= 7;
$num_pages = ceil($num_items/$event_per_page);
if(($page>$num_pages)&&$page!=1) {$page= $num_pages;}
$limit_start = ($page-1)*$event_per_page;
$res = mysql_query("SELECT id , status, time FROM ibwff_status WHERE uid='".$who."' ORDER BY lastupdate DESC LIMIT $limit_start, $event_per_page");
while ($r = mysql_fetch_assoc($res)) {
$statusid = $_GET['statusid'];
$suid = $who;
$sunick = subnick(getnick_uid($suid));
$status = trim($r['status']);
$stime = $r['time'];
$tremain = time()-$stime;
$tmdt = gettimemsg($tremain);
$lshout = mysql_fetch_array(mysql_query("SELECT status, uid FROM ibwff_mindstatus11 WHERE id='".$statusid."'"));
$text = parsepm($lshout[0],$sid);
	    $sql = "SELECT name FROM ibwff_users WHERE id=$who";
	    $sql2 = mysql_query($sql);
	    $item = mysql_fetch_array($sql2);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item[0]'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/>";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/>";}
if($sex[0]==""){$usersex = "";}
        		$avlink = getavatar($who);
if($avlink=="")
{
 $avt =  "$usersex";
}else{
 $avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"icon\" width=\"23\" height=\"18\"/>";
}
	    $sql3 = "SELECT name FROM ibwff_users WHERE id=$who";
	    $sql33 = mysql_query($sql3);
	    $item3 = mysql_fetch_array($sql33);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nicks = "<font color=\"blue\"><b>$sunick</b></font>";}
if($sex[0]=="F"){$nicks = "<font color=\"deeppink\"><b>$sunick</b></font>";}
if($sex[0]==""){$nicks = "";}
echo "<a href=\"profile.php?who=$who\">$avt$nicks</a>: ";
}
}
echo "$text ";
echo " @ ".date("h:i:s A",($stime + (6 * 60 * 60)))."<br/>";
echo "($tmdt ago)";
$comments = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_scomments WHERE statusid='".$statusid."'"));
$comm = $comments[0];
echo "<br/><b><img src=\"comment.png\" alt=\"*\" /><a href=\"scomments.php?who=$who&statusid=$statusid\">Comments ($comm) </a><br/>";
$counts = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_statuslike WHERE statusid='".$statusid."'"));
$counts1 = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_statusdislike WHERE statusid='".$statusid."'"));
if($counts[0]>0)
{
$lyk = "<a href=\"statuslike.php?who=$who&statusid=$statusid\">$counts[0]</a>";
}else{
$lyk = "<a href=\"statuslike.php?who=$who&statusid=$statusid\">$counts[0]</a>";
}
if($counts1[0]>0)
{
$dislyk = "<a href=\"statusdislike.php?who=$who&statusid=$statusid\">$counts1[0]</a>";
}else{
$dislyk = "<a href=\"statusdislike.php?who=$who&statusid=$statusid\">$counts1[0]</a>";
}
echo "<img src=\"like.png\" alt=\"*\" /><a href=\"mindstatus.php?action=like&who=$who&id=".$statusid."\">Like</a> ($lyk)";
echo "<img src=\"dislike.png\" alt=\"*\" /><a href=\"mindstatus.php?action=dislike&who=$who&id=".$statusid."\">Dislike</a> ($dislyk)<br/>";
echo "</b>";
echo "-----------<br/>";
}
if($page>1)
{
$ppage = $page-1;
echo "<a href=\"mindstatus.php?action=$action&page=$ppage&who=$who\">&#171;-Prev</a> ";
}
if($page<$num_pages)
{
$npage = $page+1;
echo "<a href=\"mindstatus.php?action=$action&page=$npage&who=$who\">Next-&#187;</a>";
}
echo "<br/>Page - $page/$num_pages<br/>";
   if($num_pages>2)
    {
		$rets = "<form action=\"mindstatus.php\" method=\"get\">";
        $rets .= "<input name=\"page\" style=\"-wap-input-format: '*N'\" size=\"2\"/>";
        $rets .= "<input type=\"hidden\" name=\"action\" value=\"$action\"/>";
        $rets .= "<input type=\"hidden\" name=\"sid\" value=\"$sid\"/>";
		$rets .= "<input type=\"hidden\" name=\"view\" value=\"$view\"/>";
   $rets .= "<input type=\"submit\" value=\"Go To Page\"/>";
        $rets .= "</form>";
        echo $rets;
    }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
?>
</html>