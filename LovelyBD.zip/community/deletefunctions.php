<?php
session_start();
include("config.php");
include("core.php");  connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo '<head>';
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"title\" content=\"FireBD.NeT\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From CJ UDAY: Don't Try To Hack OR else :P\">
<meta name=\"keywords\" content=\"Site Desined By CJ UDAY :) :)\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/></head>";
echo "<body>";
$action = $_GET["action"]; $sid = $_SESSION["sid"];
$clid = $_GET["clid"];
$uid = getuid_sid($sid);
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if($_REQUEST['who'] =='1')
{
echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  echo "<b>Unknown Error!!!</b><br/>Unknown Security By CJ UDAY :)<br/><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
else if($_REQUEST['who'] =='2')
{
echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  echo "<b>Unknown Error!!!</b><br/>Unknown Security By CJ UDAY :)<br/><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
else if($_REQUEST['who'] =='3')
{
echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  echo "<b>Unknown Error!!!</b><br/>Unknown Security By CJ UDAY :)<br/><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
else if($_REQUEST['who'] =='4')
{
echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  echo "<b>Unknown Error!!!</b><br/>Unknown Security By CJ UDAY :)<br/><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
else if($action=="delprivate")
{
  $who = $_GET["who"];
  $user = getnick_uid($who);
echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $uid = getuid_sid($sid);
  $cyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE id='".$uid."'"));
  $trgtcyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE name='".$user."'"));

  if($trgtcyberpowereragon>$cyberpowereragon){ 
  echo "<b><img src=\"../avatars/notok.gif\" alt=\"x\"/><br/>Error!!!!!<br/>Permission Denied...</b><br/>";
  echo "<br/>U Cannot Delete From $user<br/>";
  }else{

  echo "<br/>";
    $res = mysql_query("DELETE FROM ibwff_private WHERE byuid='".$who."' OR touid='".$who."'");

  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>$user PMs Deleted Successfully!";
    $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Messages Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Messages Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='2', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Messages Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='4', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
  }
  }
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
//////////////////////////Delete Notifications By CJ UDAY :)//////////////////////////

else if($action=="delnotification")
{
  $who = $_GET["who"];
  $user = getnick_uid($who);echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $uid = getuid_sid($sid);
  $cyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE id='".$uid."'"));
  $trgtcyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE name='".$user."'"));

  if($trgtcyberpowereragon>$cyberpowereragon){ 
  echo "<b><img src=\"../avatars/notok.gif\" alt=\"x\"/><br/>Error!!!!!<br/>Permission Denied...</b><br/>";
  echo "<br/>U Cannot Delete $user<br/>";echo "";
  }else{

  echo "<br/>";
    $res = mysql_query("DELETE FROM ibwff_notifications WHERE touid='".$who."'");

  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>$user Notifications Has Been Deleted Successfully!";
    $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Notifications Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Notifications Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='2', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Notifications Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='4', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
  }
  echo "";
  }  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
//////////////////////////Delete Guestbook By CJ UDAY :)//////////////////////////

else if($action=="delgb")
{
  $who = $_GET["who"];
  $user = getnick_uid($who);echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $uid = getuid_sid($sid);
  $cyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE id='".$uid."'"));
  $trgtcyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE name='".$user."'"));

  if($trgtcyberpowereragon>$cyberpowereragon){ 
  echo "<b><img src=\"../avatars/notok.gif\" alt=\"x\"/><br/>Error!!!!!<br/>Permission Denied...</b><br/>";
  echo "<br/>U Cannot Delete $user<br/>";echo "";
  }else{

  echo "<br/>";
  $res = mysql_query("DELETE FROM ibwff_gbook WHERE gbowner='".$who."' OR gbsigner='".$who."'");
  
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>$user  GB Deleted Successfully!";
  	$tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Guestbook Messages Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Guestbook Messages Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='2', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Guestbook Messages Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='4', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
  }
  echo "";
  }  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
//////////////////////////Delete Friends By CJ UDAY :)//////////////////////////

else if($action=="delfriend")
{
  $who = $_GET["who"];
  $user = getnick_uid($who);echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $uid = getuid_sid($sid);
  $cyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE id='".$uid."'"));
  $trgtcyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE name='".$user."'"));

  if($trgtcyberpowereragon>$cyberpowereragon){ 
  echo "<b><img src=\"../avatars/notok.gif\" alt=\"x\"/><br/>Error!!!!!<br/>Permission Denied...</b><br/>";
  echo "<br/>U Cannot Delete $user<br/>";echo "";
  }else{

  echo "<br/>";
  
   $res = mysql_query("DELETE FROM ibwff_buddies WHERE tid='".$who."' OR uid='".$who."'");

  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>$user  Buddies Deleted Successfully!";
  $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Friends Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Friends Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='2', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Friends Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='4', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
  }
  echo "";
  }  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
//////////////////////////Delete Ignored By CJ UDAY :)//////////////////////////

else if($action=="delignore")
{
  $who = $_GET["who"];
  $user = getnick_uid($who);echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $uid = getuid_sid($sid);
  $cyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE id='".$uid."'"));
  $trgtcyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE name='".$user."'"));

  if($trgtcyberpowereragon>$cyberpowereragon){ 
  echo "<b><img src=\"../avatars/notok.gif\" alt=\"x\"/><br/>Error!!!!!<br/>Permission Denied...</b><br/>";
  echo "<br/>U Cannot Delete $user<br/>";echo "";
  }else{

  echo "<br/>";
  
   $res = mysql_query("DELETE FROM ibwff_ignore WHERE target='".$who."' OR name='".$who."'");

  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>$user Ignores Has Been Deleted Successfully!";
  $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Ignores Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Ignores Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='2', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Ignores Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='4', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
  }
  echo "";
  }  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
//////////////////////////Delete Shouts By CJ UDAY :)//////////////////////////

else if($action=="delshts")
{
  $who = $_GET["who"];
  $user = getnick_uid($who);echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $uid = getuid_sid($sid);
  $cyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE id='".$uid."'"));
  $trgtcyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE name='".$user."'"));

  if($trgtcyberpowereragon>$cyberpowereragon){ 
  echo "<b><img src=\"../avatars/notok.gif\" alt=\"x\"/><br/>Error!!!!!<br/>Permission Denied...</b><br/>";
  echo "<br/>U Cannot Delete $user<br/>";echo "";
  }else{

  echo "<br/>";
  $res = mysql_query("DELETE FROM ibwff_shouts WHERE shouter='".$who."'");
  
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>$user  Shout Deleted Successfully!";
      $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Shouts Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Shouts Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='2', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Shouts Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='4', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
  }
  echo "";
  }  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
//////////////////////////Delete Shout Comments By CJ UDAY :)//////////////////////////

else if($action=="delshtcom")
{
  $who = $_GET["who"];
  $user = getnick_uid($who);echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $uid = getuid_sid($sid);
  $cyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE id='".$uid."'"));
  $trgtcyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE name='".$user."'"));

  if($trgtcyberpowereragon>$cyberpowereragon){ 
  echo "<b><img src=\"../avatars/notok.gif\" alt=\"x\"/><br/>Error!!!!!<br/>Permission Denied...</b><br/>";
  echo "<br/>U Cannot Delete $user<br/>";echo "";
  }else{

  echo "<br/>";
  $res = mysql_query("DELETE FROM ibwff_shcomments WHERE uid='".$who."'");

  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>$user Shouts Comments Deleted Successfully!";
  $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Shouts Comments Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Shouts Comments Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='2', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Shouts Comments Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='4', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
  }
  echo "";
  }  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
//////////////////////////Delete Shout Likes By CJ UDAY :)//////////////////////////

else if($action=="delshtlike")
{
  $who = $_GET["who"];
  $user = getnick_uid($who);echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $uid = getuid_sid($sid);
  $cyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE id='".$uid."'"));
  $trgtcyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE name='".$user."'"));

  if($trgtcyberpowereragon>$cyberpowereragon){ 
  echo "<b><img src=\"../avatars/notok.gif\" alt=\"x\"/><br/>Error!!!!!<br/>Permission Denied...</b><br/>";
  echo "<br/>U Cannot Delete $user<br/>";echo "";
  }else{

  echo "<br/>";
  $res = mysql_query("DELETE FROM ibwff_like WHERE uid='".$who."'");
  
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>$user Shout Likes Has Been Deleted Successfully!";
      $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Shout Likes Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Shout Likes Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='2', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Shout Likes Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='4', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
  }
  echo "";
  }  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
//////////////////////////Delete Shout Dislikes By CJ UDAY :)//////////////////////////

else if($action=="delshtdislike")
{
  $who = $_GET["who"];
  $user = getnick_uid($who);echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $uid = getuid_sid($sid);
  $cyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE id='".$uid."'"));
  $trgtcyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE name='".$user."'"));

  if($trgtcyberpowereragon>$cyberpowereragon){ 
  echo "<b><img src=\"../avatars/notok.gif\" alt=\"x\"/><br/>Error!!!!!<br/>Permission Denied...</b><br/>";
  echo "<br/>U Cannot Delete $user<br/>";echo "";
  }else{

  echo "<br/>";
  $res = mysql_query("DELETE FROM ibwff_dislike WHERE uid='".$who."'");
  
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>$user Shout Dislikes Has Been Deleted Successfully!";
      $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Shout Dislikes Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Shout Dislikes Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='2', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Shout Dislikes Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='4', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
  }
  echo "";
  }  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
//////////////////////////Delete Topics By CJ UDAY :)//////////////////////////

else if($action=="deltopics")
{
  $who = $_GET["who"];
  $user = getnick_uid($who);echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $uid = getuid_sid($sid);
  $cyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE id='".$uid."'"));
  $trgtcyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE name='".$user."'"));

  if($trgtcyberpowereragon>$cyberpowereragon){ 
  echo "<b><img src=\"../avatars/notok.gif\" alt=\"x\"/><br/>Error!!!!!<br/>Permission Denied...</b><br/>";
  echo "<br/>U Cannot Delete $user<br/>";echo "";
  }else{

  echo "<br/>";
  $res = mysql_query("DELETE FROM ibwff_topics WHERE authorid='".$who."'");

  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>$user Topics Deleted Successfully!";
        $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Shouts Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Shouts Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='2', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Shouts Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='4', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
  }
  echo "";
  }  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
//////////////////////////Delete Topics Posts By CJ UDAY :)//////////////////////////

else if($action=="delpsts")
{
  $who = $_GET["who"];
  $user = getnick_uid($who);echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $uid = getuid_sid($sid);
  $cyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE id='".$uid."'"));
  $trgtcyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE name='".$user."'"));

  if($trgtcyberpowereragon>$cyberpowereragon){ 
  echo "<b><img src=\"../avatars/notok.gif\" alt=\"x\"/><br/>Error!!!!!<br/>Permission Denied...</b><br/>";
  echo "<br/>U Cannot Delete $user<br/>";echo "";
  }else{

  echo "<br/>";
    $res = mysql_query("DELETE FROM ibwff_posts WHERE uid='".$who."'");

  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>$user Topics Posts Deleted Successfully!";
  $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Topics Posts Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Topics Posts Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='2', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Topics Posts Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='4', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
  }
  echo "";
  }  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
//////////////////////////Delete Storys By CJ UDAY :)//////////////////////////

else if($action=="delstorys")
{
  $who = $_GET["who"];
  $user = getnick_uid($who);echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $uid = getuid_sid($sid);
  $cyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE id='".$uid."'"));
  $trgtcyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE name='".$user."'"));

  if($trgtcyberpowereragon>$cyberpowereragon){ 
  echo "<b><img src=\"../avatars/notok.gif\" alt=\"x\"/><br/>Error!!!!!<br/>Permission Denied...</b><br/>";
  echo "<br/>U Cannot Delete $user<br/>";echo "";
  }else{

  echo "<br/>";
  $res = mysql_query("DELETE FROM ibwff_storys WHERE authorid='".$who."'");

  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>$user Storys Deleted Successfully!";
    $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Storys Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Storys Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='2', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Storys Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='4', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Error To Deleting User Storys";
  }
  echo "";
  }  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
//////////////////////////Delete Story Posts By CJ UDAY :)//////////////////////////

else if($action=="delstpsts")
{
  $who = $_GET["who"];
  $user = getnick_uid($who);echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $uid = getuid_sid($sid);
  $cyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE id='".$uid."'"));
  $trgtcyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE name='".$user."'"));

  if($trgtcyberpowereragon>$cyberpowereragon){ 
  echo "<b><img src=\"../avatars/notok.gif\" alt=\"x\"/><br/>Error!!!!!<br/>Permission Denied...</b><br/>";
  echo "<br/>U Cannot Delete $user<br/>";echo "";
  }else{

  echo "<br/>";
    $res = mysql_query("DELETE FROM ibwff_storyposts WHERE uid='".$who."'");

  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>$user Storys Comments Deleted Successfully!";
      $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Storys Comments Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Storys Comments Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='2', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Storys Comments Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='4', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Error To Deleting Story Post!";
  }
  echo "";
  }  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
//////////////////////////Delete Polls By CJ UDAY :)//////////////////////////

else if($action=="delpoll")
{
  $who = $_GET["who"];
  $user = getnick_uid($who);echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $uid = getuid_sid($sid);
  $cyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE id='".$uid."'"));
  $trgtcyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE name='".$user."'"));

  if($trgtcyberpowereragon>$cyberpowereragon){ 
  echo "<b><img src=\"../avatars/notok.gif\" alt=\"x\"/><br/>Error!!!!!<br/>Permission Denied...</b><br/>";
  echo "<br/>U Cannot Delete $user<br/>";echo "";
  }else{

  echo "<br/>";
  $res = mysql_query("DELETE FROM ibwff_polls WHERE uid='".$who."'");

  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>$user  Polls Deleted Successfully!";
        $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Polls Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Polls Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='2', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Polls Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='4', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
  }
  echo "";
  }  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
//////////////////////////Delete Poll Votes By CJ UDAY :)//////////////////////////

else if($action=="delpollvote")
{
  $who = $_GET["who"];
  $user = getnick_uid($who);echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $uid = getuid_sid($sid);
  $cyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE id='".$uid."'"));
  $trgtcyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE name='".$user."'"));

  if($trgtcyberpowereragon>$cyberpowereragon){ 
  echo "<b><img src=\"../avatars/notok.gif\" alt=\"x\"/><br/>Error!!!!!<br/>Permission Denied...</b><br/>";
  echo "<br/>U Cannot Delete $user<br/>";echo "";
  }else{

  echo "<br/>";
  $res = mysql_query("DELETE FROM ibwff_presults WHERE uid='".$who."'");

  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>$user Poll Votes Has Been Deleted Successfully!";
        $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Poll Votes Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Poll Votes Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='2', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Poll Votes Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='4', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
  }
  echo "";
  }  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
//////////////////////////Delete Blogs By CJ UDAY :)//////////////////////////

else if($action=="delblog")
{
  $who = $_GET["who"];
  $user = getnick_uid($who);echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $uid = getuid_sid($sid);
  $cyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE id='".$uid."'"));
  $trgtcyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE name='".$user."'"));

  if($trgtcyberpowereragon>$cyberpowereragon){ 
  echo "<b><img src=\"../avatars/notok.gif\" alt=\"x\"/><br/>Error!!!!!<br/>Permission Denied...</b><br/>";
  echo "<br/>U Cannot Delete $user<br/>";echo "";
  }else{

  echo "<br/>";
  $res = mysql_query("DELETE FROM ibwff_blogs WHERE bowner='".$who."'");

  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>$user Blogs Deleted Successfully!";
          $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Blogs Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Blogs Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='2', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Blogs Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='4', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
  }
  echo "";
  }  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
//////////////////////////Delete Blogs Comment By CJ UDAY :)//////////////////////////

else if($action=="delblogcom")
{
  $who = $_GET["who"];
  $user = getnick_uid($who);echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $uid = getuid_sid($sid);
  $cyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE id='".$uid."'"));
  $trgtcyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE name='".$user."'"));

  if($trgtcyberpowereragon>$cyberpowereragon){ 
  echo "<b><img src=\"../avatars/notok.gif\" alt=\"x\"/><br/>Error!!!!!<br/>Permission Denied...</b><br/>";
  echo "<br/>U Cannot Delete $user<br/>";echo "";
  }else{

  echo "<br/>";
  $res = mysql_query("DELETE FROM ibwff_bcomments WHERE uid='".$who."'");

  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>$user Blogs Comments Deleted Successfully!";
            $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Blog Comments Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Blog Comments Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='2', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Blog Comments Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='4', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
  }
  echo "";
  }  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
//////////////////////////Delete Status By CJ UDAY :)//////////////////////////

else if($action=="delst")
{
  $who = $_GET["who"];
  $user = getnick_uid($who);echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $uid = getuid_sid($sid);
  $cyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE id='".$uid."'"));
  $trgtcyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE name='".$user."'"));

  if($trgtcyberpowereragon>$cyberpowereragon){ 
  echo "<b><img src=\"../avatars/notok.gif\" alt=\"x\"/><br/>Error!!!!!<br/>Permission Denied...</b><br/>";
  echo "<br/>U Cannot Delete $user<br/>";echo "";
  }else{

  echo "<br/>";
  $res = mysql_query("DELETE FROM ibwff_status WHERE uid='".$who."'");

  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>$user Status Deleted Successfully!";
              $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Status Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Status Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='2', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Status Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='4', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
  }
  echo "";
  }  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
//////////////////////////Delete Status Comments By CJ UDAY :)//////////////////////////

else if($action=="delstcom")
{
  $who = $_GET["who"];
  $user = getnick_uid($who);echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $uid = getuid_sid($sid);
  $cyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE id='".$uid."'"));
  $trgtcyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE name='".$user."'"));

  if($trgtcyberpowereragon>$cyberpowereragon){ 
  echo "<b><img src=\"../avatars/notok.gif\" alt=\"x\"/><br/>Error!!!!!<br/>Permission Denied...</b><br/>";
  echo "<br/>U Cannot Delete $user<br/>";echo "";
  }else{

  echo "<br/>";
  $res = mysql_query("DELETE FROM ibwff_scomments WHERE uid='".$who."'");

  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>$user Status Comments Deleted Successfully!";
   $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Status Comments Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Status Comments Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='2', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Status Comments Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='4', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
  }
  echo "";
  }  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
//////////////////////////Delete Status Likes By CJ UDAY :)//////////////////////////

else if($action=="delstlike")
{
  $who = $_GET["who"];
  $user = getnick_uid($who);echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $uid = getuid_sid($sid);
  $cyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE id='".$uid."'"));
  $trgtcyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE name='".$user."'"));

  if($trgtcyberpowereragon>$cyberpowereragon){ 
  echo "<b><img src=\"../avatars/notok.gif\" alt=\"x\"/><br/>Error!!!!!<br/>Permission Denied...</b><br/>";
  echo "<br/>U Cannot Delete $user<br/>";echo "";
  }else{

  echo "<br/>";
  $res = mysql_query("DELETE FROM ibwff_statuslike WHERE uid='".$who."'");

  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>$user Status Likes Has Been Deleted Successfully!";
            $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Status Likes Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Status Likes Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='2', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Status Likes Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='4', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
  }
  echo "";
  }  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
//////////////////////////Delete Status Dislikes By CJ UDAY :)//////////////////////////

else if($action=="delstdislike")
{
  $who = $_GET["who"];
  $user = getnick_uid($who);echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $uid = getuid_sid($sid);
  $cyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE id='".$uid."'"));
  $trgtcyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE name='".$user."'"));

  if($trgtcyberpowereragon>$cyberpowereragon){ 
  echo "<b><img src=\"../avatars/notok.gif\" alt=\"x\"/><br/>Error!!!!!<br/>Permission Denied...</b><br/>";
  echo "<br/>U Cannot Delete $user<br/>";echo "";
  }else{

  echo "<br/>";
  $res = mysql_query("DELETE FROM ibwff_statusdislike WHERE uid='".$who."'");

  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>$user Status Dislikes Has Been Deleted Successfully!";
            $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Status Dislikes Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Status Dislikes Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='2', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Status Dislikes Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='4', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
  }
  echo "";
  }  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
//////////////////////////Delete Profile Picture Comment By CJ UDAY :)//////////////////////////

else if($action=="delpfpicom")
{
  $who = $_GET["who"];
  $user = getnick_uid($who);echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $uid = getuid_sid($sid);
  $cyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE id='".$uid."'"));
  $trgtcyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE name='".$user."'"));

  if($trgtcyberpowereragon>$cyberpowereragon){ 
  echo "<b><img src=\"../avatars/notok.gif\" alt=\"x\"/><br/>Error!!!!!<br/>Permission Denied...</b><br/>";
  echo "<br/>U Cannot Delete $user<br/>";echo "";
  }else{

  echo "<br/>";
  $res = mysql_query("DELETE FROM ibwff_pfpicom61 WHERE uid='".$who."'");

  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>$user Profile Picture Comments Has Been Deleted Successfully!";
            $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Profile Picture Comments Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Profile Picture Comments Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='2', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Profile Picture Comments Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='4', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
  }
  echo "";
  }  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
//////////////////////////Delete Profile Picture Likes By CJ UDAY :)//////////////////////////

else if($action=="delpfpiclike")
{
  $who = $_GET["who"];
  $user = getnick_uid($who);echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $uid = getuid_sid($sid);
  $cyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE id='".$uid."'"));
  $trgtcyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE name='".$user."'"));

  if($trgtcyberpowereragon>$cyberpowereragon){ 
  echo "<b><img src=\"../avatars/notok.gif\" alt=\"x\"/><br/>Error!!!!!<br/>Permission Denied...</b><br/>";
  echo "<br/>U Cannot Delete $user<br/>";echo "";
  }else{

  echo "<br/>";
  $res = mysql_query("DELETE FROM ibwff_pfpiclike62 WHERE uid='".$who."'");

  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>$user Profile Picture Likes Has Been Deleted Successfully!";
            $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Profile Picture Likes Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Profile Picture Likes Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='2', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Profile Picture Likes Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='4', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
  }
  echo "";
  }  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
//////////////////////////Delete Profile Picture Dislikes By CJ UDAY :)//////////////////////////

else if($action=="delpfpicdislike")
{
  $who = $_GET["who"];
  $user = getnick_uid($who);echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $uid = getuid_sid($sid);
  $cyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE id='".$uid."'"));
  $trgtcyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE name='".$user."'"));

  if($trgtcyberpowereragon>$cyberpowereragon){ 
  echo "<b><img src=\"../avatars/notok.gif\" alt=\"x\"/><br/>Error!!!!!<br/>Permission Denied...</b><br/>";
  echo "<br/>U Cannot Delete $user<br/>";echo "";
  }else{

  echo "<br/>";
  $res = mysql_query("DELETE FROM ibwff_pfpicdislike63 WHERE uid='".$who."'");

  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>$user Profile Picture Dislikes Has Been Deleted Successfully!";
            $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Profile Picture Dislikes Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Profile Picture Dislikes Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='2', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Profile Picture Dislikes Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='4', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
  }
  echo "";
  }  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
//////////////////////////Delete Cover Photo Comment By CJ UDAY :)//////////////////////////

else if($action=="delcoverphtcom")
{
  $who = $_GET["who"];
  $user = getnick_uid($who);echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $uid = getuid_sid($sid);
  $cyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE id='".$uid."'"));
  $trgtcyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE name='".$user."'"));

  if($trgtcyberpowereragon>$cyberpowereragon){ 
  echo "<b><img src=\"../avatars/notok.gif\" alt=\"x\"/><br/>Error!!!!!<br/>Permission Denied...</b><br/>";
  echo "<br/>U Cannot Delete $user<br/>";echo "";
  }else{

  echo "<br/>";
  $res = mysql_query("DELETE FROM ibwff_coverpicom11 WHERE uid='".$who."'");

  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>$user Cover Photo Comments Has Been Deleted Successfully!";
            $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Cover Photo Comments Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Cover Photo Comments Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='2', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Cover Photo Comments Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='4', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
  }
  echo "";
  }  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
//////////////////////////Delete Cover Photo Likes By CJ UDAY :)//////////////////////////

else if($action=="delcoverphtlike")
{
  $who = $_GET["who"];
  $user = getnick_uid($who);echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $uid = getuid_sid($sid);
  $cyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE id='".$uid."'"));
  $trgtcyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE name='".$user."'"));

  if($trgtcyberpowereragon>$cyberpowereragon){ 
  echo "<b><img src=\"../avatars/notok.gif\" alt=\"x\"/><br/>Error!!!!!<br/>Permission Denied...</b><br/>";
  echo "<br/>U Cannot Delete $user<br/>";echo "";
  }else{

  echo "<br/>";
  $res = mysql_query("DELETE FROM ibwff_coverpiclike12 WHERE uid='".$who."'");

  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>$user Cover Photo Likes Has Been Deleted Successfully!";
            $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Cover Photo Likes Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Cover Photo Likes Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='2', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Cover Photo Likes Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='4', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
  }
  echo "";
  }  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
//////////////////////////Delete Cover Photo Dislikes By CJ UDAY :)//////////////////////////

else if($action=="delcoverphtdislike")
{
  $who = $_GET["who"];
  $user = getnick_uid($who);echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $uid = getuid_sid($sid);
  $cyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE id='".$uid."'"));
  $trgtcyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE name='".$user."'"));

  if($trgtcyberpowereragon>$cyberpowereragon){ 
  echo "<b><img src=\"../avatars/notok.gif\" alt=\"x\"/><br/>Error!!!!!<br/>Permission Denied...</b><br/>";
  echo "<br/>U Cannot Delete $user<br/>";echo "";
  }else{

  echo "<br/>";
  $res = mysql_query("DELETE FROM ibwff_coverpicdislike13 WHERE uid='".$who."'");

  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>$user Cover Photo Dislikes Has Been Deleted Successfully!";
            $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Cover Photo Dislikes Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Cover Photo Dislikes Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='2', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Cover Photo Dislikes Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='4', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
  }
  echo "";
  }  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
//////////////////////////Delete Popups By CJ UDAY :)//////////////////////////

else if($action=="delpops")
{
  $who = $_GET["who"];
  $user = getnick_uid($who);echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $uid = getuid_sid($sid);
  $cyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE id='".$uid."'"));
  $trgtcyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE name='".$user."'"));

  if($trgtcyberpowereragon>$cyberpowereragon){ 
  echo "<b><img src=\"../avatars/notok.gif\" alt=\"x\"/><br/>Error!!!!!<br/>Permission Denied...</b><br/>";
  echo "<br/>U Cannot Delete $user<br/>";echo "";
  }else{

  echo "<br/>";
  $res = mysql_query("DELETE FROM ibwff_popups WHERE byuid='".$who."' OR touid='".$who."'");

  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>$user Popups Deleted Successfully!";
    $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Popups Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Popups Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='2', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Popups Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='4', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
  }
  echo "";
  }  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
//////////////////////////Delete Ses By CJ UDAY :)//////////////////////////

else if($action=="delses")
{
  $who = $_GET["who"];
  $user = getnick_uid($who);echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $uid = getuid_sid($sid);
  $cyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE id='".$uid."'"));
  $trgtcyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE name='".$user."'"));

  if($trgtcyberpowereragon>$cyberpowereragon){ 
  echo "<b><img src=\"../avatars/notok.gif\" alt=\"x\"/><br/>Error!!!!!<br/>Permission Denied...</b><br/>";
  echo "<br/>U Cannot Delete $user<br/>";echo "";
  }else{

  echo "<br/>";
  $res = mysql_query("DELETE FROM ibwff_ses WHERE uid='".$who."'");

  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>$user Ses Has Been Deleted Successfully!";
      $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Ses Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Ses Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='2', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Ses Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='4', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
  }
  echo "";
  }  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
//////////////////////////Delete More By CJ UDAY :)//////////////////////////

else if($action=="delothers")
{
  $who = $_GET["who"];
  $user = getnick_uid($who);echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $uid = getuid_sid($sid);
  $cyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE id='".$uid."'"));
  $trgtcyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE name='".$user."'"));

  if($trgtcyberpowereragon>$cyberpowereragon){ 
  echo "<b><img src=\"../avatars/notok.gif\" alt=\"x\"/><br/>Error!!!!!<br/>Permission Denied...</b><br/>";
  echo "<br/>U Cannot Delete $user<br/>";echo "";
  }else{

  echo "<br/>";

  $res = mysql_query("DELETE FROM ibwff_mangr WHERE uid='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_modr WHERE name='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_penalties WHERE uid='".$who."' OR exid='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_games WHERE uid='".$who."'");

  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>$user Activities Has Been Deleted Successfully!";
        $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Activities Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Activities Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='2', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Activities Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='4', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
  }
  echo "";
  }  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
//////////////////////////Delete Loves By CJ UDAY :)//////////////////////////

else if($action=="dellove")
{
  $who = $_GET["who"];
  $user = getnick_uid($who);echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $uid = getuid_sid($sid);
  $cyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE id='".$uid."'"));
  $trgtcyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE name='".$user."'"));

  if($trgtcyberpowereragon>$cyberpowereragon){ 
  echo "<b><img src=\"../avatars/notok.gif\" alt=\"x\"/><br/>Error!!!!!<br/>Permission Denied...</b><br/>";
  echo "<br/>U Cannot Delete $user<br/>";echo "";
  }else{

  echo "<br/>";
  $res = mysql_query("DELETE FROM ibwff_todaylovers75 WHERE who='".$who."' OR uid='".$who."'");

  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>$user Loves Has Been Deleted Successfully!";
      $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Loves Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Loves Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='2', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Loves Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='4', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
  }
  echo "";
  }  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
//////////////////////////Delete Hates By CJ UDAY :)//////////////////////////

else if($action=="delhate")
{
  $who = $_GET["who"];
  $user = getnick_uid($who);echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $uid = getuid_sid($sid);
  $cyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE id='".$uid."'"));
  $trgtcyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE name='".$user."'"));

  if($trgtcyberpowereragon>$cyberpowereragon){ 
  echo "<b><img src=\"../avatars/notok.gif\" alt=\"x\"/><br/>Error!!!!!<br/>Permission Denied...</b><br/>";
  echo "<br/>U Cannot Delete $user<br/>";echo "";
  }else{

  echo "<br/>";
  $res = mysql_query("DELETE FROM ibwff_todayhaters76 WHERE who='".$who."' OR uid='".$who."'");

  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>$user Hates Has Been Deleted Successfully!";
      $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Hates Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Hates Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='2', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Hates Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='4', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
  }
  echo "";
  }  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
//////////////////////////Delete Misses By CJ UDAY :)//////////////////////////

else if($action=="delmiss")
{
  $who = $_GET["who"];
  $user = getnick_uid($who);echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $uid = getuid_sid($sid);
  $cyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE id='".$uid."'"));
  $trgtcyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE name='".$user."'"));

  if($trgtcyberpowereragon>$cyberpowereragon){ 
  echo "<b><img src=\"../avatars/notok.gif\" alt=\"x\"/><br/>Error!!!!!<br/>Permission Denied...</b><br/>";
  echo "<br/>U Cannot Delete $user<br/>";echo "";
  }else{

  echo "<br/>";
  $res = mysql_query("DELETE FROM FROM ibwff_todaymissers77 WHERE who='".$who."' OR uid='".$who."'");

  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>$user Misses Has Been Deleted Successfully!";
      $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Misses Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Misses Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='2', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Misses Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='4', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
  }
  echo "";
  }  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
//////////////////////////Delete Gifts By CJ UDAY :)//////////////////////////

else if($action=="delgift")
{
  $who = $_GET["who"];
  $user = getnick_uid($who);echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $uid = getuid_sid($sid);
  $cyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE id='".$uid."'"));
  $trgtcyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE name='".$user."'"));

  if($trgtcyberpowereragon>$cyberpowereragon){ 
  echo "<b><img src=\"../avatars/notok.gif\" alt=\"x\"/><br/>Error!!!!!<br/>Permission Denied...</b><br/>";
  echo "<br/>U Cannot Delete $user<br/>";echo "";
  }else{

  echo "<br/>";
  $res = mysql_query("DELETE FROM ibwff_giftpointers61 WHERE gifterid='".$who."' OR who='".$who."'");

  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>$user Gifts Has Been Deleted Successfully!";
      $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Gifts Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Gifts Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='2', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Gifts Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='4', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
  }
  echo "";
  }  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
//////////////////////////Delete Clubs By CJ UDAY :)//////////////////////////

else if($action=="delclb")
{
  $who = $_GET["who"];
  $user = getnick_uid($who);echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $uid = getuid_sid($sid);
  $cyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE id='".$uid."'"));
  $trgtcyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE name='".$user."'"));

  if($trgtcyberpowereragon>$cyberpowereragon){ 
  echo "<b><img src=\"../avatars/notok.gif\" alt=\"x\"/><br/>Error!!!!!<br/>Permission Denied...</b><br/>";
  echo "<br/>U Cannot Delete $user<br/>";echo "";
  }else{

  echo "<br/>";

  $res = mysql_query("DELETE FROM ibwff_clubs WHERE owner='".$who."'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>$user Clubs Deleted Successfully!";
          $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Clubs Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Clubs Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='2', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Clubs Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='4', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
  }
  echo "";
  }  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
//////////////////////////Delete A User By CJ UDAY :)//////////////////////////

else if($action=="delu")
{
  $who = $_GET["who"];
if($_REQUEST['who'] =='1')
{
  echo "<card id=\"main\" title=\"Error!!!\">";
  echo "<p align=\"center\">";
  echo "<b>Unknown Error!!!</b><br/>Unknown Security By CJ UDAY :)<br/><br/>";
  echo "<a href=\"main.php?action=main&amp;sid=$sid&amp&clid=$clid&amp;who=$who\"><img src=\"../avatars/home.gif\" alt=\"\"/>Home</a>";
  echo "</p>";
  echo "</card>";
  echo "</html>";
  exit();
}else if($_REQUEST['who'] =='2')
{
  echo "<card id=\"main\" title=\"Error!!!\">";
  echo "<p align=\"center\">";
  echo "<b>Unknown Error!!!</b><br/>Unknown Security By CJ UDAY :)<br/><br/>";
  echo "<a href=\"main.php?action=main&amp;sid=$sid&amp&clid=$clid&amp;who=$who\"><img src=\"../avatars/home.gif\" alt=\"\"/>Home</a>";
  echo "</p>";
  echo "</card>";
  echo "</html>";
  exit();
}else if($_REQUEST['who'] =='3')
{
  echo "<card id=\"main\" title=\"Error!!!\">";
  echo "<p align=\"center\">";
  echo "<b>Unknown Error!!!</b><br/>Unknown Security By CJ UDAY :)<br/><br/>";
  echo "<a href=\"main.php\"><img src=\"../avatars/home.gif\" alt=\"\"/>Home</a>";
  echo "</p>";
  echo "</card>";
  echo "</html>";
  exit();
}else if($_REQUEST['who'] =='4')
{
  echo "<card id=\"main\" title=\"Error!!!\">";
  echo "<p align=\"center\">";
  echo "<b>Unknown Error!!!</b><br/>Unknown Security By CJ UDAY :)<br/><br/>";
  echo "<a href=\"main.php\"><img src=\"../avatars/home.gif\" alt=\"\"/>Home</a>";
  echo "</p>";
  echo "</card>";
  echo "</html>";
  exit();
}
  $user = getnick_uid($who);
  echo "<card id=\"main\" title=\"President Tools\">";
  echo "<p align=\"center\">";
  $uid = getuid_sid($sid);
  $cyberpowereragon = mysql_fetch_array(mysql_query("SELECT soktiman FROM ibwff_users WHERE id='".$uid."'"));
  $trgtcyberpowereragon = mysql_fetch_array(mysql_query("SELECT soktiman FROM ibwff_users WHERE name='".$user."'"));

  if($trgtcyberpowereragon>$cyberpowereragon){ 
  echo "<b><img src=\"../avatars/notok.gif\" alt=\"x\"/><br/>Error!!!!!<br/>Permission Denied...</b><br/>";
  echo "<br/>U Cannot Delete $user<br/>";
  echo "<a href=\"home.php\"><img src=\"../avatars/home.gif\" alt=\"\"/>Home</a>";
  echo "</p>";
  }else{

  echo "<br/>";
  $res = mysql_query("DELETE FROM couple WHERE who='".$who."' OR partner='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_buddies WHERE tid='".$who."' OR uid='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_gbook WHERE gbowner='".$who."' OR gbsigner='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_ignore WHERE name='".$who."' OR target='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_mangr WHERE uid='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_givelove WHERE uid='".$who."' OR who='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_givehate WHERE uid='".$who."' OR who='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_miss WHERE uid='".$who."' OR who='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_todaylovers75 WHERE uid='".$who."' OR who='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_todayhaters76 WHERE likedid='".$who."' OR likerid='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_todaymissers77 WHERE uid='".$who."' OR who='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_giftpointers61 WHERE gifterid='".$who."' OR who='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_modr WHERE name='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_polls WHERE uid='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_penalties WHERE uid='".$who."' OR exid='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_posts WHERE uid='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_storyposts WHERE uid='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_notifications WHERE touid='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_private WHERE byuid='".$who."' OR touid='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_popups WHERE byuid='".$who."' OR touid='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_shouts WHERE shouter='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_status WHERE uid='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_shcomments WHERE uid='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_like WHERE uid='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_dislike WHERE uid='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_coverpicom11 WHERE uid='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_coverpiclike12 WHERE uid='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_coverpiclike12 WHERE uid='".$who."'"); 
  $res = mysql_query("DELETE FROM ibwff_pfpicom61 WHERE uid='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_pfpiclike62 WHERE uid='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_pfpicdislike63 WHERE uid='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_scomments WHERE uid='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_topics WHERE authorid='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_storys WHERE authorid='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_brate WHERE uid='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_bcomments WHERE uid='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_games WHERE uid='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_presults WHERE uid='".$who."'");
  //$res = mysql_query("DELETE FROM ibwff_vault WHERE uid='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_blogs WHERE bowner='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_chat WHERE chatter='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_chat WHERE who='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_clubs WHERE owner='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_clubmembers WHERE uid='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_chonline WHERE uid='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_online WHERE userid='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_ses WHERE uid='".$who."'");
  $res = mysql_query("DELETE FROM ibwff_xinfo WHERE uid='".$who."'");
  deleteMClubs($who);
  $res = mysql_query("DELETE FROM ibwff_users WHERE id='".$who."'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>$user Deleted Successfully!";
   $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Account Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Account Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='2', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Account Has Been Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='4', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
  }
  echo "<br/><a href=\"ownrcp.php?clid=$clid&who=$who\">President Tools</a><br/>";
  echo "<a href=\"main.php\"><img src=\"../avatars/home.gif\" alt=\"\"/>Home</a>";
  }
  echo "</p></card>";
}
//////////////////////////Delete Ignored By CJ UDAY :)//////////////////////////

else if($action=="delshout")
{
  $who = $_GET["who"];
  $user = getnick_uid($who);echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Delete!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  $uid = getuid_sid($sid);
  $cyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE id='".$uid."'"));
  $trgtcyberpowereragon = mysql_fetch_array(mysql_query("SELECT cyberpowereragon FROM ibwff_users WHERE name='".$user."'"));

  if($trgtcyberpowereragon>$cyberpowereragon){ 
  echo "<b><img src=\"../avatars/notok.gif\" alt=\"x\"/><br/>Error!!!!!<br/>Permission Denied...</b><br/>";
  echo "<br/>U Cannot Delete $user<br/>";echo "";
  }else{

  echo "<br/>";
  
   $res = mysql_query("DELETE FROM ibwff_shouts WHERE shouter='".$who."'");

  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>$user Shouts Has Been Deleted Successfully!";
  $tm = time();
		$uid = getuid_sid($sid);
$nick = getnick_uid($uid);
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Shouts Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='1', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Shouts Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='2', timesent='".$tm."'");
 mysql_query("INSERT INTO ibwff_notifications SET text='[b]Special CID Report:[/b][br/][user=$who][b]".$user."[/b][/user] Shouts Deleted By [user=$uid][b]".getnick_uid(getuid_sid($sid)).""."[/user][/b]', touid='4', timesent='".$tm."'");
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Error!!!";
  }
  echo "";
  }  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
//>>>>>>>>>>>>>>>>>>>>>>>>.................End.............<<<<<<<<<<<<<<<<<<<<<<\\
?>
</html>