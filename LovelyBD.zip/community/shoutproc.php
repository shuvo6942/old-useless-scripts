<?php
session_start();
include("config.php");
include("core.php");
connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo "<head>";
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
##SH0UTBOX C0D3Z PR0VIDED & DESIGN3D BY Shahos :-)
echo "<body><meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG : Don't Try To Hack OR else :P\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"main,all,follow\"/></head>";
echo "<body>";
$action = $_GET["action"]; $sid = $_SESSION["sid"];
$clid = $_GET["clid"]; $action = $_GET["action"];
$page = $_GET["page"];
$who = $_GET["who"];
$uid = getuid_sid($sid);
$sitename = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='sitename'"));
$sitename = $sitename[0];
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
echo "<head>";
echo "<title>Error!!!</title>";
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\"/>";
echo "</head>";
echo "<body>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
echo "<br/>";
echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
$banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
$remain =  $banto[0] - time();
$rmsg = gettimemsg($remain);
echo "<b>Time Remaining: $rmsg</b><br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "</p>";
echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
echo "<img src=\"../images/user.png\" alt=\"user\"><b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
echo "<img src=\"../images/pass.png\" alt=\"pass\"><b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"Styles.css\"/>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<img src=\"../images/user.png\" alt=\"user\"><b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<img src=\"../images/pass.png\" alt=\"pass\"><b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"left\">";
include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\"/>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"left\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<img src=\"../images/user.png\" alt=\"user\"><b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<img src=\"../images/pass.png\" alt=\"pass\"><b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "<div class=\"div align=\"center\">Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\"/>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please Contact <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(isdeactivated(getuid_sid($sid), $uid))
{
echo "<head>";
echo "<title>Error!!!</title>";
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\"/>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<br/><b>Your Account Has Been Deactivated.<br/>And It Will Be Never Activated Again!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
//////////////////////////Like Shout :)
else if($action=="like")
{
  $brate = $_POST["brate"];
  $who = $_GET["who"];
$shid = $_GET['shid'];
  addonline(getuid_sid($sid),"Liking Shout","main.php?action=main");
   	    echo "<head>";
    echo "<title>Like Shout</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
			echo "<b>Like Shout</b></div>";
  echo "<div class=\"shout2\" align=\"left\">";
  $vb = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_like WHERE uid='".$uid."' AND shoutid='".$shid."'"));
  if($vb[0]==0)
  {
    $res = mysql_query("INSERT INTO ibwff_like SET uid='".$uid."', shoutid='".$shid."', lrate='".$brate."'");
    if($res)
    {
		$re2 = mysql_fetch_array(mysql_query("SELECT shout FROM ibwff_shouts WHERE id='".$shid."'"));
		$shtname = htmlspecialchars($re2[0]); 
       echo "<br/><img src=\"ok.gif\" alt=\"o\"/>Shout Liked Successfully!<br/><br/><img src=\"../avatars/next.gif\" alt=\"<\"/><a href=\"shcomments.php?shid=$shid\">View $shtname Comments</a><br/><br/><img src=\"../avatars/prev.gif\" alt=\"<\"/><a href=\"shouts.php?action=shouts\">Shoutbox</a><br/><br/>";
		$res2 = mysql_fetch_array(mysql_query("SELECT shout,shouter FROM ibwff_shouts WHERE id='".$shid."'"));
	    $liker = getnick_sid($sid);
		$shtname = htmlspecialchars($res2[0]);
$shouter = getnick_uid($res2[1]);
mysql_query("INSERT INTO ibwff_notifications SET text='Your Shout [shoutlik=$shid]$shtname"."[/shoutlik] Has Been Liked By [user=$uid]$liker"."[/user]', touid='".$res2[1]."', timesent='".time()."'");
   }else{
        echo "<br/><img src=\"../avatars/notok.gif\" alt=\"x\"/>Unknown Error!!!<br/><br/>";
    }
  }else{
    echo "<br/><img src=\"../avatars/notok.gif\" alt=\"x\"/>You Have Liked This Shout Before!<br/><br/>";
  }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
//////////////////////////Dislike Shout :)
else if($action=="dislike")
{
  $brate = $_POST["brate"];
  $who = $_GET["who"];
$shid = $_GET['shid'];
  addonline(getuid_sid($sid),"Disliking Shout","main.php?action=main");
   	    echo "<head>";
    echo "<title>Dislike A Shout</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
echo "<b>Dislike Shout</b></div>";
  echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
  $vb = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_dislike WHERE uid='".$uid."' AND shoutid='".$shid."'"));
  if($vb[0]==0)
  {
    $res = mysql_query("INSERT INTO ibwff_dislike SET uid='".$uid."', shoutid='".$shid."', lrate='".$brate."'");
    if($res)
    {
        		$re2 = mysql_fetch_array(mysql_query("SELECT shout FROM ibwff_shouts WHERE id='".$shid."'"));
		$shtname = htmlspecialchars($re2[0]); 
       echo "<br/><img src=\"ok.gif\" alt=\"o\"/>Shout Disliked Successfully!<br/><br/><img src=\"../avatars/next.gif\" alt=\"<\"/><a href=\"shcomments.php?shid=$shid\">View $shtname Comments</a><br/><br/><img src=\"../avatars/prev.gif\" alt=\"<\"/><a href=\"shouts.php?action=shouts\">Shoutbox</a><br/><br/>";
				$res2 = mysql_fetch_array(mysql_query("SELECT shout,shouter FROM ibwff_shouts WHERE id='".$shid."'"));
	    $disliker = getnick_sid($sid);
		$shtname = htmlspecialchars($res2[0]);
$shouter = getnick_uid($res2[1]);
mysql_query("INSERT INTO ibwff_notifications SET text='Your Shout [shoutlik=$shid]$shtname"."[/shoutlik] Has Been Disliked By [user=$uid]$disliker"."[/user]', touid='".$res2[1]."', timesent='".time()."'");
}else{
        echo "<br/><img src=\"../avatars/notok.gif\" alt=\"x\"/>Unknown Error!!!<br/><br/>";
    }
  }else{
    echo "<br/><img src=\"../avatars/notok.gif\" alt=\"x\"/>You Have Disliked this Shout Before!<br/><br/>";
  }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="shout")
{
$uid=getuid_sid($sid); 
$clid=(int) $_GET['clid']; 
$shtxt = $_POST["shtxt"];
if(strlen($shtxt)<14)
{
echo "<head>";
echo "<title>Shout</title>";
  echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"".bosshira_themes()."\">";
  echo "</head>"; 
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
		echo "</div>";
	echo "<div class=\"header\" align=\"center\"><b>Shout</b></div>";
	echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
      echo "Blank or short shout.<br/><br/>";
    echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php?action=main\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
exit();
}
addonline(getuid_sid($sid),"Shouting","");
echo "<head>";
echo "<title>Shouting</title>";
  echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"".bosshira_themes()."\">";
  echo "</head>"; 
        echo "<body>";
        echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>ShoutBox</b></div>";
$pu = mysql_fetch_array(mysql_query("SELECT pu FROM ibwff_users WHERE id='".$uid."'"));
if($pu[0]>0)
{
$p = "0";
}else{
$p = spoint();
}
$a="1";
echo "<div class=\"shout2\" align=\"left\">";
$uid=getuid_sid($sid);
if($clid>0) 
{
$clubx="Club";
}else{
$clubx="";
}
if($a=="2")
{
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>You should have at least 50 $clubx points to shout!<br/><br/>";
    echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
exit();
}
$q =mysql_fetch_assoc(mysql_query("SELECT shtime FROM ibwff_shouts ORDER BY id DESC LIMIT 1"));
$st=$q['shtime'];
$now=time();
$dif=$now - $st;
$wait= 30 - $dif;
if($dif<'30')
{
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>A shout has been added recently.<br/>So you have to wait $wait seconds to add your [shout={$shid}] Shout[/shout]!<br/><br/>";
    echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
exit();
}
if(istrashed(getuid_sid($sid)))
{
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Unknown error cannot shout!<br/>please try again later...<br/><br/>";
    echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
exit();
}
$shtm = time();
$postxt = parsepm($shtxt,$sid);
$nrom = substr_count($postxt,"<img src=");
if($nrom>3){
echo "<b>WARNING</b><br/> You can use only 3 smiles on one shout.<br/><br/>";
   echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
exit();
}
    $shoutban = mysql_fetch_array(mysql_query("SELECT shoutban FROM ibwff_users WHERE id='".$uid."'"));
if ($shoutban[0]>0) {
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>";
echo "You're Shout Banned!<br/><br/>";
}else{
$clid=(int) $clid;
$res = mysql_query("INSERT INTO ibwff_shouts SET shout='".$shtxt."', shouter='".$uid."', shtime='".$shtm."', clubid=$clid");
if($res)
{
$shts = mysql_fetch_array(mysql_query("SELECT shouts from ibwff_users WHERE id='".$uid."'"));
$shts = $shts[0]+1;
mysql_query("UPDATE ibwff_users SET shouts='".$shts."' WHERE id='".$uid."'");
$cow = mysql_fetch_array(mysql_query("SELECT plusses FROM ibwff_users WHERE id='".$uid."'"));
$cow = $cow[0]-$p;
mysql_query("UPDATE ibwff_users SET plusses='".$cow."' WHERE id='".$uid."'");
$f = "[b]Subscribe Notification:[/b] ".subnick(getnick_uid($uid))." have make a shout.";
subnot_uday($uid, $f);
echo "<img src=\"ok.gif\" alt=\"O\"/>Shout added successfully<br/>Shout Cost $p Points<br/><br/>";
echo "<img src=\"../avatars/next.gif\" alt=\"<\"><a href=\"shcomments.php?shid=$shid\">View Shout Comments</a><br/><br/><img src=\"../avatars/prev.gif\" alt=\"<\"><a href=\"shouts.php\">Shoutbox</a><br/>";
}else{
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>";
echo "Can't Post Shout Message<br/>Your Are Logged Out<br/>";
$user = getnick_sid($sid);
mysql_query("INSERT INTO ibwff_mlog SET action='autoban', details='SupeR_GirL auto banned $user for spamming shoutbox', actdt='".time()."'");
mysql_query("INSERT INTO ibwff_penalties SET uid='".$uid."', penalty='1', exid='2', timeto='".$bantime."', pnreas='Banned: Auto Ban for spamming for a crap site'");
mysql_query("UPDATE ibwff_users SET plusses='0', shield='0' WHERE id='".$uid."'");
mysql_query("DELETE FROM ibwff_ses WHERE uid='".$uid."'");
		$ibwf = time()+6*60*60;
$nick = getnick_uid($uid);
mysql_query("insert into ibwff_events (event,time) values ('<b>$nick</b> try to spam in <b>Shout</b>','$ibwf')");
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
}
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
}
?>