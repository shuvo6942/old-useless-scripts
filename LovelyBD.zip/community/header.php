<?php
$xid = getuid_sid($sid);
$umsg = getunreadpm(getuid_sid($sid));
$notify = notification(getuid_sid($sid));
$chs = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_chonline"));
echo " <div class=\"tab\"><a href=\"main.php\">Menu</a> ";
echo " <a href=\"profile.php?who=$xid\">Profile</a> ";
echo " <a href=\"notification.php\">Notifications($notify)</a> ";
echo " <a href=\"inbox.php\">Messages($umsg)</a> ";
//echo "<a href=\"mailbox.php\">Emails(0)</a> ";
echo " <a href=\"ch@t.php?action=chat\">Chat($chs[0])</a></div>";
?>