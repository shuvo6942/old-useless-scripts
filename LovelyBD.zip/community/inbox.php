<?php
session_start();
include("config.php");
include("core.php");  connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo '<head>';
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"title\" content=\"firebd.net\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From Shahos : Don't Try To Hack OR else :P\">
<meta name=\"keywords\" content=\"Site Desined By Shahos :) :)\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/></head>";
echo "<body>";
##INB0X MESS3G3S IS 100% CR3AT3D & S3CURED BY Shahos :-)
$sid = $_SESSION["sid"];
$page = $_GET["page"];
$who = $_GET["who"];
$pmid = $_GET["pmid"];
$whonick = getnick_uid($who);
$byuid = getuid_sid($sid);
$uid = getuid_sid($sid);
$action = $_GET["action"];
$sitename = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='sitename'"));
$sitename = $sitename[0];
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();
////////////////Ip Banned By CJ UDAY :)	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
echo "<head>";
echo "<title>Error!!!</title>";
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\"/>";
echo "</head>";
echo "<body>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
echo "<br/>";
echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
$banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
$remain =  $banto[0] - time();
$rmsg = gettimemsg($remain);
echo "<b>Time Remaining: $rmsg</b><br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "</p>";
echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
$uid = getuid_sid($sid);
//////////////////Banned System Updated By CJ UDAY :)
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\"/>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please Contact <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\"/>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php"); 
echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\"/>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
///////////////////Deactivated Account By CJ UDAY :)
          if(isdeactivated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\"/>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  <b>Your Account Has Been Deactivated Forever.<br/>And It Will Be Never Activate!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
///////////////////Validation By CJ UDAY :)
					if(isvalidated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\"/>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
           echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  You Are Not Validated!<br/>We are checking your ip and browser<br/>
	  This could take up to 15 munites pls be patient and try again soon<br/>Please try again later...<br/><b>Thank You</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
/////////////////////Inbox Updated By CJ UDAY :)
if($action=="sendpm")
{
 $whonick = getnick_uid($who);
$pminfo = mysql_fetch_array(mysql_query("SELECT text, byuid, timesent,touid, reported FROM ibwff_private WHERE id='".$pmid."'"));
addonline(getuid_sid($sid),"Sending Messege","inbox.php");
 	    echo "<head>";
    echo "<title>Compose Messege</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
      echo "<div class=\"header\" align=\"center\">";
	echo "<b>Compose Messages</b></div>";
    echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<form action=\"inbxproc.php?action=uday\" method=\"post\">";
 echo "<b>User:</b><br/><input name=\"who\" format=\"*x\" maxlength=\"15\"/><br/>";
  echo "<b>Message:</b><br/><input name=\"pmtext\" maxlength=\"500\"/><br/>";
  echo "<input type=\"submit\" value=\"Send\">";
$tmsg = getpmcount($uid);
 echo "</form><br/><img src=\"../avatars/prev.gif\" alt=\"<\"><a href=\"inbox.php\">Inbox Messages</a> [$umsg/$tmsg]<br/><br/>";
$outbox = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_private WHERE byuid='".$uid."'"));
echo "<img src=\"../avatars/next.gif\" alt=\"&#187;\"> <a href=\"inbox.php?view=snt\">Outbox Messages</a> [$umsg/$outbox[0]]<br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="")
{
  $whonick = getnick_uid($who);
addonline(getuid_sid($sid),"Viewing Messages","inbox.php?action=$action");
	    echo "<head>";
    echo "<title>View Messages</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
  $count = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users a INNER JOIN ibwff_private b ON a.id = b.byuid WHERE b.touid='".$myid."' AND b.starred='1'"));
    $view = $_GET["view"];
   if($view=="")$view="all";
    if($page=="" || $page<=0)$page=1;
    $myid = getuid_sid($sid);
    $doit=false;
    $num_items = getpmcount($myid,$view);
    $items_per_page= 7;
    $num_pages = ceil($num_items/$items_per_page);
    if($page>$num_pages)$page= $num_pages;
    $limit_start = ($page-1)*$items_per_page;
    if($num_items>0)
    {
      if($doit)
      {
        $exp = "&amp;rwho=$myid";
      }else{
        $exp = "";
      }
    if($view=="all")
  {
    $sql = "SELECT
            a.name, b.id, b.byuid, b.unread, b.starred FROM ibwff_users a
            INNER JOIN ibwff_private b ON a.id = b.byuid
            WHERE b.touid='".$myid."' AND starred='0'
            ORDER BY b.timesent DESC
            LIMIT $limit_start, $items_per_page
    ";
  }else if($view=="snt")
  {
    $sql = "SELECT
            a.name, b.id, b.touid, b.unread, b.starred FROM ibwff_users a
            INNER JOIN ibwff_private b ON a.id = b.touid
            WHERE b.byuid='".$myid."'
            ORDER BY b.timesent DESC
            LIMIT $limit_start, $items_per_page
    ";
  }else if($view=="str")
  {
    $sql = "SELECT
            a.name, b.id, b.byuid, b.unread, b.starred FROM ibwff_users a
            INNER JOIN ibwff_private b ON a.id = b.byuid
            WHERE b.touid='".$myid."' AND b.starred='1'
            ORDER BY b.timesent DESC
            LIMIT $limit_start, $items_per_page
    ";
  }else if($view=="urd")
  {
    $sql = "SELECT
            a.name, b.id, b.byuid, b.unread, b.starred FROM ibwff_users a
            INNER JOIN ibwff_private b ON a.id = b.byuid
            WHERE b.touid='".$myid."' AND b.unread='1'
            ORDER BY b.timesent DESC
            LIMIT $limit_start, $items_per_page
    ";
  }
echo "<div class=\"header\" align=\"center\">";
if($view=="all")
{
echo "<b>Inbox Messages</b></div>";
}else if($view=="snt")
{
echo "<b>Outbox Messages</b></div>";
}else if($view=="str")
{
echo "<b>Archived Messages</b></div>";
}
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
    $items = mysql_query($sql);
   while ($item = mysql_fetch_array($items))
    {
      if($item[3]=="1")
      {
        $iml = "<img src=\"../avatars/unread.gif\" alt=\"New!\"/> ";
      }else{
        if($item[4]=="1")
        {
            $iml = "<img src=\"../avatars/acrived.gif\" alt=\"*\"/> ";
        }else{
        $iml = "<img src=\"../avatars/read.gif\" alt=\"Old!\"/> ";
        }
      }
	  $pminfo = mysql_fetch_array(mysql_query("SELECT text FROM ibwff_private WHERE id='".$item[1]."'"));
	  $pmtext = htmlspecialchars($pminfo[0]);
	  $pmdet = substr($pmtext,0,15);
	  $text = parsepm($pmdet, $sid);
	  $neciti = mysql_fetch_array(mysql_query("SELECT unread FROM ibwff_private WHERE id='".$item[1]."'"));
      if($neciti[0]==1){
       $pmex = "<small><i>$text .....</i></small>";
	   }else{
	   $pmex = "<small><i>$text .....</i></small>";
      }
      if($lastloc=="cht"){
      $lnk = "$iml <a href=\"inbox.php?action=readpm&pmid=$item[1]&lstloc=cht&rid=$rid\">$item[0]</a> $pmex";
	}else{
	      $lnk = "$iml<a href=\"inbox.php?action=readpm&pmid=$item[1]\"> $item[0]</a> $pmex";
	}
      echo "$lnk<br/>";
    }
    echo "<p align=\"left\">";
    if($page>1)
    {
      $ppage = $page-1;
      echo "<a href=\"inbox.php?action=$action&amp;page=$ppage&view=$view\">&#171;-Prev</a> ";
    }
    if($page<$num_pages)
    {
      $npage = $page+1;
      echo "<a href=\"inbox.php?action=$action&page=$npage&view=$view\">Next-&#187;</a>";
    }
	echo "<br/>";
		  echo "<small>Page - $page/$num_pages</small>";
   if($num_pages>2)
    {
		$rets = "<form action=\"inbox.php\" method=\"get\">";
        $rets .= "<input name=\"page\" style=\"-wap-input-format: '*N'\" size=\"2\"/>";
        $rets .= "<input type=\"hidden\" name=\"action\" value=\"$action\"/>";
        $rets .= "<input type=\"hidden\" name=\"sid\" value=\"$sid\"/>";
        $rets .= "<input type=\"hidden\" name=\"view\" value=\"$view\"/>";
   $rets .= "<input type=\"submit\" value=\"Go To Page\"/>";
        $rets .= "</form>";
        echo $rets;
    }
    echo "</p>";
    }else{
	echo "<div class=\"header\" align=\"center\">";
	echo "<b>Inbox Messages</b></div>";
	echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
	    if($view=="all")
  {
    echo "You Have No Inbox Messages!<br/>";
}else if($view=="snt")
	{
	echo "You Have No Outbox Messages!<br/>";
	  }else if($view=="str")
	  {
	  echo "You Have No Archived Messages!<br/>";
	  }
	  }
echo "<p align=\"left\">";
    if($view=="all")
  {
echo "&#187; <a href=\"inbox.php?action=$action\">Refresh</a><br/>";
echo "&#187; Delete: <a href=\"inbxproc.php?action=all\">All</a> | <a href=\"inbxproc.php?action=read\">Read</a> | <a href=\"inbxproc.php?action=unread\">Unread</a><br/>";
echo "&#187; <a href=\"inbox.php?action=sendpm\">Send New Message</a><br/>";
$umsg = getunreadpm(getuid_sid($sid));
$outbox = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_private WHERE byuid='".$uid."'"));
echo "&#187; <a href=\"inbox.php?view=snt\">Outbox Messages</a> [$umsg/$outbox[0]]<br/>";
$starred = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_private WHERE touid='".$uid."' AND starred='1'"));
echo "&#187; <a href=\"inbox.php?action=$action&view=str\">Archived Messages</a> [$starred[0]]<br/>";
  }else if($view=="snt")
  {
echo "&#187; <a href=\"inbox.php?action=sendpm\">Send New Message</a><br/>";
$tmsg = getpmcount(getuid_sid($sid));
$umsg = getunreadpm(getuid_sid($sid));
echo "&#187; <a href=\"inbox.php?view=all\">Inbox Messages</a> [$umsg/$tmsg]<br/>";
$starred = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_private WHERE touid='".$uid."' AND starred='1'"));
echo "&#187; <a href=\"inbox.php?view=str\">Archived Messages</a> [$starred[0]]<br/>";
  }else if($view=="str")
  {
echo "&#187; <a href=\"inbox.php?action=sendpm\">Send New Message</a><br/>";
$tmsg = getpmcount(getuid_sid($sid));
$umsg = getunreadpm(getuid_sid($sid));
echo "&#187; <a href=\"inbox.php?view=all\">Inbox Messages</a> [$umsg]<br/>";
$umsg = getunreadpm(getuid_sid($sid));
$outbox = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_private WHERE byuid='".$uid."'"));
echo "&#187; <a href=\"inbox.php?view=snt\">Outbox Messages</a> [$umsg/$outbox[0]]<br/>";
  }
echo "</p>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
/////////////////////////////////Froward Message By CJ UDAY :)
else if($action=="forward")
{
$pmid = $_GET["pmid"];
$name = $_POST["name"];
    echo "<head>";
    echo "<title>Forwarding Message</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
			echo "<b>Forward Message</b></div>";
		echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
		echo "<br/>";
$pminfo = mysql_fetch_array(mysql_query("SELECT text, byuid, timesent,touid, reported FROM ibwff_private WHERE id='".$pmid."'"));
$txt = parsepm($pminfo[0], $sid);
echo "<b>Message: </b><br/>";
echo "$txt<br/><br/>";
echo "<b>Username:</b><br/>";
echo "<form action=\"inbxproc.php?action=forwordpm&pmid=$pmid\" method=\"post\">";
echo "<input name=\"name\" maxlength=\"500\"/><br/>";
echo " <input type=\"submit\" value=\"Send\"/>";
echo "</form><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="readpm")
{
$pminfo = mysql_fetch_array(mysql_query("SELECT text, byuid, timesent,touid, reported FROM ibwff_private WHERE id='".$pmid."'"));
$who = $_GET["who"];
$whnick = getnick_uid($who); 
addonline(getuid_sid($sid),"Reading Messages","inbox.php?action=$action");  
echo "<head>";
echo "<title>Reading Messages</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
       echo "<div class=\"header\" align=\"center\">";
	echo "<b>Read Message</b></div>";
    echo "<div class=\"shout2\" align=\"left\">";
  $pminfo = mysql_fetch_array(mysql_query("SELECT text, byuid, timesent,touid, reported FROM ibwff_private WHERE id='".$pmid."'"));
  if(getuid_sid($sid)==$pminfo[3])
  {
    $chread = mysql_query("UPDATE ibwff_private SET unread='0' WHERE id='".$pmid."'");
  }
  if(($pminfo[3]==getuid_sid($sid))||($pminfo[1]==getuid_sid($sid)))
  {
  if(getuid_sid($sid)==$pminfo[3])
  {
include("pm_by.php");
if(isonline($pminfo[1]))
  {
    $iml = "<img src=\"../avatars/onl.gif\">";
  }else{
    $iml = "<img src=\"../avatars/ofl.gif\">";
  }
	    $sql = "SELECT name FROM ibwff_users WHERE id=$pminfo[1]";
	    $sql2 = mysql_query($sql);
	    $item = mysql_fetch_array($sql2);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item[0]'"));
if($sex[0]=="M"){$icon = "<img src=\"../avatars/male.gif\" alt=\"M\"/>";}
if($sex[0]=="F"){$icon = "<img src=\"../avatars/female.gif\" alt=\"F\"/>";}
if($sex[0]==""){$icon = "";}
        		$avlink = getavatar($pminfo[1]);
if($avlink=="")
{
 $avt =  "$icon";
}else{
 $avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"icon\" width=\"18\" hieght=\"23\"/>";
}
	    $sql3 = "SELECT name FROM ibwff_users WHERE id=$pminfo[1]";
	    $sql33 = mysql_query($sql3);
	    $item3 = mysql_fetch_array($sql33);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nicks = "<font color=\"blue\">".getnick_uid($pminfo[1])."</font>";}
if($sex[0]=="F"){$nicks = "<font color=\"deeppink\">".getnick_uid($pminfo[1])."</font>";}
if($sex[0]==""){$nicks = "";}
    $ptxt = "Message By ";
        $bylnk = "$iml$avt <a href=\"profile.php?who=$pminfo[1]\">$nicks</a> (".getstatus($pminfo[1]).")";
  }
  }
  }else{
  if(isonline($pminfo[3]))
  {
    $iml = "<img src=\"../avatars/onl.gif\">";
  }else{
    $iml = "<img src=\"../avatars/ofl.gif\">";
  }
	    $sql2 = "SELECT name FROM ibwff_users WHERE id=$pminfo[3]";
	    $sql22 = mysql_query($sql2);
	    $item2 = mysql_fetch_array($sql22);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item2[0]'"));
if($sex[0]=="M"){$icon2 = "<img src=\"../avatars/male.gif\" alt=\"M\"/>";}
if($sex[0]=="F"){$icon2 = "<img src=\"../avatars/female.gif\" alt=\"F\"/>";}
if($sex[0]==""){$usersex = "";}
       		$avlink = getavatar($pminfo[3]);
if($avlink=="")
{
 $avt =  "$icon2";
}else{
 $avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"icon\" width=\"23\" hieght=\"18\"/>";
}
	    $sql3 = "SELECT name FROM ibwff_users WHERE id=$pminfo[3]";
	    $sql33 = mysql_query($sql3);
	    $item3 = mysql_fetch_array($sql33);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nicks = "<font color=\"blue\">".getnick_uid($pminfo[3])."</font>";}
if($sex[0]=="F"){$nicks = "<font color=\"deeppink\">".getnick_uid($pminfo[3])."</font>";}
if($sex[0]==""){$nicks = "";}
    $ptxt = "Message To: ";
    $bylnk = "<a href=\"profile.php?who=$pminfo[3]\">$iml$avt$nicks</a>(".getstatus($pminfo[3]).")";
   } 
  }
  }
  echo "$ptxt $bylnk<br/>";
  $tmstamp = $pminfo[2];
  $tremain = time()-$tmstamp;
  $tmdt = gettimemsg($tremain)." ago";
  echo "<b><small> ($tmdt) </small></b><br/><br/>";
  $pmtext = parsepm($pminfo[0], $sid);
    $pmtext = str_replace("/reader",getnick_uid($pminfo[3]), $pmtext);
    if(isspam($pmtext))
    {
      if(($pminfo[4]=="0") && ($pminfo[1]!=1))
      {
        mysql_query("UPDATE ibwff_private SET reported='1' WHERE id='".$pmid."'");
      }
    }
    echo $pmtext;
echo "<br/><br>";
		         $lastpmtxt = mysql_fetch_array(mysql_query("SELECT byuid, text, timesent FROM ibwff_private WHERE byuid='".$pminfo[3]."' AND touid='".$pminfo[1]."' ORDER BY timesent DESC LIMIT 0,1"));
     $lasttxt = parsepm($lastpmtxt[1], $sid);
	 $whonick = getnick_uid($pminfo[3]); 
  if ($pminfo[1]==3)
{
  echo "<form action=\"chatbot.php?action=sendpm&who=$pminfo[1]\" method=\"post\">";
  echo "<input name=\"pmtext\" maxlength=\"500\"/><br/>";
}else{
  echo "<form action=\"inbxproc.php?action=sendpm&who=$pminfo[1]\" method=\"post\">";
  echo "<input name=\"pmtext\" maxlength=\"500\"/><br/>";
}
  echo " <input type=\"submit\" value=\"Send\"/>";
echo "</form><br/><b>You Said</b>: $lasttxt<br/><br/>";
$umsg = getunreadpm(getuid_sid($sid));
$outbox = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_private WHERE byuid='".$uid."'"));
echo "&#187; <a href=\"inbox.php?action=conversation&who=$pminfo[1]\">Conversation</a> [$umsg/$outbox[0]]<br/>";
$pminfo = mysql_fetch_array(mysql_query("SELECT starred FROM ibwff_private WHERE id='".$pmid."'"));
if($pminfo[0]=="0")
{
echo "&#187; <a href=\"inbxproc.php?action=acr&pmid=$pmid\">Archive</a><br/>";
echo "<small>(to protect auto delete)</small><br/>";
}else{
echo "&#187; <a href=\"inbxproc.php?action=unacr&pmid=$pmid\">Unarchive</a><br/>";
}
echo "&#187; <a href=\"inbxproc.php?action=delpm&pmid=$pmid\">Delete</a><br/>";
echo "&#187; <a href=\"inbox.php?action=forward&pmid=$pmid\">Forward</a><br/>";
echo "&#187; <a href=\"inbxproc.php?action=rept&pmid=$pmid\">Report</a><br/>";
$tmsg = getpmcount(getuid_sid($sid));
$umsg = getunreadpm(getuid_sid($sid));
echo "<br/><img src=\"../avatars/prev.gif\" alt=\"&#171;\"> <a href=\"inbox.php?view=all\">Inbox Messages</a> [$umsg/$tmsg]<br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>This PM Isn't Yours!<br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
  }
}
else if($action=="conversation")
{
  addonline(getuid_sid($sid),"Viewing Conversations","inbox.php?action=main");
 	    echo "<head>";
    echo "<title>Conversion</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
       echo "<div class=\"header\" align=\"center\">";
$uid = getuid_sid($sid);
$unick = getnick_uid($uid);
$who = $_GET["who"];
$wnick = getnick_uid($who);
	echo "<b>Conversations Between $unick And $wnick</b></div>";
    echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
  if($page=="" || $page<=0)$page=1;
    $pms = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_private WHERE (byuid='".$uid."' AND touid='".$who."') OR (byuid='".$who."' AND touid='".$uid."') ORDER BY timesent"));
   $num_items = $pms[0];
    $items_per_page= 10;
    $num_pages = ceil($num_items/$items_per_page);
    if($page>$num_pages)$page= $num_pages;
    $limit_start = ($page-1)*$items_per_page;
    if($num_items>0)
    {
      echo "<p>";
      $pms = mysql_query("SELECT byuid, text, timesent FROM ibwff_private WHERE ((byuid=$uid AND touid=$who) OR (byuid=$who AND touid=$uid)) ORDER BY timesent ASC LIMIT $limit_start, $items_per_page");
      while($pm=mysql_fetch_array($pms))
      {
            if(isonline($pm[0]))
  {
    $iml = "<img src=\"../avatars/onl.gif\" alt=\" \"/>";
  }else{
    $iml = "<img src=\"../avatars/ofl.gif\" alt=\"-\"/>";
  }
	    $sql = "SELECT name FROM ibwff_users WHERE id=$pm[0]";
	    $sql2 = mysql_query($sql);
	    $item = mysql_fetch_array($sql2);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item[0]'"));
if($sex[0]=="M"){$icon = "<img src=\"../avatars/male.gif\" alt=\"M\"/>";}
if($sex[0]=="F"){$icon = "<img src=\"../avatars/female.gif\" alt=\"F\"/>";}
if($sex[0]==""){$icon = "";}
        		$avlink = getavatar($pm[0]);
if($avlink=="")
{
 $avt =  "$icon";
}else{
 $avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"icon\" width=\"18\" hieght=\"23\"/>";
}
	    $sql3 = "SELECT name FROM ibwff_users WHERE id=$pm[0]";
	    $sql33 = mysql_query($sql3);
	    $item3 = mysql_fetch_array($sql33);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nicks = "<font color=\"blue\">".getnick_uid($pm[0])."</font>";}
if($sex[0]=="F"){$nicks = "<font color=\"deeppink\">".getnick_uid($pm[0])."</font>";}
if($sex[0]==""){$nicks = "";}
  $bylnk = "$iml$avt<a href=\"profile.php?who=$pm[0]\">$nicks</a> :";
}
}
  $t = $pm[2] + (6*60*60);
  $tmopm = date("h:i A, D d M y",$t);
  echo "$tmopm<br/>";
  echo $bylnk;
        echo parsepm($pm[1], $sid);
  echo "<br/>--------------<br/>";
      }
   if($page>1)
    {
      $ppage = $page-1;
      echo "<a href=\"inbox.php?action=conferance&page=$ppage\">&#171;-Prev</a> ";
    }
    if($page<$num_pages)
    {
      $npage = $page+1;
      echo "<a href=\"inbox.php?action=conferance&page=$npage\">Next-&#187;</a>";
    }
    echo "<br/>Page - $page/$num_pages<br/>";
  if($num_pages>2)
    {
        $rets = "<form action=\"inbox.php\" method=\"get\">";
        $rets .= "<input name=\"page\" style=\"-wap-input-format: '*N'\" size=\"2\"/>";
        $rets .= "<input type=\"hidden\" name=\"action\" value=\"$action\"/>";
        $rets .= "<input type=\"hidden\" name=\"sid\" value=\"$sid\"/>";
        $rets .= "<input type=\"submit\" value=\"Go To Page\"/>";
        $rets .= "</form>";
        echo $rets;
    }
}else{
        echo "<p align=\"center\">";
        echo "NO DATA<br/><br/>";
      }
 if($who==3)
{
  echo "<form action=\"chatbot.php?action=sendpm&who=$who\" method=\"post\">";
  echo "<b>Reply:</b> <input name=\"pmtext\" maxlength=\"500\"/>";
}else{
  echo "<form action=\"inbxproc.php?action=sendpm&amp;who=$who\" method=\"post\">";
  echo "<b>Reply:</b> <input name=\"pmtext\" maxlength=\"500\"/>";
}
  echo " <input type=\"submit\" value=\"Send\"/><br/>";
echo "&#187; <a href=\"inbox.php?action=conversation&who=$who\">Refresh</a><br/><br/>";
$tmsg = getpmcount(getuid_sid($sid));
$umsg = getunreadpm(getuid_sid($sid));
echo "<img src=\"../avatars/prev.gif\" alt=\"&#171;\"> <a href=\"inbox.php?view=all\">Inbox Messages</a> [$umsg/$tmsg]<br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
?>
</html>