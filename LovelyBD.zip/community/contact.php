<?php
$start = microtime(true);
include("config.php");
include("core.php");  connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo '<head>';
echo "<title>Online Help Center</title>";
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"title\" content=\"Meghwap.Com\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From Meghwap: Don't Try To Hack OR else :P\">
<meta name=\"keywords\" content=\"Site Desined By Meghwap :) :)\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/></head>";
echo "<body>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"FireBD.png\" alt=\"FireBD.Com\" width=\"240\" height=\"40\"><br/>";
echo "<b>MyDhaka.Tk - Online Help Center (OHC)</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
echo "<b>Name:</b>Mehedi<br/><b>Rank Name:</b> Administrator!<br/><b>Rank Star:</b> <img src=\"../avatars/5-star.gif\" alt=\"5-star\"><br/><b>Phone:</b>01910170361<br/>[<i>Just Message Me.If seems necessity I will contact You $whonick</i>]<br/>Email:mehedihasan7700@gmail.com<br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
?>
</html>