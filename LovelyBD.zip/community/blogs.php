<?php
session_start();
include("config.php");
include("core.php");  connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo '<head>';
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"title\" content=\"FireBD.NeT\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From Megh: Don't Try To Hack OR else :P\">
<meta name=\"keywords\" content=\"Site Desined By Megh :) :)\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/>";
			$pm = mysql_fetch_array(mysql_query("SELECT bname, tags FROM ibwff_blogs WHERE id='".$bid."'"));
echo "<meta name=\"keywords\" content=\"$pm[1]\"></head>";
echo "<meta name=\"description\" content=\"$pm[0]\"></head>";
echo "<body>";
##BL0G IZ 100% CR3AT3D & S3CUR3D BY Megh! :-)
$action = $_GET["action"]; $sid = $_SESSION["sid"];
$clid = $_GET["clid"]; $page = $_GET["page"];
$who = $_GET["who"];
$whonick = getnick_uid($who);
$byuid = getuid_sid($sid);
$uid = getuid_sid($sid);
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();
////////////////Ip Banned By CJ UDAY :)	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
    	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
echo "<br/>";
echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
$banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
$remain =  $banto[0] - time();
$rmsg = gettimemsg($remain);
echo "<b>Time Remaining: $rmsg</b><br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "</p>";
echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
$uid = getuid_sid($sid);
//////////////////Banned System Updated By CJ UDAY :)
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please With Contact Us <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
/////////////////////Blogs Ban By CJ UDaY :)
  $ban = mysql_fetch_array(mysql_query("SELECT blogban FROM ibwff_users WHERE id='".$uid."'"));
if($ban[0] > 0)
  {
	echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
			 echo "<div class=\"header\" align=\"center\">";
			  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/><b><u><i>Can't ENTER To Blog<br/>";
  echo "You're Blog banned!</i></u></b><br/><br/>";
 echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php?action=main\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
    exit();
    }
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
 echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">"; 
include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
///////////////////Deactivated Account By CJ UDAY :)
          if(isdeactivated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  <b>Your Account Has Been Deactivated Forever.<br/>And It Will Be Never Activate!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
///////////////////Validation By CJ UDAY :)
					if(isvalidated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  You Are Not Validated!<br/>We are checking your ip and browser<br/>
	  This could take up to 15 munites pls be patient and try again soon<br/>Please try again later...<br/><b>Thank You</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
//////////////////////////////////Blogs Updated By CJ UDAY :)
if($action=="allbl")
{
    addonline(getuid_sid($sid),"Viewing Blogs","blogs.php?action=$action");
echo "<head>";
echo "<title>All Blogs</title>";
  echo "</head>"; 
		echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
		echo "</div>";
		echo "<div class=\"header\" align=\"center\">";
		echo "<b>Blogs</b></div>";
	echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
   if($page=="" || $page<=0)$page=1;
if($_REQUEST["clid"]>0)
{
    $noi = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_blogs WHERE clubid=$clid"));
}else{
$noi = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_blogs"));
}
    $num_items = $noi[0];
    $items_per_page= 10;
    $num_pages = ceil($num_items/$items_per_page);
    if(($page>$num_pages)&&$page!=1)$page= $num_pages;
    $limit_start = ($page-1)*$items_per_page;
if($_REQUEST["clid"]>0) {
  $sql = "SELECT id, bname, bowner FROM ibwff_blogs WHERE clubid='".$clid."' ORDER by bgdate DESC LIMIT $limit_start, $items_per_page";
}else{
 $sql = "SELECT id, bname, bowner, clubid FROM ibwff_blogs ORDER by bgdate DESC LIMIT $limit_start, $items_per_page";
}
  $items = mysql_query($sql);
   if(mysql_num_rows($items)>0)
    {
    while ($item = mysql_fetch_array($items))
    {
      $bname = htmlspecialchars($item[1]);
     $bonick = subnick(getnick_uid($item[2]));
	    $sql2 = "SELECT name FROM ibwff_users WHERE id=$item[2]";
	    $sql22 = mysql_query($sql2);
	    $item2 = mysql_fetch_array($sql22);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item2[0]'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/>";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/>";}
if($sex[0]==""){$usersex = "";}
        		$avlink = getavatar($item[2]);
if($avlink=="")
{
 $avt =  "$usersex";
}else{
 $avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"icon\" width=\"23\" height=\"18\"/>";
}
	    $sql3 = "SELECT name FROM ibwff_users WHERE id=$item[2]";
	    $sql33 = mysql_query($sql3);
	    $item3 = mysql_fetch_array($sql33);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nicks = "<font color=\"blue\"><b>$bonick</b></font>";}
if($sex[0]=="F"){$nicks = "<font color=\"deeppink\"><b>$bonick</b></font>";}
if($sex[0]==""){$nicks = "";}
        $byview = "By: $avt<a href=\"profile.php?who=$item[2]\">$nicks</a>";
		}
		}
					if (blogtval($item[0]))
	{
      $lnk = "Blog Name: <img src=\"../avatars/blogs.gif\"><a href=\"blogs.php?bid=$item[0]&clid=$clid\"><b>$bname</b></a><br/> $byview";
      echo "$lnk<br/><br/>";
	  }
	  	else
	{
if($clid>0)
{			
if(isownerclub($uid,$clid) || ismodclub($uid,$clid))
{
	echo "&#8226; Blog name: <b>$bname</b><br/>";
	    echo "&#8226; <a href=\"blogs.php?bid=$item[0]\"> Validate $bname</a><br/>";
	    echo "&#8226; <a href=\"delete.php?bid=$item[0]\"> Detete $bname</a><br/>";
}
}else{
if(blogboss($uid))
	{
	echo "&#8226; Blog name: <b>$bname</b><br/>";
	    echo "&#8226; <a href=\"blogs.php?bid=$item[0]\"> Validate $bname</a><br/>";
	    echo "&#8226; <a href=\"delete.php?bid=$item[0]\"> Detete $bname</a><br/>";
	}
	echo "-------<br/>";	
}
	}
    }
    }
    if($page>1)
    {
      $ppage = $page-1;
      echo "<a href=\"blogs.php?action=$action&amp;page=$ppage&clid=$clid\">&#171;-Prev</a> ";
    }
    if($page<$num_pages)
    {
      $npage = $page+1;
      echo "<a href=\"blogs.php?action=$action&amp;page=$npage&clid=$clid\">Next-&#47;</a>";
    }
    echo "<br/>Page - $page/$num_pages<br/>";
    if($num_pages>2)
      {
			        $rets = "<form action=\"blogs.php\" method=\"get\">";
        $rets .= "<input name=\"page\" style=\"-wap-input-format: '*N'\" size=\"2\"/>";
        $rets .= "<input type=\"hidden\" name=\"action\" value=\"$action\"/>";
        $rets .= "<input type=\"hidden\" name=\"sid\" value=\"$sid\"/>";
        $rets .= "<input type=\"hidden\" name=\"who\" value=\"$who\"/>";
        $rets .= "<input type=\"submit\" value=\"Go To Page\"/>";
        $rets .= "</form>";
        echo $rets;
    }echo "<a href=\"blogs.php?action=addblg&clid=$clid\">";
echo "<p align=\"left\">";
echo "&#187; <big>Create A New Blog</big></a><br/>";
echo "</p>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
///////////////////////////////view blog by CJ UDAY :-)
else if($action=="")
{
$bid = $_GET["bid"];
addonline(getuid_sid($sid),"Viewing A Blog","blogs.php?action=$action");
						if (!blogtval($bid))
	{
		echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
  echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
      echo "<br/>
	  This Blog is waiting for validation!<br/>Please try again later...<br/><b>Thank You</b><br/><br/>";
			if(blogboss($uid))
	{
	$fname = mysql_fetch_array(mysql_query("SELECT bname, btext, bowner FROM ibwff_blogs WHERE id='".$bid."'"));
	$bname = $fname[0];
	$btext = $fname[1];
	echo "&#8226; Blog name: <b>$bname</b><br/>";
		echo "&#8226; Blog Text:<br/> ".getbbcode($btext,$sid)."<br/>";
	echo "Created by: <a href=\"profile.php?who=$fname[2]\">".getnick_uid($fname[2])."</a><br/>";
	    echo "&#8226; <a href=\"validate.php?action=blog&bid=$bid\"> Validate $bname</a><br/>";
	    echo "&#8226; <a href=\"edit.php?action=blog&amp;sid=$sid&amp;bid=$bid\"> Edit $bname</a><br/>";
	    echo "&#8226; <a href=\"delete.php?action=blog&bid=$bid\"> Delete $bname</a><br/>";
	}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }   
    echo "<head>";
    echo "<title>Viewnig Blogs</title>";
			$pm = mysql_fetch_array(mysql_query("SELECT tags FROM ibwff_blogs WHERE id='".$bid."'"));
echo "<meta name=\"description\" content=\"$pm[0]\">";
    echo "</head>";
    echo "<body>";
	echo "<div class=\"mblock1\" align=\"left\">";
include("header.php"); 
         echo "</div>";
			$pminfo = mysql_fetch_array(mysql_query("SELECT btext, bname, bgdate,bowner, id, tags, uday_cat FROM ibwff_blogs WHERE id='".$bid."'"));
							echo "<div class=\"header\" align=\"center\">";
	echo "<b>View $pminfo[1] Blog</b></div>";
						echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$bttl = htmlspecialchars($pminfo[1]);
$btxt = parsemsg($pminfo[0], $sid);
$bnick = subnick(getnick_uid($pminfo[3]));
$vbbl = "<a href=\"profile.php?action=viewuser&who=$pminfo[3]&sid=$sid\">$bnick</a>";
$tmstamp = $pminfo[2];
$tmdt = date("l d M", $tmstamp);
	    $sql = "SELECT name FROM ibwff_users WHERE id=$pminfo[3]";
	    $sql2 = mysql_query($sql);
	    $item = mysql_fetch_array($sql2);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item[0]'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/>";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/>";}
if($sex[0]==""){$usersex = "";}
		$avlink = getavatar($pminfo[3]);
if($avlink=="")
{
 $avt =  "$usersex";
}else{
 $avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"icon\" width=\"23\" height=\"18\"/>";
}
 $sql3 = "SELECT name FROM ibwff_users WHERE id=$pminfo[3]";
	    $sql33 = mysql_query($sql3);
	    $item3 = mysql_fetch_array($sql33);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nick = "<font color=\"blue\"><b>$bnick</b></font>";}
if($sex[0]=="F"){$nick = "<font color=\"deeppink\"><b>$bnick</b></font>";}
if($sex[0]==""){$nick = "";}
echo "<b>Blog ID</b>: $bid<br/><b>Date</b>: $tmdt<br/><b>Tags:</b>$pminfo[5]<br/><b>Catagory:</b>$pminfo[6]<br/>";
echo "<b>By</b>: $avt$nick <br/><b>$pminfo[1]</b><br/><br/>$btxt<br/>";
}
}
echo "<br/>";
if((getuid_sid($sid))==$pminfo[3]  || blogboss(getuid_sid($sid)))
{
echo "[<a href=\"blogs.php?action=blgopt&bid=$bid\">+</a>]<br/>";
}
$rtr = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM uday_blgrate WHERE tid='".$bid."'"));
$rate = getblgrate($uid, $tid);
echo "<b>Rating:</b> $rate(<a href=\"blogs.php?action=raters&bid=$bid\">$rtr[0]</a>)<br/>";
$vb = mysql_fetch_array(mysql_query("SELECT rate FROM uday_blgrate WHERE uid='".$uid."' AND tid='".$bid."'"));
echo "<form action=\"blogproc.php?action=blgrate&bid=$bid\" method=\"post\">";
echo "<select name=\"rate\" value=\"$vb[0]\">";
echo "<option value=\"5\">Very Good</option>";
echo "<option value=\"4\">Good</option>";
echo "<option value=\"3\">Ok</option>";
echo "<option value=\"2\">Nice</option>";
echo "<option value=\"1\">Poor</option>";
echo "</select>";
echo "<input type=\"hidden\" name=\"system\" value=\"blog\"/>";
echo "<input type=\"submit\" value=\"Rate\"/>";
echo "</form>";
echo "<b>Comments:</b><br/>";
if($page=="" || $page<=0)$page=1;
$noi = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_bcomments WHERE blogid='".$bid."'"));
$num_items = $noi[0];
$items_per_page= 7;
$num_pages = ceil($num_items/$items_per_page);
if(($page>$num_pages)&&$page!=1)$page= $num_pages;
$limit_start = ($page-1)*$items_per_page;
$sql = "SELECT blogid, uid, bcomments, btime, id FROM ibwff_bcomments WHERE blogid='".$bid."' ORDER BY btime DESC LIMIT $limit_start, $items_per_page";
$items = mysql_query($sql);
if(mysql_num_rows($items)>0)
{
while ($item = mysql_fetch_array($items))
{
if(isonline($item[1]))
{
$iml = "<img src=\"../avatars/onl.gif\" alt=\" \"/>";
}else{
$iml = "<img src=\"../avatars/ofl.gif\" alt=\"-\"/>";
}
	$avlink = getavatar($item[1]);
if($avlink=="")
{
 $avt =  "<img src=\"../avatars/nopic.jpg\" alt=\"Nopic\" type=\"picture\" width=\"22\"/>";
}else{
 $avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"icon\" width=\"23\" height=\"18\"/>";
}
$snick = subnick(getnick_uid($item[1]));
	    $sql3 = "SELECT name FROM ibwff_users WHERE id=$item[1]";
	    $sql33 = mysql_query($sql3);
	    $item3 = mysql_fetch_array($sql33);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nicks = "<font color=\"blue\"><b>$snick</b></font>";}
if($sex[0]=="F"){$nicks = "<font color=\"deeppink\"><b>$snick</b></font>";}
if($sex[0]==""){$nicks = "";}
$bs = date("d-m-y - H:i:s",$item[3]); 
$lnk = "<br/>$iml$avt<a href=\"profile.php?who=$item[1]\">$nicks</a><br/>(".getstatus($item[1]).")<br/>$bs<br/> ";
}
echo "$lnk
";
if(blogboss($uid))
{
$delnk = "<a href=\"delete.php?action=blgcom&mid=$item[4]\">x</a>";
}else{
$delnk = "";
}
$text = parsepm($item[2], $sid);
echo "$text $delnk
";
}
}
	echo "<form action=\"blogs.php?action=addbcom&clid=$clid&amp;who=$who&amp;bid=$bid\" method=\"post\"><p align=\"left\">";
echo "<input type=\"text\" name=\"scomments\"/><br/>";
echo "<input type=\"submit\" value=\"Comment\"/>";    
echo "</form><br/>";
if($page>1)
{
$ppage = $page-1;
echo "<a href=\"blogs.php?action=$action&amp;page=$ppage\">PREV</a> ";
}
if($page<$num_pages)
{
$npage = $page+1;
echo "<a href=\"blogs.php?action=$action&amp;page=$npage\">Next</a><br/>";
}
echo "Page - $page/$num_pages";
    if($num_pages>2)
{			
        $rets = "<form action=\"blogs.php\" method=\"get\">";
        $rets .= "<input name=\"page\" style=\"-wap-input-format: '*N'\" size=\"2\"/>";
        $rets .= "<input type=\"hidden\" name=\"action\" value=\"$action\"/>";
        $rets .= "<input type=\"hidden\" name=\"sid\" value=\"$sid\"/>";
        $rets .= "<input type=\"submit\" value=\"Go To Page\"/>";
        $rets .= "</form>";
        echo $rets;
    }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php?action=main\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="addbcom")
{
/////////////////////Blog Comment Ban By CJ UDAY :)
  $ban = mysql_fetch_array(mysql_query("SELECT blogcomban FROM ibwff_users WHERE id='".$uid."'"));
if($ban[0] > 0)
  {
	echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
			 echo "<div class=\"header\" align=\"center\">";
			  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
  echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
  echo "<br/><b><u><i>Can't Add Comment To Blog<br/>";
  echo "You're Blog Comment banned!</i></u></b><br/><br/>";
 echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
    exit();
    }
/////////////////////System By CJ UDAY :)
  $total = mysql_fetch_array(mysql_query("SELECT totaltime FROM ibwff_users WHERE id='".$uid."'"));
if($total[0]<10800)
  {
	    echo "<head>";
    echo "<title>Blog Comments</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
			 echo "<div class=\"header\" align=\"center\">";
			  echo "<b>Blog Comment</b></div>";
  echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
  echo "<br/><b>You Can't Comment On Blogs</b><br/>";
  echo "Stay online for some time more to Comment any Blog!<br/><br/>";
 echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php?action=main\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
    exit();
    }
addonline(getuid_sid($sid),"Commenting On A Blog","blogs.php?action=$action");
    echo "<head>";
    echo "<title>Add Comment</title>";
   echo "</head>";
    echo "<body>";
	echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
		echo "</div>";
	echo "<div class=\"header\" align=\"center\">";
	echo "<b>Add Blog Comment</b></div>";
						echo "<div class=\"shout2\" align=\"center\">";
		include("pm_by.php");
$id = $_GET['bid'];
$stext = $_POST['scomments'];
  $whonick = getnick_uid($who);
  $byuid = getuid_sid($sid);
$stime = time();
$uid = getuid_sid($sid);
	if(isblocked($stext,$byuid))
  {
    echo "<b><u><i>Can't Comment On Blog!!!<br/><br/>";
   echo "You Just Tried To Spam In FireBD via Comment Blog<br/>So You Are Now Blog Comment Banned!<br/>If You Blog Comment Banned By Our Mistake or Want To Be Blog Comment Unban<br/>Then Please With Contact <a href=\"online.php?action=stfol\">Online FireBD Staffs</a></b></i></u><br/>";
        $user = getnick_sid($sid);
    mysql_query("UPDATE ibwff_users SET blogcomban='1' WHERE id='".$uid."'");
    mysql_query("INSERT INTO ibwff_private SET text='[b](forwarded spam via blog comment)[/b][br/]".$stext."', byuid='".$byuid."', touid='1', timesent='".$crdate."'");
	mysql_query("INSERT INTO ibwff_private SET text='[b](forwarded spam via blog comment)[/b][br/]".$stext."', byuid='".$byuid."', touid='2', timesent='".$crdate."'");
	mysql_query("INSERT INTO ibwff_private SET text='[b](forwarded spam via blog comment)[/b][br/]".$stext."', byuid='".$byuid."', touid='4', timesent='".$crdate."'");
	echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      echo "</body>";
      echo "</html>";
    exit();
  }
if(trim($stext)!="" && strlen($stext) > "15"){
mysql_query("INSERT INTO ibwff_bcomments SET blogid='".$id."', bcomments='".$stext."', uid='".$uid."', btime='".$stime."'");
mysql_query("UPDATE ibwff_status SET lastupdate='".$stime."' WHERE id='".$statusid."'");
$cow = mysql_fetch_array(mysql_query("SELECT plusses FROM ibwff_users WHERE id='".$uid."'"));
$blogcompoint = blogcompoint();
$cow = $cow[0]+$blogcompoint;
mysql_query("UPDATE ibwff_users SET plusses='".$cow."' WHERE id='".$uid."'");
echo "<br/><img src=\"../avatars/ok.gif\" alt=\"O\"/>Comment Added Successfully!<br/><br/>";
$pminfo = mysql_fetch_array(mysql_query("SELECT btext, bname, bgdate,bowner, id FROM ibwff_blogs WHERE id='".$id."'"));
		$ibwff = time()+6*60*60;
		$res2 = mysql_fetch_array(mysql_query("SELECT bname,bowner FROM ibwff_blogs WHERE id='".$id."'"));
		$commenter= getnick_uid($uid);
		} else {
echo "<br/><img src=\"../avatars/notok.gif\" alt=\"X\"/>Short Blog Comment.<br/>Type 15 Or More Digits To Add Your Blog Comment!<br/><br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
/////////////////
else if($action=="last10blg")
{
addonline(getuid_sid($sid),"Viewing Last 10 Blogs","blogs.php?action=last10blg");
echo "<head>";
echo "<title>Last 10 Blogs</title>";
echo "</head>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>View Last 10 Blogs</b></div>";
echo "<div class=\"shout2\" align=\"left\">";	
include("pm_by.php");
$sql = "SELECT a.bname, b.bowner, b.bname
FROM ibwff_blogs a
INNER JOIN ibwff_blogs b ON a.id = b.bname
ORDER BY b.id DESC
LIMIT 0 , 10";
$items = mysql_query($sql);
while ($item = mysql_fetch_array($items))
{
$a = htmlspecialchars($item[0]);
$b = subnick(getnick_uid($item[1]));
$c = "<b><a href=\"blogs.php?bid=$item[2]\"> $a</a></b>";
$d = "<b><a href=\"profile.php?who=$item[1]\"> $b</a></b>";
echo "$c By $d<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}else if($action=="raters")
{
$bid = $_GET["bid"];
$t = mysql_fetch_array(mysql_query("SELECT bname FROM ibwff_blogs WHERE id='".$bid."'"));
$tname = htmlspecialchars($t[0]);
echo "<head>";
echo "<title>$tname Rater</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Viewing $tname Raters</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$c = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM uday_blgrate WHERE tid='".$bid."'"));
if($c[0]<=0)
{
echo "<br/><img src=\"../images/notok.gif\" alt=\"x\">No Blog Raters Found!";
}else{
$sql = "SELECT uid FROM uday_blgrate WHERE tid='".$bid."'";
$rate = mysql_query($sql);
while($rater = mysql_fetch_array($rate))
{
$unick = subnick(getnick_uid($rater[0]));
$sql2 = "SELECT name FROM ibwff_users WHERE id=$rater[0]";
$sql22 = mysql_query($sql2);
$item2 = mysql_fetch_array($sql22);
{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item2[0]'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/>";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/>";}
if($sex[0]==""){$usersex = "";}
if(isonline($rater[0]))
{
$iml = "<font color=\"green\">online!</font>";
}else{
$iml = "<font color=\"red\">offline!</font>";
}
$avlink = getavatar($rater[0]);
if($avlink=="")
{
$avt =  "$usersex";
}else{
$avt = "<img src=\"../avatars/$avlink\" alt=\"$avlink\" type=\"icon\" width=\"23\" height=\"18\"/>";
}
$sql3 = "SELECT name FROM ibwff_users WHERE id=$rater[0]";
$sql33 = mysql_query($sql3);
$item3 = mysql_fetch_array($sql33);
{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nick = "<font color=\"blue\"><b>$unick</b></font>";}
if($sex[0]=="F"){$nick = "<font color=\"deeppink\"><b>$unick</b></font>";}
if($sex[0]==""){$nick = "";}
$a = mysql_fetch_array(mysql_query("SELECT rate, time FROM uday_blgrate WHERE uid='".$rater[0]."' AND tid='".$bid."'"));
$bdt = $a[1] + (6*60*60);
$time = date("h:i A, D d M y",$bdt);
$ra = "<b>Rates: ($a[0]/5)</b>";
$usl = "<br/>$avt<a href=\"profile.php?action=viewuser&who=$rater[0]\">$nick</a> $iml &#187; $time<br/>$ra";
}
}
echo "$usl<br/>";
}
}
echo "<br/><br/>";
echo "<img src=\"../images/prev.gif\" alt=\"<\"><a href=\"blogs.php?clid=$clid&bid=$bid\"><b>Back To $tname Blog</b></a><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
//by CJ UDAY :-)

else if($action=="addblg")
{
addonline(getuid_sid($sid),"Adding a blog","blogs.php?action=$action");
echo "<head>";
echo "<title>Add A Blog</title>";
    echo "</head>";
    echo "<body>";
	echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
	echo "<div class=\"header\" align=\"center\">";
echo "<b>Add Blog</b></div>";
	echo "<div class=\"shout2\" align=\"left\">";
		include("pm_by.php");
echo "<onevent type=\"onenterforward\">";
echo "<refresh>
<setvar name=\"msgtxt\" value=\"\"/>
<setvar name=\"btitle\" value=\"\"/>";
echo "</refresh></onevent>";
 echo "<form action=\"blogproc.php?action=addblg&clid=$clid&amp;who=$who\" method=\"post\">";
echo "<b><big>Blog Title:</b></big><br/><input name=\"btitle\" maxlength=\"30\"/><br/>";
echo "<b><big>Blog Text:</b></big><br/><input name=\"msgtxt\" maxlength=\"10000\"/><br/>";
echo "<b><big>Blog Tags:</b></big><br/><input name=\"udaytag\" maxlength=\"1000\"><br/>";
echo "<b><big>Blog Catagory:</b></big><br/><select name=\"udayx\" value=\"Select One\">";
echo "<option value=\"Select One\">Select One</option>";
echo "<option value=\"General\">General</option>";
echo "<option value=\"Education\">Education</option>";
echo "<option value=\"Entertainment\">Entertainment</option>";
echo "<option value=\"Sports\">Sports</option>";
echo "<option value=\"Proggraming & Networks\">Proggraming & Networks</option>";
echo "<option value=\"Technology\">Technology</option>";
echo "</select><br/>";
 echo "<input type=\"submit\" value=\"Create\"/>";
    echo "</form>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="blgopt"){
$bid = $_GET["bid"];
addonline(getuid_sid($sid),"Viewing Blog Options","blogs.php?action=$action");
$tinfo= mysql_fetch_array(mysql_query("SELECT bname, bowner, btext FROM ibwff_blogs WHERE id='".$bid."'"));
$trid = $tinfo[1];
$ttext = htmlspecialchars($tinfo[2]);
$tname = htmlspecialchars($tinfo[0]);
echo "<head>";
echo "<title>View Option</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Blog Option</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<onevent type=\"onenterforward\">";
echo "<refresh>
<setvar name=\"ttext\" value=\"$ttext\"/>
<setvar name=\"tname\" value=\"$tname\"/>";
echo "</refresh></onevent>";
echo "Blog ID: <b>$bid</b><br/>";
$trnick = subnick(getnick_uid($tinfo[1]));
echo "<img src=\"../images/next.gif\" alt=\">\"><a href=\"profile.php?who=$trid\">View $trnick's Profile</a><br/>";
$cfrm = mysql_fetch_array(mysql_query("SELECT clubid FROM ibwff_blogs WHERE id='".$clid."'"));
if ($cfrm[0]>0)
{
$cname = getclubname($cfrm[0]);
echo "Club Name: <b>$cname</b><br/>";
}
$clid = $_GET["clid"];
if(blogboss($uid) || $tinfo[2]==$uid || isclubmod($uid,$clid)=="1" || isownerclub($uid,$clid)=="1")
{
echo "<form action=\"edit.php?action=renblg&clid=$clid&bid=$bid\" method=\"post\">";
echo "<b>Blog Title:</b> <input name=\"tname\" value=\"$tname\" maxlength=\"300\"/>";
echo "<input type=\"submit\" value=\"Rename\"/>";
echo "</form>";
echo "<form action=\"edit.php?action=blog&clid=$clid&bid=$bid\" method=\"post\">";
echo "<b>Blog Text:</b> <input name=\"ttext\" value=\"$ttext\" maxlength=\"10000\"/>";
echo "<input type=\"submit\" value=\"Edit\"/>";
echo "</form>";
}
if(blogboss($uid))
{
echo "<img src=\"../images/next.gif\" alt=\">\"><a href=\"delete.php?action=blog&clid=$clid&bid=$bid&sid=$sid\">Delete</a><br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
?>
</html>
  