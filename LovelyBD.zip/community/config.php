<?php
$dbname = "mydhaka_mehedi2";
$dbhost = "localhost";
$dbuser = "mydhaka_mehedi2";
$dbpass = "4535900m00";

$max_buds=500;
$topic_af = 20;
$post_af = 15;
$onver = true;
date_default_timezone_set('UTC');
?>