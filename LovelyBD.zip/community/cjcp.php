<?php
session_start();
include("config.php");
include("core.php");  connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo '<head>';
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"title\" content=\"FireBD.NeT\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From Megh: Don't Try To Hack OR else :P\">
<meta name=\"keywords\" content=\"Site Desined By Megh :) :)\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/></head>";
echo "<body>";
$action = $_GET["action"]; $sid = $_SESSION["sid"];
$page = $_GET["page"];
$who = $_GET["who"];
$uid = getuid_sid($sid);
$name = $_GET["name"];
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();
////////////////Ip Banned By CJ UDAY :)	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
    echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
	echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
      echo "<br/>";
      echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
      $banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
      $remain =  $banto[0] - time();
      $rmsg = gettimemsg($remain);
      echo "<b>Time Remaining: $rmsg</b><br/>";
      $nick = getnick_uid($banto[2]);
       $text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
      echo "</p>";
    	echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
    echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
    echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
//////////////////Banned System Updated By CJ UDAY :)
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please With Contact Us <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
 echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
///////////////////Validation By CJ UDAY :)
					if(isvalidated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
	echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  You Are Not Validated!<br/>We are checking your ip and browser<br/>
	  This could take up to 15 munites pls be patient and try again soon<br/>Please try again later...<br/><b>Thank You</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }

///////////////////Deactivated Account By CJ UDAY :)
          if(isdeactivated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  <b>Your Account Has Been Deactivated Forever.<br/>And It Will Be Never Activate!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="ssonl")
  {
$who = $_GET["who"];
	echo "<head>";
    echo "<title>Show in staff online</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Show in staff online</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$lname = getnick_uid($who);
$uday = mysql_query("UPDATE ibwff_users SET showonline='0' WHERE id='".$who."'");
if($uday)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> <b>$lname</b> showed at staff online successfully!<br/>";
$validater = getnick_sid($sid);
$action = 'Show Online';
$msg = "[b]".$lname."[/b] is shown online in staff list by [b]".$validater."[/b]";
adminnot($msg);
mlog($action, $msg);
$p = "You are now show online in staff list by [b]".$validater."[/b]";
notify($po, $who);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> <b>$lname</b> cannot be shown at staff online at this moment!<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="hsonl")
  {
$who = $_GET["who"];
	echo "<head>";
    echo "<title>Hide in staff online</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Hide in staff online</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<form action=\"cjproc.php?action=uday&who=$who\" method=\"post\">";
echo "Code:<br/><input name=\"uday\"><br/><input type=\"submit\" value=\"Hide\"></form>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="hsonl")
  {
$who = $_GET["who"];
	echo "<head>";
    echo "<title>Hide in staff online</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Hide in staff online</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$lname = getnick_uid($who);
$uday = mysql_query("UPDATE ibwff_users SET showonline='1' WHERE id='".$who."'");
if($uday)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> <b>$lname</b> hidden at staff online successfully!<br/>";
$validater = getnick_sid($sid);
$action = 'Hide Online';
$msg = "[b]".$lname."[/b] is hidden online in staff list by [b]".$validater."[/b]";
adminnot($msg);
mlog($action, $msg);
$p = "You are now hide online in staff list by [b]".$validater."[/b]";
notify($po, $who);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> <b>$lname</b> cannot be hidden at staff online at this moment!<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="remstf")
  {
$who = $_GET["who"];
	echo "<head>";
    echo "<title>Remove from staff</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Remove from staff</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$lname = getnick_uid($who);
$uday = mysql_query("UPDATE ibwff_users SET cyberpowereragon='0' WHERE id='".$who."'");
if($uday)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> <b>$lname</b> removed from staff successfully!<br/>";
$validater = getnick_sid($sid);
$msg = "[b]".$lname."[/b] is removed from staff by [b]".$validater."[/b]";
adminnot($msg);
$p = "You are now removed from staff by [b]".$validater."[/b]";
notify($po, $who);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> <b>$lname</b> cannot be removed from staff at this moment!<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="mkstf")
  {
$who = $_GET["who"];
	echo "<head>";
    echo "<title>Make staff</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Make staff</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<p align=\"left\">";
echo "<b>Select What Level Of Staff Do You Want To Make ".subnick(getnick_uid($who))."!<br/><br/></p></b>";
echo "<form action=\"cjcp.php?action=udaymod&who=$who\" method=\"post\">";
echo "<select name=\"mod\">
<option value=\"1\">Moderator!</option>
<option value=\"2\">Junior Moderator!</option>
<option value=\"3\">Senior Moderator!</option>
<option value=\"4\">Head Moderator!</option>
<option value=\"5\">Administrator</option>
</select>";
echo "<input type=\"submit\" value=\"Update\">";
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="udaymod")
  {
$who = $_GET["who"];
$mod = $_POST["mod"];
	echo "<head>";
    echo "<title>Make staff</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Make staff</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
if($mod=='1'){$x = "Moderator";}
if($mod=='2'){$x = "Junior Moderator";}
if($mod=='3'){$x = "Senior Moderator";}
if($mod=='4'){$x = "Head Moderator";}
if($mod=='5'){$x = "Administrator";}
$lname = getnick_uid($who);
$uday = mysql_query("UPDATE ibwff_users SET cyberpowereragon='".$mod."' WHERE id='".$who."'");
if($uday)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> <b>$lname</b> made ".$x." successfully!<br/>";
$validater = getnick_sid($sid);
$msg = "[b]".$lname."[/b] is made ".$x." by [b]".$validater."[/b]";
adminnot($msg);
$p = "You are now made ".$x." by [b]".$validater."[/b]";
notify($po, $who);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> <b>$lname</b> cannot be made ".$x." at this moment!<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="editu")
  {
$who = $_GET["who"];
$n = subnick(getnick_uid($who));
	echo "<head>";
    echo "<title>Edit User</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Edit $n's profile</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$ud = mysql_fetch_array(mysql_query("SELECT name, sex, birthday, email, phone, hiranick, interested, profilemsg, totaltime, title_uday FROM ibwff_users WHERE id='".$who."'"));
echo "<form action=\"cjcp.php?action=udayedt&who=$who\" method=\"post\">";
echo "<b>Name:</b><br/><input name=\"name\" value=\"$ud[0]\"><br/>";
echo "<b>Sex:</b><br/><select name=\"sex\" value=\"$ud[1]\">
<option value=\"M\">Male</option>
<option value=\"F\">Female</option>
</select><br/>";
echo "<b>Birthday:</b><br/><input name=\"bday\" value=\"$ud[2]\"><br/>";
echo "<b>Email:</b><br/><input name=\"email\" value=\"$ud[3]\"><br/>";
echo "<b>Phone:</b><br/><input name=\"phone\" value=\"$ud[4]\"><br/>";
echo "<b>Display Name:</b><br/><input name=\"dname\" value=\"$ud[5]\"><br/>";
if($ud[9]!="")
{
echo "<b>Title Name:</b><br/><input name=\"tname\" value=\"$ud[9]\"><br/>";
}
echo "<b>About me:</b><br/><input name=\"ame\" value=\"$ud[6]\"><br/>";
echo "<b>Profile message:</b><br/><input name=\"pm\" value=\"$ud[7]\"><br/>";
echo "<b>Total online time:</b><br/><input name=\"tot\" value=\"$ud[8]\"><br/>";
echo "<input type=\"submit\" value=\"Edit\">";
echo "</form>";
echo "&#187; <a href=\"deletefunctions.php?action=delu&who=$who\"> Delete This User</a>";
echo "<hr>";
echo "<form action=\"cjcp.php?action=udayedtp&who=$who\" method=\"post\">";
echo "<b>Password:</b><br/><input name=\"p\"><br/>";
echo "<input type=\"submit\" value=\"Edit\">";
echo "</form>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
if($action=="udayedt")
{
	echo "<head>";
    echo "<title>Edit User</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Edit User</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
$name = $_POST["name"];
$sex = $_POST["sex"];
$bday = $_POST["bday"];
$email = $_POST["email"];
$phn = $_POST["phone"];
$dn = $_POST["dname"];
$tn = $_POST["tname"];
$am = $_POST["ame"];
$pm = $_POST["pm"];
$tot = $_POST["tot"];
$lname = getnick_uid($who);
$uday = mysql_query("UPDATE ibwff_users SET name='".$name."', sex='".$sex."', birthday='".$bday."', email='".$email."', phone='".$phn."', hiranick='".$dn."', interested='".$am."', title_uday='".$tn."', totaltime='".$tot."', profilemsg='".$pm."' WHERE id='".$who."'");
if($uday)
{
echo "<img src=\"../images/ok.gif\" alt=\"O\"> <b>$lname</b> profile edited successfully!<br/>";
$validater = getnick_sid($sid);
$msg = "[b]".$lname."[/b] profile edited by [b]".$validater."[/b]";
adminnot($msg);
$p = "Your profile is now edited by [b]".$validater."[/b]";
notify($po, $who);
$p = "Your profile is now edited by [b]".$validater."[/b]";
notify($po, $who);
}else{
echo "<img src=\"../images/notok.gif\" alt=\"x\"> <b>$lname</b> profile cannot be edited at this moment!<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
}
else if($action=="udayedtp")
{
  addonline(getuid_sid($sid),"Updating Password","setting.php?action=setting");
  $opwd = $_POST["p"];
 $epwd = md5($opwd);
    	    echo "<head>";
    echo "<title>Update Password</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
    echo "<div class=\"header\" align=\"center\">";
	echo "<b>Change Password</b></div>";
    echo "<div class=\"shout2\" align=\"center\">";
    include("pm_by.php");
    $res = mysql_query("UPDATE ibwff_users SET pass='".$epwd."' WHERE id='".$who."'");
    if($res)
  {
    echo "<br/><img src=\"../avatars/ok.gif\" alt=\"o\"/> Password Updated Successfully!<br/><br/>";
  }else{
    echo "<br/><img src=\"../avatars/notok.gif\" alt=\"x\"/>Error Updating Password!<br/><br/>";
  }
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="clpl")
  {
$clid = $_GET["clid"];
	echo "<head>";
    echo "<title>Club Points</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Club Points</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<form action=\"cjproc.php?action=up&clid=$clid\" method=\"post\">";
echo "<b>Point:</b><br/><input name=\"p\"><br/>";
echo "<b>System:</b><br/> <select name=\"pf\">
<option value=\"a\">Add</option>
<option value=\"b\">Cut</option>
</select><br/>";
echo "<input type=\"submit\" value=\"Update\">";
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="dcl")
{
echo "<head>";
    echo "<title>Delete club</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Delete club</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$r = deleteClub($clid);
if($r)
{
echo "<img src=\"ok.gif\"> Club deleted successfully!<br/>";
}else{
echo "<img src=\"../avatars/notok.gif\"> Club cannot be deleted at this moment!<br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
  echo "</html>";
  exit();
}
else if($action=="sof")
{
  echo "<head>";
    echo "<title>Security Option</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
  echo "</div>";
  echo "<div class=\"header\" align=\"center\"><b>Unlock Account</b></div>";
	echo"<div class=\"shout2\" align=\"center\">";
$q = mysql_query("UPDATE ibwff_usersecurity SET status='0' WHERE uid='".$who."'");
if($q)
{
echo "<br/><img src=\"../images/ok.gif\">You have successfully turned off security for this account.<br/>";
}else{
echo "Unknown Error!!!";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<p align=\"left\"><img src=\"../images/home.gif\"><a href=\"main.php\">Home</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
?>
</html>