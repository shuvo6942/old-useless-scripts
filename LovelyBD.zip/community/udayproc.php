<?php
session_start();
include("config.php");
include("core.php");  connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo '<head>';
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"title\" content=\"Firebd.net\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From Shahos : Don't Try To Hack OR else :P\">
<meta name=\"keywords\" content=\"Site Desined By Shahos :) :)\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/></head>";
echo "<body>";
$action = $_GET["action"]; $sid = $_SESSION["sid"];
$page = $_GET["page"];
$who = $_GET["who"];
$uid = getuid_sid($sid);
$name = $_GET["name"];
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();
////////////////Ip Banned By CJ UDAY :)	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
    echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
	echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
      echo "<br/>";
      echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
      $banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
      $remain =  $banto[0] - time();
      $rmsg = gettimemsg($remain);
      echo "<b>Time Remaining: $rmsg</b><br/>";
      $nick = getnick_uid($banto[2]);
       $text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
      echo "</p>";
    	echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
    echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
    echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
//////////////////Banned System Updated By CJ UDAY :)
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please With Contact Us <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
 echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
///////////////////Validation By CJ UDAY :)
					if(isvalidated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
	echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  You Are Not Validated!<br/>We are checking your ip and browser<br/>
	  This could take up to 15 munites pls be patient and try again soon<br/>Please try again later...<br/><b>Thank You</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }

///////////////////Deactivated Account By CJ UDAY :)
          if(isdeactivated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  <b>Your Account Has Been Deactivated Forever.<br/>And It Will Be Never Activate!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="general")
{
if(!settingboss(getuid_sid($sid)))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  echo "permission Denied!<br/>";
  echo "<br/>You are not permited for this action...<br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
  echo "</html>";
  exit();
}
  $sitename = $_POST["sitename"];
  $xtm = $_POST["sesp"];
  $cpoint = $_POST["cpoint"];
  $spoint = $_POST["spoint"];
  $lpoint = $_POST["lpoint"];
  $mkfpoint = $_POST["mkfpoint"];
  $fcompoint = $_POST["fcompoint"];
  $litpoint = $_POST["litpoint"];
  $litcompoint = $_POST["litcompoint"];
  $blogpoint = $_POST["blogpoint"];
  $blogcompoint = $_POST["blogcompoint"];
  $clpluss = $_POST["clpluss"];
  $nmpluss = $_POST["nmpluss"];
  $pp = $_POST["pp"]; 
  $pvp = $_POST["pvp"]; 
  $newclubpoint = $_POST["newclubpoint"];
  $memberpoint = $_POST["memberpoint"];
  $junmemberpoint = $_POST["junmemberpoint"];
  $senmemberpoint = $_POST["senmemberpoint"];
  $junvip = $_POST["junvip"];
  $senvip = $_POST["senvip"];
  $knightpoint = $_POST["knightpoint"];
  $expellerpoint = $_POST["expellerpoint"];
  $expartpoint = $_POST["expartpoint"];
  $mrsmispoint = $_POST["mrsmispoint"];
  $pppoint = $_POST["pppoint"];
  $king = $_POST["king"];
  $kok = $_POST["kok"];
  $areg = $_POST["areg"];
  $vldtn = $_POST["vldtn"];
  $fmvldtn = $_POST["fmvldtn"];
  $fmtvldtn = $_POST["fmtvldtn"];
  $litcatvldtn = $_POST["litcatvldtn"];
  $fmtvldtn = $_POST["fmtvldtn"];
  $pollvldtn = $_POST["pollvldtn"];
  $blogvldtn = $_POST["blogvldtn"];
 if($areg=="d")
  {
  $arv = 0;
  }else{
  $arv = 1;
  }
  if($vldtn=="d")
  {
  $valid = 1;
  }else{
  $valid = 0;
  }
  if($fmvldtn=="d")
  {
  $fmvlid = 1;
  }else{
  $fmvlid = 0;
  }
if($fmtvldtn=="d")
  {
  $fmtvlid = 1;
  }else{
  $fmtvlid = 0;
  }
if($litcatvldtn=="d")
  {
  $litcvlid = 1;
  }else{
  $litcvlid = 0;
  }
  if($litvldtn=="d")
  {
  $litvlid = 1;
  }else{
  $litvlid = 0;
  }
  if($pollvldtn=="d")
  {
  $pollvlid = 1;
  }else{
  $pollvlid = 0;
  }
  if($blogvldtn=="d")
  {
  $blogvlid = 1;
  }else{
  $blogvlid = 0;
  }
  echo "<head>";
    echo "<title>Site Settings</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Site Settings</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
    echo "<b><u>Settings:-</u></b><br/>";
  $res = mysql_query("UPDATE ibwff_settings SET value='".$sitename."' WHERE name='sitename'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Site Name updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Error Updating Site Name<br/>";
  }

  $res = mysql_query("UPDATE ibwff_settings SET value='".$xtm."' WHERE name='sesexp'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Session Period updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Error Updating Session Period<br/>";
  }
  $res = mysql_query("UPDATE ibwff_settings SET value='".$cpoint."' WHERE name='cpoint'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>point per Chat post updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>point per chatpost updated error!<br/>";
  }
  $res = mysql_query("UPDATE ibwff_settings SET value='".$spoint."' WHERE name='spoint'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>point cut for shout updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>point cut for shout error!<br/>";
  }
  $res = mysql_query("UPDATE ibwff_settings SET value='".$lpoint."' WHERE name='lpoint'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>point cut for givelove updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>point cut for givelove error!<br/>";
  }
  $res = mysql_query("UPDATE ibwff_settings SET value='".$mkfpoint."' WHERE name='mkfpoint'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>point per forum topic create updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>point per forum topic create error!<br/>";
  }
  $res = mysql_query("UPDATE ibwff_settings SET value='".$fcompoint."' WHERE name='fcompoint'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>point per forum topic post updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>point per forum topic post error!<br/>";
  }
  $res = mysql_query("UPDATE ibwff_settings SET value='".$litpoint."' WHERE name='litpoint'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>point per Literature updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>point per Literature error!<br/>";
  }
  $res = mysql_query("UPDATE ibwff_settings SET value='".$litcompoint."' WHERE name='litcompoint'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>point per Literature Comment updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>point per Literature Comment error!<br/>";
  }
  $res = mysql_query("UPDATE ibwff_settings SET value='".$blogpoint."' WHERE name='blogpoint'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>point for create a blog updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>point for create a blog error!<br/>";
  }
  $res = mysql_query("UPDATE ibwff_settings SET value='".$blogcompoint."' WHERE name='blogcompoint'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>point for create a blog comment updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>point for create a blog comment error!<br/>";
  }
  $res = mysql_query("UPDATE ibwff_settings SET value='".$clpluss."' WHERE name='clpluss'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>point need for a club updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>point need for a club error!<br/>";
  }
  $res = mysql_query("UPDATE ibwff_settings SET value='".$nmpluss."' WHERE name='nmpluss'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>point need for nick change updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>point need for nick change error!<br/>";
  }
$res = mysql_query("UPDATE ibwff_settings SET value='".$pp."' WHERE name='poll_uday'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>point for create a poll updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>point for create a poll error!<br/>";
  }
$res = mysql_query("UPDATE ibwff_settings SET value='".$pvp."' WHERE name='pollc_uday'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>point for vote on a poll updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>point for vote on a poll error!<br/>";
  }
  $res = mysql_query("UPDATE ibwff_settings SET value='".$newclubpoint."' WHERE name='newclubpoint'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>point need for create a club updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>point need for create a club error!<br/>";
  }
    echo "<b><u>Member Status:-</u></b><br/>";
$res = mysql_query("UPDATE ibwff_settings SET value='".$memberpoint."' WHERE name='memberpoint'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Member Status updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Member Status error!<br/>";
  }
  $res = mysql_query("UPDATE ibwff_settings SET value='".$junmemberpoint."' WHERE name='junmemberpoint'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Junior Member Status updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>junior Member Status error!<br/>";
  }
  $res = mysql_query("UPDATE ibwff_settings SET value='".$senmemberpoint."' WHERE name='senmemberpoint'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Senior Member Status updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Senior Member Status error!<br/>";
  }
$res = mysql_query("UPDATE ibwff_settings SET value='".$junvip."' WHERE name='junvip_uday'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Junior vip Status updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Junior vip Status error!<br/>";
  }
$res = mysql_query("UPDATE ibwff_settings SET value='".$senvip."' WHERE name='senvip_uday'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Senior vip Status updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Senior vip Status error!<br/>";
  }
  $res = mysql_query("UPDATE ibwff_settings SET value='".$knightpoint."' WHERE name='knightpoint'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Knight Status updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Knight Status error!<br/>";
  }
  $res = mysql_query("UPDATE ibwff_settings SET value='".$expellerpoint."' WHERE name='expellerpoint'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Expeller Status updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Expeller Status error!<br/>";
  }
  $res = mysql_query("UPDATE ibwff_settings SET value='".$expartpoint."' WHERE name='expartpoint'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Expart Status updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Expart Status error!<br/>";
  }
  $res = mysql_query("UPDATE ibwff_settings SET value='".$mrsmispoint."' WHERE name='mrsmispoint'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Master/Mistres Status updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>master/Mistres Status error!<br/>";
  }
  $res = mysql_query("UPDATE ibwff_settings SET value='".$pppoint."' WHERE name='pppoint'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Prince/Princes Status updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Prince/Princes Status error!<br/>";
  }
  $res = mysql_query("UPDATE ibwff_settings SET value='".$king."' WHERE name='king'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>King Status updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>King Status error!<br/>";
  }
  $res = mysql_query("UPDATE ibwff_settings SET value='".$kok."' WHERE name='kok'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>King Of King Status updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>King Of King Status error!<br/>";
  }
  echo "<b><u>validation:-</u></b><br/>";
  $res = mysql_query("UPDATE ibwff_settings SET value='".$arv."' WHERE name='reg'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Registration Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Error Updating Registration<br/>";
  }
   $res = mysql_query("UPDATE ibwff_settings SET value='".$valid."' WHERE name='vldtn'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Validation Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Error Updating Validation<br/>";
  }
   $res = mysql_query("UPDATE ibwff_settings SET value='".$fmvlid."' WHERE name='fmvldtn'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Forum Catagory Validation Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Error Updating Forum Catagory Validation<br/>";
  }
   $res = mysql_query("UPDATE ibwff_settings SET value='".$fmtvlid."' WHERE name='tpcval'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Topic Validation Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Error Updating Topic Validation<br/>";
  }
   $res = mysql_query("UPDATE ibwff_settings SET value='".$litcvlid."' WHERE name='artval'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Literature Catagory Validation Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Error Updating Literature Catagory Validation<br/>";
  }
   $res = mysql_query("UPDATE ibwff_settings SET value='".$litvlid."' WHERE name='litvldtn'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Literature Validation Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Error Updating Literature Validation<br/>";
  }
   $res = mysql_query("UPDATE ibwff_settings SET value='".$pollvlid."' WHERE name='pollvldtn'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Poll Validation Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Error Updating Poll Validation<br/>";
  }
  
   $res = mysql_query("UPDATE ibwff_settings SET value='".$blogvlid."' WHERE name='blogvldtn'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Blog Validation Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Error Updating Blog Validation<br/>";
  }
  echo "<br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
else if($action=="an")
{
if(!announcementboss(getuid_sid($sid)))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  echo "permission Denied!<br/>";
  echo "<br/>You are not permited for this action...<br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
  echo "</html>";
  exit();
}
	echo "<head>";
    echo "<title>Announcement Settings</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Announcement Settings</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$fmsg = $_POST["fmsg"];
$ntitle = $_POST["ntitle"];
$ntb = $_POST["ntb"];
$cntitle = $_POST["cntitle"];
$cnt = $_POST["cnt"];
$lnktitle = $_POST["lnktitle"];
$lnkads = $_POST["lnkads"];
 $res = mysql_query("UPDATE ibwff_settings SET value='".$fmsg."' WHERE name='4ummsg'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Forum Message Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Error Updating Forum message<br/>";
  }
   $res = mysql_query("UPDATE ibwff_settings SET value='".$ntb."' WHERE name='ntcmsg'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Notice Board Message Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Error Updating Notice Board Message!<br/>";
  }
  $res = mysql_query("UPDATE ibwff_settings SET value='".$cnt."' WHERE name='cntmsg'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Contest Box Message Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Error Updating Contest Box Message!<br/>";
  }
  $res = mysql_query("UPDATE ibwff_settings SET value='".$lnkads."' WHERE name='lnkmsg'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Offer Ads Message Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Error Updating Offer Ads Message!<br/>";
  }
  $res = mysql_query("UPDATE ibwff_settings SET value='".$ntitle."' WHERE name='ntitle'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Notice Board Title Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Error Updating Notice Board Title!<br/>";
  }
 $res = mysql_query("UPDATE ibwff_settings SET value='".$lnktitle."' WHERE name='lnktitle'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Offer Ads Title Name Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Error Updating Offer Ads Title!<br/>";
  } 
$res = mysql_query("UPDATE ibwff_settings SET value='".$cntitle."' WHERE name='cntitle'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Contest Box Title Name Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Error Updating Contest Box Title!<br/>";
  }
    echo "<br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
else if($action=="ins")
{
if(!instructionboss(getuid_sid($sid)))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  echo "permission Denied!<br/>";
  echo "<br/>You are not permited for this action...<br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
  echo "</html>";
  exit();
}
	echo "<head>";
    echo "<title>Instruction Settings</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Instruction Settings</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$institle = $_POST["institle"];
$insmsg = $_POST["insmsg"];
$res = mysql_query("UPDATE ibwff_settings SET value='".$institle."' WHERE name='institle'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Instruction Title Name Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Error Updating Instruction Title!<br/>";
  }
$res = mysql_query("UPDATE ibwff_settings SET value='".$insmsg."' WHERE name='insmsg'");
  if($res)
  {
  echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Instruction Message Updated Successfully!<br/>";
  }else{
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Error Updating Instruction Message!<br/>";
  } 
    echo "<br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
else if($action=="asm")
{
if(!smiliesboss(getuid_sid($sid)))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
  echo "permission Denied!<br/>";
  echo "<br/>You are not permited for this action...<br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
  echo "</html>";
  exit();
}
	echo "<head>";
    echo "<title>Add Smilies</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Add Smilies</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$smlcde = $_POST["smlcde"];
$smlsrc = $_POST["smlsrc"];
$res = mysql_query("INSERT INTO ibwff_smilies SET scode='".$smlcde."', imgsrc='".$smlsrc."', hidden='0'");
if($res)
{
echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Smilie Added Successfully!";
}else{
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Error adding Smilie!";
}
echo "<br/></div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
  echo "</html>";
  exit();
}
else if($action=="logo")
{
	echo "<head>";
    echo "<title>Logo</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Logo</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
$size = $_FILES['attach']['size']/2050;
$origname = $_FILES['attach']['name'];
$res = false;
$ext = explode(".", strrev($origname));
switch(strtolower($ext[0])){
        case "gpj":
    $res = true;
    break;
    case "gepj":
    $res = true;
    break;
	case "gnp":
    $res = true;
    break;
}
$uploaddir = "../community";
if($size>2050){
echo "File Is Larger Than 2MB!";
}
else if ($res!=true){
echo "<br/>File type not supported ! Please attach only a JPG/JPEG format image.<br/>";
}else{
    $uploadfile = "FireBD.png";
    $uppath=$uploaddir."/".$uploadfile;
    move_uploaded_file($_FILES['attach']['tmp_name'], $uppath);
    echo "<br/> <img src=\"../avatars/ok.gif\" alt=\"0\"> Logo Was Successfully Uploaded!<br/><br/>";
    }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
}
else if($action=="themes")
{
	echo "<head>";
    echo "<title>Themes</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Themes</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
$size = $_FILES['attach']['size']/2050;
$origname = $_FILES['attach']['name'];
$res = false;
$ext = explode(".", strrev($origname));
switch(strtolower($ext[0])){
        case "ssc":
    $res = true;
    break;
}
$uploaddir = "../community";
if($res!=true){
echo "File type not supported ! Please attach only a CSS format file.<br/>";
}else{
    $name = getuid_sid($sid);
    $uploadfile = $origname;
    $uppath=$uploaddir."/".$uploadfile;
	$file1=$origname;
    move_uploaded_file($_FILES['attach']['tmp_name'], $uppath);
	$res1 = mysql_query("INSERT INTO ibwff_themes SET lnk='$uppath', name='".$origname."'");
    if ($res1)
	{
	echo "<br/> <img src=\"../avatars/ok.gif\" alt=\"0\"/> Theme Uploaded Successfully <br/><br/>";
    }else{
	echo "<br/>[X] Unknown Error!! Please Contact With CJ UDAY!<br/>";
	}
	}

echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
}
else if($action=="h")
{
echo "<head>";
    echo "<title>Hidden Staff Code</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Update Code</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$ud = $_POST["uday"];
$f =
mysql_query("UPDATE ibwff_settings SET cd='".$ud."'");
if($f)
{
echo "[0] staff hidden code updated successfully!";
}else{
echo "[x] unable to update hidden staff code!";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</html>";
  exit();
}
?>
</html>