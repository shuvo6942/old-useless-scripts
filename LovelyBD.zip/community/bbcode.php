<?php
session_start();
include("config.php");
include("core.php");  connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo '<head>';
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"title\" content=\"FireBD.NeT\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From Megh: Don't Try To Hack OR else :P\">
<meta name=\"keywords\" content=\"Site Desined By Megh :) :)\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/></head>";
echo "<body>";
$action = $_GET["action"]; $sid = $_SESSION["sid"];
$page = $_GET["page"];
$who = $_GET["who"];
$uid = getuid_sid($sid);
$name = $_GET["name"];
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();
////////////////Ip Banned By CJ UDAY :)	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
    echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
	echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
      echo "<br/>";
      echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
      $banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
      $remain =  $banto[0] - time();
      $rmsg = gettimemsg($remain);
      echo "<b>Time Remaining: $rmsg</b><br/>";
      $nick = getnick_uid($banto[2]);
       $text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
      echo "</p>";
    	echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
    echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
    echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
//////////////////Banned System Updated By CJ UDAY :)
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please With Contact Us <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
 echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
///////////////////Validation By CJ UDAY :)
					if(isvalidated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
	echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  You Are Not Validated!<br/>We are checking your ip and browser<br/>
	  This could take up to 15 munites pls be patient and try again soon<br/>Please try again later...<br/><b>Thank You</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }

///////////////////Deactivated Account By CJ UDAY :)
          if(isdeactivated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  <b>Your Account Has Been Deactivated Forever.<br/>And It Will Be Never Activate!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
//////////////////////////////////BBCodes Updated By CJ UDAY :)
else if($action=="bbcode")
{
    addonline(getuid_sid($sid),"Viewing BBCodes List","lists.php?action=$action");
	    echo "<head>";
    echo "<title>View BBCodes List</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
    echo "<div class=\"header\" align=\"center\">";
	echo "<b>FireBD BBCodes Lists</b></div>";
	echo "<div class=\"shout2\" align=\"left\">";
    include("pm_by.php");
    echo "<br/>";
 echo "<b>WARNING:</b> Misusing the bbcodes may cause display errors!!!<br/><br/>";
 echo "[b]TEXT[/b]: <b>TEXT</b><br/>";
 echo "[i]TEXT[/i]: <i>TEXT</i><br/>";
 echo "[u]TEXT[/u]: <u>TEXT</u><br/>";
 echo "[big]TEXT[/big]: <big>TEXT</big><br/>";
 echo "[small]TEXT[/small]: <small>TEXT</small><br/>";
 echo "[blink]TEXT[/blink]: <blink>TEXT</blink><br/>";
 echo "[del]TEXT[/del]: <del>TEXT</del><br/>";
 echo "[code]TEXT[/code]: <input name=\"bbcode\" value=\"TEXT\"/><br/><br/>";
 echo "[br/]: Line Break Code<br/><br/>";
 echo "[left]TEXT[/left]: <p align=\"left\">TEXT</p><br/>";
 echo "[center]TEXT[/center]: <p align=\"center\">TEXT</p><br/>";
 echo "[right]TEXT[/right]: <p align=\"right\">TEXT</p><br/>";
echo "[topic=<i>1</i>]<i>Topic Name</i>[/topic]: <a href=\"forums.php?action=viewtopic&tid=1\">Topic Name</a><br/>";
 echo "<small>replace 1 with the topic id, and replace Topic Name with any word you want</small><br/><br/>";
 echo "[literature=<i>1</i>]<i>Literature Name</i>[/literature]: <a href=\"literature.php?tid=1\">Literature Name</a><br/>";
 echo "<small>replace 1 with the literature id, and replace Literature Name with any word you want</small><br/><br/>";
 echo "[blog=<i>1</i>]<i>Blog Name</i>[/blog]: <a href=\"blogs.php?bid=1\">Blog Name</a><br/>";
 echo "<small>replace 1 with the blog id, and replace Blog Name with any word you want</small><br/><br/>";
 echo "[poll=<i>1</i>]<i>Poll Name</i>[/poll]: <a href=\"polls.php?who=1\">Poll Name</a><br/>";
 echo "<small>replace 1 by your poll id number, and replace your Poll Name with any word you want</small><br/><br/>";
 echo "[club=<i>1</i>]<i>Club Name</i>[/club]: <a href=\"clubs.php?clid=1\">Club Name</a><br/>";
 echo "<small>replace 1 with the club id, and replace Club Name with any word you want</small><br/><br/>";
 echo "[user=<i>1</i>]<i>Mehedi</i>[/user]: <a href=\"profile.php?who=4\">Mehedi</a><br/>";
 echo "<small>replace 1 by your id number, and replace your Name with any word you want</small><br/><br/>";
 echo "[guestbook=<i>1</i>]<i>Guestbook</i>[/guestbook]: <a href=\"gbook.php?action=gbook&who=1\">Guestbook</a><br/>";
 echo "<small>replace 1 by your id number, and replace your Guestbook Name with any word you want</small><br/><br/>";
 echo "[mindstatus=<i>1</i>]<i>Mind Status Name</i>[/mindstatus]: <a href=\"scomments.php?statusid=1\">Mind Status Name</a><br/>";
 echo "<small>replace 1 with the mindstatus id, and replace Mind Status Name with any word you want</small><br/><br/>";
 echo "[shout=<i>1</i>]<i>Shout Name</i>[/shout]: <a href=\"shcomments.php?shid=1\">Shout Name</a><br/>";
 echo "<small>replace 1 with the shout id, and replace Shout Name with any word you want</small><br/><br/>";
 echo "[profilepicture=<i>1</i>]<i>Profile Picture Name</i>[/profilepicture]: <a href=\"profilepic.php?id=1\">Profile Picture Name</a><br/>";
 echo "<small>replace 1 with the profile picture id, and replace Profile Picture Name with any word you want</small><br/><br/>";
 echo "[coverphoto=<i>1</i>]<i>Cover Photo Name</i>[/coverphoto]: <a href=\"coverphoto.php?id=1\">Cover Photo Name</a><br/>";
 echo "<small>replace 1 with the cover photo id, and replace Cover Photo Name with any word you want</small><br/><br/>";
 echo "[black]TEXT[/black]: <font color=\"black\">BLACK TEXT</font><br/>";
 echo "[white]TEXT[/white]: <font color=\"white\">WHITE TEXT</font><br/>";
 echo "[yellow]TEXT[/yellow]: <font color=\"yellow\">YELLOW TEXT</font><br/>";
 echo "[lime]TEXT[/lime]: <font color=\"lime\">LIME TEXT</font><br/>";
 echo "[green]TEXT[/green]: <font color=\"green\">GREEN TEXT</font><br/>";
 echo "[red]TEXT[/red]: <font color=\"red\">RED TEXT</font><br/>";
 echo "[blue]TEXT[/blue]: <font color=\"blue\">BLUE TEXT</font><br/>";
 echo "[teal]TEXT[/teal]: <font color=\"teal\">TEAL TEXT</font><br/>";
 echo "[deepskyteal]TEXT[/deepskyteal]: <font color=\"deepskyteal\">DEEP SKY BLUE TEXT</font><br/>";
 echo "[grey]TEXT[/grey]: <font color=\"grey\">GREY TEXT</font><br/>";
 echo "[silver]TEXT[/silver]: <font color=\"silver\">SILVER TEXT</font><br/>";
 echo "[navy]TEXT[/navy]: <font color=\"navy\">NAVY TEXT</font><br/>";
 echo "[darkgreen]TEXT[/darkgreen]: <font color=\"darkgreen\">DARK GREEN TEXT</font><br/>";
 echo "[lightgreen]TEXT[/lightgreen]: <font color=\"lightgreen\">LIGHT GREEN TEXT</font><br/>";
 echo "[aqua]TEXT[/aqua]: <font color=\"aqua\">AQUA TEXT</font><br/>";
 echo "[litegreen]TEXT[/litegreen]: <font color=\"litegreen\">LITE GREEN TEXT</font><br/>";
 echo "[lightseagreen]TEXT[/lightseagreen]: <font color=\"lightseagreen\">LIGHT SEA GREEN TEXT</font><br/>";
 echo "[aquamarine]TEXT[/aquamarine]: <font color=\"aquamarine\">AQUAMARINE TEXT</font><br/>";
 echo "[maroon]TEXT[/maroon]: <font color=\"maroon\">MAROON TEXT</font><br/>";
 echo "[mediumturquiose]TEXT[/mediumturquiose]: <font color=\"mediumturquiose\">MEDIUMTURQUIOSE TEXT</font><br/>";
 echo "[purple]TEXT[/purple]: <font color=\"purple\">PURPLE TEXT</font><br/>";
 echo "[skyteal]TEXT[/skyteal]: <font color=\"skyteal\">SKY BLUE TEXT</font><br/>";
 echo "[darkseagreen]TEXT[/darkseagreen]: <font color=\"darkseagreen\">DARK SEA GREEN TEXT</font><br/>";
 echo "[yellowgreen]TEXT[/yellowgreen]: <font color=\"yellowgreen\">YELLOW GREEN TEXT</font><br/>";
 echo "[sienna]TEXT[/sienna]: <font color=\"sienna\">SIENNA TEXT</font><br/>";
 echo "[palegreen]TEXT[/palegreen]: <font color=\"palegreen\">PALE GREEN TEXT</font><br/>";
 echo "[greenyellow]TEXT[/greenyellow]: <font color=\"greenyellow\">GREEN YELLOW TEXT</font><br/>";
 echo "[powderteal]TEXT[/powderteal]: <font color=\"powderteal\">POWDER BLUE TEXT</font><br/>";
 echo "[tan]TEXT[/tan]: <font color=\"tan\">TAN TEXT</font><br/>";
 echo "[thistle]TEXT[/thistle]: <font color=\"thistle\">THISTLE TEXT</font><br/>";
 echo "[orchid]TEXT[/orchid]: <font color=\"orchid\">ORCHID TEXT</font><br/>";
 echo "[goldenrod]TEXT[/goldenrod]: <font color=\"goldenrod\">GOLDENROD TEXT</font><br/>";
 echo "[orangered]TEXT[/orangered]: <font color=\"orangered\">ORANGE RED TEXT</font><br/>";
 echo "[deeppink]TEXT[/deeppink]: <font color=\"deeppink\">CRIMSON TEXT</font><br/>";
 echo "[plum]TEXT[/plum]: <font color=\"plum\">PLUM TEXT</font><br/>";
 echo "[lightcyan]TEXT[/lightcyan]: <font color=\"lightcyan\">LIGHT CYAN TEXT</font><br/>";
 echo "[violet]TEXT[/violet]: <font color=\"violet\">VIOLET TEXT</font><br/>";
 echo "[khaki]TEXT[/khaki]: <font color=\"khaki\">KHAKI TEXT</font><br/>";
 echo "[magenta]TEXT[/magenta]: <font color=\"magenta\">MAGENTA TEXT</font><br/>";
 echo "[hotpink]TEXT[/hotpink]: <font color=\"hotpink\">HOT PINK TEXT</font><br/>";
 echo "[deeppink]TEXT[/deeppink]: <font color=\"deeppink\">DEEP PINK TEXT</font><br/>";
 echo "[orange]TEXT[/orange]: <font color=\"orange\">ORANGE TEXT</font><br/>";
if(ismod(getuid_sid($sid)))
{
echo "<br/><b><u>Special BBCode for Staffs.<br/>Dont Misuse This Code When Remove From Staff List:</u></b><br/><br/>";
echo "<b>@allmember@</b>: <font color=\"red\">View Username Who See This.</font><br/>";
echo "<b>@ALLMEMBER@</b>: <font color=\"green\">View Username with Profile Who See This.</font><br/>";
}
echo "</p></div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
?>
</html>