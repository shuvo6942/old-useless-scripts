<?php
session_start();
include("config.php");
include("core.php");  connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo '<head>';
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"title\" content=\"FireBD.NeT\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From Shahos: Don't Try To Hack OR else :P\">
<meta name=\"keywords\" content=\"Site Desined By Shahos :) :)\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/></head>";
echo "<body>";
$action = $_GET["action"]; $sid = $_SESSION["sid"];
$clid = $_GET["clid"]; $page = $_GET["page"];
$who = $_GET["who"];
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();
////////////////Ip Banned By CJ UDAY :)	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
    echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
echo "<br/>";
echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
$banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
$remain =  $banto[0] - time();
$rmsg = gettimemsg($remain);
echo "<b>Time Remaining: $rmsg</b><br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "</p>";
echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
/////////////////Banned System Updated By CJ UDAY :)
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please With Contact Us <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
 echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
 echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
///////////////////Deactivated Account Created By CJ UDAY :)
          if(isdeactivated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  <b>Your Account Has Been Deactivated Forever.<br/>And It Will Be Never Activate!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
///////////////////Validation By CJ UDAY :)
					if(isvalidated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  You Are Not Validated!<br/>We are checking your ip and browser<br/>
	  This could take up to 15 munites pls be patient and try again soon<br/>Please try again later...<br/><b>Thank You</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
///////////////////////////////Search Updated By CJ UDAY :)
if($action=="")
{
$whnick = getnick_uid($uid);
addonline(getuid_sid($sid),"Viewing Search Menu","search.php?action=$action");
echo "<head>";
echo "<title>View Search Menu</title>";
  echo "</head>"; 
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Search Menu</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<br/>";
echo "<b><u>MyDhaka Search Area:</b></u><br/>";
echo "<img src=\"../avatars/forums.gif\"><a href=\"search.php?action=frm\">Search In Forums</a><br/>";
echo "<img src=\"../avatars/literature.gif\"><a href=\"search.php?action=let\">Search In Article</a><br/>";
echo "<img src=\"../avatars/blogs.gif\"><a href=\"search.php?action=blg\">Search In Blogs</a><br/>";
echo "<img src=\"../avatars/polls.gif\"><a href=\"search.php?action=poll\">Search In Polls</a><br/>";
echo "<img src=\"../avatars/unread.gif\"><a href=\"search.php?action=nbx\">Search In Messages</a><br/>";
echo "<img src=\"../avatars/clubs.gif\"><a href=\"search.php?action=clb\">Search In Clubs</a><br/>";
echo "<img src=\"../avatars/menu.gif\"><a href=\"search.php?action=mbrn\">Search In Members</a><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
////////////////////////////Forums By CJ UDAY :-)
else if($action=="frm")
{
    addonline(getuid_sid($sid),"Searching In Topics","search.php?action=$action");
echo "<head>";
echo "<title>Search Topics</title>";
  echo "</head>"; 
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
    echo "</div>";
    echo "<div class=\"header\" align=\"center\">";
	echo "<b>Search Forums</b></div>";
	echo "<div class=\"shout2\" align=\"left\">";
	include("pm_by.php");
	echo "<br/>";
	echo "<form action=\"search.php?action=sfrm\" method=\"post\">";
    echo "<b><img src=\"../avatars/forums.gif\"> Text:</b><br/> <input name=\"stext\" maxlength=\"30\"/><br/>";
    echo "<b>Order By:</b><br/> <select name=\"sor\">";
    echo "<option value=\"1\">Newest</option>";
    echo "<option value=\"2\">Oldest</option>";
    echo "</select><br/>";
	echo "<b>In:</b><br/> <select name=\"sin\">";
    echo "<option value=\"1\">Topic Posts</option>";
    echo "<option value=\"2\">Topic Text</option>";
    echo "<option value=\"3\">Topic Title</option>";
    echo "</select><br/>";
   echo "<input type=\"submit\" value=\"Search\"/>";    
    echo "</form>";
	echo "<br/><br/>";
	echo "<img src=\"../avatars/prev.gif\" alt=\"&#171;\"><a href=\"search.php\"><b>Back to Search Menu</b></a>";
    echo "<br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
////////////////////////////Article by CJ UDAY :-)
else if($action=="let")
{
    addonline(getuid_sid($sid),"Searching In Article","search.php?action=$action");
echo "<head>";
echo "<title>Search Article</title>";
  echo "</head>"; 
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
    echo "<div class=\"header\" align=\"center\">";
	echo "<b>Search Article</b></div>";
	echo "<div class=\"shout2\" align=\"left\">";
	include("pm_by.php");
	echo "<br/>";
	echo "<form action=\"search.php?action=slet\" method=\"post\">";
    echo "<b><img src=\"../avatars/literature.gif\"> Text:</b><br/>  <input name=\"stext\" maxlength=\"30\"/><br/>";
    echo "<b>Order By:</b><br/> <select name=\"sor\">";
    echo "<option value=\"1\">Newest</option>";
    echo "<option value=\"2\">Oldest</option>";
    echo "</select><br/>";
	echo "<b>In:</b><br/>  <select name=\"sin\">";
    echo "<option value=\"1\">Article Comments</option>";
    echo "<option value=\"2\">Article Text</option>";
    echo "<option value=\"3\">Article Title</option>";
    echo "</select><br/>";
   echo "<input type=\"submit\" value=\"Search\"/>";    
    echo "</form>";
	echo "<br/><br/>";
	echo "<img src=\"../avatars/prev.gif\" alt=\"&#171;\"><a href=\"search.php\"><b>Back to Search Menu</b></a>";
    echo "<br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
//////////////////////////Blogs by CJ UDAY :-)
else if($action=="blg")
{
    addonline(getuid_sid($sid),"Searching In Blogs","search.php?action=$action");
echo "<head>";
echo "<title>Search Blogs</title>";
  echo "</head>"; 
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
    echo "<div class=\"header\" align=\"center\">";
	echo "<b>Search Blogs</b></div>";
	echo "<div class=\"shout2\" align=\"left\">";
	include("pm_by.php");
	echo "<br/>";
	echo "<form action=\"search.php?action=sblg\" method=\"post\">";
    echo "<b><img src=\"../avatars/blogs.gif\"> Text:</b><br/> <input name=\"stext\" maxlength=\"30\"/><br/>";
    echo "<b>Order By:</b><br/> <select name=\"sor\">";
    echo "<option value=\"1\">Blog Title</option>";
    echo "<option value=\"2\">Time</option>";
    echo "</select><br/>";
    echo "<b>In:</b><br/> <select name=\"sin\">";
    echo "<option value=\"1\">Blog Text</option>";
    echo "<option value=\"2\">Blog Title</option>";
    echo "</select><br/>";
  	echo "<input type=\"submit\" value=\"Search\"/>";    
    echo "</form>";
	echo "<br/><br/>";
	echo "<img src=\"../avatars/prev.gif\" alt=\"&#171;\"><a href=\"search.php\"><b>Back to Search Menu</b></a>";
    echo "<br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
//////////////////////////Polls by CJ UDAY :-)
else if($action=="poll")
{
    addonline(getuid_sid($sid),"Searching In Polls","search.php?action=$action");
echo "<head>";
echo "<title>Search Polls</title>";
 echo "</head>"; 
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
    echo "<div class=\"header\" align=\"center\">";
	echo "<b>Search Polls</b></div>";
	echo "<div class=\"shout2\" align=\"left\">";
	include("pm_by.php");
	echo "<br/>";
	echo "<form action=\"search.php?action=spoll\" method=\"post\">";
    echo "<b><img src=\"../avatars/polls.gif\"> Text:</b><br/> <input name=\"stext\" maxlength=\"30\"/><br/>";
    echo "<b>Order By:</b><br/> <select name=\"sor\">";
    echo "<option value=\"1\">Poll Title</option>";
    echo "<option value=\"2\">Poll Time</option>";
    echo "</select><br/>";
    echo "<b>In:</b><br/> <select name=\"sin\">";
    echo "<option value=\"1\">Poll Question</option>";
    echo "<option value=\"2\">Poll Title</option>";
    echo "</select><br/>";
  	echo "<input type=\"submit\" value=\"Search\"/>";    
    echo "</form>";
	echo "<br/><br/>";
	echo "<img src=\"../avatars/prev.gif\" alt=\"&#171;\"><a href=\"search.php\"><b>Back to Search Menu</b></a>";
    echo "<br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
//////////////////////////Clubs by CJ UDAY :-)
else if($action=="clb")
{ 
    addonline(getuid_sid($sid),"Searching For Club","search.php?action=$action");
echo "<head>";
echo "<title>Search Clubs</title>";
  echo "</head>"; 
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
    echo "<div class=\"header\" align=\"center\">";
	echo "<b>Search Clubs</b></div>";
	echo "<div class=\"shout2\" align=\"left\">";
	include("pm_by.php");
	echo "<br/>";
	echo "<form action=\"search.php?action=sclb&clid=$clid&who=$who\" method=\"post\">";
    echo "<b><img src=\"../avatars/clubs.gif\"> Text:</b><br/> <input name=\"stext\" maxlength=\"30\"/><br/>";
    echo "<b>Order By:</b><br/> <select name=\"sor\">";
    echo "<option value=\"1\">Club Name</option>";
    echo "<option value=\"2\">Oldest Club</option>";
    echo "<option value=\"3\">Newest Club</option>";
    echo "</select><br/>";
    echo "<b>In:</b><br/> <select name=\"sin\">";
    echo "<option value=\"1\">Club Description</option>";
    echo "<option value=\"2\">Club Name</option>";
    echo "</select><br/>";
  	echo "<input type=\"submit\" value=\"Search\"/>";    
    echo "</form>";
	echo "<br/><br/>";
	echo "<img src=\"../avatars/prev.gif\" alt=\"&#171;\"><a href=\"search.php\"><b>Back to Search Menu</b></a>";
    echo "<br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
////////////////////////////Messages by CJ UDAY :-)
else if($action=="nbx")
{
    addonline(getuid_sid($sid),"Searching In Messages","search.php?action=$action");
echo "<head>";
echo "<title>Search Messages</title>";
 echo "</head>"; 
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
    echo "<div class=\"header\" align=\"center\">";
	echo "<b>Search Messages</b></div>";
	echo "<div class=\"shout2\" align=\"left\">";
	include("pm_by.php");
	echo "<br/>";
	echo "<form action=\"search.php?action=smsg\" method=\"post\">";
    echo "<b><img src=\"../avatars/unread.gif\"> Text:</b><br/> <input name=\"stext\" maxlength=\"30\"/><br/>";
    echo "<b>Order By:</b><br/> <select name=\"sor\">";
    echo "<option value=\"1\">Newest Messages</option>";
    echo "<option value=\"2\">Oldest Messages</option>";
    echo "<option value=\"2\">Sender Name</option>";
    echo "</select><br/>";
	echo "<b>In:</b><br/> <select name=\"sin\">";
    echo "<option value=\"1\">Recieved Messages</option>";
	echo "<option value=\"2\">Sent Messages</option>";
    echo "<option value=\"3\">Sender Name</option>";
    echo "</select><br/>";
    echo "<input type=\"submit\" value=\"Search\"/>";    
    echo "</form>";
	echo "<br/><br/>";
	echo "<img src=\"../avatars/prev.gif\" alt=\"&#171;\"><a href=\"search.php\"><b>Back to Search Menu</b></a>";
    echo "<br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
////////////////////////////Members by CJ UDAY
else if($action=="mbrn")
{
    addonline(getuid_sid($sid),"Searching For Members","search.php?action=$action");
echo "<head>";
echo "<title>Search Members</title>";
 echo "</head>"; 
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
 echo "</div>";
    echo "<div class=\"header\" align=\"center\">";
	echo "<b>Search Members</b></div>";
	echo "<div class=\"shout2\" align=\"left\">";
	include("pm_by.php");
	echo "<br/>";
	echo "<form action=\"search.php?action=smbr\" method=\"post\">";
    echo "<b><img src=\"../avatars/menu.gif\"> Nickname:</b><br/> <input name=\"stext\" maxlength=\"15\"/><br/>";
    echo "<b>Order By:</b><br/> <select name=\"sor\">";
    echo "<option value=\"1\">Member Name</option>";
    echo "<option value=\"2\">Last Active</option>";
    echo "<option value=\"3\">Join Date</option>";
    echo "</select><br/>";
   	echo "<input type=\"submit\" value=\"Search\"/>";    
    echo "</form>";
	echo "<br/><br/>";
	echo "<img src=\"../avatars/prev.gif\" alt=\"&#171;\"><a href=\"search.php\"><b>Back to Search Menu</b></a>";
    echo "<br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
//////////////////////////Search Forums by CJ UDAY :-)
else if($action=="sfrm")
{
  $stext = mysql_real_escape_string($_POST["stext"]);
  $sin = mysql_real_escape_string($_POST["sin"]);
  $sor = mysql_real_escape_string($_POST["sor"]);
    addonline(getuid_sid($sid),"Searching For Forums","search.php?action=");
echo "<head>";
echo "<title>Search Forums</title>";
 echo "</head>"; 
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
    echo "<div class=\"header\" align=\"center\">";
	echo "<b>Search Forums</b></div>";
	echo "<div class=\"shout2\" align=\"left\">";
    include("pm_by.php");
	echo "<br/>";
        if(trim($stext)=="")
        {
    echo "<img src=\"../avatars/notok.gif\"><b>No Result Found!</b><br/><br/>";
	echo "<img src=\"../avatars/prev.gif\" alt=\"&#171;\"><a href=\"search.php?action=frm\"><b>Back to Forum Search</b></a>";
    echo "<br/><br/>";
        }else{
         if($page=="" || $page<1)$page=1;
          if($sin=="1")
          {
            $where_table = "ibwff_posts";
            $cond = "text";
            $select_fields = "id, tid";
            if($sor=="1")
            {
              $ord_fields = "dtpost DESC";
            }else{
                $ord_fields = "dtpost";
            }
          }else if($sin=="2")
          {
            $where_table = "ibwff_topics";
            $cond = "text";
            $select_fields = "name, id";
            if($sor=="1")
            {
              $ord_fields = "crdate DESC";
            }else{
                $ord_fields = "crdate";
            }
          }else if($sin=="3")
          {
            $where_table = "ibwff_topics";
            $cond = "name";
            $select_fields = "name, id";
            if($sor=="1")
            {
              $ord_fields = "crdate DESC";
            }else{
                $ord_fields = "crdate";
            }
          }
          $noi = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ".$where_table." WHERE ".$cond." LIKE '%".$stext."%'"));
          $num_items = $noi[0];
          $items_per_page = 10;
          $num_pages = ceil($num_items/$items_per_page);
    if(($page>$num_pages)&&$page!=1)$page= $num_pages;
    $limit_start = ($page-1)*$items_per_page;    
    $sql = "SELECT ".$select_fields." FROM ".$where_table." WHERE ".$cond." LIKE '%".$stext."%' ORDER BY ".$ord_fields." LIMIT $limit_start, $items_per_page";
          $items = mysql_query($sql);
          while($item=mysql_fetch_array($items))
          {
            if($sin=="1")
            {
              $tname = htmlspecialchars(gettname($item[1]));
if($tname=="" || !canaccess(getuid_sid($sid),getfid_tid($item[1]))){
                $tlink = "Unreachable<br/>";
              }else{
              $tlink = "<img src=\"../avatars/forums.gif\"><a href=\"forums.php?tid=$item[1]&go=$item[0]\">".$tname."</a><br/>";
              }
                echo  $tlink;
            }
            else
            {
              $tname = htmlspecialchars($item[0]);
              if($tname=="" || !canaccess(getuid_sid($sid),getfid_tid($item[1]))){
                $tlink = "Unreachable<br/>";
              }else{
              $tlink = "<img src=\"../avatars/forums.gif\"><a href=\"forums.php?tid=$item[1]\">".$tname."</a>";
              }
                echo  $tlink;
            }
          }
	    if($page>1)
    {
      $ppage = $page-1;
      echo "<a href=\"search.php?action=$action&page=$npage\">&#171;-Prev</a> ";
    }
    if($page<$num_pages)
    {
      $npage = $page+1;
      echo "<a href=\"search.php?action=$action&page=$npage\">Next-&#187;</a>";
    }
    echo "<br/>Page - $page/$num_pages<br/>";
    if($num_pages>2)
    {
        $rets = "<form action=\"search.php\" method=\"get\">";
        $rets .= "<input name=\"page\" style=\"-wap-input-format: '*N'\" size=\"2\"/>";
        $rets .= "<input type=\"hidden\" name=\"stext\" value=\"$stext\"/>";
        $rets .= "<input type=\"hidden\" name=\"sin\" value=\"$sin\"/>";
		$rets .= "<input type=\"hidden\" name=\"sor\" value=\"$sor\"/>";
		$rets .= "<input type=\"submit\" value=\"Go To Page\"/>";
        $rets .= "</form>";
        echo $rets;
    }
	echo "<br/><br/>";
	echo "<img src=\"../avatars/prev.gif\" alt=\"&#171;\"><a href=\"search.php?action=frm\"><b>Back to Forum Search</b></a>";
    echo "<br/><br/>";
    echo "</p>";
        } 
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
////////////////////////Search Literature by CJ UDAY :-)
else if($action=="slet")
{
  $stext = mysql_real_escape_string($_POST["stext"]);
  $sin = mysql_real_escape_string($_POST["sin"]);
  $sor = mysql_real_escape_string($_POST["sor"]);
    addonline(getuid_sid($sid),"Searching For Article","search.php?action=");
echo "<head>";
echo "<title>Search Literature</title>";
  echo "</head>"; 
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
    echo "<div class=\"header\" align=\"center\">";
	echo "<b>Search Article</b></div>";
	echo "<div class=\"shout2\" align=\"left\">";
	include("pm_by.php");
    echo "<br/>";
        if(trim($stext)=="")
        {
    echo "<img src=\"../avatars/notok.gif\"><b>No Result Found!</b><br/><br/>";
	echo "<img src=\"../avatars/prev.gif\" alt=\"&#171;\"><a href=\"search.php?action=let\"><b>Back to Literatures Search</b></a>";
    echo "<br/><br/>";
        }else{
          if($page=="" || $page<1)$page=1;
          if($sin=="1")
          {
            $where_table = "ibwff_storyposts";
            $cond = "text";
            $select_fields = "id, tid";
            if($sor=="1")
            {
              $ord_fields = "dtpost DESC";
            }else{
                $ord_fields = "dtpost";
            }
          }else if($sin=="2")
          {
            $where_table = "ibwff_storys";
            $cond = "text";
            $select_fields = "name, id";
            if($sor=="1")
            {
              $ord_fields = "crdate DESC";
            }else{
                $ord_fields = "crdate";
            }
          }else if($sin=="3")
          {
            $where_table = "ibwff_storys";
            $cond = "name";
            $select_fields = "name, id";
            if($sor=="1")
            {
              $ord_fields = "crdate DESC";
            }else{
                $ord_fields = "crdate";
            }
          }
          $noi = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ".$where_table." WHERE ".$cond." LIKE '%".$stext."%'"));
          $num_items = $noi[0];
          $items_per_page = 10;
          $num_pages = ceil($num_items/$items_per_page);
    if(($page>$num_pages)&&$page!=1)$page= $num_pages;
    $limit_start = ($page-1)*$items_per_page;
        $sql = "SELECT ".$select_fields." FROM ".$where_table." WHERE ".$cond." LIKE '%".$stext."%' ORDER BY ".$ord_fields." LIMIT $limit_start, $items_per_page";
          $items = mysql_query($sql);
          while($item=mysql_fetch_array($items))
          {
            if($sin=="1")
            {
              $tname = htmlspecialchars(gettname($item[1]));
			  
              if($tname==""){
                $tlink = "Unreachable<br/>";
              }else{
              $tlink = "<img src=\"../avatars/literature.gif\"><a href=\"literature.php?action=viewstory&tid=$item[1]&go=$item[0]\">".$tname."</a><br/>";
              }
                echo  $tlink;
            }else{
              $tname = htmlspecialchars($item[0]);
              if($tname==""){
                $tlink = "Unreachable<br/>";
              }else{
              $tlink = "<img src=\"../avatars/literature.gif\"><a href=\"literature.php?action=viewstory&tid=$item[1]\">".$tname."</a>";
              }
                echo  $tlink;
            }
          }
	    if($page>1)
    {
      $ppage = $page-1;
      echo "<a href=\"search.php?action=$action&page=$npage\">&#171;-Prev</a> ";
    }
    if($page<$num_pages)
    {
      $npage = $page+1;
      echo "<a href=\"search.php?action=$action&page=$npage\">Next-&#187;</a>";
    }
    echo "<br/>Page - $page/$num_pages<br/>";
    if($num_pages>2)
    {
        $rets = "<form action=\"search.php\" method=\"get\">";
        $rets .= "<input name=\"page\" style=\"-wap-input-format: '*N'\" size=\"2\"/>";
        $rets .= "<input type=\"hidden\" name=\"stext\" value=\"$stext\"/>";
        $rets .= "<input type=\"hidden\" name=\"sin\" value=\"$sin\"/>";
		$rets .= "<input type=\"hidden\" name=\"sor\" value=\"$sor\"/>";
        $rets .= "<input type=\"submit\" value=\"Go To Page\"/>";
        $rets .= "</form>";
        echo $rets;
    }
	echo "<br/><br/>";
	echo "<img src=\"../avatars/prev.gif\" alt=\"&#171;\"><a href=\"search.php?action=let\"><b>Back to Articles Search</b></a>";
    echo "<br/><br/>";
    echo "</p>";
        }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
////////////////////////////////Search Blogs By CJ UDAY :-)
else if($action=="sblg")
{
  $stext = mysql_real_escape_string($_POST["stext"]);
  $sin = mysql_real_escape_string($_POST["sin"]);
  $sor = mysql_real_escape_string($_POST["sor"]);
    addonline(getuid_sid($sid),"Searching In Blogs","search.php?action=$action");
echo "<head>";
echo "<title>Search Blogs</title>";
  echo "</head>"; 
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
    echo "<div class=\"header\" align=\"center\">";
	echo "<b>Search Blogs</b></div>";
	echo "<div class=\"shout2\" align=\"left\">";
	include("pm_by.php");
    echo "<br/>";
        if(trim($stext)=="")
        {
    echo "<img src=\"../avatars/notok.gif\"><b>No Result Found!</b><br/><br/>";
	echo "<img src=\"../avatars/prev.gif\" alt=\"&#171;\"><a href=\"search.php?action=blg\"><b>Back to Blogs Search</b></a>";
    echo "<br/><br/>";
        }else{
          if($page=="" || $page<1)$page=1;
          if($sin=="1")
          {
            $where_table = "ibwff_blogs";
            $cond = "btext";
            $select_fields = "id, bname";
            if($sor=="1")
            {
              $ord_fields = "bname";
            }else{
                $ord_fields = "bgdate DESC";
            }
          }else if($sin=="2")
          {
            $where_table = "ibwff_blogs";
            $cond = "bname";
            $select_fields = "id, bname";
            if($sor=="1")
            {
              $ord_fields = "bname";
            }else{
                $ord_fields = "bgdate DESC";
            }
          }
          $noi = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ".$where_table." WHERE ".$cond." LIKE '%".$stext."%'"));
          $num_items = $noi[0];
          $items_per_page = 10;
          $num_pages = ceil($num_items/$items_per_page);
    if(($page>$num_pages)&&$page!=1)$page= $num_pages;
    $limit_start = ($page-1)*$items_per_page;
    $sql = "SELECT ".$select_fields." FROM ".$where_table." WHERE ".$cond." LIKE '%".$stext."%' ORDER BY ".$ord_fields." LIMIT $limit_start, $items_per_page";
          $items = mysql_query($sql);
          while($item=mysql_fetch_array($items))
          {
              $tlink = "<img src=\"../avatars/blogs.gif\"><a href=\"blogs.php?bid=$item[0]&go=$item[0]\">".htmlspecialchars($item[1])."</a><br/>";
                echo  $tlink;        
          }
   if($page>1)
    {
      $ppage = $page-1;
      echo "<a href=\"search.php?action=$action&page=$ppage\">&#171;-Prev</a> ";
    }
    if($page<$num_pages)
    {
      $npage = $page+1;
      echo "<a href=\"search.php?action=$action&page=$npage\">Next-&#187;</a>";
    }
    echo "<br/>Page - $page/$num_pages<br/>";
	echo "</p>";
	    echo "<p align=\"left\">";
   if($num_pages>2)
    {
			        $rets = "<form action=\"search.php\" method=\"get\">";
        $rets .= "<input name=\"page\" style=\"-wap-input-format: '*N'\" size=\"2\"/>";
        $rets .= "<input type=\"hidden\" name=\"action\" value=\"$action\"/>";
        $rets .= "<input type=\"hidden\" name=\"sid\" value=\"$sid\"/>";
   $rets .= "<input type=\"submit\" value=\"Go To Page\"/>";
        $rets .= "</form>";
        echo $rets;
    }
	echo "<br/><br/>";
	echo "<img src=\"../avatars/prev.gif\" alt=\"&#171;\"><a href=\"search.php?action=blg\"><b>Back to Blogs Search</b></a>";
    echo "<br/><br/>";
    echo "</p>";
        }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
////////////////////////////////Search Polls By CJ UDAY :-)
else if($action=="spoll")
{
  $stext = mysql_real_escape_string($_POST["stext"]);
  $sin = mysql_real_escape_string($_POST["sin"]);
  $sor = mysql_real_escape_string($_POST["sor"]);
    addonline(getuid_sid($sid),"Searching In Polls","search.php?action=$action");
echo "<head>";
echo "<title>Search Polls</title>";
  echo "</head>"; 
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
    echo "<div class=\"header\" align=\"center\">";
	echo "<b>Search Polls</b></div>";
	echo "<div class=\"shout2\" align=\"left\">";
	include("pm_by.php");
    echo "<br/>";
        if(trim($stext)=="")
        {
    echo "<img src=\"../avatars/notok.gif\"><b>No Result Found!</b><br/><br/>";
	echo "<img src=\"../avatars/prev.gif\" alt=\"&#171;\"><a href=\"search.php?action=poll\"><b>Back to Polls Search</b></a>";
    echo "<br/><br/>";
        }else{
          if($page=="" || $page<1)$page=1;
          if($sin=="1")
          {
            $where_table = "ibwff_polls";
            $cond = "pqst";
            $select_fields = "id, pqst";
            if($sor=="1")
            {
              $ord_fields = "pqst";
            }else{
                $ord_fields = "pdt DESC";
            }
          }else if($sin=="2")
          {
            $where_table = "ibwff_polls";
            $cond = "pqst";
            $select_fields = "id, pqst";
            if($sor=="1")
            {
              $ord_fields = "pqst";
            }else{
                $ord_fields = "pdt DESC";
            }
          }
          $noi = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ".$where_table." WHERE ".$cond." LIKE '%".$stext."%'"));
          $num_items = $noi[0];
          $items_per_page = 10;
          $num_pages = ceil($num_items/$items_per_page);
    if(($page>$num_pages)&&$page!=1)$page= $num_pages;
    $limit_start = ($page-1)*$items_per_page;

    $sql = "SELECT ".$select_fields." FROM ".$where_table." WHERE ".$cond." LIKE '%".$stext."%' ORDER BY ".$ord_fields." LIMIT $limit_start, $items_per_page";
          $items = mysql_query($sql);
          while($item=mysql_fetch_array($items))
          {
              $tlink = "<img src=\"../avatars/polls.gif\"><a href=\"polls.php?who=$item[0]&go=$item[0]\">".htmlspecialchars($item[1])."</a><br/>";
                echo  $tlink;        
          }
   if($page>1)
    {
      $ppage = $page-1;
      echo "<a href=\"search.php?action=$action&page=$ppage\">&#171;-Prev</a> ";
    }
    if($page<$num_pages)
    {
      $npage = $page+1;
      echo "<a href=\"search.php?action=$action&page=$npage\">Next-&#187;</a>";
    }
    echo "<br/>Page - $page/$num_pages<br/>";
if($num_pages>2)
    {
			        $rets = "<form action=\"search.php\" method=\"get\">";
        $rets .= "<input name=\"page\" style=\"-wap-input-format: '*N'\" size=\"2\"/>";
        $rets .= "<input type=\"hidden\" name=\"action\" value=\"$action\"/>";
        $rets .= "<input type=\"hidden\" name=\"sid\" value=\"$sid\"/>";
   $rets .= "<input type=\"submit\" value=\"Go To Page\"/>";
        $rets .= "</form>";
        echo $rets;
    }
	echo "<br/><br/>";
	echo "<img src=\"../avatars/prev.gif\" alt=\"&#171;\"><a href=\"search.php?action=blg\"><b>Back to Blogs Search</b></a>";
    echo "<br/><br/>";
    echo "</p>";
        }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
/////////////////////////////Search Club by CJ UDAY
else if($action=="sclb")
{
  $stext = mysql_real_escape_string($_POST["stext"]);
  $sin = mysql_real_escape_string($_POST["sin"]);
  $sor = mysql_real_escape_string($_POST["sor"]);
    addonline(getuid_sid($sid),"Searching For Clubs","search.php?action=$action");
echo "<head>";
echo "<title>Search Clubs</title>";
 echo "</head>"; 
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
    echo "<div class=\"header\" align=\"center\">";
	echo "<b>Search Clubs</b></div>";
	echo "<div class=\"shout2\" align=\"left\">";
	include("pm_by.php");
    echo "<br/>";
        if(trim($stext)=="")
        {
    echo "<img src=\"../avatars/notok.gif\"><b>No Result Found!</b><br/><br/>";
	echo "<img src=\"../avatars/prev.gif\" alt=\"&#171;\"><a href=\"search.php?action=clb\"><b>Back to Clubs Search</b></a>";
    echo "<br/><br/>";
        }else{
          if($page=="" || $page<1)$page=1;
          if($sin=="1")
          {
            $where_table = "ibwff_clubs";
            $cond = "description";
            $select_fields = "id, name";
            if($sor=="1")
            {
              $ord_fields = "name";
            }else if($sor=="2"){
                $ord_fields = "created";
            }else if($sor=="3"){
                $ord_fields = "created DESC";
            }
          }else if($sin=="2")
          {
            $where_table = "ibwff_clubs";
            $cond = "name";
            $select_fields = "id, name";
            if($sor=="1")
            {
              $ord_fields = "name";
            }else if($sor=="2"){
                $ord_fields = "created";
            }else if($sor=="3"){
                $ord_fields = "created DESC";
            }
          }
          $noi = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ".$where_table." WHERE ".$cond." LIKE '%".$stext."%'"));
          $num_items = $noi[0];
          $items_per_page = 10;
          $num_pages = ceil($num_items/$items_per_page);
    if(($page>$num_pages)&&$page!=1)$page= $num_pages;
    $limit_start = ($page-1)*$items_per_page;
    $sql = "SELECT ".$select_fields." FROM ".$where_table." WHERE ".$cond." LIKE '%".$stext."%' ORDER BY ".$ord_fields." LIMIT $limit_start, $items_per_page";
          $items = mysql_query($sql);
          while($item=mysql_fetch_array($items))
          {
              $tlink = "<img src=\"../avatars/clubs.gif\"><a href=\"clubs.php?action=gocl&clid=$item[0]\">".htmlspecialchars($item[1])."</a><br/>";
                echo  $tlink;
          }
   if($page>1)
    {
      $ppage = $page-1;
      echo "<a href=\"search.php?action=$action&page=$ppage\">&#171;-Prev</a> ";
    }
    if($page<$num_pages)
    {
      $npage = $page+1;
      echo "<a href=\"search.php?action=$action&page=$npage\">Next-&#187;</a>";
    }
    echo "<br/>Page - $page/$num_pages<br/>";
if($num_pages>2)
    {
			        $rets = "<form action=\"search.php\" method=\"get\">";
        $rets .= "<input name=\"page\" style=\"-wap-input-format: '*N'\" size=\"2\"/>";
        $rets .= "<input type=\"hidden\" name=\"action\" value=\"$action\"/>";
        $rets .= "<input type=\"hidden\" name=\"sid\" value=\"$sid\"/>";
   $rets .= "<input type=\"submit\" value=\"Go To Page\"/>";
        $rets .= "</form>";
        echo $rets;
    }
	echo "<br/><br/>";
	echo "<img src=\"../avatars/prev.gif\" alt=\"&#171;\"><a href=\"search.php?action=clb\"><b>Back to Clubs Search</b></a>";
    echo "<br/><br/>";
    echo "</p>";
        }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
////////////////////////////////Search Messages By CJ UDAY :-)
else if($action=="smsg")
{
  $stext = mysql_real_escape_string($_POST["stext"]);
  $sin = mysql_real_escape_string($_POST["sin"]);
  $sor = mysql_real_escape_string($_POST["sor"]);
    addonline(getuid_sid($sid),"Sarching In Messages","search.php?action=$action");
echo "<head>";
echo "<title>Search Messages</title>";
  echo "</head>"; 
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
    echo "<div class=\"header\" align=\"center\">";
	echo "<b>Search Messages</b></div>";
	echo "<div class=\"shout2\" align=\"left\">";
    include("pm_by.php");
	echo "<br/>";
        $myid = getuid_sid($sid);
        if(trim($stext)=="")
        {
    echo "<img src=\"../avatars/notok.gif\"><b>No Result Found!</b><br/><br/>";
	echo "<img src=\"../avatars/prev.gif\" alt=\"&#171;\"><a href=\"search.php?action=msg\"><b>Back to Messages Search</b></a>";
    echo "<br/><br/>";
        }else{
          if($page=="" || $page<1)$page=1;
          if($sin==1)
          {
          $noi = mysql_fetch_array(mysql_query("SELECT COUNT(*)  FROM ibwff_private  WHERE text LIKE '%".$stext."%' AND touid='".$myid."'"));
		  }else if($sin==2)
		  {
			$noi = mysql_fetch_array(mysql_query("SELECT COUNT(*)  FROM ibwff_private  WHERE text LIKE '%".$stext."%' AND byuid='".$myid."'"));
          }else{
                $stext = getuid_nick($stext);
            $noi = mysql_fetch_array(mysql_query("SELECT COUNT(*)  FROM ibwff_private  WHERE byuid ='".$stext."' AND touid='".$myid."'"));
          }
          $num_items = $noi[0];
          $items_per_page = 10;
          $num_pages = ceil($num_items/$items_per_page);
    if(($page>$num_pages)&&$page!=1)$page= $num_pages;
    $limit_start = ($page-1)*$items_per_page;
          if($sin=="1")
          {           
            if($sor=="1")
            {
              $sql = "SELECT
            a.name, b.id, b.byuid, b.unread, b.starred FROM ibwff_users a
            INNER JOIN ibwff_private b ON a.id = b.byuid
            WHERE b.touid='".$myid."' AND b.text like '%".$stext."%'
            ORDER BY b.timesent DESC
            LIMIT $limit_start, $items_per_page";
            }else if($sor=="2"){
                $sql = "SELECT
            a.name, b.id, b.byuid, b.unread, b.starred FROM ibwff_users a
            INNER JOIN ibwff_private b ON a.id = b.byuid
            WHERE b.touid='".$myid."' AND b.text like '%".$stext."%'
            ORDER BY b.timesent 
            LIMIT $limit_start, $items_per_page";
            }else{
                $sql = "SELECT
            a.name, b.id, b.byuid, b.unread, b.starred FROM ibwff_users a
            INNER JOIN ibwff_private b ON a.id = b.byuid
            WHERE b.touid='".$myid."' AND b.text like '%".$stext."%'
            ORDER BY a.name
            LIMIT $limit_start, $items_per_page";
            }
          }
		  else if($sin=="2")
		  {
			if($sor=="1")
            {
              $sql = "SELECT
            a.name, b.id, b.touid, b.unread, b.starred FROM ibwff_users a
            INNER JOIN ibwff_private b ON a.id = b.byuid
            WHERE b.byuid='".$myid."' AND b.text like '%".$stext."%'
            ORDER BY b.timesent DESC
            LIMIT $limit_start, $items_per_page";
            }else if($sor=="2"){
                $sql = "SELECT
            a.name, b.id, b.touid, b.unread, b.starred FROM ibwff_users a
            INNER JOIN ibwff_private b ON a.id = b.byuid
            WHERE b.byuid='".$myid."' AND b.text like '%".$stext."%'
            ORDER BY b.timesent 
            LIMIT $limit_start, $items_per_page";
            }else{
                $sql = "SELECT
            a.name, b.id, b.touid, b.unread, b.starred FROM ibwff_users a
            INNER JOIN ibwff_private b ON a.id = b.touid
            WHERE b.byuid='".$myid."' AND b.text like '%".$stext."%'
            ORDER BY a.name
            LIMIT $limit_start, $items_per_page";
            }
		  }
		  else if($sin=="3")
          {            
            if($sor=="1")
            {
              $sql = "SELECT
            a.name, b.id, b.byuid, b.unread, b.starred FROM ibwff_users a
            INNER JOIN ibwff_private b ON a.id = b.byuid
            WHERE b.touid='".$myid."' AND b.byuid ='".$stext."'
            ORDER BY b.timesent DESC
            LIMIT $limit_start, $items_per_page";
            }else if($sor=="2"){
                $sql = "SELECT
            a.name, b.id, b.byuid, b.unread, b.starred FROM ibwff_users a
            INNER JOIN ibwff_private b ON a.id = b.byuid
            WHERE b.touid='".$myid."' AND b.byuid ='".$stext."'
            ORDER BY b.timesent
            LIMIT $limit_start, $items_per_page";
            }else{
                $sql = "SELECT
            a.name, b.id, b.byuid, b.unread, b.starred FROM ibwff_users a
            INNER JOIN ibwff_private b ON a.id = b.byuid
            WHERE b.touid='".$myid."' AND b.byuid ='".$stext."'
            ORDER BY a.name
            LIMIT $limit_start, $items_per_page";
            }
          }
                 $items = mysql_query($sql);
         while($item=mysql_fetch_array($items))
          {
              if($item[3]=="1")
      {
        $iml = "<img src=\"../avatars/ofl.gif\" alt=\"-\"/>";
      }else{
        if($item[4]=="1")
        {
            $iml = "<img src=\"../avatars/spm.gif\" alt=\"*\"/>";
        }else{
        $iml = "<img src=\"../avatars/onl.gif\" alt=\" \"/>";
        }
      }
	if(isonline($item[2]))
    {
      $iml2 = "<img src=\"../avatars/onl.gif\" alt=\" \"/>";
    }else{
        $iml2 = "<img src=\"../avatars/ofl.gif\" alt=\"-\"/>";
    }
    $sql3 = "SELECT name FROM ibwff_users WHERE id=$item[2]";
	    $sql33 = mysql_query($sql3);
	    $item3 = mysql_fetch_array($sql33);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nicks = "<font color=\"blue\"><b>".getnick_uid($item[2])."</b></font>";}
if($sex[0]=="F"){$nicks = "<font color=\"deeppink\"><b>".getnick_uid($item[2])."</b></font>";}
if($sex[0]==""){$nicks = "";}
	    $sql2 = "SELECT name FROM ibwff_users WHERE id=$item[2]";
	    $sql22 = mysql_query($sql2);
	    $item2 = mysql_fetch_array($sql22);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item2[0]'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/>";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/>";}
if($sex[0]==""){$usersex = "";}
        		$avlink = getavatar($item[2]);
if($avlink=="")
{
 $avt =  "$usersex";
}else{
 $avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"icon\" width=\"23\" height=\"18\"/>";
}
$noi = mysql_fetch_array(mysql_query("SELECT lastact FROM ibwff_users WHERE id='".$item[2]."'"));
$remain = time() - $noi[0];
$idle = gettimemsg($remain);
      $lnk = "<a href=\"inbox.php?action=readpm&pmid=$item[1]\">$iml2 $avt$nicks</a>&#187; <b>(".getstatus($item[2]).")</b><br/><small>[Idle: $idle]</small>";
      echo "$lnk<br/>";
	  }
	  }
          }
    if($page>1)
    {
      $ppage = $page-1;
      echo "<a href=\"search.php?action=$action&page=$ppage\">&#171;-Prev</a> ";
    }
    if($page<$num_pages)
    {
      $npage = $page+1;
      echo "<a href=\"search.php?action=$action&page=$npage\">Next-&#187;</a>";
    }
    echo "<br/>Page - $page/$num_pages<br/>";
if($num_pages>2)
    {
			        $rets = "<form action=\"search.php\" method=\"get\">";
        $rets .= "<input name=\"page\" style=\"-wap-input-format: '*N'\" size=\"2\"/>";
        $rets .= "<input type=\"hidden\" name=\"action\" value=\"$action\"/>";
        $rets .= "<input type=\"hidden\" name=\"sid\" value=\"$sid\"/>";
   $rets .= "<input type=\"submit\" value=\"Go To Page\"/>";
        $rets .= "</form>";
        echo $rets;
    }
	echo "<br/><br/>";
	echo "<img src=\"../avatars/prev.gif\" alt=\"&#171;\"><a href=\"search.php?action=msg\"><b>Back to Messages Search</b></a>";
    echo "<br/><br/>";
    echo "</p>";
        }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
///////////////////Search Members by CJ UDAY :-)
else if($action=="smbr")
{
	$stext = mysql_real_escape_string($_POST["stext"]);
  $sin = mysql_real_escape_string($_POST["sin"]);
  $sor = mysql_real_escape_string($_POST["sor"]);
    addonline(getuid_sid($sid),"Searching For Members","search.php?action=");
echo "<head>";
echo "<title>Search Members</title>";
  echo "</head>"; 
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
    echo "<div class=\"header\" align=\"center\">";
	echo "<b>Search Members</b></div>";
	echo "<div class=\"shout2\" align=\"left\">";
	include("pm_by.php");
    echo "<br/>";
        if(trim($stext)=="")
        {
    echo "<img src=\"../avatars/notok.gif\"><b>No Result Found!</b><br/><br/>";
	echo "<img src=\"../avatars/prev.gif\" alt=\"&#171;\"><a href=\"search.php?action=mbrn\"><b>Back to Members Search</b></a>";
    echo "<br/><br/>";
        }else{
         if($page=="" || $page<1)$page=1; 
            $where_table = "ibwff_users";
            $cond = "name";
            $select_fields = "id, name";
            if($sor=="1")
            {
              $ord_fields = "name";
            }else if($sor=="2"){
                $ord_fields = "lastact DESC";
            }else if($sor=="3"){
                $ord_fields = "regdate";
            }
          $noi = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ".$where_table." WHERE ".$cond." LIKE '%".$stext."%'"));
          $num_items = $noi[0];
          $items_per_page = 10;
          $num_pages = ceil($num_items/$items_per_page);
    if(($page>$num_pages)&&$page!=1)$page= $num_pages;
    $limit_start = ($page-1)*$items_per_page;
    $sql = "SELECT ".$select_fields." FROM ".$where_table." WHERE ".$cond." LIKE '%".$stext."%' ORDER BY ".$ord_fields." LIMIT $limit_start, $items_per_page";
          $items = mysql_query($sql);
          while($item=mysql_fetch_array($items))
          {
	    $sql2 = "SELECT name FROM ibwff_users WHERE id=$item[0]";

	    $sql22 = mysql_query($sql2);
	    $item2 = mysql_fetch_array($sql22);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item2[0]'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/>";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/>";}
if($sex[0]==""){$usersex = "";}
        		$avlink = getavatar($item[0]);
if($avlink=="")
{
 $avt =  "$usersex";
}else{
 $avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"icon\" width=\"23\" height=\"18\"/>";
}
	if(isonline($item[0]))
    {
      $iml = "<font color=\"green\"/>online!</font>";
    }else{
        $iml = "<font color=\"red\"/>offline!</font>";
    }
$noi = mysql_fetch_array(mysql_query("SELECT lastact FROM ibwff_users WHERE id='".$item[0]."'"));
$remain = time() - $noi[0];
$idle = gettimemsg($remain);
	    $sql3 = "SELECT name FROM ibwff_users WHERE id=$item[0]";
	    $sql33 = mysql_query($sql3);
	    $item3 = mysql_fetch_array($sql33);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nicks = "<font color=\"blue\"><b>".htmlspecialchars($item[1])."</b></font>";}
if($sex[0]=="F"){$nicks = "<font color=\"deeppink\"><b>".htmlspecialchars($item[1])."</b></font>";}
if($sex[0]==""){$nicks = "";}
              $tlink = "<a href=\"profile.php?who=$item[0]\">$avt$nicks</a>&#187; <b>(".getstatus($item[0]).")</b> <small>$iml</small>";
                echo  $tlink;
				echo "<br/><small>[Idle: $idle]</small><br/>";
           }
		   }
          }
    if($page>1)
    {
      $ppage = $page-1;
      echo "<a href=\"search.php?action=$action&page=$ppage\">&#171;-Prev</a> ";
    }
    if($page<$num_pages)
    {
      $npage = $page+1;
      echo "<a href=\"search.php?action=$action&page=$npage\">Next-&#187;</a>";
    }
    echo "<br/>Page - $page/$num_pages<br/>";
    if($num_pages>2)
    {
			        $rets = "<form action=\"search.php\" method=\"get\">";
        $rets .= "<input name=\"page\" style=\"-wap-input-format: '*N'\" size=\"2\"/>";
        $rets .= "<input type=\"hidden\" name=\"action\" value=\"$action\"/>";
        $rets .= "<input type=\"hidden\" name=\"sid\" value=\"$sid\"/>";
        $rets .= "<input type=\"submit\" value=\"Go To Page\"/>";
        $rets .= "</form>";
        echo $rets;
    }
	echo "<br/><br/>";
    echo "<img src=\"../avatars/prev.gif\" alt=\"&#171;\"><a href=\"search.php?action=mbrn\"><b>Back to Members Search</b></a>";
    echo "<br/><br/>";
    echo "</p>";
        }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
?>
</html>