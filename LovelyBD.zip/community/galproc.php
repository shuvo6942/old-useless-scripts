<?php
session_start();
include("config.php");
include("core.php");  connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo '<head>';
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"title\" content=\"FireBD.NeT\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From CJ UDAY: Don't Try To Hack OR else :P\">
<meta name=\"keywords\" content=\"Site Desined By CJ UDAY :) :)\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/></head>";
echo "<body>";
$action = $_GET["action"]; $sid = $_SESSION ["sid"];
$page = $_GET["page"];
$who = $_GET["who"];
$uid = getuid_sid($sid);
$name = $_GET["name"];
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();
////////////////Ip Banned By CJ UDAY :)	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
    echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
	echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
      echo "<br/>";
      echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
      $banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
      $remain =  $banto[0] - time();
      $rmsg = gettimemsg($remain);
      echo "<b>Time Remaining: $rmsg</b><br/>";
      $nick = getnick_uid($banto[2]);
       $text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
      echo "</p>";
    	echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
    echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
    echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
//////////////////Banned System Updated By CJ UDAY :)
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please With Contact Us <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
 echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
///////////////////Validation By CJ UDAY :)
					if(isvalidated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
	echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  You Are Not Validated!<br/>We are checking your ip and browser<br/>
	  This could take up to 15 munites pls be patient and try again soon<br/>Please try again later...<br/><b>Thank You</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }

///////////////////Deactivated Account By CJ UDAY :)
          if(isdeactivated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  <b>Your Account Has Been Deactivated Forever.<br/>And It Will Be Never Activate!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
else if($action=="delgal")
{
    $gid = $_GET["gid"];
  addonline(getuid_sid($sid),"Deleting Gallery Photo","gallery.php");
	    echo "<head>";
    echo "<title>Delete Photo Gallery</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Delete Gallery Photo</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
$uid = getuid_sid($sid);
$itemowner = mysql_fetch_array(mysql_query("SELECT uid FROM ibwff_gallery WHERE uid='".$uid."'"));
if(galleryboss(getuid_sid($sid))||getuid_sid($sid)==$itemowner[0])
{
$res = mysql_query("DELETE FROM ibwff_gallery WHERE id='".$gid."'");
$res2 = mysql_query("DELETE FROM ibwff_galcomments WHERE gid='".$gid."'");
$res3 = mysql_query("DELETE FROM ibwff_prate WHERE gid='".$gid."'");
if($res||res2||res3)
{
echo "<img src=\"../avatars/ok.gif\" alt=\"o\"/>Photo Deleted From Gallery<br/>";
}else{
echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>Unknown Error!!!<br/>";
}
}else{
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>You can't delete this Photo";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="commentadd")
{
    $text = $_POST["comments"];
$gid = $_GET["gid"];
  addonline(getuid_sid($sid),"Adding Photo Comment","gallery.php?action=$action");
	    echo "<head>";
    echo "<title>Add Photo Comment</title>";
echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
			echo "<b>Comment</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
      echo "<p align=\"center\"><small>";
      $crdate = time();
      $uid = getuid_sid($sid);
      $res = false;
      if(trim($text)!="")
      {        
      $res = mysql_query("INSERT INTO ibwff_galcomments SET galcomments='".$text."', uid='".$uid."', btime='".$crdate."', gid='".$gid."'");
      }
      if($res)
      {
	    $cow = mysql_fetch_array(mysql_query("SELECT plusses FROM ibwff_users WHERE id='".$uid."'"));
       echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/>Photo Comment Added Successfully!<br/>";
      }else{
        echo "<img src=\"../images/notok.gif\" alt=\"X\"/>Can't Comments On this Photo!<br/>";
      }
echo "</div>";
echo "<p align=\"left\"><img src=\"../images/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
//////////////////////////Like Photo By CJ UDAY :)
else if($action=="galphotolike")
{
$gid = $_GET["gid"];
  $who = $_GET["who"];
  $whonick = subnick(getnick_uid($who));
  addonline(getuid_sid($sid),"Liking $whonick Gallery Photo","galproc.php?action=$action");
    	    echo "<head>";
    echo "<title>Like Gallery Photo</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
			echo "<b>Like $whonick Gallery Photo</b></div>";
  echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
  $vb = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM uday_galpiclike12 WHERE uid='".$uid."' AND gid='".$gid."'"));
  if($vb[0]==0)
  {
    $res = mysql_query("INSERT INTO uday_galpiclike12 SET uid='".$uid."', gid='".$gid."', time='".time()."'");
    if($res)
    {
        echo "<br/><img src=\"../avatars/ok.gif\" alt=\"o\"/>Gallery Photo Liked Successfully!<br/><br/>";
$liker = getnick_sid($sid);
mysql_query("INSERT INTO ibwff_notifications SET text='Your [gallery=$id]Gallery Photo"."[/gallery] Has Been Liked By [user=$uid]$liker"."[/user]', touid='".$who."', timesent='".time()."'");
    }else{
       echo "<br/><img src=\"../avatars/notok.gif\" alt=\"x\"/>Unknown Error!!!<br/><br/>";
    }
  }else{
    echo "<br/><img src=\"../avatars/notok.gif\" alt=\"x\"/>You Have Liked This Gallery Photo Before!<br/><br/>";
  }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
} 
//////////////////////////Dislike photo By CJ UDAY :)
else if($action=="galphotodislike")
{
$gid = $_GET["gid"];
  $who = $_GET["who"];
  $whonick = getnick_uid($who);
  addonline(getuid_sid($sid),"Disliking $whonick Gallery Photo","galproc.php?action=$action");
    	    echo "<head>";
    echo "<title>Dislike Gallery Photo</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">"; 
include("header.php");
            echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
			echo "<b>Dislike $whonick Gallery Photo</b></div>";
  echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
 $vb = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM uday_galpicdislike13 WHERE uid='".$uid."' AND gi='".$gid."'"));
  if($vb[0]==0)
  {
    $res = mysql_query("INSERT INTO uday_galpicdislike13 SET uid='".$uid."', gid='".$gid."', time='".time()."'");
    if($res)
    {
     echo "<br/><img src=\"../avatars/ok.gif\" alt=\"o\"/>Gallery Photo Disliked Successfully!<br/><br/>";
$disliker = getnick_sid($sid);
mysql_query("INSERT INTO ibwff_notifications SET text='Your [gallery=$gid]Gallery Photo"."[/gallery] Has Been Disliked By [user=$uid]$disliker"."[/user]', touid='".$who."', timesent='".time()."'");
    }else{
        echo "<br/><img src=\"../avatars/notok.gif\" alt=\"x\"/>Unknown Error!!!<br/><br/>";
    }
  }else{
    echo "<br/><img src=\"../avatars/notok.gif\" alt=\"x\"/>You Have Disliked this Gallery Photo Before!<br/><br/>";
  }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
} 
//////Delete Photo  By Shahos :-)
else if($action=="delphoto")
{
$id = $_GET["gid"];
echo "<head>";
echo "<title>Delete A Photo!</title>";
  echo "</head>"; 
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
			echo "<b>Delete Photo</b></div>";
  echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
if(ismod(getuid_sid($sid)))
{
$res = mysql_query("DELETE FROM ibwff_gallery WHERE id='".$id."'");
if($res)
{
echo "<br/><img src=\"../avatars/ok.gif\" alt=\"o\"/>Photo Deleted Sucessfully!<br/><br/>";
}else{
echo "<br/><img src=\"../avatars/notok.gif\" alt=\"x\"/>Unknown Error!!!<br/><br/>";
}
}else{
echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/>You dont have permission to use this tool!!!<br/><br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
//////Delete Photo Comment By CJ UDAY :-)
else if($action=="delgalcom")
{
    $gcid = $_GET["gcid"];
	echo "<head>";
    echo "<title>Delete Gallery Picture Comment</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
  echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
			echo "<b>Delete Gallery Photo Comment</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
    $res = mysql_query("DELETE FROM ibwff_galcomments WHERE id='".$gcid."'");
    if($res)
        {
            echo "<br/><img src=\"../avatars/ok.gif\" alt=\"o\"/>Gallery Photo Comment Deleted Sucessfully!<br/><br/>";
        }else{
          echo "<br/><img src=\"../avatars/notok.gif\" alt=\"x\"/>Unknown Error!!!<br/><br/>";
        }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="spp")
{
    $gid = $_GET["id"];
	echo "<head>";
    echo "<title>Delete Gallery Picture Comment</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
  echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
			echo "<b>Set Cover Photo</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
$uday = mysql_fetch_array(mysql_query("SELECT itemurl FROM ibwff_gallery WHERE id='".$gid."'"));    
$res = mysql_query("UPDATE ibwff_users SET avatar='".$uday[0]."' WHERE id='".$uid."'");
    if($res)
        {
            echo "<br/><img src=\"../avatars/ok.gif\" alt=\"o\"/>Set As Profile Photo Sucessfully!<br/><br/>";
        }else{
        echo "<br/><img src=\"../avatars/notok.gif\" alt=\"x\"/>Unknown Error!!!<br/><br/>";
        }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}  
else if($action=="scp")
{
    $gid = $_GET["id"];
	echo "<head>";
    echo "<title>Gallery Picture</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
  echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
			echo "<b>Set Cover Photo</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
$uday = mysql_fetch_array(mysql_query("SELECT itemurl FROM ibwff_gallery WHERE id='".$gid."'"));    
$res = mysql_query("UPDATE ibwff_users SET coverpic='".$uday[0]."' WHERE id='".$uid."'");
    if($res)
        {
            echo "<br/><img src=\"../avatars/ok.gif\" alt=\"o\"/>Set As Cover Photo Sucessfully!<br/><br/>";
        }else{
        echo "<br/><img src=\"../avatars/notok.gif\" alt=\"x\"/>Unknown Error!!!<br/><br/>";
        }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}  
?>
</html>