<?php
session_start();
//&#187; &#187;
//&#171; &#171;
header("Content-type: text/vnd.wap.wml");
header("Cache-Control: no-store, no-cache, must-revalidate");
echo "<?xml version=\"1.0\"?>";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.1//EN\"". " \"http://www.wapforum.org/DTD/wml_1.1.xml\">";

  echo '
<head>
<!--
/---------------------------
A Concern Of hira
----------------------------/
-->
';

echo "<meta http-equiv=\"Cache-Control\" content=\"must-revalidate\" />
<meta http-equiv=\"Cache-Control\" content=\"no-cache\"/>
<meta name=\"title\" content=\"FireBD.NeT\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From hira: Don't Try To Hack OR else :P\">
<meta name=\"keywords\" content=\"Site Desined By hira :) :)\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/></head>";
echo "<body>";

  ####################################################
#  <!-----!> (: Script Desiner Shahos :) <!-----!> #
####################################################

?>

<wml>
<?php
include("config.php");
include("core.php");  connectdb();
$bcon = connectdb();
if (!$bcon)
{
    echo "<card id=\"main\" title=\"Error!!!\">";
    echo "<p align=\"center\">";
    echo "<img src=\"../avatars/exit.gif\" alt=\"!\"/><br/>";
echo mobads();
    echo "<b>Error!!! Cannot Connect To Database...</b><br/><br/>";
    echo "This error happens usually when backing up the database, please be patient...";
    echo "</p>";
    echo "</card>";
    echo "</wml>";
    exit();
}
$action = $_GET["action"]; $sid = $_SESSION["sid"];
$clid = $_GET["clid"]; $action = $_GET["action"];
$page = $_GET["page"];
$who = $_GET["who"];
$sitename = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='sitename'"));
$sitename = $sitename[0];
$uid = getuid_sid($sid);
if((islogged($sid)==false)||($uid==0))
{
        echo "<card id=\"main\" title=\"Error!!!\">";
      echo "<p align=\"center\">";
      echo "You are not logged in<br/>";
      echo "Or Your session has been expired<br/><br/>";
echo mobads();
      echo "<a href=\"main.php\">Login</a>";
      echo "</p>";
      echo "</card>";
      echo "</wml>";
      exit();
}
if(isbanned($uid))
    {
      echo "<card id=\"main\" title=\"Error!!!\">";
      echo "<p align=\"center\">";
      echo "<img src=\"../avatars/notok.gif\" alt=\"x\"/><br/>";
      echo "<b>You are Banned</b><br/><br/>";
      $banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
	$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
      $remain = $banto[0]- time();
      $rmsg = gettimemsg($remain);
      echo "<b>Time Left: </b>$rmsg<br/>";
      $nick = getnick_uid($banto[2]);
	echo "<b>By: </b>$nick<br/>";
	echo "<b>Reason: </b>$banto[1]";
echo mobads();
      //echo "<a href=\"main.php\">Login</a>";
      echo "</p>";
      echo "</card>";
      echo "</wml>";
      exit();
    }
if($action=="guessgm")
{
    addonline(getuid_sid($sid),"Playing Gtn","");
    echo "<card id=\"main\" title=\"Guess The Number\">";
  echo "<p align=\"center\">";
  $gid = $_POST["gid"];
  $un = $_POST["un"];

  if($gid=="")
  {
        mysql_query("DELETE FROM ibwff_games WHERE uid='".$uid."'");
        mt_srand((double)microtime()*1000000);
        $rn = mt_rand(1,100);
        mysql_query("INSERT INTO ibwff_games SET uid='".$uid."', gvar1='8', gvar2='".$rn."'");
        $tries = 8;
        $gameid = mysql_fetch_array(mysql_query("SELECT id FROM ibwff_games WHERE uid='".$uid."'"));
        $gid=$gameid[0];
  }else{
    $ginfo = mysql_fetch_array(mysql_query("SELECT gvar1,gvar2 FROM ibwff_games WHERE id='".$gid."' AND uid='".$uid."'"));
    $tries = $ginfo[0]-1;
    mysql_query("UPDATE ibwff_games SET gvar1='".$tries."' WHERE id='".$gid."'");
    $rn = $ginfo[1];
  }
  if ($tries>0)
                {
                $gmsg = "<small>Just try to guess the number before you have no more tries, the number is between 1-100</small><br/><br/>";
                echo $gmsg;
                $tries = $tries-1;
                $gpl = $tries*3;
                echo "Tries:$tries, Plusses:$gpl<br/><br/>";
                      if ($un==$rn){
                        $gpl = $gpl+3;
                        $ugpl = mysql_fetch_array(mysql_query("SELECT gplus FROM ibwff_users WHERE id='".$uid."'"));
                        $ugpl = $gpl + $ugpl[0];
                        mysql_query("UPDATE ibwff_users SET gplus='".$ugpl."' WHERE id='".$uid."'");
                        echo "<small>Congrats! the number was $rn, $gpl Plusses has been added to your Game Plusses, <a href=\"games.php?action=guessgm&clid=$clid&who=$who\">New Game</a></small><br/><br/>";
                      }else{
                        if($un <$rn)
                        {
                          echo "Try bigger number than $un !<br/><br/>";
                        }else{
                            echo "Try smaller number than $un !<br/><br/>";
                        }
echo "Your Guess: <input type=\"text\" name=\"un\" format=\"*N\" size=\"3\" value=\"$un\"/><anchor>";
		echo " TRY";
		echo "<go href=\"games.php?action=guessgm&clid=$clid&who=$who\" method=\"post\">";
		echo "<postfield name=\"un\" value=\"$(un)\"/>";
		echo "<postfield name=\"gid\" value=\"$gid\"/>";
		echo "</go>";
		echo "</anchor><br/>";
                      }


                }else{
                    $gmsg = "<small>GAME OVER, <a href=\"games.php?action=guessgm&clid=$clid&who=$who\">New Game</a></small><br/><br/>";
                    echo $gmsg;
                }
  echo "<br/><br/><a href=\"main.php\"><img src=\"../avatars/home.gif\" alt=\"*\"/>";
echo "Home</a>";
echo mobads();
  echo "</p></card>";
}
/////////////////////////////////

else if($action == "scramble")
{
    addonline(getuid_sid($sid),"Playing Word Scramble","");
    echo "<card id=\"main\" title=\"Word Scramble\">";
$answer = $_POST["answer"];
if (empty($_POST["answer"]))  {

srand((float) microtime() * 10000000);
$input = array(
"dictionary",   
"recognize",
"example",
"entertainment",
"experiment",
"appreciation",
"information",
"pronunciation",
"language",
"government",
"psychic",
"blueberry",
"selection",
"automatic",
"strawberry",
"bakery",
"shopping",
"eggplant",
"chicken",
"organic ",
"angel",
"season",
"market",
"information",
"complete",
"sunset",
"unique",
"customer"
);
$rand_keys = array_rand($input, 2);
$word = $input[$rand_keys[0]];
$Sword = str_shuffle($word);
echo "<p align=\"center\">$Sword</p>
      <p align=\"center\">In the
      text box below type the correct word that is scrambled above.</p>
<p align=\"center\"><input type=\"text\" name=\"answ\" size=\"20\"/>
<anchor> GO!<go href=\"games.php?action=scramble&clid=$clid&who=$who\" method=\"post\">
<postfield name=\"answer\" value=\"$(answ)\"/>
<postfield name=\"correct\" value=\"$word\"/></go></anchor></p>
<p align=\"center\"><a href=\"main.php\"><img src=\"../avatars/home.gif\" alt=\"\"/>Home</a>

</p>
</card>";
}
else {
$answer = strtolower($answer);
if($answer == $correct){
$result = "Correct! <b>$answer</b>";
$uid = getuid_sid($sid);
$ugpl = mysql_fetch_array(mysql_query("SELECT gplus FROM ibwff_users WHERE id='".$uid."'"));
$ugpl = "25" + $ugpl[0];
mysql_query("UPDATE ibwff_users SET gplus='".$ugpl."' WHERE id='".$uid."'");

echo "<p align=\"center\">$result<br/>You Have Had 25 game Plusses Added For Winning.
</p>
      <p align=\"center\"><a href=\"games.php?action=scramble&clid=$clid&who=$who\">Try Another Word?</a><br/>
<a href=\"main.php\"><img src=\"../avatars/home.gif\" alt=\"\"/>Home</a>

</p>
</card>";}


else { $result = "Sorry! The Correct Answer Was <b>$correct</b>.";
$uid = getuid_sid($sid);
$ugpl = mysql_fetch_array(mysql_query("SELECT gplus FROM ibwff_users WHERE id='".$uid."'"));
$ugpl = $ugpl[0] - "25";
mysql_query("UPDATE ibwff_users SET gplus='".$ugpl."' WHERE id='".$uid."'");

echo "<p align=\"center\">$result<br/>You Have Had 25 game Plusses Deducted For Losing.
</p>
<p align=\"center\"><a href=\"games.php?action=scramble&clid=$clid&amp;who=$who\">Try Another Word?</a><br/>

<a href=\"main.php\"><img src=\"../avatars/home.gif\" alt=\"\"/>Home</a></p>
</card>";
}
}
}


/////////////////////////////////////////////////FCI
else if($action=="fci")
{
    addonline(getuid_sid($sid),"Playing Fortune Cookie","");
    echo "<card id=\"main\" title=\"Playing Fortune Cookie\">";
    echo "<p align=\"center\">"; echo mobads();
    $view = $_GET["view"];
    if($view=="")$view="date";

    echo "<small>Hmmm... So  you have come to let the cookie tell you your fortune?! Well good luck young (or old,lol) FireBD wapper!!!!</small>";
    echo "</p>";
    //////ALL LISTS SCRIPT <<

        echo "<p align=\"center\">";
    echo "<a href=\"games.php?action=fc&clid=$clid&who=$who\"><small>Read Fortune Cookie</small></a><br/>";
    echo "</p>";
      ////// UNTILL HERE >>
    echo "<p align=\"center\">";
echo mobads();
   echo "<br/><br/><a href=\"more.php?action=funm&clid=$clid&who=$who\">[&#171;]</a> Back<br/>";
    echo "<a href=\"main.php\"><img src=\"../avatars/home.gif\" alt=\"*\"/>";
echo "Home</a>";
  echo "</p>";
    echo "</card>";
}
/////////////////////////////////////////////////FCI2
else if($action=="fc")
{
    addonline(getuid_sid($sid),"Playing Fortune Cookie","");
    echo "<card id=\"main\" title=\"Playing Fortune Cookie\">";
    echo "<p align=\"center\">"; echo mobads();

    addonline(getuid_sid($sid),"Playing Fortune Cookie","");
    $view = $_GET["view"];
    if($view=="")$view="date";
    echo "<small><b>The fortune cookie tells you:</b></small>";
    echo "</p>";
 //////ALL LISTS SCRIPT <<
echo "<p align=\"center\">";
$xfile = @file("fortune.txt");
$random_num = rand (0,count($xfile)-1);
$udata = explode("::",$xfile[$random_num]);
echo $udata[1];
 echo "<br/><a href=\"games.php?action=fc&clid=$clid&who=$who\"><small>Another Cookie</small></a>";
   echo "</p>";


  ////// UNTILL HERE >>
    echo "<p align=\"center\">";
echo mobads();
   echo "<br/><br/><a href=\"more.php?action=funm&clid=$clid&who=$who\">[&#171;]</a> Back<br/>";
    echo "<a href=\"main.php\"><img src=\"../avatars/home.gif\" alt=\"*\"/>";
echo "Home</a>";
  echo "</p>";
    echo "</card>";
}

///////////////
else if($action=="startlove")
{
    addonline(getuid_sid($sid),"Love Calculator","");
    echo "<card id=\"main\" title=\"Love Calculator\">";
    echo "<p align=\"center\">"; echo mobads();
echo "<img src=\"../rex/love.gif\" alt=\"*\"/><br/>";
     $view = $_GET["view"];
     if($view == "")$view = "date";
     echo "Your Name:<br/>";
     echo "<input name=\"name\" maxlength=\"12\"/><br/>";
     echo "partner's Name:<br/>";
     echo "<input name=\"partner\" maxlength=\"12\"/><br/>";
     echo "<a href=\"games.php?action=results&clid=$clid&who=$who\"><small>Calculate</small></a><br/>";
     echo "</p>";
    echo "<p align=\"center\">";
echo mobads();
     echo "<br/><br/><a href=\"more.php?action=funm&clid=$clid&who=$who\">[&#171;]</a> Back<br/>";
     echo "<a href=\"main.php\"><img src=\"../avatars/home.gif\" alt=\"*\"/>";
    echo "Home</a>";  
  echo "</p>";
    echo "</card>";
}
else if($action=="results")
{
    addonline(getuid_sid($sid),"Love Calculator","");
    echo "<card id=\"main\" title=\"Love Calculator\">";
    echo "<p align=\"center\">";echo mobads();
     $view = $_GET["view"];
     if($view == "")$view = "date";
     $lovecalc = rand (40, 100);
     $jeez = "48";
     $wow = "67";
     echo "<small>You Love Your Partner <b>$lovecalc %</b></small><br/>";
    if($lovecalc < $jeez) echo "<small><b>Jeez Do Better Than That!</b></small>";
     elseif($lovecalc > $wow) echo "<small><b>WOW Thats Cool Keep It Up!</b></small>";
     else echo "<small><b>Obviously I Dont Know What To Say!</b></small>";
     echo "</p>";
     // //// UNTILL HERE >>
    echo "<p align=\"center\">";
echo mobads();
     echo "<br/><br/><a href=\"more.php?action=funm&clid=$clid&who=$who\">[&#171;]</a> Back<br/>";
     echo "<a href=\"main.php?action=main&clid=$clid&who=$who\"><img src=\"../avatars/home.gif\" alt=\"*\"/>";
    echo "Home</a>";
  echo "</p>";
    echo "</card>";
}
//////////////////////////////////LOTTO

else if($action=="lottoi")
{
    addonline(getuid_sid($sid),"Playing lotto","");
    echo "<card id=\"main\" title=\"Playing lotto\">";
    echo "<p align=\"center\">"; echo mobads();
    echo "<small><b>RW Lotto Draw</b><br/>Wanna become an Vip? Really? Really,really? Then this game should keep you busy and entertained for HOURS! Win the lotto and be known as a Vip here!</small><br/>";

    echo "</p>";
    //////ALL LISTS SCRIPT <<
 echo "<p align=\"center\">";

 echo "<br/><a href=\"games.php?action=lotto&clid=$clid&amp;who=$who\">";
 echo "<small>QuickPick</small></a><br/>";
 echo "Quickpick Price: 2 Credits<br/><br/>";
  echo "<a href=\"games.php?action=lottop&clid=$clid&amp;who=$who\">";
 echo "<small>Winner rewards</small></a><br/>";
   echo "</p>";


  ////// UNTILL HERE >>
    echo "<p align=\"center\">";
echo mobads();
    echo "<br/><br/><a href=\"more.php?action=funm&clid=$clid&amp;who=$who\">[&#171;]</a> Back<br/>";
    echo "<a href=\"main.php\"><img src=\"../avatars/home.gif\" alt=\"*\"/>";
    echo "Home</a>";
  echo "</p>";
    echo "</card>";
}

//////////////////////////////////LOTTO2

else if($action=="lotto")
{
    addonline(getuid_sid($sid),"Playing lotto","");
    echo "<card id=\"main\" title=\"Playing lotto\">";
    echo "<p align=\"center\">"; echo mobads();

    echo "<small><b>Lotto Draw</b><br/>Heres the lucky draw =D</small><br/>";

    echo "</p>";
    //////ALL LISTS SCRIPT <<
echo "<p align=\"center\">";
 if(getplusses(getuid_sid($sid))<10)
    {
        echo "<small>You should have at least 10 Credits to play this game!</small>";
    }else{
echo "<small><u>These are the winning lotto numbers</u></small><br/>";
 echo "<small><b>(2)(9)(18)(30)(38)(42)</b></small><br/>";
   echo "<small><u>These are your numbers</u></small><br/>";
$xfile = @file("lotto.txt");
$random_num = rand (0,count($xfile)-1);
$udata = explode("::",$xfile[$random_num]);
echo $udata[1];
}
  $ugpl = mysql_fetch_array(mysql_query("SELECT plusses FROM ibwff_users WHERE id='".$uid."'"));
  $ugpl = $ugpl[0] - 2;
  mysql_query("UPDATE ibwff_users SET plusses='".$ugpl."' WHERE id='".$uid."'");
echo "<br/><a href=\"games.php?action=lotto&clid=$clid&amp;who=$who\">";
echo "<small>Another Quickpick</small></a><br/>";
   echo "</p>";

  ////// UNTILL HERE >>
    echo "<p align=\"center\">";
echo mobads();
    echo "<br/><a href=\"more.php?action=funm&clid=$clid&amp;who=$who\">[&#171;]</a> Back<br/>";
    echo "<a href=\"main.php\"><img src=\"../avatars/home.gif\" alt=\"*\"/>";
    echo "Home</a>";
  echo "</p>";
    echo "</card>";
}

//////////////////////////////////LOTTO3

else if($action=="lottow")
{
    addonline(getuid_sid($sid),"Playing lotto","");
    echo "<card id=\"main\" title=\"Playing lotto\">";
    echo "<p align=\"center\">"; echo mobads();
    echo "<small><b>Lotto Draw</b><br/>This is the secret code that you must inbox in order to become an Vip!</small><br/>";

    echo "</p>";
    //////ALL LISTS SCRIPT <<
echo "<p align=\"center\">";
 if(getplusses(getuid_sid($sid))<10)
    {
        echo "<small>You should have at least 10 credits to play this game!</small>";
    }else{
  $xfile = @file("lottowin.txt");
  echo $udata[1];
   }

  ////// UNTILL HERE >>
    echo "<p align=\"center\">";
echo mobads();
    echo "<br/><br/><a href=\"more.php?action=funm&clid=$clid&amp;who=$who\">[&#171;]</a> Back<br/>";
    echo "<a href=\"main.php\"><img src=\"../avatars/home.gif\" alt=\"*\"/>";
    echo "Home</a>";
  echo "</p>";
    echo "</card>";
}

//////////////////////////////////LOTTO4
else if($action=="lottop")
{
    addonline(getuid_sid($sid),"Playing lotto","");
    echo "<card id=\"main\" title=\"Playing lotto\">";
    echo "<p align=\"center\">"; echo mobads();
      echo "<small><b>Lotto Draw</b><br/>Winner get:</small><br/>";

    echo "</p>";
    //////ALL LISTS SCRIPT <<


   echo "<b>*</b> <small>300 plusses</small><br/>";
   echo "<b>*</b> <small>their status changes to V.I.P User</small><br/>";
    echo "<b>*</b> <small>your name will be up in site stats as one of the lotto winners</small><br/>";
    echo "<b>*</b> <small>you will also be added to out V.I.P list</small><br/>";



  ////// UNTILL HERE >>
    echo "<p align=\"center\">";
echo mobads();
    echo "<a href=\"more.php?action=funm&clid=$clid&amp;who=$who\"><img src=\"../avatars/roll.gif\" alt=\"*\"/>";
echo "[&#171;]</a>Fun Menu<br/>";
    echo "<a href=\"main.php\"><img src=\"../avatars/home.gif\" alt=\"*\"/>";
echo "Home</a>";
  echo "</p>";
    echo "</card>";
}

//////////////////////////////////Mix A Buddy Guy

else if($action=="mixabudguy")
{
    addonline(getuid_sid($sid),"Mix A Buddy Guy","");
    echo "<card id=\"main\" title=\"Mix A Buddy Guy\">";
    echo "<p align=\"center\">"; echo mobads();
    $view = $_GET["view"];
    if($view=="")$view="date";
    echo "<small>Here You Go Mate, This Could Be Your New Buddy/Friend! Give Him A Try, Or If You Dont Think This Buddy Is Right For You, Then Feel Free To Try Again</small><br/>";
echo "<a href=\"games.php?action=mixabudguy&clid=$clid&who=$who\"><small>Try Again!</small></a>";
    echo "</p>";
    //////ALL LISTS SCRIPT <<

    //changable sql
    $sql = "SELECT id, name, regdate FROM ibwff_users WHERE sex='M' ORDER BY

RAND() LIMIT 1";

    echo "<p>";
    $items = mysql_query($sql);

    if(mysql_num_rows($items)>0)
    {
    while ($item = mysql_fetch_array($items))
    {
      $jdt = date("d-m-y", $item[2]);
      $lnk = "<a href=\"profile.php?who=$item[0]\">$item[1]</a>

joined: $jdt";
      echo "$lnk<br/>";
      echo "<small>If You Like The Above User/Buddy, Check His Profile And See If He Could Become Your New Buddy/Friend!</small><br/>";
    }
    }
    echo "</p>";
  ////// UNTILL HERE >>
    echo "<p align=\"center\">";
echo mobads();
   echo "<br/><br/><a href=\"more.php?action=funm&clid=$clid&who=$who\">[&#171;]</a> Back<br/>";
    echo "<a href=\"main.php\"><img src=\"../avatars/home.gif\" alt=\"*\"/>";
echo "Home</a>";
  echo "</p>";
    echo "</card>";
}

//////////////////////////////////Mix A Buddy Girl

else if($action=="mixabudgirl")
{
    addonline(getuid_sid($sid),"Mix A Buddy Girl","");
    echo "<card id=\"main\" title=\"Mix A Buddy Girl\">";
    echo "<p align=\"center\">"; echo mobads();
    $view = $_GET["view"];
    if($view=="")$view="date";
    echo "<small>Here You Go Mate, This Could Be Your New Buddy/Friend! Give Her A Try, Or If You Dont Think This Buddy Is Right For You, Then Feel Free To Try Again</small>-clap-<br/>";
echo "<a href=\"games.php?action=mixabudgirl&clid=$clid&who=$who\"><small>Try Again!</small></a>";
    echo "</p>";
    //////ALL LISTS SCRIPT <<

    //changable sql
    $sql = "SELECT id, name, regdate FROM ibwff_users WHERE sex='F' ORDER BY RAND() LIMIT 1";

    echo "<p>";
    $items = mysql_query($sql);

    if(mysql_num_rows($items)>0)
    {
    while ($item = mysql_fetch_array($items))
    {
      $jdt = date("d-m-y", $item[2]);
      $lnk = "<a href=\"profile.php?who=$item[0]\">$item[1]</a>

joined: $jdt";
      echo "$lnk<br/>";
      echo "<small>If You Like The Above User/Buddy, Check Her Profile And See If She Could Become Your New Buddy/Friend!</small><br/>";
    }
    }
    echo "</p>";
  ////// UNTILL HERE >>
    echo "<p align=\"center\">";
echo mobads();
   echo "<br/><br/><a href=\"more.php?action=funm&clid=$clid&who=$who\">[&#171;]</a> Back<br/>";
    echo "<a href=\"main.php\"><img src=\"../avatars/home.gif\" alt=\"*\"/>";
echo "Home</a>";

  echo "</p>";
    echo "</card>";
}
////////////////////////////////////////

else if($action == "hangman")
{
  addonline(getuid_sid($sid),"Playing Hangman","");
  echo "<card id=\"main\" title=\"Hangman\">";
  if ($cat==""){
  echo "<p align=\"center\">
  <img src=\"../avatars/hang_6.gif\" alt=\"Hangman\"/><br/>
  Select a category:<br/>";
  echo "<a href=\"$PHP_SELF?action=hangman&cat=anmls&clid=$clid&who=$who\">Animals</a><br/>";
  echo "<a href=\"$PHP_SELF?action=hangman&cat=clrs&clid=$clid&who=$who\">Colours</a><br/>";
  echo "<a href=\"$PHP_SELF?action=hangman&cat=comp&clid=$clid&who=$who\">Computers</a><br/>";
  echo "<a href=\"$PHP_SELF?action=hangman&cat=frt&clid=$clid&amp;who=$who\">Fruit</a><br/>";
  echo "<a href=\"$PHP_SELF?action=hangman&amp;cat=big&clid=$clid&amp;who=$who\">Big Words</a><br/>";
  echo "<a href=\"$PHP_SELF?action=hangman&amp;cat=lotr&clid=$clid&amp;who=$who\">Lord Of The Rings</a><br/>";
  echo "<a href=\"$PHP_SELF?action=hangman&amp;cat=mths&clid=$clid&amp;who=$who\">Months</a><br/>";
  echo "<a href=\"$PHP_SELF?action=hangman&amp;cat=web&clid=$clid&amp;who=$who\">Web / Wap coding</a><br/>";

  echo "<br/><a href=\"main.php\">Back</a><br/>";
echo mobads();

  echo "</p></card></wml>";
  exit();
  }
if ($cat==anmls){
$category="ANIMALS";
$list = "ANIMALS
BABOON
BEAR
BULL
CAMEL
CAT
COW
CROW
DOG
DONKEY
DUCKBILL PLATYPUS
EAGLE
ELEPHANT
FISH
FOX
GIRAFFE
GOAT
GOLDFISH
HAWK
HEDGEHOG
HORSE
KANGAROO
KITTEN
MOLE
MONKEY
MOUSE
MULE
OWL
PARROT
PIG
PINK ELEPHANT
POLAR BEAR
PORCUPINE
POSSUM
PUPPY
RABBIT
RACCOON
RAT
ROBIN
SEAL
SHARK
SKUNK
SQUIRREL
STOAT
WALRUS
WEASEL
WHALE
ZEBRA";}



if ($cat==clrs){
$category="COLOURS";
$list = "BLACK
BLUE
BROWN
BUBBLEGUM PINK
COLORS
CYAN
FUCHSIA
GOLD
GREEN
GREY
INDIGO
LAVENDER
LIME GREEN
MAROON
OLIVE
ORANGE
PERIWINKLE
PINK
PURPLE
RED
ROYAL BLUE
SCARLET
TEAL
TURQUOISE
VIOLET
WHITE
YELLOW"; }


if ($cat==comp){
$category="COMPUTERS";
$list = "ACCESS
ANTI-VIRUS SOFTWARE
BASIC
CD-ROM DRIVE
CHAT
COMPUTER
CPU
DATABASE
DOS
EMAIL
EXCEL
FIREWALL
FLOPPY DRIVE
FORUMS
FRONTPAGE
GAMES
HACKER
HARD DRIVE
HTML
ICQ
INTERNET
JUNK MAIL
KEYBOARD
LINUX
LOTUS
MICROSOFT
MONITOR
MOTHER BOARD
MOUSEPAD
OPERATING SYSTEM
PARALLEL PORT
PHP
PRINTER
PUBLISHING
RAM
SERIAL PORT
SOLITARE
SPEAKERS
TECHNOLOGY
UNIX
URL
VIRUS
VISUAL BASIC
WINDOWS
WORD
WORD PROCESSING
WORLD WIDE WEB
ZIP"; }


if ($cat==frt){
$category="FRUIT";
$list = "APPLE
BANANA
BLACKBERRY
BLUEBERRY
FRUIT
GRAPE
GRAPEFRUIT
KIWI
MANGO
ORANGE
PEACH
PEAR
RASBERRY
STRAWBERRY
TANGERINE
TOMATO
UGLY FRUIT"; }



if ($cat==big){
$category="BIG WORDS";
$list = "AUSTRALOPITHECINE
DEOXYRIBONUCLEIC ACID
LARGE WORDS
MITOCHONDRIA"; }

if ($cat==lotr){
$category="LORD OF THE RINGS";
$list = "AGORNATH
ARAGORN
ARWEN
BAG END
BALIN
BALROG
BARROW DOWNS
BARROW WRIGHT
BEREN
BILBO BAGGINS
BLACK RIDERS
BOROMIR
BREE
BUCKLAND
CELEBORN
DEAD MARSHES
DWARVES
EDORAS
ELENDIL
ELFSTONE
ELROND
ELVES
ENTS
EOWYN
FANGORN FOREST
FARAMIR
FRODO BAGGINS
GALADRIEL
GANDALF
GILGALAD
GLAMDRING
GLORFINDEL
GOLDBERRY
GOLLUM
GONDOR
HALDIR
HELMS DEEP
HOBBITON
HOBBITS
ISENGARD
ISILDUR
LEGOLAS
LEMBAS BREAD
LONELY MOUNTAIN
LONELY MOUNTIAN
LORD OF THE RINGS
LOTHLORIEN
LUTHIEN
MELKOR
MEN
MERRY
MIDDLE EARTH
MINAS MORGUL
MINAS TIRITH
MIRKWOOD
MITHRANDIR
MITHRIL
MORDOR
MORIA
MT. DOOM
MY PRECIOUSSS
NAZGUL
NUMENOR
OLD FOREST
OLD MAN WILLOW
ORCS
ORTHANC
PIPE WEED
PIPPIN
PLAINTIR
RANGERS
RINGWRAITHS
RIVENDELL
ROHAN
SAMWISE GAMGEE
SARUMAN
SAURON
SHADOWFAX
SHAGRAT
SHELOB
SHIRE
SILMARILLIAN
SMAUG
SMEAGOL
STEWARD OF GONDOR
STING
STRIDER
THE FELLOWSHIP OF THE RING
THE RETURN OF THE KING
THE RING
THE TWO TOWERS
THEODIN
TOM BOMBADIL
TREEBEARD
TROLLS
UNDYING LANDS
URUK-HAI
VALINOR
WARG RIDERS
WEATHERTOP
WIZARDS
WORMTONGUE";}


if ($cat==mths){
$category="MONTHS";
$list = "APRIL
AUGUST
DECEMBER
FEBRUARY
JANUARY
JULY
JUNE
MARCH
MAY
MONTHS
NOVEMBER
OCTOBER
SEPTEMBER"; }

if ($cat==web){
$category="WEB / WAP CODING";
$list = "JAVA BEANS
PHP SCRIPTS
SOURCE CODE
JAVASCRIPT GAMES
SSI IS SERVER SIDE INCLUDES
BILL GATES
COOKIES
HTTP AUTHENTICATION
ERROR HANDLING
MANIPULATING IMAGES
FILE UPLOADS
DATABASE / CONNECTION
APACHE SERVER
ZIP FILE
TAR COMPRESSION
FUNCTIONS
ENCRYPTION
MYSQL DATABASE
INITIALIZATION
FAQ - FREQUENTLY ASKED QUESTIONS
DEBUGGING
VERIFICATION
HTML VALIDATION
CASCADING STYLE SHEETS";}

# below ($alpha) is the alphabet letters to guess from.
#   you can add international (non-English) letters, in any order, such as in:
#   $alpha = "????????????????????????????ABCDEFGHIJKLMNOPQRSTUVWXYZ";
$alpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

# below ($additional_letters) are extra characters given in words; '?' does not work
#   these characters are automatically filled in if in the word/phrase to guess
$additional_letters = " -.,;!?%& 0123456789/";

#========= do not edit below here ======================================================

$clid = $_GET["clid"]; $action = $_GET["action"];
$uid = getuid_sid($sid);
$len_alpha = strlen($alpha);

if(isset($_GET["n"])) $n=$_GET["n"];
if(isset($_GET["letters"])) $letters=$_GET["letters"];
if(!isset($letters)) $letters="";

if(isset($PHP_SELF)) $self=$PHP_SELF;
else $self=$_SERVER["PHP_SELF"];

$links="";
$max=6;
# error_reporting(0);
$list = strtoupper($list);
$words = explode("\n",$list);
srand ((double)microtime()*1000000);
$all_letters=$letters.$additional_letters;
$wrong = 0;

echo "<p align=\"center\">";
if (!isset($n)) { $n = rand(1,count($words)) - 1; }
$word_line="";
$word = trim($words[$n]);
$done = 1;
for ($x=0; $x < strlen($word); $x++)
{
  if (strstr($all_letters, $word[$x]))
  {
    if ($word[$x]==" ") $word_line.=" / "; else $word_line.=$word[$x];
  }
  else { $word_line.="_ "; $done = 0; }
}

if (!$done)
{

  for ($c=0; $c<$len_alpha; $c++)
  {
    if (strstr($letters, $alpha[$c]))
    {
      if (strstr($words[$n], $alpha[$c])) {$links .= "<b>$alpha[$c]</b> "; }
      else { $links .= " $alpha[$c] "; $wrong++; }
    }
    else
    { $links .= " <a href=\"$self?action=hangman&cat=$cat&letters=$alpha[$c]$letters&n=$n&clid=$clid&who=$who\">$alpha[$c]</a> "; }
  }
  $nwrong=$wrong; if ($nwrong>6) $nwrong=6;
  echo "<br/><img src=\"../avatars/hang_$nwrong.gif\" alt=\"Wrong: $wrong out of $max\"/><br/>";

  if ($wrong >= $max)
  {
    $n++;
    if ($n>(count($words)-1)) $n=0;
    echo "<br/><br/>$word_line";
    echo "<br/><br/><big>SORRY, YOU ARE HANGED!!!</big><br/><br/>";
    if (strstr($word, " ")) $term="answer"; else $term="word";
    echo "The $term was \"<b>$word</b>\"<br/><br/>";
    $sqlfetch=mysql_query("SELECT gplus FROM ibwff_users WHERE id='".$uid."'");
    $sqlfet=mysql_fetch_array($sqlfetch);
    $gplusnew=$sqlfet[0] - "25";
    $sql="UPDATE ibwff_users SET gplus='".$gplusnew."' WHERE id='".$uid."'";
    $res=mysql_query($sql);
    echo "You Have Had 25 game Plusses Deducted For Losing.<br/>";
    echo "<a href=\"$self?action=hangman&amp;cat=$cat&n=$n&clid=$clid&who=$who\">Play again</a><br/>";
  echo "<a href=\"$self?action=hangman&clid=$clid&amp;who=$who\">Change category</a>";
  }else{
    echo " Wrong Guesses Left: <b>".($max-$wrong)."</b><br/><br/>";
    echo "$word_line";
    echo "<br/><br/>Choose a letter:<br/>";
    echo "$links";
  }
}else{
  $n++;    # get next word
  if ($n>(count($words)-1)) $n=0;
  echo "<br/><br/>\n$word_line";
  echo "<br/><br/><b>Congratulations!!! You win!!!</b><br/><br/><br/>";
      $sqlfetch=mysql_query("SELECT gplus FROM ibwff_users WHERE id='".$uid."'");
    $sqlfet=mysql_fetch_array($sqlfetch);
    $gplusnew=$sqlfet[0] + "25";
    $sql="UPDATE ibwff_users SET gplus='".$gplusnew."' WHERE id='".$uid."'";
    $res=mysql_query($sql);
    echo "You Have Had 25 game Plusses Added For Winning.<br/>";
  echo "<a href=\"$self?action=hangman&amp;cat=$cat&amp;n=$n&clid=$clid&amp;who=$who\">Play again</a><br/>";
  echo "<a href=\"$self?action=hangman&clid=$clid&amp;who=$who\">Change category</a>";
}
  echo "<br/><br/><a href=\"main.php\">Back</a>";
echo mobads();
  echo "</p></card>";
}

else
{
  addonline(getuid_sid($sid),"Lost in Games lol","");
  echo "<card id=\"main\" title=\"\">";
 echo "<p align=\"center\">";
  //echo "I don't know how did you get into here, but there's nothing to show<br/><br/>";
  //echo "<a href=\"main.php?action=main&amp;sid=$sid&amp&clid=$clid&amp;who=$who\"><img src=\"../avatars/home.gif\" alt=\"\"/>Home</a>";

  echo "</p></card>";
}
?>
</wml>