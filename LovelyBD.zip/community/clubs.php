<?php
session_start();
include("config.php");
include("core.php");  
connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo '<head>';
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"title\" content=\"FireBD.NeT\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From Megh: Don't Try To Hack OR else :P\">
<meta name=\"keywords\" content=\"Site Desined By Megh :) :)\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/></head>";
echo "<body>";
$action = $_GET["action"];
$sid = $_SESSION["sid"];
$page = $_GET["page"];
$who = $_GET["who"];
$whonick = getnick_uid($who);
$uid = getuid_sid($sid);
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();
////////////////Ip Banned By CJ UDAY :)	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
   	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
echo "<br/>";
echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
$banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
$remain =  $banto[0] - time();
$rmsg = gettimemsg($remain);
echo "<b>Time Remaining: $rmsg</b><br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "</p>";
echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
/////////////////Banned System Updated By CJ UDAY :)
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please Contact <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
 echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
 echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
///////////////////Deactivated Account By CJ UDAY :)
          if(isdeactivated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  <b>Your Account Has Been Deactivated Forever.<br/>And It Will Be Never Activate!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
///////////////////Validation By CJ UDAY :)
					if(isvalidated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  You Are Not Validated!<br/>We are checking your ip and browser<br/>
	  This could take up to 15 munites pls be patient and try again soon<br/>Please try again later...<br/><b>Thank You</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
//////////////////////////////////Clubs Menu Updated By CJ UDAY :)
if($action=="clmenu")
{
addonline(getuid_sid($sid),"Viewing Clubs Menu","clubs.php?action=$action");
  echo "<head>";
    echo "<title>View Clubs Menu</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"header\" align=\"left\">";
echo "<img src=\"FireBD.png\" alt=\"$sitename\" type=\"logo\" width=\"240\" height=\"50\"/><br/>";
			echo "<b>Clubs Menu</b></div>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
		
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<p align=\"left\">";
$uday = newclubpoint();
echo "Clubs are small communities that users can create.<br/>
Every community should have things in common<br/>
and anythin else you can think of<br/>";
echo "Currently people who have at least $uday points usually can create clubs<br/>
Also premium members and vip members can create clubs<br/>
A user can create up to maximum of 1 clubs<br/>
Using forums, chat or inviting friends etc...<br/>";
echo "will get you more points,<br/>
You can also get club points,<br/>
The more users that join and more activities in your club will put ur club on top<br/>";
echo "<b>Joined Clubs:</b><br/>";
	if($page=="" || $page<=0)$page=1;
    $noi = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_clubmembers WHERE uid='".$uid."' AND accepted='1'"));
    $num_items = $noi[0];
    $items_per_page= 10;
    $num_pages = ceil($num_items/$items_per_page);
    if(($page>$num_pages)&&$page!=1)$page= $num_pages;
    $limit_start = ($page-1)*$items_per_page;
    $sql = "SELECT  clid  FROM ibwff_clubmembers  WHERE uid='".$uid."' AND accepted='1' ORDER BY joined DESC  LIMIT $limit_start, $items_per_page";
    $items = mysql_query($sql);
    if(mysql_num_rows($items)>0)
    {
    while ($item = mysql_fetch_array($items))
    {
        $clnm = mysql_fetch_array(mysql_query("SELECT name FROM ibwff_clubs WHERE id='".$item[0]."'"));
      $lnk = "<img src=\"../avatars/clubs.gif\" alt=\"*\"/><a href=\"clubs.php?action=gocl&clid=$item[0]\">".htmlspecialchars($clnm[0])."</a><br/>";
      echo $lnk;
    }
    }
   if($page>1)
    {
      $ppage = $page-1;
      echo "<a href=\"clubs.php?action=$action&page=$ppage\">&#171;PREV</a> ";
echo "<br/>";
    }
    if($page<$num_pages)
    {
      $npage = $page+1;
      echo "<a href=\"clubs.php?action=$action&page=$npage\">Next&#187;</a>";
echo "<br/>";
    }
$x = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_clubs WHERE owner='".$uid."'"));
if($x[0]<1)
{
if(isvip($uid) || udaypu($uid) || getplusses($uid)>$uday)
{
echo "&#8594; <a href=\"clubs.php?action=addcl\"> Create a new Club</a><br/>";
}else{
echo "You must be a VIP or Premium User or have $uday points to create a new club!<br/>";
}
}else{
echo "You already have a club. So you can't create any more clubs.<br/>";
}
echo "<a href=\"clubproc.php?action=top\">&#187;View Top Clubs</a><br/>";
echo "<a href=\"clubproc.php?action=new\">&#187;View New Clubs</a><br/>";
echo "<a href=\"clubproc.php?action=clubs\">&#187;View All Clubs</a><br/>";
$ncl = mysql_fetch_array(mysql_query("SELECT id, name, owner FROM ibwff_clubs ORDER BY created DESC LIMIT 1"));
$owner =  subnick(getnick_uid($ncl[2]));
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE id='$ncl[2]'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/>";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/>";}
        		$avlink = getavatar($ncl[2]);
if($avlink=="")
{
 $avt =  "$usersex";
}else{
 $avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"icon\" width=\"18\" height=\"23\"/>";
}
echo "The Newest Club Is: <br/><img src=\"../avatars/clubs.gif\"><a href=\"clubs.php?action=gocl&clid=$ncl[0]\">".htmlspecialchars($ncl[1])."</a> <br/>Owner: <a href=\"profile.php?who=$ncl[2]\">$avt$owner</a>";
echo "</p>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
////////////////////////////////Clubs By CJ UDAY
else if($action=="gocl")
{
$clid = $_GET["clid"];
$shid = $_GET["shid"];
$fid = $_GET["fid"];
$rid = $_GET["rid"];
$bid = $_GET["bid"];
$tid = $_GET["tid"];
$clinfo = mysql_fetch_array(mysql_query("SELECT name, owner, description, rules, logo, plusses, created FROM ibwff_clubs WHERE id='".$clid."'"));
$clrn = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_clubs WHERE id='".$clid."' AND plusses>'{$clinfo[5]}'"));
$clme = mysql_fetch_array(mysql_query("SELECT points FROM ibwff_clubmembers WHERE uid='".getuid_sid($sid)."' AND clid='".$clid."'"));
addonline(getuid_sid($sid),"Viewing A Club","");
$clnm = htmlspecialchars($clinfo[0]);
   echo "<head>";
echo "<title>Viewing $clnm Club</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"header\" align=\"left\">";
echo "<img src=\"FireBD.png\" alt=\"$sitename\" type=\"logo\" width=\"240\" height=\"50\"/><br/>";
echo "<b>$clnm</b><br/>".getclubranking($clid)."<br/></div>";
echo "<div class=\"mblock1\" align=\"left\">";				
include("header.php");
echo "</div>";  

						echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php"); 
if(isbanclub(getuid_sid($sid),$clid)) {
echo "you are banned from this club<br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\" alt=\"m\"><a href=\"main.php\">Menu</a></p>";
						echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
exit();
}
if(!canenterclub(getuid_sid($sid),$clid))
   {
echo "you are not permited to access into this club.<br/>
Please Join This Club before using club features.<br/>";
$clubname = getclubname($clid);
echo "<a href=\"clubproc.php?action=join&clid=$clid&sid=$sid\">Join $clubname!</a>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\" alt=\"m\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
exit();
}
if(clubboss(getuid_sid($sid)))
{
echo "<p align\"left\"><a href=\"udaycp.php?action=club&clid=$clid\">Site Staff tools</a><br/>
[<a href=\"events.php?clid=$clid\">Club history</a>]
</p>";
}
	$lastannc = mysql_fetch_array(mysql_query("SELECT id, antext, antime FROM ibwff_announcements WHERE clid='".$clid."' ORDER BY antime DESC LIMIT 0, 1"));
	$annc = htmlspecialchars($lastannc[1]);
if(trim($annc)!="")
{
echo "<small><div class=\"div\" align=\"center\"><b>Announcement</b></div>";
	$f =getbbcode($annc);
echo $f;
}else{
echo "";
} 
$cango = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_clubmembers WHERE clid='".$clid."' AND uid='".$uid."' AND accepted='1'"));
	echo "<div class=\"div\" align=\"center\"><b><b>===$clnm===</b></b></div>";
	if(trim($clinfo[4])=="")
    {
      echo "<img src=\"../clublogo/club.png\" alt=\"logo\"/>";
    }else{
       echo "<img src=\"$clinfo[4]\" alt=\"logo\"/>";
    }
	echo "<br/><p align=\"left\">";
$cango = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_clubmembers WHERE clid='".$clid."' AND uid='".$uid."' AND accepted='1'"));
$clme=mysql_fetch_array(mysql_query("SELECT * FROM ibwff_clubmembers WHERE uid='".$uid."'"));
echo "<b><div align=\"left\">Club ID: </b>$clid";
echo "<b><br/>Created On</b>: ".date("h:i a, l d M y", $clinfo[6])."<br/>";
$item = subnick(getnick_uid($clinfo[1]));
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE id='$clinfo[1]'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/>";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/>";}
if($sex[0]==""){$usersex = "";}
        		$avlink = getavatar($clinfo[1]);
if($avlink=="")
{
 $avt =  "$usersex";
}else{
 $avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"icon\" width=\"23\" height=\"18\"/>";
}
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$clinfo[1]'"));
if($sex[0]=="M"){$nicks = "<font color=\"blue\"><b>$item</b></font>";}
if($sex[0]=="F"){$nicks = "<font color=\"deeppink\"><b>$item</b></font>";}
if($sex[0]==""){$nicks = "<font color=\"blue\"><b>$item</b></font>";}
echo "<b>Points</b>: $clinfo[5]<br/>";
$clrn = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_clubs WHERE id='".$clid."' AND plusses>'{$clrn[0]}'"));
$chss = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_clubs"));
$uall = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_clubs"));
$nopl = mysql_fetch_array(mysql_query("SELECT plusses FROM ibwff_clubs WHERE id='".$clid."'"));
$nopm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_clubs WHERE plusses>'{$nopl[0]}'"));
$nopmx=$nopm[0];
if($nopmx==0) {$nopmx="1";}
echo "<b>Rank: </b>$nopmx out of $uall[0] Clubs<br/>";
echo "<b>Owner</b>: $avt<a href=\"profile.php?who=$clinfo[1]\">$nicks</a><br/>";
$ot=time()-3600;
$time=time();
$ot=(int) $ot;
$mems = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_clubmembers WHERE clid='".$clid."' AND accepted='1'"));
$mods = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_clubmembers WHERE clid='".$clid."' AND accepted='1' AND power=1"));
$subs = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_clubmembers WHERE clid='".$clid."' AND accepted='1' AND subscriber=1"));
$vip = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_clubmembers WHERE clid='".$clid."' AND accepted='1' AND vip>0"));
$modson = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_clubmembers WHERE clid='".$clid."' AND accepted='1' AND power=1 AND onl>$ot"));
$subson = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_clubmembers WHERE clid='".$clid."' AND accepted='1' AND subscriber=1 AND onl>$ot"));
$vipson = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_clubmembers WHERE clid='".$clid."' AND accepted='1' AND vip>0 AND onl>$ot"));
$banson = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_clubmembers WHERE clid='".$clid."' AND banned>0 AND onl>$ot"));
mysql_query("UPDATE ibwff_clubmembers SET onl=$time WHERE uid='".getuid_sid($sid)."' ");
$onln = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_clubmembers WHERE clid='".$clid."' AND accepted='1' AND onl>$ot"));
echo "<b>Members</b>: <a href=\"clublist.php?action=members&clid=$clid\">$mems[0]</a>,";
echo "<b>Online</b>: <a href=\"clublist.php?action=memonl&clid=$clid\">$onln[0]</a><br/>";
echo "<b>Moderators</b>: <a href=\"clublist.php?action=mod&amp;clid=$clid\">$mods[0]</a>,";
echo "<b>Online</b>: <a href=\"clublist.php?action=modon&clid=$clid\">$modson[0]</a><br/>";
echo "<b>Vips</b>: <a href=\"clublist.php?action=vip&clid=$clid\">$vip[0]</a>,";
echo "<b>Online</b>: <a href=\"clublist.php?action=vipon&clid=$clid\">$vipson[0]</a><br/>";
echo "<b>Subscribers</b>: <a href=\"clublist.php?action=subs&clid=$clid\">$subs[0]</a>,";
echo "<b>Online</b>: <a href=\"clublist.php?action=subson&clid=$clid\">$subson[0]</a><br/>";
$bans = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_clubmembers WHERE clid='".$clid."' AND accepted='1' AND banned=1"));
echo "<b>Banned</b>: <a href=\"clublist.php?action=ban&clid=$clid\">$bans[0]</a>,";
echo "<b>Online</b>: <a href=\"clublist.php?action=banon&clid=$clid\">$banson[0]</a></b></div><br/>";
if(canenterclub($uid, $clid))
{
$pl=mysql_fetch_array(mysql_query("SELECT plusses from ibwff_users WHERE id='".$uid."'"));
  if($pl[0]<50)
    {
echo "<div class=\"mblock1\" aling=\"center\">";
	    $remp = 50 - $pl[0];
        echo "<br/>You need $remp more club points to shout! 
		[<a href=\"forums.php?tid=2\"><font color=\"red\">How To Get Points??</font></a>]</div>";
    }else{
 	  echo "<div class=\"div\" align=\"center\"><b>Shoutbox</b></div>";
				echo "<div class=\"shout\" align=\"left\">";
echo getshoutboxclub($clid, $sid);
echo "</div>";
echo "<div class=\"shout\" align=\"left\">";
echo getshoutbox3club($clid, $sid);
echo "</div>";
echo "<a href=\"shouts.php?action=shouts&clid=$clid\">[More]</a><br/>";
echo "<form action=\"shoutproc.php?action=shout&clid=$clid\" method=\"post\">";
  echo "ShoutBox Message:<br/><input name=\"shtxt\" maxlength=\"250\"/><br/>";
  echo "<br/><img src=\"../images/activity.jpg\" alt=\"activity\"><a href=\"activity.php\"><font color=\"grey\"><b>Activity</b></font></a> <input type=\"Submit\" name=\"shout\" Value=\"Add Shout\"> <img src=\"../images/attach.png\" alt=\"attach\"><a href=\"attach.php\"><font color=\"grey\"><b>Attach</b></font></a></form></center>";
  }
echo "</div><div class=\"penanda\">";
if($clinfo[1]==$uid || isclubmod($uid,$clid)=="1")
{
echo "<div class=\"div\" align=\"center\"><b>Club tools</b></div><div class=\"shout\" align=\"center\">";
$hcl = $_GET["clid"];
$uday = getunvalcl_uday($hcl);
echo "&#8226; <a href=\"clubs.php?action=clubcp&clid=$clid\">Clubs cP</a><br/>";
$mems = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_clubmembers WHERE clid='".$clid."' AND accepted='0'"));
echo "&#8226; <a href=\"clublist.php?action=clreq&clid=$clid\">Club Request</a> ($mems[0])<br/>&#8226; <a href=\"validatecp.php?action=club&clid=$clid\">Validate List</a> ($uday)<br/></div>";
}
$fid = mysql_fetch_array(mysql_query("SELECT id FROM ibwff_forums WHERE clubid='".$clid."'"));
$rid = mysql_fetch_array(mysql_query("SELECT id FROM ibwff_rooms WHERE clubid='".$clid."'"));
$lits = mysql_fetch_array(mysql_query("SELECT id FROM ibwff_literatures WHERE clubid='".$clid."'"));
$tps = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_topics WHERE fid='".$fid[0]."'"));
$pss = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_posts a INNER JOIN ibwff_topics b ON a.tid = b.id WHERE b.fid='".$fid[0]."'"));
$blg = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_blogs WHERE clubid='".$clid."'"));
$ltr = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_storys WHERE fid='".$lits[0]."'"));
$polz = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_polls WHERE clubid='".$clid."'"));
$gallery = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_gallery WHERE clubid='".$clid."'"));
$noa = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_chat WHERE rid='".$rid[0]."'"));
echo "<div align=\"left\"><div class=\"div\"><b>{$clinfo[0]} Menu</b></div>";
echo "<a href=\"chat.php?rid=$rid[0]\"><img src=\"../avatars/folder.jpg\" alt=\"*\"/>{$clinfo[0]}  Chat($noa[0])</a><br/>";
echo "<a href=\"forums.php?action=viewtopicbox&amp;clid=$clid&fid=$fid[0]\"><img src=\"../avatars/forums.gif\" alt=\"*\"/>{$clinfo[0]} Forum($tps[0]/$pss[0])</a><br/>";
echo "<a href=\"literature.php?action=viewlitbox&fid=$lits[0]&clid=$clid\"><img src=\"../avatars/literature.gif\" alt=\"*\"/>{$clinfo[0]} Articles($ltr[0])</a><br/>";
echo "<a href=\"blogs.php?action=allbl&clid=$clid&clid=$clid\"><img src=\"../avatars/blogs.gif\" alt=\"*\"/>{$clinfo[0]} Blog($blg[0])</a><br/>";
echo "<a href=\"polls.php?action=polls&clid=$clid\"><img src=\"../avatars/polls.gif\" alt=\"*\"/>{$clinfo[0]} Polls($polz[0])</a><br/>";
echo "<a href=\"gallery.php?clid=$clid\"><img src=\"../images/gallery.gif\" alt=\"*\"/>{$clinfo[0]} Gallery($gallery[0])</a>";
        echo "<div class=\"div\" align=\"left\"><b>Last Forum Topic</b></div>";
		echo "<p align=\"left\">";
include("lasttpcclub.php");
        echo "<div class=\"div\" align=\"left\"><b>Last Forum Post</b></div>";
		echo "<p align=\"left\">";
include("lastpostclub.php");
        echo "<div class=\"div\" align=\"left\"><b>Last Literature</b></div>";
		echo "<p align=\"left\">";
include("lastlitclub.php");
        echo "<div class=\"div\" align=\"left\"><b>Last Blog</b></div>";
		echo "<p align=\"left\">";
include("lastblogclub.php");
        echo "<div class=\"div\" align=\"left\"><b>Last Poll</b></div>";
		echo "<p align=\"left\">";
include("lastpollclub.php");
echo "</p>";
$ismem = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_clubmembers WHERE clid='".$clid."' AND uid='".getuid_sid($sid)."'"));
$issubs = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_clubmembers WHERE clid='".$clid."' AND uid='".getuid_sid($sid)."' AND subscriber=1"));
if($ismem[0]>0)
{
if($clinfo[1]!=$uid)
{
echo "<a href=\"clubproc.php?action=unjoin&clid=$clid\"><img src=\"../avatars/ignore.gif\" alt=\"*\"/>Unjoin Club</a><br/>";
}
if($issubs[0]>0)
{
echo "<a href=\"clubproc.php?action=unsub&clid=$clid\"><img src=\"../images/unsub.png\" alt=\"*\"/>Usubscribe Club</a><br/>";
echo "</div>";
}else{
echo "<a href=\"clubproc.php?action=sub&clid=$clid\"><img src=\"../images/sub.png\" alt=\"*\"/>Subscribe Club</a><br/>";
echo "</div>";
}
}else{
echo "<br/><a href=\"clubproc.php?action=join&&clid=$clid\"><img src=\"../avatars/join.gif\" alt=\"*\"/>Join Now!</a>";
}
}else{
echo "<p align=\"left\">";
echo "Seems Good? <a href=\"clubproc.php?action=join&clid=$clid\"><img src=\"../avatars/join.gif\" alt=\"*\"/>Join Now!</a></p>";
echo "</div>";
}
 echo "</div></div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="clubcp")
{
addonline(getuid_sid($sid),"clubs Cp","main.php?action=main");
echo "<head>";
echo "<title>Club cP</title>";
 echo "</head>"; 
	echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
$clid = $_REQUEST["clid"];
$cname = getclubname($clid);
echo "<div class=\"header\" align=\"center\"><b>$cname Club cP</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<p align=\"left\">";
$cow = mysql_fetch_array(mysql_query("SELECT owner FROM ibwff_clubs WHERE id='".$clid."'"));
if($cow[0]!=$uid && isclubmod($uid,$clid)!="1" && !clubboss($uid))
{
echo "<img src=\"../images/notok.gif\"> This club is not yours!";
}else{
echo "<div class=\"mblock1\">&#8226; <a href=\"clubs.php?action=$action&clid=$clid&do=logo\">Change Logo</a></div>";
$sys = $_REQUEST["do"];
if ($sys=="logo")
{
$cname = getclubname($clid);
echo "<br/>Change $cname Logo <br/>";
	echo "<form enctype=\"multipart/form-data\" action=\"clubs.php?action=$action&clid=$clid&amp;subdo=logo\" method=\"post\">
	<input type=\"file\" name=\"file\" size=\"1\"/><br/>
	<input type=\"submit\" value=\"Upload\"/>
	</form>
	";
}
echo "<hr>";
$sys = $_REQUEST["subdo"];
if ($sys=="logo")
{
	$file = $_FILES['file'];
$file = str_replace(' ','_',$file);
$nf = "club{$clid}".$file['name'];
$dotpos = strrpos($nf,'.');
$ft = substr($nf,$dotpos); 
if ($ft ==".php") { $ft =".txt";}
if ($ft ==".asp") { $ft =".txt";}
if ($ft ==".js") { $ft =".txt";}
if ($ft ==".so") { $ft =".txt";}
if ($ft ==".pl") { $ft =".txt";}
if ($ft ==".cgi") { $ft =".txt";}
if ($ft ==".shtml") { $ft =".txt";}
if ($ft ==".html") { $ft =".txt";}
if ($ft ==".phtml") { $ft =".txt";}
if ($ft ==".htm") { $ft =".txt";}
if ($ft ==".xml") { $ft =".txt";}
if ($ft ==".wml") { $ft =".txt";}
if ($ft ==".exe") { $ft =".txt";}
if ($ft ==".ini") { $ft =".txt";}
if ($ft ==".htaccess") { $ft =".txt";}
$hf .= $ft;
if (!eregi("\.(jpeg|jpg|gif|bmp)$",$nf)){
echo "<br/><br/><b>Unsupported File extention!!!</b><br/>";} else {
$file = $file['tmp_name'];
if(copy($file,"../clublogo/$nf"))
{	
	$res=mysql_query("UPDATE ibwff_clubs SET logo='../clublogo/".$nf."' WHERE id='".$clid."'");
	}
	}
	if(!$res) {
	echo "<br/><img src=\"../avatars/notok.gif\" alt=\"x\"/>Error updating club logo.";}
	else {
	echo "<br/><img src=\"../avatars/ok.gif\" alt=\"o\"/>Club logo added successfully!";
	}
echo "<hr>";
}
echo "<div class=\"mblock1\">&#8226; <a href=\"clubs.php?action=$action&clid=$clid&amp;do=annc\">Club Announcement</a></div>";
$sys = $_REQUEST["do"];
if ($sys=="annc")
{
echo "<br/>Add Announcement<br/>";
$rules = mysql_fetch_array(mysql_query("SELECT annc FROM ibwff_clubs WHERE id='".$clid."'"));
echo "<form action=\"clubs.php?action=$action&amp;clid=$clid&amp;subdo=annc\" method=\"post\">";
 echo "Text:<input name=\"antx\" maxlength=\"200\" value=\"$rules[0]\"/><br/>";
    echo "<input type=\"submit\" value=\"Update\"/>";
  echo "</form>";
}
echo "<hr>";
$sys = $_REQUEST["subdo"];
if ($sys=="annc")
{
$rules = $_POST["antx"];
$res = mysql_query("UPDATE ibwff_clubs SET annc='".$rules."' WHERE id='".$clid."'");
if ($res)
{
echo "<br/>Club Announcement Successfully Updated!";
}else{
echo "<br/>Error Updating Club Announcement!";
}
echo "<hr>";
}
echo "<div class=\"mblock1\">&#8226; <a href=\"clubs.php?action=$action&clid=$clid&do=rules\">Club Rules</a></div>";
$sys = $_REQUEST["do"];
if ($sys=="rules")
{
echo "<br/>Add Rules<br/>";
$rules = mysql_fetch_array(mysql_query("SELECT rules FROM ibwff_clubs WHERE id='".$clid."'"));
echo "<form action=\"clubs.php?action=$action&clid=$clid&subdo=rules\" method=\"post\">";
 echo "Text:<input name=\"antx\" maxlength=\"200\" value=\"$rules[0]\"/><br/>";
  echo "<input type=\"submit\" value=\"Update\"/>";
  echo "</form>";
}
echo "<hr>";
$sys = $_REQUEST["subdo"];
if ($sys=="rules")
{
$rules = $_POST["antx"];
$res = mysql_query("UPDATE ibwff_clubs SET rules='".$rules."' WHERE id='".$clid."'");
if ($res)
{
echo "<br/>Club rules Successfully!";
}else{
echo "<br/>Error Updating Club Rules";
}
echo "<hr>";
}
echo "<div class=\"mblock1\">&#8226; <a href=\"clubs.php?action=$action&clid=$clid&amp;do=pm2all\">Pm 2 All Club Members</a></div>";
$sys = $_REQUEST["do"];
if ($sys=="pm2all")
{
echo "<br/>Add Message<br/>";
echo "<form action=\"clubs.php?action=$action&clid=$clid&amp;subdo=pm2all\" method=\"post\">";
 echo "Message:<input name=\"antx\" maxlength=\"200\"/><br/>";
  echo "<input type=\"submit\" value=\"Send\"/>";
  echo "</form>";
}
echo "<hr>";
$sys = $_REQUEST["subdo"];
if ($sys=="pm2all")
{
$rules = $_POST["antx"];
$cname = getclubname($clid);
if (!empty($rules))
{
$res = clubpmall($clid,$rules);
$user = getnick_uid(getuid_sid($sid));
$history = "<b>$user</b> pm to all club members!";
clubhis_uday($clid,$history);
echo "<br/>You Have Send A Pm2All club Members Successfully!";
}else{
echo "<br/>Error Making Pm2all clubmembers
!";
}
echo "<hr>";
}
echo "<div class=\"mblock1\">&#8226; <a href=\"clubs.php?action=$action&clid=$clid&amp;do=cleardata\">Clear Data</a></div>";
echo "<hr>"; 
$sys = $_REQUEST["do"];
if ($sys=="cleardata")
{
echo "<br/>";
echo "<p align=\"left\">";
echo "<b>&#187;</b> <a href=\"clubs.php?action=$action&amp;clid=$clid&amp;subdo=delevent\">Delete Club Events</a><br/><hr>";
echo "<b>&#187;</b> <a href=\"clubs.php?action=$action&amp;clid=$clid&amp;subdo=delshout\">Delete Club Old Shouts (5 Days Ago)</a><br/><hr>";
echo "</p>";
}
$sys = $_REQUEST["subdo"];
if ($sys=="delshout")
{
$altm = time()-(5*24*60*60);
$res = mysql_query("DELETE FROM ibwff_shouts WHERE shtime<'".$altm."' AND clubid='".$clid."'");
if ($res)
{
echo "<br/>Club Shouts Deleted Successfully!";
}else{
echo "<br/>Error Deleteing Club Shouts!";
}
echo "<hr>";
}
$sys = $_REQUEST["subdo"];
if ($sys=="delevent")
{
$altm = time()-(5*24*60*60);
$res = mysql_query("DELETE FROM ibwff_events WHERE time<'".$altm."' AND clubid='".$clid."'");
if ($res)
{
echo "<br/>Club Events Deleted Successfully!";
}else{
echo "<br/>Error Deleteing Club events!";
}
echo "<hr>";
}
}
$clname = getclubname($clid);
echo "<b>&#171;</b> <a href=\"clubs.php?action=gocl&clid=$clid\">Back to $clname club</a></p>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
////////////////////////////ADD CLUB By CJ UDAY :)
else if($action=="addcl")
{
    echo "<head>";
    echo "<title>Add A Club</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
						echo "<div class=\"header\" align=\"center\">";
			echo "<b>Add Club</b></div>";
						echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<p align=\"left\">";
$newclubpoint = newclubpoint();
if(getplusses($uid)>=$newclubpoint || ispu($uid) || spu($uid) || isvip($uid))
{
$noi = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_clubs WHERE owner='".$uid."'"));
if($noi[0]<1)
{
echo "<img src=\"../avatars/point.gif\" alt=\"*\"/> All info are required except the logo!<br/>";
echo "<img src=\"../avatars/point.gif\" alt=\"*\"/> Beside you, moderator can moderate your club's forum, literature, blog, poll and chat!<br/>";
echo "<img src=\"../avatars/point.gif\" alt=\"*\"/> Any leading spaces for description, name, logo, or rules will be removed!<br/>";
echo "<img src=\"../avatars/point.gif\" alt=\"*\"/> Admins will delete your club and subtract your points if you abuse the rules of owning a club!<br/>";
echo "<img src=\"../avatars/point.gif\" alt=\"*\"/> Admins have the right to delete your club if it isn't active or useless!<br/><br/>";
 echo "<form action=\"clubproc.php?action=addcl\" method=\"post\">"; 
 echo"<p align=\"left\">";
echo "<b><big>Club Name:<br/><input name=\"clnm\" maxlength=\"30\"/><br/>";
echo "Description:<br/><input name=\"clds\" maxlength=\"200\"/><br/>";
echo "Rules:</b></big><br/><input name=\"clrl\" maxlength=\"10000\"/><br/>";
  echo "<input type=\"submit\" value=\"Create\"/>";
    echo "</form>";
}else{
echo "<img src=\"../avatars/notok.gif\"> You Already Have a Club!";
}
}else{
echo "<img src=\"../avatars/notok.gif\">You Need $newclubpoint Points To Add A Club!<br/> 
<a href=\"forums.php?tid=2\">How To Get Points??</a>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="clmop")
{
$clid = $_GET["clid"];
$who = $_GET["who"];
$whn = subnick(getnick_uid($who));
$own = mysql_fetch_array(mysql_query("SELECT owner FROM ibwff_clubs WHERE id=$clid"));
    echo "<head>";
    echo "<title>Moderating Club Member</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
						echo "<div class=\"header\" align=\"center\">";
			echo "<b>Moderating $whn</b></div>";
						echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<p align=\"left\">";
if((isclubmod($uid,$clid)==1) || ($own[0]=$uid))
{
echo "<b>Point:</b><br/>";
echo "&#8226; <a href=\"clubcp.php?action=pointa&who=$who&clid=$clid\">Give Point</a><br/>";
echo "&#8226; <a href=\"clubcp.php?action=pointc&who=$who&clid=$clid\">Cut Point</a><br/>";
if(isclubmod($who,$clid)!=1)
{
if($own[0]!=$who)
{
echo "<b>Penalty:</b><br/>";
if(isbanclub($who,$clid)!=1)
{
echo "&#8226; <a href=\"clubcp.php?action=ban&who=$who&clid=$clid\">Ban From Club</a><br/>";
}else{
echo "&#8226; <a href=\"clubcp.php?action=unban&who=$who&clid=$clid\">Unban From Club</a><br/>";
}
}else{
echo "";
}
}else{
echo "";
}
if($own[0]=$uid)
{
echo "<b>Power:</b><br/>";
if(isclubmod($who,$clid)!=1)
{
echo "&#8226; <a href=\"clubcp.php?action=mod&who=$who&clid=$clid\">Make Moderator</a><br/>";
}else{
echo "&#8226; <a href=\"clubcp.php?action=demod&who=$who&clid=$clid\">Demote From Moderator</a><br/>";
}
}else{
echo "";
}
if($own[0]=$uid)
{
echo "<b>VIP:</b><br/>";
if(isclubvip($who,$clid)!=1)
{
echo "&#8226; <a href=\"clubcp.php?action=vip&who=$who&clid=$clid\">Make Vip Member</a><br/>";
}else{
echo "&#8226; <a href=\"clubcp.php?action=unvip&who=$who&clid=$clid\">Make Normal Member</a><br/>";
}
}else{
echo "";
}
if($own[0]!=$who)
{
echo "<b>Remove:</b><br/>";
echo "&#8226; <a href=\"clubcp.php?action=delete&who=$who&clid=$clid\">Remove Member From Club</a><br/>";
}else{
echo "";
}
}else{
echo "<img src=\"../images/notok.gif\"> You Can't Use This Tools!";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
?>
</html>