<?php
session_start();
include("config.php");
include("core.php");  
connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?sid=$sid&xml version=\"1.0\" encoding=\"ISO-8859-1\" ?sid=$sid&>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo '<head>'; 
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"title\" content=\"MyDhaka.Tk\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From Mehedi: Don't Try To Hack OR else :P\">
<meta name=\"keywords\" content=\"Site Desined By Mehedi:) :)\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/></head>";
echo "<body>";
$action = $_GET["action"]; 
$sid = $_SESSION["sid"];
$page = $_GET["page"];
$who = $_GET["who"];
$uid = getuid_sid($sid);
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();
////////////////Ip Banned By CJ UDAY :)	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
    echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
      echo "<br/>";
      echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
      $banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
      $remain =  $banto[0] - time();
      $rmsg = gettimemsg($remain);
      echo "<b>Time Remaining: $rmsg</b><br/>";
      $nick = getnick_uid($banto[2]);
       $text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
      echo "</p>";
    	echo "<form action=\"login.php\" method=\"get\"><p align=\"center\">";
    echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
    echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"center\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
$uid = getuid_sid($sid);
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time center: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please With Contact Us <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"center\"><a href=\"".$_SERVER['HTTP_REFFERER']."\">Back</a><br/><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"center\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "Not Registered Yet?sid=$sid&<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "<p align=\"center\"><a href=\"".$_SERVER['HTTP_REFFERER']."\">Back</a><br/><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"center\"><a href=\"".$_SERVER['HTTP_REFFERER']."\">Back</a><br/><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
  include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
///////////////////Deactivated Account By CJ UDAY :)
          if(isdeactivated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  <b>Your Account Has Been Deactivated Forever.<br/>And It Will Be Never Activate!</b><br/><br/>";
echo "</div>";
echo "<p align=\"center\"><a href=\"".$_SERVER['HTTP_REFFERER']."\">Back</a><br/><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
///////////////////Validation By CJ UDAY :)
					if(isvalidated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  You Are Not Validated!<br/>We are checking your ip and browser<br/>
	  This could take up to 15 munites pls be patient and try again soon<br/>Please try again later...<br/><b>Thank You</b><br/><br/>";
echo "</div>";
echo "<p align=\"center\"><a href=\"".$_SERVER['HTTP_REFFERER']."\">Back</a><br/><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
/////////////////////////////////Profile Updataed By CJ UDAY :)
if($action=="")
{
$whnick = subnick(getnick_uid($who));
if((isignored($uid, $who)))
{
    echo "<head>";
    echo "<title>Viewing $whnick Basic Profile</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
						echo "<div class=\"header\" align=\"center\">";
echo "<b>$whnick</b><br/>";
		if($uid == $who)
        {
		echo "<small><a href=\"nickshop.php\"><font color=\"white\">[Change Display Name]</font></a></small><br/>";
		}
		echo "(".getstatus($who).")<br/>";
		echo "".getranking($who)."<br/>";
		if(gettitle($who))
		echo "[".gettitle($who)."]<br/>";
		echo "</div>";
echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
echo "<p align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"><b>$whnick</b> has ignored you & you cannot see <b>$whnick's</b> profile!<br/>";
$ires = ignoreres($uid, $who);
if(isignored($who, $uid))
{
echo "<br/>&#187; <a href=\"proproc.php?action=del&who=$who\">Remove from Ignore List</a><br/>";
}
echo "</p>";
echo "</div>";
echo "<p align=\"center\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
exit();
}
if($uid == $who)
        {
addonline(getuid_sid($sid),"Viewing My Advance Profile","profile.php?sid=$sid&action=viewuser&amp;who=$who");
}else{
addonline(getuid_sid($sid),"Viewing $whnick Advance Profile","profile.php?sid=$sid&action=viewuser&amp;who=$who");
}
echo "<head>";
			if($uid == $who)
        {
$whnick = subnick(getnick_uid($uid));
    echo "<title>$whnick@My Advance Profile</title>";
	}else{
$whnick = subnick(getnick_uid($uid));
	echo "<title>$whnick@Viewing $whonick Advance Profile</title>";
	}
    echo "</head>";
    echo "<body>";

//echo "<div class=\"header\"> <img src=\"FireBD.png\" alt=\"[$sitename]\" width=\"280\" height=\"55\"/><br/>";
						$infd = mysql_fetch_array(mysql_query("SELECT hiranick FROM ibwff_users WHERE id='".$who."'"));
echo "<div class=\"\" align=\"center\">";
		echo "<b>$infd[0]</b><br/>";
		if($uid == $who)
{
		echo "<small><a href=\"nickshop.php\"><font color=\"white\">[Change Display Name]</font></a></small><br/>";
		}
		$text = parsepm(getstatus($who), $sid);
		echo "($text)<br/>";
		echo "".getranking($who)."<br/>";
if(getplusses($who)>".knightpoint().")
{
echo "".gettitle($who)."";
}else{
echo "";
}
echo "</div>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
						
////////////////////////////security System Updated By CJ UDAY :)			
$inf1 = mysql_fetch_array(mysql_query("SELECT prof FROM ibwff_users WHERE id='".$who."'"));
			echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
$whonick = getnick_uid($who);
echo "<p align=\"right\">";
////////Cover Picture By CJ UDAY :)
$coverpiclnk = getcoverpic($who);
$cf = "../coverpics/".$coverpiclnk;
$hexa = mysql_fetch_array(mysql_query("SELECT id FROM ibwff_gallery WHERE itemurl='".$cf."'"));
if($coverpiclnk=="")
{
if($uid == $who)
{echo "[<a href=\"coverpic.php\">Upload Your Cover Picture</a>]<br/><br/>";}
}else{
    if($inf1[0]=='1')
    {
 if(($who==$uid)||(arebuds($uid, $who))||(ispu(getuid_sid($sid)))||(ismod(getuid_sid($sid)))||(isowner(getuid_sid($sid))))
    {
echo "<a href=\"coverphoto.php?id=$hexa[0]\"><img src=\"../coverpics/$coverpiclnk\" alt=\"$coverpiclnk\" type=\"cover\" width=\"300\"/></a><br/><br/>";
}else{
 echo "";
}
}else{
echo "<a href=\"coverphoto.php?id=$hexa[0]\"><img src=\"../coverpics/$coverpiclnk\" alt=\"$coverpiclnk\" type=\"cover\" width=\"300\"/></a><br/><br/>";
}
if($uid == $who)
{
echo "[<a href=\"coverpic.php\">Upload Your Cover Picture</a>]<br/><br/>";}
}
$item = mysql_fetch_array(mysql_query("SELECT profilemsg FROM ibwff_users WHERE id='".$who."'"));
$unick = getnick_uid($who);
$text = parsepm($item[0], $sid);
    if($inf1[0]=='1')
    {
 if(($who==$uid)||(arebuds($uid, $who))||(ispu(getuid_sid($sid)))||(ismod(getuid_sid($sid)))||(isowner(getuid_sid($sid))))
    {
echo "$text";
}else{
echo "";
}
}else{
echo "$text-<b>$unick</b><br/>";
}
if($whonick!="")

{
if($uid == $who)
{
echo "<p align=\"right\">";
echo "[<a href=\"setting.php?action=upfmsg\">Update Profile Message</a>]";
echo "</p>";
}
echo "</p>";
    if($inf1[0]=='1')
    {
 if(($who==$uid)||(arebuds($uid, $who))||(ispu(getuid_sid($sid)))||(ismod(getuid_sid($sid)))||(isowner(getuid_sid($sid))))
    {
}else{
	    $sql = "SELECT name FROM ibwff_users WHERE id=$who";
	    $sql2 = mysql_query($sql);
	    $item = mysql_fetch_array($sql2);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item[0]'"));
if($sex[0]=="M"){$usex = "him";}
if($sex[0]=="F"){$usex = "her";}
if($sex[0]==""){$usex = "";}
	    $sql2 = "SELECT name FROM ibwff_users WHERE id=$who";
	    $sql22 = mysql_query($sql2);
	    $item2 = mysql_fetch_array($sql22);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item2[0]'"));
if($sex[0]=="M"){$usex2 = "his";}
if($sex[0]=="F"){$usex2 = "her";}
if($sex[0]==""){$usex2 = "";}
echo "<b>[It's a security profile]</b><br/>";
echo "<b>[Only friends can access $usex2 profile]</b><br/>";
echo "<b>[You cannot see $usex2 profile untill you become a friend of $usex]</b>";
}
}
}
}else{
echo "<div class=\"div\" align=\"center\">";
echo "<a href=\"profile.php?who=$who\">Basic</a> | <b>Advance</b> | ";
echo "<a href=\"prohis.php?who=$who\">History</a> | ";
echo "<a href=\"proact.php?who=$who\">Activity</a> | ";
echo "<a href=\"prostat.php?who=$who\">Statistics</a> ";
echo "</div><br/>";
}
if($inf1[0]=='1')
{
 if(($who==$uid)||(arebuds($uid, $who))||(ispu(getuid_sid($sid)))||(ismod(getuid_sid($sid)))||(isowner(getuid_sid($sid))))
    {
echo "<div class=\"div\" align=\"center\">";
echo "<a href=\"profile.php?who=$who\">Basic</a> | <b>Advance</b> | ";
echo "<a href=\"prohis.php?who=$who\">History</a> | ";
echo "<a href=\"proact.php?who=$who\">Activity</a> | ";
echo "<a href=\"prostat.php?who=$who\">Statistics</a> ";
echo "</div>";
}else{
echo "";
}
}
if(getuid_sid($sid) == $who)
{
echo "<p align=\"center\">";
echo "[<a href=\"setting.php?action=setting\">Update Your Profile</a>]<br/>";
echo "[<b><a href=\"privacy.php\">Change Your privacy</a></b>]<br/>";
}
}
   if($inf1[0]=='1')
    {
	echo "<b>[It's a privacy profile]</b><br/><br/>";
    }
 if($inf1[0]=='1')
    {
 if(($who==$uid)||(arebuds($uid, $who))||(ispu(getuid_sid($sid)))||(ismod(getuid_sid($sid)))||(isowner(getuid_sid($sid))))
    {
echo "<div class=\"div\" align=\"center\"><b>Advance Profile Of $whonick</b></div><br/>";
}else{
 echo "";
}
}else{
echo "<div class=\"div\" align=\"center\"><b>Advance Profile Of $whonick</b></div>";
}
echo "<p align=\"left\">";
if($inf1[0]=='1')
{
 if(($who==$uid)||(arebuds($uid, $who))||(ispu(getuid_sid($sid)))||(ismod(getuid_sid($sid)))||(isowner(getuid_sid($sid))))
    {
$bi = mysql_fetch_array(mysql_query("SELECT name, fn, sn, mst, rg, lin, ht, sat, wat FROM ibwff_users WHERE id='".$who."'"));
echo "<b><u>Basic Info</u></b><br/>";
echo "<b>Full name:</b> $bi[1]<br/><b>Surname:</b> $bi[2]<br/><b>Nickname:</b> $bi[0]<br/><b>Marital Status:</b> $bi[3]<br/><b>Religion:</b> $bi[4]<br/><b>Living In:</b> $bi[5]<br/><b>Hometown:</b> $bi[6]<br/><b>Study at:</b> $bi[7]<br/><b>Works at:</b> $bi[8]<br/>";
}else{
echo "";
}
}else{
$bi = mysql_fetch_array(mysql_query("SELECT name, fn, sn, mst, rg, lin, ht, sat, wat FROM ibwff_users WHERE id='".$who."'"));
echo "<b><u>Basic Info</u></b><br/>";
echo "<b>Full name:</b> $bi[1]<br/><b>Surname:</b> $bi[2]<br/><b>Nickname:</b> $bi[0]<br/><b>Marital Status:</b> $bi[3]<br/><b>Religion:</b> $bi[4]<br/><b>Living In:</b> $bi[5]<br/><b>Hometown:</b> $bi[6]<br/><b>Study at:</b> $bi[7]<br/><b>Works at:</b> $bi[8]<br/>";
}
if($uid == $who)
{
echo "<a href=\"advance.php?action=basic\">[Update Basic Info]</a><br/><br/>";
}
if($inf1[0]=='1')
{
 if(($who==$uid)||(arebuds($uid, $who))||(ispu(getuid_sid($sid)))||(ismod(getuid_sid($sid)))||(isowner(getuid_sid($sid))))
    {
$ap = mysql_fetch_array(mysql_query("SELECT height, weight, body, orgin, hair, eye FROM ibwff_users WHERE id='".$who."'"));
echo "<br/><b><u>Appearance</u></b><br/>";
echo "<b>Height:</b> $ap[0]<br/><b>Weight:</b> $ap[1]<br/><b>Body:</b> $ap[2]<br/><b>Ethnic orgin:</b> $ap[3]<br/><b>Hair:</b> $ap[4]<br/><b>Eyes:</b> $ap[5]<br/>";
}else{
echo "";
}
}else{
$ap = mysql_fetch_array(mysql_query("SELECT height, weight, body, orgin, hair, eye FROM ibwff_users WHERE id='".$who."'"));
echo "<br/><b><u>Appearance</u></b><br/>";
echo "<b>Height:</b> $ap[0]<br/><b>Weight:</b> $ap[1]<br/><b>Body:</b> $ap[2]<br/><b>Ethnic orgin:</b> $ap[3]<br/><b>Hair:</b> $ap[4]<br/><b>Eyes:</b> $ap[5]<br/>";
}
if($uid == $who)
{
echo "<a href=\"advance.php?action=app\">[Update Appearance]</a><br/><br/>";
}
if($inf1[0]=='1')
{
 if(($who==$uid)||(arebuds($uid, $who))||(ispu(getuid_sid($sid)))||(ismod(getuid_sid($sid)))||(isowner(getuid_sid($sid))))
    {
$in = mysql_fetch_array(mysql_query("SELECT mh, ms, ir, pf, bh, gh FROM ibwff_users WHERE id='".$who."'"));
echo "<br/><b><u>Interests</u></b><br/>";
echo "<b>Makes me happy:</b> $in[0]<br/><b>Makes me sad:</b> $in[1]<br/><b>Interests:</b> $in[2]<br/><b>Profession:</b> $in[3]<br/><b>Bad habits:</b> $in[4]<br/><b>Good habits:</b> $in[5]<br/>";
}else{
echo "";
}
}else{
$in = mysql_fetch_array(mysql_query("SELECT mh, ms, ir, pf, bh, gh FROM ibwff_users WHERE id='".$who."'"));
echo "<br/><b><u>Interests</u></b><br/>";
echo "<b>Makes me happy:</b> $in[0]<br/><b>Makes me sad:</b> $in[1]<br/><b>Interests:</b> $in[2]<br/><b>Profession:</b> $in[3]<br/><b>Bad habits:</b> $in[4]<br/><b>Good habits:</b> $in[5]<br/>";
}
if($uid == $who)
{
echo "<a href=\"advance.php?action=int\">[Update Interests]</a><br/><br/>";
}
if($inf1[0]=='1')
{
 if(($who==$uid)||(arebuds($uid, $who))||(ispu(getuid_sid($sid)))||(ismod(getuid_sid($sid)))||(isowner(getuid_sid($sid))))
    {
$fav = mysql_fetch_array(mysql_query("SELECT teamx, bandx, musicx, showx, foodx, athrx, moviex, animalx, placex, thingx FROM ibwff_users WHERE id='".$who."'"));
echo "<b><u>Favourites</u></b><br/>";
echo "<b>Team:</b> $fav[0]<br/><b>Singer/Band:</b> $fav[1]<br/><b>Music:</b> $fav[2]<br/><b>TV/Show:</b> $fav[3]<br/><b>Food:</b> $fav[4]<br/><b>Author:</b> $fav[5]<br/><b>Movie:</b> $fav[6]<br/><b>Animal:</b> $fav[7]<br/><b>Place:</b> $fav[8]<br/><b>Thing:</b> $fav[9]<br/>";
}else{
echo "";
}
}else{
$fav = mysql_fetch_array(mysql_query("SELECT teamx, bandx, musicx, showx, foodx, athrx, moviex, animalx, placex, thingx FROM ibwff_users WHERE id='".$who."'"));
echo "<b><u>Favourites</u></b><br/>";
echo "<b>Team:</b> $fav[0]<br/><b>Singer/Band:</b> $fav[1]<br/><b>Music:</b> $fav[2]<br/><b>TV/Show:</b> $fav[3]<br/><b>Food:</b> $fav[4]<br/><b>Author:</b> $fav[5]<br/><b>Movie:</b> $fav[6]<br/><b>Animal:</b> $fav[7]<br/><b>Place:</b> $fav[8]<br/><b>Thing:</b> $fav[9]<br/>";
}
if($uid == $who)
{
echo "<a href=\"advance.php?action=fav\">[Update Favourites]</a><br/><br/>";
}
if($inf1[0]=='1')
{
 if(($who==$uid)||(arebuds($uid, $who))||(ispu(getuid_sid($sid)))||(ismod(getuid_sid($sid)))||(isowner(getuid_sid($sid))))
    {
$mam = mysql_fetch_array(mysql_query("SELECT mamx FROM ibwff_users WHERE id='".$who."'"));
echo "<b><u>More About Me:</u></b><br/>";
echo "<b>Description:</b> $mam[0]<br/>";
}else{
echo "";
}
}else{
$mam = mysql_fetch_array(mysql_query("SELECT mamx FROM ibwff_users WHERE id='".$who."'"));
echo "<b><u>More About Me:</u></b><br/>";
echo "<b>Description:</b> $mam[0]<br/>";
}
if($uid == $who)
{
echo "<a href=\"advance.php?action=mam\">[Update Description]</a><br/>";
}
echo "</p>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
exit();
}
?>
</html>