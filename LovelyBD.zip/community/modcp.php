<?php
session_start();
include("config.php");
include("core.php");  connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo '<head>';
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"title\" content=\"FireBD.NeT\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From Megh: Don't Try To Hack OR else :P\">
<meta name=\"keywords\" content=\"Site Desined By Megh :) :)\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/></head>";
echo "<body>";
$sid = $_SESSION["sid"];
$page = $_GET["page"];
$who = $_GET["who"];
$pmid = $_GET["pmid"];
$whonick = getnick_uid($who);
$byuid = getuid_sid($sid);
$uid = getuid_sid($sid);
$action = $_GET["action"];
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();
////////////////Ip Banned By CJ UDAY :)	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
echo "<head>";
echo "<title>Error!!!</title>";
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\"/>";
echo "</head>";
echo "<body>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
echo "<br/>";
echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
$banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
$remain =  $banto[0] - time();
$rmsg = gettimemsg($remain);
echo "<b>Time Remaining: $rmsg</b><br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "</p>";
echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
$uid = getuid_sid($sid);
//////////////////Banned System Updated By CJ UDAY :)
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\"/>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please Contact <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\"/>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php"); 
echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\"/>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
///////////////////Deactivated Account By CJ UDAY :)
          if(isdeactivated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  <b>Your Account Has Been Deactivated Forever.<br/>And It Will Be Never Activate!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
///////////////////Validation By CJ UDAY :)
					if(isvalidated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
           echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  You Are Not Validated!<br/>We are checking your ip and browser<br/>
	  This could take up to 15 munites pls be patient and try again soon<br/>Please try again later...<br/><b>Thank You</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
///////////////////////////////////////Access By CJ UDAY :)
if($action=="")
{
	echo "<head>";
    echo "<title>Moderator Tools!</title>";
   echo "</head>";
    echo "<body>";
    echo "<div class=\"header\" align=\"left\">";
echo "<img src=\"FireBD.png\" alt=\"$sitename\" type=\"logo\" width=\"240\" height=\"50\"/><br/>";
echo "<b>Moderator Tools!</b></div>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							
  echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<div class=\"block\" align=\"left\">";
  $uid = getuid_sid($sid);
if(settingboss($uid))
{
echo "&#187; <a href=\"udaycp.php?action=gen\"> General Settings</a><hr>";
}
if(announcementboss($uid))
{
echo "&#187; <a href=\"udaycp.php?action=an\"> Announcements</a><hr>";
}
if(instructionboss($uid))
{
echo "&#187; <a href=\"udaycp.php?action=ins\"> Instructions</a><hr>";
}
if(forumboss($uid))
{
echo "&#187; <a href=\"udaycp.php?action=forum\">Forums</a><hr>";
echo "&#187; <a href=\"udaycp.php?action=fcat\"> Forum Catagories</a><hr>";
}
if(literatureboss($uid))
{
echo "&#187; <a href=\"udaycp.php?action=lit\">Literatures</a><hr>";
echo "&#187; <a href=\"udaycp.php?action=litcat\"> Literature Catagories</a><hr>";
}
if(smiliesboss($uid))
{
echo "&#187; <a href=\"../smilies/index.php?action=upload\">Upload Smiley</a><hr>";
echo "&#187; <a href=\"udaycp.php?action=asm\"> Add Smiley</a><hr>";
}
if(blocksiteboss($uid))
{
echo "&#187; <a href=\"udaycp.php?action=bsit\">Block Site</a><hr>";
}
if(bedregboss($uid))
{
echo "&#187; <a href=\"udaycp.php?action=breg\">Block Bad Register</a><hr>";
}
if(badnickboss($uid))
{
echo "&#187; <a href=\"udaycp.php?action=bnik\">Block Bad Nick</a><hr>";
}
if(pm2allboss($uid))
{
echo "&#187; <a href=\"pm2all.php\">PM 2 All</a><hr>";
}
if(rewardboss($uid))
{
echo "&#187; <a href=\"reward2all.php\">Reward 2 All</a><hr>";
}
if(chatboss($uid))
{
echo "&#187; <a href=\"udaycp.php?action=chat\">Chatrooms</a><hr>";
}
if(cleardataboss($uid))
{
echo "&#187; <a href=\"cleardata.php\">Clear Data</a><hr>";
}
if(isowner($uid))
{
echo "&#187; <a href=\"udaycp.php?action=logo\">Logo Settings</a><hr>";
echo "&#187; <a href=\"udaycp.php?action=themes\"> Theme Settings</a><hr>";
echo "&#187; <a href=\"udaycp.php?action=hso\">Hide Staff Online Settings</a><hr>";
}
 echo "</div>";
 echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
}
//////////////////////////Mod a user Updated By CJ UDAY//////////////////////////
else if($action=="user")
{
  $who = $_GET["who"];
  $uid = getuid_sid($sid);
	echo "<head>";
    echo "<title>Staff Tools!</title>";
    echo "</head>";
    echo "<body>";
    echo "<div class=\"header\" align=\"left\">";
echo "<img src=\"FireBD.png\" alt=\"$sitename\" type=\"logo\" width=\"240\" height=\"50\"/><br/>";
$unick = subnick(getnick_uid($who));					
echo "<b>Moderating $unick!</b></div>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";

  echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
 echo "<div class=\"div\"><b><u>Reward Penalitys:-</u></b></div>";
  echo "<p align=\"left\">";
if(pointboss($uid))
{
  echo "&#8594; <a href=\"mcp.php?action=point&who=$who\">Points</a><br/>";
}
if(blncboss($uid))
{
  echo "&#8594; <a href=\"mcp.php?action=balance&who=$who\">Account Balance</a><br/>"; 
}
if(wrboss($uid))
{
  echo "&#8594; <a href=\"mcp.php?action=warn&who=$who\">Warning level</a><br/>";
} 
if(gcboss($uid))
{
 echo "&#8594; <a href=\"mcp.php?action=gc&who=$who\">Golden Coins</a><br/>";
}
if(gpboss($uid))
{
  echo "&#8594; <a href=\"mcp.php?action=gpoint&who=$who\">Game Points</a><br/>";
}
  echo "</p>";
   if($who==1)
  {
  echo "";
  }else if($who==2)
  {
  echo "";
  }else{
if(readboss($uid))
{
  echo "<div class=\"div\"><b><u>Read User:-</u></b></div>";
  echo "<p align=\"left\">";
     echo "&#8594; <a href=\"mcp.php?action=msgs&who=$who\">Read Conversations</a><br/>";
   echo "</p>";
}
  }
  if($who==1)
  {
  echo "";
  }else if($who==2)
  {
  echo "";
  }else{
if(addpboss($uid))
{
   echo "<div class=\"div\"><b><u>Staff Power:-</u></b></div>";
   echo "<p align=\"left\">";
if(!ismod($who))
{
   echo "&#8594; <a href=\"cjcp.php?action=mkstf&who=$who\">Make Staff</a><br/>"; 
}else{
   echo "&#8594; <a href=\"cjcp.php?action=remstf&who=$who\">Remove From Staff</a><br/>";   
}
$d = mysql_fetch_array(mysql_query("SELECT status FROM ibwff_usersecurity WHERE uid='".$who."'"));
if($d[0]=='1')
{
   echo "&#8594; <a href=\"cjcp.php?action=sof&who=$who\">Turned Off Security Code</a><br/>";
}
if(ismod($who))
{
  $noi = mysql_fetch_array(mysql_query("SELECT showonline FROM ibwff_users WHERE id='".$who."'"));
  if($noi[0]==1)
  {
  echo "&#8594; <a href=\"cjcp.php?action=ssonl&who=$who\">Show In Staff Online</a><br/>";
  }else{
  echo "&#8594; <a href=\"cjcp.php?action=hsonl&who=$who\">Hide In Staff Online</a><br/>";
  } 
}
}
if(editpboss($uid))
{  
     if($who==1)
  {
  echo "";
  }else if($who==2)
  {
  echo "";
  }else{
  	echo "&#8594; <a href=\"cjcp.php?action=editu&who=$who\">Edit User</a>";
 }
}
}

   if($who==1)
  {
  echo "";
  }else if($who==2)
  {
  echo "";
  }else{
  echo "<div class=\"div\"><b><u>Banned Penalitys:-</u></b></div>";
  echo "<p align=\"left\">";
  $noi = mysql_fetch_array(mysql_query("SELECT count(*) FROM ibwff_users WHERE validated='0' AND id='".$who."'"));
  if($noi[0]==1)
  {
  echo "&#8594; <a href=\"validate.php?action=user&who=$who\">Validate</a><br/>";
  }else{
  echo "&#8594; <a href=\"validate.php?action=unuser&who=$who\">Unvalidate</a><br/>";
  }
  echo "&#8594; <a href=\"cjproc.php?action=boot&who=$who\">Boot</a><br/>";
if(deacboss($uid))
{
$noi = mysql_fetch_array(mysql_query("SELECT count(*) FROM ibwff_users WHERE diactivate='1' AND id='".$who."'"));
  if($noi[0]==1)
  {
  echo "&#8594; <a href=\"cjproc.php?action=active&who=$who\">Activate This Account</a><br/>";
  }else{
  echo "&#8594; <a href=\"cjproc.php?action=deactive&who=$who\">Deactivate This Account</a><br/>";
}
}
if(vippboss($uid))
{
    $vp = mysql_fetch_array(mysql_query("SELECT vip FROM ibwff_users WHERE id='".$who."'"));
if($vp[0]=="0")
{
echo "&#8594; <a href=\"cjproc.php?action=vip&who=$who\">Make VIP From Normal</a><br/>";
}else{
echo "&#8594; <a href=\"cjproc.php?action=unvip&who=$who\">Make Normal From VIP</a><br/>";
}  
}
}
   if($who==1)
  {
  echo "";
  }else if($who==2)
  {
  echo "";
  }else{
  if(!istrashed($who))
  {
  echo "&#8594; <a href=\"cjproc.php?action=trash&who=$who\">Trash</a><br/>";
  }else{
  echo "&#8594; <a href=\"cjproc.php?action=untr&who=$who\">Untrash</a><br/>";
  }
if(shieldboss($uid))
{
  if(!isshield($who))
  {
  echo "&#8594; <a href=\"cjproc.php?action=shld&who=$who\">Shield</a><br/>";
  }else{
  echo "&#8594; <a href=\"cjproc.php?action=ushld&who=$who\">Unshield</a><br/>";
  }
  }
}  
 if($who==1)
  {
  echo "";
  }else if($who==2)
  {
  echo "";
  }else{
if(banboss($uid))
{
  if(!isbanned($who))
  {
  echo "&#8594; <a href=\"banproc.php?action=ban&who=$who\">Ban</a><br/>";
if(ipbanboss($uid))
{
  echo "&#8594; <a href=\"banproc.php?action=ipban&who=$who\">Ip-ban</a><br/>";
}
  }else{
  echo "&#8594; <a href=\"banproc.php?action=unbn&who=$who\">Unban</a><br/>";
  }
}
  }
   if($who==1)
  {
  echo "";
  }else if($who==2)
  {
  echo "";
  }else{
if(pmboss($uid))
{
  if(!ispmban($who))
  {
  echo "&#8594; <a href=\"banproc.php?action=pmban&who=$who\">PM Ban</a><br/>";
  }else{
  echo "&#8594; <a href=\"banproc.php?action=pmunban&who=$who\">PM Unban</a><br/>";
  }
}
if(forumboss($uid))
{
  if(!isforumban($who))
  {
  echo "&#8594; <a href=\"banproc.php?action=forumban&who=$who\">Forum Ban</a><br/>";
  }else{
  echo "&#8594; <a href=\"banproc.php?action=forumunban&who=$who\">Forum Unban</a><br/>";
  }
if(!ispostban($who))
  {
  echo "&#8594; <a href=\"banproc.php?action=postban&who=$who\">Post Ban</a><br/>";
  }else{
  echo "&#8594; <a href=\"banproc.php?action=postunban&who=$who\">Post Unban</a><br/>";
  }
}
if(chatboss($uid))
{
 if(!ischatban($who))
  {
  echo "&#8594; <a href=\"banproc.php?action=chatban&who=$who\">Chat Ban</a><br/>";
  }else{
  echo "&#8594; <a href=\"banproc.php?action=chatunban&who=$who\">Chat Unban</a><br/>";
  }
}
if(pollboss($uid))
{
  if(!ispollsban($who))
  {
  echo "&#8594; <a href=\"banproc.php?action=pollban&who=$who\">Poll Ban</a><br/>";
  }else{
  echo "&#8594; <a href=\"banproc.php?action=pollunban&who=$who\">Poll Unban</a><br/>";
  }
}
if(blogboss($uid))
{
  if(!isblogsban($who))
  {
  echo "&#8594; <a href=\"banproc.php?action=blogban&who=$who\">Blog Ban</a><br/>";
  }else{
  echo "&#8594; <a href=\"banproc.php?action=blogunban&who=$who\">Blog Unban</a><br/>";
  }
  if(!isblogscomban($who))
  {
  echo "&#8594; <a href=\"banproc.php?action=blogcomban&who=$who\">Blog Comment Ban</a><br/>";
  }else{
  echo "&#8594; <a href=\"banproc.php?action=blogcomunban&who=$who\">Blog Comment Unban</a><br/>";
  }
}
if(shoutboss($uid))
{
  if(!isshoutban($who))
  {
  echo "&#8594; <a href=\"banproc.php?action=shoutban&who=$who\">Shout Ban</a><br/>";
  }else{
  echo "&#8594; <a href=\"banproc.php?action=shoutunban&who=$who\">Shout Unban</a><br/>";
  }
}
if(literatureboss($uid))
{
  if(!isliteratureban($who))
  {
  echo "&#8594; <a href=\"banproc.php?action=letban&who=$who\">Literature Ban</a><br/>";
  }else{
  echo "&#8594; <a href=\"banproc.php?action=letunban&who=$who\">Literature Unban</a><br/>";
  }
}
  echo "</p>";
  }
   if($who==1)
  {
  echo "";
  }else if($who==2)
  {
  echo "";
  }else{
    echo "</p>";
   echo "<div class=\"div\"><b><u>Delete Functions:-</u></b></div>";
   echo "<p align=\"left\">";
   echo "&#8594; <a href=\"deletefunctions.php?action=delprivate&who=$who\">Delete PMs</a><br/>";
   echo "&#8594; <a href=\"deletefunctions.php?action=delshout&who=$who\">Delete Shouts</a><br/>";
   echo "&#8594; <a href=\"deletefunctions.php?action=deltopics&who=$who\">Delete Topics</a><br/>";
   echo "&#8594; <a href=\"deletefunctions.php?action=delpsts&;who=$who\">Delete Posts</a><br/>";
   echo "&#8594; <a href=\"deletefunctions.php?action=delstorys&who=$who\">Delete Literatures</a><br/>";
   echo "&#8594; <a href=\"deletefunctions.php?action=delblog&who=$who\">Delete Blogs</a><br/>";
   echo "&#8594; <a href=\"deletefunctions.php?action=delpoll&who=$who\">Delete Polls</a><br/>";  
   echo "&#8594; <a href=\"deletefunctions.php?action=delpollvote&who=$who\">Delete Poll Votes</a><br/>";  
   echo "&#8594; <a href=\"deletefunctions.php?action=delclb&who=$who\">Delete Club</a><br/>";
   echo "&#8594; <a href=\"deletefunctions.php?action=delshts&who=$who\">Delete Shouts</a><br/>";
   echo "&#8594; <a href=\"deletefunctions.php?action=delshtlike&who=$who\">Delete Shout Likes</a><br/>";
   echo "&#8594; <a href=\"deletefunctions.php?action=delshtdislike&who=$who\">Delete Shout Dislikes</a><br/>";
   echo "&#8594; <a href=\"deletefunctions.php?action=delst&who=$who\">Delete Status</a><br/>"; 
   echo "&#8594; <a href=\"deletefunctions.php?action=delstlike&who=$who\">Delete Status Likes</a><br/>"; 
   echo "&#8594; <a href=\"deletefunctions.php?action=delstdislike&who=$who\">Delete Status Dislikes</a><br/>"; 
   echo "&#8594; <a href=\"deletefunctions.php?action=delfriend&who=$who\">Delete Friends</a><br/>";
   echo "&#8594; <a href=\"deletefunctions.php?action=delignore&who=$who\">Delete Ignores</a><br/>";
   echo "&#8594; <a href=\"deletefunctions.php?action=dellove&who=$who\">Delete Loves</a><br/>";
   echo "&#8594; <a href=\"deletefunctions.php?action=delmiss&who=$who\">Delete Missess</a><br/>";
   echo "&#8594; <a href=\"deletefunctions.php?action=delothers&who=$who\">Delete Others</a><br/>"; 
   echo "&#8594; <a href=\"deletefunctions.php?action=delgift&who=$who\">Delete Gifts</a><br/>"; 
   echo "&#8594; <a href=\"deletefunctions.php?action=delgb&who=$who\">Delete Guestbooks</a><br/>";
   echo "&#8594; <a href=\"deletefunctions.php?action=delstpsts&who=$who\">Delete Literature Posts</a><br/>";
   echo "&#8594; <a href=\"deletefunctions.php?action=delblogcom&who=$who\">Delete Blog Comments</a><br/>";  
   echo "&#8594; <a href=\"deletefunctions.php?action=delstcom&who=$who\">Delete Status Comments</a><br/>"; 
   echo "&#8594; <a href=\"deletefunctions.php?action=delshtcom&who=$who\">Delete Shouts Comments</a><br/>";
   echo "&#8594; <a href=\"deletefunctions.php?action=delnotification&who=$who\">Delete Notifications</a><br/>";
   echo "&#8594; <a href=\"deletefunctions.php?action=delcoverphtcom&who=$who\">Delete Cover Photo Comments</a><br/>";  
   echo "&#8594; <a href=\"deletefunctions.php?action=delcoverphtlike&who=$who\">Delete Cover Photo Likes</a><br/>";  
   echo "&#8594; <a href=\"deletefunctions.php?action=delcoverphtdislike&who=$who\">Delete Cover Photo Dislikes</a><br/>"; 
   echo "&#8594; <a href=\"deletefunctions.php?action=delpfpicom&who=$who\">Delete Profile Picture Comments</a><br/>";  
   echo "&#8594; <a href=\"deletefunctions.php?action=delpfpiclike&who=$who\">Delete Profile Picture Likes</a><br/>";  
   echo "&#8594; <a href=\"deletefunctions.php?action=delpfpicdislike&who=$who\">Delete Profile Picture Dislikes</a><br/>";     
   }
  echo "</p>";
  echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
}
?>
</html>