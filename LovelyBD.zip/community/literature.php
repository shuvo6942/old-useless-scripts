<?php
session_start();
include("config.php");
include("core.php");
connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo '<head>';
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\"/>";
$udy = mysql_query("SELECT tags FROM ibwff_storys WHERE id='".$tid."'");
$roman = mysql_fetch_array($udy);
echo "<meta name=\"description\" content=\"$roman[0]\">";
echo "<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG : Don't Try To Hack OR else :P\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/></head>";
echo "<body>";
##L!T3RATUR3 !Z FULLY CR3AT3D BY Shahos
$action = $_GET["action"]; $sid = $_SESSION["sid"];
$clid = $_GET["clid"];
$page = $_GET["page"];
$who = $_GET["who"];
$whonick = getnick_uid($who);
$byuid = getuid_sid($sid);
$uid = getuid_sid($sid);
$sitename = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='sitename'"));
$sitename = $sitename[0];
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();
////////////////Ip Ban By CJ UDAY :)
if(isipbanned($ipad,$ubrw))
{
if(!isshield(getuid_sid($sid)))
{
echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
echo "<br/>";
echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
$banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
$remain =  $banto[0] - time();
$rmsg = gettimemsg($remain);
echo "<b>Time Remaining: $rmsg</b><br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "</p>";
echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
exit();
}
}
$uid = getuid_sid($sid);
//////////////////Ban System Updated BY CJ UDAY :)
if(isbanned($uid))
{
echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please Contact <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
/////////////////////Article Ban :)
$ban = mysql_fetch_array(mysql_query("SELECT letban FROM ibwff_users WHERE id='".$uid."'"));
if($ban[0] > 0)
{
echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<br/><b><u><i>Can't Enter To Articles<br/>";
echo "You're Article banned!</u></i></b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(!isuser(getuid_sid($sid)))
{
echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<br/>This feature is unavailiable for guests.
So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
echo "<div class=\"div\" align=\"center\">";
echo "<b>USER ACCESS</b></div>";
echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";
echo "</form><br/><br/>";
echo "Not Registered Yet?<br/>";
echo "<a href=\"register.php\">Register Now!</a>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(islogged($sid)==false)
{
echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<br/>For some security reasons,you are automatically logged out.<br/>
You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
Or, Please Login Again :-)<br/><br/>";
echo "<div class=\"div\" align=\"center\">";
echo "<b>USER ACCESS</b></div>";
echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
///////////////////Deactivated Account :)
if(isdeactivated(getuid_sid($sid), $uid))
{
echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<br/>
<b>Your Account Has Been Deactivated.<br/>And It Will Be Never Activated Again!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
exit();
}
///////////////////Validation :)
if(isvalidated(getuid_sid($sid), $uid))
{
echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<br/>
You Are Not Validated!<br/>We are checking your ip and browser<br/>
This could take up to 15 munites pls be patient and try again soon<br/>Please try again later...<br/><b>Thank You</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
exit();
}
//////////////////////////////////Articles Updated :)
if($action=="Lite")
{
addonline(getuid_sid($sid),"Viewing Articles","literature.php?action=$action");
echo "<head>";
echo "<title>View Articles</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Articles</b><br/>Articles Categories</div>";
echo "<center>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<b>Top Article Poster Of The Day:</b>";
include("topliterator.php");
echo "<br/><b>Top Article Poster Of The Week:</b><br/>";
include("top_weekly_literator.php");
echo "<br/><b>Last 10 Story:</b><br/>";
include("laststory.php");
echo "<br/><b>Last 10 Poem:</b><br/>";
include("lastpoem.php");
echo "<br/><b>Last 10 Joke:</b><br/>";
include("lastjoke.php");
$letcats = mysql_query("SELECT id, name FROM ibwff_letcats ORDER BY position, id");
$iml = "<img src=\"../images/literature.png\" alt=\"*\">";
while($fcat=mysql_fetch_array($letcats))
{
$catlink = "$fcat[1]";
echo "<p align=\"left\"><b>$catlink</b><br/>";
$forums = mysql_query("SELECT id, name FROM ibwff_literatures WHERE cid='".$fcat[0]."' AND clubid='0' ORDER BY position, id, name");
while($forum=mysql_fetch_array($forums))
{
$notp = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_storys WHERE fid='".$forum[0]."'"));
$nops = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_storyposts a INNER JOIN ibwff_storys b ON a.tid = b.id WHERE b.fid='".$forum[0]."'"));
if(litcatval_uday($forum[0]))
{
echo "<a href=\"literature.php?action=viewlitbox&fid=$forum[0]\">$iml$forum[1]
$notp[0]/$nops[0]</a><br/>";
}else{
			if (literatureboss($uid))
	{
	echo "&#8226; Catagory name: <b>$forum[1]</b><br/>";
	    echo "&#8226; <a href=\"validate.php?action=vallit&fid=$forum[0]\"> Validate $forum[1]</a><br/>";
}
echo "------<br/>";
}
}
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
exit();
}
else if($action=="")
{
$tid = $_GET["tid"];
$go = $_GET["go"];
$clid = $_GET["clid"]; $action = $_GET["action"];
$tinfo = mysql_fetch_array(mysql_query("SELECT name, text, authorid, crdate, views, fid, pollid from ibwff_storys WHERE id='".$tid."'"));
addonline(getuid_sid($sid),"Viewing $tinfo[0] Topic","literatures.php?action=viewlit&tid=$tid");
$tfid = mysql_fetch_array(mysql_query("SELECT fid FROM ibwff_storys WHERE id='".$tid."'"));
$uday = littyp_fid($tfid[0]);
$cfrm = mysql_fetch_array(mysql_query("SELECT clubid FROM ibwff_literatures WHERE id='".$tfid[0]."'"));
$tinfo = mysql_fetch_array(mysql_query("SELECT name, text, authorid, crdate, views, fid, pollid from ibwff_storys WHERE id='".$tid."'"));
$tnm = htmlspecialchars($tinfo[0]);
if (!litval($tid))
{
echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<br/>
This Article is waiting for validation!<br/>Please try again later...<br/><b>Thank You</b><br/><br/>";
if (isclubmod((getuid_sid($sid)),$clid) || isownerclub((getuid_sid($sid)),$clid) || literatureboss($uid))
{
$fname = mysql_fetch_array(mysql_query("SELECT name, text FROM ibwff_storys WHERE id='".$tid."'"));
$name = $fname[0];
$text = $fname[1];
echo "&#8226; Article name: <b>$name</b><br/>";
echo "&#8226; Article Text: <br/>".getbbcode($text,$sid)."<br/>";
echo "&#8226; <a href=\"validate.php?action=valart&tid=$tid\"> Validate $name</a><br/>";
echo "&#8226; <a href=\"literature.php?action=litopt&tid=$tid\"> Edit $name</a><br/>";
echo "&#8226; <a href=\"delete.php?action=art&tid=$tid\"> Delete $name</a><br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
exit();
}   
echo "<head>";
echo "<title>Viewing $tinfo[0] $uday</title>";
$udy = mysql_query("SELECT tags FROM ibwff_storys WHERE id='".$tid."'");
$roman = mysql_fetch_array($udy);
echo "<meta name=\"description\" content=\"$roman[0]\">";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";	
echo "<div class=\"header\" align=\"center\">";
echo "<b>Viewing $tinfo[0] $uday</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$num_pages = getnumpages($tid);
if($page==""||$page<1)$page=1;
if($go!="")$page=getpage_go($go,$tid);
$storyposts_per_page = 5;
if($page>$num_pages)$page=$num_pages;
$limit_start = $storyposts_per_page *($page-1);
echo "&#187; <a href=\"literature.php?action=comment&clid=$clid&tid=$tid\">Post Comment</a><br/>";
$lastlink = "&#187; <a href=\"literature.php?action=$action&amp;tid=$tid&clid=$clid&amp;go=last\"> Last Page</a><br/>";
$firstlink = "&#171; <a href=\"literature.php?action=$action&amp;tid=$tid&clid=$clid&amp;who=$who&page=1\">First Page</a><br/>";
$golink = "";
if($page>1)
{
$golink = $firstlink;
}
if($page<$num_pages)
{
$golink .= $lastlink;
}
if($golink !="")
{
echo "$golink";
}
$vws = $tinfo[4]+1;
$tid = $_GET["tid"];
$sub = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM uday_sublit WHERE tid='".$tid."'"));
$rpls = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_storyposts WHERE tid='".$tid."'"));
echo "ID: $tid<br/>";
echo "Subscriber: $sub[0]<br/>";
echo "Comments: $rpls[0] - ";
echo "Views: $vws<br/>";
$tfid = mysql_fetch_array(mysql_query("SELECT fid FROM ibwff_storys WHERE id='".$tid."'"));
$cj = mysql_fetch_array(mysql_query("SELECT tags FROM ibwff_storys WHERE id='".$tid."'"));
echo "<b>Tags:</b> $cj[0]<br/>";
$cfrm = mysql_fetch_array(mysql_query("SELECT clubid FROM ibwff_literatures WHERE id='".$tfid[0]."'"));
if ($clid>0)
{
$cname = getclubname($clid);
echo "Club Name: <b>$cname</b><br/>";
}
$suscriber = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM uday_sublit WHERE uid='".$uid."' AND tid='".$tid."'"));
if($suscriber[0]>0)
{
echo"<img src=\"../images/unsub.png\" alt=\"-\"> <a href=\"litproc.php?action=litunsub&tid=$tid\">Unsubscribe Article</a>";
}else{
echo "<img src=\"../images/sub.png\" alt=\"-\"> <a href=\"litproc.php?action=litsub&tid=$tid\">Subscribe Article</a>";
}
echo "<br/>";
if($page==1)
{
$storyposts_per_page=4;
mysql_query("UPDATE ibwff_storys SET views='".$vws."' WHERE  id='".$tid."'");
$ttext = mysql_fetch_array(mysql_query("SELECT authorid, text, crdate FROM ibwff_storys WHERE id='".$tid."'"));
$unick = subnick(getnick_uid($ttext[0]));
$sql = "SELECT name FROM ibwff_users WHERE id=$ttext[0]";
$sql2 = mysql_query($sql);
$item = mysql_fetch_array($sql2);
{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item[0]'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/>";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/>";}
if($sex[0]==""){$usersex = "";}      if(isonline($ttext[0]))
{
$iml = "<img src=\"../avatars/onl.gif\" alt=\" \"/>";
}else{
$iml = "<img src=\"../avatars/ofl.gif\" alt=\"-\"/>";
}
$avlink = getavatar($ttext[0]);
if($avlink=="")
{
$avt =  "$usersex";
}else{
$avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"icon\" width=\"23\" height=\"18\"/>";
}
$sql3 = "SELECT name FROM ibwff_users WHERE id=$ttext[0]";
$sql33 = mysql_query($sql3);
$item3 = mysql_fetch_array($sql33);
{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nicks = "<font color=\"blue\"><b>$unick</b></font>";}
if($sex[0]=="F"){$nicks = "<font color=\"deeppink\"><b>$unick</b></font>";}
if($sex[0]==""){$nicks = "";}
$usl = "<div class=\"mblock1\" align=\"left\">$iml$avt<a href=\"profile.php?who=$ttext[0]\">$nicks</a>";
}
$topt = "<a href=\"literature.php?action=litopt&clid=$clid&tid=$tid\">[+]</a>";
}
if($go==$tid)
{
$fli = "<img src=\"../avatars/flag.gif\" alt=\"!\"/>";
}else{
$fli ="";
}
$pst = parsemsg($ttext[1],$sid);
$dtot = date("h:i:s A D d M y",$ttext[2]);
echo "$usl:<br/>(".getstatus($ttext[0]).")<br/><small>$dtot</small><br/><br/>";
echo "$fli$pst";
echo "<br/></div>";
echo "&#187; <a href=\"sms:?body=$pst($sitename)\">Share Via Sms</a>";
echo "<p align=\"left\">"; echo "$topt<br/>";
echo "<b>Topic Ratings:</b><br/>";
$rtr = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM uday_litrate WHERE tid='".$tid."'"));
$rate = getlitrate($uid, $tid);
echo "$rate(<a href=\"literature.php?action=raters&tid=$tid\">$rtr[0]</a>)<br/>";
$vb = mysql_fetch_array(mysql_query("SELECT rate FROM uday_litrate WHERE uid='".$uid."' AND tid='".$tid."'"));
echo "<form action=\"litproc.php?action=litrate&tid=$tid\" method=\"post\">";
echo "<select name=\"rate\" value=\"$vb[0]\">";
echo "<option value=\"5\">Very Good</option>";
echo "<option value=\"4\">Good</option>";
echo "<option value=\"3\">Ok</option>";
echo "<option value=\"2\">Nice</option>";
echo "<option value=\"1\">Poor</option>";
echo "</select>";
echo "<input type=\"hidden\" name=\"system\" value=\"literature\"/>";
echo "<input type=\"submit\" value=\"Rate\"/>";
echo "</form>";
}
if($page>1)
{
$limit_start--;
}
$sql = "SELECT id, text, uid, dtpost, quote FROM ibwff_storyposts WHERE tid='".$tid."' ORDER BY dtpost LIMIT $limit_start, $storyposts_per_page";
$storyposts = mysql_query($sql);
while($post = mysql_fetch_array($storyposts))
{
$unick = subnick(getnick_uid($post[2]));
$sql2 = "SELECT name FROM ibwff_users WHERE id=$post[2]";
$sql22 = mysql_query($sql2);
$item2 = mysql_fetch_array($sql22);
{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item2[0]'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/>";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/>";}
if($sex[0]==""){$usersex = "";}
if(isonline($post[2]))
{
$iml = "<img src=\"../avatars/onl.gif\" alt=\" \"/>";
}else{
$iml = "<img src=\"../avatars/ofl.gif\" alt=\"-\"/>";
}
$avlink = getavatar($post[2]);
if($avlink=="")
{
$avt =  "$usersex";
}else{
$avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"icon\" width=\"23\" height=\"18\"/>";
}
$sql3 = "SELECT name FROM ibwff_users WHERE id=$post[2]";
$sql33 = mysql_query($sql3);
$item3 = mysql_fetch_array($sql33);
{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nick = "<font color=\"blue\"><b>$unick</b></font>";}
if($sex[0]=="F"){$nick = "<font color=\"deeppink\"><b>$unick</b></font>";}
if($sex[0]==""){$nick = "";}
$usl = "<br/>$iml$avt<a href=\"profile.php?who=$post[2]\">$nick<br/></a>(".getstatus($post[2]).")<br/>";
}
}
$pst = parsemsg($post[1], $sid);
$topt = "<a href=\"literature.php?action=coopt&pid=$post[0]&fid=$tinfo[5]\">[+]</a>";
if($go==$post[0])
{
$fli = "<img src=\"../avatars/flag.gif\" alt=\"!\"/>";
}else{
$fli ="";
}
$dtot = date("H:i:s A d D m y",$post[3]);
echo "$usl $dtot<br/>$fli$pst";
echo "<br/><br/>$topt";
echo "<br/>";
}
echo "<p align=\"left\">";
if($page>1)
{
$ppage = $page-1;
echo "<a href=\"literature.php?page=$ppage&clid=$clid&tid=$tid\">&#171;-Prev</a> ";
}
if($page<$num_pages)
{
$npage = $page+1;
echo "<a href=\"literatjre.php?page=$npage&clid=$clid&tid=$tid\">Next-&#187;</a>";
}
if($num_pages>2)
{
$rets = "<form action=\"literature.php\" method=\"get\">";
$rets .= "<p align=\"left\">";
$rets .= "<input name=\"page\" style=\"-wap-input-format: '*N'\" size=\"2\"/>";
$rets .= "<input type=\"hidden\" name=\"action\" value=\"$action\"/>";
$rets .= "<input type=\"hidden\" name=\"sid\" value=\"$sid\"/>";
$rets .= "<input type=\"hidden\" name=\"tid\" value=\"$tid\"/>";
$rets .= "<input type=\"submit\" value=\"Go To Page\"/>";
$rets .= "</p>";
$rets .= "</form>";
echo $rets;
}
echo "<br/>Page - $page/$num_pages<br/>";
echo "<form action=\"litproc.php?action=comment&tid=$tid&clid=$clid\" method=\"post\">";
echo "<input name=\"reptxt\" maxlength=\"200\"/><br/>";
echo "<input type=\"hidden\" name=\"tid\" value=\"$tid\"/>";
echo "<input type=\"submit\" value=\"Add Comment\"/>";
echo "</form>";
echo "<p align=\"left\">";
$fid = $tinfo[5];
$fname = getlfname($fid);
$cid = mysql_fetch_array(mysql_query("SELECT cid FROM ibwff_literatures WHERE id='".$fid."'"));
$cinfo = mysql_fetch_array(mysql_query("SELECT name FROM ibwff_letcats WHERE id='".$fid."'"));
$cname = $cinfo[0];
$cid = mysql_fetch_array(mysql_query("SELECT cid FROM ibwff_literatures WHERE id='".$fid."'"));
$fname = htmlspecialchars($fname);
echo "<a href=\"literatures.php?action=Lite&sid=$sid\">Articles</a>&#187;<a href=\"literature.php?action=viewlitbox&fid=$fid\">$fname</a> &#187;$tinfo[0]";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
//////////////////////////////////View Article Updated :)
else if($action=="viewlitbox")
{
$fid = mysql_real_escape_string($_GET["fid"]);
$view = mysql_real_escape_string($_GET["view"]);
addonline(getuid_sid($sid),"Viewing Article Box","literature.php?action=$action");
$finfo = mysql_fetch_array(mysql_query("SELECT name from ibwff_literatures WHERE id='".$fid."'"));
$fnm = htmlspecialchars($finfo[0]);
echo "<head>";
echo "<title>View $finfo[0] Articles</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>View $finfo[0] Articles</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
echo "<form action=\"literature.php\" method=\"get\"><center>";
echo "View: <select name=\"view\">";
echo "<option value=\"all\">All</option>";
echo "<option value=\"new\">Since Last Visit</option>";
echo "<option value=\"myps\">I commented In</option>";
echo "</select>";
echo "<input type=\"submit\" value=\"Go\"/>";
echo "<input type=\"hidden\" name=\"action\" value=\"$action\"/>";
echo "<input type=\"hidden\" name=\"fid\" value=\"$fid\"/>";
echo "<input type=\"hidden\" name=\"sid\"  value=\"$sid\"/>";
echo "</form>";
echo "<br/>";
if($view=="new")
{
echo "Viewing literature that has no new comments since your last visit";
}else if($view=="myps")
{
echo "Viewing literature contain comments of you";
}else {
echo "Viewing All Article";
}
echo "<p align=\"left\">";
if($page=="" || $page<=0)$page=1;
if($page==1)
{
echo "&#187; <a href=\"literature.php?action=newlit&clid=$clid&fid=$fid\"><big>New Topic</big></a><br/>";
///////////pinned storys
$storys = mysql_query("SELECT id, name, closed, views, pollid FROM ibwff_storys WHERE fid='".$fid."' AND pinned='1' ORDER BY lastpost DESC, name, id LIMIT 0,5");
while($topic = mysql_fetch_array($storys))
{
$iml = "<img src=\"../avatars/normal.gif\" alt=\"*\"/>";
$iml = "*";
$tnm = htmlspecialchars($topic[1]);
$nop = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_storyposts WHERE tid='".$topic[0]."'"));
if(litval($topic[0]))
{
echo "<a href=\"literature.php?clid=$clid&tid=$topic[0]\">$iml$tnm($nop[0])</a><br/>";
}else{
$clid = $_GET["clid"];
		if (isclubmod((getuid_sid($sid)),$clid) || isownerclub((getuid_sid($sid)),$clid) || literatureboss($uid))
{
echo "&#8226; Article name: <b>$tnm</b><br/>";
echo "&#8226; <a href=\"literature.php?tid=$topic[0]&clid=$clid\"> Validate $tnm</a><br/>";
echo "&#8226; <a href=\"delete.php?action=art&tid=$topic[0]&clid=$clid\"> Delete $tnm</a><br/>";
}
echo "-------<br/>";
}
}
echo "<br/>";
}
$uid = getuid_sid($sid);
if($view=="new")
{
$ulv = mysql_fetch_array(mysql_query("SELECT lastvst FROM ibwff_users WHERE id='".$uid."'"));
$noi = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_storys WHERE fid='".$fid."' AND pinned='0' AND lastpost >='".$ulv[0]."'"));
}
else if($view=="myps")
{
$noi = mysql_fetch_array(mysql_query("SELECT COUNT(DISTINCT a.id) FROM ibwff_storys a INNER JOIN ibwff_storyposts b ON a.id = b.tid WHERE a.fid='".$fid."' AND a.pinned='0' AND b.uid='".$uid."'"));
}else{
$noi = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_storys WHERE fid='".$fid."' AND pinned='0'"));
}
$num_items = $noi[0]; //changable
$items_per_page= 10;
$num_pages = ceil($num_items/$items_per_page);
if($page>$num_pages)$page= $num_pages;
$limit_start = ($page-1)*$items_per_page;
if($limit_start<0)$limit_start=0;
if($view=="new")
{
$ulv = mysql_fetch_array(mysql_query("SELECT lastvst FROM ibwff_users WHERE id='".$uid."'"));
$storys = mysql_query("SELECT id, name, closed, views, moved, pollid FROM ibwff_storys WHERE fid='".$fid."' AND pinned='0' AND lastpost >='".$ulv[0]."' ORDER BY lastpost DESC, name, id LIMIT $limit_start, $items_per_page");
}
else if($view=="myps"){
$storys = mysql_query("SELECT a.id, a.name, a.closed, a.views, a.moved, a.pollid FROM ibwff_storys a INNER JOIN ibwff_storyposts b ON a.id = b.tid WHERE a.fid='".$fid."' AND a.pinned='0' AND b.uid='".$uid."' GROUP BY a.id ORDER BY a.lastpost DESC, a.name, a.id LIMIT $limit_start, $items_per_page");
}else{
$storys = mysql_query("SELECT id, name, closed, views, moved, pollid FROM ibwff_storys WHERE fid='".$fid."' AND pinned='0' ORDER BY lastpost DESC, name, id LIMIT $limit_start, $items_per_page");
}
while($topic = mysql_fetch_array($storys))
{
$nop = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_storyposts WHERE tid='".$topic[0]."'"));
$iml = "<img src=\"../avatars/normal.gif\" alt=\"*\"/>";
if($nop[0]>24)
{
$iml = "<img src=\"../avatars/hot.gif\" alt=\"*\"/>";
}
if($topic[4]=='1')
{
$iml = "<img src=\"../avatars/moved.gif\" alt=\"*\"/>";
}
if($topic[2]=='1')
{
$iml = "<img src=\"../avatars/closed.gif\" alt=\"*\"/>";
}
if($topic[5]>0)
{
$iml = "<img src=\"../avatars/poll.gif\" alt=\"*\"/>";
}
$atxt ="";
if($topic[2]=='1')
{
//closed
$atxt = "(X)";
}
$tnm = htmlspecialchars($topic[1]);
if(litval($topic[0]))
{
echo "<a href=\"literature.php?clid=$clid&tid=$topic[0]\">$iml$tnm($nop[0])$atxt</a><br/>";
}else{
$clid = $_GET["clid"];
		if (isclubmod((getuid_sid($sid)),$clid) || isownerclub((getuid_sid($sid)),$clid) || literatureboss($uid))
	{
	echo "&#8226; Article name: <b>$tnm</b><br/>";	
	    echo "&#8226; <a href=\"literature.php?tid=$topic[0]&clid=$clid\"> Validate $tnm</a><br/>";
	    echo "&#8226; <a href=\"delete.php?action=art&tid=$topic[0]&clid=$clid\"> Delete $tnm</a><br/>";	
}
echo "-------<br/>";
}
}
echo "</p>";
echo "<p align=\"center\">";
if($page>1)
{
$ppage = $page-1;
echo "<a href=\"literature.php?action=viewlitbox&page=$ppage&clid=$clid&fid=$fid&view=$view\">&#171;-Prev</a> ";
}
if($page<$num_pages)
{
$npage = $page+1;
echo "<a href=\"literature.php?action=viewlitbox&page=$npage&clid=$clid&fid=$fid&view=$view\">Next&#8594;</a>";
}
if($num_pages>2)
{
$rets = "<form action=\"literature.php\" method=\"get\">";
$rets .= "<input name=\"page\" style=\"-wap-input-format: '*N'\" size=\"2\"/>";
$rets .= "<input type=\"hidden\" name=\"action\" value=\"$action\"/>";
$rets .= "<input type=\"hidden\" name=\"sid\" value=\"$sid\"/>";
$rets .= "<input type=\"hidden\" name=\"fid\" value=\"$fid\"/>";
$rets .= "<input type=\"hidden\" name=\"view\" value=\"$view\"/>";
$rets .= "<input type=\"submit\" value=\"Go To Page\"/>";
$rets .= "</form>";
echo $rets;
}
echo "<p align=\"left\">";
echo "<br/><br/>&#187; <a href=\"literature.php?action=newlit&clid=$clid&fid=$fid\"><big>New Topic</big></a>";
echo "<br/>Page - $page/$num_pages<br/>";
echo "</p>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
//////////////////////////////////New Topic
else if($action=="newlit")
{
$fid = mysql_real_escape_string($_GET["fid"]);
addonline(getuid_sid($sid),"Creating A New Article","literature.php?action=$action");
echo "<head>";
$uday = littyp_fid($fid);
echo "<title>Create A New  $uday</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";					echo "<div class=\"header\" align=\"center\">";
echo "<b>Create A New $uday</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include ("pm_by.php");
echo "<form action=\"litproc.php?action=newlitt&clid=$clid&who=$uid\" method=\"post\">";
echo "<p align=\"left\">";
echo "<big><b>$uday Title:</b></big><br/><input name=\"ntitle\" maxlength=\"250\"/><br/>";
echo "<big><b>$uday Text:</b></big><br/><input name=\"tpctxt\" maxlength=\"10000\"/><br/>";
echo "<big><b>$uday Tags:</b></big><br/><input name=\"udaytag\" maxlength=\"1000\"/><br/>";
echo "<input type=\"hidden\" name=\"fid\" value=\"$fid\"/>";
echo "<input type=\"submit\" value=\"Create\"/>";
echo "</form>";
echo "<br/><a href=\"literature.php?action=viewlitbox&fid=$fid\">";
$fname = getlfname($fid);
echo "<b>$fname</b></a>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
//////////////////////////////////////////Post reply
else if($action=="comment")
{
$tid = mysql_real_escape_string($_GET["tid"]);
$tfid = mysql_fetch_array(mysql_query("SELECT fid FROM ibwff_storys WHERE id='".$tid."'"));
$fid = $tfid[0];
addonline(getuid_sid($sid),"Posting Comment","forums.php?action=$action");
$tinfo = mysql_fetch_array(mysql_query("SELECT name from ibwff_storys WHERE id='".$tid."'"));
echo "<head>";
echo "<title>Post A Comment</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Post Comment</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<onevent type=\"onenterforward\">";
echo "<refresh>
<setvar name=\"reptxt\" value=\"\"/>
";
echo "</refresh></onevent>";
echo "<b>Post Commen:</b> <br/><form action=\"litproc.php?action=comment&clid=$clid\" method=\"post\">";
echo "<input name=\"reptxt\" maxlength=\"10000\"/><br/>";
echo "<input type=\"hidden\" name=\"tid\" value=\"$tid\"/>";
echo "<input type=\"submit\" value=\"Comment\"/>";
echo "</form>";
echo "<br/><br/>";
echo "<img src=\"../avatars/prev.gif\"><a href=\"literature.php?page=$page&clid=$clid&tid=$tid\">Back to $tinfo[0] Topic</a>";
echo "<br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
/////////////////////Article Options :)
else if($action=="litopt"){
$tid = $_GET["tid"];
addonline(getuid_sid($sid),"Viewing Article Options","literature.php?action=$action");
$tinfo= mysql_fetch_array(mysql_query("SELECT name, fid, authorid, text FROM ibwff_storys WHERE id='".$tid."'"));
$tname = $tinfo[0];
$uday = littyp_tid($tid);
$trid = $tinfo[2];
$ttext = htmlspecialchars($tinfo[3]);
$tname = htmlspecialchars($tinfo[0]);
echo "<head>";
echo "<title>View $uday Option</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>$uday Options</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<onevent type=\"onenterforward\">";
echo "<refresh>
<setvar name=\"ttext\" value=\"$ttext\"/>
<setvar name=\"tname\" value=\"$tname\"/>";
echo "</refresh></onevent>";
echo "$uday ID: <b>$tid</b><br/>";
$trnick = subnick(getnick_uid($trid));
echo "<img src=\"../images/next.gif\" alt=\">\"><a href=\"profile.php?action=viewuser&who=$trid&sid=$sid\">View $trnick's Profile</a><br/>";
echo "<img src=\"../images/next.gif\" alt=\">\"><a href=\"modproc.php?action=dels&clid=$clid&who=$who&tid=$tid\">Delete</a><br/>";
echo "<img src=\"../images/next.gif\" alt=\">\"><a href=\"litproc.php?action=rlit&clid=$clid&tid=$tid\">Report This $uday</a><br/>";
echo "&#171;<a href=\"literature.php?clid=$clid&tid=$tid\">Back To $uday!</a><br/>";
$tfid = mysql_fetch_array(mysql_query("SELECT fid FROM ibwff_storys WHERE id='".$tid."'"));
$cfrm = mysql_fetch_array(mysql_query("SELECT clubid FROM ibwff_literatures WHERE id='".$tfid[0]."'"));
if ($clid>0)
{
$cname = getclubname($clid);
echo "Club Name: <b>$cname</b><br/>";
}
if (isclubmod((getuid_sid($sid)),$clid) || isownerclub((getuid_sid($sid)),$clid) || literatureboss($uid) || $tinfo[2]==getuid_sid($sid))
{
echo "<form action=\"edit.php?action=renlit&clid=$clid&who=$who&tid=$tid\" method=\"post\">";
echo "<b>$uday Title:</b> <input name=\"tname\" value=\"$tname\" maxlength=\"300\"/>";
echo "<input type=\"submit\" value=\"Rename\"/>";
echo "</form>";
echo "<form action=\"edit.php?action=article&clid=$clid&who=$who&tid=$tid\" method=\"post\">";
echo "<b>$uday Text:</b> <input name=\"ttext\" value=\"$ttext\" maxlength=\"10000\"/>";
echo "<input type=\"submit\" value=\"Edit\"/>";
echo "</form>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
//////////////////////////////////////////Comment Options :)
else if($action=="coopt")
{
$pid = $_GET["pid"];
$fid = $_GET["fid"];
addonline(getuid_sid($sid),"Viewing Article Comment Options","literature.php?action=$action");
$pinfo= mysql_fetch_array(mysql_query("SELECT uid, tid, text  FROM ibwff_storyposts WHERE id='".$pid."'"));
$trid = $pinfo[0];
$tid = $pinfo[1];
$ptext = htmlspecialchars($pinfo[2]);
$trnick = subnick(getnick_uid($trid));
echo "<head>";
echo "<title>View $trnick Article Comment Options</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>$trnick Topics Post Option</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<onevent type=\"onenterforward\">";
echo "<refresh>
<setvar name=\"ptext\" value=\"$ptext\"/>";
echo "</refresh></onevent>";
echo "Article Comment ID: <b>$pid</b><br/>";
echo "<img src=\"../images/next.gif\" alt=\">\"><a href=\"profile.php?who=$trid\">View $trnick's Profile</a><br/>";
echo "<img src=\"../images/next.gif\" alt=\">\"><a href=\"litproc.php?action=rcom&pid=$pid\">Report $trnick Comment</a><br/>";
echo "<img src=\"../images/next.gif\" alt=\">\"><a href=\"delete.php?action=artcom&pid=$pid\">Delete This Comment</a><br/>";
echo "<a href=\"literature.php?tid=$tid&page=$page\">&#171;Back to $uday! </a><br/>";
if (isclubmod((getuid_sid($sid)),$clid) || isownerclub((getuid_sid($sid)),$clid) || literatureboss($uid) || $trid==getuid_sid($sid))
{
echo "<form action=\"edit.php?action=artcom&pid=$pid\" method=\"post\">";
echo "<b>$trnick Comment:</b> <input name=\"ptext\" value=\"$ptext\" maxlength=\"10000\"/>";
echo "<input type=\"submit\" value=\"Edit\"/>";
echo "</form>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
}
else if($action=="10story")
{
echo "<head>";
echo "<title>Last 10 Story</title>";
echo "</head>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Last 10 Story</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$sql = "SELECT id, name, authorid
FROM ibwff_storys WHERE type='Story' 
ORDER BY id DESC
LIMIT 0 , 10";
$items = mysql_query($sql);
while ($item = mysql_fetch_array($items))
{
$sql2 = "SELECT name FROM ibwff_users WHERE id=$item[2]";
$sql22 = mysql_query($sql2);
$item2 = mysql_fetch_array($sql22);
{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item2[0]'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/>";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/>";}
if($sex[0]==""){$usersex = "";}
$avlink = getavatar($item[2]);
if($avlink=="")
{
$avt =  "$usersex";
}else{
$avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"icon\" width=\"23\" height=\"18\"/>";
}
$a = htmlspecialchars($item[1]);
$b = subnick(getnick_uid($item[2]));
$sql3 = "SELECT name FROM ibwff_users WHERE id=$item[2]";
$sql33 = mysql_query($sql3);
$item3 = mysql_fetch_array($sql33);
{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nicks = "<font color=\"blue\"><b>$b</b></font>";}
if($sex[0]=="F"){$nicks = "<font color=\"deeppink\"><b>$b</b></font>";}
if($sex[0]==""){$nicks = "";}
$c = "<a href=\"literature.php?action=viewlit&clid=$clid&tid=$item[0]&go=last&sid=$sid\">$a</a></b> ";
$d = "<a href=\"profile.php?who=$item[2]\"> $avt$nicks</a></b> ";
}
echo "<img src=\"../images/literature.png\">$c By <b>$d</b><br/>";
}
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="10poem")
{
addonline(getuid_sid($sid),"Viewing Last 10 Poem","literature.php?action=$action");
echo "<head>";
echo "<title>Last 10 Poem</title>";
echo "</head>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Last 10 Poem</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$sql = "SELECT name, authorid, id
FROM ibwff_storys WHERE type='Poem' 
ORDER BY id DESC
LIMIT 0 , 10";
$items = mysql_query($sql);
while ($item = mysql_fetch_array($items))
{
$sql2 = "SELECT name FROM ibwff_users WHERE id=$item[1]";
$sql22 = mysql_query($sql2);
$item2 = mysql_fetch_array($sql22);
{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item2[0]'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/>";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/>";}
if($sex[0]==""){$usersex = "";}
$avlink = getavatar($item[1]);
if($avlink=="")
{
$avt =  "$usersex";
}else{
$avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"icon\" width=\"23\" height=\"18\"/>";
}
$xT = htmlspecialchars($item[0]);
$b = subnick(getnick_uid($item[1]));
$sql3 = "SELECT name FROM ibwff_users WHERE id=$item[1]";
$sql33 = mysql_query($sql3);
$item3 = mysql_fetch_array($sql33);
{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nick = "<font color=\"blue\"><b>$b</b></font>";}
if($sex[0]=="F"){$nick = "<font color=\"deeppink\"><b>$b</b></font>";}
if($sex[0]==""){$nick = "";}
$c = "<a href=\"literature.php?clid=$clid&tid=$item[2]&amp;go=last\">$item[0]</a>";
$d = "<a href=\"profile.php?who=$item[1]\">$avt$nick</a>";
}
echo "<img src=\"../images/literature.png\">$c By <b>$d</b><br/>";
}
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="10joke")
{
addonline(getuid_sid($sid),"Viewing Last 10 Joke","literature.php?action=$action");
echo "<head>";
echo "<title>Last 10 Joke</title>";
echo "</head>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Last 10 Joke</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$sql = "SELECT name, authorid, id
FROM ibwff_storys WHERE type='Joke' 
ORDER BY id DESC
LIMIT 0 , 10";
$items = mysql_query($sql);
while ($item = mysql_fetch_array($items))
{
$sql2 = "SELECT name FROM ibwff_users WHERE id=$item[1]";
$sql22 = mysql_query($sql2);
$item2 = mysql_fetch_array($sql22);
{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item2[0]'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/>";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/>";}
if($sex[0]==""){$usersex = "";}
$avlink = getavatar($item[1]);
if($avlink=="")
{
$avt =  "$usersex";
}else{
$avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"icon\" width=\"23\" height=\"18\"/>";
}
$xT = htmlspecialchars($item[0]);
$b = subnick(getnick_uid($item[1]));
$sql3 = "SELECT name FROM ibwff_users WHERE id=$item[1]";
$sql33 = mysql_query($sql3);
$item3 = mysql_fetch_array($sql33);
{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nick = "<font color=\"blue\"><b>$b</b></font>";}
if($sex[0]=="F"){$nick = "<font color=\"deeppink\"><b>$b</b></font>";}
if($sex[0]==""){$nick = "";}
$c = "<a href=\"literature.php?clid=$clid&tid=$item[2]&go=last\">$item[0]</a>";
$d = "<a href=\"profile.php?who=$item[1]\">$avt$nick</a>";
}
echo "<img src=\"../images/literature.png\">$c By <b>$d</b><br/>";
}
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="raters")
{
$tid = $_GET["tid"];
$t = mysql_fetch_array(mysql_query("SELECT name FROM ibwff_storys WHERE id='".$tid."'"));
$uday = littyp_fid($fid);
$tname = htmlspecialchars($t[0]);
echo "<head>";
echo "<title>$tname Rater</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<b>Viewing $tname Raters</b></div>";
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$c = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM uday_litrate WHERE tid='".$tid."'"));
if($c[0]<=0)
{
echo "<br/><img src=\"../images/notok.gif\" alt=\"x\">No $uday Raters Found!";
}else{
$sql = "SELECT uid FROM uday_litrate WHERE tid='".$tid."'";
$rate = mysql_query($sql);
while($rater = mysql_fetch_array($rate))
{
$unick = subnick(getnick_uid($rater[0]));
$sql2 = "SELECT name FROM ibwff_users WHERE id=$rater[0]";
$sql22 = mysql_query($sql2);
$item2 = mysql_fetch_array($sql22);
{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item2[0]'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/>";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/>";}
if($sex[0]==""){$usersex = "";}
if(isonline($rater[0]))
{
$iml = "<font color=\"green\">online!</font>";
}else{
$iml = "<font color=\"red\">offline!</font>";
}
$avlink = getavatar($rater[0]);
if($avlink=="")
{
$avt =  "$usersex";
}else{
$avt = "<img src=\"$avlink\" alt=\"$avlink\" type=\"icon\" width=\"23\" height=\"18\"/>";
}
$sql3 = "SELECT name FROM ibwff_users WHERE id=$rater[0]";
$sql33 = mysql_query($sql3);
$item3 = mysql_fetch_array($sql33);
{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nick = "<font color=\"blue\"><b>$unick</b></font>";}
if($sex[0]=="F"){$nick = "<font color=\"deeppink\"><b>$unick</b></font>";}
if($sex[0]==""){$nick = "";}
$a = mysql_fetch_array(mysql_query("SELECT rate, time FROM uday_litrate WHERE uid='".$rater[0]."' AND tid='".$tid."'"));
$bdt = $a[1] + (6*60*60);
$time = date("h:i A, D d M y",$bdt);
$ra = "<b>Rates: ($a[0]/5)</b>";
$usl = "<br/>$avt<a href=\"profile.php?who=$rater[0]\">$nick</a> $iml &#187; $time<br/>$ra";
}
}
echo "$usl<br/>";
}
}
echo "<br/><br/>";
echo "<img src=\"../images/prev.gif\" alt=\"<\"><a href=\"literature.php?clid=$clid&tid=$tid\"><b>Back To $tname $uday</b></a><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
?>
</html>