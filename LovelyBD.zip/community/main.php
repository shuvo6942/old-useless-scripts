<?php
session_start();
include("config.php");
include("core.php");  connectdb();
    echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"".bosshira_themes()."\">";
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo '<head>';
/*FireBD is an organization which is developed & 100% secured by *Mehedi*
*/
echo "<meta name=\"google-site-verification\" content=\"9BYeG2VfinXzhkbXjs_ivQR0ow6NY1fM7llH3fEjNcQ\" />
<meta name=\"msvalidate.01\" content=\"878C96B4CA35257BB06B7C14D282A048\" />
<meta name=\"author\" content=\"Fire's browser\" />
<meta name=\"title\" content=\"MyDhaka.Tk\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From Mehedi: Don't Try To Hack OR else :P\">
<meta name=\"keywords\" content=\"Site Desined By Mehedi:)\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"main,all,follow\"/></head>";
echo "<body>";
$bcon = connectdb();
if (!$bcon)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"Styles.css\">";  
echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/><b>Site Is Under Construction!</b><br/><br/>";
  echo "If you have faced any problem, or need a site, please <a href=\"contact.php\">contact admin</a><br/><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php?action=main&sid=$sid\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
  echo "&#169; <img src=\"favicon.ico\" type=\"icon\" alt=\"[ ]\" width=\"15\" height=\"17\"><normal><a href=\"main.php\"><b>MyDhaka.Tk</b></a>";
$end = microtime(true);
$time = number_format(($end - $start), 2);
  echo " (".$time."s)</normal>";
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
$who = $_GET["who"];
$page = $_GET["page"];
$sid = $_SESSION["sid"];
$action = $_GET["action"];
$uid = getuid_sid($sid);
$whonick = getnick_uid($who);
$accountno = getuid_sid($sid);

cleardata();

$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
$banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwf_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
$remain =  $banto[0] - time();
$rmsg = gettimemsg($remain);
echo "<b>Time Remaining: $rmsg</b><br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "</p>";
echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
echo "&#169; <img src=\"superbonhu.ico\" type=\"icon\" alt=\"[ ]\" width=\"15\" height=\"17\"><normal><a href=\"main.php\"><b>$sitename</b></a>";
echo " (<b>Classic</b> | <a href=\"../desktop/main.php\">Desktop</a> | <a href=\"../Mobile/main.php\">Mobile</a>)</normal>";
echo "</div>";
echo "</body>";
      exit();
      }
    }
if(($action != ""))
{
$uid = getuid_sid($sid);
if((islogged($sid)==false)||($uid==0))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
}
//////////////////Banned System Updated By CJ Uday :)
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
  echo "</div>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please Contact <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
///////////////////Deactivated Account Created CJ UdaY :)
          if(isdeactivated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  <b>Your Account Has Been Deactivated Forever.<br/>And It Will Be Never Activated!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
  }
////////////////////////////////////////MAIN Index CREADTED BY CJ Uday :)
if((islogged($sid)==true))
{
$whnick = subnick(getnick_uid($uid));
addvisitor();
addonline(getuid_sid($sid),"Online Community (Menu)","main.php");
    echo "<head>";
    echo "<title>$whnick@Online Community (Menu)</title>";
    echo "</head>";
    echo "<body>";
    echo "<div class=\"header\" align=\"center\"><img src=\"FireBD.png\" alt=\"[MyDhaka.Tk]\" type=\"logo\" width=\"240\" height=\"80\"/><br/>";
date_default_timezone_set('UTC');
$gerNew_Time = time()+(6* 60 * 60);
$gertime=date("h:i:s a,",$gerNew_Time);
echo "<small>$gertime</small>";
echo "<small>".date("D d M y  ")."</small>\n";
echo "<small><a href=\"time.php?sid=$sid\">".date("")."</a></small>";
echo "</div>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
			
echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
$nick = getnick_sid($sid);
$sql= mysql_fetch_array(mysql_query("SELECT lastview,ltime FROM ibwff_lastview WHERE whonick='".$nick."'ORDER BY ltime DESC LIMIT 1"));
$ltmx=time()-$sql[1];
if($ltmx<180) {
$a = getuid_nick($sql[0]);
echo "<b>Currently <a href=\"profile.php?who=$a\">$sql[0]</a> is checking out your profile!</b><br/>";
$shdt = date("H:i", $sql[1]);
$stime = $sql['ltime'];
$tremain = time()-$stime;
$tmdt = gettimemsg($tremain);
//echo "$tmdt ago!<br/>";
echo "<br/>";
} else {}
echo "<hr>";
////////////////////////SECURITY OPTION BY CJ UdAY ;)
  $src_security = mysql_fetch_array(mysql_query("SELECT COUNT (*) FROM ibwff_usersecurity WHERE uid='".$uid."'"));
  $src_view = mysql_fetch_array(mysql_query("SELECT view FROM ibwff_usersecurity WHERE uid='".$uid."'"));
  include ("user_sec.php"); 
 if ($src_complete<100 && $src_view[0]<1)
  {
  echo "<p align=\"left\">&#187; <a href=\"usersecurity.php\"><b>Your Security level is $src_complete%</b>
  <br/>Please Lock Your Account!</a></p>";
  if ($src_complete>70)
  {
  mysql_query("UPDATE ibwff_usersecurity SET view='1' WHERE uid='".$uid."'");
  }
  }
 if ($src_view[0]==1)
  {
  echo "<p align=\"left\">&#187; <a href=\"usersecurity.php\"><b>Your Security level is $src_complete%</b>
  <br/>Your account now secured!</a></p>";
    mysql_query("UPDATE ibwff_usersecurity SET view='2' WHERE uid='".$uid."'");
  }
    if ($src_complete<80)
  {
  mysql_query("UPDATE ibwff_usersecurity SET view='0' WHERE uid='".$uid."'");
  }
  ///////////////////// SECURITY OPTION BY CJ UdAY ;) 

//echo "<center><a href=\"http://facebook.com/Mydhaka.tk\"><img src=\"../smilies/fb.gif\" alt=\"-fb-\"/><font color=\"purple\"><b>Like Our Fanpage</b></a></font> <b>and Get <font color=\"red\">100 Points!<img src=\"../smilies/up.gif\" alt=\"-up-\"/></font></b></center>";
		        echo "<div class=\"div\" align=\"center\"><b>Announcements</b></div><br/>";
echo "<div class=\"di\" align=\"center\">";
$fmsg = getbbcode(getfmsg(), $sid, 0);
  echo $fmsg."<br/>";
echo "</div>";
   $ntbd = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='ntitle'"));
  //echo "<center><img src=\"../avatars/ok.gif\" alt=\"-\"/><a href=\"announcements.php?action=notice\"><font color=\"#b22222\"><b>Notice Board</b></a></font> [$ntbd[0]]</center>";
  $cntbx  = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='cntitle'"));
//echo "<center><img src=\"../avatars/ok.gif\" alt=\"-\"/><a href=\"announcements.php?action=contest\"><font color=\"green\"><b>Contest</b></a></font> [$cntbx[0]]</center>";
$lnk  = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='lnktitle'"));
//echo "<center><img src=\"../avatars/ok.gif\" alt=\"-\"/><a href=\"announcements.php?action=linkads\"><font color=\"blue\"><b>Offer Box</b></a></font> [$lnk[0]]<br/><img src=\"../avatars/ok.gif\" alt=\"-\"/><a href=\"forums.php?clid=$clid&tid=139\"><font color=\"orange\"><b>Complain Box</b></font></a> [Complain Here]<br/><br/><img src=\"../smilies/-line-.gif\" alt=\"line\"><img src=\"../smilies/-line-.gif\" alt=\"line\"></center>";
                echo "<br/>";
		        echo "<div class=\"div\" align=\"center\"><b>Shoutbox</b></div>";
				echo "<div class=\"shout\" align=\"left\">";
$tr = time();
echo getshoutbox($sid);
echo "</div><div class=\"shout\" align=\"left\">";
echo getshoutbox3($sid);
echo "</div>";
echo "<center><a href=\"shouts.php?action=shouts&clid=$clid\">[More]</a></center>";
  if(getplusses(getuid_sid($sid))<50)
    {
	    $remp = 50 - getplusses($uid);
        echo "<center>You Need $remp Points To Add A Shout! 
		[<a href=\"forums.php?clid=$clid&tid=2\">How To Get Points??</a>]</center>";
    }else{
  echo "<center><form action=\"shoutproc.php?action=shout&clid=$clid\" method=\"post\">";
  echo "Shoutbox Message:<br/><textarea name=\"shtxt\" maxlength=\"250\"/></textarea>";
  echo "<br/><img src=\"../images/activity.jpg\" alt=\"\"><a href=\"activity.php\"><font color=\"grey\"><b>Activity</b></font></a> <input type=\"Submit\" name=\"shout\" Value=\"Add Shout\"> <img src=\"../images/attach.png\" alt=\"\"><a href=\"attach.php\"><font color=\"grey\"><b>Attach</b></font></a></form></center>";
  }

      echo "<div class=\"div\" align=\"center\"><b>Online Community (Menu)</b></div>";
				echo "<div class=\"block\" align=\"left\">";
///////////////////////////////Premium By UdAY :)
echo "<b>&#187; <a href=\"premium.php\">Buy Premium Membership</a></b><hr>";
//////////////////////////////Friends, Relatives By UdAY :)
$reqs = getnreqs($uid);
if($reqs>0)
{
$request = "! <a href=\"friends.php?action=reqs&who=$sid\">$reqs Requests Pending</a>";
}
$uid = getuid_sid($sid);
$mybuds = getnbuds($uid);
$onbuds = getonbuds($uid);
$rltv = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwf_relatives WHERE tid='".$uid."' AND agreed=0"));
if($rltv[0]>0)
{
$request = "! <a href=\"Relatives.php?action=reqs&who=$sid\">$rltv[0] Requests Pending</a>";
}
$onrel = getonrels($uid);
$myrel = getnrels($uid);
echo "&#187; <a href=\"Relatives.php?who=uid\">Relatives</a> [$onrel/$myrel] $request<hr>"; 
echo "&#187; <a href=\"friends.php?action=buds&who=$uid\">Friends</a> [$onbuds/$mybuds] $request<hr>";
////////Forums By CJ UdaY :)
$topics = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_topics"));
$posts = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_posts"));
echo "&#187; <a href=\"forums.php?action=forums\">Forums</a> [$topics[0]/$posts[0]]<hr>";
////////////////Literature By CJ UdaY :)
$topics = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_storys"));
$topics2 = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_storyposts"));
echo "&#187; <a href=\"literature.php?action=Lite\">Literature</a> [$topics[0]/$topics2[0]]<hr>";
//////////////Blogs By CJ UdaY :)
$noi = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_blogs"));
$nou = mysql_fetch_array(mysql_query("SELECT COUNT(DISTINCT bowner) FROM ibwff_blogs"));
$noi = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_blogs"));
echo "&#187; <a href=\"blogs.php?action=allbl\">Blogs</a> [$nou[0]/$noi[0]]<hr>";
//////////Polls By CJ UdaY :)
$noi = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_polls"));
echo "&#187; <a href=\"polls.php?action=polls\">Polls</a> [$noi[0]]<hr>";
/////////////Clubs By CJ UdaY :)
$chss = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_clubs"));
 echo "&#187; <a href=\"clubs.php?action=clmenu\">Clubs</a> [$chss[0]]<hr>";
//////////////////Golden Coin By CJ UdaY :)
$p = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_online WHERE place='Playing Golden Coin'"));
echo "<b>&#187;</b> <a href=\"gcoin.php\">Golden Coin</a> [$p[0]]<hr>";
///////////////////////Search, Golden Lotto, Golden Coin, Grab A Free Item By CJ UdaY :)
//echo "<b>&#187;</b> <a href=\"glotto.php\">Golden Lotto</a> <hr>";
$p = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_online WHERE place='Playing Grab A Free Item'"));
//echo "<b>&#187;</b> <a href=\"gfi.php\"><b>Grab A Free Item</b></a> [$p[0]]<hr>";
//echo "<b>&#187;</b> <a href=\"crct.php\"><b>Cricket</b></a><hr>";
echo "&#187; <a href=\"announcements.php?action=ins\">MyDhaka Instructions</a> <hr/>";
echo "&#187; <a href=\"search.php\">Search</a><hr/>";
///////////////////////By CJ UdaY :)
echo "&#187; <a href=\"more.php\">Extra Menu</a> [More Menu] </div>";
///////////////////////By CJ UdaY :)
      echo "<div class=\"div\" align=\"left\"><b>Last Forum Topic</b></div>";
		echo "<p align=\"left\">";
include("lasttpc.php");
        echo "<div class=\"div\" align=\"left\"><b>Last Forum Post</b></div>";
		echo "<p align=\"left\">";
include("lastpost.php");
        echo "<div class=\"div\" align=\"left\"><b>Last Literature</b></div>";
		echo "<p align=\"left\">";
include("lastlite.php");
        echo "<div class=\"div\" align=\"left\"><b>Last Blog</b></div>";
		echo "<p align=\"left\">";
include("lastblog.php");
echo "</p>";
        echo "<div class=\"div\" align=\"left\"><b>Last Poll</b></div>";
		echo "<p align=\"left\">";
include("lastpoll.php");
echo "</p>";
echo "<p align=\"right\">";
echo "<div class=\"div\" align=\"center\"><b>Online Lists</b></div>";
echo "<div class=\"block\" align=\"right\">";
echo "Members Online: [<a href=\"online.php?action=online\">".getnumonline()."</a>]<hr>";
$timeout = 3600;
$timeon = time()-$timeout;
$bangladesh = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE country='Bangladesh' AND lastact>'".$timeon."'"));
$bangladesh[0] = $bangladesh[0];
echo "From Bangladesh: [<a href=\"online.php?action=bangladesh\">$bangladesh[0]</a>]<hr>";
$timeout = (time() - $timeadjust)  - 300;
$male = mysql_fetch_array(mysql_query("SELECT count(a.userid) FROM ibwff_online a,ibwff_users b where a.userid=b.id and b.sex='M'"));
$male[0] = $male[0];
$female = mysql_fetch_array(mysql_query("SELECT count(a.userid) FROM ibwff_online a,ibwff_users b where a.userid=b.id and b.sex='F'"));
$female[0] = $female[0];
echo "Male/Female: [<a href=\"online.php?action=monline\">$male[0]</a>/<a href=\"online.php?action=fonline\">$female[0]</a>]<hr>";
$timeout = 3600;
$timeon = time()-$timeout;
$noi = mysql_fetch_array(mysql_query("SELECT count(*) FROM ibwff_users WHERE pu>'0' AND lastact>'".$timeon."'"));
$pu = $noi[0];
$timeout = 3600;
$timeon = time()-$timeout;
$top = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE  plusses>'".knightpoint()."' AND lastact>'".$timeon."'"));
$top = $top[0];
echo "Premium/Top:[<a href=\"online.php?action=puol\">".$pu."</a>/<a href=\"online.php?action=toponl\">".$top."</a>]<hr>";
$timeout = 3600;
$timeon = time()-$timeout;
$noi = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE cyberpowereragon>'0' AND lastact>'".$timeon."'"));
$staff = $noi[0]-1;
$timeout = 3600;
$timeon = time()-$timeout;
$noi = mysql_fetch_array(mysql_query("SELECT count(*) FROM ibwff_users WHERE vip>'0' AND lastact>'".$timeon."'"));
$vip = $noi[0];
echo "Staff/Vip: [<a href=\"online.php?action=stfol\">".$staff."</a>/<a href=\"online.php?action=vipol\">".$vip."</a>]<hr>";
$timeout = 3600;
$memberpoint = memberpoint();
$junmemberpoint = junmemberpoint();
$senmemberpoint = senmemberpoint();
$timeon = time()-$timeout;
$noi = mysql_fetch_array(mysql_query("SELECT count(*) FROM ibwff_users WHERE totaltime>'".$junmemberpoint."' AND totaltime<'".$senmemberpoint."' AND lastact>'".$timeon."'"));
$jumem = $noi[0];
$noi2 = mysql_fetch_array(mysql_query("SELECT count(*) FROM ibwff_users WHERE totaltime>'".$senmemberpoint."' AND cyberpowereragon='0' AND id!='3' AND vip='0' AND lastact>'".$timeon."'"));
$semem = $noi2[0];
echo "Junior/Senior:[<a href=\"online.php?action=jumem\">".$jumem."</a>/<a href=\"on.php?action=semem\">".$semem."</a>]<hr>";
$memid = mysql_fetch_array(mysql_query("SELECT id, name  FROM ibwff_users ORDER BY regdate DESC LIMIT 0,1"));
$noi2 = mysql_fetch_array(mysql_query("SELECT count(*) FROM ibwff_users WHERE cyberpowereragon>'0'"));
$tm24 = time() - (24*60*60);
$aut = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE lastact>'".$tm24."'"));
$mem = $aut[0];
$norm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users"));
echo "Regular User: [<a href=\"online.php?action=actmem\">".$mem."</a>/<a href=\"memlist.php?action=members\">$norm[0]</a>]<hr>";
$memid = mysql_fetch_array(mysql_query("SELECT id, name  FROM ibwff_users WHERE validated>'0' ORDER BY regdate DESC LIMIT 0,1"));
    {
	    $sql = "SELECT name FROM ibwff_users WHERE id=$memid[0]";
	    $sql2 = mysql_query($sql);
	    $item = mysql_fetch_array($sql2);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item[0]'"));
if($sex[0]=="M"){$usersex = "<img src=\"../avatars/male.gif\" alt=\"M\"/>";}
if($sex[0]=="F"){$usersex = "<img src=\"../avatars/female.gif\" alt=\"F\"/>";}
if($sex[0]==""){$usersex = "";}
        		$avlink = getavatar($memid[0]);
if($avlink=="")
{
 $avt =  "$usersex";
}else{
 $avt = "<img src=\"$avlink\" type=\"icon\" width=\"18\" hieght=\"23\"/>";
}
	    $sql3 = "SELECT name FROM ibwff_users WHERE id=$memid[0]";
	    $sql33 = mysql_query($sql3);
	    $item3 = mysql_fetch_array($sql33);
		{
$sex = mysql_fetch_array(mysql_query("SELECT sex FROM ibwff_users WHERE name='$item3[0]'"));
if($sex[0]=="M"){$nicks = "<font color=\"blue\"><b>$memid[1]</b></font>";}
if($sex[0]=="F"){$nicks = "<font color=\"deeppink\"><b>$memid[1]</b></font>";}
mysql_query("UPDATE ibwff_users SET sex='M' WHERE sex=''");
if($sex[0]==""){$nicks = "$memid[1]";}
echo "Newest: [<a href=\"profile.php?who=$memid[0]\"><u>$avt$nicks</u></a>]<a href=\"memlist.php?action=new\">[+]</a></div>";
}}}
        echo "<div class=\"div\" align=\"center\"><b>&#171;<a href=\"logout.php?action=logout&who=$uid\">Log Out</a></b></div>";
//echo "<center><b><font color=\"purple\">Facebook Share :</font></b> <a href='http://m.facebook.com/sharer.php?u=http%3A%2F%2Ffirebd.net%2F&amp;t=FireBD.NeT+-+A+Different+World%2C+For+Friendship%21&amp;src=sp'><img src=\"../smilies/fshare.jpg\" alt=\"-fb-\"/></a></center>";
		echo "</div>";	
if(isowner(getuid_sid($sid)))
{
		        echo "<div class=\"div\" align=\"center\"><b>Site Tools</b></div>";
				echo "<div class=\"block1\" align=\"center\">";
echo "<a href=\"modcp.php\">Admin Tools</a><hr>";
$nx = vld_uday();
echo "<a href=\"validatecp.php\">Validate List($nx)</a><hr>";
}
if(isheadadmin(getuid_sid($sid)))
{
		        echo "<div class=\"div\" align=\"center\"><b>Site Tools</b></div>";
				echo "<div class=\"block1\" align=\"center\">";
echo "<a href=\"modcp.php\">Head Moderator Tools</a><hr>";
$nx = vld_uday();
echo "<a href=\"validatecp.php\">Validate List($nx)</a><hr>";
}
if(ismod($uid))
{
if(!isowner(getuid_sid($sid)))
{
if(!isheadadmin(getuid_sid($sid)))
{
		        echo "<div class=\"div\" align=\"center\"><b>Site Tools</b></div>";
				echo "<div class=\"block1\" align=\"center\">";
echo "<a href=\"modcp.php\">Moderator Tools</a><hr>";
}
}
}
if(ismod($uid))
{
$evnt = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_events WHERE clubid=0"));
echo "<a href=\"events.php\">Recent Events ($evnt[0])</a><hr>";
$evt = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_mlog"));
echo "<a href=\"stafflogs.php\">Reports And Logs($evt[0])</a><br/>";
}
echo "</div>";		
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
exit();
}else{
/////////////////////////Main Page Here Updated BY Megh  :)
addvisitor();
    echo "<head>";
    echo "<title>MyDhaka.Tk Online Community</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"\" align=\"center\">";
	echo "<div class=\"header\">";
echo "<img src=\"FireBD.png\" alt=\"[$sitename]\" type=\"logo\" width=\"240\" height=\"80\"/>";
echo "</div>";
echo "<div class=\"penanda\" align=\"center\">";
echo "<center>MyDhaka Online Community<br/>A New Generation Wap Community";
echo "<br/><br/><b>Please 
<a href=\"register.php\">Sign Up Now</a> If You Do Not Have An Account Here!<br/></b><hr>";
echo "<div class=\"div\" align=\"center\">";
$tm24 = time() - (72*60*60);
$aut = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM ibwff_users WHERE lastact>'".$tm24."'"));
$aut2 = $aut[0];
echo "Regular User: <b>$aut2</b>, ";
  echo "Currently Online: <b>".getnumonline()."</b>";
echo "</div>";
    	echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
    echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
    echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form>";
echo "<p align=\"left\">&#187; <a href=\"forget.php\">Forgot Password???</a><br/></p><hr>";
echo "<div class=\"div\" align=\"center\">";
echo "<b>Not Registered Yet?<a href=\"register.php\">Sign Up Now!!</b></a></div>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<p align=\"left\"><img src=\"../avatars/home.gif\"><a href=\"main.php\">Home</a></p>";
echo "<div class=\"footer\" align=\"center\">";
echo "<b>2015</b> <img src=\"favicon.ico\" type=\"icon\" alt=\"[+]\" width=\"15\" height=\"23\"><normal><a href=\"main.php\"><b>MyDhaka.Tk</b></a>";
$end = microtime(true);
$time = number_format(($end - $start), 2);  
//echo " (".$time."s)</normal>";
echo "<b>(Classic | <a href=\"../mobile/main.php\">Mobile</a>)<br/><br/><b>A Concern OF :::...Mehedi Hasan...:::</b>";
echo " </div>";
echo "</body>";
exit();
}
//session end();
?>