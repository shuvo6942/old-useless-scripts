<?php
session_start();
include("config.php");
include("core.php");  
connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo '<head>';
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"title\" content=\"firebd.net\">
<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG From Shahos: Don't Try To Hack OR else :P\">
<meta name=\"keywords\" content=\"Site Desined By Shahos :) :)\">
<meta name=\"Content-Type\" content=\"text/html\" charset=\"utf-8\"/>
<meta name=\"robots\" content=\"index,all,follow\"/></head>";
echo "<body>";
$action = $_GET["action"]; 
$sid = $_SESSION["sid"];
$who = $_GET["who"];
$uid = getuid_sid($sid);
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();
////////////////Ip Banned By CJ UDAY :)	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
    echo "<head>";
echo "<title>Error!!!</title>";
echo "</head>";
echo "<body>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
echo "<br/>";
echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.ip banned created by <b>CJ UDAY</b><br/><br/>";
$banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
$remain =  $banto[0] - time();
$rmsg = gettimemsg($remain);
echo "<b>Time Remaining: $rmsg</b><br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "</p>";
echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
      exit();
      }
    }
//////////////////Banned System Updated By CJ UDAY :)
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please With Contact Us <a href=\"contact2.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
  include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact2.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
  include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
///////////////////Validation By CJ UDAY :)
					if(isvalidated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  You Are Not Validated!<br/>We are checking your ip and browser<br/>
	  This could take up to 15 munites pls be patient and try again soon<br/>Please try again later...<br/><b>Thank You</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
/////////////////////Premium User Created By CJ UDAY :)
if($action=="")
{
  addonline(getuid_sid($sid),"Upgrading To Premium","premium.php?action=$action");
    echo "<head>";
    echo "<title>Premium Account</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
$abl = mysql_fetch_array(mysql_query("SELECT rp FROM ibwff_users WHERE id='$uid'"));
			echo "<div class=\"header\" align=\"center\">";
			echo "<b>Premium Account Features</b></div>";
  echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
echo "<p><b><big><u>Your account balance:</u></big></b><br/>Your account balance is  &#2547;{$abl[0]} Taka.<br/><a href=\"balance.php\">[what is account balance?]</a></p><br/>";
   echo "<p><b><u>Monthly (General) Premium Member Facilities: [Cost: 200 Taka for Non-VIP, 150 Taka for VIP]</u></b><br/>
<img src=\"p.gif\"/>General Premium members can create clubs, topics & polls even if they have 0 point!<br/>
<img src=\"p.gif\"/>General Premium members can see any club's forum! Infact, they have full forum access!<br/>
<img src=\"p.gif\"/>General Premium members can edit, hide, delete, close, move, pin their created any forum topics!<br/>
<img src=\"p.gif\"/>General Premium members can edit their club announcements at anytime!<br/>
<img src=\"p.gif\"/>General Premium members profile are highly ranked with full 5 star!<br/>
<img src=\"p.gif\"/>A member can be unbanned once if buy General Premium membership!<br/>
<img src=\"p.gif\"/>General Premium members can change their title name instead Premium Member! anytime.<br/>
<img src=\"p.gif\"/>General Premium members will get 250 points salary per month!<br/>
<img src=\"p.gif\"/>General Premium members can change their display name just for 20 points while normal members spend 100 points!<br/>
<img src=\"p.gif\"/>General Premium members can shout without any cost!<br/>
<img src=\"p.gif\"/>General Premium members can shout for 12 times per day while normal members can do 5 shouts only!<br/>
<img src=\"p.gif\"/>General Premium members can give Love only for 1 point while normal members spend 3 points per Love!<br/>
<img src=\"p.gif\"/>General Premium members can gift any members without any gift charge!<br/>
<img src=\"p.gif\"/>General Premium members can gift upto 1000 points per day while normal members can gift upto 300 points per day!<br/>";
if(!spu($uid) && !ispu($uid)) {
echo "&#187; &#187; <a href=\"premium.php?action=upgrade&pkg=200\">Buy Monthly Premium Membership!</a>";
}else{
echo "<b>You are a premium user!<br/></b>";
}
echo "</p>";
echo "<br/><br/><b>Monthly Super Premium Member Facilities:</b> <big>[<i>Cost: &#2547;300 Taka for Non-VIP, &#2547;250 Taka for VIP</i>]</big><br/>
<img src='p.gif' alt=''/>***Super Premium members can view any privacy profile.<br/>
<img src='p.gif' alt=''/>***Super Premium members can send messages to any privacy profile.<br/>
<img src='p.gif' alt=''/>***Super Premium members can send friend requests to any privacy profile.<br/>
<img src='p.gif' alt=''/>***Super Premium members can create clubs, topics &amp; polls even if they have 0 point!<br/>
<img src='p.gif' alt=''/>***Only Super Premium members can edit their clubs name, logo, settings like auto accept, auto validation, allow guest etc at anytime.<br/>
<img src='p.gif' alt=''/>Super Premium members can edit their club announcements at anytime!<br/>
<img src='p.gif' alt=''/>Super Premium members profile are highly ranked with full 5 star!<br/>
<img src='p.gif' alt=''/>A member can be unbanned once if buy Super Premium membership!<br/>
<img src='p.gif' alt=''/>Super Premium members can see any club's forum! Infact, they have full forum access!<br/>
<img src='p.gif' alt=''/>Super Premium members can edit, hide, delete, close, move, pin their created any forum topics!<br/>
<img src='p.gif' alt=''/>Super Premium members can change their title name instead Super Premium Member! anytime.<br/>
<img src='p.gif' alt=''/>Super Premium members will get 500 points salary per month!<br/>
<img src='p.gif' alt=''/>Super Premium members can change their display name just for 50 points while normal members spend 500 points!<br/>
<img src='p.gif' alt=''/>Super Premium members can shout without any cost!<br/>
<img src='p.gif' alt=''/>Super Premium members can shout for 12 times per day while normal members can do 5 shouts only!<br/>
<img src='p.gif' alt=''/>Super Premium members can give Love without any cost!<br/>
<img src='p.gif' alt=''/>Super Premium members can gift any members without any gift charge!<br/>
<img src='p.gif' alt=''/>Super Premium members can gift upto 2000 points per day while normal members can gift upto 300 points per day!<br/><b>";
if(!spu($uid)) {
echo "&#187; &#187; <a href=\"premium.php?action=upgrade&pkg=300\">Buy Monthly Super Premium Membership!</a>";
}else{
echo "<b>You are a super premium user!<br/></b>";
}
echo "</b><br/><br/><b>Remember:</b><br/>
<img src='p.gif' alt=''/>All premium membership are valid for a fixed time (1 month/28 days).You can renew your premium membership to add extra 1 month.<br/>
<img src='p.gif' alt=''/>MyDhaka Rules are for all.If you break any rules, you will be punished by penalty or ban.<br/>
<img src='p.gif' alt=''/>If you are a VIP member, you will not lose your VIP memberhip after buying premium membership.You will be both.</p>
";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="upgrade")
{
  addonline(getuid_sid($sid),"Upgrading To Premium","premium.php?action=$action");
 echo "<head>";
    echo "<title>Premium Account</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
			echo "<div class=\"header\" align=\"center\">";
			echo "<b>Premium Account</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
    $pkg = mysql_real_escape_string($_GET["pkg"]);
    if($pkg=='200')
    {
    }else if($pkg=='300'){
    }else if($pkg=='180'){
    }else{
    echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Unknown Packege!<br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
echo "</div>";
echo "</body>";
    exit();
    }
    $epp = mysql_fetch_array(mysql_query("SELECT rp FROM ibwff_users WHERE id='".$uid."'"));
    if($pkg==200 && $epp[0]<200)
    {
    echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Sorry! Your current account balance is: &#2547; $epp[0] Taka
Cost for buying this premium membership is: &#2547; 200 Taka
That means, You must have at least &#2547; 200 Taka in your account to buy this premium membership!
So, Please Recharge At Least &#2547; 200 Taka & then try again.<br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
    }
if($pkg==300 && $epp[0]<300)
    {
    echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/>Sorry! Your current account balance is: &#2547; $epp[0] Taka
Cost for buying this premium membership is: &#2547; 300 Taka
That means, You must have at least &#2547; 300 Taka in your account to buy this premium membership!
So, Please Recharge At Least &#2547; 300 Taka & then try again.<br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
    echo "</html>";
    exit();
    }
    $timeto = 30*24*60*60;
    $vtime = $timeto + time();
    if($pkg=='200')
    {
      $mins = $epp[0] - 200; $puxx="1";
    }else if($pkg=='300'){
      $mins = $epp[0] - 300; $puxx="2";
    }else if($pkg=='180'){
      $mins = $epp[0] - 300;
    }
    $res = mysql_query("UPDATE ibwff_users SET ptime='".$vtime."' WHERE id='".$uid."'");
    if($res)

    {$nam = mysql_fetch_array(mysql_query("SELECT name FROM ibwff_users WHERE id='".$uid."'"));
$id = mysql_fetch_array(mysql_query("SELECT id FROM ibwff_users WHERE id='".$uid."'"));


$sagor = date(" h:i a,l dS F Y",time()+(6* 60 * 60));
$sagor2 = date(" h:i a, l dS F Y",time()+(6* 60 * 60)+(30*24*60*60));
    	//$nam = getnick_uid($1pt[0]);
    	mysql_query("INSERT INTO ibwff_shouts SET shout='[b][user=".$id[0]."]".$nam[0]."[/user] has bought premium membership for  the session [u]".$sagor."[/u] to [u]".$sagor2."[/u][/b]', shouter='4', shtime='".time()."'");
    mysql_query("UPDATE ibwff_users SET pu='$puxx' WHERE id='".$uid."'");
    mysql_query("UPDATE ibwff_users SET rp='".$mins."' WHERE id='".$uid."'");
if($pkg == '200')
{
$uday = 250;
}else if($pkg == '300')
{
$uday = 500;
}else{
$uday = 250;
}
    mysql_query("UPDATE ibwff_users SET plusses=plusses+$uday WHERE id='".$uid."'");
      echo "<img src=\"../avatars/ok.gif\" alt=\"O\"/> Upgrated Successfully to Premium<br/>$uday Points bonus for you!";
    }else{
      echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/> Upgrating not complate. Please try again";
    }
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
?>
</html>