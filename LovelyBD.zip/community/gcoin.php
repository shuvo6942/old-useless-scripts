<?php
session_start();
include("config.php");
include("core.php");
connectdb();
header("Content-type: text/html; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\"\"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
echo "<head>";
echo "<link rel=\"StyleSheet\" type=\"text/css\" href=\"".bosshira_themes()."\" />";
echo "<meta name=\"descriptions\" content=\"free, community, forums, chat, wap, community, download\">
<meta name=\"messgeses\" content=\"MSG : Don't Try To Hack OR else :P\">
</head>";
echo "<body>";
##G0LD3N C0IN IS FULLY CR3AT3D N D3S!GNED BY Shahos :-)
$action = $_GET["action"]; 
$sid = $_SESSION["sid"];
$uid = getuid_sid($sid);
$who = $_GET["who"];
$sitename = mysql_fetch_array(mysql_query("SELECT value FROM ibwff_settings WHERE name='sitename'"));
$sitename = $sitename[0];
$ubrw = explode(" ",$HTTP_USER_AGENT);
$ubrw = $ubrw[0];
$ipad = getip();
////////////////Ip Ban By CJ UDAY :)	
if(isipbanned($ipad,$ubrw))
    {
      if(!isshield(getuid_sid($sid)))
      {
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
echo "<b><u>This IP Address Has Been Blocked!!!</u></b><br/>";
echo "<br/>";
echo "How ever we grant a shield against IP-Ban for our great users, you can try to see if you are shielded by trying to log-in, if you kept coming to this page that means you are not shielded, so come back when the ip-ban period is over.<br/><br/>";
$banto = mysql_fetch_array(mysql_query("SELECT  timeto, pnreas FROM ibwff_penalties WHERE  penalty='2' AND ipadd='".$ipad."' AND browserm='".$ubrw."' LIMIT 1 "));
$remain =  $banto[0] - time();
$rmsg = gettimemsg($remain);
echo "<b>Time Remaining: $rmsg</b><br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "</p>";
echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
echo "<b>Username:</b><br/><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
echo "<b>Password:</b><br/><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
echo "<input type=\"submit\" value=\"Login\"/>";    
echo "</form><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
exit();
      }
    }
//////////////////Ban By CJ UDAY :)
if(isbanned($uid))
{
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
$banto = mysql_fetch_array(mysql_query("SELECT timeto, pnreas, exid FROM ibwff_penalties WHERE uid='".$uid."' AND penalty='1' OR uid='".$uid."' AND penalty='2'"));
$banres = mysql_fetch_array(mysql_query("SELECT lastpnreas FROM ibwff_users WHERE id='".$uid."'"));
$remain = $banto[0]- time();
$rmsg = gettimemsg($remain);
echo "<br/><b>Time Left: </b>$rmsg<br/>";
$nick = getnick_uid($banto[2]);
$text = parsepm($banto[1], $sid);
echo "<b>Reason: </b>$text<br/>";
echo "<b><i><u>If You Banned By Our Mistake or Want To Be Unban<br/>Then Please Contact <a href=\"contact.php\">Admin</a></b></i></u><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
exit();
}
if(!isuser(getuid_sid($sid)))
{
  echo "<head>";
  echo "<title>Error!!!</title>";
  echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>This feature is unavailiable for guests.
 So, please login if you are already a member otherwise<br/><a href=\"register.php\">Register/Sign Up for FREE.</a><br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><br/><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><br/><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
 echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/><br/>";
  echo "Not Registered Yet?<br/>";
  echo "<a href=\"register.php\">Register Now!</a>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
if(islogged($sid)==false)
{
  echo "<head>";
  echo "<title>Error!!!</title>";
 echo "</head>";
  echo "<body>";
  echo "<div class=\"header\" align=\"center\">";
  echo "<img src=\"../avatars/notok.gif\" type=\"error\" alt=\"X\"/><br/><b>Error!!!</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
  echo "<br/>For some security reasons,you are automatically logged out.<br/>
  You should <a href=\"contact.php\">contact admin</a> immediately if you are facing this problem frequently!<br/>
  Or, Please Login Again :-)<br/><br/>";
  echo "<div class=\"div\" align=\"center\">";
  echo "<b>USER ACCESS</b></div>";
  echo "<form action=\"login.php\" method=\"get\"><p align=\"left\">";
  echo "<b>Username:</b><br/><input name=\"loguid\" format=\"*x\" maxlength=\"20\"/><br/>";
  echo "<b>Password:</b><input type=\"password\" name=\"logpwd\"  maxlength=\"20\"/><br/>";
  echo "<input type=\"submit\" value=\"Login\"/>";    
  echo "</form><br/>";
  echo "</div>";
  echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
  echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
  echo "</div>";
  echo "</body>";
  echo "</html>";
  exit();
}
///////////////////Deactivated Account By CJ UDAY :)
          if(isdeactivated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
    echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/><b>Error!!!</b></div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  <b>Your Account Has Been Deactivated.<br/>And It Will Be Never Activated Again!</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
///////////////////Validation:)
					if(isvalidated(getuid_sid($sid), $uid))
  {
	echo "<head>";
    echo "<title>Error!!!</title>";
   echo "</head>";
    echo "<body>";
echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
							echo "<div class=\"header\" align=\"center\">";
echo "<img src=\"../avatars/notok.gif\" alt=\"X\"/><br/>Error!!!</div>";
echo "<div class=\"shout2\" align=\"center\">";
      echo "<br/>
	  You Are Not Validated!<br/>We are checking your ip and browser<br/>
	  This could take up to 15 munites pls be patient and try again soon<br/>Please try again later...<br/><b>Thank You</b><br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
      exit();
  }
//////////////////Golden Coin By CJ UDAY :)
    date_default_timezone_set('UTC');
    $New_Time = time() + (6 * 60 * 60);
    $Hour = date("G",$New_Time);
    if((8>$Hour ||  9<$Hour) && (14>$Hour || 15<$Hour) && (20>$Hour || 21<$Hour))
    {
echo "<head>";
    echo "<title>Golden Coin</title>";
   echo "</head>";
    echo "<body>";
	echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
            echo "</div>";
						echo "<div class=\"header\" align=\"center\">";
			echo "<b>Golden Coin</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
echo "<img src=\"../avatars/notok.gif\" alt=\"x\"> Sorry!the game playing time is over.<br/>";
echo "<img src=\"../avatars/next.gif\" alt=\">\"> <b>You can play this game everyday from 8 A.M to 10 A.M,2 P.M to 4 P.M and 8 P.M to 10 P.M BST (Bangladesh Standard Time)</b><br/>
Please try again at playing time.<br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
    echo "</html>";
    exit();
    }
if($action=="")
{
  addonline(getuid_sid($sid),"Grabing Golden Coin","gcoin.php?action=$action");
    echo "<head>";
    echo "<title>Golden Coin</title>";
    echo "</head>";
    echo "<body>";
	echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
echo "</div>";
						echo "<div class=\"header\" align=\"center\">";
			echo "<b>Golden Coin</b></div>";
  echo "<div class=\"shout2\" align=\"left\">";
include("pm_by.php");
date_default_timezone_set('UTC');
$BD_Time = time() + (6* 60 * 60);
$newtime = date("h:i:s a",$BD_Time);
$lstall = mysql_fetch_array(mysql_query("SELECT id, uid, coin, createtime, catchtime FROM uday_goldencoin ORDER BY catchtime DESC LIMIT 1"));
$lstcoin = mysql_fetch_array(mysql_query("SELECT id, createtime FROM uday_goldencoin WHERE uid='' ORDER BY createtime DESC LIMIT 1"));
$unick = subnick(getnick_uid($uid));
$whonick = subnick(getnick_uid($lstall[1]));
echo "Golden Coin are being thrown here with a rendom interval of time. All you need to do is, refresh this page until a link to grab your coin appears than hits the link. Remember, you need to be fast to grab the coin otherwise it will be transferred to someone else's pocket!<br/>";
$dj = mysql_fetch_array(mysql_query("SELECT id, uid, coin, createtime, catchtime FROM uday_goldencoin ORDER BY createtime DESC LIMIT 1"));
$nowx = time();
$nxtcoin = gettimemsg($dj[3] - $nowx);
$gcrs = mysql_fetch_assoc(mysql_query("select pu from ibwff_users where id='$uid'"));
if((ispu(getuid_sid($sid))) || spu($uid)){
echo "<br/>Next coin Comming: [$nxtcoin]<br/>";
}else{
echo "<b>Only Premium Users Can see next golden coin coming time!</b><br/>";
}
echo "<hr>"; 
if(time()<$lstcoin[1])
{
echo "<br/>Sorry there's no coin at the moment<br/>";
echo "<a href=\"gcoin.php\">Search for coin</a> [$newtime]";
}else{
echo "<br/>Here is your coin <a href=\"gcoin.php?action=grab&coinid=$lstcoin[0]\">Grab it!</a>";
}
$idle = gettimemsg(time() - $lstall[4]);
echo "<br/>Last Coin Gainer: <a href=\"profile.php?who=$lstall[1]\"><b>$whonick</b></a> ($idle ago)<br/>";
$c = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM uday_gcg"));
echo "Today coin gainers : [<a href=\"gcg.php\">$c[0]</a> Times Grabbed Coins]<br/><br/>";
echo "<b>Currently playing</b> :<br/>";
$px = "SELECT userid FROM ibwff_online WHERE place='Grabing Golden Coin'";
$pz = mysql_query($px);
while($p = mysql_fetch_array($pz))
{
$n = mysql_fetch_array(mysql_query("SELECT hiranick, sex FROM ibwff_users WHERE id='".$p[0]."'"));
if($n[1]=="M"){$nicks = "<font color=\"blue\"><b>$n[0]</b></font>";}
if($n[1]=="F"){$nicks = "<font color=\"deeppink\"><b>$n[0]</b></font>";}
if($n[1]==""){$nicks = "<font color=\"blue\"><b>$n[0]</b></font>";}
echo "<a href=\"profile.php?who=$p[0]\">$nicks</a> ,";
}
echo "</div>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
else if($action=="grab")
{
  addonline(getuid_sid($sid),"Catching Golden Coin","gcoin.php?action=main");
echo "<head>";
    echo "<title>Grab Golden Coin</title>";
    echo "</head>";
    echo "<body>";
	echo "<div class=\"mblock1\" align=\"left\">";
include("header.php");
          echo "</div>";
						echo "<div class=\"header\" align=\"center\">";
			echo "<b>Grab Golden Coin</b></div>";
  echo "<div class=\"shout2\" align=\"center\">";
include("pm_by.php");
$unick = getnick_uid($uid);
$coinid = $_GET["coinid"];
$rndm = rand(200, 500);
$showtime = time() + $rndm;
$gcoin = mysql_fetch_array(mysql_query("SELECT uid, coin, createtime, catchtime FROM uday_goldencoin WHERE id='".$coinid."'"));
$nout = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM uday_goldencoin WHERE id='".$coinid."'"));
    if(time()<$gcoin[2])
    {
    echo "cJ uDaY is here, Go away :P<br/><br/>";
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
echo "</html>";
    exit();
    }
if($gcoin[0]<1 && $coinid!=0 && $nout[0]!=0)
{
$prof = mysql_fetch_array(mysql_query("SELECT coins FROM ibwff_users WHERE id='".$uid."'"));
$vws = $prof[0]+1; mysql_query("UPDATE ibwff_users SET coins='".$vws."'WHERE  id='".$uid."'");
    mysql_query("UPDATE uday_goldencoin SET uid='".$uid."', catchtime='".time()."', coin='1' WHERE id='".$coinid."'");
        echo "<br/><img src=\"../avatars/ok.gif\" alt=\"O\"/> Coin Grabbed Successfully!<br/><a href=\"gcoin.php\">Play Again!</a><br/><br/>";
    mysql_query("INSERT INTO uday_goldencoin SET createtime='".$showtime."'");
    mysql_query("INSERT INTO uday_gcg SET message='[user=$uid]$unick"."[/user] just grabbed a G-coin-lden C-coin-in', time='".time()."'");
}else{
        echo "<br/><img src=\"../avatars/notok.gif\" alt=\"X\"/> Sorry this coin already grabbed!<br/><a href=\"gcoin.php\">Try Again!</a><br/><br/>";
}
echo "</div>";
echo "<p align=\"left\"><img src=\"../avatars/menu.gif\"><a href=\"main.php\">Menu</a></p>";
echo "<div class=\"footer\" align=\"center\">";
include("footer.php");
echo "</div>";
echo "</body>";
}
?>
</html>