++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Nama Script : cPanel Creator
Fungsi : Membuat akun cPanel tanpa perlu login ke WHM
++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Cara memakai :
1. Miliki WHM
2. Upload script
3. Edit bagian 
$whm_user   = "";
$whm_pass   = "";
$whm_host   = "";


dan terakhir, edit bagian di bawah

<input type="hidden" name="package" size="30" value="">
isi VALUE itu dengan paket cPanel yang sudah kamu setting di WHM


4. Selesai.....

++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Follow me  at Twitter : @pubiwayone
My Blog : www.EdwinBlog.Us