
Cute Guestbook
Copyright Cgixp Team
Website: http://www.cgixp.tk
Email: mali75850@yahoo.com

        INSTALLATION

This script requires no configurations, just upload the
files on your server and chmod 777 guestbook.txt and temp.txt.
The folder in which the files are uploaded must also be chmod 777
Thats All
:)

If you have any problem feel free to contact us.
