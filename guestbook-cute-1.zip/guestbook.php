<html>
<head>
<SCRIPT language=JavaScript>
function textCounter(field, countfield, maxlimit) {
if (field.value.length > maxlimit)
field.value = field.value.substring(0, maxlimit);
else
countfield.value = maxlimit - field.value.length;
}
</SCRIPT>
<script language="JavaScript">
<!--
function emo(emo){
document.all.comment.value += emo;
document.all.comment.focus();
return;
}
//-->
</script>
<style>
BODY{
	FONT-SIZE: 15px; COLOR: #000; FONT-FAMILY: Verdana, Tahoma, Arial, sans-serif
BORDER-RIGHT: #c2cfdf 1px solid; PADDING-RIGHT: 6px; PADDING-TOP: 6px; BACKGROUND-COLOR: #f5f9fd
}
TABLE {
	FONT-SIZE: 11px; COLOR: #000; FONT-FAMILY: Verdana, Tahoma, Arial, sans-serif
}
TR {
	BORDER-RIGHT: #345487 1px solid; PADDING-RIGHT: 6px; BORDER-TOP: #345487 1px solid; PADDING-LEFT: 6px; PADDING-BOTTOM: 6px; BORDER-LEFT: #345487 1px solid; PADDING-TOP: 6px; BORDER-BOTTOM: #345487 1px solid; BACKGROUND-COLOR: #f5f9fd
}
TD {
	BORDER-RIGHT: #345487 1px solid; BORDER-TOP: #345487 1px solid; BORDER-LEFT: #345487 1px solid; BORDER-BOTTOM: #345487 1px solid; BACKGROUND-COLOR: #f5f9fd
}
	TEXTAREA     	{font-family:Verdana;font-size:10pt;background:#f5f9fd;color:#000000;}
input
{
	BORDER-RIGHT: #345487 1px solid; BORDER-TOP: #345487 1px solid; BORDER-LEFT: #345487 1px solid; BORDER-BOTTOM: #345487 1px solid; BACKGROUND-COLOR: #f5f9fd
}
	A:link  {
	FONT-WEIGHT: bold; FONT-SIZE: 15px; COLOR: #3a4f6c; TEXT-DECORATION: none
}
A:visited {
	FONT-WEIGHT: bold; FONT-SIZE: 15px; COLOR: #3a4f6c; TEXT-DECORATION: none
}
A:active {
	COLOR: #000; TEXT-DECORATION: underline
}
A:hover {
	COLOR: #465584; TEXT-DECORATION: underline
}
TABLE{
	PADDING-RIGHT: 7px; MARGIN-TOP: 1px; PADDING-LEFT: 7px; FONT-SIZE: 15px; PADDING-BOTTOM: 7px; PADDING-TOP: 7px; BACKGROUND-COLOR: #d1dceb
}
.gmenu{
	PADDING-RIGHT: 7px; MARGIN-TOP: 1px; PADDING-LEFT: 7px; FONT-SIZE: 10px;PADDING-BOTTOM: 7px; PADDING-TOP: 7px; BACKGROUND-COLOR: #d1dceb
}
	.small{
	FONT-SIZE: 10px; BACKGROUND-COLOR: #d1dceb
}

</style>
<title>Cute Guestbook</title>
</head>
<body>
<!--Copyright CUTE GUESTBOOK Downloaded from http://www.cgixp.tk (Free PHP Scripts)-->
<?php 
extract($HTTP_GET_VARS);
extract($HTTP_POST_VARS);
include "conf.txt";
function smiles(){
?>
<a href="javascript:emo(' :) ')"><img src="images/smile.gif" border=0 alt=":)"></a>
    <a href="javascript:emo(' :(' ) "><img src="images/sad.gif" border=0 alt=":("></a>
    <a href="javascript:emo(' :P ')"><img src="images/tongue.gif" border=0 alt=":P"></a>
    <a href="javascript:emo(' :o ')"><img src="images/scared.gif"  border=0 alt=":o"></a>
    <a href="javascript:emo(' :C ')"><img src="images/mad.gif" border=0 alt=":C"></a>
    <a href="javascript:emo(' ;Y ')"><img src="images/thumbsup.gif" border=0 alt=";Y"></a>
	<a href="javascript:emo(' :O) ')"><img src="images/clown.gif"border=0 alt=":0"></a>
    <a href="javascript:emo(' :D ')"><img src="images/laugh.gif" border=0 alt=":D"></a>
    <a href="javascript:emo(' :/ ')"><img src="images/sweatdrop.gif" border=0 alt=":/"></a>
    <a href="javascript:emo(' :s ')"><img src="images/shocking.gif" border=0 alt=":s"></a>
    <a href="javascript:emo(' :r ')"><img src="images/naughty.gif" border=0 alt=":r"></a>
    <a href="javascript:emo(' ;) ')"><img src="images/rolleyes.gif"border=0 alt=";)"></a>
    <a href="javascript:emo(' :H) ')"><img src="images/heart.gif"border=0 alt=":H)"></a>
    <a href="javascript:emo(' :i) ')"><img src="images/info.gif"border=0 alt=":i)"></a>
    <a href="javascript:emo(' :Q) ')"><img src="images/question.gif"border=0 alt=":Q)"></a>
	<?php
}

$day =date("D d");
$month =date("M");
$year =date("Y");
$dt="$day-$month-$year";
$copyright="<FONT SIZE=1 COLOR=#3a4f6c>Powered By:</font><A HREF=http://www.cgixp.tk target=new><font class=small>Cute Guestbook</font></A></FONT>";
if($do=="do_sign"){
if ($name!="" && $comment !=""){
$name = str_replace ("|~!|","", $name);
$comment = str_replace ("\n", "<br>", $comment);
$comment = str_replace ("|~!|", "-", $comment);
$comment = str_replace ("<img ","", $comment);
$comment = str_replace ("<a ","", $comment);
$comment = str_replace (":)","<img src=images/smile.gif>", $comment);
$comment = str_replace (":(","<img src=images/sad.gif>", $comment);
$comment = str_replace (":P","<img src=images/tongue.gif>", $comment);
$comment = str_replace (":o","<img src=images/scared.gif>", $comment);
$comment = str_replace (":C","<img src=images/mad.gif>", $comment);
$comment = str_replace (";)","<img src=images/rolleyes.gif>", $comment);
$comment = str_replace (";Y","<img src=images/thumbsup.gif>", $comment);
$comment = str_replace (":D","<img src=images/laugh.gif>", $comment);
$comment = str_replace (":s","<img src=images/shocking.gif>", $comment);
$comment = str_replace (":r","<img src=images/naughty.gif>", $comment);
$comment = str_replace (":/","<img src=images/sweatdrop.gif>", $comment);
$comment = str_replace (":O)","<img src=images/clown.gif>", $comment);
$comment = str_replace (":H)","<img src=images/heart.gif>", $comment);
$comment = str_replace (":i)","<img src=images/info.gif>", $comment);
$comment = str_replace (":Q)","<img src=images/question.gif>", $comment);
$name = stripslashes ($name);
$comment = stripslashes ($comment);
$lis="0";
$user=file("badwords.txt");
for($x=0;$x<sizeof($user);$x++) {
$comment = str_replace($temp[0],"-",$comment);
$jemp = explode(";",$user[$x]);
$opp[$x] = "$jemp[0];";
$list[$lis] = $opp[$x];
$lis++; 
}
if(sizeof($list) != "0") {
for($y=0;$y<sizeof($list);$y++) {
$temp = explode(";",$list[$y]);
$temq=ucwords($temp[0]);
$temr=ucfirst($temp[0]);
$tems=strtoupper($temp[0]);
$comment = str_replace ($temp[0],"-", $comment);
$comment = str_replace ($tep,"-", $comment);
$comment = str_replace ($temq,"-", $comment);
$comment = str_replace ($temr,"-", $comment);
$comment = str_replace ($tems,"-", $comment);
$name = str_replace ($temp[0],"-",$name);
$name = str_replace ($temq,"-",$name);
$name = str_replace ($temr,"-",$name);
$name = str_replace ($tems,"-",$name);
}
}
$fp = fopen ("guestbook.txt", "a+");
fwrite ($fp, $name);
fwrite ($fp, "|~!|");
fwrite ($fp, $email);
fwrite ($fp, "|~!|");
fwrite ($fp, $website);
fwrite ($fp, "|~!|");
fwrite ($fp, $comment);
fwrite ($fp, "|~!|");
fwrite ($fp, $dt);
fwrite ($fp, "|~!|");
fwrite ($fp, "\n");
fclose ($fp);
print "<CENTER>Thank you for signing our guestbook.</CENTER><BR>";
}else{ echo"<FONT COLOR=red>Please fill the required fields</FONT><BR><BR>";}
}
$latest_rev = $maximum;
$lp=file("guestbook.txt");
$abd = count($lp);
//echo "$abd";
if ($abd > $latest_rev) {
$folename = "guestbook.txt"; 
$fd = fopen ($folename, "r"); 
$puff = fread ($fd, filesize($folename)); 
fclose ($fd);
$last_file = fopen ("temp.txt", "a+");
fwrite ($last_file, $puff);
fclose($last_file);
$fz = fopen ("guestbook.txt", "w");
fwrite ($fz, "");
fclose($fz);
$lines14 = file("temp.txt");
$a1 = count($lines14);
$u = $a1 - $maximum;
for($i1 = $a1; $i1 >= $u ;$i1--){
$msg_old =  $lines14[$i1] . $msg_old;
}
$fz = fopen ("guestbook.txt", "a+");
fwrite ($fz,$msg_old);
fclose($fz);
}
$fz = fopen ("temp.txt", "w");
fwrite ($fz, "");
fclose($fz);
$user1=file("guestbook.txt");
if($action==""){
echo "<a href=?action=sign class=gmenu>Click here to sign our Guestbook</a>";
echo "<table width=100%><td>";
$tlis = 0;
	for($mp=sizeof($user1)-1;$mp>=0;$mp--){
		$mop = explode("|~!|",$user1[$mp]);
		$opp[$mp] = "$mop[0]|~!|$mop[1]|~!|$mop[2]|~!|$mop[3]|~!|$mop[4]|~!|$mop[5]|~!|";
		$list123[$tlis] = $opp[$mp];
		$tlis++; 
	}
$latest_max = sizeof($list123);
$u = $a - $latest_max;
if (is_file("guestbook.txt"))
{
$s=sizeof($list123);
if ($page=='' or !$page) { $page=1; }
$end=$listings_per_page*$page;
$start=$end-$listings_per_page;
if ($start<>'0') {
$new_page=$page-1;
$prev="<a href='?page=$new_page' ><<-Previous</a>";
}
else {
	$prev="<<-Previous";
}

if ($end<$s) {
	$new_page1=$page+1;
	$next="<a href='?page=$new_page1' >Next->></a>";
}
else {
	$next="Next->>";
}
$today = time();
for ($i=$start; $i<$end; $i++){
if(substr($list123[$i], 1, 5 )!= "")
{
$p=explode('|~!|', $list123[$i]);
if ($p[2]=="http://"){
$link="None";
}else{
$link="<a href=$p[2] target=balnk>$p[2]</a>";
}if($p[1]==""){
$nm=$p[0];
}else{ $nm="<a href=mailto:$p[1]>$p[0]</a>"; }
echo "<tr><tr><tr><td width=10%>Name:</td><td>$nm</td></tr><tr><td>Website:</td><td>$link</td></tr><tr><td>Comments:</td><td>$p[3]</td></tr></tr><tr><td>Signed on:</td><td>$p[4]</td></tr></tr></tr>";
}
}
$pages=$s/$listings_per_page;
$pages1=round($pages, 2);
$p= explode(".", $pages1);
$pcount=count($p);
$ext=$p[$pcount-2];
if ($ext!=0) {
	$num=$p[0]+1;
}

else {
	$num=$p[0];
}
echo "</table><table width='100%'><tr><td align='left'>$prev</td><td align='center'>";
for ($i=1; $i<=$num; $i++) {
	if ($i==$page) {
echo " <B>$i</B> ";

	}
	else {
echo " <a href='?page=$i'>$i</a> ";
}
}
echo "</td><td align='right'>$next</td></tr></table>";
}
}
if ($action=="sign"){
echo"<table><font size=3>Sign our Guestbook</font></td></table>";
echo "<table><form method=post action=?do=do_sign><tr><td>* Name:</td><td><input type=text name=name maxlength=28 size=28></td></tr><tr><td>Email:</td><td><input type=text name=email maxlength=35 size=28></td></tr><tr><td>Website:</td><td><input type=text name=website maxlength=80 size=28 value=http://></td></tr><tr><td></td><td>";
smiles();
echo"</td></tr><tr><td>* Comments:</td><td><textarea name=comment rows=5 cols=45 onkeydown=textCounter(this.form.comment,this.form.descriptionleft,250); onkeyup=textCounter(this.form.comment,this.form.descriptionleft,250);></textarea><BR>Characters Left:<INPUT style='BORDER-RIGHT: 0px; BORDER-TOP:0px;BORDER-LEFT:0px; BORDER-BOTTOM:0px; 	FONT-SIZE: 15px; COLOR: #000; FONT-FAMILY:Arial' maxLength=3 name=descriptionleft readOnly size=3 tabIndex=250 value=250> </td></tr><tr><td></td><td align=center><input type=submit value=Submit> <input type=button value=Cancel onclick=javascript:history.back()> * = Required</td></tr></form></table>";
}
echo "<BR><table align=center class=small><tr class=small><td>$copyright</td></tr></tr></table>";
?>
</body>
</html>
