CREATE TABLE IF NOT EXISTS `nid_card` (
`id` int(11) NOT NULL auto_increment,
`id_user` int(11) NOT NULL,
`card_name` varchar(50) NOT NULL,
`msg` varchar(5000) NOT NULL,
`time` int(11) NOT NULL,
`privat` int(11) NOT NULL,
`count` int(11) NOT NULL default '0',
`card_view` int(11) NOT NULL default '0',
`cat` int(11) NOT NULL default '0',
PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
