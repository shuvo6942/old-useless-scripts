<? include_once 'sys/inc/start.php';
include_once 'sys/inc/compress.php';
include_once 'sys/inc/sess.php';
include_once 'sys/inc/home.php';
include_once 'sys/inc/settings.php';
include_once 'sys/inc/db_connect.php';
include_once 'sys/inc/ipua.php';
include_once 'sys/inc/fnc.php';


$set['title']='NID Card maker';   
include_once 'sys/inc/thead.php';include_once 'delete.php';

	if(isset($_FILES['image'])){
		$errors= array();
		$file_name = basename($url);
list($txt, $ext) = explode(".", $file_name);
$file_name = $txt.time();
$file_name = $file_name.".".$ext.jpg;
		$file_size =$_FILES['image']['size'];
		$file_tmp =$_FILES['image']['tmp_name'];
		$file_type=$_FILES['image']['type'];   
		$file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));
		
		$expensions= array("jpeg","jpg"); 		
		if(in_array($file_ext,$expensions)=== false){
			$err[]="extension not allowed, please choose a JPEG file.";
		}
		if($file_size > 2097152){
		$err[]='File size must be excately 2 MB';
		}				
		
	}
 if (isset($_POST['ok'])){

$nameb=$_POST['nameb'];
$name =$_POST['nam'];
$father=$_POST['father'];
$mother=$_POST['mother']; 
$d=$_POST['d'];
$m=$_POST['m'];
$y=$_POST['y'];
$address=$_POST['address'];
$blad=$_POST['blad'];
$sign=$_POST['sign'];
if($_POST['privacy']==1){} else{$err[]='For create card must be accept our privacy';} $id= rand(10000000000000, 99999999999999); $file= rand(10000000, 99999999);
if($_POST['y']==1990){$date='2009';}
if($_POST['y']==1991){$date='2010';} if($_POST['y']==1992){$date='2011';}
if($_POST['y']==1993){$date='2012';}
if($_POST['y']==1994){$date='2013';} 
if($_POST['y']==1995){$date='2014';}
if($_POST['y']==1996){$date='2015';} if($_POST['y']==1996){$date='2015';} if($_POST['y']==1997){$date='2015';} if (strlen2($name)<3)$err[]='write your name in english'; if (strlen2($nameb)<3)$err[]='write your name in bengali'; if (strlen2($mother)<3)$err[]="write your mother's name in bangla";
if (strlen2($father)<3)$err[]="write your father's name in bangla";
if (strlen2($sign)<2)$err[]='write your singature';
if (strlen2($sign)>6)$err[]='write your singature in english within 6 chactors';
if (strlen2($address)<8)$err[]='write your address in english'; if (strlen2($blad)<1)$err[]='write your blad group in english'; if (strlen2($d)<1)$err[]='write your day in number'; if (strlen2($d)>2)$err[]='invaild your birthday';
if (!isset($err)){ 
if (eregi('\.jpe?g$',$_FILES['image']['name']) && $imgc=@imagecreatefromjpeg($_FILES['image']['tmp_name'])){
if (imagesx($imgc)>107 || imagesy($imgc)>92){
$img_x=imagesx($imgc);
$img_y=imagesy($imgc);

if ($img_x==$img_y){
$dstW=100;
$dstH=130;}
elseif ($img_x>$img_y){
$prop=$img_x/$img_y;
$dstW=100;
$dstH=ceil($dstW/$prop);}

else{
$prop=$img_y/$img_x;
$dstH=110;
$dstW=ceil($dstH/$prop);}
list($image_width, $image_height) = getimagesize($_FILES['image']);
$screen=imagecreatetruecolor(92, 99);
imagecopyresampled($screen, $imgc, 0, 0, 0, 0, 92, 99, $img_x, $img_y);
imagedestroy($imgc);
@chmod(H."idcard/tmp/$file_name",0777);
@unlink(H."idcard/tmp/$file_name");
imagejpeg($screen,H."tmp/$file_name",100);
@chmod(H."tmp/$file_name",0777);
imagedestroy($screen); }}
	 $image_id_png       = 'id.jpg'; 
$temp_folder        = 'tmp/'; //temp dir path to store images$fbuser="$file";
$font               = 'fonts/DidactGothic.ttf';  $fon               = 'fonts/Bangla.ttf';  $fontb               = 'fonts/arialbd.ttf'; $fontbl               = 'fonts/arialbda.ttf'; $sinf               = 'fonts/Absinthe.ttf';   $dest = imagecreatefromjpeg($image_id_png); // source id card image template
			    $src =     imagecreatefromjpeg($temp_folder.$file_name); 
    imagealphablending($dest, false); 
    imagesavealpha($dest, true);
    
   imagecopymerge($dest, $src, 9, 80, 0, 0, 90, 97, 90);  

    
      $facebook_blue = imagecolorallocate($dest, 81, 103, 147);   $facebook_grey = imagecolorallocate($dest, 74, 74, 74); $black = imagecolorallocate($dest, 0, 0, 0); $red = imagecolorallocate($dest, 255, 0, 0);
    
       $id_no        = "$id";
    $name_bangla      = "$nameb";
$name_english      = "$name";
    
    $for_birthdate     = "$d $m $y";
        $given_date         = "3rd March $date";      imagealphablending($dest, true); 
    
    imagettftext($dest, 17, 0, 175, 225, $red , $fontbl, $id_no); 
    imagettftext($dest, 15, 0, 157, 104, $black, $fon, $name_bangla);    imagettftext($dest, 12, 0, 157, 126, $black, $fontbl, $name_english); 
    imagettftext($dest, 15, 0, 157, 153, $black, $fon, $father); 
    imagettftext($dest, 13, 0, 206, 198, $red, $fontbl, $for_birthdate);    imagettftext($dest, 16, 0, 21, 209, $black, $sinf, $sign); 
    imagettftext($dest, 15, 0, 157, 178, $black, $fon, $mother); imagettftext($dest, 12, 0, 78, 308, $black, $fontbl, $address);  imagettftext($dest, 12, 0, 78, 367, $red, $fontbl, $blad); imagettftext($dest, 11, 0, 282, 423, $black, $fontbl, $given_date);        imagepng($dest, $temp_folder.'id_'.$fbuser.'.jpg'); 
    header('Content-Type: image/jpeg');
    imagejpeg($dest); 
unlink("tmp/$file_name"); $time="$time+60*60";
@mysql_query("insert into `nid_card` (`id`, `card_name`, `time`, `card_view`) values('$file', 'id_$file.jpg ', '$time', '1')");
header("Location: /view.php?card=$file".SID);exit; }  }
err();
echo'<div class="p_t"><font color="red"> এই Fake NID Card ব্যক্তিগত কোন কাজে ব্যবহার করা আইনগত অপরাধ । এই কার্ড শুধু facebook account varification এর জন্য । এই হা ব্যক্তিগত কোন কাজে ব্যবহার করে যদি কোন সমস্যা বা আইনের জামেলায় পড়েন এর জন্য আমরা দায়ী নয় ।</font><hr/>এই National Id card maker এর Script বিক্রয় করা হবে । শুধু script নিলে 150 টাকা আর setup করালে 200 টাকা<br/> Call +8801775820343<br/>OR<br/>+8801836262425<hr/> '; echo'<form method="post" action="" enctype="multipart/form-data">'; echo"<br/>Photo(jpg file only):<br/><input type=\"file\" name=\"image\" /><br/>\n";
 echo 'Name (Eng):<br/><input type="text" name="nam"/><br/>Name (বাংলায়): <br/><input type="text" name="nameb"/><br/>Fathers Name (বাংলায়):<br/><input type="text" name="father"/><br/>Mothers Name (বাংলায়) : <br/><input type="text" name="mother"/><br/>Birthday:<br/><table><tr><td><input type="text" name="d" size="2"/></td><td><select name="m"/><option value="Jan">January</option><option value="Feb">February</option><option value="Mar">March</option><option value="Apr">April</option><option value="May">May</option><option value="Jun">June</option><option value="Jul">July</option><option value="Aug">August</option><option value="Sep">September</option><option value="Oct">October</option><option value="Nov">November</option><option value="Dec">December</option></select></td><td><select name="y"/><option value="1990">1990</option><option value="1991">1991</option><option value="1992">1992</option><option value="1993">1993</option><option value="1994">1994</option><option value="1995">1995</option><option value="1996">1996</option><option value="1997">1997</option></select></td></tr></table><br/>Address (Eng): (thana,distric,country)<br/><input type="text" name="address"/><br/>Blad group:<br/><input type="text" name="blad"/><br/>Singanutre (Eng):<br/><input type="text" name="sign"/><br/><input type="radio" name="privacy" value="1"/> আমি উপরের শর্ত বুজলাম এবং কথা দিলাম শর্তের বাহিরে যাবো না ।<br/><input type="submit" name="ok" value="Create NID Card" class="btnC"/></form><br/><br/>'; $total_id=mysql_result(mysql_query("SELECT COUNT(*) FROM `nid_card`"),0); echo"<br/><center><b>Total $total_id NID Card Made by us</b></center>"; echo'</div>'; 
 ?>  