<?

echo "<a href='/info.php?info'>My Profile</a><br/>";
echo "<a href='/anketa.php'>Edit Profile</a><br/>";
echo "<a href='/addinfo.php'>Edit Info</a><br/>";
echo "<a href='/interest.php'>Edit Interests</a><br/>";
echo "<a href='/educat.php'>Edit Education</a><br/>";

$opdirbase=@opendir(H.'sys/add/umenu');
while ($filebase=@readdir($opdirbase))
if (eregi('\.php$',$filebase))
include_once(H.'sys/add/umenu/'.$filebase);

echo "<a href='/avatar.php'>Change Photo</a><br/>";
echo "<a href='/secure.php'>Change Password</a><br/>";
echo "<a href='/settings.php'>Settings</a><br/>";
echo "<a href='/rules.php'>Rules</a><br/>";

if (user_access('adm_panel_show'))echo "<a href='/adm_panel/'>Admin Panel</a><br/>";

if ($set['web']==false)
echo "<div class='penanda'>User</div><a href='/exit.php'>Exit</a><br/>";
?>
