<?

echo"<div class='penanda'><br/>";
include_once 'adv/sponser.php';
 $res = mysql_query("SELECT * FROM `statuse_list` WHERE `privat` = '0' ORDER BY id DESC LIMIT 15");

while ($statuse = mysql_fetch_array($res)){
if (isset($_GET['tidak']) && isset($user))
{
mysql_query("DELETE FROM `statuse_like` WHERE `id_user` = '$user[id]' AND `id_statuse` = '".intval($_GET['id'])."' LIMIT 1");
}
$string=output_text($statuse['msg'])." ";

$ank=get_user($statuse['id_user']);
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `ban` WHERE `id_user` = '$ank[id]' AND `time` > '$time'"), 0)!=0){ } else{ echo'<div class="status" style="border: 1px #c4c6ca solid; padding-top:6px;padding:5px;"><font color="black">'; if ($ank['ank_name']!=NULL){
echo "<a href='info.php?id=$ank[id]'><b>$ank[ank_name]</b></a><br/>"; } else{ echo"<a href='info.php?id=$ank[id]'><b>$ank[nick]</b></a><br/>";}  
if (strlen2($statuse['msg'])>500){$string =output_text($statuse['msg'])." "; $string = strip_tags($string);
if (strlen($string) > 500) {
   
   $stringCut = substr($string, 0, 500);
      $string = substr($stringCut, 0, strrpos($stringCut, ' ')).'.....<a href="list.php?id='.$statuse['id'].'">Read more</a> ';
}
echo "$string";} else{ echo output_text($statuse['msg'])." "; }

 
echo "<br/>";
echo "<font class='time' size='2'>".waktu($statuse['time'])."</font></br>";
if($statuse['kategori']==0){

$anu = mysql_result(mysql_query("SELECT COUNT(*) FROM `statuse_like` WHERE `id_statuse` = '$statuse[id]'"),0);
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `statuse_like` WHERE `id_statuse` = '$statuse[id]' AND `id_user` = '$user[id]' LIMIT 1"),0)==0){
if($anu==0){
echo " &#183; <a href='status/like.php?id=".$statuse['id']."&amp;like'>Like</a>";} else {
echo " &#183; <a href='status/like_all.php?id=".$statuse['id']."'><img src='status/suka.gif' width='12' height='13'> $anu</a> &#183; <a href='status/like.php?id=".$statuse['id']."&amp;like'>Like</a>";
}
}
else
{
if($anu==0){
echo " &#183; <a href='status/like.php?id=".$statuse['id']."&amp;tidak'>Unlike</a>";} else {
echo " &#183; <a href='/status/like_all.php?id=".$statuse['id']."'><img src='status/suka.gif' width='12' height='13'> $anu</a> &#183; <a href='/status/like.php?id=".$statuse['id']."&amp;tidak'>Unlike</a>";
}
}

$cmn=mysql_result(mysql_query("SELECT COUNT(*) FROM `statuse_komm` WHERE `id_statuse` = '$statuse[id]'"),0);
if(mysql_result(mysql_query("SELECT COUNT(*) FROM `statuse_komm` WHERE `id_statuse` = '$statuse[id]'"),0)==0){
echo " &#183; <a href='list.php?id=".$statuse['id']."'>Comment</a>\n";
}
else
{
if(mysql_result(mysql_query("SELECT COUNT(*) FROM `statuse_komm` WHERE `id_statuse` = '$statuse[id]'"),0)==1){
echo " &#183; <a href='list.php?id=".$statuse['id']."'>1 Comment</a>\n";
}
else
{
echo " &#183; <a href='list.php?id=".$statuse['id']."'>$cmn Comments</a>\n";
}
}
echo "<a href='/status/share.php?id=".$statuse['id']."&s'>Share</a>\n";
}
if($statuse['kategori']==2){

$anu = mysql_result(mysql_query("SELECT COUNT(*) FROM `photo_like` WHERE `id_photo` = '$ank[id]'"),0);
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `photo_like` WHERE `id_photo` = '$ank[id]' AND `id_user` = '$user[id]' LIMIT 1"),0)==0){
if($anu==0){
echo " &#183; <a href='primary.php?id=".$ank['id']."&amp;like'>Like</a>";} else {
echo " &#183; <a href='status/photolike_all.php?id=".$ank['id']."'><img src='status/suka.gif' width='12' height='13'> $anu</a> &#183; <a href='primary.php?id=".$ank['id']."&amp;like'>Like</a>";
}
}
else
{
if($anu==0){
echo " &#183; <a href='primary.php?id=".$ank['id']."&amp;tidak'>Unlike</a>";} else {
echo " &#183; <a href='/status/photolike_all.php?id=".$ank['id']."'><img src='status/suka.gif' width='12' height='13'> $anu</a> &#183; <a href='primary.php?id=".$ank['id']."&amp;tidak'>Unlike</a>";
}
}

$cmn=mysql_result(mysql_query("SELECT COUNT(*) FROM `photo_komm` WHERE `user_id` = '$ank[id]'"),0);
if(mysql_result(mysql_query("SELECT COUNT(*) FROM `photo_komm` WHERE `user_id` = '$ank[id]'"),0)==0){
echo " &#183; <a href='primary.php?id=".$ank['id']."'>Comment</a>\n";
}
else
{
if(mysql_result(mysql_query("SELECT COUNT(*) FROM `photo_komm` WHERE `user_id` = '$ank[id]'"),0)==1){
echo " &#183; <a href='primary.php?id=".$ank['id']."'>1 Comment</a>\n";
}
else
{
echo " &#183; <a href='primary.php?id=".$ank['id']."'>$cmn Comments</a>\n";
}
}

echo "<a href='/status/share.php?id=".$ank['id']."&p'>Share</a>\n";}
if($statuse['kategori']==3){
$gallery=mysql_fetch_array(mysql_query("SELECT * FROM `gallery_foto` WHERE `id` = '$statuse[cat]';"));

$anu = mysql_result(mysql_query("SELECT COUNT(*) FROM `gallery_like` WHERE `id_photo` = '$statuse[cat]'"),0);
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `gallery_like` WHERE `id_photo` = '$statuse[cat]' AND `id_user` = '$user[id]' LIMIT 1"),0)==0){
if($anu==0){
echo " &#183; <a href='foto/$ank[id]/$gallery[id_gallery]/komm/$statuse[cat]/?like'>Like</a>";} else {
echo " &#183; <a href='status/gallerylike_all.php?id=".$statuse['cat']."'><img src='status/suka.gif' width='12' height='13'> $anu</a> &#183; <a href='foto/$ank[id]/$gallery[id_gallery]/komm/$statuse[cat]/?like'>Like</a>";
}
}
else
{
if($anu==0){
echo " &#183; <a href='foto/$ank[id]/$gallery[id_gallery]/komm/$statuse[cat]/?tidak'>Unlike</a>";} else {
echo " &#183; <a href='/status/gallerylike_all.php?id=".$statuse['cat']."'><img src='status/suka.gif' width='12' height='13'> $anu</a> &#183; <a href='foto/$ank[id]/$gallery[id_gallery]/komm/$statuse[cat]/?tidak'>Unlike</a>";
}
}

$cmn=mysql_result(mysql_query("SELECT COUNT(*) FROM `gallery_komm` WHERE `id_foto` = '$statuse[cat]'"),0);
if(mysql_result(mysql_query("SELECT COUNT(*) FROM `gallery_komm` WHERE `id_foto` = '$statuse[cat]'"),0)==0){
echo " &#183; <a href='foto/$ank[id]/$gallery[id_gallery]/komm/$statuse[cat]/'>Comment</a>\n";
}
else
{
if(mysql_result(mysql_query("SELECT COUNT(*) FROM `gallery_komm` WHERE `id_foto` = '$statuse[cat]'"),0)==1){
echo " &#183; <a href='foto/$ank[id]/$gallery[id_gallery]/komm/$statuse[cat]/'>1 Comment</a>\n";
}
else
{
echo " &#183; <a href='foto/$ank[id]/$gallery[id_gallery]/komm/$statuse[cat]/'>$cmn Comments</a>\n";
}
}

echo "<a href='/status/share.php?id=".$statuse['cat']."&a'>Share</a>\n";} echo"</font></div>";} } include_once 'pagestatus.php';
echo"</div>";
 ?>

