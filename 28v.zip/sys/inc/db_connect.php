<?
$dbname = "ictu_16920736_fb";
$dbhost = "sql209.icthost.tk";
$dbuser = "ictu_16920736";
$dbpass = "raju1998";
$db=@mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_connect($dbhost,$dbuser,$dbpass);

if (!@mysql_select_db($dbname,$db))
{
echo "Database Conection faild<br /> Try to fix it.";
exit;
}


mysql_query('set charset utf8',$db);
mysql_query('SET names utf8',$db);
mysql_query('set character_set_client="utf8"',$db);
mysql_query('set character_set_connection="utf8"',$db);
mysql_query('set character_set_result="utf8"',$db);

?>