<?

// created by noe
// http://nnetwork.tk
// loegue.info@gmail.com

echo "<a href='/anketa.php'>User Information</a><br />\n";
echo "<a href='/addinfo.php'>Additional Information</a><br />\n";
echo "<a href='/interest.php'>Like and Interest</a><br />\n";
echo "<a href='/educat.php'>Education and Work</a><br />\n";

?>
