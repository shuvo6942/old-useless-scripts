<?echo "<a href='/foto/$user[id]/'>Albums</a><br />\n";?>
