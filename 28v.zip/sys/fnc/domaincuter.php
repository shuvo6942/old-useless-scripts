<? function domaincutter($url)
{ $reg_exUrl = "/(http|https|ftp|ftps)\:\/\/[a-zA-Z0-9\-\.]+\.[a-zA-Z]{2,3}(\/\S*)?/";


if (preg_match($reg_exUrl ,$url)) { $parts = explode( "/" , $url );
array_shift($parts ); array_shift($parts ); array_shift($parts );
$newurl = implode( "/", $parts ); $newurl = str_replace(array("\n","\r"),'',$newurl);

return"$newurl" ; 
} else{ return"$url";}
} ?>