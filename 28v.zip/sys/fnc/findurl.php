<?php
function click($text)
{ $reg_exUrl = "/(http|https|ftp|ftps)\:\/\/www\.[a-zA-Z0-9\-\.]+\.[a-zA-Z]{2,3}(\/\S*)?/";


if (preg_match($reg_exUrl , $text , $url))  {preg_replace($reg_exUrl , $url[0], $text );
return $url[0];
}
 }
 ?>
