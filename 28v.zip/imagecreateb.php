<? 

 ##### start generating Facebook ID ########$image_id_png       = 'id.jpg'; 
$temp_folder        = 'tmp/'; //temp dir path to store images$fbuser='1';
$font               = 'fonts/DidactGothic.ttf';  $fon               = 'fonts/akshar.ttf';  $fontb               = 'assets/fonts/arialbd.ttf'; $fontbl               = 'assets/fonts/arialbda.ttf'; $sinf               = 'assets/fonts/Absinthe.ttf';   $dest = imagecreatefromjpeg($image_id_png); // source id card image template
    $src = imagecreatefromjpeg($temp_folder.$fbuser.'.jpg'); //facebook user image stored in our temp folder
    
    imagealphablending($dest, false); 
    imagesavealpha($dest, true);
    
    //merge user picture with id card image template
    //need to play with numbers here to get alignment right
    imagecopymerge($dest, $src, 9, 80, 0, 0, 90, 97, 90);  

    
    //colors we use for font
    $facebook_blue = imagecolorallocate($dest, 81, 103, 147); // Create blue color
    $facebook_grey = imagecolorallocate($dest, 74, 74, 74); $black = imagecolorallocate($dest, 0, 0, 0); // Create grey color$red = imagecolorallocate($dest, 255, 0, 0);
    
    //Texts to embed into id card image template
    $id_no        = '13149840022698';
    $name_bangla      = 'ওসমান গণী';
$name_english      = 'Osman Gani';
    $mother    = 'জেসমিন বেগম';
    $father  = 'মোস্তফা কামাল ';
    $for_birthdate     = '08 Nov 1995';
    $sing          = 'Osman';
    $given_date         = '3rd february 2014';  $address         = 'Chandpur,chittagong,bangladesh'; 
$blad='A-';    imagealphablending($dest, true); //bring back alpha blending for transperent font
    
    imagettftext($dest, 17, 0, 175, 225, $red , $fontbl, $id_no); //Write user id to id card
    imagettftext($dest, 15, 0, 157, 104, $black, $fon, $name_bangla); //Write name to id card
    imagettftext($dest, 12, 0, 157, 126, $black, $fontbl, $name_english); //Write gender to id card
    imagettftext($dest, 15, 0, 157, 153, $black, $fon, $father); //Write hometown to id card
    imagettftext($dest, 13, 0, 206, 198, $red, $fontbl, $for_birthdate); //Write birthday to id card
    imagettftext($dest, 16, 0, 21, 209, $black, $sinf, $sing); //Write custom text to id card
    imagettftext($dest, 15, 0, 157, 178, $black, $fon, $mother); imagettftext($dest, 12, 0, 78, 308, $black, $fontbl, $address);  imagettftext($dest, 12, 0, 78, 367, $red, $fontbl, $blad); imagettftext($dest, 11, 0, 282, 423, $black, $fontbl, $given_date);        
    imagepng($dest, $temp_folder.'id_'.$fbuser.'.jpg'); //save id card in temp folder

	//now we have generated ID card, we can display or post it on facebook
    echo '<img src="tmp/id_'.$fbuser.'.jpg" >'; //display saved user id card
     echo '<a href="tmp/id_'.$fbuser.'.jpg" >Download</a>';
    /* or output image to browser directly
    header('Content-Type: image/png');
    imagepng($dest); ?>