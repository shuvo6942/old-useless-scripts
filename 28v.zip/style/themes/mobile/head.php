<?
$set['web']=false;
//header("Content-type: application/vnd.wap.xhtml+xml");
//header("Content-type: application/xhtml+xml");
header("Content-type: text/html");
echo '<?xml version="1.0" encoding="utf-8"?>';
?><!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru">
<head><title><?echo $set['title'];?></title>
<link rel="shortcut icon" href="/favicon.ico" />
<link rel="stylesheet" href="/style/themes/<?echo $set['set_them'];?>/style.css" type="text/css" />
<link rel="stylesheet" href="/style/themes/<?echo $set['set_them'];?>/fb.css" type="text/css" />
</head>
<body>
<?
if(isset($user)){echo' <a name="top"></a><div tabindex="0" class="b c d"><div class="e"><div id="viewport"><div class="f"><div class="g h" id="header"><form method="post" class="i j" action="/users.php?go&amp;sort=$sort&amp;$por"><input type="hidden" name="refid" value="7" /><input type="hidden" name="search" value="Search" /><input type="hidden" name="search_source" value="top_nav" /><table class="k"><tbody><tr><td class="l"><a class="m n o" href="/index.php"><img src="/style/themes/'.$set[set_them].'/i.png" width="20" height="20" class="p img" alt="FC" /></a></td><td class="l"> <a class="m n o" href="/info.php?id='.$user[id].'">'; if(is_file(H."sys/avatar/$user[id].jpg")){
echo "<img src='/sys/avatar/$user[id].jpg' alt='' width='20' height='20'/>";}
else{
echo "<img src='/style/themes/$set[set_them]/user.png' alt='' width='20' height='20'/>";}
 echo'</a></td><td class="q r"><input class="s t u" name="usearch" placeholder="Find friends,pages,group" autocomplete="off" autocorrect="off" spellcheck="false" type="text" /></td><td class="l"><input type="image" class="v w x y" src="/logolock/search.jpg" width="21" height="20" alt="Find">
</td></tr></tbody></table></form></div></div></div></div></div>';
}

echo'<style>.bdyn{background:#
fff;display:block;text-
align:center;padding:0px
2px;font-site:x-small} .bdy4n{white-
space:nowrap;display:block;
padding: 10px 2px 10px
2px;margin-left:-2px} .bdy4nr{white-
space:nowrap;display:block;
padding: 10px 2px 10px
2px;margin-left:-2px; font-color:#e41b7; color;#e41b17;}</style>';
if(isset($user)){
echo'<div class="bdyn"><table width="100%" cellspecing="0px" cellspacing="0px" style="vertical-align:middle"><tbody><tr>'; 

if($_SERVER['PHP_SELF']=='/online_ch.php'){$knm=mysql_result(mysql_query("SELECT COUNT(*) FROM `user` WHERE `date_last` >".(time()-600).""), 0);if($knm==0){$requestchat="Chat";} else{ $requestchat="Chat($knm)";} echo'<td width="20%" style="background:#fff;width:25px;overflow:hidden;padding:4px; border-right: 1px solid #41a317"><a class="bdy4nr" href="/online_ch.php?SESS='.$sess.'"><center><img style="vertical-align:middle;" src="/logolock/chatread.jpg" width="15" height="15" /></center><center><div style="background:#fff;padding:4px; border-bottom: 2px solid #e41b17; color;#e41b17;"><font color="#e41b17">'.$requestchat.'</font></div></center></a></td>'; 

}
else
{$knm=mysql_result(mysql_query("SELECT COUNT(*) FROM `user` WHERE `date_last` >".(time()-600).""), 0); if($knm==0){$requestchat="Chat";} else{ $requestchat="Chat($knm)";}  echo'<td width="20%" style="background:#fff;width:20px;overflow:hidden;padding:4px; border-right: 1px solid #41a317"><a class="bdy4n" href="/online_ch.php?SESS='.$sess.'"><center><img style="vertical-align:middle;" src="/logolock/chathome.jpg" width="15" height="15" /></center><br/><center><span class="cm"><font color="#41a317">'.$requestchat.'</font></span></center></a></td>'; 
}
if($_SERVER['PHP_SELF']=='/mail.php'){$knm=mysql_result(mysql_query("SELECT COUNT(*) FROM `mail` WHERE `id_kont` = '$user[id]' AND `read` = '0'"), 0);if($knm==0){$requestmail="SMS";} else{ $requestmail="SMS($knm)";}  
 echo'<td width="20%" style="background:#fff;width:20px;overflow:hidden;padding:4px; border-right: 1px solid #41a317"><a class="bdy4nr" href="/mail.php?SESS='.$sess.'"><center><img style="vertical-align:middle;" src="/logolock/msgread.jpg" width="15" height="15" /></center><center><div style="background:#fff;padding:4px; border-bottom: 2px solid #e41b17; color;#e41b17;"><font color="#e41b17">'.$requestmail.'</font></div></center></a></td>'; 
}
else{$knm=mysql_result(mysql_query("SELECT COUNT(*) FROM `mail` WHERE `id_kont` = '$user[id]' AND `read` = '0'"), 0);
if($knm==1){$mank=mysql_fetch_assoc(mysql_query("SELECT * FROM `mail` WHERE `id_kont` =' $user[id]' AND `read` = '0' ORDER BY `time` DESC LIMIT 1")); $manku=mysql_fetch_assoc(mysql_query("SELECT * FROM `user` WHERE `id` =' $mank[id_user]' LIMIT 1")); if (is_file(H."sys/avatar/$mank[id_user].jpg")){$img="/sys/avatar/$mank[id_user].jpg";
 } else{$img="/logolock/msghome.jpg";}
$parts="$manku[ank_name]"; $parts = explode(' ', $parts, 2);
$mankus = $parts[0];

echo'<td width="20%" style="background:#fff;width:20px;overflow:hidden;padding:4px; border-right: 1px solid #41a317"><a class="bdy4n" href="/mail.php?id='.$mank[id_user].'&SESS='.$sess.'"><center><img style="vertical-align:middle;" src="'.$img.'" width="15" height="15" /></center><br/><center><span class="cm"><font color="#e41b17">'.$mankus.'(1)</font></span></center></a></td>';} else{ if($knm>=2){echo'<td width="20%" style="background:#fff;width:20px;overflow:hidden;padding:4px; border-right: 1px solid #41a317"><a class="bdy4n" href="/mail.php?SESS='.$sess.'"><center><img style="vertical-align:middle;" src="/logolock/msgread.jpg" width="15" height="15" /></center><br/><center><span class="cm"><font color="#e41b17">'; if($knm==0){echo'SMS';} else{echo'SMS('.$knm.')';} echo'</font></span></center></a></td>';} else{echo'<td width="20%" style="background:#fff;width:20px;overflow:hidden;padding:4px; border-right: 1px solid #41a317"><a class="bdy4n" href="/mail.php?SESS='.$sess.'"><center><img style="vertical-align:middle;" src="/logolock/msghome.jpg" width="15" height="15" /></center><br/><center><span class="cm"><font color="#41a317">'; if($knm==0){echo'SMS';} else{echo'SMS('.$knm.')';} echo'</font></span></center></a></td>';} } }

if($_SERVER['PHP_SELF']=='/frend.php'){
$knm=mysql_result(mysql_query("SELECT COUNT(*) FROM `frends_new` WHERE `to` = '$user[id]'"), 0);
if($knm==0){$requestfriend="Friends";} else{ $requestfriend="Friends($knm)";} echo'<td width="20%" style="background:#fff;width:20px;overflow:hidden;padding:4px; border-right: 1px solid #41a317"><a class="bdy4nr" href="/frend.php?SESS='.$sess.'"><center><img style="vertical-align:middle;" src="/logolock/friendread.jpg" width="15" height="15" /></center><center><div style="background:#fff;padding:4px; border-bottom: 2px solid #e41b17; color;#e41b17;"><font color="#e41b17">'.$requestfriend.'</font></div></center></a></td>'; 
}
else{
$knm=mysql_result(mysql_query("SELECT COUNT(*) FROM `frends_new` WHERE `to` = '$user[id]'"), 0);
if($knm==0){$requestfriend="Friends";} else{ $requestfriend="Friends($knm)";} if($knm!=0){echo'<td width="20%" style="background:#fff;width:20px;overflow:hidden;padding:4px; border-right: 1px solid #41a317"><a class="bdy4n" href="/frend.php?SESS='.$sess.'"><center><img style="vertical-align:middle;" src="/logolock/friendread.jpg" width="15" height="15" /></center><br/><center><span class="cm"><font color="#e41b17">'.$requestfriend.'</font></span></center></a></td>'; 
} else{echo'<td width="20%" style="background:#fff;width:20px;overflow:hidden;padding:4px; border-right: 1px solid #41a317"><a class="bdy4n" href="/frend.php?SESS='.$sess.'"><center><img style="vertical-align:middle;" src="/logolock/friendhome.jpg" width="15" height="15" /></center><br/><center><span class="cm"><font color="#41a317">'.$requestfriend.'</font></span></center></a></td>'; 
}
}


if($_SERVER['PHP_SELF']=='/jurnal.php'){
$knm=mysql_result(mysql_query("SELECT COUNT(*) FROM `jurnal` WHERE `id_kont` = '$user[id]' AND `read` = '0'"), 0);if($knm==0){$requestn="Alart";} else{ $requestn="Alart($knm)";}  echo'<td width="20%" style="background:#fff;width:20px;overflow:hidden;padding:4px; border-right: 1px solid #41a317"><a class="bdy4nr" href="/jurnal.php?SESS='.$sess.'"><center><img style="vertical-align:middle;" src="/logolock/notiread.jpg" width="15" height="15" /></center><center><div style="background:#fff;padding:4px; border-bottom: 2px solid #e41b17; color;#e41b17;"><font color="#e41b17">'.$requestn.'</font></div></center></a></td>'; 

}
else{
$knm=mysql_result(mysql_query("SELECT COUNT(*) FROM `jurnal` WHERE `id_kont` = '$user[id]' AND `read` = '0'"), 0);if($knm==0){$requestn="Alart";} else{ $requestn="Alart($knm)";} if($knm!=0){echo'<td width="20%" style="background:#fff;width:20px;overflow:hidden;padding:4px; border-right: 1px solid #41a317"><a class="bdy4n" href="/jurnal.php?SESS='.$sess.'"><center><img style="vertical-align:middle;" src="/logolock/notiread.jpg" width="15" height="15" /></center><br/><center><span class="cm"><font color="#e41b17">'.$requestn.'</font></span></center></a></td>'; 
}  else { echo'<td width="20%" style="background:#fff;width:20px;overflow:hidden;padding:4px; border-right: 1px solid #41a317"><a class="bdy4n" href="/jurnal.php?SESS='.$sess.'"><center><img style="vertical-align:middle;" src="/logolock/notihome.jpg" width="15" height="15" /></center><br/><center><span class="cm"><font color="#41a317">'.$requestn.'</font></span></center></a></td>'; 
}
}
if($_SERVER['PHP_SELF']=='/menu2015.php'){
echo'<td width="20%" style="background:#fff;width:20px;overflow:hidden"><a class="bdy4nr" href="/menu2015.php?SESS='.$sess.'"><center><img style="vertical-align:middle;" src="/logolock/moreread.jpg" width="15" height="15" /></center><center><div style="background:#fff;padding:4px; border-bottom: 2px solid #e41b17; color;#e41b17;"><font color="#e41b17">More</font></div></center></a></td>'; 

}
else{
echo'<td width="20%" style="background:#fff;width:20px;overflow:hidden"><a class="bdy4n" href="/menu2015.php?SESS='.$sess.'"><center><img style="vertical-align:middle;" src="/logolock/morehome.jpg" width="15" height="15" /></center><br/><center><span class="cm"><font color="#41a317">More</font></span></center></a></td>'; 

} echo'</tr></tbody></table></div><div style="background:#fff;border-bottom: 1px solid #41a317"></div>';} 
if(!isset($user)){
echo'<div tabindex="0" class="b c d"><div class="e"><div id="viewport"><div class="f"><div class="g h" id="header">'; echo"<table><tr><td><img class=\"img\" src=\"/style/themes/$set[set_them]/logo.png\" id=\"facebook_logo\" alt=\"FoortiClub\" title=\"forceimage\" width=\"86%\" height=\"30\" /></td></tr></table></div></div></div></div></div><title>Welcome to FoortiClub </title>";}

?>
