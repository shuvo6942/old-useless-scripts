<?php
function destroy($dir) {$mydir = opendir($dir);
while($file = readdir($mydir)) {
    if($file != "." && $file !="..") {
        chmod($dir.$file,0777);
        if(is_dir($dir.$file)) {
            chdir('.');
            while($dir.$file) {
                if(date("U",filectime($file) >= time() - 3600))
                {        unlink($dir.$file);
                }
            }
        }
        else
            unlink($dir.$file);
or DIE("couldn't delete $dir $file<br />");
    }
}
closedir($mydir);
}
destroy("tmp/");
echo destory("tmp/"); ?>