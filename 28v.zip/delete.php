<?php
/** define the directory **/
$dir = "tmp/";
/*** cycle through all files
in the directory ***/
foreach (glob($dir."*.jpg") as $file) {
/*** if file is 24 hours
(86400 seconds) old then
delete it ***/
if (filemtime($file) < time() -3600) {
    unlink($file);
    }
}
?>