<?php include_once 'sys/inc/start.php';
include_once 'sys/inc/compress.php';
include_once 'sys/inc/sess.php';
include_once 'sys/inc/home.php';
include_once 'sys/inc/settings.php';
include_once 'sys/inc/db_connect.php';
include_once 'sys/inc/ipua.php';
include_once 'sys/inc/fnc.php';


$set['title']='Download';   
include_once 'sys/inc/thead.php';
echo'<style type="text/css">.bs{appearance:none;background:none;display:inline-block;font-size:12px;height:28px;line-height:28px;margin:0;color:#ffffff;overflow:visible;padding:0 9px;text-align:center;vertical-align:top;white-space:nowrap;} .bs{border-radius:2px;}.bx{background-color:#4e69a2;border:1px solid #385490;} background: #fff;
padding: 3px; border: solid
1px #ddd; }
.bu{background-color:#E42217;border:1px solid #E42217;} .buv{background-color:#e41b17;border:1px solid #FCDFFF;}.b z::after{content:"";display:inline-block;height:100%;vertical-align:middle;} .bz{height:26px;line-height:26px;}</style>';

$card=intval($_GET['card']);
$filename= "tmp/id_$card.jpg";
if(file_exists($filename)) { echo "<div class='status'><font color='red'><b>This ID Card delete from our site after 1 hour from created time. So Download and save your computer/mobile.<br/>Again we say for mind card privacy<hr/>NID CARD:<hr/></b></font><center><img src='tmp/id_$card.jpg' ></div><br/>"; 
     echo "<br/><a href='/tmp/id_$card.jpg' ><div style='padding:6px;padding-left:5px;background:#e41b17'>Download and save</div></a><br/> <b> If you are not able to download by click downlad button Plz copy the link and past your browser address bar<br/><a href='http://idcard.22web.org/tmp/id_$card.jpg'>http://idcard.22web.org/tmp/id_$card.jpg</a><br/><textarea>http://idcard.22web.org/tmp/id_$card.jpg</textarea> </center>"; } else{ echo"<div class='status'><b>OPPs Not found</b></div>";}  ?>