<?php get_header(); ?> 
             
        
										<div class="clear"></div>
                             <div class="block_posts">
<h2>Recent post</h2>
								<ul class="rpul">
                                    <?php if(have_posts()) : ?>
                                    <?php while(have_posts()) : the_post(); ?>
                                      
                    
					
										<li>
										<?php the_post_thumbnail('post-image', array('class' => 'post-thumb')); ?>
											                <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a>
												<p><?php echo human_time_diff( get_the_time('U'), current_time('timestamp') ) . ' ago'; ?> <?php comments_popup_link('No Comment', '1  Comment', '% comments'); ?> <font color="gray"> <?php if(function_exists('the_views')) { the_views(); } ?></font> </font></p>
										</li>
                                    <?php endwhile; ?>
                                    </ul>
           
                    
                                    <?php else : ?>
                    
                                        <div class="post" id="post-<?php the_ID(); ?>">
                                            <h2><?php _e('No posts are added.'); ?></h2>
                                        </div>
                    
                                    <?php endif; ?>
                                    
                                </div>

										<div class="wp-pagenavi">
											<?php echo paginate_links( $args ); ?>
										</div>
										<div class="clear"></div>

 <!--entry-->

<div class="clear"></div></div>

		<?php dynamic_sidebar('Categories'); ?>	

        <?php get_footer(); ?>        