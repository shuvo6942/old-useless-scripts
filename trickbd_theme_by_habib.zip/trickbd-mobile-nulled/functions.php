<?php

add_filter('show_admin_bar', '__return_false');
/* SIDEBARS */
if ( function_exists('register_sidebar') )

	
	register_sidebar(array(
	'name' => 'topuser',
    'before_widget' => '<div class="sidebar-box">',
    'after_widget' => '</div>',
	'before_title' => '<h2>',
    'after_title' => '</h2>',
	));		
	register_sidebar(array(
	'name' => 'Categories',
    'before_widget' => '<div class="block_category">',
    'after_widget' => '</div>',
	'before_title' => '<h2>',
    'after_title' => '</h2>',
	));	
	
add_filter('the_content', 'wpse_ad_content');

function wpse_ad_content($content)
{
    if (!is_single()) return $content;
    $paragraphAfter = 2; //Enter number of paragraphs to display ad after.
    $content = explode("</p>", $content);
    $new_content = '';
    for ($i = 0; $i < count($content); $i++) {
        if ($i == $paragraphAfter) {
            $new_content.= '<div align="center">';
            $new_content.= '<div class="clear"></div><script type="text/javascript" src="http://wap4dollar.com/ad/codex/?id=9owcdvkf1w"></script>
<!-- Mobile Head -->
<script type="text/javascript" src="http://wap4dollar.com/ad/codex/?id=9owcdvkf1w"></script><div class="clear"></div>';
            $new_content.= '</div>';
        }

        $new_content.= $content[$i] . "</p>";
    }

    return $new_content;
}


/* CUSTOM MENUS */	
register_nav_menus( array(
		'primary' => __( 'Primary Navigation', '' ),
	) );
	

function fallbackmenu(){ ?>
			<div id="submenu">
				<ul><li style="color:#fff"> Go to Adminpanel > Appearance > Menus to create your menu. You should have WP 3.0+ version for custom menus to work.</li></ul>
			</div>
<?php }	


/* FEATURED THUMBNAILS */

add_theme_support( 'post-thumbnails', array( 'post' ) );
set_post_thumbnail_size( 200, 200, true );
add_image_size( 'post-image', 70, 70, true );
add_image_size( 'post-selected', 268, 300, true );



?>
<?php 



/* This code for readmore */

function excerpt($num) {

$limit = $num+1;

$excerpt = explode(' ', get_the_excerpt(), $limit);

array_pop($excerpt);

$excerpt = implode(" ",$excerpt)." ....!";

echo $excerpt;

}



?>
