# Unicode2Bijoy
PHP class to convert unicode to Bijoy ANSI.
#### Install via composer

```shell
composer require mirazmac/unicode2bijoy
```

### Example

```php
$str='জানার আছে অনেক কিছু!';
echo mirazmac\Unicode2Bijoy::convert($str);
```

### Boring Legal Stuff

Unicode2Bijoy is licensed under **The MIT license**. I'll be happy if you contribute and improve this class. Don't forget to report bug(s). 

There should be some of 'em :p '