<?php get_header(); ?>

<div id="page_start">

<div class="sponsored_block">
<h2>Sponsored Post</h2>
<ul></ul>
</div>
<div class="clear"></div>

<div class="main_block">

<div class="main_left">
<h2><div class="breadcumbs">
<div id="crumbs"><a href="/">Home</a> › <span class="current">Posts tagged '<?php single_tag_title(); ?>'</span></div></div>
</h2>

<ul>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<li>
<h3><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h3><br/><a href="<?php the_permalink(); ?>"><?php
// Feature post thumbnail.

if ( has_post_thumbnail() ) {
	the_post_thumbnail( 'medium' );
}
else {
	echo '<img width="110" height="75" src="' . get_bloginfo( 'template_url' ) . '/images/no-thumbnail-110x75.png" class="attachment-thumbnail wp-post-image" alt="No image" />';
} ?></a>
<h5>
<div class="pad4"><?php the_author_posts_link(); ?> on <?php the_category( ', ' ) ?> at <span><?php echo human_time(); ?></span></div>
<div><?php the_time( get_option( 'time_format' ) ) ?> | <span><a href="<?php the_permalink(); ?>#comments"><?php comments_number( 'No Comment', '1 Comment', '% Comments' ); ?></a></span> | <?php echo getPostViews(get_the_ID()); ?></div>
</h5>
<p><?php echo wp_trim_words( get_the_content(),25, '<a href="'. get_permalink($post->ID) . '">Read More</a>' ); ?></p>
</li>
<?php endwhile; else: ?>
<?php endif; ?>
</ul>
<div class="clear"></div>

<?php wp_pagenavi(); ?>
<div class="clear"></div>
</div>

<?php get_sidebar(); ?>
</div>

</div>

<?php get_footer(); ?>