<div class="links_block">
<div class="link_left">
<div class="menu-pc-footer-container"><ul id="menu-pc-footer" class="menu">
<li id="menu-item-53" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-53"><a href="/terms">Terms</a></li>
<li id="menu-item-54" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-54"><a href="/privacy">Privacy</a></li>
<li id="menu-item-55" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-55"><a href="/faq">FAQ</a></li>
<li id="menu-item-56" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-56"><a href="/copyright">Copyright</a></li>
<li id="menu-item-60" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-60"><a href="/contact">Contact Us</a></li>
<li id="menu-item-61" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-61"><a href="/advertise">Advertise</a></li>
<li id="menu-item-62" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-62"><a href="/about">About</a></li>
</ul>
</div>
</div>

<div class="link_right">
<ul>
<li><small><?php echo do_shortcode('[show_theme_switch_link]'); ?></small></li>
</ul>
</div>
</div>
<div class="clear"></div>

<div class="footer_block fix">
<div class="footer_left">Copyright 2016 </div><div class="footer_right">Powered by <a href="http://appsplorer.ml">Appsplorer Team</a> and <a href="">Wordpress</a></div>
</div>

<script type='text/javascript' src='<?php bloginfo( 'template_url' ); ?>/js/jquery.sticky-kit.min.js'></script>

<script type='text/javascript' src='<?php bloginfo( 'template_url' ); ?>/js/script.js'></script>

</body>
</html>