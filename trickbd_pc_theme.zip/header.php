<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta charset="<?php bloginfo('charset'); ?>" />

<title><?php wp_title(); ?></title>

<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>?ver=1.3" />

<link rel="shortcut icon" type="image/x-icon" href="<?php bloginfo( 'template_url' ); ?>/favicon.ico" />

<link rel="stylesheet" href="<?php bloginfo( 'template_url' ); ?>/css/font-awesome.min.css" media="all" />

<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
<?php wp_head(); ?>
<style type="text/css" title="dynamic-css" class="options-output">.ad_block{border-top:1px solid #ddd;border-bottom:1px solid #ddd;border-left:1px solid #ddd;border-right:1px solid #ddd;}.ad_block{margin-top:4px;margin-right:4px;margin-bottom:4px;margin-left:4px;}.ad_block{padding-top:4px;padding-right:4px;padding-bottom:4px;padding-left:4px;}.ad_block_pc{border-top:0px solid #ddd;border-bottom:0px solid #ddd;border-left:0px solid #ddd;border-right:0px solid #ddd;}.ad_block_pc{margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;}.ad_block_pc{padding-top:0;padding-right:0;padding-bottom:0;padding-left:0; }</style>
</head>
<body>
<div class="full_col">

<div class="top_block">
<?php
if ( is_user_logged_in() ) {

    $current_user = wp_get_current_user();
	echo '<table width="100%"><tr>
<td class="fleft"><div class="menu-top-pc-logged-container"><ul id="menu-top-pc-logged" class="menu">
<li id="menu-item-40" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-40"><a href="/wp-admin">Hi, <b>'.$current_user->display_name.'</b></a></li></ul></div></td>
<td><div class="menu-top-pc-logged-container"><ul id="menu-top-pc-logged" class="menu">
<li id="menu-item-41" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-41"><a href="/notification">Notification</a></li>
<li id="menu-item-42" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-42"><a href="/wp-admin/index.php">Dashboard</a></li>
<li id="menu-item-43" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-43"><a href="/wp-admin/profile.php">Profile</a></li>
<li id="menu-item-44" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-44"><a href="/wp-admin/post-new.php">New Post</a></li></ul></div></td>
</tr></table>';
} else {
	echo '<div class="menu-top-pc-non-logged-container"><ul id="menu-top-pc-non-logged" class="menu"><li id="menu-item-50" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-50"><a href="/wp-admin">Login</a></li>
<li id="menu-item-51" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-51"><a href="/wp-login.php?action=register">Register</a></li></ul></div>';
} ?>
</div>
<div class="clear"></div>

<div class="header_block">
<div class="header_logo fleft"><a href="/"><img src="<?php bloginfo( 'template_url' ); ?>/images/logo.png" /></a></div>
<div class="top_ad fright"></div>
</div>
<div class="clear"></div>

<div class="nav_block">
<div class="menu-pc-nav-container"><ul id="menu-pc-nav" class="menu">
<li id="menu-item-117" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item menu-item-home menu-item-117"><a href="/">Home</a></li>
<li id="menu-item-148" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-148"><a href="#">Android</a>
<ul class="sub-menu">
<li id="menu-item-118" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-118"><a href="/category/android-phone-review">Android phone review</a></li>
<li id="menu-item-119" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-119"><a href="/category/android-root">Android root</a></li>
<li id="menu-item-120" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-120"><a href="/category/android-tips">Android Tips</a></li>
<li id="menu-item-123" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-123"><a href="/category/custom-rom">Android Custom Rom</a></li>
</ul>
</li>
<li id="menu-item-149" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-149"><a href="#">Programming</a>
<ul class="sub-menu">
<li id="menu-item-122" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-122"><a href="/category/c-programming">C programming</a></li>
<li id="menu-item-133" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-133"><a href="/category/java-programming">Java programming</a></li>
<li id="menu-item-137" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-137"><a href="/category/python-programming">Python programming</a></li>
<li id="menu-item-136" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-136"><a href="/category/php">Php</a></li>
</ul>
</li>
<li id="menu-item-153" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-153"><a href="#">Review</a>
<ul class="sub-menu">
<li id="menu-item-121" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-121"><a href="/category/apps-review">Apps review</a></li>
<li id="menu-item-126" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-126"><a href="/category/games-review">Games Review</a></li>
<li id="menu-item-141" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-141"><a href="/category/themes-review">Themes Review</a></li>
</ul>
</li>
<li id="menu-item-150" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-150"><a href="#">Mobile</a>
<ul class="sub-menu">
<li id="menu-item-140" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-140"><a href="/category/symbian">Symbian Mobile</a></li>
<li id="menu-item-132" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-132"><a href="/category/java-mobile">Java mobile</a></li>
<li id="menu-item-146" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-146"><a href="/category/windows-mobile">Windows mobile</a></li>
</ul>
</li>
<li id="menu-item-135" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-135"><a href="/category/pdf-books">Books</a></li>
<li id="menu-item-152" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-152"><a href="#">Web Development</a>
<ul class="sub-menu">
<li id="menu-item-147" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-147"><a href="/category/wordpress">WordPress</a></li>
<li id="menu-item-145" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-145"><a href="/category/wapka">Wapka</a></li>
<li id="menu-item-138" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-138"><a href="/category/seo-tricks">SEO</a></li>
</ul></li> </ul></div>
</div>
<div class="clear"></div>

<div class="head_ad_block">
<div class="header_ad_left fleft">
<div class="ad_block_pc"><div class="ad_body_pc"></div>
</div>
</div>
<div class="header_ad_right fright">
<div class="ad_block_pc"><div class="ad_body_pc"></div>
</div>
</div>
</div>
<div class="clear"></div>