<?php get_header(); ?>

<div id="page_start">

<div class="main_block">

<div class="single_left">

<div class="single_content bg_white">
<h1 class="single_title pad4"><span style="font-size:100px;padding-right:0px 10px;">404</span> Not found</h1> <p>Sorry, The content is unavailable.</p>
</div>
</div>
</div>
<div class="clear"></div>

<div class="main_block">
<div class="main_left">
<h2>Check our recent post:</h2>
<ul>
<?php query_posts('posts_per_page=20'); if (have_posts()) : while (have_posts()) : the_post(); ?>
<li>
<h3><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h3><br/><a href="<?php the_permalink(); ?>"><?php
// Feature post thumbnail.

if ( has_post_thumbnail() ) {
	the_post_thumbnail( 'medium' );
}
else {
	echo '<img width="110" height="75" src="' . get_bloginfo( 'template_url' ) . '/images/no-thumbnail-110x75.png" class="attachment-thumbnail wp-post-image" alt="No image" />';
} ?></a> 
<h5>
<div class="pad4"><?php the_author_posts_link(); ?> on <?php the_category( ', ' ) ?> at <span><?php echo human_time(); ?></span></div> 
<div><?php the_time( get_option( 'time_format' ) ) ?> | <span><a href="<?php the_permalink(); ?>#comments"><?php comments_number( 'No Comment', '1 Comment', '% Comments' ); ?></a></span> | <?php echo getPostViews(get_the_ID()); ?></div>
</h5>
<p><?php echo wp_trim_words( get_the_content(),25, '<a href="'. get_permalink($post->ID) . '">Read More</a>' ); ?></p>
</li>
<?php endwhile; else: ?>
<?php endif; ?>
</ul>
</div>
<div class="main_middle"></div>

<?php get_sidebar(); ?>
</div>

</div>

<?php get_footer(); ?>