jQuery(function($) {
return jQuery("#right_sidebar").stick_in_parent({
  parent: ".main_block"
});
});

jQuery(window).on("resize", (function(_this) {
return function(e) {
  return jQuery(document.body).trigger("sticky_kit:recalc");
};
})(this));