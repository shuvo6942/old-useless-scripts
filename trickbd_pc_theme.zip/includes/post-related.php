<div class="related_post">
<h3>Related Posts</h3>
<ul>
<?php
	$category = get_the_category(); //get first current category ID
	$this_post = $post->ID; // get ID of current post
	$posts = get_posts('numberposts=5&category=' . $category[0]->cat_ID . '&exclude=' . $this_post);
	foreach($posts as $post) { ?>
<li>
<?php
// Related post thumbnail.

if ( has_post_thumbnail() ) {
	the_post_thumbnail( 'thumbnail' );
}
else {
	echo '<img width="60" height="60" src="' . get_bloginfo( 'template_url' ) . '/images/no-thumbnail-60x60.png" class="attachment-thumbnail wp-post-image" alt="No image" />';
} ?> <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a> <p><?php the_time( get_option( 'date_format' ) ) ?> - <?php the_time( get_option( 'time_format' ) ) ?></p>
</li>
<?php } wp_reset_postdata(); ?>
</ul>
</div>