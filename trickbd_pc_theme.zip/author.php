﻿<?php get_header(); ?>

<div id="start_page">

<div class="author_block">
<!– This sets the $curauth variable –>
<?php
if(isset($_GET['author_name'])) :
$curauth = get_userdatabylogin($author_name);
else :
$curauth = get_userdata(intval($author));
endif;
?>

<h2>Techbd profile of <?php the_author(); ?></h2>
<table width="100%"><tr>
<td width="75px"><?php echo get_avatar( get_the_author_meta('email'), '70' ); ?></td>
<td><h3><?php the_author(); ?></h3>
<div class="user_role"><?php $aid = get_the_author_meta('ID'); 
echo get_user_role($aid); ?></div>
<p><?php echo $curauth->user_description; ?></p>
</td>
</tr></table>

<div class="author_info">
<p><span>Registered:</span> <?php echo $curauth->user_registered; ?></p>

<p><span>Website:</span> <?php echo $curauth->user_url; ?></p>

<p><span>Twitter: </span><?php echo $curauth->twitter; ?> </p>

<p><span>Facebook: </span><?php echo $curauth->facebook; ?></p>

<p><span>User Posts:</span> <?php the_author_posts(); ?></p>

<p><span>User ID:</span> <?php the_author_id(); ?></p>
</div>
</div>

<div class="main_block">

<div class="main_left">
<h2><div class="breadcumbs"><div id="crumbs"><a href="/">Home</a> › <span class="current">Articles posted by <?php the_author(); ?></span></div></div></h2>

<ul>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<li>
<h3><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h3><br/><a href="<?php the_permalink(); ?>"><?php
// Feature post thumbnail.

if ( has_post_thumbnail() ) {
the_post_thumbnail( 'medium' );
}
else {
echo '<img width="110" height="75" src="' . get_bloginfo( 'template_url' ) . '/images/no-thumbnail-110x75.png" class="attachment-thumbnail wp-post-image" alt="No image" />';
} ?></a>
<h5>
<div class="pad4"><?php the_author_posts_link(); ?> on <?php the_category( ', ' ) ?> at <span><?php echo human_time(); ?></span></div> 
<div><?php the_time( get_option( 'time_format' ) ) ?> | <span><a href="<?php the_permalink(); ?>#comments"><?php comments_number( 'No Comment', '1 Comment', '% Comments' ); ?></a></span> | <?php echo getPostViews(get_the_ID()); ?></div>
</h5>
<p><?php echo wp_trim_words( get_the_content(),25, ' <a href="'. get_permalink($post->ID) . '">Read More</a>' ); ?></p>
</li>
<?php endwhile; else: ?>
<br/><h1 class="page-404"><?php _e('No posts by this author'); ?></h1><br/>
<?php endif; ?>
</ul>
<div class="clear"></div>

<?php wp_pagenavi(); ?>
<div class="clear"></div>
</div>

<?php get_sidebar(); ?>
</div>

</div>

<?php get_footer(); ?>