<div id="right_sidebar">
<div class="main_right">

<div class="main_right_ad">
<div class="ad_block_pc"><div class="ad_body_pc"></div><!-- G&R_300x250 --><script id="GNR24091">
    (function (i,g,b,d,c) {
        i[g]=i[g]||function(){(i[g].q=i[g].q||[]).push(arguments)};
        var s=d.createElement(b);s.async=true;s.src=c;
        var x=d.getElementsByTagName(b)[0];
        x.parentNode.insertBefore(s, x);
    })(window,'gandrad','script',document,'//content.green-red.com/lib/display.js');
    gandrad({siteid:8083,slot:24091});
</script>
<!-- End of G&R_300x250 --></div>
</div>
<div class="clear"></div>

<div class="right_cat_list fix">
<h2>Categories</h2>

<div class="menu-categories-container"><ul id="menu-categories" class="menu">
<li id="menu-item-8188" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-8188"><a href="/category/android-custom-rom,android-phone-review,android-root,android-tips,android-xposed-framework,apps-review">Android</a>
<ul class="sub-menu">
<li id="menu-item-71" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-71"><a href="/category/games-review">Games Review</a></li>
<li id="menu-item-68" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-68"><a href="/category/custom-rom">Android Custom Rom</a></li>
<li id="menu-item-105654" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-105654"><a href="/category/walton-custom-rom">Walton Custom Rom</a></li>
<li id="menu-item-105653" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-105653"><a href="/category/symphony-custom-rom">Symphony Custom Rom</a></li>
<li id="menu-item-6815" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-6815"><a href="/category/android-xposed-framework">Android Xposed Framework</a></li>
<li id="menu-item-66" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-66"><a href="/category/apps-review">Apps review</a></li>
<li id="menu-item-65" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-65"><a href="/category/android-tips">Android Tips</a></li>
<li id="menu-item-64" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-64"><a href="/category/android-root">Android root</a></li>
<li id="menu-item-86" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-86"><a href="/category/themes-review">Themes Review</a></li>
<li id="menu-item-63" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-63"><a href="/category/android-phone-review">Android phone review</a></li>
</ul>
</li>
<li id="menu-item-8226" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-8226"><a href="/category/education-guideline,hsc-exam-result,jsc-exam-result,pdf-books">Education</a>
<ul class="sub-menu">
<li id="menu-item-69" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-69"><a href="/category/education-guideline">Education Guideline</a></li>
<li id="menu-item-75" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-75"><a href="/category/hsc-exam-result">Hsc Exam result</a></li>
<li id="menu-item-79" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-79"><a href="/category/jsc-exam-result">Jsc Exam result</a></li>
<li id="menu-item-84" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-84"><a href="/category/ssc-exam-result">Ssc Exam result</a></li>
<li id="menu-item-80" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-80"><a href="/category/pdf-books">Pdf books</a></li>
</ul>
</li>
<li id="menu-item-70" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-70"><a href="/category/facebook-tricks">Facebook tricks</a></li>
<li id="menu-item-8235" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-8235"><a href="/category/gp-free-net,airtel-free-net,banglalink-free-net,robi-free-net">Free Nert Tricks</a>
<ul class="sub-menu">
<li id="menu-item-8229" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-8229"><a href="/category/airtel-free-net">Airtel free net</a></li>
<li id="menu-item-8230" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-8230"><a href="/category/banglalink-free-net">Banglalink free net</a></li>
<li id="menu-item-8231" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-8231"><a href="/category/gp-free-net">Gp free net</a></li>
<li id="menu-item-8232" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-8232"><a href="/category/robi-free-net">Robi free net</a></li>
</ul>
</li>
<li id="menu-item-8238" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-8238"><a href="/category/java-mobile,windows-mobile,symbian">Games, Apps &#038; Tricks</a>
<ul class="sub-menu">
<li id="menu-item-77" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-77"><a href="/category/java-mobile">Java mobile</a></li>
<li id="menu-item-85" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-85"><a href="/category/symbian">Symbian Tips</a></li>
<li id="menu-item-91" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-91"><a href="/category/windows-mobile">Windows mobile</a></li>
</ul>
</li>
<li id="menu-item-8236" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-8236"><a href="/category/hacking-news,hacking-tutorials">Hacking</a>
<ul class="sub-menu">
<li id="menu-item-72" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-72"><a href="/category/hacking-news">Hacking news</a></li>
<li id="menu-item-73" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-73"><a href="/category/hacking-tutorials">Hacking tutorials</a></li>
</ul>
</li>
<li id="menu-item-8237" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-8237"><a href="/category/hadith-quran,islamic-stories">Islamic Forum</a>
<ul class="sub-menu">
<li id="menu-item-74" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-74"><a href="/category/hadith-quran">Hadith &#038; Quran</a></li>
<li id="menu-item-76" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-76"><a href="/category/islamic-stories">Islamic Stories</a></li>
</ul>
</li>
<li id="menu-item-77" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-77"><a href="/category/lifestyle">LifeStyle</a></li>
<li id="menu-item-8241" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-8241"><a href="/category/techbd-notice,tuner-competition,featured,hot">Techbd Updates</a>
<ul class="sub-menu">
<li id="menu-item-87" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-87"><a href="/category/hot">Hot</a></li>
<li id="menu-item-88" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-88"><a href="/category/featured">Featured</a></li>
<li id="menu-item-89" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-89"><a href="/category/techbd-notice">Techbd Notice</a></li>
<li id="menu-item-90" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-90"><a href="/category/tuner-competition">Tuner Competition</a></li>
</ul>
</li>
<li id="menu-item-94753" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-94753"><a href="/category/operator-news">Operator News</a></li>
<li id="menu-item-8240" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-8240"><a href="/category/c-programming,java-programming,php,python-programming">Programming</a>
<ul class="sub-menu">
<li id="menu-item-67" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-67"><a href="/category/c-programming">C programming</a></li>
<li id="menu-item-78" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-78"><a href="/category/java-programming">Java programming</a></li>
<li id="menu-item-81" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-81"><a href="/category/php">Php</a></li>
<li id="menu-item-82" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-82"><a href="/category/python-programming">Python programming</a></li>
</ul>
</li>
<li id="menu-item-38803" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-38803"><a href="/category/technology-updates">Technology Updates</a></li>
<li id="menu-item-8242" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-8242"><a href="/category/seo-tricks,wapka,wordpress">Web Development</a>
<ul class="sub-menu">
<li id="menu-item-94752" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-94752"><a href="/category/online-earning">Online Earning</a></li>
<li id="menu-item-83" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-83"><a href="/category/seo-tricks">Seo tricks</a></li>
<li id="menu-item-90" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-90"><a href="/category/wapka">Wapka</a></li>
<li id="menu-item-92" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-92"><a href="/category/wordpress">WordPress</a></li>
</ul>
</li>
<li id="menu-item-89" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-89"><a href="/category/uncategorized">Uncategorized</a></li>
</ul>
</div>
</div>
<div class="clear"></div>

<div class="main_right_ad_bottom"></div>
<div class="clear"></div>

<div class="top_author">
<h2>Top Authors</h2>
<div class="ta-custom "><?php
global $wpdb;
$top_authors = $wpdb->get_results("
	SELECT u.ID, count(post_author) as posts FROM {$wpdb->posts} as p
	LEFT JOIN {$wpdb->users} as u ON p.post_author = u.ID
	WHERE p.post_status = 'publish'
	AND p.post_type = 'post'
	GROUP by p.post_author
	ORDER by posts DESC
	LIMIT 0,15
");
if( !empty( $top_authors ) ) {
	echo '<ul>';
	foreach( $top_authors as $key => $author ) {
		echo '<li><a href="' . get_author_posts_url( $author->ID ) . '">' . get_avatar( $author->ID , 50 ) . ' ' . get_the_author_meta( 'display_name' , $author->ID ) . '</a>
			(' . $author->posts . ') 
		</li>';
	}
	echo '</ul>';
}
?></div>
</div>
<div class="clear"></div>

<div class="footer_ad_block"></div>

<div class="comments_block">
<div class="recent_comments"></div>
</div>

<div class="top_author">
<h2>Email Notification</h2>
<form align="center" action="https://feedburner.google.com/fb/a/mailverify" method="post" target="popupwindow" onsubmit="window.open('https://feedburner.google.com/fb/a/mailverify?uri=livetipsbd', 'popupwindow', 'scrollbars=yes,width=300,height=150');return true"><p>Enter your email address:</p><p><input type="text" style="width:140px" name="email"/></p><input type="hidden" value="livetipsbd" name="uri"/><input type="hidden" name="loc" value="en_US"/><input type="submit" value="Subscribe" /></form>
</div>

<div class="new_users"></div>

</div>

</div>
<div class="clear"></div>