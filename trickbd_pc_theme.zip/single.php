﻿<?php get_header(); ?>

<div id="page_start">

<link rel="stylesheet" href="<?php bloginfo( 'template_url' ); ?>/comment.css" />
<div class="clear"></div>

<div class="main_block">

<div class="single_left">
<?php if(have_posts()) : ?> <?php while(have_posts()) : the_post(); ?>

<div class="breadcumbs_single">
<div id="crumbs"><a href="/">Home</a> › <?php the_category( ' › ' ) ?> › <span class="current"><?php the_title(); ?></span></div>
</div>

<div class="single">
<h4 class="single_info">
<table width="100%">
<td><?php echo human_time(); ?> <span>(<?php the_time( get_option( 'date_format' ) ) ?>)</span>
</td>
<td style="text-align: right"><?php setPostViews(get_the_ID()); ?> <?php echo getPostViews(get_the_ID()); ?></td>
</table>
</h4>

<h1 class="single_title"><?php the_title(); ?></h1>

<h4 class="single_info_sub">
<span>Category: </span><?php the_category( ', ' ) ?> Tags: <?php the_tags( ', ' ); ?><span> by </span><?php the_author_posts_link(); ?>
</h4>

<div class="single_content">
<center><?php
// Feature post thumbnail.

if ( has_post_thumbnail() ) {
	the_post_thumbnail( 'large' );
}
else {
	echo '<img width="140" height="140" src="' . get_bloginfo( 'template_url' ) . '/images/no-thumbnail-110x75.png" class="attachment-thumbnail wp-post-image" alt="No thumbnail"/>';
} ?></center>
<?php the_content(); ?>
</div>
</div>

<?php edit_post_link('Edit', '<p>', '</p>'); ?>

<div class="single_author_info">
<h2><table width="100%">
<td>About <?php the_author_posts_link(); ?></td>
<td style="text-align: right"><?php the_author_posts(); ?></td>
</table></h2>

<div class="author_bio">
<?php echo get_avatar( get_the_author_meta('email'), '60' ); ?>
<p><?php $aid = get_the_author_meta('ID'); 
echo get_user_role($aid); ?></p>
<p><?php the_author_meta('description'); if(!get_the_author_meta('description')) _e('This user may not interusted to share anything with others','Techbd.cf'); ?></p>
</div>

</div>
<?php endwhile; ?>
<?php endif; ?>
<div class="clear"></div>

<?php get_template_part( 'includes/post-related' ); ?>
<div class="clear"></div>

<?php comments_template( '', true ); ?>
<div class="clear"></div>
</div>

<?php get_sidebar(); ?>
<div class="clear"></div>
</div>

</div>

<?php get_footer(); ?>