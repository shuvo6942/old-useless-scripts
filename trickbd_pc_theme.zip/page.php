<?php get_header(); ?>

<div id="page_start">

<link rel="stylesheet" href="<?php bloginfo( 'template_url' ); ?>/comment.css" />
<div class="clear"></div>

<div class="main_block">

<div class="single_left">
<div class="single">
<?php if ( have_posts() ): while ( have_posts() ): the_post(); ?>
if ( has_post_thumbnail() ) {
	the_post_thumbnail( array(140,140) );
}
<h1 class="single_title"><?php the_title(); ?></h1>

<div class="single_content">
<?php the_content(); ?>
</div>
</div>
<?php endwhile; ?>
<?php endif; ?>
</div>

<div class="main_middle"></div>

<?php get_sidebar(); ?>
</div>

</div>

<?php get_footer(); ?>