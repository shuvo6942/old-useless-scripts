<?php get_header(); ?>

<div id="page_start">

<div class="featured_block">
<div class="current_featued">
<h2>Featured post</h2>

<div class="featured_full fix">
<?php $cat_id = 1;
$latest_cat_post = new WP_Query( array('posts_per_page' => 1, 'category__in' => array($cat_id)));
if( $latest_cat_post->have_posts() ) : while( $latest_cat_post->have_posts() ) : $latest_cat_post->the_post();  ?> 
<h1><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h1><br/><a href="<?php the_permalink(); ?>"><?php
// Feature post thumbnail.

if ( has_post_thumbnail() ) {
	the_post_thumbnail( array(310,205) );
}
else {
	echo '<img width="110" height="75" src="' . get_bloginfo( 'template_url' ) . '/images/no-thumbnail-110-75.png" class="attachment-thumbnail wp-post-image" alt="No thumbnail" />';
} ?></a><br/><p><?php echo wp_trim_words( get_the_content(),15, ' <a href="'. get_permalink($post->ID) . '">Read More</a>' ); ?></p>
<?php endwhile; endif; ?>

<div class="current_featued_author">
<?php echo get_avatar( get_the_author_meta('email'), '60' ); ?>
<div class="current_featured_info">
<p>Author <?php the_author_posts_link(); ?></p>
<p>Posted in <?php the_category( ', ' ) ?></p>
<p>Posted on <?php the_time( get_option( 'date_format' ) ) ?></p>
<p><?php echo getPostViews(get_the_ID()); ?></p>
</div>
</div>
</div>
</div>

<div class="hot_posts">
<h2>Hot post</h2>

<ul class="hot_now">
<?php $cat_id = 1;
$latest_cat_post = new WP_Query( array('posts_per_page' => 4, 'category__in' => array($cat_id)));
if( $latest_cat_post->have_posts() ) : while( $latest_cat_post->have_posts() ) : $latest_cat_post->the_post();  ?>
<li>
<a href="<?php the_permalink(); ?>"><?php
// Hot post thumbnail.

if ( has_post_thumbnail() ) {
	the_post_thumbnail( 'thumbnail' );
}
else {
	echo '<img width="110" height="75" src="' . get_bloginfo( 'template_url' ) . '/images/no-thumbnail-110x75.png" class="attachment-thumbnail wp-post-image" alt="No image" />';
} ?></a> <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a> <p>By <?php the_author_posts_link(); ?>, <?php the_time( get_option( 'date_format' ) ) ?></p>
</li>
<?php endwhile; endif; ?>
</ul>
</div>
</div>
<div class="clear"></div>

<div class="main_block" id="sidebar_parent"><div class="main_left" id="main_block_home">
<h2>Recent Post</h2>

<ul>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<li>
<h3><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h3><br/><a href="<?php the_permalink(); ?>"><?php
// Recent post thumbnail.

if ( has_post_thumbnail() ) {
	the_post_thumbnail( 'thumbnail' );
}
else {
	echo '<img width="110" height="75" src="' . get_bloginfo( 'template_url' ) . '/images/no-thumbnail-110x75.png" class="attachment-thumbnail wp-post-image" alt="No image" />';
} ?></a>
<h5>
<div class="pad4"><?php the_author_posts_link(); ?> on <?php the_category( ', ' ) ?> at <span><?php echo human_time(); ?></span></div> 
<div><?php the_time( get_option( 'time_format' ) ) ?> | <span><a href="<?php the_permalink(); ?>#comments"><?php comments_number( 'No Comment', '1 Comment', '% Comments' ); ?></a></span> | <?php echo getPostViews(get_the_ID()); ?></div>
</h5>
<p><?php echo wp_trim_words( get_the_content(),25, ' <a href="'. get_permalink($post->ID) . '">Read More</a>' ); ?></p>
</li>
<?php endwhile; else: ?>
<?php endif; ?>
</ul>
<div class="clear"></div>

<?php wp_pagenavi(); ?>
<div class="clear"></div>
</div>

<?php get_sidebar(); ?>
</div>

</div>

<?php get_footer(); ?>