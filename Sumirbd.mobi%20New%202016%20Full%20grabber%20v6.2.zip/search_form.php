<div class="search tCenter"><form method="get" action="/search.php">Search : <input type="text" name="find" id="find" value="" size="15" /><select name="ext" id="ext"><option value="ALL" selected="selected">ALL</option>
<option value="MP3">MP3</option>
<option value="3GP">3GP</option>
<option value="MP4">MP4</option>
<option value="APK">APK</option>
<option value="JAR">JAR</option>
<option value="SIS">SIS</option>
</select><input type="submit" name="commit" value="Search" id="file" /></form></div>

