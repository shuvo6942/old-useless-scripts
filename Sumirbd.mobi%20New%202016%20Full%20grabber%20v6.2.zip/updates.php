<?php
$upd = file_get_contents('http://m.sumirbd.mobi');
$upd = preg_replace('|<!DOCTYPE html(.*?)<h2>Latest Updates</h2>|is','<div class="updates"><h2>Latest Updates</h2>',$upd);
$upd = preg_replace('|<div class="top21">(.*?)</html>|is','',$upd);
$upd=str_replace('/latest_updates','/mobile/latest_updates',$upd);
$upd=str_replace('http://sumirbd.mobi','/mobile',$upd);
echo $upd;?>