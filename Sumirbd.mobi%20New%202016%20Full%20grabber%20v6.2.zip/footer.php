<div class="ftrLink">© <a href="/" class="siteLink">Friendclub.iN</a> 2014</div>
</body>
</html>

<CENTER>
<a href="">Enjoy 3G Speed on a 2G Network</a>



<br>
<script id="_wauaaw">var _wau = _wau || []; _wau.push(["small", "pxrs0ezx2ep4", "aaw"]);
(function() {var s=document.createElement("script"); s.async=true;
s.src="http://widgets.amung.us/small.js";
document.getElementsByTagName("head")[0].appendChild(s);
})();</script>
</br>
</CENTER>

<style> body:after { content: "AnowarBD.Com"; display: block; padding: px; repeat-x scroll center top #cccccc; padding: 4px 2px 2px; margin-bottom: 1px; font-weight: bold; text-align: center; border: 1px solid #7fd4e9; color: #fff; background: #7fd4e9; background: -moz-linear-gradient(top, #b0efff 0%, #7fd4e9 100%); background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#b0efff), color-stop(100%,#7fd4e9)); background: -webkit-linear-gradient(top, #b0efff 0%, #7fd4e9 100%); text-shadow: 1px 1px 1px #177086; } </style>
