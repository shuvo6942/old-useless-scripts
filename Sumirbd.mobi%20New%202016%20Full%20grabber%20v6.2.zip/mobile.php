<?php
/* Script Made By Anowar khan Friendclub.in */
/* Facebook: facebook.com/anowar.khana.7 */
$s=$_GET['show'];

$link='http://m.sumirbd.mobi/'.$s;
$file = file_get_contents(''.$link.'');
$link='http://m.sumirbd.mobi/'.$s;
include 'function.php';
echo $file;
include 'footer.php';
include 'Advertisers Footer.php';
?>

