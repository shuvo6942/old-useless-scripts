<?php
$url = "http://Friendclub.in";
$site = "Friendclub.iN";
$ads = '<div class="ad"><a href="http://Friendclub.in">Unlimited Free Downloads Portal</a></div>';
$home = "Friendclub.in";
$voice = "ON"; // ON or OFF
$day = "1"; // Stored File deleted times
/* MP3 Tag Settings */
$albumart = "Art.jpg";
$mp3_album = "Friendclub.in";
$mp3_artist = "Friendclub.iN";
$mp3_composer = "Friendclub.in";
$mp3_copyright = "Friendclub.in";
$mp3_comment = "Friendclub.in";
$mp3_genre = "Friendclub.in";
$mp3_year = "2014";
$mp3_original_artist = "Friendclub.in";
$mp3_encoded_by = "Friendclub.in"; ?>