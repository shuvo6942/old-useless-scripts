<center>

<iframe src="http://yx-ads6.com/banner_show.php?section=General&amp;pub=819252&amp;format=300x50&amp;ga=g" frameborder="0" scrolling="no" width="300" height="50" marginwidth="0" marginheight="0"></iframe>


</center>