<center>


<script type="text/javascript" src="http://yx-ads6.com/banner.php?section=General&pub=819252&format=300x50&ga=g"></script>


</center>