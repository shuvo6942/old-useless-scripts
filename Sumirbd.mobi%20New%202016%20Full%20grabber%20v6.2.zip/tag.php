<?php
// mp3 track title
$mp3_title = basename($save);
$mp3_title = str_replace('_',' ',$mp3_title);
$mp3_title = str_replace('.mp3','',$mp3_title);
$mp3_tagformat = 'UTF-8';
require_once('getid3/getid3.php');
$mp3_handler = new getID3;
$mp3_handler->setOption(array('encoding'=>$mp3_tagformat));
require_once('getid3/write.php');
$mp3_writter = new getid3_writetags;
$mp3_writter->filename       = $save;
$mp3_writter->tagformats     = array('id3v1', 'id3v2.3');
$mp3_writter->overwrite_tags = true;
$mp3_writter->tag_encoding   = $mp3_tagformat;
$mp3_writter->remove_other_tags = true;
$mp3_data['title'][]   = ''.$mp3_title.'';
$mp3_data['artist'][]  = ''.$mp3_artist.'';
$mp3_data['album'][]   = ''.$mp3_album.'';
$mp3_data['composer'][]   = ''.$mp3_composer.'';
$mp3_data['copyright'][]   = ''.$mp3_copyright.'';
$mp3_data['original_artist'][]   = ''.$mp3_original_artist.'';
$mp3_data['encoded_by'][]   = ''.$mp3_encoded_by.'';
$mp3_data['year'][]    = ''.$mp3_year.'';
$mp3_data['genre'][]    = ''.$mp3_genre.'';
$mp3_data['comment'][] = ''.$mp3_comment.'';
$mp3_data['attached_picture'][0]['data'] = file_get_contents($albumart);
$mp3_data['attached_picture'][0]['picturetypeid'] = "image/jpeg";
$mp3_data['attached_picture'][0]['description'] = "albumart.jpg";
$mp3_data['attached_picture'][0]['mime'] = "image/jpeg";
$mp3_writter->tag_data = $mp3_data;
$mp3_writter->WriteTags();?>