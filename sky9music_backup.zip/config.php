<?php
/******************

* Developed by CXUideas

* Project: Wapking Grabber

* Developed on 28/05/2014

* Coded by Febin Baiju
* CXUideas | cxuideas@gmail.com

******************/

$sitename = 'BDsong25.Com'; // Sitename
$mp3_join = true; // set false to disable joining mp3 at last
$path_url = 'http://webking.gq/'; // your site URL
?>