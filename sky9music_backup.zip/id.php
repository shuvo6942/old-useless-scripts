<?php
/******************

* Developed by CXUideas

* Project: Wapking Grabber

* Developed on 28/05/2014

* Coded by Febin Baiju

* CXUideas | cxuideas@gmail.com

******************/

require_once('getid3/getid3.php');
$mp3_handler = new getID3;
$info = $mp3_handler->analyze($sname);
$head = $info['id3v2']['comments'];
$mp3_tagformat = 'UTF-8';

$mp3_title = str_ireplace(array("wapking.cc","waploft.com","wapking.in"),$sitename,$head['title'][0]);
$mp3_album = str_ireplace(array("wapking.cc","waploft.com","wapking.in"),$sitename,$head['album'][0]);
$mp3_artist = str_ireplace(array("wapking.cc","waploft.com","wapking.in"),$sitename,$head['artist'][0]);
$mp3_year = str_ireplace(array("wapking.cc","waploft.com","wapking.in"),$sitename,$head['year'][0]);
$mp3_genre = str_ireplace(array("wapking.cc","waploft.com","wapking.in"),$sitename,$head['genre'][0]);
$mp3_comment = str_ireplace(array("wapking.cc","waploft.com","wapking.in"),$sitename,$head['comment'][0]);
$mp3_publisher = str_ireplace(array("wapking.cc","waploft.com","wapking.in"),$sitename,$head['publisher'][0]);
$mp3_handler->setOption(array('encoding'=>$mp3_tagformat));
require_once('getid3/write.php'); 
if(file_exists("sound.mp3") && $mp3_join==true)
{

$bs = str_replace(basename($sname),null,$sname);
if(!file_exists("temp/".$bs)) mkdir("temp/".$bs,0777,true);
rename($sname,"temp/".$sname);
fopen($sname,"w");
/////////////////////////////////////////////////////////////////
/// getID3() by James Heinrich <info@getid3.org>               //
//  available at http://getid3.sourceforge.net                 //
//            or http://www.getid3.org                         //
/////////////////////////////////////////////////////////////////
//                                                             //
// /demo/demo.joinmp3.php - part of getID3()                   //
// Sample script for splicing two or more MP3s together into   //
// one file. Does not attempt to fix VBR header frames.        //
// See readme.txt for more details                             //
//                                                            ///
/////////////////////////////////////////////////////////////////


// sample usage:

function CombineMultipleMP3sTo($FilenameOut, $FilenamesIn) {

	foreach ($FilenamesIn as $nextinputfilename) {
		if (!is_readable($nextinputfilename)) {
			echo 'Cannot read "'.$nextinputfilename.'"<BR>';
			return false;
		}
	}
	if (!is_writeable($FilenameOut)) {
	$handle =	fopen($FilenameOut,'w');
    if($handle)
    {
    fclose($handle);
    }
	}

	require_once('getid3/getid3.php');
	ob_start();
	if ($fp_output = fopen($FilenameOut, 'wb')) {

		ob_end_clean();
		// Initialize getID3 engine
		$getID3 = new getID3;
		foreach ($FilenamesIn as $nextinputfilename) {

			$CurrentFileInfo = $getID3->analyze($nextinputfilename);
			if ($CurrentFileInfo['fileformat'] == 'mp3') {

				ob_start();
				if ($fp_source = fopen($nextinputfilename, 'rb')) {

					ob_end_clean();
					$CurrentOutputPosition = ftell($fp_output);

					// copy audio data from first file
					fseek($fp_source, $CurrentFileInfo['avdataoffset'], SEEK_SET);
					while (!feof($fp_source) && (ftell($fp_source) < $CurrentFileInfo['avdataend'])) {
						fwrite($fp_output, fread($fp_source, 32768));
					}
					fclose($fp_source);

					// trim post-audio data (if any) copied from first file that we don't need or want
					$EndOfFileOffset = $CurrentOutputPosition + ($CurrentFileInfo['avdataend'] - $CurrentFileInfo['avdataoffset']);
					fseek($fp_output, $EndOfFileOffset, SEEK_SET);
					ftruncate($fp_output, $EndOfFileOffset);

				} else {

					$errormessage = ob_get_contents();
					ob_end_clean();
					echo 'failed to open '.$nextinputfilename.' for reading';
					fclose($fp_output);
					return false;

				}

			} else {

				echo $nextinputfilename.' is not MP3 format';
				fclose($fp_output);
				return false;

			}

		}

	} else {

		$errormessage = ob_get_contents();
		ob_end_clean();
		echo 'failed to open '.$FilenameOut.' for writing';
		return false;

	}

	fclose($fp_output);
	return true;
}
$FilenameOut = $sname;
$FilenamesIn[] = "temp/".$sname;
$FilenamesIn[] = "sound.mp3";
CombineMultipleMP3sTo($FilenameOut, $FilenamesIn);

unlink("temp/".$sname);
}
$mp3_writter = new getid3_writetags;
$mp3_writter->filename       = $sname;
$mp3_writter->tagformats     = array('id3v1', 'id3v2.3');
$mp3_writter->overwrite_tags = true;
$mp3_writter->tag_encoding   = $mp3_tagformat;
$mp3_writter->remove_other_tags = true;
$mp3_data['title'][]   = $mp3_title;
$mp3_data['artist'][]  = $mp3_artist;
$mp3_data['album'][]   = $mp3_album;
$mp3_data['year'][]    = $mp3_year;
$mp3_data['genre'][]   = $mp3_genre;
$mp3_data['comment'][] = $mp3_comment;
$mp3_data['publisher'][] = $mp3_publisher;

$mp3_data['attached_picture'][0]['data'] = file_get_contents('cover.jpg');
$mp3_data['attached_picture'][0]['picturetypeid'] = "image/jpeg";
$mp3_data['attached_picture'][0]['description'] = "Cover Image";
$mp3_data['attached_picture'][0]['mime'] = "image/jpeg";
$mp3_writter->tag_data = $mp3_data;

$mp3_writter->WriteTags();
?>