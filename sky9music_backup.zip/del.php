<?php
/******************

* Developed by CXUideas

* Project: Wapking Grabber

* Developed on 28/05/2014

* Coded by Febin Baiju

* CXUideas | cxuideas@gmail.com

******************/

function glob_rec($folder)
{
$scan = glob($folder."/*");

if(!empty($scan[0]))
{
foreach($scan as $l)
{
if(is_file($l))
{
if(filemtime($l)<time()-86400) unlink($l);
}
else
{
glob_rec($l);
}
}

}
}

function del_old_files()
{
$dirs = array();
if(file_exists("siteuploads"))
$dirs[] = "siteuploads";
if(file_exists("files"))
$dirs[] = "files";
if(!empty($dirs[0]))
{
foreach($dirs as $dir)
{
glob_rec($dir);
}
}
}
del_old_files();
?>