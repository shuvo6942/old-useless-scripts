<?php
/******************

* Developed by CXUideas

* Project: Wapking Grabber

* Developed on 28/05/2014

* Coded by Febin Baiju
* CXUideas | cxuideas@gmail.com

******************/


include 'config.php';
include 'w.php';
$cat = @$_GET['cat'];
$page = @$_GET['page'];
$sort = @$_GET['sort'];

$page = $page==0?1:$page;
if(!in_array($sort,array('download','a2z','new2old')))
$sort = 'new2old';
$url = 'http://wapking.cc/fileList/'.$cat.'/'.$sort.'/'.$page.'.html';
include 'curl.php';

preg_match_all('|<h2>[^>]*(.*?)[^>]*</h2>|',$content,$t);

if(empty($t[0][0]))
{
$title = 'File Not Found';
$div_title = 'Not Found';

$err_msg = 'File Not found';
}
else
{
$title = $t[1][0].' :: '.$sitename;

if(empty($t[1][0]))
$title = str_replace(array('<h2>','</h2>'),null,$t[0][0]).' :: '.$sitename;
$sub = $t[0][0];
}
include 'header.php';


if(preg_match('/<img class="absmiddle"/',$content))
{
preg_match_all('|<img class="absmiddle" src="(.*?)" alt="(.*?)" />|',$content,$mid_img);

if(!file_exists(str_replace(array('http://waploft.com/',basename($mid_img[1][0])),null,$mid_img[1][0])))
mkdir(str_replace(array('http://waploft.com/',basename($mid_img[1][0])),null,$mid_img[1][0]),0777,true);
if(!file_exists(str_replace('http://waploft.com/',null,$mid_img[1][0])))
copy($mid_img[1][0],str_replace('http://waploft.com/',null,$mid_img[1][0]));
watermark(str_replace('http://waploft.com/',null,$mid_img[1][0]));echo '<p class="tCenter showimage"><img class="absmiddle" src="'.$path_url.''.str_replace('http://waploft.com/',null,$mid_img[1][0]).'" alt="'.$mid_img[2][0].'" /></p>
';
}

preg_match_all('|<div class="dtype">(.*?)</div>|is',$content,$sorts);
echo str_replace('href="/','href="',$sorts[0][0]);

preg_match_all('|<td(.*?)<a class="fileName" href="/fileDownload/(.*?)">(.*?)</a><br/>(.*?)<br style="clear:both;"></td>|',$content,$wid_prev);
echo '<table cellspacing="0"><tbody>';
for($i=0;$i<count($wid_prev[1]);$i++)
{
if($i%2==0) $c = 'even';
else $c = 'odd';

preg_match_all('|src="(.*?)"|',$wid_prev[1][$i],$srcs);

$src = $srcs[1][0];
$srcs[1][0] = $srcs[1][0];
if(!empty($src))
{
$bs = preg_replace('|http://(.*?).waploft.com/|',null,str_replace(basename($srcs[1][0]),null,$srcs[1][0]));

$bs = 'siteuploads/'.$bs.'';

if(!file_exists($bs))
{
mkdir($bs,0777,true);
}
if(!file_exists($bs.'/'.basename($srcs[1][0])))
copy($src,$bs.'/'.basename($srcs[1][0]));

if(preg_match("/(.apk|.sis|.zip|.jar|.thm|.nth)/i",$content))
{
watermark($bs.'/'.basename($srcs[1][0]),90);
}

else watermark($bs.'/'.basename($srcs[1][0]));
}
echo '<tr class="'.$c.'"><td'.str_replace('src="/','src="',preg_replace('|src="(.*?)"|','src="'.$path_url.$bs.'/'.basename($srcs[1][0]).'"',$wid_prev[1][$i])).'<a class="fileName" href="fileDownload/'.$wid_prev[2][$i].'">'.$wid_prev[3][$i].'</a><br /><br/>'.$wid_prev[4][$i].'<br style="clear:both;"></td></tr>';
}
echo '</tbody></table>';include 'footer.php';
?>