<?php
/******************

* Developed by CXUideas

* Project: Wapking Grabber

* Developed on 28/05/2014

* Coded by Febin Baiju

* CXUideas | cxuideas@gmail.com

******************/

function watermark($img,$degrees=false)
{
$q = 93;
$filetype = substr($img,strlen($img)-4,4);
$filetype = strtolower($filetype);
if($filetype == ".gif") $image = @imagecreatefromgif($img);
if($filetype == ".jpg") $image = @imagecreatefromjpeg($img);
if($filetype == ".png") $image = @imagecreatefrompng($img);
if (!$image) die();
//getting the image size for the original image
$img_w = imagesx($image);
$img_h = imagesy($image);
//if the filename has 150x150 in it's name then we don't apply the watermark
if (preg_match("/150x150/", $img)) {
    imagejpeg($image, null, $q); die();
} else {

    $watermark = @imagecreatefrompng("watermark.png");
    if($degrees!==false)
    $watermark = imagerotate($watermark,$degrees,0);
    }

$w_w = imagesx($watermark);
$w_h = imagesy($watermark);

    $dest_x = $img_w - $w_w;
    $dest_y = $img_h - $w_h;
imagecopy($image, $watermark, $dest_x, $dest_y, 0, 0, $w_w, $w_h);

imagejpeg($image, $img, $q);
}
?>