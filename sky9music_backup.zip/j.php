<?php
/******************

* Developed by CXUideas

* Project: Wapking Grabber

* Developed on 28/05/2014

* Coded by Febin Baiju

* CXUideas | cxuideas@gmail.com

******************/

include 'config.php';

if($_GET['jump']=='search')
{
if(!empty($_GET['sort'])){
$u = ''.$path_url.'files/search/find/'.base64_encode(urlencode($_GET['find'])).'/sort/'.$_GET['sort'].'/page/'.$_GET['page'].''; }

else
$u = ''.$path_url.'files/search/find/'.base64_encode(urlencode($_GET['find'])).'/page/'.$_GET['page'].'';
header('location:'.$u.'');
}
else

{
if(!empty($_GET['list']))
$l = 'categorylist';
else
$l = 'fileList';
header('location:'.$path_url.''.$l.'/'.$_GET['parent'].'/'.$_GET['sort'].'/'.$_GET['page'].'.html');

}
?>