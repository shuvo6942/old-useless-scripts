<?php
/******************

* Developed by CXUideas

* Project: Wapking Grabber

* Developed on 28/05/2014

* Coded by Febin Baiju

* CXUideas | cxuideas@gmail.com

******************/

if(preg_match('/<div class="pgn">/',$content))
{
preg_match_all('|<div>Page(.*?)</div>|',$content,$pa);
$copy_content = preg_replace('|<div>Page(.*?)</div>|','<span>TAG</span>',$content);

preg_match_all('|<div class="pgn">(.*?)</div>|is',$copy_content,$pg);

$cl = preg_replace('|action="(.*?)"|','action="j.php"',str_replace(array('href="/','src="/'),array('href="'.$path_url.'','src="'),$pg[0][0]));
if(preg_match('/action="\/category\/list"/',$pg[0][0]))
$cl = str_replace('</form>','<input type="hidden" value="cat" name="list" /></form>',$cl);

if($jump=='search')
$cl = str_replace('</form>','<input type="hidden" value="search" name="jump" /></form>',$cl);

echo str_replace('<span>TAG</span>',$pa[0][0],$cl);
}

if(preg_match('/<div class="path">/',$content))
{
preg_match_all('|<div class="path">(.*?)</div>|is',$content,$path);
echo str_replace(array('href="/','src="/'),array('href="'.$path_url.'','src="'),$path[0][0]);

}
include 'footer.add';
?>