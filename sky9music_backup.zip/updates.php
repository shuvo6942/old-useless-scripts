<?php
/******************

* Developed by CXUideas

* Project: Wapking Grabber

* Developed on 28/05/2014

* Coded by Febin Baiju
* CXUideas | cxuideas@gmail.com

******************/

include_once 'config.php';
$url = 'http://wapking.cc';
include 'curl.php';

preg_match_all('|<h2>Latest Updates</h2>(.*?)<a class="" href="/latest_updates/1.html">|mis',$content,$m);
echo '<div class="updates"><h2>Latest Updates</h2>'.str_ireplace(array('http://wapking.cc','href="/','</h2>'),array($path_url,'href="'.$path_url,'</h2><div class="updates">'),$m[1][0]).'</div></div></div>';
?>