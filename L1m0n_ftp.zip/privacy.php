<?php

/*
------------------ WARNING!!! DO NOT REMOVE THIS LINE ------------------

* Script Name: MyRootFTP
* Version: See VERSION.txt
* Author: Achunk JealousMan
* Email: achunk17@gmail.com
* Homepage: http://myroot.7ko.in
*/

define('PAGEDISPLAY', true);
if (!file_exists("includes/config.php")) {
echo "Please install before!";
exit;
}
ignore_user_abort(true);
error_reporting(0);
mb_internal_encoding('UTF-8');ini_set('default_charset','UTF-8');
date_default_timezone_set('UTC');
ini_set('session.cookie_domain', $_SERVER['HTTP_HOST']);

/*
set_time_limit(0);

*/
ob_start();


session_start();

include("language.php");
require("includes/config.php");
$sql_connect = mysql_connect($db_host,$db_user,$db_pass);
if (!$sql_connect) {
die("Connecting Error!");
exit;
}
mysql_select_db($db_name) or die('Database Error!');

function deleteDir($path) {$directory = $path;
if(is_dir($directory)) {
$directoryHandle = scandir($directory);

foreach ($directoryHandle as $contents) {
if($contents != '.' && $contents != '..') {
$path = $directory . "/" . $contents;

if(is_dir($path)) {
deleteDir($path);
} else {
unlink($path);
}
}
}

reset($directoryHandle);
rmdir($directory);
}
}
// Start
$__tm = time() - 3600;
$__q = mysql_query("SELECT * FROM `".$db_prefix."ftp` WHERE `lastlogin` < '".$__tm."' AND `delete` > '1' LIMIT 1");
if (mysql_num_rows($__q) > 0) {
$__f = mysql_fetch_array($__q);
deleteDir($dir_dataftp."/".$__f['id']);
mysql_query("UPDATE `".$db_prefix."ftp` SET `delete` = '1' WHERE `id` = '".$__f['id']."'");
}
// End
$conn_id = 0;
$login = 0;

$title = "Privasi Akun";
require_once("includes/header.php");
echo '<div class="content"><h1>Privasi Akun</h1>Dengan menggunakan layanan Kami berarti Anda telah menyetujui bahwa akun FTP Anda untuk sementara waktu Kami simpan pada sistem Kami, tetapi Kami tidak menyimpan kata sandi akun FTP Anda melainkan kata sandi tersebut disimpan pada cookie browser Anda dan kata sandi tersebut telah Kami enkripsi.<br />Setiap kali Anda masuk ke layanan Kami maka dengan secara otomatis sistem kami mendaftarkan akun FTP Anda yang nantinya sistem Kami akan memberikan kode rahasia akun Anda dan menyimpannya pada cookie browser Anda bersamaan dengan kata sandi akun FTP Anda yang telah di-enkripsi.<br />Ketika browser Anda masuk ke situs Kami maka sistem Kami akan memeriksa apakah browser Anda mempunyai cookie kode rahasia, jika browse tidak mempunyai cookie kode rahasia dan cookie kata sandi maka browser Anda akan dialihkan ke halaman Masuk, tetapi jika browser Anda mempunyai cookie kode rahasia yang sesuai dengan data pada sistem Kami maka selanjutnya sistem Kami akan mendeskripsi kata sandi akun FTP Anda.<br />Anda dapat menghapus cookie kode rahasia dan kata sandi akun FTP Anda bahkan menghapus data akun FTP (server, port, nama pengguna dan pengaturan tambahan lainnya) yang ada pada sistem setiap saat ketika Anda melakukan logout (Keluar) tetapi walau pun Anda tidak melakukan logout (Keluar) sistem Kami akan menghapus akun Anda secara otomatis jika jangka waktu yang telah Anda pilih pada saat masuk telah habis (Expires).<br /><h1>Profesionalitas Kami</h1>* Menyimpan kerahasiaan akun Anda.<br />* Tidak akan memberitahukan data akun Anda kepada siapa pun.<br />* Tidak akan masuk ke akun FTP Anda.<br /><br /><b>Kepercayaan Anda adalah tanggung jawab Kami.</b></div>';
require_once("includes/footer.php");
?>