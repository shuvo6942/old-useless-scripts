<?phpdefined('PAGEDISPLAY') or die('Access Forbidden');
echo '<div class="menu"><ul><li><a href="index.php">Home</a></li><li><a href="package.php">Package Info</a></li><li><a href="submit.php">Submit File</a></li><li><a href="../index.php">FTP Client</a></li><li><a href="http://api.7ko.in/redir/1623076">Free Premium Hosting</a></li><li><a href="http://indowapblog.com/">Free Mobile Blog</a></li></ul></div>';
echo '<div id="footer"><p>&copy; '.$_SERVER['HTTP_HOST'].' '.date('Y',time()).'</p></div></div></body>
</html>';?>