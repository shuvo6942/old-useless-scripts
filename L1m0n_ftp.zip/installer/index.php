<?php
define('PAGEDISPLAY',true);
$title = "FTP Installer";
require_once("header.php");
$package = isset($_GET['package']) ? htmlentities(rawurldecode(trim($_GET['package']))) : '';
$server = isset($_GET['server']) ? htmlentities(trim($_GET['server'])) : '';
$user = isset($_GET['user']) ? htmlentities(trim($_GET['user'])) : '';
$port = isset($_GET['port']) ? htmlentities(trim($_GET['port'])) : '21';
$dir = isset($_GET['dir']) ? htmlentities(rawurldecode(trim($_GET['dir']))) : '/public_html';
?>
<div class="content">
<div class="info">Free and easy script installer, Just click <b>INSTALL</b> the package script automaticaly extracted on your host.</div><form name="ActionForm" action="installer.php" method="post">
<b>Archive Package</b>
<br />
<select name="package" onchange="document.forms['ActionForm'].package_url.value=document.forms['ActionForm'].package.options[document.forms['ActionForm'].package.selectedIndex].value;">
<option value="" style="font-weight: bold; text-decoration: underline;" selected="selected">Other scripts</option>

<?php
$file_size = filesize("archive.dat");
$handle = fopen("archive.dat", "r");
ob_start();
$content = fread($handle, $file_size);
fclose($handle);
ob_clean();
$items = explode("\r\n",$content);
foreach ($items as $item) {
$arch = explode("::",$item);
$name = base64_decode($arch[1]);
$url = base64_decode($arch[0]);
echo '<option value="'.htmlentities($url).'">'.htmlentities($name).'</option>';
}
?>
</select><br /><input type="text" name="package_url" value="<?php echo $package; ?>"><br />
<b>FTP Server</b><br /><input type="text" name="ftp_server" value="<?php echo $server; ?>"><br />
<b>FTP Port</b><br /><input type="text" name="ftp_port" value="<?php echo $port; ?>" size="2"><br />
<b>FTP User</b><br /><input type="text" name="ftp_user" value="<?php echo $user; ?>"><br />
<b>FTP Password</b><br /><input type="password" name="ftp_password" value=""><br />
<b>Directory</b><br /><input type="text" name="dir" value="<?php echo $dir; ?>"><br />
<input type="submit" name="save" value="INSTALL"></form></div>
<?php
require_once("footer.php");
?>