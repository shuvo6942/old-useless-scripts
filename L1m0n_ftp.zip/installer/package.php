<?php
define('PAGEDISPLAY',true);
if (isset($_GET['zip'])) {
$zip = $_GET['zip'];
$file_size = filesize("archive.dat");
$handle = fopen("archive.dat", "r");
ob_start();
$content = fread($handle, $file_size);
fclose($handle);
ob_clean();
$items = explode("\r\n",$content);
for ($i = 0; $i < count($items); $i++) {
$iz = "i".$i;
if ($iz == $zip) {
$arch = explode("::",$items[$i]);
$name = base64_decode($arch[1]);
$html = '<div class="alt"><b>Name</b>: <b>'.htmlentities($name).'</b><br /><b>URL</b>: <a href="'.htmlentities(base64_decode($arch[0])).'">'.htmlentities(base64_decode($arch[0])).'</a><br /><b>Note</b>: '.htmlentities(base64_decode($arch[2])).'<br /><b>Size</b>: '.htmlentities(base64_decode($arch[3])).'<br /><b>Added</b>: '.htmlentities(base64_decode($arch[4])).'<br /><br /><div align="center"><form method="post" action="edit.php">Action<br /><select name="act"><option value="edit">Edit</option><option value="delete">Delete</option></select><input type="hidden" name="zip" value="'.htmlentities($zip).'"/><br />Admin Password<br /><input type="password" name="password"/><br /><input type="submit" name="submit" value="  Apply  "/></form></div></div>';
}
}
$title = "Package Info - ".htmlentities($name);
require_once("header.php");
echo '<div class="content">';
if ($html) {
echo $html;
}
else {
echo '<div class="error">File not found!</div>';
}
echo '</div>';
require_once("footer.php");
}
else {
$title = "Package Info";
require_once("header.php");
echo '<div class="content">';
$file_size = filesize("archive.dat");
$handle = fopen("archive.dat", "r");
ob_start();
$content = fread($handle, $file_size);
fclose($handle);
ob_clean();
$items = explode("\r\n",$content);
for ($i = 0; $i < count($items); $i++) {
$arch = explode("::",$items[$i]);
$name = base64_decode($arch[1]);
echo '<div id="files">&raquo; <a href="package.php?zip=i'.$i.'">'.htmlentities($name).'</a></div>';
}
echo '</div>';
require_once("footer.php");
}
?>