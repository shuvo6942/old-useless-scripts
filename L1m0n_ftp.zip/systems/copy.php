<?php

/*
------------------ WARNING!!! DO NOT REMOVE THIS LINE ------------------

* Script Name: MyRootFTP
* Version: See VERSION.txt
* Author: Achunk JealousMan
* Email: achunk17@gmail.com
* Homepage: http://myroot.7ko.in
*/

defined('PAGEDISPLAY') or die('Access Forbidden!');
if ($client_id == 0) {
header("Location: index.php");
exit;
}
if (isset($_GET['file'])) {
$file = rawurldecode(trim($_GET['file']));
if ($file == "") {
header("Location: index.php?ftp=list");
exit;
}
$dir = str_replace("/".basename($file),"",$file);
if (isset($_POST['submit'])) {
$copy = $_POST['copy'];
$chmod = $_POST['chmod'];
if ($copy == "")
$error .= $_lng['cantcopyfile'];
if (strlen($chmod) != 3 || !ctype_digit($chmod)) 
$error .= $_lng['chmodterms'];
if (empty($error)) {
createDir();
if (ftp_get($conn_id,$dir_dataftp."/".$_ftp['id']."/".basename($file),$file,FTP_BINARY)) {
if (ftp_put($conn_id,$copy,$dir_dataftp."/".$_ftp['id']."/".basename($file),FTP_BINARY)) {
ftp_site($conn_id,"CHMOD 0".$chmod." ".$copy);
deleteDir($dir_dataftp."/".$_ftp['id']);
header("Location: index.php?ftp=list&dir=".rawurlencode($dir));
exit;
}
else {
$notice = '<div class="error">'.$_lng['cantsavefile'].'</div>';
}
}
else {
$notice = '<div class="error">'.$_lng['cantgetfile'].'</div>';
}
}
else {
$notice = '<div class="error">'.$error.'</div>';
}
}

$title = $_lng['copytitle'].": ".htmlspecialchars($file);
require_once("includes/header.php");
echo '<div class="content">';
showDirNav($dir);
if ($_ftp['help'] == "yes") {
echo '<div class="info">'.$_lng['help_copy'].'</div><br />';
}
if ($notice)
echo $notice;
echo ''.$_lng['filetitle'].': <a href="index.php?ftp=file&amp;file='.rawurlencode($file).'">'.htmlentities($file).'</a><br /><form method="post" action="index.php?ftp=copy&amp;file='.rawurlencode($file).'">'.$_lng['copyto'].':<br /><input type="text" name="copy" value="'.htmlspecialchars($dir."/Copy_".basename($file)).'"><br />'.$_lng['chmod'].':<br /><input type="text" name="chmod" value="644" size="3" maxlength="3" format="*N"/><br /><input type="submit" name="submit" value="   '.$_lng['copybutton'].'   "/></form></div>';
require_once("includes/footer.php");
}
elseif (isset($_GET['dir'])) {
$dir = rawurldecode(trim($_GET['dir']));
if ($dir == "" || $dir == "/") {
header("Location: index.php?ftp=list");
exit;
}

$exdir = implode("/",explode("/",$dir,-1));
$directory = substr($dir,strlen($exdir));

if (isset($_POST['submit'])) {
createDir();
$local = $dir_dataftp."/".$_ftp['id'];
$copy = $_POST['copy'];
$coping = ftpFileList($dir);
foreach ($coping as $item) {
$localDir = $local.substr($item,strlen($exdir),"-".(strlen(basename($item)) + 1));
$ftpDir = $copy.substr($localDir,strlen($local));
localMkDirRecusive($localDir);
if (ftp_get($conn_id,$localDir."/".basename($item),$item,FTP_BINARY)) {
ftpMkDirRecusive($ftpDir);
if (ftp_put($conn_id,$ftpDir."/".basename($item),$localDir."/".basename($item),FTP_BINARY)) {
$notice .= '<div class="success"><b>'.str_replace('%s',htmlentities($directory),str_replace('%s1',htmlentities($item),str_replace('%s2',htmlentities($ftpDir.'/'.basename($item)),$_lng['copydirsuccess']))).'</div>';
}
else {
$notice .= '<div class="error">'.str_replace('%s',htmlentities($directory),str_replace('%s1',htmlentities($item),str_replace('%s2',htmlentities($ftpDir.'/'.basename($item)),$_lng['copydirerror']))).'</div>';
}
}
else {
$notice .= '<div class="error">'.str_replace('%s','<b>'.htmlentities($directory).'</b>',str_replace('%s1',htmlentities($item),$_lng['copygeterror'])).'</div>';
}
}
deleteDir($dir_dataftp."/".$_ftp['id']);
}

$title = $_lng['copytitle'].": ".htmlspecialchars($dir);
require_once("includes/header.php");
echo '<div class="content">';
showDirNav($dir);
if ($_ftp['help'] == "yes") {
echo '<div class="info">'.$_lng['help_copy'].'</div><br />';
}
if ($notice)
echo $notice;
echo '<form method="post" action="index.php?ftp=copy&amp;dir='.rawurlencode($dir).'">'.$_lng['copyto'].':<br /><input type="text" name="copy" value="'.htmlspecialchars($exdir).'"><br /><input type="submit" name="submit" value="   '.$_lng['copybutton'].'   "/></form></div>';
require_once("includes/footer.php");
}
else {
header("Location: index.php?ftp=list");
}
ftp_close($conn_id);
?>