<?php

/*
------------------ WARNING!!! DO NOT REMOVE THIS LINE ------------------

* Script Name: MyRootFTP
* Version: See VERSION.txt
* Author: Achunk JealousMan
* Email: achunk17@gmail.com
* Homepage: http://myroot.7ko.in
*/

defined('PAGEDISPLAY') or die('Access Forbidden!');
if ($client_id == 0) {
header("Location: index.php");
exit;
}
$file = rawurldecode(trim($_GET['file']));

$title = $_lng['untartitle'].": ".htmlspecialchars($file);
require_once("includes/header.php");
echo '<div class="content">';
$dir = implode("/",explode("/",$file,-1));
if (!$dir || $dir == "")
$dir = "/";
showDirNav($dir);
$local = $dir_dataftp."/".$_ftp['id'];
$tarname = basename($file);
if (isset($_POST['untar'])) {
if (ftp_get($conn_id,$local."/".$tarname,$file,FTP_BINARY)) {
$directory = $_POST['directory'];
if ($directory == "")
$directory = $dir;
if (substr($directory,-1) == "/")
$directory = substr($directory,0,-1);
require_once('includes/tar.php');
$tar = new Archive_Tar($local."/".$tarname);
if ($tar->extract($local."/")!=0)
{
unlink($local."/".$tarname);
ftpMkDirRecusive($directory);
$files = localGlob($local);
$count = count($files);
foreach ($files as $file) {
$ftp_dir = str_replace("#REPLACE#".$local,$directory,str_replace(basename($file)."#REPLACE#","","#REPLACE#".$file."#REPLACE#"));
ftpMkDirRecusive($ftp_dir);
if (ftp_put($conn_id,$ftp_dir.basename($file),$file,FTP_BINARY)) {
echo '<div class="success">'.$ftp_dir.basename($file).' '.$_lng['untarsuccess'].'</div>';
}
else {
echo '<div class="error">'.$ftp_dir.basename($file).' '.$_lng['untarerror'].'</div>';
}
}
echo ''.$_lng['totalfile'].' <b>'.$count.'</b>';
}
else {
echo '<div class="error">'.$_lng['extracterror'].' <b>'.htmlentities($file).'</b></div>';
}
}
else {
echo '<div class="error">'.$_lng['cantgetfile'].'</div>';
}
deleteDir($local);
}
else {
deleteDir($local);
createDir();
echo '<img src="images/efile.png" alt=""/> '.htmlentities($file).'<br /><form method="post" action="index.php?ftp=untar&amp;file='.rawurlencode($file).'"><b>'.$_lng['directory'].':</b><br /><input type="text" name="directory" value="'.htmlentities($dir).'"/><br /><input type="submit" name="untar" value="   '.$_lng['untarbutton'].'   "/></form>';
}
ftp_close($conn_id);
echo '</div>';
require_once("includes/footer.php");
?>
