<?php

/*
------------------ WARNING!!! DO NOT REMOVE THIS LINE ------------------

* Script Name: MyRootFTP
* Version: See VERSION.txt
* Author: Achunk JealousMan
* Email: achunk17@gmail.com
* Homepage: http://myroot.7ko.in
*/

defined('PAGEDISPLAY') or die('Access Forbidden!');
if ($client_id == 0) {
header("Location: index.php");
exit;
}
$dir = rawurldecode(trim($_GET['dir']));
if ($dir == "")
$dir = "/";
if (isset($_POST['upload'])) {
$count = count($_FILES['file']);
$max_size = 7340032;

if ($dir == "/")
$directory = "";
else
$directory = $dir;
for ($i = 0; $i < $count; $i++) {
$name = $_FILES['file']['name'][$i];
$size = $_FILES['file']['size'][$i];
if ($name != "" AND $size <= $max_size) {
$tmp = $_FILES['file']['tmp_name'][$i];
if (ftp_put($conn_id,$directory."/".$name,$tmp,FTP_BINARY)) {
$notice .= '<div class="success">'.$_lng['filetitle'].': '.htmlentities($name).' '.$_lng['withsize'].' '.round($size / 1024, 2).' kb '.$_lng['uploadsuccess'].'</div>';
}
else {
$notice .= '<div class="error">'.$_lng['filetitle'].': '.htmlentities($name).' '.$_lng['withsize'].' '.round($size / 1024, 2).' kb '.$_lng['uploaderror'].'</div>';
}
}
}
}

ftp_close($conn_id);
$title = $_lng['uploadtitle'].": ".htmlentities($dir);
require_once("includes/header.php");
echo '<div class="content">';
showDirNav($dir);
if ($notice)
echo $notice;

echo '<form action="index.php?ftp=upload&amp;dir='.rawurlencode($dir).'" enctype="multipart/form-data" method="post">'.$_lng['uploadinfo'].':<br />
<input type="file" name="file[]" size="15"><br /><input type="file" name="file[]" size="15"><br /><input type="file" name="file[]" size="15"><br /><input type="file" name="file[]" size="15"><br /><input type="file" name="file[]" size="15"><br /><input type="submit" name="upload" value="   '.$_lng['uploadbutton'].'   "></form></div>';
require_once("includes/footer.php");
?>