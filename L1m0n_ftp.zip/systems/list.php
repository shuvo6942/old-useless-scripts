<?php

/*
------------------ WARNING!!! DO NOT REMOVE THIS LINE ------------------

* Script Name: MyRootFTP
* Version: See VERSION.txt
* Author: Achunk JealousMan
* Email: achunk17@gmail.com
* Homepage: http://myroot.7ko.in
*/

defined('PAGEDISPLAY') or die('Access Forbidden!');
if ($client_id == 0) {
header("Location: index.php");
exit;
}
$dir = isset($_GET['dir']) ? rawurldecode($_GET['dir']) : '';
if ($dir == "")
$dir = "/";
if (!ftp_chdir($conn_id,$dir)) {
header("Location: index.php?ftp=list");
exit;
}
if ($dir != "/" AND substr($dir,-1) == "/")
$dir = substr($dir,0,-1);
$title = $_lng['directory'].": ".htmlentities($dir);
require_once("includes/header.php");
echo '<div class="content">';
showDirNav($dir);
if ($_ftp['help'] == "yes") {
echo '<div class="info">'.$_lng['help_list'].'</div>';
}
$files = ftpList($conn_id,$dir);
ftp_close($conn_id);
$page = trim($_GET['page']);
$count = count($files);
$view = $_ftp['view'];
if ($_ftp['view'] < 1 || $_ftp['view'] > 100) {
$view = 15;
}
$pages = ceil($count / $view);
if (empty($page)) {
$page = 1;
}
elseif ($page > $pages) {
$page = $pages;
}

$begin = $page * $view - $view;
if ($begin > $count) {
$begin = 0;
}
$end = $begin + $view;
if ($end > $count) {
$end = $count;
}
for ($i = $begin; $i < $end; $i++) {
$links .= $files[$i];
}
if ($pages > 1) {
echo '<div class="pagination">';
showPagination($page,$view,$count,'index.php?ftp=list&amp;dir='.rawurlencode($dir).'&amp;page=');
echo '<br /><form action="index.php"><input type="hidden" name="ftp" value="list"/><input type="hidden" name="dir" value="'.$dir.'"/><input name="page" type="text" value="'.htmlentities($page).'" size="2" format="*N"/><input type="submit" value="'.$_lng['go'].'"/></form></div>';
}
echo '<form action="index.php?ftp=submit&dir='.rawurlencode($dir).'" method="post">';
echo $links;
echo '<br /><script type="text/javascript"><!--
function checkboxall(source)
{
checkboxes = document.getElementsByName("file[]");
for(var i in checkboxes)
checkboxes[i].checked = source.checked;
}
//--></script><input type="checkbox" onclick="checkboxall(this)"> '.$_lng['withselected'].':<br /><select name="action"><option value="copy">'.$_lng['copytitle'].'</option>
<option value="rename">'.$_lng['renametitle'].'</option>
<option value="move">'.$_lng['movetitle'].'</option>
<option value="delete">'.$_lng['deletetitle'].'</option>
<option value="chmod">'.$_lng['chmodtitle'].'</option>
<option value="backup">'.$_lng['backuptitle'].'</option>
<input type="submit" name="submit" onclick="return confirm(\''.$_lng['actionconfirm'].'\')" value="'.$_lng['actionbutton'].'"/></form><br />';
if ($pages > 1) {
echo '<div class="pagination">';
showPagination($page,$view,$count,'index.php?ftp=list&amp;dir='.rawurlencode($dir).'&amp;page=');
echo '<br /><form action="index.php"><input type="hidden" name="ftp" value="list"/><input type="hidden" name="dir" value="'.$dir.'"/><input name="page" type="text" value="'.htmlentities($page).'" size="2" format="*N"/><input type="submit" value="'.$_lng['go'].'"/></form></div>';
}
echo '</div><div class="menu"><ul><li><a href="index.php?ftp=copy&amp;dir='.rawurlencode($dir).'">'.showIcon('<img src="images/copy.gif" alt=""/>','&raquo;').' '.$_lng['copytitle'].'</a></li><li><a href="index.php?ftp=move&amp;dir='.rawurlencode($dir).'">'.showIcon('<img src="images/move.gif" alt=""/>','&raquo;').' '.$_lng['movetitle'].'</a></li><li><a href="index.php?ftp=rename&amp;dir='.rawurlencode($dir).'">'.showIcon('<img src="images/rename.gif" alt=""/>','&raquo;').' '.$_lng['renametitle'].'</a></li><li><a href="index.php?ftp=delete&amp;dir='.rawurlencode($dir).'" onclick="return confirm(\''.$_lng['deleteconfirm'].'\')">'.showIcon('<img src="images/delete.gif" alt=""/>','&raquo;').' '.$_lng['deletetitle'].'</a></li><li><a href="installer/?server='.$_ftp['server'].'&amp;port='.$_ftp['port'].'&amp;user='.$_ftp['username'].'&amp;dir='.rawurlencode($dir).'">'.showIcon('<img src="images/zip.png" alt=""/>','&raquo;').' '.$_lng['zipinstaller'].'</a></li><li><a href="index.php?ftp=create&amp;dir='.rawurlencode($dir).'">'.showIcon('<img src="images/create.gif" alt=""/>','&raquo;').' '.$_lng['createtitle'].'</a></li><li><a href="index.php?ftp=backup&amp;dir='.rawurlencode($dir).'">'.showIcon('<img src="images/backup.gif" alt=""/>','&raquo;').' '.$_lng['backuptitle'].'</a></li><li><a href="index.php?ftp=import&amp;dir='.rawurlencode($dir).'">'.showIcon('<img src="images/import.gif" alt=""/>','&raquo;').' '.$_lng['importtitle'].'</a></li><li><a href="index.php?ftp=upload&amp;dir='.rawurlencode($dir).'">'.showIcon('<img src="images/upload.gif" alt=""/>','&raquo;').' '.$_lng['uploadtitle'].'</a></li></ul></div>';
require_once("includes/footer.php");
?>