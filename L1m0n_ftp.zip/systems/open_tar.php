<?php

/*
------------------ WARNING!!! DO NOT REMOVE THIS LINE ------------------

* Script Name: MyRootFTP
* Version: See VERSION.txt
* Author: Achunk JealousMan
* Email: achunk17@gmail.com
* Homepage: http://myroot.7ko.in
*/

defined('PAGEDISPLAY') or die('Access Forbidden!');
if ($client_id == 0) {
header("Location: index.php");
exit;
}
$file = rawurldecode(trim($_GET['file']));
$size = ftp_size($conn_id,$file);
if ($size > 20001040) {
header("Location: index.php");
exit;
}
$arr_unsource = array('zip','jar','tar','gz','bz','bz2','tgz','jpg','jpeg','gif','png','rar','mp3','mp4','3gp','avi','amr','nth','thm','sis','sisx','ico','apk');

createDir();
$local = $dir_dataftp."/".$_ftp['id'];
require_once("includes/tar.php");
if (isset($_GET['download'])) {
if (ftp_get($conn_id,$local."/".basename($file),$file,FTP_BINARY)) {
$tar = new Archive_Tar($local."/".basename($file));
if ($tar->extractList(trim($_GET['download']),$local."/"))
{
header('Content-Description: File Transfer');
header('Content-Type: application/octet-stream');    header('Content-Disposition: attachment; filename='.basename($local."/".trim($_GET['download'])));
header('Content-Transfer-Encoding: binary');
header('Expires: 0');
header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
header('Pragma: public');
header('Content-Length: ' .filesize($local."/".trim($_GET['download'])));
readfile($local."/".trim($_GET['download']));
}
else {
$error = $_lng['filenotfound'];
}
}
else {
$error = $_lng['cantgetfile'];
}
}
elseif (isset($_GET['extract'])) {
$extract = rawurldecode($_GET['extract']);
$title = $_lng['extracttitle'].": ".htmlspecialchars($extract);
require_once("includes/header.php");
echo '<div class="content">';
$dir = substr($file,0,"-".(strlen(basename($file)) + 1));
showDirNav($dir);
echo '<b>File:</b> <a href="index.php?ftp=file&amp;file='.rawurlencode($file).'">'.htmlentities($file).'</a><br /><b>Item:</b> '.htmlentities($extract).'<br />';
if (isset($_POST['extract'])) {
$save = $_POST['save'];
if (ftp_get($conn_id,$local."/".basename($file),$file,FTP_BINARY)) {
$tar = new Archive_Tar($local."/".basename($file));
if ($tar->extractList($extract,$local."/") != false) {
if (ftp_put($conn_id,$save,$local."/".$extract,FTP_BINARY)) {
echo '<div class="success">'.$_lng['extractitemsuccess'].' '.htmlentities($save).'!</div>';
}
else {
echo '<div class="error">'.$_lng['cantsavefile'].'</div>';
}
}
else {
echo '<div class="error">'.$_lng['filenotfound'].'</div>';
}
}
else {
echo '<div class="error">'.$_lng['cantgetfile'].'</div>';
}
}
else {
echo '<form method="post" action="index.php?ftp=open_tar&amp;file='.rawurlencode($file).'&amp;extract='.rawurlencode($extract).'"><b>'.$_lng['saveas'].'</b><br /><input type="text" name="save" value="'.htmlentities($dir.'/'.$extract).'"><br /><input type="submit" name="extract" value="   '.$_lng['extractbutton'].'   "/></form>';
}
echo '</div>';
require_once("includes/footer.php");
}
elseif (isset($_GET['source'])) {
$source = $_GET['source'];
$title = $_lng['sourcetitle'].": ".htmlspecialchars($source);
$ext = getExtension($source);
if (in_array($ext,$arr_unsource)) {
deleteDir($local);
header("Location: index.php?ftp=list");
exit;
}
require_once("includes/header.php");
echo '<div class="content">';
$dir = substr($file,0,"-".(strlen(basename($file)) + 1));
showDirNav($dir);
echo '<b>'.$_lng['filetitle'].':</b> <a href="index.php?ftp=file&amp;file='.rawurlencode($file).'">'.htmlentities($file).'</a><br /><b>'.$_lng['item'].':</b> '.htmlentities($source).'<br />';
if (ftp_get($conn_id,$local."/".basename($file),$file,FTP_BINARY)) {
$tar = new Archive_Tar($local."/".basename($file));
if ($tar->extractList($source,$local."/") != 0) {
$f = file($local."/".$source);
for ($i = 0; $i < count($f); $i++) {
echo htmlentities($f[$i],ENT_QUOTES)."<br />";
}
}
else {
echo '<div class="error">'.$_lng['filenotfound'].'</div>';
}
}
else {
echo '<div class="error">'.$_lng['cantgetfile'].'</div>';
}
echo '</div>';
require_once("includes/footer.php");
}
else {
$title = $_lng['openarchive'].": ".htmlspecialchars($file);
require_once("includes/header.php");
echo '<div class="content">';
$dir = substr($file,0,"-".(strlen(basename($file)) + 1));
showDirNav($dir);
echo '<b>'.$_lng['filetitle'].':</b> <a href="index.php?ftp=file&amp;file='.rawurlencode($file).'">'.htmlentities($file).'</a><br />';
if ($error)
echo '<div class="error">'.$error.'</div>';
if (ftp_get($conn_id,$local."/".basename($file),$file,FTP_BINARY)) {
$tar = new Archive_Tar($local."/".basename($file));
if (($list = $tar->listContent()) == 0) {
echo "<p>".$_lng['archiveempty']."</p>";
}
else {
$arr_ext = array(
"3gp" => "3gp.png",
"avi" => "avi.png",
"bmp" => "bmp.png",
"doc" => "doc.png",
"error_log" => "error_log.png",
"exe" => "exe.png",
"gif" => "gif.png",
"htm" => "htm.png",
"html" => "htm.png",
"jpg" => "jpg.png",
"jpe" => "jpg.png",
"jpeg" => "jpg.png",
"mdb" => "mdb.png",
"mid" => "mid.png",
"midi" => "mid.png",
"mp3" => "mp3.png",
"php" => "php.png",
"png" => "png.png",
"ppt" => "ppt.png",
"psd" => "psd.png",
"rar" => "rar.png",
"rtf" => "rtf.png",
"ttf" => "ttf.png",
"wav" => "wav.png",
"wml" => "wml.png",
"xls" => "xls.png",
"xml" => "xml.png",
"wmv" => "wmv.png",
"txt" => "txt.png",
"zip" => "zip.png",
"tar" => "rar.png",
"tgz" => "rar.png",
"tbz" => "rar.png",
"bz2" => "rar.png",
"tgz2" => "rar.png",
"tbz2" => "rar.png",
"fla" => "fla.png",
"swf" => "swf.png",
"htaccess" => "htaccess.png",
"css" => "css.png",
"py" => "py.png",
"log" => "log.png",
"ini" => "css.png",
"jar" => "jar.png",
"jad" => "jad.png",
"sql" => "sql.png",
"dat" => "dat.png",
"vim" => "vim.png",
"ico" => "ico.png",
"thm" => "thm.png",
"sys" => "sys.png",
"sysx" => "sysx.png",
"url" => "url.png",
"flv" => "flv.png",
"tar" => "tar.png",
"gz" => "tar.png",
"xhtml" => "xhtml.png",
"db" => "db.png"
);
$total = sizeof($list);
$page = $_GET['page'];
$line = $_ftp['view'];
if (!ctype_digit($page) || empty($page) || $page == 0 || $page > (ceil($total / $line)))
$page =1;
$page--;
$start = $page * $line;
$page++;
$end = $start + $line;
if ($end > $total)
$end = $total;
for ($i = $start; $i < $end; $i++) {
$name = preg_replace("~(^/)|(/$)~","",$list[$i]['filename']);
if ($list[$i]['typeflag'] != 5) {
$ext = getExtension(str_replace(".htaccess","dot.htaccess",str_replace("error_log","dot.error_log",$name)));
if ($_ftp['icon'] == "yes") {
if (in_array($ext,array_keys($arr_ext)))
$icon = '<img src="images/'.$arr_ext[$ext].'" width="16" height="16" alt="'.$ext.'"/>';
else
$icon = '<img src="images/unkn.png" width="16" height="16" alt=""/>';
}
else {
$icon = "&raquo";
}

$size = $list[$i]['size'];
if ($size < 1000) {
$size = $size." bytes";
}
elseif ($size < 10240) {
$size = str_replace(".", ",", round($size / 1024, 1))." kb";
}
elseif ($size < 1024000) {
$size = round($size / 1024)." kb";
}
else {
$size = str_replace(".", ",", round($size / 1024 / 1024, 1))." mb";
}
$path = substr($list[$i]['filename'],0,"-".strlen($name));
echo '<div id="files">'.$icon.'&nbsp;';
if (in_array($ext,$arr_unsource))
echo $path.'<b>'.$name.'</b>';
else
echo $path.'<a href="index.php?ftp=open_tar&amp;file='.rawurlencode($file).'&amp;source='.rawurlencode($list[$i]['filename']).'">'.htmlentities($name).'</a>';
echo '&nbsp;('.$size.') <span>[<a href="index.php?ftp=open_tar&amp;file='.rawurlencode($file).'&amp;extract='.rawurlencode($list[$i]['filename']).'">'.$_lng['extracttitle'].'</a>][<a href="index.php?ftp=open_tar&amp;file='.rawurlencode($file).'&amp;download='.rawurlencode($list[$i]['filename']).'">'.$_lng['download'].'</a>]</span></div>';
}
}
echo '<div class="pagination">';
showPagination($page,$line,$total,'index.php?ftp=open_tar&amp;file='.rawurlencode($file).'&amp;page=');
echo '</div>';
}
}
else {
echo '<div class="error">'.$_lng['cantgetfile'].'</div>';
}
echo '</div>';
require_once("includes/footer.php");
}
deleteDir($local);
ftp_close($conn_id);
?>
