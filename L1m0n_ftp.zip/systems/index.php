<?php

/*
------------------ WARNING!!! DO NOT REMOVE THIS LINE ------------------

* Script Name: MyRootFTP
* Version: See VERSION.txt
* Author: Achunk JealousMan
* Email: achunk17@gmail.com
* Homepage: http://myroot.7ko.in
*/

defined('PAGEDISPLAY') or die('Access Forbidden');

if ($client_id != 0) {
header("Location: index.php?ftp=list");
exit;
}
$server = isset($_POST['server']) ? strtolower($_POST['server']) : '';
$username = isset($_POST['username']) ? $_POST['username'] : '';
$dir = isset($_POST['dir']) ? rawurlencode($_POST['dir']) : '%2F';
if (isset($_POST['connect'])) {
$auth = $_POST['auth'];
$password = $_POST['password'];
$size = htmlentities($_POST['size']);
$icon = htmlentities($_POST['icon']);
$port = htmlentities($_POST['port']);
$view = htmlentities($_POST['view']);
$help = htmlentities($_POST['help']);
$time = htmlentities($_POST['time']);
$agreement = htmlentities($_POST['agreement']);
if (!ctype_digit($time))
$time = 17924000;
if ($agreement != 1) {
$error = $_lng['error'].": ".$_lng['agreementerror'];
}
elseif ($_SESSION['auth'] != $auth OR empty($_SESSION['auth'])) {
$error = $_lng['error'].": ".$_lng['sessionerror'];
}
else {
$connect = ftp_connect($server,$port);
$login = ftp_login($connect,$username,$password);
if ($connect && $login) {

$cookie = base64_encode($password) . base64_encode($username) . base64_encode($server);
$cookie = md5($cookie);
$exp = time() + $time;
$cek = mysql_query("SELECT * FROM `".$db_prefix."ftp` WHERE `server` = '".mysql_real_escape_string($server)."' AND `username` = '".mysql_real_escape_string($username)."' AND `password` = '".mysql_real_escape_string($password)."'");
if (mysql_num_rows($cek) == 0) {
mysql_query("INSERT INTO `".$db_prefix."ftp` SET `server` = '".mysql_real_escape_string($server)."', `port` = '".mysql_real_escape_string($port)."', `username` = '".mysql_real_escape_string($username)."', `password` = '".mysql_real_escape_string($password)."', `size` = '".mysql_real_escape_string($size)."', `icon` = '".mysql_real_escape_string($icon)."', `view` = '".mysql_real_escape_string($view)."', `cookie` = '".mysql_real_escape_string($cookie)."', `help` = '".mysql_real_escape_string($help)."'");
$rootid = mysql_insert_id();
}
else {
$_ftp = mysql_fetch_array($cek);
mysql_query("UPDATE `".$db_prefix."ftp` SET `server` = '".mysql_real_escape_string($server)."', `port` = '".mysql_real_escape_string($port)."', `username` = '".mysql_real_escape_string($username)."', `password` = '".mysql_real_escape_string($password)."', `size` = '".mysql_real_escape_string($size)."', `icon` = '".mysql_real_escape_string($icon)."', `view` = '".mysql_real_escape_string($view)."', `cookie` = '".mysql_real_escape_string($cookie)."', `help` = '".mysql_real_escape_string($help)."' WHERE `id` = '".$_ftp['id']."'");
$rootid = $_ftp['id'];
}
setcookie('rootid',$rootid,$exp,'/',$_SERVER['HTTP_HOST']);
setcookie('rootkey',$cookie,$exp,'/',$_SERVER['HTTP_HOST']);
$redir = "index.php?ftp=list&dir=".$dir;
header("Location: ".$redir);
exit;
}
else {
$error = $_lng['ftpconnecterror'];
}
}
}
$title = $_lng['globaltitle'];
require_once("includes/header.php");
echo '<div class="content">';
echo '<div class="info">'.$_lng['cookieterms'].'</div>';

if ($error)
echo '<div class="error">'.$error.'</div>';
echo '<form action="index.php?ftp=index" method="POST">';
$_SESSION['auth'] = md5(rand(1000000,9999999));
echo '<input type="hidden" name="auth" value="'.htmlentities($_SESSION['auth']).'"/><b>'.$_lng['ftpserver'].'</b><br /><input type="text" name="server" value="'.htmlentities($server).'"/><br/>
<b>'.$_lng['ftpport'].'</b><br /><input type="text" name="port" size="3" value="21"/><br />
<b>'.$_lng['ftpusername'].'</b><br /><input type="text" name="username" value="'.htmlentities($username).'"/><br/>
<b>'.$_lng['ftppassword'].'</b><br /><input type="password" name="password" value=""/><br/>
<b>'.$_lng['ftpdirectory'].'</b><br /><input type="text" name="dir" value="'.htmlentities(rawurldecode($dir)).'"/><br />
<b>'.$_lng['showsize'].'</b><br /><select name="size">
<option value="yes">'.$_lng['yes'].'</option>
<option value="no">'.$_lng['no'].'</option>
</select><br />
<b>'.$_lng['showicon'].'</b><br /><select name="icon"><option value="yes">'.$_lng['yes'].'</option><option value="no">'.$_lng['no'].'</option>
</select><br />
<b>'.$_lng['elementsperpage'].'</b><br /><select name="view"><option value="10">10</option><option value="20">20</option><option value="30">30</option><option value="40">40</option><option value="50" selected="selected">50</option><option value="60">60</option><option value="70">70</option><option value="80">80</option><option value="90">90</option><option value="100">100</option>
</select><br /><b>'.$_lng['showhelptext'].'</b><br /><select name="help"><option value="yes">'.$_lng['yes'].'</option><option value="no">'.$_lng['no'].'</option>
</select><br />
<b>'.$_lng['loginfor'].'</b><br /><select name="time"><option value="600">10 '.$_lng['minute'].'</option><option value="3600">1 '.$_lng['hour'].'</option><option value="85400">1 '.$_lng['day'].'</option><option value="597800">1 '.$_lng['week'].'</option><option value="17924000" selected="selected">1 '.$_lng['month'].'</option></select><br /><input type="checkbox" name="agreement" value="1"/> '.$_lng['agreement'].'<br /><input type="submit" name="connect" value="   '.$_lng['connectbutton'].'   "/></form></div><div class="menu"><ul><li><a href="/installer/">FTP Installer</a></li><li><a href="http://ht24.gq">Free Premium Hosting</a></li><li><a href="http://tipsview24.ml">Free Mobile Blog</a></li></ul></div>';
require_once("includes/footer.php");
?>
