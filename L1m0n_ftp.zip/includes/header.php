<?php

/*
------------------ WARNING!!! DO NOT REMOVE THIS LINE ------------------

* Script Name: MyRootFTP
* Version: See VERSION.txt
* Author: Achunk JealousMan
* Email: achunk17@gmail.com
* Homepage: http://myroot.7ko.in
*/

defined('PAGEDISPLAY') or die('OK');
$title = isset($title) ? $title : $_SERVER['HTTP_HOST'];
echo '<?xml version="1.0" encoding="utf-8"?><!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN"
"http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head><title>'.$title.'</title>

<link rel="shortcut icon" href="favicon.ico"/>
<link rel="stylesheet" href="style.css" type="text/css"/>
</head><body>';
echo '<div id="header"><h1>';
if ($conn_id && $login)
echo '<a href="./">'.strtoupper(htmlentities($_ftp['username'])).'</a>';
else
echo '<a href="./">'.strtoupper(htmlentities($_SERVER['HTTP_HOST'])).'</a>';
echo '</h1></div>';
if ($conn_id && $login)
echo '<div class="topnav"><a href="index.php?ftp=settings">'.$_lng['settings'].'</a><a href="index.php?ftp=logout">'.$_lng['logout'].'</a><a href="http://fb.com/sattartips">Contact Us</a></div>';
else
echo '<div class="topnav"><a href="http://tipsview24.ml">Open Source</a><a href="http://ht24.gq">Free Hosting</a></div>';
echo '<div id="wrapper">';
?>
