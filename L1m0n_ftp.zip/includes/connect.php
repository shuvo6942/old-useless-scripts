<?php

/*
------------------ WARNING!!! DO NOT REMOVE THIS LINE ------------------

* Script Name: MyRootFTP
* Version: See VERSION.txt
* Author: Achunk JealousMan
* Email: achunk17@gmail.com
* Homepage: http://myroot.7ko.in
*/

defined('PAGEDISPLAY') or die('Access Forbidden!');
$rootid = isset($_COOKIE['rootid']) ? stripslashes($_COOKIE['rootid']) : '';
$rootkey = isset($_COOKIE['rootkey']) ? stripslashes($_COOKIE['rootkey']) : '';
$sql_connect = mysql_connect($db_host,$db_user,$db_pass);
if (!$sql_connect) {
die("Connecting Error!");
exit;
}
mysql_select_db($db_name) or die('Database Error!');

$req = mysql_query("SELECT * FROM `".$db_prefix."ftp` WHERE `id` = '".mysql_real_escape_string($rootid)."' AND `cookie` = '".mysql_real_escape_string($rootkey)."'");
$client_id = mysql_num_rows($req);

if ($client_id != 0) {
$_ftp = mysql_fetch_array($req);
$conn_id = ftp_connect($_ftp['server'],$_ftp['port']);
$login = ftp_login($conn_id,$_ftp['username'],$_ftp['password']);
if ($conn_id && $login) {
ftp_pasv($conn_id, true);
$sol = time() - 300;
if ($_ftp['lastlogin'] < $sol)
{
mysql_query("UPDATE `".$db_prefix."ftp` SET `lastlogin` = '".time()."', `delete` = '".time()."' WHERE id = '".$_ftp['id']."'");
}
}
else {
if ($_GET['ftp'] != "logout") {
$title = "Connecting Error";
require_once("includes/header.php");
echo '<div class="content"><div class="error">'.$_lng['connectingerror'].'<br />'.$_lng['ftpserver'].': '.htmlentities($_ftp['server']).'<br />'.$_lng['ftpport'].': '.htmlentities($_ftp['port']).'<br />'.$_lng['ftpusername'].': '.htmlentities($_ftp['username']).'<br />'.$_lng['ftppassword'].': ****<br /><a href="index.php?ftp=logout">'.$_lng['logout'].'</a> '.$_lng['connectingerror2'].'</div></div>';
require_once("includes/footer.php");
exit;
}
}
}
?>