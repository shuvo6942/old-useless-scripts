<?php
/*淡然汉化*
18772635637@139.com
汉化日期 2012 12
*/
$_lng['aboutftp'] = "淡然汉化";
$_lng['actionbutton'] = "确定";
$_lng['actionconfirm'] = "确定操作?";
$_lng['agreement'] = "我相信，我的<a href='privacy.php'>隐私</a>在这里是安全的.";
$_lng['agreementerror'] = "你不批准标记列.";
$_lng['archiveempty'] = "空文件";

// B
$_lng['back'] = "后退";
$_lng['backupwithdirectory'] = "%s 目录内?";
$_lng['backupbutton'] = "备份";
$_lng ['backuperror'] = "无法创建";
$_lng['backupsuccess'] =  "文件创建成功并保存为";
$_lng['backuptitle'] = "备份";

// C
$_lng['cantcopyfile'] = "无法复制文件";
$_lng['cantcopydirectory'] = "无法复制目录";
$_lng['cantcreatedirectory'] = "不能创建目录";
$_lng['cantcreatefile'] = "不能创建文件";
$_lng['cantgetfile'] = "无法获取文件";
$_lng['cantsavefile'] = "无法保存文件";
$_lng['checksyntax'] = "检查语法";
$_lng['chmod'] = "CHMOD";
$_lng['chmodbutton'] = "Chmod";
$_lng['connectbutton'] = "登录";
$_lng['chmoddirerror'] = "目录 %s1 不能 chmod 命令 %s2";
$_lng['chmoddirsuccess'] = "目录 %s1 成功 chmod 命令 %s2";
$_lng['chmodfileerror'] = "文件 %s1 不能 chmod 命令 %s2";
$_lng['chmodfilesuccess'] = "文件 %s1 成功 chmod 命令 %s2";
$_lng['chmoddirectory'] = "CHMOD 目录";
$_lng['chmoderror'] = "Chmod 失败!";
$_lng['chmodfile'] = "CHMOD 文件";
$_lng['chmodterms'] = "CHMOD为3个字符!";
$_lng['chmodtitle'] = "Chmod";
$_lng['connectingerror'] = "无法连接到FTP服务器的帐户详情如下.";
$_lng['connectingerror2'] = "或稍后重试.";
$_lng['contact'] = "联系";
$_lng['cookieterms'] = "亲，要启用Cookies和JavaScript哦.";
$_lng['copybutton'] = "复制";
$_lng['copydirerror'] = "目录: %s<br/>不能复制 %s1 到 %s2";
$_lng['copydirsuccess'] = "目录: %s<br/>成功复制 %s1 到 %s2";
$_lng['copyfileerror'] = "文件: %s<br/>不能复制 %s1 到 %s2";
$_lng['copyfilesuccess'] = "文件: %s<br/>成功复制 %s1 到 %s2";
$_lng['copygeterror'] = "目录: %s<br/>无法获取文件 %s2";
$_lng['copyfilegeterror'] = "文件: %s<br />无法获取文件 %s2";
$_lng['copyto'] = "复制到";
$_lng['copytitle'] = "复制";
$_lng['createbutton'] = "创建";
$_lng['createtitle'] = "创建";
$_lng['createinstaller'] = "创建安装程序";
$_lng['createsqlbutton'] = "创建";

// D
$_lng['day'] = "天";
$_lng['deletedirectoryerror'] = "Error 删除目录";
$_lng['deletefileerror'] = "Error 删除文件";
$_lng['deleteconfirm'] = "您确定您要删除这个吗？";
$_lng['deletedirerror'] = "目录 %s 不能被删除";
$_lng['deletefileerror'] = "文件 %s 不能被删除";
$_lng['deletedirsuccess'] = "目录 %s 删除成功";
$_lng['deletefilesuccess'] = "文件 %s 删除成功";
$_lng['deletetitle'] = "删除";
$_lng['deletebutton'] = "删除";
$_lng['directory'] = "目录";
$_lng['download'] = "下载";

// E
$_lng['editerror'] = "不能保存更改";
$_lng['editfile'] = "编辑文件";
$_lng['editsuccess'] = "成功保存的更改";
$_lng['elementsperpage'] = "每页显示文件";
$_lng['emptyname'] = "名称不能为空";
$_lng['emptynewname'] = "新名称不能为空!";
$_lng['error'] = "错误!";
$_lng['extractbutton'] = "提取";
$_lng['extracttitle'] = "提取";
$_lng['extractarchive'] = "提取归档";
$_lng['extracterror'] = "无法解压缩文件";
$_lng['extractitemsuccess'] = "项目成功地提取并保存为";

// F
$_lng['faq'] = "FAQ";
$_lng['fileinfo'] = "文件信息";
$_lng['filename'] = "名称";
$_lng['filesize'] = "大小";
$_lng['filenotfound'] = "文件未找到!";
$_lng['filetitle'] = "文件";
$_lng['filetoobig'] = "文件 %s 文件太大,最大文件5MB";
$_lng['formerror'] = "请填写表格!";
$_lng['ftpconnecterror'] = "无法连接到FTP服务器!";
$_lng['ftpdirectory'] = "默认目录";
$_lng['ftppassword'] = "密码";
$_lng['ftpport'] = "FTP 端口";
$_lng['ftpserver'] = "FTP 服务器";
$_lng['ftpusername'] = "用户名";

// G
$_lng['globaltitle'] = "My Root FTP - 淡然";
$_lng['go'] = "Go";

// H
$_lng['height'] = "高";
$_lng['hour'] = "小时";

// I
$_lng['imageresize'] = "图片大小";
$_lng['importbutton'] = "导入";
$_lng['importtitle'] = "导入";
$_lng['importsuccess'] = "文件 %s 成功导入";
$_lng['item'] = "项目";

// L
$_lng['language'] = "语言";
$_lng['lastmodified'] = "最后修改";
$_lng['listtitle'] = "列表";
$_lng['login'] = "登录";
$_lng['loginfor'] = "Cookie有效期";
$_lng['logout'] = "退出";

// M
$_lng['minute'] = "分";
$_lng['month'] = "月";
$_lng['movebutton'] = "移动";
$_lng['moveerror'] = "移动出错了";
$_lng['movedirerror'] = "目录 %s1 不能移动到 %s2";
$_lng['movedirsuccess'] = "目录 %s1 成功移动到 %s2";
$_lng['movefileerror'] = "文件 %s1 不能转移到 %s2";
$_lng['movefilesuccess'] = "文件 %s1 成功移动到 %s2";
$_lng['movetitle'] = "移动";
$_lng['moveto'] = "移动到…";

// N
$_lng['name'] = "文件名";
$_lng['newname'] = "新文件名";
$_lng['no'] = "不显示";

// O
$_lng['oldname'] = "旧名称";
$_lng['openarchive'] = "打开文件";

// P
$_lng['password'] = "密码";

// R
$_lng['renamebutton'] = "重命名";
$_lng['renamedirerror'] = "目录 %s1 不能重命名为 %s2";
$_lng['renamedirsuccess'] = "目录 %s1 成功重命名为 %s2";
$_lng['renameerror'] = "重命名失败!";
$_lng['renamefileerror'] = "文件 %s1 不能重命名为 %s2";
$_lng['renamefilesuccess'] = "文件 %s1 成功重命名为 %s2";
$_lng['renametitle'] = "重命名";
$_lng['renameto'] = "重命名为";
$_lng['resizeimage'] = "调整大小";
$_lng['resizeimageerror'] = "图片不能保存";
$_lng['resizeimagesuccess'] = "图片已经调整， %w x %h 并保存为 %image";

// S
$_lng['saveas'] = "另存为";
$_lng['savebutton'] = "保存";
$_lng['sessionerror'] = "Session 超时.";
$_lng['settings'] = "设置";
$_lng['settingssuccessfullysaved'] = "设置保存成功";
$_lng['showhelptext'] = "显示帮助提示";
$_lng['showicon'] = "显示图片";
$_lng['showsize'] = "显示大小";
$_lng['sourcetitle'] = "查看";
$_lng['sqldatabase'] = "数据库";
$_lng['sqlhost'] = "主机";
$_lng['sqlpassword'] = "密码";
$_lng['sqluser'] = "用户";
$_lng['syntaxtitle'] = "句法";

// T
$_lng['totalfile'] = "总文件";
$_lng['type'] = "类型";

// U
$_lng['unableextract'] = "无法解压缩文件";
$_lng['untarbutton'] = "提取";
$_lng['untartitle'] = "解压缩";
$_lng['untarerror'] = "无法发送到您的服务器.";
$_lng['untarsuccess'] = "成功发送到您的服务器.";
$_lng['unzipbutton'] = "解压缩";
$_lng['unziperror'] = "无法发送到您的服务器.";
$_lng['unzipdir'] = "目录";
$_lng['unzipsuccess'] = "成功发送到您的服务器.";
$_lng['unziptitle'] = "解压缩";
$_lng['uploadbutton'] = "上传";
$_lng['uploaderror'] = "不能上传.";
$_lng['uploadinfo'] = "选择文件(每个文件最多5M)";
$_lng['uploadsuccess'] = "上传成功.";
$_lng['uploadtitle'] = "上传";

// W
$_lng['width'] = "宽";
$_lng['week'] = "星期";
$_lng['withselected'] = "全选";
$_lng['withsize'] = "与大小";

// Y
$_lng['yes'] = "是";

// Z
$_lng['zipinstaller'] = "Zip 安装";

$_lng['help_chmod'] = "设置目录或文件的权限. CHMOD 只允许是3位数字 如：(755，777)";
$_lng['help_copy'] = "复制文件或目录,目标目录必须已经存在.";
$_lng['help_create'] = "请填写名称，并选择类型。如果你创建了一个文件，然后CHMOD自动为644,如果你创建一个目录，然后自动的CHMOD 755.";
$_lng['help_list'] = "不懂，请联系淡然.";
$_lng['help_move'] = "移动文件或目录到另一个目录,目标目录必须已经存在.";
$_lng['help_unzip'] = "请提取这个文件中插入目录的位置,如果目标目录不存在,将自动创建.";
?>