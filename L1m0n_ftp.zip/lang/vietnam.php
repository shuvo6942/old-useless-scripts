<?
// A
$_lng['aboutftp'] = "<h1>Tentang FTP</h1>Giao thức tập tin giao hàng
(tiếng Anh: File Transfer
Protocol) là một giao thức
Internet chạy trên lớp ứng
dụng là tiêu chuẩn cho việc
cung cấp máy tính của tập tin (file) giữa các máy trong một
liên mạng.<br />FTP là một trong những giao
thức Internet đầu tiên được
phát triển, và vẫn được sử
dụng ngày hôm nay để thực
hiện tải về (download) và các
tập tin giữa các máy tính của bạn và khách hàng FTP FTP
server, penggugahan
(upload). Một khách hàng FTP
là một ứng dụng có thể ra
lệnh FTP đến một máy chủ
FTP, trong khi các máy chủ FTP là một dịch vụ Windows
hoặc daemon chạy trên một
máy tính đáp ứng các lệnh từ
một máy khách FTP.<br />Lệnh FTP có thể được sử dụng
để thay đổi thư mục, thay đổi
chế độ giao hàng giữa hệ nhị
phân, các tập tin ASCII máy
tính gợi nhiều liên tưởng đến
máy chủ FTP và tải về một tập tin từ một máy chủ FTP.<br />Một máy chủ FTP được truy
cập bằng cách sử dụng một
Universal Resource Identifier
(URI) bằng cách sử dụng
ftp://namaserver định dạng.
FTP khách hàng có thể liên lạc với máy chủ FTP bằng cách
mở các URI.<br />Sử dụng giao thức FTP
Transmission Control Protocol
(TCP) để truyền dữ liệu giữa
máy khách và máy chủ, do đó
giữa hai thành phần sẽ được
thực hiện một phiên giao tiếp trước khi truyền dữ liệu bắt
đầu. Trước khi thực hiện kết
nối, số cổng TCP 21 ở phía
máy chủ \"mendengarkan\" thí nghiệm kết nối từ một
khách hàng FTP và sau đó
được sử dụng như là một
cổng điều khiển (kiểm soát
cảng) (1) làm cho kết nối
giữa máy chủ và khách, (2) để cho phép khách hàng để gửi
một lệnh cho các máy chủ FTP
và cũng (3) trả về phản ứng
máy chủ để đặt hàng. Một khi
các kết nối điều khiển đã
được thực hiện, sau đó máy chủ sẽ bắt đầu mở cổng TCP
số 20 để thiết lập một kết nối
mới với khách hàng để gửi
dữ liệu thực tế đang được
trao đổi trong quá trình
download và penggugahan.<br />FTP chỉ sử dụng phương pháp
xác thực tiêu chuẩn, cụ thể là
bằng cách sử dụng tên người
dùng và mật khẩu được gửi
trong các hình thức tar không
được mã hóa. Người dùng đăng ký có thể sử dụng tên
người dùng và mật khẩu để
truy cập, tải về, và tải lên các
tập tin mình muốn. Nói
chung, người dùng đăng ký có
thể truy cập vào nhiều thư mục, do đó, họ có thể tạo ra
các tập tin, tạo thư mục, và
thậm chí xóa các tập tin.
Người dùng không đăng ký
cũng có thể sử dụng phương
pháp đăng nhập vô danh, bằng cách sử dụng một tên
người dùng và mật khẩu đầy
ẩn danh bằng cách sử dụng
địa chỉ e-mail.<br /><br />Sumber: <a href=\"http://id.wikipedia.org/wiki/Protokol_Transfer_Berkas\">http://id.wikipedia.org/wiki/Protokol_Transfer_Berkas</a>";
$_lng['actionbutton'] = "Áp dụng";
$_lng['actionconfirm'] = "Bạn có chắc chắn sẽ hành
động này?";
$_lng['agreement'] = "Tôi tin rằng các <a href=\"privacy.php\">privacy</a> tài khoản của tôi là an toàn ở
đây.";
$_lng['agreementerror'] = "Bạn không đánh dấu cột
chính.";
$_lng['archiveempty'] = "Lưu Trữ rỗng";

// B
$_lng['back'] = "Trở Về";
$_lng['backupwithdirectory'] = "Với bên trong thư mục %s?";
$_lng['backupbutton'] = "Sao lưu";
$_lng ['backuperror'] = "Không thể tạo";
$_lng['backupsuccess'] = "Lưu trữ tạo thành công và đã
được lưu";
$_lng['backuptitle'] = "Sao lưu";

// C
$_lng['cantcopyfile'] = "Không thể sao chép tập tin!";
$_lng['cantcopydirectory'] = "Không thể sao chép thư mục!";
$_lng['cantcreatedirectory'] = "Không thể tạo thư mục";
$_lng['cantcreatefile'] = "Không thể tạo tập tin";
$_lng['cantgetfile'] = "Không thể nhận được tập tin!";
$_lng['cantsavefile'] = "Không thể lưu các tập tin";
$_lng['checksyntax'] = "Kiểm tra cú pháp";
$_lng['chmod'] = "CHMOD";
$_lng['chmodbutton'] = "Chmod";
$_lng['connectbutton'] = "Kết nối";
$_lng['chmoddirerror'] = "Thư mục %s1 không thể
chmod %s2";
$_lng['chmoddirsuccess'] = "Thư mục s1% thành công
chmod %s2";
$_lng['chmodfileerror'] = "Tập tin %s1 không thể chmod
%s2";
$_lng['chmodfilesuccess'] = "Tập tin %s1 chmod %s2 thành công";
$_lng['chmoddirectory'] = "CHMOD thư mục";
$_lng['chmoderror'] = "Chmod failed!";
$_lng['chmodfile'] = "CHMOD Tập tin";
$_lng['chmodterms'] = "Chmod chỉ số cho phép và
chiều dài 3!";
$_lng['chmodtitle'] = "Chmod";
$_lng['connectingerror'] = "Không thể để kết nối với máy
chủ FTP với các chi tiết tài
khoản dưới đây.";
$_lng['connectingerror2'] = "hoặc thử lại sau.";
$_lng['contact'] = "Liên hệ";
$_lng['cookieterms'] = "Cookies và Javascript phải
được bật.";
$_lng['copybutton'] = "Sao chép";
$_lng['copydirerror'] = "Thư mục: %s<br />Can't copy %s1 to %s2";
$_lng['copydirsuccess'] = "Thư mục: %s<br />Successfully copy %s1 to %s2";
$_lng['copyfileerror'] = "Tập tin: %s<br />Không thể sao chép %s1 tới %s2";
$_lng['copyfilesuccess'] = "Tập tin: %s<br />sao chép  %s1 tới %s2 thành công";
$_lng['copygeterror'] = "Thư mục: %s<br />Không thể có được các tập tin %s2";
$_lng['copyfilegeterror'] = "File: %s<br />Không thể có được các tập tin %s2";
$_lng['copyto'] = "Hội trường tới";
$_lng['copytitle'] = "Hội trường";
$_lng['createbutton'] = "Tạo";
$_lng['createtitle'] = "Tạo";
$_lng['createinstaller'] = "Tạo cài đặt";
$_lng['createsqlbutton'] = "Tạo";

// D
$_lng['day'] = "Ngày";
$_lng['deletedirectoryerror'] = "Lỗi khi xóa thư mục";
$_lng['deletefileerror'] = "Lỗi khi xóa tập tin";
$_lng['deleteconfirm'] = "Bạn có chắc bạn muốn xóa?";
$_lng['deletedirerror'] = "Không thể bị xóa thư mục %s";
$_lng['deletefileerror'] = "Không thể xóa tập tin %s";
$_lng['deletedirsuccess'] = "Thư mục %s xóa thành công";
$_lng['deletefilesuccess'] = "Tập tin %s xoá thành công";
$_lng['deletetitle'] = "Xoá";
$_lng['deletebutton'] = "Xoá";
$_lng['directory'] = "Thư mục";
$_lng['download'] = "Tải về";
// E
$_lng['editerror'] = "Thay đổi không thể được lưu";
$_lng['editfile'] = "Sửa tập tin";
$_lng['editsuccess'] = "Thay đổi đã được lưu";
$_lng['elementsperpage'] = "Các yếu tố trên một trang";
$_lng['emptyname'] = "Tên không thể để trống";
$_lng['emptynewname'] = "Tên mới không thể để trống!";
$_lng['error'] = "Lỗi rồi!";
$_lng['extractbutton'] = "Giải nén";
$_lng['extracttitle'] = "Giải nén";
$_lng['extractarchive'] = "Giải nén lưu trữ";
$_lng['extracterror'] = "Không thể giải nén tập tin";
$_lng['extractitemsuccess'] = "Mục giải nén thành công và đã được lưu";

// F
$_lng['faq'] = "FAQ";
$_lng['fileinfo'] = "Thông tin tệp tin";
$_lng['filename'] = "Tên";
$_lng['filesize'] = "Kích thước";
$_lng['filenotfound'] = "Không tìm thấy tệp tin!";
$_lng['filetitle'] = "Tệp tin";
$_lng['filetoobig'] = "Tệp tin %s quá lớn để nhập khẩu. Kích thước tập tin tối đa 5MB";
$_lng['formerror'] = "Xin vui lòng hoàn thành các hình thức!";
$_lng['ftpconnecterror'] = "Không thể kết nối đến máy chủ FTP!";
$_lng['ftpdirectory'] = "Thư mục";
$_lng['ftppassword'] = "Mật Khẩu";
$_lng['ftpport'] = "Cổng FTP";
$_lng['ftpserver'] = "Máy Chủ FTP";
$_lng['ftpusername'] = "Tên đăng nhập";

// G
$_lng['globaltitle'] = "My Root FTP";
$_lng['go'] = "Go";

// H
$_lng['height'] = "Cao";
$_lng['hour'] = "Giờ";

// I
$_lng['imageresize'] = "Resize ảnh";
$_lng['importbutton'] = "Nhập khẩu";
$_lng['importtitle'] = "Nhập khẩu";
$_lng['importsuccess'] = "Tệp tin %s nhập khẩu thành công";
$_lng['item'] = "Mục";

// L
$_lng['language'] = "Ngôn ngữ";
$_lng['lastmodified'] = "Thay đổi lần cuối";
$_lng['listtitle'] = "Danh sách";
$_lng['login'] = "Đăng nhập";
$_lng['loginfor'] = "Đăng nhập cho";
$_lng['logout'] = "Đăng xuất";

// M
$_lng['minute'] = "Phút";
$_lng['month'] = "Tháng";
$_lng['movebutton'] = "Di chuyển";
$_lng['moveerror'] = "Di chuyển lỗi";
$_lng['movedirerror'] = "Thư mục %s1 không thể chuyển đến %s2";
$_lng['movedirsuccess'] = "Thư mụ2 %s1 đã di chuyển đến %s2";
$_lng['movefileerror'] = "Tệp tin %s1 không thể di chuyển đến %s2";
$_lng['movefilesuccess'] = "Tập tin %s1 đã di chuyển đến %s2";
$_lng['movetitle'] = "Di chuyển";
$_lng['moveto'] = "Di chuyển đến";

// N
$_lng['name'] = "Tên";
$_lng['newname'] = "Tên mới";
$_lng['no'] = "Không";

// O
$_lng['oldname'] = "Tên cũ";
$_lng['openarchive'] = "Mở kho lưu trữ";

// P
$_lng['password'] = "Mật khẩu";

// R
$_lng['renamebutton'] = "Đổi tên";
$_lng['renamedirerror'] = "Thư mục %s1 không thể đổi tên thành %s2";
$_lng['renamedirsuccess'] = "Thư mục %s1 đã đổi tên thành %s2";
$_lng['renameerror'] = "Đổi tên thất bại!";
$_lng['renamefileerror'] = "Tệp tin %s1 không thể đổi tên thành %s2";
$_lng['renamefilesuccess'] = "Tệp tin %s1 đã đổi tên thành %s2";
$_lng['renametitle'] = "Đổi tên";
$_lng['renameto'] = "Đổi tên thành";
$_lng['resizeimage'] = "Thay đổi kích thước";
$_lng['resizeimageerror'] = "Không thể lưu hình ảnh";
$_lng['resizeimagesuccess'] = "Hình ảnh đã được thay đổi kích thước %w x %h và lưu dưới dạng %image";

// S
$_lng['saveas'] = "Lưu tất cả";
$_lng['savebutton'] = "Lưu";
$_lng['sessionerror'] = "Session time out.";
$_lng['settings'] = "Thiết lập";
$_lng['settingssuccessfullysaved'] = "Thiết lập lưu thành công";
$_lng['showhelptext'] = "Hiển thị văn bản giúp đỡ";
$_lng['showicon'] = "Show icon";
$_lng['showsize'] = "Show size";
$_lng['sourcetitle'] = "Source";
$_lng['sqldatabase'] = "Cơ sở dữ liệu";
$_lng['sqlhost'] = "Host";
$_lng['sqlpassword'] = "Mật khẩu";
$_lng['sqluser'] = "Người sử dụng";
$_lng['syntaxtitle'] = "Cú pháp";

// T
$_lng['totalfile'] = "Tổng số tệp tin";
$_lng['type'] = "Loại";

// U
$_lng['unableextract'] = "Không thể giải nén tập tin";
$_lng['untarbutton'] = "Giải nén";
$_lng['untartitle'] = "Giải nén";
$_lng['untarerror'] = "không thể gửi đến máy chủ của bạn.";
$_lng['untarsuccess'] = "gửi thành công đến máy chủ của bạn.";
$_lng['unzipbutton'] = "Unzip";
$_lng['unziperror'] = "không thể gửi đến máy chủ của bạn";
$_lng['unzipdir'] = "Thư mục";
$_lng['unzipsuccess'] = "gửi thành công đến máy chủ của bạn.";
$_lng['unziptitle'] = "Unzip";
$_lng['uploadbutton'] = "Tải lên";
$_lng['uploaderror'] = "không thể tải lên.";
$_lng['uploadinfo'] = "Chọn các tập tin (tối đa 5 mb cho mỗi tập tin)";
$_lng['uploadsuccess'] = "tải lên thành công.";
$_lng['uploadtitle'] = "Tải lên";

// W
$_lng['width'] = "Chiều rộng";
$_lng['week'] = "Tuần";
$_lng['withselected'] = "Với các yếu tố được lựa chọn";
$_lng['withsize'] = "với kích thước";

// Y
$_lng['yes'] = "Có";

// Z
$_lng['zipinstaller'] = "Zip cài đặt";

$_lng['help_chmod'] = "Thiết lập quyền cho thư mục hoặc tập tin. CHMOD chỉ số cho phép (000 lên đến 777) và phải có 3 chữ số";
$_lng['help_copy'] = "Sao chép tập tin hoặc thư mục. Thư mục đích đã phải tồn tại.";
$_lng['help_create'] = "Xin vui lòng chèn Name và chọn loại. Nếu bạn tạo File sau đó CHMOD tự động 644 và nếu bạn tạo thư mục sau đó CHMOD tự động đến 755.";
$_lng['help_list'] = "Đang hiển thị các thư mục và tập tin. Để bắt đầu tạo thư mục hoặc tập tin, xin vui lòng bấm vào <b>Tạo</b>.";
$_lng['help_move'] = "Di chuyển tập tin hoặc thư mục vào thư mục khác. Thư mục đích đã phải tồn tại.";
$_lng['help_unzip'] = "Xin vui lòng chèn vị trí thư mục để giải nén tập tin này. Nếu thư mục đích không tồn tại, nó sẽ được tạo tự động.";
?>
