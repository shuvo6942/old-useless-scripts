<?
// A
$_lng['aboutftp'] = "<h1>Tentang FTP</h1>Protokol pengiriman berkas (Bahasa inggris: File Transfer Protocol) adalah sebuah protokol Internet yang berjalan di dalam lapisan aplikasi yang merupakan standar untuk pengiriman berkas (file) komputer antar mesin-mesin dalam sebuah Antar jaringan.<br />FTP merupakan salah satu protokol Internet yang paling awal dikembangkan, dan masih digunakan hingga saat ini untuk melakukan pengunduhan (download) dan penggugahan (upload) berkas-berkas komputer antara klien FTP dan server FTP. Sebuah Klien FTP merupakan aplikasi yang dapat mengeluarkan perintah-perintah FTP ke sebuah server FTP, sementara server FTP adalah sebuah Windows Service atau daemon yang berjalan di atas sebuah komputer yang merespons perintah-perintah dari sebuah klien FTP.<br />Perintah-perintah FTP dapat digunakan untuk mengubah direktori, mengubah modus pengiriman antara biner dan ASCII, menggugah berkas komputer ke server FTP, serta mengunduh berkas dari server FTP.<br />Sebuah server FTP diakses dengan menggunakan Universal Resource Identifier (URI) dengan menggunakan format ftp://namaserver. Klien FTP dapat menghubungi server FTP dengan membuka URI tersebut.<br />FTP menggunakan protokol Transmission Control Protocol (TCP) untuk komunikasi data antara klien dan server, sehingga di antara kedua komponen tersebut akan dibuatlah sebuah sesi komunikasi sebelum pengiriman data dimulai. Sebelum membuat koneksi, port TCP nomor 21 di sisi server akan \"mendengarkan\" percobaan koneksi dari sebuah klien FTP dan kemudian akan digunakan sebagai port pengatur (control port) untuk (1) membuat sebuah koneksi antara klien dan server, (2) untuk mengizinkan klien untuk mengirimkan sebuah perintah FTP kepada server dan juga (3) mengembalikan respons server ke perintah tersebut. Sekali koneksi kontrol telah dibuat, maka server akan mulai membuka port TCP nomor 20 untuk membentuk sebuah koneksi baru dengan klien untuk mengirim data aktual yang sedang dipertukarkan saat melakukan pengunduhan dan penggugahan.<br />FTP hanya menggunakan metode autentikasi standar, yakni menggunakan username dan password yang dikirim dalam bentuk tidak ter enkripsi. Pengguna terdaftar dapat menggunakan username dan password-nya untuk mengakses, men-download, dan meng-upload berkas-berkas yang ia kehendaki. Umumnya, para pengguna terdaftar memiliki akses penuh terhadap beberapa direktori, sehingga mereka dapat membuat berkas, membuat direktori, dan bahkan menghapus berkas. Pengguna yang belum terdaftar dapat juga menggunakan metode anonymous login, yakni dengan menggunakan nama pengguna anonymous dan password yang diisi dengan menggunakan alamat e-mail.<br /><br />Sumber: <a href=\"http://id.wikipedia.org/wiki/Protokol_Transfer_Berkas\">http://id.wikipedia.org/wiki/Protokol_Transfer_Berkas</a>";
$_lng['actionbutton'] = "Lakukan";
$_lng['actionconfirm'] = "Kamu yakin akan melakukan tindakan ini?";
$_lng['agreement'] = "Saya percaya bahwa <a href=\"privacy.php\">privasi</a> akun saya aman di sini.";
$_lng['agreementerror'] = "Anda belum menandai kolom persetujuan.";
$_lng['archiveempty'] = "Arsip Kosong";

// B
$_lng['back'] = "Kembali";
$_lng['backupwithdirectory'] = "Dengan direktori %s di dalamnya?";
$_lng['backupbutton'] = "Backup";
$_lng ['backuperror'] = "Gagal untuk membuat";
$_lng['backupsuccess'] = "Arsip berhasil dibuat dan telah disimpan sebagai";
$_lng['backuptitle'] = "Backup";

// C
$_lng['cantcopyfile'] = "Gagal menyalin berkas!";
$_lng['cantcopydirectory'] = "Tidak dapat menyalin direktori!";
$_lng['cantcreatedirectory'] = "Tidak dapat membuat direktori";
$_lng['cantcreatefile'] = "Tidak dapat membuat berkas";
$_lng['cantgetfile'] = "Tidak dapat mengambil berkas!";
$_lng['cantsavefile'] = "Tidak dapat menyimpan berkas";
$_lng['checksyntax'] = "Periksa Sintaks";
$_lng['chmod'] = "CHMOD";
$_lng['chmodbutton'] = "Chmod";
$_lng['connectbutton'] = "Koneksikan";
$_lng['chmoddirerror'] = "Direktori %s1 tidak dapat di-chmod ke %s2";
$_lng['chmoddirsuccess'] = "Direktori %s1 berhasil di-chmod ke %s2";
$_lng['chmodfileerror'] = "Berkas %s1 tidak dapat di-chmod ke %s2";
$_lng['chmodfilesuccess'] = "Berkas %s1 berhasil di-chmod ke %s2";
$_lng['chmoddirectory'] = "CHMOD Direktori";
$_lng['chmoderror'] = "Chmod gagal!";
$_lng['chmodfile'] = "CHMOD Berkas";
$_lng['chmodterms'] = "Chmod hanya digit angka yang diperbolehkan dan panjang 3 angka!";
$_lng['chmodtitle'] = "Chmod";
$_lng['connectingerror'] = "Tidak dapat terhubung ke FTP server dengan rincian akun di bawah ini.";
$_lng['connectingerror2'] = "atau coba lagi nanti.";
$_lng['contact'] = "Kontak";
$_lng['cookieterms'] = "Cookie dan Javascript harus diaktifkan.";
$_lng['copybutton'] = "Salin";
$_lng['copydirerror'] = "Direktori: %s<br />Tidak dapat menyalin %s1 ke %s2";
$_lng['copydirsuccess'] = "Direktori: %s<br />Berhasil menyalin %s1 ke %s2";
$_lng['copyfileerror'] = "Berkas: %s<br />Tidak dapat menyalin %s1 ke %s2";
$_lng['copyfilesuccess'] = "Berkas: %s<br />Berhasil menyalin %s1 ke %s2";
$_lng['copygeterror'] = "Direktor: %s<br />Tidak dapat mengambil berkas %s2";
$_lng['copyfilegeterror'] = "Berkas: %s<br />Tidak dapat mengambil berkas %s2";
$_lng['copyto'] = "Salin ke";
$_lng['copytitle'] = "Salin";
$_lng['createbutton'] = "Membuat";
$_lng['createtitle'] = "Membuat";
$_lng['createinstaller'] = "Membuat Penginstall";
$_lng['createsqlbutton'] = "Membuat";

// D
$_lng['day'] = "Hari";
$_lng['deletedirectoryerror'] = "Kesalahan menghapus direktori";
$_lng['deletefileerror'] = "Kesalahan menghapus berkas";
$_lng['deleteconfirm'] = "Apakah kamu yakin ingin menghapus ini?";
$_lng['deletedirerror'] = "Direktori %s tidak dapat dihapus";
$_lng['deletefileerror'] = "Berkas %s tidak dapat dihapus";
$_lng['deletedirsuccess'] = "Direktori %s berhasil dihapus";
$_lng['deletefilesuccess'] = "Berkas %s berhasil dihapus";
$_lng['deletetitle'] = "Hapus";
$_lng['deletebutton'] = "Hapus";
$_lng['directory'] = "Direktori";
$_lng['download'] = "Unduh";

// E
$_lng['editerror'] = "Perubahan tidak dapat disimpan";
$_lng['editfile'] = "Edit Berkas";
$_lng['editsuccess'] = "Perubahan berhasil disimpan";
$_lng['elementsperpage'] = "Elemen per halaman";
$_lng['emptyname'] = "Nama tidak boleh kosong";
$_lng['emptynewname'] = "Nama baru tidak boleh kosong!";
$_lng['error'] = "Kesalahan!";
$_lng['extractbutton'] = "Ekstrak";
$_lng['extracttitle'] = "Ekstrak";
$_lng['extractarchive'] = "Ekstrak Arsip";
$_lng['extracterror'] = "Tidak dapat mengekstrak berkas";
$_lng['extractitemsuccess'] = "Item berhasil diekstrak dan disimpan sebagai";

// F
$_lng['faq'] = "FAQ";
$_lng['fileinfo'] = "Info Berkas";
$_lng['filename'] = "Nama";
$_lng['filesize'] = "Ukuran";
$_lng['filenotfound'] = "Berkas tidak ditemukan!";
$_lng['filetitle'] = "Berkas";
$_lng['filetoobig'] = "Berkas %s terlalu besar untuk diimpor. Maks ukuran berkas 5mb";
$_lng['formerror'] = "Silakan lengkapi kolom isian!";
$_lng['ftpconnecterror'] = "Tidak dapat terhubung dengan FTP server!";
$_lng['ftpdirectory'] = "Direktori";
$_lng['ftppassword'] = "Kata sandi";
$_lng['ftpport'] = "FTP port";
$_lng['ftpserver'] = "FTP server";
$_lng['ftpusername'] = "Nama pengguna";

// G
$_lng['globaltitle'] = "My Root FTP";
$_lng['go'] = "Go";

// H
$_lng['height'] = "Tinggi";
$_lng['hour'] = "Jam";

// I
$_lng['imageresize'] = "Ubah ukuran gambar";
$_lng['importbutton'] = "Impor";
$_lng['importtitle'] = "Impor";
$_lng['importsuccess'] = "Berkas %s berhasil diimpor";
$_lng['item'] = "Item";

// L
$_lng['language'] = "Bahasa";
$_lng['lastmodified'] = "Terakhir dimodifikasi";
$_lng['listtitle'] = "List";
$_lng['login'] = "Masuk";
$_lng['loginfor'] = "Masuk selama";
$_lng['logout'] = "Keluar";

// M
$_lng['minute'] = "Menit";
$_lng['month'] = "Bulan";
$_lng['movebutton'] = "Pidahkan";
$_lng['moveerror'] = "Kesalahan dalam pemindahan";
$_lng['movedirerror'] = "Direktori %s1 tidak dapat dipindahkan ke %s2";
$_lng['movedirsuccess'] = "Direktori %s1 berhasil dipindahkan ke %s2";
$_lng['movefileerror'] = "Berkas %s1 tidak dapat dipindahkan ke %s2";
$_lng['movefilesuccess'] = "Berkas %s1 berhasil dipindahkan ke %s2";
$_lng['movetitle'] = "Pindahkan";
$_lng['moveto'] = "Pindahkan ke";

// N
$_lng['name'] = "Nama";
$_lng['newname'] = "Nama baru";
$_lng['no'] = "Tidak";

// O
$_lng['oldname'] = "Nama lama";
$_lng['openarchive'] = "Buka Arsip";

// P
$_lng['password'] = "Kata sandi";

// R
$_lng['renamebutton'] = "Ubah nama";
$_lng['renamedirerror'] = "Direktori %s1 tidak dapat diubah nama ke %s2";
$_lng['renamedirsuccess'] = "Direktori %s1 berhasil diubah nama menjadi %s2";
$_lng['renameerror'] = "Ubah nama gagal!";
$_lng['renamefileerror'] = "Berkas %s1 tidak dapat diubah nama ke %s2";
$_lng['renamefilesuccess'] = "Berkas %s1 berhasil diubah nama menjadi %s2";
$_lng['renametitle'] = "Ubah nama";
$_lng['renameto'] = "Ubah menjadi";
$_lng['resizeimage'] = "Ubah ukuran";
$_lng['resizeimageerror'] = "Gambar tidak dapat disimpan";
$_lng['resizeimagesuccess'] = "Ukuran gambar berhasil diubah ke %w x %h dan disimpan sebagai %image";

// S
$_lng['saveas'] = "Simpan sebagai";
$_lng['savebutton'] = "Simpan";
$_lng['sessionerror'] = "Sesi habis.";
$_lng['settings'] = "Setelan";
$_lng['settingssuccessfullysaved'] = "Pengaturan berhasil disimpan";
$_lng['showhelptext'] = "Tampilkan teks bantuan";
$_lng['showicon'] = "Tampilkan ikon";
$_lng['showsize'] = "Tampilkan ukuran";
$_lng['sourcetitle'] = "Source";
$_lng['sqldatabase'] = "Database";
$_lng['sqlhost'] = "Host";
$_lng['sqlpassword'] = "Kata sandi";
$_lng['sqluser'] = "Nama pengguna";
$_lng['syntaxtitle'] = "Sintaks";

// T
$_lng['totalfile'] = "Total Berkas";
$_lng['type'] = "Jenis";

// U
$_lng['unableextract'] = "Tidak dapat mengekstrak berkas";
$_lng['untarbutton'] = "Ekstrak";
$_lng['untartitle'] = "Untar";
$_lng['untarerror'] = "tidak dapat mengirim ke server Anda.";
$_lng['untarsuccess'] = "berhasil dikirim ke server Anda.";
$_lng['unzipbutton'] = "Unzip";
$_lng['unziperror'] = "tidak dapat mengirim ke server Anda.";
$_lng['unzipdir'] = "Direktori";
$_lng['unzipsuccess'] = "berhasil dikirim ke server Anda.";
$_lng['unziptitle'] = "Unzip";
$_lng['uploadbutton'] = "Unggah";
$_lng['uploaderror'] = "tidak dapat diunggah.";
$_lng['uploadinfo'] = "Pilih berkas (maks 5mb per berkas)";
$_lng['uploadsuccess'] = "berhasil diunggah.";
$_lng['uploadtitle'] = "Unggah";

// W
$_lng['width'] = "Lebar";
$_lng['week'] = "Minggu";
$_lng['withselected'] = "Yang ditandai";
$_lng['withsize'] = "dengan ukuran";

// Y
$_lng['yes'] = "Ya";

// Z
$_lng['zipinstaller'] = "Penginstall Zip";

$_lng['help_chmod'] = "Mengatur hak akses pada file atau folder. CHMOD hanya digit angka (000 sampai 777) yang diperbolehkan dan harus 3 digit";
$_lng['help_copy'] = "Menyalin berkas atau direktori. Direktori tujuan harus sudah ada.";
$_lng['help_create'] = "Silakan isi Nama dan pilih Tipe. Jika membuat Berkas/file maka CHMOD akan otomatis ke 644 dan jika membuat Direktori maka CHMOD akan otomatis ke 755.";
$_lng['help_list'] = "Menampilkan daftar berkas dan direktori. Untuk memulai membuat direktori atau berkas silakan klik <b>Membuat</b>";
$_lng['help_move'] = "Memindahkan berkas atau direktori ke direktori lain. Direktori tujuan harus sudah ada.";
$_lng['help_unzip'] = "Silakan masukan lokasi direktori untuk mengekstrak berkas ini. Jika direktori tujuan tidak ada maka direktori akan dibuat secara otomatis.";
?>