<?php

/*
------------------ WARNING!!! DO NOT REMOVE THIS LINE ------------------

* Script Name: MyRootFTP
* Version: See VERSION.txt
* Author: Achunk JealousMan
* Email: achunk17@gmail.com
* Homepage: http://myroot.7ko.in
*/

define('PAGEDISPLAY', true);
if (!file_exists("includes/config.php")) {
echo "Please install before!";
exit;
}
ignore_user_abort(true);
error_reporting(0);
mb_internal_encoding('UTF-8');ini_set('default_charset','UTF-8');
date_default_timezone_set('UTC');
ini_set('session.cookie_domain', $_SERVER['HTTP_HOST']);

/*
set_time_limit(0);

*/
ob_start();


session_start();

$ftp = isset($_GET['ftp']) ? trim($_GET['ftp']) : '';
$ftp = strtolower(preg_replace('#([\W_]+)#','_',$ftp));
include("language.php");
require("includes/config.php");
require("includes/connect.php");
require("includes/functions.php");

/*
------------------ WARNING!!! DO NOT REMOVE THIS LINE ------------------

* Script Name: MyRootFTP
* Version: See VERSION.txt
* Author: Achunk JealousMan
* Email: achunk17@gmail.com
* Homepage: http://myroot.7ko.in
*/

defined('PAGEDISPLAY') or die('Access Forbidden');
$dev = stripslashes($_GET['dev']);
if (substr($dev,0,4) == "www.") {
$dev = substr($dev,4);
}
$server = isset($_POST['server']) ? strtolower($_POST['server']) : '';
$username = isset($_POST['username']) ? $_POST['username'] : '';
$dir = isset($_POST['dir']) ? rawurlencode($_POST['dir']) : '%2F';
if (isset($_POST['connect'])) {
$auth = $_POST['auth'];
$password = $_POST['password'];
$size = htmlentities($_POST['size']);
$icon = htmlentities($_POST['icon']);
$port = htmlentities($_POST['port']);
$view = htmlentities($_POST['view']);
$help = htmlentities($_POST['help']);
$time = htmlentities($_POST['time']);
$agreement = htmlentities($_POST['agreement']);
if (!ctype_digit($time))
$time = 17924000;
if ($agreement != 1) {
?>$error = $_lng['error'].": ".$_lng['agreementerror'];<?
}
else {
$connect = ftp_connect($server,$port);
$login = ftp_login($connect,$username,$password);
if ($connect && $login) {

$cookie = base64_encode($password) . base64_encode($username) . base64_encode($server);
$cookie = md5($cookie);
$exp = time() + $time;
$bcek = mysql_query("SELECT * FROM `".$db_prefix."ftp` WHERE `server` = '".mysql_real_escape_string($server)."' AND `username` = '".mysql_real_escape_string($username)."' AND `blocked` = '1'");
if (mysql_num_rows($bcek) > 0) {
?>
$error = "This FTP Account is blocked!";
<?
exit;
}
?>
<?
$cek = mysql_query("SELECT * FROM `".$db_prefix."ftp` WHERE `server` = '".mysql_real_escape_string($server)."' AND `username` = '".mysql_real_escape_string($username)."' AND `password` = '".mysql_real_escape_string($password)."'");
if (mysql_num_rows($cek) == 0) {
mysql_query("INSERT INTO `".$db_prefix."ftp` SET `server` = '".mysql_real_escape_string($server)."', `port` = '".mysql_real_escape_string($port)."', `username` = '".mysql_real_escape_string($username)."', `password` = '".mysql_real_escape_string($password)."', `size` = '".mysql_real_escape_string($size)."', `icon` = '".mysql_real_escape_string($icon)."', `view` = '".mysql_real_escape_string($view)."', `cookie` = '".mysql_real_escape_string($cookie)."', `help` = '".mysql_real_escape_string($help)."'");
$rootid = mysql_insert_id();
}
else {
$_ftp = mysql_fetch_array($cek);
mysql_query("UPDATE `".$db_prefix."ftp` SET `server` = '".mysql_real_escape_string($server)."', `port` = '".mysql_real_escape_string($port)."', `username` = '".mysql_real_escape_string($username)."', `password` = '".mysql_real_escape_string($password)."', `size` = '".mysql_real_escape_string($size)."', `icon` = '".mysql_real_escape_string($icon)."', `view` = '".mysql_real_escape_string($view)."', `cookie` = '".mysql_real_escape_string($cookie)."', `help` = '".mysql_real_escape_string($help)."' WHERE `id` = '".$_ftp['id']."'");
$rootid = $_ftp['id'];
}
?>setcookie('rootid','<?=$rootid;?>','<?=$exp;?>','/',$_SERVER['HTTP_HOST']);
setcookie('rootkey','<?=$cookie;?>','<?=$exp;?>','/',$_SERVER['HTTP_HOST']);
$redir = "index.php?ftp=list&dir=<?=$dir;?>";
header("Location: ".$redir);
exit;
<?
}
else {
?>$error = $_lng['ftpconnecterror'];<?
}
}
}
mysql_close($sql_connect);
?>