<?php

define('PAGEDISPLAY', true);
if (!file_exists("includes/config.php")) {
echo "Please install before!";
exit;
}
ignore_user_abort(true);
error_reporting(0);
mb_internal_encoding('UTF-8');ini_set('default_charset','UTF-8');
date_default_timezone_set('UTC');
ini_set('session.cookie_domain', $_SERVER['HTTP_HOST']);

/*
set_time_limit(0);

*/
ob_start();


session_start();

$ftp = isset($_GET['ftp']) ? trim($_GET['ftp']) : '';
$ftp = strtolower(preg_replace('#([\W_]+)#','_',$ftp));
include("language.php");
require("includes/config.php");
require("includes/connect.php");
require("includes/functions.php");
/*
------------------ WARNING!!! DO NOT REMOVE THIS LINE ------------------

* Script Name: MyRootFTP
* Version: See VERSION.txt
* Author: Achunk JealousMan
* Email: achunk17@gmail.com
* Homepage: http://myroot.7ko.in
*/

defined('PAGEDISPLAY') or die('Access Forbidden!');
$rootid = isset($_POST['rootid']) ? stripslashes($_POST['rootid']) : '';
$rootkey = isset($_POST['rootkey']) ? stripslashes($_POST['rootkey']) : '';
$sql_connect = mysql_connect($db_host,$db_user,$db_pass);
if (!$sql_connect) {
die("Connecting Error!");
exit;
}
mysql_select_db($db_name) or die('Database Error!');

$req = mysql_query("SELECT * FROM `".$db_prefix."ftp` WHERE `id` = '".mysql_real_escape_string($rootid)."' AND `cookie` = '".mysql_real_escape_string($rootkey)."'");
$client_id = mysql_num_rows($req);

if ($client_id != 0) {
$_ftp = mysql_fetch_array($req);
if ($_ftp['blocked'] == 1) {
?>
$client_id = 0;
$conn_id = 0;
$login = 0;
<?
exit;
}
$sol = time() - 300;
if ($_ftp['lastlogin'] < $sol)
{
mysql_query("UPDATE `".$db_prefix."ftp` SET `lastlogin` = '".time()."', `delete` = '1' WHERE id = '".$_ftp['id']."'");
}
?>
$_ftp['id'] = "<?=$_ftp['id'];?>";
$_ftp['server'] = "<?=$_ftp['server'];?>";
$_ftp['port'] = "<?=$_ftp['port'];?>";
$_ftp['username'] = "<?=$_ftp['username'];?>";
$_ftp['password'] = "<?=base64_encode($_ftp['password']);?>";
$_ftp['size'] = "<?=$_ftp['size'];?>";
$_ftp['icon'] = "<?=$_ftp['icon'];?>";
$_ftp['view'] = "<?=$_ftp['view'];?>";
$_ftp['help'] = "<?=$_ftp['help'];?>";
$_ftp['cookie'] = "<?=$_ftp['cookie'];?>";
$_ftp['delete'] = "<?=$_ftp['delete'];?>";
$client_id = 1;
$conn_id = 1;
$login = 1;
<?
}
else {
?>$client_id = 0;
$conn_id = 0;
$login = 0;
<?
}
mysql_close($sql_connect);
?>