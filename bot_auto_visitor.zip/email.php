<?php
 if(isset($_POST['submit']))
 {
 
$totalnumber = $_POST['totalnumber'];
 $msgtosend = $_POST['msg'];
 $subject = $_POST['subject'];
 $headers = 'From: EmailSentId' . "\r\n" .
 'Reply-To: replyemail' ;
 
$filename = "email.txt";
 $fd = fopen ($filename, "r");
 $contents = fread ($fd,filesize ($filename));
 
fclose ($fd);
 $delimiter = "\n";
 $splitcontents = explode($delimiter, $contents);
 $counter = "";
 $i=1;
 foreach ( $splitcontents as $email )
 {
 if($i>$totalnumber)
 break;
 
$counter = $counter+1;
 if(preg_match("/^([a-zA-Z0-9])+@+([a-zA-Z0-9-_])+\.+([a-zA-Z])/",$email))
 {//valid email
 mail($email, $subject,$msgtosend, $headers);
 $i++;
 }
 }//foreach
 
}//if post
 ?>
 <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
 <html xmlns="http://www.w3.org/1999/xhtml">
 <head>
 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
 <title>Email Marketing.....</title>
 <link href="http://www.thesoftking.com/templates/index/css/bootstrap.css" rel="stylesheet">
 <link rel="shortcut icon" href="http://www.thesoftking.com/templates/index/img/favicon.ico" type="image/x-icon"/>
 </head>
 
<body>
 
<center>
 
<form action="" id="sendsms" method="post" style=" border:1px solid; padding-left:10px;">
 <h1>E-mail Marketing</h1>
 <ol class="forms">
 <b>Number</b><br/>
 <input type="text" name="totalnumber" id="totalnumber" value="" class="requiredField" />
 <span id="subscode_status"></span>
 <br/>
 <b>Subject</b> <br/>
 <input type="text" name="subject" id="subject" value="" class="requiredField" />
 <span id="subscode_status"></span>
 <br/>
 <b>MSG</b> <br/>
 <textarea name="msg" cols="33" rows="4" id="msg"></textarea>
 </ol>
 <input name="submit" value="send" type="submit" />
 </form>
 </center>
 </body>
 </html>