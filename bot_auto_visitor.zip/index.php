<?php

if(!file_exists('cookies.txt')){

file_put_contents('cookies.txt','');

}

$url="http://trickfarbd.gq";

$visit=1500; //কত বার ভিসিট দিবেন (2000 এর বেশি দেয়া উচিত না তাহলে আপনার Server এ লোড পড়বে)

for($i=0;$i<$visit;$i++){

$agent="Nokia $i";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, ''.$url.'');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_USERAGENT, $agent);
curl_setopt($ch,CURLOPT_COOKIESESSION,$cookie);
curl_setopt($ch,CURLOPT_COOKIEJAR,"cookies.txt");
curl_setopt($ch,CURLOPT_COOKIEFILE,"cookies.txt");
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Accept-Language: en-us,en;q=0.7,de-de;q=0.3','Accept: text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5'));
$end = curl_exec($ch);

}

?>