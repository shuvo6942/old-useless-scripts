<?php
/* 
Project: TechTunes Grabber 
Author: Miraz Mac
Author URI: http://mirazmac.info
License: GPL v2 or later
*/
require_once'inc/init.php';
// Go home if No URI passed!
if(!$_GET['uri']){
$miraz->redir(''.$config->url.'');
}
// Ok So the URL passed
$uri=filter_var($_GET['uri'],FILTER_SANITIZE_STRING);

if(!$_GET['paged']){
$paged=1;
}
else{
$paged=(int)$_GET['paged'];
}
$data=$miraz->get_contents('http://www.techtunes.com.bd/'.$uri.'/feed/?paged='.$paged.''); // Grab the Data via HTTP Request
// Make Sure There is data!


if($data){
$rss = new SimpleXMLElement($data); // Make New Simple XML element
$pageTitle=$rss->channel->title;
$pageTitle=str_replace('টেকটিউনস » ','',$pageTitle);
include''.MAC_ROOT.'header.php';
echo'<div class="links"><span itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb"> <a href="'.$config->url.'" itemprop="url"><span itemprop="title">Home</span></a> › </span><span itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb"><a href="'.$config->url.'/categories" itemprop="url"><span itemprop="title">Categories</span></a> › </span> <b>'.$pageTitle.'</b></div>';
echo'<div class="mac_hdr">'.$pageTitle.'</div>';
// Loop it baby!
$i=1;
foreach($rss->channel->item as $item) {
// Get the thumbnail Image 
preg_match('#<img(.*?)" />#s',$item->description,$img);
$link=$item->link;
$title=$item->title;
$title=mb_substr($title,0,60,'UTF-8');
$timestamp=strtotime($item->pubDate);
$link=str_replace('http://www.techtunes.com.bd/',''.$config->url.'/v/',$link);
echo'<div class="post_list post-'.$i.'"><span class="thumb">'.$img[0].'</span>
<a href="'.$link.'" title="'.$item->title.'">'.$title.'...</a><br/>Updated: '.$miraz->timeAgo($timestamp).'</div>';
$i++;
}
echo'<div class="post_list paging">';
$next=$paged+1;
$prev=$paged-1;
if($paged > 1){
echo '<a href="'.$config->url.'/explore/'.$uri.'/page/'.$prev.'">&#171; Prev</a>';
}
if(count($rss) < 10){
echo '<a href="'.$config->url.'/explore/'.$uri.'/page/'.$next.'">Next &#187;</a>';
}
echo'</div>';
}
// Nothing Found :(
else{
$pageTitle="404 Not Found!";
include''.MAC_ROOT.'header.php';
echo'<div class="mac_hdr">Error Occured!</div><div class="single"><div class="error">Could not fetch content from TechTunes!<br/>May be they have blacklisted your Server IP.</div></div>';


}

include''.MAC_ROOT.'footer.php';
?>