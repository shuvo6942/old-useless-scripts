<?php
/* 
Project: TechTunes Grabber 
Author: Miraz Mac
Author URI: http://mirazmac.info
License: GPL v2 or later
*/
error_reporting(E_ALL ^ E_NOTICE); // hide the notice
define("MAC_ROOT",dirname(dirname(__FILE__)). "/");
require_once''.MAC_ROOT.'inc/config.php';
require_once''.MAC_ROOT.'lib/mirazmac.class.php';
$config = (object)$config;
$miraz=new MirazMac;