<?php
/* 
Project: TechTunes Grabber 
Author: Miraz Mac
Author URI: http://mirazmac.info
License: GPL v2 or later
*/
// Your Site name
$config['sitename']='AhmedBD.Ga';
// Site Tagline
$config['tagline']='Bangladeshi Top Tecnology Updated Bangla Blog By JessorWap'; 
// Site URL without any slash at end
$config['url']='http://ahmedbd.ga';
// Site description aka Meta Description
$config['description']='Bangladeshi Fast Tecnology Updated Bangla Blog';

/* THATS ALL STOP EDITING! */
?>