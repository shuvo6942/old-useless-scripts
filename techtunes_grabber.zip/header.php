<!DOCTYPE html PUBLIC "-//OMA//DTD XHTML Mobile 1.2//EN" "http://www.openmobilealliance.org/tech/DTD/xhtml-mobile12.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta http-equiv="Cache-Control" content="public"/>
<meta name="HandheldFriendly" content="True" />
<meta name="viewport" content="width = device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=no;"/>
<link rel="stylesheet" type="text/css" href="<?php echo $config->url;?>/static/mirazmac.css?1.2" media="all"/>
<link rel="shortcut icon" type="image/x-icon" href="<?php echo $config->url;?>/favicon.ico"/>
<title>
<?php if(isset($pageTitle)){
echo''.$pageTitle.' - '.$config->sitename.'';
}
else{
echo''.$config->sitename.' - '.$config->tagline.'';
}
?>
</title>
</head>
<body>
<div class="header"><span class="logo"><?php echo'<a href="'.$config->url.'" title="Home"><img src="'.$config->url.'/static/logo.png?1.3" alt="'.$config->sitename.'"/></a></span><span class="menu"><a href="#explore" title="Menu"><img src="'.$config->url.'/static/menu.png?1.3" alt="Menu"/></a></span>';?></div>
<div class="nav"><ul><li><a href="<?php echo $config->url;?>">Home</a></li><li><a href="<?php echo $config->url;?>/categories">Explore</a></li><li><a href="#explore">More</a></li></ul></div>
<script type="text/javascript" src="http://Popsup.net/adz/union/250/adv/javascript/5010"></script>