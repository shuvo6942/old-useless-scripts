<?php
/* 
Project: TechTunes Grabber 
Author: Miraz Mac
Author URI: http://mirazmac.info
License: GPL v2 or later
*/
require_once'inc/init.php';
// Go home if No URI passed!
if(!$_GET['uri']){
$miraz->redir(''.$config->url.'/?invalid_url');
}
// Ok So the URL passed
$uri=filter_var($_GET['uri'],FILTER_SANITIZE_STRING);
$data=$miraz->get_contents('http://www.techtunes.com.bd/'.$uri.'');
preg_match('#<title>(.*?)</title>#s',$data,$rt);
$pageTitle=$rt[1];
$pageTitle=str_replace(' | Techtunes | টেকটিউনস','',$pageTitle);
$data=preg_replace('|<script(.*?)</script>|is','',$data); // remove all js to hide ads
$data=preg_replace('|<noscript(.*?)</noscript>|is','',$data); // remove all js to hide ads
$data=preg_replace('|<iframe(.*?)</iframe>|is','',$data); // remove all frame to hide ads
preg_match('#class="entry">(.*?)class="post-utilities"#s',$data,$content);

if($content[1]){
include''.MAC_ROOT.'header.php';
preg_match('#<strong>বিভাগ(.*?)</span>#s',$data,$cat);
$c=$cat[1];
$c=str_replace(' : </strong> ','',$c);
$c=strip_tags($c);



echo'<div class="links"><span itemscope itemtype="http://data-vocabulary.org/Breadcrumb"> <a href="'.$config->url.'" itemprop="url"><span itemprop="title">Home</span></a> › </span><span itemscope itemtype="http://data-vocabulary.org/Breadcrumb"><a
href="'.$config->url.'/categories" itemprop="url"><span itemprop="title">Categories</span></a> › </span> <b>'.$c.'</b></div>';
$entry=''.$content[1].'id="none"></div>';
$entry=preg_replace('|<div(.*?)style="float:right;margin-left:15px">(.*?)</div>|is','',$entry);
$entry=preg_replace('|<div(.*?)class="chain-tunes-meta-single">(.*?)</div>|is','',$entry);
$entry=preg_replace('|<div(.*?)class="chain-tunes-list-box">(.*?)<ul(.*?)class="serieslist-ul">|is','<div class="chain-tunes-list-box"><ul class="serieslist-ul">',$entry);
$entry=str_replace('http://www.techtunes.com.bd/',''.$config->url.'/v/',$entry);
$entry=str_replace('টেকটিউনস',''.$config->sitename.'',$entry);
$entry=str_replace('টেকটিউন্সে',''.$config->sitename.'-এ',$entry);
echo'<div class="mac_hdr">'.$pageTitle.'</div><div class="single mirazmac"><div>'.$entry.'</div>';
}
else{
unset($pageTitle);
$pageTitle='404 Not Found!';
include''.MAC_ROOT.'header.php';
echo'<div class="mac_hdr">404 Not Found!</div><div class="single mirazmac"><div class="error"><b>404 Not Found!</b><br/>The URL you have requested doesn\'t exists on our server. Thats all we know!<br/><a href="'.$config->url.'">Go back to homepage</a>
</div>
</div>';
}
include''.MAC_ROOT.'footer.php';