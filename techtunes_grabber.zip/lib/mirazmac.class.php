<?php
// A class with several useful functions 
// Made by Miraz Mac for Personal use
// Credits should be given, if you use it without permission.
class MirazMac{
## URL & Remote Contents based functions ##

// Scrape data from remote URL
public static function get_contents($url,$ua='desktop'){
// Switch the User agent
if($ua == 'desktop'){
$user_agent="Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.0";
}
elseif($ua == 'mobile'){
$user_agent="Opera/9.80 (J2ME/MIDP; Opera Mini/4.2.13337/34.818; U; en) Presto/2.8.119 Version/11.10";
}
elseif($ua == 'googlebot'){
$user_agent="Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)";
}
elseif($ua == 'bingbot'){
$user_agent="Mozilla/5.0 (compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm)";
}
else{
$user_agent=trim($ua);
}
$btext=rand(600,600000); // A Random Number, Might me useful :/
if (function_exists('curl_init')) {
$uinfo=parse_url($url);
$ch = curl_init(); 
curl_setopt($ch, CURLOPT_URL, ''.$url.''); 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // access the ssl sites
curl_setopt($ch, CURLOPT_REFERER, 'https://www.google.com/search?sclient=psy-ab&site=&source=hp&btnG=Search&q=site:'.$uinfo[host].''); // i came from google :p
curl_setopt($ch, CURLOPT_AUTOREFERER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); // May be you need to change this for few sites :/
curl_setopt($ch, CURLOPT_USERAGENT, ''.$user_agent.' '.$btext.''); 
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Accept-Language: en-us,en;q=0.7,bn-BD,bn;q=0.3','Accept: text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5')); 
$content = curl_exec($ch); 
curl_close($ch); 
if(!empty($content)){
return $content;}
else{
return false;
}
    } 
// It seems You don't have cURL installed, lets go for the old way then :(
elseif(ini_get('allow_url_fopen')) {
$header = array('http' => array(
'method'=>"GET",
'user_agent' => ''.$user_agent.' '.$btext.'',
'header' => "Origin: https://www.google.com/search?sclient=psy-ab&site=&source=hp&btnG=Search&q=site:".$uinfo[host]."\r\nAccept-Language: en-us,en;q=0.7,bn-BD,bn;q=0.3\r\nAccept: text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5"
));
$context = stream_context_create($header);
$content = file_get_contents(''.$url.'', false, $context);
if(!empty($content)){
return $content;}
else{
return false;}
}
// Your hosting is just a shit! No cURL, neither allow_url_fopen. Man!
else{
return false;}
}

// Function to Make URL friendly URLS
public static function url_slug($str, $options = array()) {
	// Make sure string is in UTF-8 and strip invalid UTF-8 characters
	$str = mb_convert_encoding((string)$str, 'UTF-8', mb_list_encodings());
	
	$defaults = array(
		'delimiter' => '-',
		'limit' => null,
		'lowercase' => true,
		'replacements' => array(),
		'transliterate' => false,
	);
	
	// Merge options
	$options = array_merge($defaults, $options);
	
	$char_map = array(
		// Latin
		'À' => 'A', 'Á' => 'A', 'Â' => 'A', 'Ã' => 'A', 'Ä' => 'A', 'Å' => 'A', 'Æ' => 'AE', 'Ç' => 'C', 
		'È' => 'E', 'É' => 'E', 'Ê' => 'E', 'Ë' => 'E', 'Ì' => 'I', 'Í' => 'I', 'Î' => 'I', 'Ï' => 'I', 
		'Ð' => 'D', 'Ñ' => 'N', 'Ò' => 'O', 'Ó' => 'O', 'Ô' => 'O', 'Õ' => 'O', 'Ö' => 'O', 'O' => 'O', 
		'Ø' => 'O', 'Ù' => 'U', 'Ú' => 'U', 'Û' => 'U', 'Ü' => 'U', 'U' => 'U', 'Ý' => 'Y', 'Þ' => 'TH', 
		'ß' => 'ss', 
		'à' => 'a', 'á' => 'a', 'â' => 'a', 'ã' => 'a', 'ä' => 'a', 'å' => 'a', 'æ' => 'ae', 'ç' => 'c', 
		'è' => 'e', 'é' => 'e', 'ê' => 'e', 'ë' => 'e', 'ì' => 'i', 'í' => 'i', 'î' => 'i', 'ï' => 'i', 
		'ð' => 'd', 'ñ' => 'n', 'ò' => 'o', 'ó' => 'o', 'ô' => 'o', 'õ' => 'o', 'ö' => 'o', 'o' => 'o', 
		'ø' => 'o', 'ù' => 'u', 'ú' => 'u', 'û' => 'u', 'ü' => 'u', 'u' => 'u', 'ý' => 'y', 'þ' => 'th', 
		'ÿ' => 'y',
		// Latin symbols
		'©' => '(c)',
		// Greek
		'?' => 'A', '?' => 'B', 'G' => 'G', '?' => 'D', '?' => 'E', '?' => 'Z', '?' => 'H', 'T' => '8',
		'?' => 'I', '?' => 'K', '?' => 'L', '?' => 'M', '?' => 'N', '?' => '3', '?' => 'O', '?' => 'P',
		'?' => 'R', 'S' => 'S', '?' => 'T', '?' => 'Y', 'F' => 'F', '?' => 'X', '?' => 'PS', 'O' => 'W',
		'?' => 'A', '?' => 'E', '?' => 'I', '?' => 'O', '?' => 'Y', '?' => 'H', '?' => 'W', '?' => 'I',
		'?' => 'Y',
		'a' => 'a', 'ß' => 'b', '?' => 'g', 'd' => 'd', 'e' => 'e', '?' => 'z', '?' => 'h', '?' => '8',
		'?' => 'i', '?' => 'k', '?' => 'l', 'µ' => 'm', '?' => 'n', '?' => '3', '?' => 'o', 'p' => 'p',
		'?' => 'r', 's' => 's', 't' => 't', '?' => 'y', 'f' => 'f', '?' => 'x', '?' => 'ps', '?' => 'w',
		'?' => 'a', '?' => 'e', '?' => 'i', '?' => 'o', '?' => 'y', '?' => 'h', '?' => 'w', '?' => 's',
		'?' => 'i', '?' => 'y', '?' => 'y', '?' => 'i',
		// Turkish
		'S' => 'S', 'I' => 'I', 'Ç' => 'C', 'Ü' => 'U', 'Ö' => 'O', 'G' => 'G',
		's' => 's', 'i' => 'i', 'ç' => 'c', 'ü' => 'u', 'ö' => 'o', 'g' => 'g', 
		// Russian
		'?' => 'A', '?' => 'B', '?' => 'V', '?' => 'G', '?' => 'D', '?' => 'E', '?' => 'Yo', '?' => 'Zh',
		'?' => 'Z', '?' => 'I', '?' => 'J', '?' => 'K', '?' => 'L', '?' => 'M', '?' => 'N', '?' => 'O',
		'?' => 'P', '?' => 'R', '?' => 'S', '?' => 'T', '?' => 'U', '?' => 'F', '?' => 'H', '?' => 'C',
		'?' => 'Ch', '?' => 'Sh', '?' => 'Sh', '?' => '', '?' => 'Y', '?' => '', '?' => 'E', '?' => 'Yu',
		'?' => 'Ya',
		'?' => 'a', '?' => 'b', '?' => 'v', '?' => 'g', '?' => 'd', '?' => 'e', '?' => 'yo', '?' => 'zh',
		'?' => 'z', '?' => 'i', '?' => 'j', '?' => 'k', '?' => 'l', '?' => 'm', '?' => 'n', '?' => 'o',
		'?' => 'p', '?' => 'r', '?' => 's', '?' => 't', '?' => 'u', '?' => 'f', '?' => 'h', '?' => 'c',
		'?' => 'ch', '?' => 'sh', '?' => 'sh', '?' => '', '?' => 'y', '?' => '', '?' => 'e', '?' => 'yu',
		'?' => 'ya',
		// Ukrainian
		'?' => 'Ye', '?' => 'I', '?' => 'Yi', '?' => 'G',
		'?' => 'ye', '?' => 'i', '?' => 'yi', '?' => 'g',
		// Czech
		'C' => 'C', 'D' => 'D', 'E' => 'E', 'N' => 'N', 'R' => 'R', 'Š' => 'S', 'T' => 'T', 'U' => 'U', 
		'Ž' => 'Z', 
		'c' => 'c', 'd' => 'd', 'e' => 'e', 'n' => 'n', 'r' => 'r', 'š' => 's', 't' => 't', 'u' => 'u',
		'ž' => 'z', 
		// Polish
		'A' => 'A', 'C' => 'C', 'E' => 'e', 'L' => 'L', 'N' => 'N', 'Ó' => 'o', 'S' => 'S', 'Z' => 'Z', 
		'Z' => 'Z', 
		'a' => 'a', 'c' => 'c', 'e' => 'e', 'l' => 'l', 'n' => 'n', 'ó' => 'o', 's' => 's', 'z' => 'z',
		'z' => 'z',
		// Latvian
		'A' => 'A', 'C' => 'C', 'E' => 'E', 'G' => 'G', 'I' => 'i', 'K' => 'k', 'L' => 'L', 'N' => 'N', 
		'Š' => 'S', 'U' => 'u', 'Ž' => 'Z',
		'a' => 'a', 'c' => 'c', 'e' => 'e', 'g' => 'g', 'i' => 'i', 'k' => 'k', 'l' => 'l', 'n' => 'n',
		'š' => 's', 'u' => 'u', 'ž' => 'z'
	);
	
	// Make custom replacements
	$str = preg_replace(array_keys($options['replacements']), $options['replacements'], $str);
	
	// Transliterate characters to ASCII
	if ($options['transliterate']) {
		$str = str_replace(array_keys($char_map), $char_map, $str);
	}
	
	// Replace non-alphanumeric characters with our delimiter
	$str = preg_replace('/[^\p{L}\p{Nd}]+/u', $options['delimiter'], $str);
	
	// Remove duplicate delimiters
	$str = preg_replace('/(' . preg_quote($options['delimiter'], '/') . '){2,}/', '$1', $str);
	
	// Truncate slug to max. characters
	$str = mb_substr($str, 0, ($options['limit'] ? $options['limit'] : mb_strlen($str, 'UTF-8')), 'UTF-8');
	
	// Remove delimiter from ends
	$str = trim($str, $options['delimiter']);
	
	return $options['lowercase'] ? mb_strtolower($str, 'UTF-8') : $str;
}
// Function to Redirect using Header Location
function redir($url)
{
ob_end_clean();
header('Location: '.$url); exit;
}
// Function to Redirect using HTML tags(useful in case headers sent :/ )
public static function htmlredir($url){
 
        echo '<script type="text/javascript">';
        echo 'window.location.href="'.$url.'";';
        echo '</script>';
        echo '<noscript>';
        echo '<meta http-equiv="refresh" content="0;url='.$url.'" />';
        echo '</noscript>'; exit;
}

## File & folder related functions 
// Function to get max upload size
public static function get_max_upl() {
$max_upload = (int)(ini_get('upload_max_filesize'));
$max_post = (int)(ini_get('post_max_size'));
$memory_limit = (int)(ini_get('memory_limit'));
return min($max_upload, $max_post, $memory_limit);
}
// Function to convert bytes to readable size
function format_size($bytes)
    {
        if ($bytes >= 1073741824)
        {
            $bytes = number_format($bytes / 1073741824, 2) . ' GB';
        }
        elseif ($bytes >= 1048576)
        {
            $bytes = number_format($bytes / 1048576, 2) . ' MB';
        }
        elseif ($bytes >= 1024)
        {
            $bytes = number_format($bytes / 1024, 2) . ' KB';
        }
        elseif ($bytes > 1)
        {
            $bytes = $bytes . ' bytes';
        }
        elseif ($bytes == 1)
        {
            $bytes = $bytes . ' byte';
        }
        else
        {
            $bytes = '0 bytes';
        }

        return $bytes;
}


// Delete Everything from a directory! Files, even sub-sub-sub.... directories! :D
public static function deleteAll($directory, $empty = false) { 
    if(substr($directory,-1) == "/") { 
        $directory = substr($directory,0,-1); 
    } 

    if(!file_exists($directory) || !is_dir($directory)) { 
        return false; 
    } elseif(!is_readable($directory)) { 
        return false; 
    } else { 
        $directoryHandle = opendir($directory); 
        
        while ($contents = readdir($directoryHandle)) { 
            if($contents != '.' && $contents != '..') { 
                $path = $directory . "/" . $contents; 
                
                if(is_dir($path)) { 
                    deleteAll($path); 
                } else { 
                    unlink($path); 
                } 
            } 
        } 
        
        closedir($directoryHandle); 

        if($empty == false) { 
            if(!rmdir($directory)) { 
                return false; 
            } 
        } 
        
        return true; 
    } 
} 

## String & Validation Functions

// Convert timestamp into XX Ago format
public static function timeAgo($ptime)
{
    $estimate_time = time() - $ptime;

    if( $estimate_time < 1 )
    {
        return 'Just Now';
    }

    $condition = array(
                12 * 30 * 24 * 60 * 60  =>  'year',
                30 * 24 * 60 * 60       =>  'month',
                24 * 60 * 60            =>  'day',
                60 * 60                 =>  'hour',
                60                      =>  'minute',
                1                       =>  'second'
    );

    foreach( $condition as $secs => $str )
    {
        $d = $estimate_time / $secs;

        if( $d >= 1 )
        {
            $r = round( $d );
            return '' . $r . ' ' . $str . ( $r > 1 ? 's' : '' ) . ' ago';
        }
    }
}


// replace all spaces from string
public static function clean_spaces($string) {
	  return ( preg_replace('/(\s+)/u','',$string ) );
}
// Validate Email
public static function checkEmail( $str ) {
		return preg_match("/^[\.A-z0-9_\-\+]+[@][A-z0-9_\-]+([.][A-z0-9_\-\.]+)+[A-z]{2,4}$/", $str);
}
// Function to Send Mail
public static function send_mail( $from, $to, $subject, $body) {
		$headers = '';
		$headers .= "MIME-Version: 1.0\n";
		$headers .= 'Content-type: text/html; charset=utf-8' . "\r\n";
		$headers .= "From: $from\n";
		$headers .= "Reply-To: $from\n" . 
		'X-Mailer: PHP/' . phpversion();
	
		mail( $to, $subject , $body, $headers );
	}
// Convert all urls in text to clickable links
// arg $t is the type of link. ex. nofollow, external etc.
public static function linkText($text,$t='') { 
        if($t){
		$tx=' rel="'.$t.'"';
		}
	    $ret = ' ' . $text; 
	    $ret = preg_replace("#([\t\r\n ])([a-z0-9]+?){1}://([\w\-]+\.([\w\-]+\.)*[\w]+(:[0-9]+)?(/[^ \"\n\r\t<]*)?)#i", '\1<a href="\2://\3" target="_blank"'.$tx.'>\3</a>', $ret); 
	    $ret = preg_replace("#([\t\r\n ])(www|ftp)\.(([\w\-]+\.)*[\w]+(:[0-9]+)?(/[^ \"\n\r\t<]*)?)#i", '\1<a href="http://\2.\3" target="_blank"'.$tx.'>\2.\3</a>', $ret); 
	    $ret = preg_replace("#([\n ])([a-z0-9\-_.]+?)@([\w\-]+\.([\w\-\.]+\.)*[\w]+)#i", "\\1<a href=\"mailto:\\2@\\3\">\\2@\\3</a>", $ret); 
	    $ret = substr( $ret, 1 ); 
	    return( $ret ); 
	}
// Generates a Random String
	public static function stringRandom( $long = 16, $chars = '0123456789abcdefghijklmnopqrstuvwxyz!~^#!{}@+*' ) {
    $string = '';
    $max = mb_strlen( $chars ) - 1 ;

    for( $i = 0; $i < $long; ++$i ){
    	
        $string .= mb_substr( $chars, mt_rand( 0, $max ), 1 );
    }
    return $string;
	
	}
// Custom base64 encode/decode. Replace custom url safe values with normal
public static function base64_url_encode($val) {

            return strtr(base64_encode($val), '+/=', '-_,');

        }

public static function base64_url_decode($val) {

return base64_decode(strtr($val, '-_,', '+/='));

        }
// Convert ASCii
 public static function convertAscii( $entry ) {
		 $changes = array(
		'!' => '%21',
		'"' => '%22',
		'#' => '%23',
		'$' => '%24',
		'&' => '%26',
		"'" => '%27',
		'(' => '%28',
		')' => '%29',
		'*' => '%2A',
		'+' => '%2B',
		'-' => '%2D',
		'`' => '%60',
		'@' => '%40',
		'<' => '%3C',
		'=' => '3D',
		'>' => '3E',
		'?' => '3F',
		'^' => '5E'
		);
		
		$output = strtr( $entry , $changes );
		return $output;
	}
// Image Width Height 
public static function getHeight( $image ) {
		$size   = getimagesize( $image );
		$height = $size[1];
		return $height;
	}
	
public static function getWidth( $image ) {
		$size  = getimagesize( $image);
		$width = $size[0];
		return $width;
	}
public static function get_current_url() {
	$pageURL = 'http';
	if (isset($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] == "on") {
		$pageURL .= "s";
	}
	$pageURL .= "://";
	if ($_SERVER["SERVER_PORT"] != "80") {
		$pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
	} else {
		$pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
	}
	return $pageURL;
}
	
// Function to detect mobile device/browser
// return true if is mobile else false
public static function is_mobile(){
$useragent=$_SERVER['HTTP_USER_AGENT'];
if(preg_match('/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i',$useragent)||preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i',substr($useragent,0,4))){
return true;}
else{
return false;}
}
// Convert extension to mime type
public static function ext_to_mime($ext = '')
{
    switch (strtolower($ext)) {
        default:
            return 'application/octet-stream';
            break;

        case 'jar':
            return 'application/java-archive';
            break;

        case 'jad':
            return 'text/vnd.sun.j2me.app-descriptor';
            break;

        case 'cab':
            return 'application/vnd.ms-cab-compressed';
            break;

        case 'sis':
            return 'application/vnd.symbian.install';
            break;

        case 'zip':
            return 'application/x-zip';
            break;

        case 'rar':
            return 'application/x-rar-compressed';
            break;

        case '7z':
            return 'application/x-7z-compressed';
            break;

        case 'gz':
        case 'tgz':
            return 'application/x-gzip';
            break;

        case 'bz':
        case 'bz2':
            return 'application/x-bzip';
            break;

        case 'jpg':
        case 'jpe':
        case 'jpeg':
            return 'image/jpeg';
            break;

        case 'gif':
            return 'image/gif';
            break;

        case 'png':
            return 'image/png';
            break;

        case 'bmp':
            return 'image/bmp';
            break;

        case 'txt':
        case 'dat':
        case 'php':
        case 'php4':
        case 'php5':
        case 'phtml':
        case 'htm':
        case 'html':
        case 'shtm':
        case 'shtml':
        case 'wml':
        case 'css':
        case 'js':
        case 'xml':
        case 'sql':
            return 'text/plain';
            break;

        case 'mmf':
            return 'application/x-smaf';
            break;

        case 'mid':
            return 'audio/mid';
            break;

        case 'mp3':
            return 'audio/mpeg';
            break;

        case 'amr':
            return 'audio/amr';
            break;

        case 'wav':
            return 'audio/x-wav';
            break;

        case 'mp4':
            return 'video/mp4';
            break;

        case 'wmv':
            return 'video/x-ms-wmv';
            break;

        case '3gp':
            return 'video/3gpp';
            break;

        case 'avi':
            return 'video/x-msvideo';
            break;

        case 'mpg':
        case 'mpe':
        case 'mpeg':
            return 'video/mpeg';
            break;

        case 'pdf':
            return 'application/pdf';
            break;

        case 'doc':
        case 'docx':
            return 'application/msword';
            break;

        case 'swf':
            return 'application/x-shockwave-flash';
            break;
    }
}
// Function to Get User's Real IP
public static function realIp(){
    if (!empty($_SERVER['HTTP_CLIENT_IP']))   //check ip from share internet
    {
      $realIP=$_SERVER['HTTP_CLIENT_IP'];
    }
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   //to check ip is pass from proxy
    {
      $realIP=$_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    else
    {
      $realIP=$_SERVER['REMOTE_ADDR'];
    }
    return $realIP;
}
// Generate SiteMap From Array
public static function generateSitemap($sitemapTab,$changeFreq='monthly') {
	$todayDate = date('Y-m-d');
	
	$sitemapXML = '<?xml version="1.0" encoding="UTF-8"?>';
	$sitemapXML .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'."\n";
	
	foreach($sitemapTab as $value) {
		$sitemapXML .= '<url>';
		$sitemapXML .= '<loc>'.$value.'</loc>';
		$sitemapXML .= '<lastmod>'.$todayDate.'</lastmod>';
		$sitemapXML .= '<changefreq>'.$changeFreq.'</changefreq>';
		$sitemapXML .= '<priority>0.5</priority>';
		$sitemapXML .= '</url>'."\n";
	}
	
	$sitemapXML .= '</urlset>';
	return $sitemapXML;
}
// Return file extension from filename
public static function fileExt($fname) {
$f1 = strrpos($fname, ".");
$f2 = substr($fname, $f1 + 1, 999);
$name = strtolower($f2);
return $name;
}
// Write String to file
public static function write_to_file($filename,$q,$mode='a')
{$fh = fopen($filename, $mode);
if(flock($fh, LOCK_EX))
{fwrite($fh, $q);
flock($fh, LOCK_UN);}
fclose($fh);}

// Detect some common web bots
public static function is_bot($USER_AGENT) {
$crawlers_agents = strtolower('Bloglines subscriber|Dumbot|Sosoimagespider|QihooBot|FAST-WebCrawler|Superdownloads Spiderman|LinkWalker|msnbot|ASPSeek|WebAlta Crawler|Lycos|FeedFetcher-Google|Yahoo|YoudaoBot|AdsBot-Google|Googlebot|Scooter|Gigabot|Charlotte|eStyle|AcioRobot|GeonaBot|msnbot-media|Baidu|CocoCrawler|Google|Charlotte t|Yahoo! Slurp China|Sogou web spider|YodaoBot|MSRBOT|AbachoBOT|Sogou head spider|AltaVista|IDBot|Sosospider|Yahoo! Slurp|Java VM|DotBot|LiteFinder|Yeti|Rambler|Scrubby|Baiduspider|accoona');
$crawlers = explode("|", $crawlers_agents);
if(is_array($crawlers)) {
foreach($crawlers as $crawler) {
if (strpos(strtolower($USER_AGENT), trim($crawler)) !== false) {
return true;
}
}
}
return false;
}

// Random Content from an array
public static function randIt($data=array()){
$n=count($data);
$num=rand(0, ($n-1));
$rand=$data[$num];
return $rand;
}

// Gravatar from email
public static function show_gravatar($email, $size, $default, $rating)  
{  
    echo '<img src="http://www.gravatar.com/avatar.php?gravatar_id='.md5($email).  
        '&default='.$default.'&size='.$size.'&rating='.$rating.'" width="'.$size.'px"  
        height="'.$size.'px" />';  
}  
/* creates a compressed zip file */  
public static function create_zip($files = array(),$destination = '',$overwrite = false) {  
    //if the zip file already exists and overwrite is false, return false  
    if(file_exists($destination) && !$overwrite) { return false; }  
    //vars  
    $valid_files = array();  
    //if files were passed in...  
    if(is_array($files)) {  
        //cycle through each file  
        foreach($files as $file) {  
            //make sure the file exists  
            if(file_exists($file)) {  
                $valid_files[] = $file;  
            }  
        }  
    }  
    //if we have good files...  
    if(count($valid_files)) {  
        //create the archive  
        $zip = new ZipArchive();  
        if($zip->open($destination,$overwrite ? ZIPARCHIVE::OVERWRITE : ZIPARCHIVE::CREATE) !== true) {  
            return false;  
        }  
        //add the files  
        foreach($valid_files as $file) {  
            $zip->addFile($file,$file);  
        }  
        //debug  
        //echo 'The zip archive contains ',$zip->numFiles,' files with a status of ',$zip->status;  
          
        //close the zip -- done!  
        $zip->close();  
          
        //check to make sure the file exists  
        return file_exists($destination);  
    }  
    else  
    {  
        return false;  
    }  
}  

// Unzip a ZIP file
public static function unzip_file($file, $destination){  
    // create object  
    $zip = new ZipArchive() ;  
    // open archive  
    if ($zip->open($file) !== TRUE) {  
        die ('Could not open archive');  
    }  
    // extract contents to destination directory  
    $zip->extractTo($destination);  
    // close archive  
    $zip->close();  
    echo 'Archive extracted to directory';  
}  

public static function tiny_url($url)  
{  
	$data=Self::get_contents('http://tinyurl.com/api-create.php?url='.$url.'');
	return $data;  
}

// Get Server load (supported on win system also)
public static function get_server_load() {
   
        if (stristr(PHP_OS, 'win')) {
       
            $wmi = new COM("Winmgmts://");
            $server = $wmi->execquery("SELECT LoadPercentage FROM Win32_Processor");
           
            $cpu_num = 0;
            $load_total = 0;
           
            foreach($server as $cpu){
                $cpu_num++;
                $load_total += $cpu->loadpercentage;
            }
           
            $load = round($load_total/$cpu_num);
           
        } else {
       
            $sys_load = sys_getloadavg();
            $load = $sys_load[0];
       
        }
       
        return (int) $load;
   
    }
// Get Meta Tags, Title also
public static function get_url_meta($url, $raw=false) // $raw - enable for raw display
{
    $result = false;
  
    $contents = Self::get_contents($url);

    if (isset($contents) && is_string($contents))
    {
        $title = null;
        $metaTags = null;
        $metaProperties = null;
      
        preg_match('/<title>([^>]*)<\/title>/si', $contents, $match );

        if (isset($match) && is_array($match) && count($match) > 0)
        {
            $title = strip_tags($match[1]);
        }
      
        preg_match_all('/<[\s]*meta[\s]*(name|property)="?' . '([^>"]*)"?[\s]*' . 'content="?([^>"]*)"?[\s]*[\/]?[\s]*>/si', $contents, $match);
      
        if (isset($match) && is_array($match) && count($match) == 4)
        {
            $originals = $match[0];
            $names = $match[2];
            $values = $match[3];
          
            if (count($originals) == count($names) && count($names) == count($values))
            {
                $metaTags = array();
                $metaProperties = $metaTags;
                if ($raw) {
                    if (version_compare(PHP_VERSION, '5.4.0') == -1)
                         $flags = ENT_COMPAT;
                    else
                         $flags = ENT_COMPAT | ENT_HTML401;
                }
              
                for ($i=0, $limiti=count($names); $i < $limiti; $i++)
                {
                    if ($match[1][$i] == 'name')
                         $meta_type = 'metaTags';
                    else
                         $meta_type = 'metaProperties';
                    if ($raw)
                        ${$meta_type}[$names[$i]] = array (
                            'html' => htmlentities($originals[$i], $flags, 'UTF-8'),
                            'value' => $values[$i]
                        );
                    else
                        ${$meta_type}[$names[$i]] = array (
                            'html' => $originals[$i],
                            'value' => $values[$i]
                        );
                }
            }
        }
      
        $result = array (
            'title' => $title,
            'metaTags' => $metaTags,
            'metaProperties' => $metaProperties,
        );
    }
  
    return $result;
}

## End Class
}
?>