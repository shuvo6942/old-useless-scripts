<?php
/* 
Project: TechTunes Grabber 
Author: Miraz Mac
Author URI: http://mirazmac.info
License: GPL v2 or later
*/
require_once'inc/init.php';
include''.MAC_ROOT.'header.php';
if(!$_GET['paged']){
$paged=1;
}
else{
$paged=(int)$_GET['paged'];
}
$data=$miraz->get_contents('http://techtunes.com.bd/feed/?paged='.$paged.''); // Grab the Data via HTTP Request
// Make Sure There is data!
echo'<div class="mac_hdr">Latest Post</div><div class="post_list post"><script type="text/javascript" src="http://Popsup.net/ad/jsa/id/5010"></script></div>';
if($data){
$rss = new SimpleXMLElement($data); // Make New Simple XML element
// Loop it baby!
$i=1;
foreach($rss->channel->item as $item) {
// Get the thumbnail Image 
preg_match('#<img(.*?)" />#s',$item->description,$img);
$link=$item->link;
$title=$item->title;
$title=mb_substr($title,0,60,'UTF-8');
$timestamp=strtotime($item->pubDate);
$link=str_replace('http://www.techtunes.com.bd/',''.$config->url.'/v/',$link);
echo'<div class="post_list post-'.$i.'"><span class="thumb">'.$img[0].'</span>
<a href="'.$link.'" title="'.$item->title.'">'.$title.'...</a><br/>Updated: '.$miraz->timeAgo($timestamp).'</div>';
$i++;
}
echo'<div class="post_list paging">';
$next=$paged+1;
$prev=$paged-1;
if($paged > 1){
echo '<a href="'.$config->url.'/page/'.$prev.'">&#171; Prev</a>';
}
if(count($rss) < 10){
echo '<a href="'.$config->url.'/page/'.$next.'">Next &#187;</a>';
}
echo'</div>';
}
// Nothing Found :(
else{
echo'<div class="single"><div class="error">Could not fetch content from TechTunes!<br/>May be they have blacklisted your Server IP.</div></div>';


}

include''.MAC_ROOT.'footer.php';
?>