/* 
Project: TechTunes Grabber 
Author: Miraz Mac
Author URI: http://mirazmac.info
License: GPL v2 or later
*/

/* == How to Install == */
1. First of all extract the ZIP archive in your web hosting. 
2. Then edit "inc/config.php" and save with your site details
3. Its done! Easy as 1,2,3!!

/* == Important Notes == */
1. Please don't remove the footer credit link if you support my work. :)
2. Keep visiting and sharing http://mirazmac.info with your friends!
3. Like us on facebook: http://fb.me/realmacinc

