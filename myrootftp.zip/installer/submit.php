<?phpdefine('PAGEDISPLAY',true);

error_reporting(0);
ignore_user_abort(true);
session_start();
if (!file_exists("admin.php")) {
echo "Admin password not found!";
exit;
}
include("admin.php");

function waktu($var)
{
$gmt = 7;
$jm = 3600;
$var = $var+($gmt*$jm);
$var = gmdate('d M Y - H:i',$var);
return ''.$var.' GMT +7';
}
function getExtension($str) {
$i = strrpos($str,".");
if (!$i) { return ""; }
$l = strlen($str) - $i;
$ext = substr($str,$i+1,$l);
return strtolower($ext);
}


$title = "Submit File";
require_once("header.php");
echo '<div class="content">';
if (isset($_POST['send']))
{
$file = $_POST['file'];
$nama = substr($_POST['filename'],0,30);
$my_message = $_POST['message'];$code = $_POST['code'];


$mime_types = array(
'mp3' => 'audio/mpeg',
'3gp' => 'video/3gpp',
'mp4' => 'video/mp4',
'mid' => 'audio/midi',
'amr' => 'audio/amr',
'wav' => 'audio/x-wav',
'jpg' => 'image/jpg',
'gif' => 'image/gif',
'jpeg' => 'image/jpeg',
'png' => 'image/png',
'ico' => 'image/x-icon',
'txt' => 'text/plain',
'jar' => 'application/java-archive',
'jad' => 'text/vnd.sun.j2me.app-descriptor',
'sis' => 'application/vnd.symbian.install',
'sisx' => 'application/vnd.symbian.install',
'apk' => 'application/vnd.android.package-archive',
'cod' => 'application/vnd.rim.cod',
'zip' => 'application/zip',
'rar' => 'application/x-rar-compressed',
'nth' => 'application/vnd.nok-s40theme',
'thm' => 'application/vnd.eri.thm',
'swf' => 'application/x-shockwave-flash',
'pdf' => 'application/pdf'
);
if (md5($code) != $admin_password) {
echo "<div class=\"error\">Incorrect Password!</div>";
echo '</div>';
require_once("footer.php");
exit;}

$ext = getExtension($file);
if ($ext != "zip") {
echo "<div class=\"error\">Not zip file!</div>";
echo '</div>';
require_once("footer.php");
exit;
}
if (!eregi('http://(.*)/(.*)',$file) AND !eregi('https://(.*)/(.*)',$file)) {
echo "<div class=\"error\">Invalid URL</div>";
echo '</div>';
require_once("footer.php");
exit;
}
$url = $file;
$target = explode("/",substr($url,7));
$host = $target[0];
$path = substr($url,(strlen($host) + 7));
$fp = fsockopen($host,80,$errno,$errstr,10);
$headers = "GET $path HTTP/1.1\r\n";

$headers .= "Host: $host\r\n";
$headers .= "Accept: **\r\n";
$headers .= "Accept-Charset: **\r\n";
$headers .= "Content-Type: application/x-www-form-urlencoded\r\n";
$headers .= "User-Agent: Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1) Gecko/20060918 Firefox/2.0\r\n\r\n";
fputs($fp,$headers);
while(!feof($fp))
{
$header .= fgets($fp,512);
}fclose($fp);
if (strpos($header,"Content-Length:")!==false) {
eregi("Content-Length: ([0-9]*)",$header,$mss);
$file_size = trim($mss[1]);
}
if ($file_size < 1024) {
$size = $file_size." bytes";
}
elseif ($file_size >= "1024" && $file_size < "1048576") {
$size = strtr(round($file_size/1024,2),".",",")." kb";
}
elseif ($file_size >= 1048576) {
$size = strtr(round($file_size/1024/1024,2),".",",")." mb";
}
$data[] = base64_encode($file);
$data[] = base64_encode($nama);
$data[] = base64_encode($my_message);
$data[] = base64_encode($size);
$data[] = base64_encode(waktu(time()));
$datas = implode('::',$data);
$get = file_get_contents('archive.dat');
if ($get == "") {
$save = $datas;
}
else {
$save = $datas."\r\n".$get;
}
$put = file_put_contents("archive.dat",$save);
if ($put != false) {
echo '<div class="success">File berhasil ditambahkan. Mohon jangan menghapus atau merubah url file yang telah Anda tambahkan tersebut.</div></div>';
require_once("footer.php");
exit;}
else {
echo '<div class="error">File gagal ditambahkan!</div></div>';
require_once("footer.php");
exit;}
}
echo '<div class="info">File must be zip extension and maximum file size 5mb</div><form method="post" action="'.basename(__FILE__).'"><b>File URL</b><br/><input name="file" type="text" value="http://"/><br/><span>Only .zip and max size 5mb</span><br /><b>File name</b><br /><input name="filename" type="text" value=""/><br /><span>without extension</span><br/>
<b>Info</b><br /><textarea name="message"></textarea><br /><b>Admin Password</b><br/><input name="code" type="password" value=""/><br/><br/><input type="submit" name="send" value="SUBMIT"/></form>';
echo '</div>';
require_once("footer.php");
?>