<?php

/*
------------------ WARNING!!! DO NOT REMOVE THIS LINE ------------------

* Script Name: MyRootFTP
* Version: See VERSION.txt
* Author: Achunk JealousMan
* Email: achunk17@gmail.com
* Homepage: http://myroot.7ko.in
*/

defined('PAGEDISPLAY') or die('OK');
$title = isset($title) ? $title : $_SERVER['HTTP_HOST'];
echo '<?xml version="1.0" encoding="utf-8"?><!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN"
"http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head><title>'.$title.'</title>
<meta http-equiv="expires" content="0"/>
<meta http-equiv="Content-Language" content="en-us"/>
<meta http-equiv="content-type" content="Text/html;
charset=UTF-8"/>
<meta name="description" content="Wap FTP Client Service. This Free, Fast, Easy and Secure."/>
<meta name="keywords" content="Wap,ftp,client,secure wapftp,wap ftp,ftp,online,free,ftp client,unzip,php"/>
<meta name="copyright" content="Copyright (c) 2012 MyRootFTP"/>
<meta name="author" content="Achunk JealousMan"/>
<meta name="charset"
content="UTF-8"/>
<meta name="distribution" content="Global"/>
<meta name="rating" content="General"/>
<meta name="robots" content="Index,follow"/>
<meta name="revisit-after" content="3 Day"/>
<link rel="shortcut icon" href="../favicon.ico"/>
<link rel="stylesheet" href="../style.css" type="text/css"/>
</head><body>';
echo '<div id="header"><div style="text-align:center;margin:2px;"><a href="index.php"><h1><img src="http://www.logomatik.net/eng/image.png?fsize=20&font=Deutsch_Gothic.ttf&text='.strtoupper(htmlentities($_SERVER['HTTP_HOST'])).'&mirror=No&color=ccc&vcolor=ccc&bgcolor=&alpha=no&output=png&spacing=1&shadow=no&transparent=yes" alt=""/></h1></a></div></div>';
echo '<div class="topnav"><a href="mailto:achunk17@gmail.com">Contact Us</a></div>';
echo '<div id="wrapper">';
?>