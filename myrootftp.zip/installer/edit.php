<?php
define('PAGEDISPLAY',true);
if (!file_exists("admin.php")) {
echo "Admin password not found!";
exit;
}
include("admin.php");
if (!isset($_POST['submit'])) {
header("Location: index.php");
exit;
}
if (md5($_POST['password']) != $admin_password) {
header("Location: index.php");
exit;
}
$act = $_POST['act'];
$zip = $_POST['zip'];
switch ($act) {
case 'delete':
$file_size = filesize("archive.dat");
$handle = fopen("archive.dat", "r");
ob_start();
$content = fread($handle, $file_size);
fclose($handle);
ob_clean();
$items = explode("\r\n",$content);
for ($i = 0; $i < count($items); $i++) {
$iz = "i".$i;
if ($iz == $zip) {
}
else {
$save[] = $items[$i];
}
}
$saves = implode("\r\n",$save);
if (file_put_contents("archive.dat",$saves)) {
header("Location: package.php");
exit;
}
else {
echo "Cant deleted!";
}
break;

case 'edit':
$file_size = filesize("archive.dat");
$handle = fopen("archive.dat", "r");
ob_start();
$content = fread($handle, $file_size);
fclose($handle);
ob_clean();
$items = explode("\r\n",$content);
for ($i = 0; $i < count($items); $i++) {
$iz = "i".$i;
if ($iz == $zip) {
$ar = explode("::",$items[$i]);
$judul = base64_decode($ar[1]);
$catatan = base64_decode($ar[2]);
if (isset($_POST['title'])) {
$save[] = $ar[0]."::".base64_encode($_POST['title'])."::".base64_encode($_POST['note'])."::".$ar[3]."::".$ar[4];
}
}
else {
$save[] = $items[$i];
}
}
$saves = implode("\r\n",$save);
if (isset($_POST['title'])) {
if (file_put_contents("archive.dat",$saves)) {
header("Location: package.php?zip=".$_POST['zip']);
exit;
}
else {
header("Location: package.php?zip=".$_POST['zip']);
exit;
}
}
else {
$title = "Edit Archive";
require_once("header.php");
echo '<div class="content">';
echo '<form method="post" action="edit.php"><input type="hidden" name="act" value="edit"/><input type="hidden" name="zip" value="'.htmlentities($_POST['zip']).'"/><br />Title<br /><input type="text" name="title" value="'.htmlentities($judul).'"/><br />Note<br /><textarea name="note">'.htmlentities($catatan).'</textarea><br /><input type="hidden" name="password" value="'.htmlentities($_POST['password']).'"/><input type="submit" name="submit" value="  Save  "/></form>';
echo '</div>';
require_once("footer.php");
}
break;
default:
header("Location: index.php");
break;
}
?>