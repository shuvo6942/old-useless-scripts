<?php
error_reporting(0);

ini_set("max_execution_time", "300");
ini_set("memory_limit", "10M");

function ftp_mkdir_recusive($con_id,$path){
        $parts = explode("/",$path);
        $return = true;
        $fullpath = "";
        foreach($parts as $part){
                if(empty($part)){
                        $fullpath .= "/";
                        continue;
                }
                $fullpath .= $part."/";
                if(@ftp_chdir($con_id,$fullpath)){
                   ftp_chdir($con_id,$fullpath);
                }else{
                        if(@ftp_mkdir($con_id, $part)){
                                ftp_chdir($con_id, $part);
                        }else{
                                $return = false;
                        }
                }
        }
        return $return;
}


if (!isset($_POST['save'])) {
header("Location: index.php");
exit;
}
$url = $_POST['package_url'];
$serv = $_POST['ftp_server'];
$port = $_POST['ftp_port'];
$user = $_POST['ftp_user'];
$pass = $_POST['ftp_password'];
$dir = $_POST['dir'];
if (empty($url) OR empty($serv) OR empty($port) OR empty($user) OR empty($pass) OR empty($dir)) {
echo "Incorrect Data.<br /><a href=\"index.php\">&laquo;Back</a>";
exit;
}

$conn_id = ftp_connect($serv, $port);
if ($conn_id == false) {
echo "Could'n connect to FTP Server using this Port.<br /><a href=\"index.php\">&laquo;Back</a>";
exit;
}
if (substr($dir,-1) == "/")
$dir = substr($dir,0,-1);
$log = ftp_login($conn_id, $user, $pass);
if ($log == false) {
echo "Could'n login to FTP.<br /><a href=\"index.php\">&laquo;Back</a>";
exit;
}
if (ftp_mkdir_recusive($conn_id,$dir)) {
ftp_pasv($conn_id,true);
$unziper = ftp_put($conn_id,''.$dir.'/myroot7koin-unziper.php','myroot.txt',FTP_BINARY);
}
else {
ftp_pasv($conn_id,true);
$unziper = ftp_put($conn_id,$dir.'/myroot7koin-unziper.php','myroot.txt',FTP_BINARY);
}
if ($unziper) {
echo 'Installer successfully created. Go to <a href="http://'.$serv.''.str_replace('/public_html','',str_replace('/www','',$dir)).'/myroot7koin-unziper.php?zip='.rawurlencode($url).'">http://'.$serv.''.str_replace('/public_html','',str_replace('/www','',$dir)).'/myroot7koin-unziper.php?zip='.rawurlencode($url).'</a><br /><textarea>http://'.$serv.''.str_replace('/public_html','',str_replace('/www','',$dir)).'/myroot7koin-unziper.php?zip='.rawurlencode($url).'</textarea>';
}
else {
echo "Error!<br /><a href=\"index.php\">&laquo;Back</a>";
}
?>