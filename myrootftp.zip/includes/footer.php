<?php

/*
------------------ WARNING!!! DO NOT REMOVE THIS LINE ------------------

* Script Name: MyRootFTP
* Version: See VERSION.txt
* Author: Achunk JealousMan
* Email: achunk17@gmail.com
* Homepage: http://myroot.7ko.in
*/

defined('PAGEDISPLAY') or die('Access Forbidden');

$ol = time() - 300;

$user_ol=mysql_result(mysql_query("SELECT COUNT(*) FROM `".$db_prefix."ftp` WHERE `lastlogin` > $ol"), 0);

echo '<div class="topnav"><a href="changelanguage.php?language=emglish">EN</a><a href="changelanguage.php?language=indonesian">ID</a><a href="changelanguage.php?language=chinese">CN</a><a href="changelanguage.php?language=vietnam">VN</a></div><div id="footer"><p>Online '.$user_ol.'<br />&copy; '.date('Y',time()).' - '.$_SERVER['HTTP_HOST'].'.<br />All Rights Reserved</p></div></div></body>
</html>';
mysql_close($sql_connect);
?>

