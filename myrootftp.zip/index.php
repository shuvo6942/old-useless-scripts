<?php

/*
------------------ WARNING!!! DO NOT REMOVE THIS LINE ------------------

* Script Name: MyRootFTP
* Version: See VERSION.txt
* Author: Achunk JealousMan
* Email: achunk17@gmail.com
* Homepage: http://myroot.7ko.in
*/

define('PAGEDISPLAY', true);
if (!file_exists("includes/config.php")) {
echo "Please install before!";
exit;
}
ignore_user_abort(true);
error_reporting(0);
mb_internal_encoding('UTF-8');ini_set('default_charset','UTF-8');
date_default_timezone_set('UTC');
ini_set('session.cookie_domain', $_SERVER['HTTP_HOST']);

/*
set_time_limit(0);

*/
ob_start();


session_start();

$ftp = isset($_GET['ftp']) ? trim($_GET['ftp']) : '';
$ftp = strtolower(preg_replace('#([\W_]+)#','_',$ftp));
include("language.php");
require("includes/config.php");
require("includes/connect.php");
require("includes/functions.php");
// Start
$__tm = time() - 3600;
$__q = mysql_query("SELECT * FROM `".$db_prefix."ftp` WHERE `lastlogin` < '".$__tm."' AND `delete` > '1' LIMIT 1");
if (mysql_num_rows($__q) > 0) {
$__f = mysql_fetch_array($__q);
deleteDir($dir_dataftp."/".$__f['id']);
mysql_query("UPDATE `".$db_prefix."ftp` SET `delete` = '1' WHERE `id` = '".$__f['id']."'");
}
// End
if ($ftp == "") {
include_once("systems/index.php");
}
else {
if (file_exists("systems/".$ftp.".php")) {
include_once("systems/".$ftp.".php");
}
else {
include_once("systems/index.php");
}
}
?>