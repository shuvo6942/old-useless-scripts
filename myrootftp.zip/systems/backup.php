<?php

/*
------------------ WARNING!!! DO NOT REMOVE THIS LINE ------------------

* Script Name: MyRootFTP
* Version: See VERSION.txt
* Author: Achunk JealousMan
* Email: achunk17@gmail.com
* Homepage: http://myroot.7ko.in
*/

defined('PAGEDISPLAY') or die('Access Forbidden!');
if ($client_id == 0) {
header("Location: index.php");
exit;
}
$dir = rawurldecode(trim($_GET['dir']));
if ($dir == "") {
header("Location: index.php?ftp=list");
exit;
}
if (ftp_size($conn_id,$dir) > 3145728) {
header("Location: index.php?ftp=list");
exit;
}
if ($array = explode("/",$dir)) {
$count_array = count($array) - 1;
if ($count_array < 1)
$in = "";
else
$in = $array[$count_array];
}
else {
$in = "";
}
if (isset($_POST['backup'])) {
$save = $_POST['save'];
$inside = $_POST['inside'];
$local = $dir_dataftp."/".$_ftp['id'];
if ($inside == "yes") {
if ($in == "")
$backup_dir = $local;
else
$backup_dir = $local."/".$in;
}
else {
$backup_dir = $local;
}
$backup = ftpFileList($dir);
foreach ($backup as $item) {
$localSave = $backup_dir."/".substr(str_replace(basename($item)."#REPLACE#","",$item."#REPLACE#"),strlen($dir));
localMkDirRecusive($localSave);
ftp_get($conn_id,$localSave.basename($item),$item,FTP_BINARY);
}

$title = $_lng['backuptitle'].": ".htmlspecialchars($dir);
require_once("includes/header.php");
echo '<div class="content">';
showDirNav($dir);
$ext = getExtension(basename($save));
if ($ext == "zip" || $ext == "jar") {
require_once('includes/pclzip.lib.php');
$zip = new PclZip($local."/BACKUP.zip");
if ($zip->add($local, PCLZIP_OPT_REMOVE_PATH, $local)!=0)
{$list = $zip->delete(PCLZIP_OPT_BY_NAME, "BACKUP.zip");if ($list == 0)
{
$send = ftp_put($conn_id,$save,$local."/BACKUP.zip",FTP_BINARY);
}
else {
$send = ftp_put($conn_id,$save,$local."/BACKUP.zip",FTP_BINARY);
}
if ($send)
echo '<div class="success">'.$_lng['backupsuccess'].' '.htmlentities($save).'</div>';
else
echo '<div class="error">'.$_lng['cantsavefile'].' '.htmlentities($save).'</div>';
}
else {
echo '<div class="error">'.$_lng['backuperror'].' '.htmlentities($save).'!</div>';
}
} else {
require_once("includes/tar.php");
$tar = new Archive_Tar($local."/BACKUP.tar");
if ($tar->createModify($backup_dir,"",$local)) {
if (ftp_put($conn_id,$save,$local."/BACKUP.tar",FTP_BINARY)) {echo '<div class="success">'.$_lng['backupsuccess'].' '.htmlentities($save).'</div>';
}
else {
echo '<div class="error">'.$_lng['cantsavefile'].' '.htmlentities($save).'</div>';
}
}
else {
echo '<div class="error">'.$_lng['backuperror'].' '.htmlentities($save).'!</div>';
}
}deleteDir($dir_dataftp."/".$_ftp['id']);
ftp_close($conn_id);
echo '</div>';
require_once("includes/footer.php");
}
else {
deleteDir($dir_dataftp."/".$_ftp['id']);
createDir();

$title = $_lng['backuptitle'].": ".htmlspecialchars($dir);
require_once("includes/header.php");
echo '<div class="content">';
showDirNav($dir);
echo '<form method="post" action="index.php?ftp=backup&amp;dir='.rawurlencode($dir).'"><b>'.$_lng['saveas'].'</b><input type="text" name="save" value="'.htmlentities($dir).'/Archive.zip"/><br />';
if ($in != "")
echo '<b>'.str_replace('%s','<font color="red">'.htmlentities($in).'</font>',$_lng['backupwithdirectory']).'</b><br /><input type="radio" name="inside" value="yes" checked="checked">'.$_lng['yes'].'<br /><input type="radio" name="inside" value="no">'.$_lng['no'].'<br />';
echo '<input type="submit" name="backup" value="'.$_lng['backupbutton'].'"/></form>';
ftp_close($conn_id);
echo '</div>';
require_once("includes/footer.php");
}
?>