<?php

/*
------------------ WARNING!!! DO NOT REMOVE THIS LINE ------------------

* Script Name: MyRootFTP
* Version: See VERSION.txt
* Author: Achunk JealousMan
* Email: achunk17@gmail.com
* Homepage: http://myroot.7ko.in
*/

defined('PAGEDISPLAY') or die('Access Forbidden');

if ($client_id == 0) {
header("Location: index.php");
exit;
}
if (isset($_GET['file'])) {
$file = rawurldecode(trim($_GET['file']));
$back = str_replace(basename($file),'',$file);
if (ftp_delete($conn_id,$file)) {
header("Location: index.php?ftp=list&dir=".rawurlencode($back));
exit;
}
else {
$title = $_lng['deletetitle'];
require_once("includes/header.php");
echo '<div class="content">';
showDirNav($back);
echo $_lng['deletefileerror'].' '.htmlentities($file).'<br /><a href="index.php?ftp=list&amp;dir='.rawurlencode($back).'">&laquo; '.$_lng['back'].'</a></div>';
require_once("includes/footer.php");
}

}
elseif (isset($_GET['dir'])) {
$dir = rawurldecode(trim($_GET['dir']));
$back = explode("/", $dir, -1);
$back = implode("/",$back);

if (ftpDeleteDirectory($conn_id,$dir)) {
header("Location: index.php?ftp=list&dir=".rawurlencode($back));
exit;
}
else {
$title = $_lng['deletetitle'];
require_once("includes/header.php");
echo '<div class="content">';
showDirNav($dir);
echo $_lng['deletedirectoryerror'].' '.htmlentities($dir).'<br /><a href="index.php?ftp=list&amp;dir='.rawurlencode($dir).'">&laquo; '.$_lng['back'].'</a></div>';
require_once("includes/footer.php");
}

}
else {
header("Location: index.php?ftp=list");
}
?>