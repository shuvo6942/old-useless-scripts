<?php

/*
------------------ WARNING!!! DO NOT REMOVE THIS LINE ------------------

* Script Name: MyRootFTP
* Version: See VERSION.txt
* Author: Achunk JealousMan
* Email: achunk17@gmail.com
* Homepage: http://myroot.7ko.in
*/

defined('PAGEDISPLAY') or die('Access Forbidden!');
if ($client_id == 0 || !isset($_POST['submit'])) {
header("Location: index.php");
exit;
}
$dir = rawurldecode(trim($_GET['dir']));
if ($dir == "/")
$directory = "";
else
$directory = $dir;
$action = isset($_POST['action']) ? $_POST['action'] : '';
switch ($action) {

case 'rename':
$title = $_lng['renametitle'];
require_once("includes/header.php");
echo '<div class="content">';
showDirNav($dir);
if (isset($_POST['dir']) || isset($_POST['file'])) {
echo '<form method="post" action="index.php?ftp=submit&amp;dir='.rawurlencode($dir).'&amp;execute=true">';

if (isset($_POST['dir'])) {
$countDirs = count($_POST['dir']);
for ($d = 0; $d < $countDirs; $d++) {
$dirname = $_POST['dir'][$d];
if (isset($_GET['execute'])) {
$cd = "dir".$d;
$rename = $_POST[$cd];
if ((strlen($rename) > 1) AND ($rename != $dir) AND ($rename != $dir."/".$dirname)) {
if (ftp_rename($conn_id,$dir."/".$dirname,$dir."/".$rename) !== false) {
echo '<div class="success">'.str_replace('%s1',htmlentities($dir.'/'.$dirname),str_replace('%s2',htmlentities($dir.'/'.$rename),$_lng['renamedirsuccess'])).'</div>';
}
else {
echo '<div class="error">'.str_replace('%s1',htmlentities($dir.'/'.$dirname),str_replace('%s2',htmlentities($dir.'/'.$rename),$_lng['renamedirerror'])).'</div>';
}
}
else {
echo '<div class="error">'.str_replace('%s1',htmlentities($dir.'/'.$dirname),str_replace('%s2',htmlentities($dir.'/'.$rename),$_lng['renamedirerror'])).'</div>';
}
}
else {
echo '<b>'.$_lng['directory'].':</b> '.htmlentities($dir.'/'.$dirname).'<br /><input type="hidden" name="dir[]" value="'.htmlentities($dirname).'"><b>'.$_lng['renameto'].':</b><br /><input type="text" name="dir'.$d.'" value="'.htmlentities($dirname).'"/><br /><br />';
}

}
}


if (isset($_POST['file'])) {
$countFiles = count($_POST['file']);
for ($f = 0; $f < $countFiles; $f++) {
$filename = $_POST['file'][$f];
if (isset($_GET['execute'])) {
$cf = "file".$f;
$rename = $_POST[$cf];
if ((strlen($rename) > 1) AND ($rename != $dir) AND ($rename != $dir."/".$filename)) {
if (ftp_rename($conn_id,$dir."/".$filename,$dir."/".$rename) !== false) {
echo '<div class="success">'.str_replace('%s1','<b>'.htmlentities($dir.'/'.$filename).'</b>',str_replace('%s2','<b>'.htmlentities($dir.'/'.$rename).'</b>',$_lng['renamefilesuccess'])).'</div>';
}
else {
echo '<div class="error">'.str_replace('%s1','<b>'.htmlentities($dir.'/'.$filename).'</b>',str_replace('%s2','<b>'.htmlentities($dir.'/'.$rename).'</b>',$_lng['renamefileerror'])).'</div>';
}
}
else {
echo '<div class="error">'.str_replace('%s1','<b>'.htmlentities($dir.'/'.$filename).'</b>',str_replace('%s2','<b>'.htmlentities($dir.'/'.$rename).'</b>',$_lng['renamefileerror'])).'</div>';
}
}
else {
echo '<b>'.$_lng['filetitle'].':</b> '.htmlentities($dir.'/'.$filename).'<br /><input type="hidden" name="file[]" value="'.htmlentities($filename).'"><b>'.$_lng['renameto'].':</b><br /><input type="text" name="file'.$f.'" value="'.htmlentities($filename).'"/><br /><br />';
}

}
}

if (!isset($_GET['execute'])) {
echo '<br /><input type="hidden" name="action" value="rename"><input type="submit" name="submit" value="   '.$_lng['renamebutton'].'   "/></form>';
}
}
else {
echo '<div class="error">'.$_lng['renameerror'].'</div>';
}
ftp_close($conn_id);
echo '</div>';
require_once("includes/footer.php");
break;


case 'move':
$title = $_lng['movetitle'];
require_once("includes/header.php");
echo '<div class="content">';
showDirNav($dir);
if ($_ftp['help'] == "yes") {
echo '<div class="info">'.$_lng['help_move'].'</div><br />';
}
if (isset($_POST['dir']) || isset($_POST['file'])) {
echo '<form method="post" action="index.php?ftp=submit&amp;dir='.rawurlencode($dir).'&amp;execute=true">';

if (isset($_POST['dir'])) {
$countDirs = count($_POST['dir']);
for ($d = 0; $d < $countDirs; $d++) {
$dirname = $_POST['dir'][$d];
if (isset($_GET['execute'])) {
$cd = "dir".$d;
$move = $_POST[$cd];
if ((strlen($move) > 1) AND ($move != $dir) AND ($move != $dir."/".$dirname)) {
if (ftp_rename($conn_id,$dir."/".$dirname,$move) !== false) {
echo '<div class="success">'.str_replace('%s1','<b>'.htmlentities($dir.'/'.$dirname).'</b>',str_replace('%s2','<b>'.htmlentities($move).'</b>',$_lng['movedirsuccess'])).'</div>';
}
else {
echo '<div class="error">'.str_replace('%s1','<b>'.htmlentities($dir.'/'.$dirname).'</b>',str_replace('%s2','<b>'.htmlentities($move).'</b>',$_lng['movedirerror'])).'</div>';
}
}
else {
echo '<div class="error">'.str_replace('%s1','<b>'.htmlentities($dir.'/'.$dirname).'</b>',str_replace('%s2','<b>'.htmlentities($move).'</b>',$_lng['movedirerror'])).'</div>';
}
}
else {
echo '<b>'.$_lng['directory'].':</b> '.htmlentities($dir.'/'.$dirname).'<br /><input type="hidden" name="dir[]" value="'.htmlentities($dirname).'"><b>'.$_lng['moveto'].':</b><br /><input type="text" name="dir'.$d.'" value="'.htmlentities($dir.'/'.$dirname).'"/><br /><br />';
}

}
}


if (isset($_POST['file'])) {
$countFiles = count($_POST['file']);
for ($f = 0; $f < $countFiles; $f++) {
$filename = $_POST['file'][$f];
if (isset($_GET['execute'])) {
$cf = "file".$f;
$move = $_POST[$cf];
if ((strlen($move) > 1) AND ($move != $dir) AND ($move != $dir."/".$filename)) {
if (ftp_rename($conn_id,$dir."/".$filename,$move) !== false) {
echo '<div class="success">'.str_replace('%s1','<b>'.htmlentities($dir.'/'.$filename).'</b>',str_replace('%s2','<b>'.htmlentities($move).'</b>',$_lng['movefilesuccess'])).'</div>';
}
else {
echo '<div class="error">'.str_replace('%s1','<b>'.htmlentities($dir.'/'.$filename).'</b>',str_replace('%s2','<b>'.htmlentities($move).'</b>',$_lng['movefileerror'])).'</div>';
}
}
else {
echo '<div class="error">'.str_replace('%s1','<b>'.htmlentities($dir.'/'.$filename).'</b>',str_replace('%s2','<b>'.htmlentities($move).'</b>',$_lng['movefileerror'])).'</div>';
}
}
else {
echo '<b>'.$_lng['filetitle'].':</b> '.htmlentities($dir.'/'.$filename).'<br /><input type="hidden" name="file[]" value="'.htmlentities($filename).'"><b>'.$_lng['moveto'].':</b><br /><input type="text" name="file'.$f.'" value="'.htmlentities($dir.'/'.$filename).'"/><br /><br />';
}

}
}

if (!isset($_GET['execute'])) {
echo '<br /><input type="hidden" name="action" value="move"><input type="submit" name="submit" value="   '.$_lng['movebutton'].'   "/></form>';
}
}
else {
echo '<div class="error">'.$_lng['moveerror'].'</div>';
}
ftp_close($conn_id);
echo '</div>';
require_once("includes/footer.php");
break;

case 'delete':
$title = $_lng['deletetitle'];
require_once("includes/header.php");
echo '<div class="content">';
showDirNav($dir);
if (isset($_POST['dir'])) {
$countDirs = count($_POST['dir']);
for ($d = 0; $d < $countDirs; $d++) {
$dirname = $_POST['dir'][$d];
if (ftpDeleteDirectory($conn_id,$dir."/".$dirname)) {
echo '<div class="success">'.str_replace('%s','<b>'.htmlentities($directory.'/'.$dirname).'</b>',$_lng['deletedirsuccess']).'</div>';
}
else {
echo '<div class="error">'.str_replace('%s','<b>'.htmlentities($directory.'/'.$dirname).'</b>',$_lng['deletedirerror']).'</div>';
}
}
}
if (isset($_POST['file'])) {
$countFiles = count($_POST['file']);
for ($f = 0; $f < $countFiles; $f++) {
$filename = $_POST['file'][$f];
if (ftp_delete($conn_id,$directory."/".$filename)) {
echo '<div class="success">'.str_replace('%s','<b>'.htmlentities($directory.'/'.$filename).'</b>',$_lng['deletefilesuccess']).'</div>';
}
else {
echo '<div class="error">'.str_replace('%s','<b>'.htmlentities($directory.'/'.$filename).'</b>',$_lng['deletefileerror']).'</div>';
}
}
}
if (!isset($_POST['dir']) AND !isset($_POST['file'])) {
echo '<div class="error">ERROR</div>';
}
ftp_close($conn_id);
echo '</div>';
require_once("includes/footer.php");
break;

case 'backup':
$title = $_lng['backuptitle'];
require_once("includes/header.php");
echo '<div class="content">';
showDirNav($dir);
if (isset($_POST['dir']) || isset($_POST['file'])) {
createDir();
echo '<form method="post" action="index.php?ftp=submit&amp;dir='.rawurlencode($dir).'&amp;execute=true">';
if (isset($_POST['dir'])) {
$countDirs = count($_POST['dir']);
for ($d = 0; $d < $countDirs; $d++) {
$dirname = $_POST['dir'][$d];
$local = $dir_dataftp.'/'.$_ftp['id'];
if (isset($_GET['execute'])) {
$coping = ftpFileList($dir."/".$dirname);
foreach ($coping as $item) {
$localDir = $local.substr($item,strlen($dir),"-".(strlen(basename($item)) + 1));
$ftpDir = $cd.substr($localDir,strlen($local));
localMkDirRecusive($localDir);
ftp_get($conn_id,$localDir."/".basename($item),$item,FTP_BINARY);
}
}
else {
echo '<input type="hidden" name="dir[]" value="'.htmlentities($dirname).'">';
}
}
}

if (isset($_POST['file'])) {
$countFiles = count($_POST['file']);
for ($f = 0; $f < $countFiles; $f++) {
$filename = $_POST['file'][$f];
if (isset($_GET['execute'])) {
ftp_get($conn_id,$dir_dataftp."/".$_ftp['id']."/".$filename,$dir."/".$filename,FTP_BINARY);
}
else {
echo '<input type="hidden" name="file[]" value="'.htmlentities($filename).'">';
}
}
}
if (isset($_GET['execute'])) {
$save = $_POST['save'];
$local = $dir_dataftp.'/'.$_ftp['id'];
$ext = getExtension(basename($save));
if ($ext == "zip" || $ext == "jar") {
require_once('includes/pclzip.lib.php');
$zip = new PclZip($local."/BACKUP.zip");
if ($zip->add($local, PCLZIP_OPT_REMOVE_PATH, $local)!=0)
{$list = $zip->delete(PCLZIP_OPT_BY_NAME, "BACKUP.zip");if ($list == 0)
{
$send = ftp_put($conn_id,$save,$local."/BACKUP.zip",FTP_BINARY);
}
else {
$send = ftp_put($conn_id,$save,$local."/BACKUP.zip",FTP_BINARY);
}
if ($send)
echo '<div class="success">'.$_lng['backupsuccess'].' '.htmlentities($save).'</div>';
else
echo '<div class="error">'.$_lng['backuperror'].' '.htmlentities($save).'</div>';
}
else {
echo $_lng['backuperror'];
}
} else {
require_once("includes/tar.php");
$tar = new Archive_Tar($local."/BACKUP.tar");
if ($tar->createModify($local,"",$local)) {if (ftp_put($conn_id,$save,$local."/BACKUP.tar",FTP_BINARY)) {echo '<div class="success">'.$_lng['backupsuccess'].' '.htmlentities($save).'</div>';
}
else {
echo '<div class="error">'.$_lng['backuperror'].' '.htmlentities($save).'</div>';
}
}
else {
echo $_lng['backuperror'];
}
}


}
else {
echo '<b>'.$_lng['saveas'].':</b><br /><input type="text" name="save" value="'.htmlentities($dir).'/Archive.zip"/><br /><input type="hidden" name="action" value="backup"><input type="submit" name="submit" value="   '.$_lng['backupbutton'].'   "/></form>';
}
deleteDir($dir_dataftp.'/'.$_ftp['id']);
}
else {
echo '<div class="error">ERROR</div>';
}
ftp_close($conn_id);
echo '</div>';
require_once("includes/footer.php");
break;


case 'copy':
$title = $_lng['copytitle'];
require_once("includes/header.php");
echo '<div class="content">';
showDirNav($dir);
if ($_ftp['help'] == "yes") {
echo '<div class="info">'.$_lng['help_copy'].'</div><br />';
}
if (isset($_POST['dir']) || isset($_POST['file'])) {
createDir();
echo '<form method="post" action="index.php?ftp=submit&amp;dir='.rawurlencode($dir).'&amp;execute=true">';
if (isset($_POST['dir'])) {
$countDirs = count($_POST['dir']);
for ($d = 0; $d < $countDirs; $d++) {
$dirname = $_POST['dir'][$d];
$cd = "dir".$d;
$cd = isset($_POST[$cd]) ? $_POST[$cd] : '/';
if (substr($cd,-1) == "/")
$cd = substr($cd,0,-1);
$local = $dir_dataftp.'/'.$_ftp['id'];
if (isset($_GET['execute'])) {
$coping = ftpFileList($dir."/".$dirname);
foreach ($coping as $item) {
$localDir = $local.substr($item,strlen($dir),"-".(strlen(basename($item)) + 1));
$ftpDir = $cd.substr($localDir,strlen($local));
localMkDirRecusive($localDir);
if (ftp_get($conn_id,$localDir."/".basename($item),$item,FTP_BINARY)) {
ftpMkDirRecusive($ftpDir);
if (ftp_put($conn_id,$ftpDir."/".basename($item),$localDir."/".basename($item),FTP_BINARY)) {
echo '<div class="success">'.str_replace('%s','<b>'.htmlentities($dirname).'</b>',str_replace('%s1','<b>'.htmlentities($item).'</b>',str_replace('%s2','<b>'.htmlentities($ftpDir.'/'.basename($item)).'</b>',$_lng['copydirsuccess']))).'</div>';
}
else {
echo '<div class="error">'.str_replace('%s','<b>'.htmlentities($dirname).'</b>',str_replace('%s1','<b>'.htmlentities($item).'</b>',str_replace('%s2','<b>'.htmlentities($ftpDir.'/'.basename($item)).'</b>',$_lng['copydirerror']))).'</div>';
}
}
else {
echo '<div class="error">'.str_replace('%s','<b>'.htmlentities($dirname).'</b>',str_replace('%s1','<b>'.htmlentities($item).'</b>',str_replace('%s2','<b>'.htmlentities($ftpDir.'/'.basename($item)).'</b>',$_lng['copygeterror']))).'</div>';
}
}
}
else {
echo '<b>'.$_lng['directory'].':</b> '.htmlentities($dirname).'<br /><input type="hidden" name="dir[]" value="'.htmlentities($dirname).'"><b>'.$_lng['copyto'].':</b><br /><input type="text" name="dir'.$d.'" value="'.htmlentities($dir).'"><br /><br />';
}
}
}
if (isset($_POST['file'])) {
$countFiles = count($_POST['file']);
for ($f = 0; $f < $countFiles; $f++) {
$filename = $_POST['file'][$f];
if (isset($_GET['execute'])) {
$fc = "file".$f;
$copy = $_POST[$fc];
if (ftp_get($conn_id,$dir_dataftp."/".$_ftp['id']."/".$filename,$dir."/".$filename,FTP_BINARY)) {
if (ftp_put($conn_id,$copy,$dir_dataftp."/".$_ftp['id']."/".$filename,FTP_BINARY)) {
echo '<div class="success">'.str_replace('%s','<b>'.htmlentities($filename).'</b>',str_replace('%s1','<b>'.htmlentities($dir.'/'.$filename).'</b>',str_replace('%s2','<b>'.htmlentities($copy).'</b>',$_lng['copyfilesuccess']))).'</div>';
}
else {
echo '<div class="error">'.str_replace('%s','<b>'.htmlentities($filename).'</b>',str_replace('%s1','<b>'.htmlentities($dir.'/'.$filename).'</b>',str_replace('%s2','<b>'.htmlentities($copy).'</b>',$_lng['copyfileerror']))).'</div>';
}
}
else {
echo '<div class="error">'.str_replace('%s','<b>'.htmlentities($filename).'</b>',str_replace('%s2','<b>'.htmlentities($dir.'/'.$filename).'</b>',$_lng['copyfilegeterror'])).'</div>';
}
}
else {
echo '<b>'.$_lng['filetitle'].':</b> '.htmlentities($dir.'/'.$filename).'<br /><input type="hidden" name="file[]" value="'.htmlentities($filename).'"><b>'.$_lng['copyto'].':</b><br /><input type="text" name="file'.$f.'" value="'.htmlentities($dir.'/Copy_'.$filename).'"><br /><br />';
}
}
}
if (!isset($_GET['execute'])) {
echo '<br /><input type="hidden" name="action" value="copy"><input type="submit" name="submit" value="   '.$_lng['copybutton'].'   "/></form>';
}
deleteDir($dir_dataftp.'/'.$_ftp['id']);
}
else {
echo '<div class="error">Tidak ada file atau direktori yang dipilih!</div>';
}
ftp_close($conn_id);
echo '</div>';
require_once("includes/footer.php");
break;

case 'chmod':
$title = $_lng['chmodtitle'];
require_once("includes/header.php");
echo '<div class="content">';
showDirNav($dir);
if ($_ftp['help'] == "yes") {
echo '<div class="info">'.$_lng['help_chmod'].'</div><br />';
}
if (isset($_POST['dir']) || isset($_POST['file'])) {
echo '<form method="post" action="index.php?ftp=submit&amp;dir='.rawurlencode($dir).'&amp;execute=true">';

if (isset($_POST['dir'])) {
$countDirs = count($_POST['dir']);
for ($d = 0; $d < $countDirs; $d++) {
$dirname = $_POST['dir'][$d];
if (isset($_GET['execute'])) {
$cd = "dir".$d;
$chmod = $_POST[$cd];
if (strlen($chmod) == 3 AND ctype_digit($chmod)) {
if (ftp_site($conn_id,"CHMOD 0".$chmod." ".$dir."/".$dirname) !== false) {
echo '<div class="success">'.str_replace('%s1','<b>'.htmlentities($dir.'/'.$dirname).'</b>',str_replace('%s2','<b>'.htmlentities($chmod).'</b>',$_lng['chmoddirsuccess'])).'</div>';
}
else {
echo '<div class="error">'.str_replace('%s1','<b>'.htmlentities($dir.'/'.$dirname).'</b>',str_replace('%s2','<b>'.htmlentities($chmod).'</b>',$_lng['chmoddirerror'])).'</div>';
}
}
else {
echo '<div class="error">'.$_lng['directory'].' <b>'.htmlentities($dir.'/'.$dirname).'</b><br />'.$_lng['chmodterms'].'</div>';
}
}
else {
echo '<b>'.$_lng['directory'].':</b> '.htmlentities($dir.'/'.$dirname).'<br /><input type="hidden" name="dir[]" value="'.htmlentities($dirname).'"><b>'.$_lng['chmod'].':</b><br /><input type="text" name="dir'.$d.'" value="" size="3"/><br /><br />';
}

}
}

if (isset($_POST['file'])) {
$countFiles = count($_POST['file']);
for ($f = 0; $f < $countFiles; $f++) {
$filename = $_POST['file'][$f];
if (isset($_GET['execute'])) {
$cf = "file".$f;
$chmod = $_POST[$cf];
if (strlen($chmod) == 3 AND ctype_digit($chmod)) {
if (ftp_site($conn_id,"CHMOD 0".$chmod." ".$dir."/".$filename) !== false) {
echo '<div class="success">'.str_replace('%s1','<b>'.htmlentities($dir.'/'.$filename).'</b>',str_replace('%s2','<b>'.htmlentities($chmod).'</b>',$_lng['chmodfilesuccess'])).'</div>';
}
else {
echo '<div class="error">'.str_replace('%s1','<b>'.htmlentities($dir.'/'.$filename).'</b>',str_replace('%s2','<b>'.htmlentities($chmod).'</b>',$_lng['chmodfileerror'])).'</div>';
}
}
else {
echo '<div class="error">'.$_lng['filetitle'].' <b>'.htmlentities($dir.'/'.$filename).'</b><br />'.$_lng['chmodterms'].'</div>';
}
}
else {
echo '<b>'.$_lng['filetitle'].':</b> '.htmlentities($dir.'/'.$filename).'<br /><input type="hidden" name="file[]" value="'.htmlentities($filename).'"><b>'.$_lng['chmod'].':</b><br /><input type="text" name="file'.$f.'" value="" size="3"/><br /><br />';
}

}
}

if (!isset($_GET['execute'])) {
echo '<br /><input type="hidden" name="action" value="chmod"><input type="submit" name="submit" value="   '.$_lng['chmodbutton'].'   "/></form>';
}

}
else {
echo '<div class="error">ERROR</div>';
}
ftp_close($conn_id);
echo '</div>';
require_once("includes/footer.php");
break;

default:
header("Location: index.php?ftp=list");
break;
}
?>