<?php

/*
------------------ WARNING!!! DO NOT REMOVE THIS LINE ------------------

* Script Name: MyRootFTP
* Version: See VERSION.txt
* Author: Achunk JealousMan
* Email: achunk17@gmail.com
* Homepage: http://myroot.7ko.in
*/

defined('PAGEDISPLAY') or die('Access Forbidden');
if ($client_id == 0) {
header("Location: index.php");
exit;
}
$dir = rawurldecode(trim($_GET['dir']));

if (isset($_POST['import'])) {
if ($dir == "/")
$directory = "";
else
$directory = $dir;
createDir();
$count = count($_POST['url']);
for ($i = 0; $i < $count; $i++) {
$url = $_POST['url'][$i];
if ($url != NULL AND $url != "http://" AND (substr($url,0,7) == "http://" OR substr($url,0,8) == "https://")) {
$target = explode("/",substr($url,7));
$host = $target[0];
$path = substr($url,(strlen($host) + 7));
$fp = fsockopen($host,80,$errno,$errstr,10);
$headers = "GET $path HTTP/1.1\r\n";

$headers .= "Host: $host\r\n";
$headers .= "Accept: **\r\n";
$headers .= "Accept-Charset: **\r\n";
$headers .= "Content-Type: application/x-www-form-urlencoded\r\n";
$headers .= "User-Agent: Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1) Gecko/20060918 Firefox/2.0\r\n\r\n";
fputs($fp,$headers);
while(!feof($fp))
{
$header .= fgets($fp,512);
}fclose($fp);
if (strpos($header,"Content-Length:")!==false) {
eregi("Content-Length: ([0-9]*)",$header,$mss);
$filesize = trim($mss[1]);
}
if ($filesize <= 9242880) {
$local = $dir_dataftp."/".$_ftp['id']."/".basename($url);
if (copy($url,$local)) {
if (ftp_put($conn_id,$directory."/".basename($local),$local,FTP_BINARY)) {
$success .= str_replace('%s',htmlentities(basename($local)),$_lng['importsuccess']);
}
else {
$error .= $_lng['cantsavefile'];
}
unlink($local);
}
else {
$error .= $_lng['cantcopyfile'].' '.htmlentities($url).'<br />';
}
}
else {
$error .= str_replace('%s',htmlentities($url),$_lng['filetoobig']).'<br />';
}
}
}
deleteDir($dir_dataftp."/".$_ftp['id']);
}
ftp_close($conn_id);

$title = $_lng['importtitle'].": ".htmlspecialchars($dir);
require_once("includes/header.php");
echo '<div class="content">';
showDirNav($dir);
if ($success)
echo '<div class="success">'.$success.'</div>';
if ($error)
echo '<div class="error">'.$error.'</div>';
echo '<form method="post" action="index.php?ftp=import&amp;dir='.rawurlencode($dir).'"><b>'.$_lng['filetitle'].'</b><br /><input type="text" name="url[]" value="http://"/><br /><b>'.$_lng['filetitle'].'</b><br /><input type="text" name="url[]" value="http://"/><br /><b>'.$_lng['filetitle'].'</b><br /><input type="text" name="url[]" value="http://"/><br /><b>'.$_lng['filetitle'].'</b><br /><input type="text" name="url[]" value="http://"/><br /><b>'.$_lng['filetitle'].'</b><br /><input type="text" name="url[]" value="http://"/><br /><input type="submit" name="import" value="   '.$_lng['importbutton'].'   "/></form></div>';
require_once("includes/footer.php");
?>