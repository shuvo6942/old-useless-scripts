<?php

/*
------------------ WARNING!!! DO NOT REMOVE THIS LINE ------------------

* Script Name: MyRootFTP
* Version: See VERSION.txt
* Author: Achunk JealousMan
* Email: achunk17@gmail.com
* Homepage: http://myroot.7ko.in
*/

defined('PAGEDISPLAY') or die('Access Forbidden!');

if ($client_id == 0) {
header("Location: index.php");
exit;
}
$file = rawurldecode($_GET['file']);
if ($file == "") {
header("Location: index.php?ftp=list");
exit;
}
$local = $dir_dataftp."/".$_ftp['id'];
$filename = basename($file);
$dir = substr($file,"0","-".(strlen($filename) + 1));
$size = ftp_size($conn_id,$file);
if ($size >= 222880) {
header("Location: index.php?ftp=list");
exit;
}
createDir();
if (ftp_get($conn_id,$local."/".$filename,$file,FTP_BINARY) !== false) {
$s = file($local."/".$filename);
for ($i = 0; $i < count($s); $i++) {
$source .= htmlentities($s[$i],ENT_QUOTES)."<br />";
}
}
else {
$source = "";
}
$title = $_lng['sourcetitle'].": ".htmlspecialchars($file);
require_once("includes/header.php");
echo '<div class="content">';
showDirNav($dir);
echo '<b>'.$_lng['filetitle'].':</b> <a href="index.php?ftp=file&amp;file='.rawurlencode($file).'">'.htmlentities($file).'</a><br />'.$source.'</div>';
require_once("includes/footer.php");
deleteDir($local);
ftp_close($conn_id);
?>