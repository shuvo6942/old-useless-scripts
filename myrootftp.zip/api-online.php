<?php

define('PAGEDISPLAY', true);
if (!file_exists("includes/config.php")) {
echo "Please install before!";
exit;
}
ignore_user_abort(true);
error_reporting(0);
mb_internal_encoding('UTF-8');
ini_set('default_charset','UTF-8');
date_default_timezone_set('UTC');
ini_set('session.cookie_domain', $_SERVER['HTTP_HOST']);

/*
set_time_limit(0);

*/
ob_start();


session_start();

$ftp = isset($_GET['ftp']) ? trim($_GET['ftp']) : '';
$ftp = strtolower(preg_replace('#([\W_]+)#','_',$ftp));
include("language.php");
require("includes/config.php");
require("includes/connect.php");
require("includes/functions.php");
/*
------------------ WARNING!!! DO NOT REMOVE THIS LINE ------------------

* Script Name: MyRootFTP
* Version: See VERSION.txt
* Author: Achunk JealousMan
* Email: achunk17@gmail.com
* Homepage: http://myroot.7ko.in
*/

defined('PAGEDISPLAY') or die('Access Forbidden!');
$sql_connect = mysql_connect($db_host,$db_user,$db_pass);
if (!$sql_connect) {
die("Connecting Error!");
exit;
}
mysql_select_db($db_name) or die('Database Error!');
$ol = time() - 300;
$user_ol=mysql_result(mysql_query("SELECT COUNT(*) FROM `".$db_prefix."ftp` WHERE `lastlogin` > $ol"), 0);
mysql_close($sql_connect);
header("Content-Type: application/x-javascript");
?>document.write('<?=$user_ol;?><br>');