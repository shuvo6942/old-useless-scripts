<?
// A
$_lng['aboutftp'] = "<h1>Tentang FTP</h1>Protokol pengiriman berkas (Bahasa inggris: File Transfer Protocol) adalah sebuah protokol Internet yang berjalan di dalam lapisan aplikasi yang merupakan standar untuk pengiriman berkas (file) komputer antar mesin-mesin dalam sebuah Antar jaringan.<br />FTP merupakan salah satu protokol Internet yang paling awal dikembangkan, dan masih digunakan hingga saat ini untuk melakukan pengunduhan (download) dan penggugahan (upload) berkas-berkas komputer antara klien FTP dan server FTP. Sebuah Klien FTP merupakan aplikasi yang dapat mengeluarkan perintah-perintah FTP ke sebuah server FTP, sementara server FTP adalah sebuah Windows Service atau daemon yang berjalan di atas sebuah komputer yang merespons perintah-perintah dari sebuah klien FTP.<br />Perintah-perintah FTP dapat digunakan untuk mengubah direktori, mengubah modus pengiriman antara biner dan ASCII, menggugah berkas komputer ke server FTP, serta mengunduh berkas dari server FTP.<br />Sebuah server FTP diakses dengan menggunakan Universal Resource Identifier (URI) dengan menggunakan format ftp://namaserver. Klien FTP dapat menghubungi server FTP dengan membuka URI tersebut.<br />FTP menggunakan protokol Transmission Control Protocol (TCP) untuk komunikasi data antara klien dan server, sehingga di antara kedua komponen tersebut akan dibuatlah sebuah sesi komunikasi sebelum pengiriman data dimulai. Sebelum membuat koneksi, port TCP nomor 21 di sisi server akan \"mendengarkan\" percobaan koneksi dari sebuah klien FTP dan kemudian akan digunakan sebagai port pengatur (control port) untuk (1) membuat sebuah koneksi antara klien dan server, (2) untuk mengizinkan klien untuk mengirimkan sebuah perintah FTP kepada server dan juga (3) mengembalikan respons server ke perintah tersebut. Sekali koneksi kontrol telah dibuat, maka server akan mulai membuka port TCP nomor 20 untuk membentuk sebuah koneksi baru dengan klien untuk mengirim data aktual yang sedang dipertukarkan saat melakukan pengunduhan dan penggugahan.<br />FTP hanya menggunakan metode autentikasi standar, yakni menggunakan username dan password yang dikirim dalam bentuk tidak ter enkripsi. Pengguna terdaftar dapat menggunakan username dan password-nya untuk mengakses, men-download, dan meng-upload berkas-berkas yang ia kehendaki. Umumnya, para pengguna terdaftar memiliki akses penuh terhadap beberapa direktori, sehingga mereka dapat membuat berkas, membuat direktori, dan bahkan menghapus berkas. Pengguna yang belum terdaftar dapat juga menggunakan metode anonymous login, yakni dengan menggunakan nama pengguna anonymous dan password yang diisi dengan menggunakan alamat e-mail.<br /><br />Sumber: <a href=\"http://id.wikipedia.org/wiki/Protokol_Transfer_Berkas\">http://id.wikipedia.org/wiki/Protokol_Transfer_Berkas</a>";
$_lng['actionbutton'] = "Apply";
$_lng['actionconfirm'] = "Are you sure will take this action?";
$_lng['agreement'] = "I believe that the <a href=\"privacy.php\">privacy</a> of my account is safe here.";
$_lng['agreementerror'] = "You do not mark the approval column.";
$_lng['archiveempty'] = "Archive Empty";

// B
$_lng['back'] = "Back";
$_lng['backupwithdirectory'] = "With the %s directory inside?";
$_lng['backupbutton'] = "Backup";
$_lng ['backuperror'] = "Failed to create";
$_lng['backupsuccess'] = "Archive successfully created and has been saved as";
$_lng['backuptitle'] = "Backup";

// C
$_lng['cantcopyfile'] = "Can't copy file!";
$_lng['cantcopydirectory'] = "Can't copy directory!";
$_lng['cantcreatedirectory'] = "Cant create directory";
$_lng['cantcreatefile'] = "Cant create file";
$_lng['cantgetfile'] = "Can't get file!";
$_lng['cantsavefile'] = "Can't save file";
$_lng['checksyntax'] = "Check Syntax";
$_lng['chmod'] = "CHMOD";
$_lng['chmodbutton'] = "Chmod";
$_lng['connectbutton'] = "Connect";
$_lng['chmoddirerror'] = "Directory %s1 cant chmod to %s2";
$_lng['chmoddirsuccess'] = "Directory %s1 successfully chmod to %s2";
$_lng['chmodfileerror'] = "File %s1 cant chmod to %s2";
$_lng['chmodfilesuccess'] = "File %s1 successfully chmod to %s2";
$_lng['chmoddirectory'] = "CHMOD Directory";
$_lng['chmoderror'] = "Chmod failed!";
$_lng['chmodfile'] = "CHMOD File";
$_lng['chmodterms'] = "Chmod only digit allowed and lenght 3!";
$_lng['chmodtitle'] = "Chmod";
$_lng['connectingerror'] = "Unable to connect to FTP server with the account details below.";
$_lng['connectingerror2'] = "or try again later.";
$_lng['contact'] = "Contact";
$_lng['cookieterms'] = "Cookies and Javascript must be enabled.";
$_lng['copybutton'] = "Copy";
$_lng['copydirerror'] = "Directory: %s<br />Can't copy %s1 to %s2";
$_lng['copydirsuccess'] = "Directory: %s<br />Successfully copy %s1 to %s2";
$_lng['copyfileerror'] = "File: %s<br />Can't copy %s1 to %s2";
$_lng['copyfilesuccess'] = "File: %s<br />Successfully copy %s1 to %s2";
$_lng['copygeterror'] = "Directory: %s<br />Can't get the file %s2";
$_lng['copyfilegeterror'] = "File: %s<br />Can't get the file %s2";
$_lng['copyto'] = "Copy to";
$_lng['copytitle'] = "Copy";
$_lng['createbutton'] = "Create";
$_lng['createtitle'] = "Create";
$_lng['createinstaller'] = "Create Installer";
$_lng['createsqlbutton'] = "Create";

// D
$_lng['day'] = "Day";
$_lng['deletedirectoryerror'] = "Error deleting directory";
$_lng['deletefileerror'] = "Error deleting file";
$_lng['deleteconfirm'] = "Are you sure you want to delete this?";
$_lng['deletedirerror'] = "Directory %s cant be deleted";
$_lng['deletefileerror'] = "File %s cant be deleted";
$_lng['deletedirsuccess'] = "Directory %s successfully deleted";
$_lng['deletefilesuccess'] = "File %s successfully deleted";
$_lng['deletetitle'] = "Delete";
$_lng['deletebutton'] = "Delete";
$_lng['directory'] = "Directory";
$_lng['download'] = "Download";

// E
$_lng['editerror'] = "Changes can't be saved";
$_lng['editfile'] = "Edit File";
$_lng['editsuccess'] = "Changes successfully saved";
$_lng['elementsperpage'] = "Elements per page";
$_lng['emptyname'] = "Name cant be empty";
$_lng['emptynewname'] = "New name cant be empty!";
$_lng['error'] = "Error!";
$_lng['extractbutton'] = "Extract";
$_lng['extracttitle'] = "Extract";
$_lng['extractarchive'] = "Extract Archive";
$_lng['extracterror'] = "Unable to extract file";
$_lng['extractitemsuccess'] = "Item successfully extracted and has been saved as";

// F
$_lng['faq'] = "FAQ";
$_lng['fileinfo'] = "File Info";
$_lng['filename'] = "Name";
$_lng['filesize'] = "Size";
$_lng['filenotfound'] = "File not found!";
$_lng['filetitle'] = "File";
$_lng['filetoobig'] = "File %s is too big to imported. Max file size 5mb";
$_lng['formerror'] = "Please completed the form!";
$_lng['ftpconnecterror'] = "Can't connect to FTP server!";
$_lng['ftpdirectory'] = "Directory";
$_lng['ftppassword'] = "Password";
$_lng['ftpport'] = "FTP port";
$_lng['ftpserver'] = "FTP server";
$_lng['ftpusername'] = "Username";

// G
$_lng['globaltitle'] = "My Root FTP";
$_lng['go'] = "Go";

// H
$_lng['height'] = "Height";
$_lng['hour'] = "Hour";

// I
$_lng['imageresize'] = "Image Resize";
$_lng['importbutton'] = "Import";
$_lng['importtitle'] = "Import";
$_lng['importsuccess'] = "File %s successfully imported";
$_lng['item'] = "Item";

// L
$_lng['language'] = "Language";
$_lng['lastmodified'] = "Last modified";
$_lng['listtitle'] = "Lists";
$_lng['login'] = "Login";
$_lng['loginfor'] = "Login for";
$_lng['logout'] = "Logout";

// M
$_lng['minute'] = "Minute";
$_lng['month'] = "Month";
$_lng['movebutton'] = "Move";
$_lng['moveerror'] = "Move Error";
$_lng['movedirerror'] = "Directory %s1 cant moved to %s2";
$_lng['movedirsuccess'] = "Directory %s1 successfully moved to %s2";
$_lng['movefileerror'] = "File %s1 cant moved to %s2";
$_lng['movefilesuccess'] = "File %s1 successfully moved to %s2";
$_lng['movetitle'] = "Move";
$_lng['moveto'] = "Move to";

// N
$_lng['name'] = "Name";
$_lng['newname'] = "New name";
$_lng['no'] = "No";

// O
$_lng['oldname'] = "Old name";
$_lng['openarchive'] = "Open Archive";

// P
$_lng['password'] = "Password";

// R
$_lng['renamebutton'] = "Rename";
$_lng['renamedirerror'] = "Directory %s1 cant renamed to %s2";
$_lng['renamedirsuccess'] = "Directory %s1 successfully renamed to %s2";
$_lng['renameerror'] = "Rename Failed!";
$_lng['renamefileerror'] = "File %s1 cant renamed to %s2";
$_lng['renamefilesuccess'] = "File %s1 successfully renamed to %s2";
$_lng['renametitle'] = "Rename";
$_lng['renameto'] = "Rename to";
$_lng['resizeimage'] = "Resize";
$_lng['resizeimageerror'] = "Image cant be saved";
$_lng['resizeimagesuccess'] = "Image has been resize to %w x %h and saved as %image";

// S
$_lng['saveas'] = "Save as";
$_lng['savebutton'] = "Save";
$_lng['sessionerror'] = "Session time out.";
$_lng['settings'] = "Settings";
$_lng['settingssuccessfullysaved'] = "Settings successfully saved";
$_lng['showhelptext'] = "Show help text";
$_lng['showicon'] = "Show icon";
$_lng['showsize'] = "Show size";
$_lng['sourcetitle'] = "Source";
$_lng['sqldatabase'] = "Database";
$_lng['sqlhost'] = "Host";
$_lng['sqlpassword'] = "Password";
$_lng['sqluser'] = "User";
$_lng['syntaxtitle'] = "Syntax";

// T
$_lng['totalfile'] = "Total Files";
$_lng['type'] = "Type";

// U
$_lng['unableextract'] = "Unable to extract file";
$_lng['untarbutton'] = "Extract";
$_lng['untartitle'] = "Untar";
$_lng['untarerror'] = "unable to sent to your server.";
$_lng['untarsuccess'] = "successfully sent to your server.";
$_lng['unzipbutton'] = "Unzip";
$_lng['unziperror'] = "unable sent to your server.";
$_lng['unzipdir'] = "Directory";
$_lng['unzipsuccess'] = "successfully sent to your server.";
$_lng['unziptitle'] = "Unzip";
$_lng['uploadbutton'] = "Upload";
$_lng['uploaderror'] = "can't to uploaded.";
$_lng['uploadinfo'] = "Choose files (max 5 mb per file)";
$_lng['uploadsuccess'] = "successfully uploaded.";
$_lng['uploadtitle'] = "Upload";

// W
$_lng['width'] = "Width";
$_lng['week'] = "Week";
$_lng['withselected'] = "With selected elements";
$_lng['withsize'] = "with size";

// Y
$_lng['yes'] = "Yes";

// Z
$_lng['zipinstaller'] = "Zip installer";

$_lng['help_chmod'] = "Set permission for directory or file. CHMOD only digit number allowed (000 up to 777) and must be 3 digits";
$_lng['help_copy'] = "Copy file or directory. The destination directory must already exist.";
$_lng['help_create'] = "Please insert Name and select type. If you create File then CHMOD automatically to 644 and if you create Directory then CHMOD automatically to 755.";
$_lng['help_list'] = "Showing directories and files. To start creating directory or file please click <b>Create</b>.";
$_lng['help_move'] = "Move file or directory to another directory. The destination directory must already exist.";
$_lng['help_unzip'] = "Please insert the directories location for extracting this file. If the destination directory does not exist it will be created automatically.";
?>