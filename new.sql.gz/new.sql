-- MySQL dump 10.13  Distrib 5.5.40, for Linux (x86_64)
--
-- Host: localhost    Database: user1100_colld
-- ------------------------------------------------------
-- Server version	5.5.40-cll

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `couple`
--

DROP TABLE IF EXISTS `couple`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `couple` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `who` int(100) NOT NULL DEFAULT '0',
  `partner` int(100) NOT NULL DEFAULT '0',
  `req` int(100) NOT NULL DEFAULT '0',
  `accept` int(100) NOT NULL DEFAULT '0',
  `joined` int(100) NOT NULL DEFAULT '0',
  `time` int(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `couple`
--

LOCK TABLES `couple` WRITE;
/*!40000 ALTER TABLE `couple` DISABLE KEYS */;
INSERT INTO `couple` (`id`, `who`, `partner`, `req`, `accept`, `joined`, `time`) VALUES (1,1,3,2,1,1420565433,1420565035);
/*!40000 ALTER TABLE `couple` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `foribd_extra_power`
--

DROP TABLE IF EXISTS `foribd_extra_power`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `foribd_extra_power` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `userid` int(12) NOT NULL,
  `access_codes_new_fbd` int(12) NOT NULL DEFAULT '0',
  `name` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `foribd_extra_power`
--

LOCK TABLES `foribd_extra_power` WRITE;
/*!40000 ALTER TABLE `foribd_extra_power` DISABLE KEYS */;
INSERT INTO `foribd_extra_power` (`id`, `userid`, `access_codes_new_fbd`, `name`) VALUES (1,1,7080901,'Admin'),(2,3,7080901,'Chatgirl');
/*!40000 ALTER TABLE `foribd_extra_power` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himel_conf`
--

DROP TABLE IF EXISTS `himel_conf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himel_conf` (
  `id` int(120) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `text` varchar(1565) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `time` varchar(1465) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `timex` varchar(65) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `uid` int(40) NOT NULL DEFAULT '0',
  `prov` int(40) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himel_conf`
--

LOCK TABLES `himel_conf` WRITE;
/*!40000 ALTER TABLE `himel_conf` DISABLE KEYS */;
INSERT INTO `himel_conf` (`id`, `name`, `text`, `time`, `timex`, `uid`, `prov`) VALUES (1,'ioli','','','',1,0),(2,'My first conference','','','',7,0);
/*!40000 ALTER TABLE `himel_conf` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himel_confuser`
--

DROP TABLE IF EXISTS `himel_confuser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himel_confuser` (
  `id` int(120) NOT NULL AUTO_INCREMENT,
  `uid` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `cnid` varchar(1565) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `time` varchar(1465) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `timex` varchar(65) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `vld` int(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himel_confuser`
--

LOCK TABLES `himel_confuser` WRITE;
/*!40000 ALTER TABLE `himel_confuser` DISABLE KEYS */;
INSERT INTO `himel_confuser` (`id`, `uid`, `cnid`, `time`, `timex`, `vld`) VALUES (1,'1','1','','',0),(2,'7','2','','',0),(3,'15','2','','',0);
/*!40000 ALTER TABLE `himel_confuser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `himel_conmsg`
--

DROP TABLE IF EXISTS `himel_conmsg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `himel_conmsg` (
  `id` int(120) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `text` varchar(1565) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `time` varchar(1465) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `timex` varchar(65) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `vld` int(4) NOT NULL DEFAULT '0',
  `cnid` int(40) NOT NULL DEFAULT '0',
  `uid` int(46) NOT NULL DEFAULT '0',
  `img` int(4) NOT NULL DEFAULT '0',
  `cat` varchar(1465) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `rate` varchar(65) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `himel_conmsg`
--

LOCK TABLES `himel_conmsg` WRITE;
/*!40000 ALTER TABLE `himel_conmsg` DISABLE KEYS */;
INSERT INTO `himel_conmsg` (`id`, `name`, `text`, `time`, `timex`, `vld`, `cnid`, `uid`, `img`, `cat`, `rate`) VALUES (1,'','iholi','','',0,1,1,0,'',''),(2,'','\\\\\\\'','','',0,1,1,0,'',''),(3,'','My first text','','',0,2,7,0,'','');
/*!40000 ALTER TABLE `himel_conmsg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwf_announcements`
--

DROP TABLE IF EXISTS `ibwf_announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwf_announcements` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `antext` varchar(200) NOT NULL DEFAULT '',
  `clid` int(100) NOT NULL DEFAULT '0',
  `antime` int(100) NOT NULL DEFAULT '0',
  `name` text NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwf_announcements`
--

LOCK TABLES `ibwf_announcements` WRITE;
/*!40000 ALTER TABLE `ibwf_announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwf_announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwf_buddies`
--

DROP TABLE IF EXISTS `ibwf_buddies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwf_buddies` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `uid` int(100) NOT NULL,
  `tid` int(100) NOT NULL,
  `agreed` int(1) NOT NULL,
  `reqdt` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwf_buddies`
--

LOCK TABLES `ibwf_buddies` WRITE;
/*!40000 ALTER TABLE `ibwf_buddies` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwf_buddies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwf_fanpage`
--

DROP TABLE IF EXISTS `ibwf_fanpage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwf_fanpage` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `bowner` int(100) NOT NULL DEFAULT '0',
  `bname` varchar(100) NOT NULL DEFAULT '',
  `btext` varchar(1000) NOT NULL,
  `bgdate` int(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `bname` (`bname`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwf_fanpage`
--

LOCK TABLES `ibwf_fanpage` WRITE;
/*!40000 ALTER TABLE `ibwf_fanpage` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwf_fanpage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwf_fanpageads`
--

DROP TABLE IF EXISTS `ibwf_fanpageads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwf_fanpageads` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `owner` int(100) NOT NULL DEFAULT '0',
  `pageid` int(30) NOT NULL,
  `title` varchar(20) NOT NULL,
  `bgdate` int(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `bname` (`pageid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwf_fanpageads`
--

LOCK TABLES `ibwf_fanpageads` WRITE;
/*!40000 ALTER TABLE `ibwf_fanpageads` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwf_fanpageads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwf_fanpagecomments`
--

DROP TABLE IF EXISTS `ibwf_fanpagecomments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwf_fanpagecomments` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `statusid` int(100) NOT NULL DEFAULT '0',
  `uid` int(100) NOT NULL DEFAULT '0',
  `scomments` varchar(255) NOT NULL DEFAULT '',
  `stime` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwf_fanpagecomments`
--

LOCK TABLES `ibwf_fanpagecomments` WRITE;
/*!40000 ALTER TABLE `ibwf_fanpagecomments` DISABLE KEYS */;
INSERT INTO `ibwf_fanpagecomments` (`id`, `statusid`, `uid`, `scomments`, `stime`) VALUES (1,1,1,'nnoiiiii','1420557725'),(2,2,81,'Hm. System Ta Valoi','1420561108'),(3,1,81,'Test. . . . .','1420561170'),(4,2,1,'right......','1420561191');
/*!40000 ALTER TABLE `ibwf_fanpagecomments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwf_fanpagedislike`
--

DROP TABLE IF EXISTS `ibwf_fanpagedislike`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwf_fanpagedislike` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `shoutid` int(100) NOT NULL DEFAULT '0',
  `uid` int(100) NOT NULL DEFAULT '0',
  `lrate` char(1) NOT NULL,
  `ltime` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwf_fanpagedislike`
--

LOCK TABLES `ibwf_fanpagedislike` WRITE;
/*!40000 ALTER TABLE `ibwf_fanpagedislike` DISABLE KEYS */;
INSERT INTO `ibwf_fanpagedislike` (`id`, `shoutid`, `uid`, `lrate`, `ltime`) VALUES (1,0,1,'','1420559951');
/*!40000 ALTER TABLE `ibwf_fanpagedislike` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwf_fanpagelike`
--

DROP TABLE IF EXISTS `ibwf_fanpagelike`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwf_fanpagelike` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `shoutid` int(100) NOT NULL DEFAULT '0',
  `uid` int(100) NOT NULL DEFAULT '0',
  `lrate` char(1) NOT NULL,
  `ltime` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwf_fanpagelike`
--

LOCK TABLES `ibwf_fanpagelike` WRITE;
/*!40000 ALTER TABLE `ibwf_fanpagelike` DISABLE KEYS */;
INSERT INTO `ibwf_fanpagelike` (`id`, `shoutid`, `uid`, `lrate`, `ltime`) VALUES (1,0,1,'','1420559932'),(2,0,81,'','1420561063'),(3,0,151,'','1420576192'),(4,0,14,'','1420821641'),(5,0,18,'','1420947978'),(6,0,60,'','1421079322'),(7,0,84,'','1421606214');
/*!40000 ALTER TABLE `ibwf_fanpagelike` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwf_follow`
--

DROP TABLE IF EXISTS `ibwf_follow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwf_follow` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `followid` int(100) NOT NULL,
  `followdt` int(100) NOT NULL DEFAULT '0',
  `uid` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwf_follow`
--

LOCK TABLES `ibwf_follow` WRITE;
/*!40000 ALTER TABLE `ibwf_follow` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwf_follow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwf_profilemood`
--

DROP TABLE IF EXISTS `ibwf_profilemood`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwf_profilemood` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pmoodlink` varchar(150) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `pmoodlink` (`pmoodlink`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwf_profilemood`
--

LOCK TABLES `ibwf_profilemood` WRITE;
/*!40000 ALTER TABLE `ibwf_profilemood` DISABLE KEYS */;
INSERT INTO `ibwf_profilemood` (`id`, `pmoodlink`) VALUES (1,'');
/*!40000 ALTER TABLE `ibwf_profilemood` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwf_relatives`
--

DROP TABLE IF EXISTS `ibwf_relatives`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwf_relatives` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `uid` int(100) NOT NULL,
  `tid` int(100) NOT NULL,
  `agreed` int(1) NOT NULL,
  `reqdt` int(100) NOT NULL,
  `relation` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwf_relatives`
--

LOCK TABLES `ibwf_relatives` WRITE;
/*!40000 ALTER TABLE `ibwf_relatives` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwf_relatives` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_acc`
--

DROP TABLE IF EXISTS `ibwff_acc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_acc` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `gid` int(100) NOT NULL DEFAULT '0',
  `fid` int(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_acc`
--

LOCK TABLES `ibwff_acc` WRITE;
/*!40000 ALTER TABLE `ibwff_acc` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_acc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_announcements`
--

DROP TABLE IF EXISTS `ibwff_announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_announcements` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `antext` varchar(200) NOT NULL DEFAULT '',
  `clid` int(100) NOT NULL DEFAULT '0',
  `antime` int(100) NOT NULL DEFAULT '0',
  `name` text NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_announcements`
--

LOCK TABLES `ibwff_announcements` WRITE;
/*!40000 ALTER TABLE `ibwff_announcements` DISABLE KEYS */;
INSERT INTO `ibwff_announcements` (`id`, `antext`, `clid`, `antime`, `name`, `value`) VALUES (1,'',0,0,'',''),(2,'',0,0,'',''),(3,'',0,0,'',''),(4,'',0,0,'',''),(5,'testiiiiii',28,1420651870,'',''),(6,'uuuuuuu',28,1420651962,'',''),(7,'-salam--wc-[b][color=royalblue][u][code]  our club                                              [/u][/b][/color][/code]',45,1420683490,'',''),(8,'-salam--wc-[b][color=greenseayellow][u][code]  our club                                              [/u][/b][/color][/code]',45,1420683579,'',''),(9,'Ai club is best alltime,so,plz join my club.',2,1420803197,'',''),(10,'Wellcome To Our Club........',1,1421233338,'','');
/*!40000 ALTER TABLE `ibwff_announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_antifloods`
--

DROP TABLE IF EXISTS `ibwff_antifloods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_antifloods` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '',
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=65 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_antifloods`
--

LOCK TABLES `ibwff_antifloods` WRITE;
/*!40000 ALTER TABLE `ibwff_antifloods` DISABLE KEYS */;
INSERT INTO `ibwff_antifloods` (`id`, `name`, `value`) VALUES (1,'sesexp','36'),(2,'Fri 14 Dec 2012 - 12:22','108'),(3,'4ummsg',''),(4,'Counter','160910'),(5,'pmaf','10'),(6,'reg','0'),(7,'fview',''),(8,'lastbpm','2014-04-05'),(9,'sitename','Meetwap.Com'),(10,'siteage','0'),(11,'vldtn','0'),(32,'blogpoint','10'),(13,'chpluss',''),(33,'clpluss','13'),(16,'blpluss',''),(17,'themes','Styles.css'),(18,'popupaf','20'),(19,'regaf','15'),(20,'shoutaf','300'),(21,'cpoint','1'),(22,'spoint','2'),(23,'lpoint','3'),(24,'hpoint','4'),(25,'mkfpoint','5'),(26,'fcompoint','6'),(27,'litpoint','7'),(28,'litcompoint','8'),(29,'blogneedpoint','9'),(30,'blogcompoint','11'),(31,'fpluss','13'),(34,'nmpluss','50'),(35,'newclubpoint','50'),(36,'memberpoint','200'),(37,'junmemberpoint','500'),(38,'senmemberpoint','1000'),(39,'expellerpoint','4000'),(40,'mrsmispoint','7000'),(41,'pppoint','8000'),(42,'king','10000'),(43,'kok','10001'),(44,'knightpoint','2100'),(45,'expartpoint','6000'),(46,'fmvldtn','0'),(47,'litvldtn','0'),(48,'pollvldtn','0'),(49,'blogvldtn','0'),(50,'ntitle','2'),(51,'cntitle','13'),(52,'lnktitle','1'),(53,'cntmsg','gg jhnyuuju rftretfgre'),(54,'ntcmsg','na ns ns'),(55,'lnkmsg','bondhunir.net'),(56,'insmsg','fffggghhh'),(57,'institle','1'),(58,'pollc_uday','2'),(59,'poll_uday','1'),(60,'junvip_uday','5000'),(61,'senvip_uday','10000'),(62,'tpcval','0'),(63,'artval','0');
/*!40000 ALTER TABLE `ibwff_antifloods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_avatars`
--

DROP TABLE IF EXISTS `ibwff_avatars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_avatars` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `avlink` varchar(150) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `avlink` (`avlink`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_avatars`
--

LOCK TABLES `ibwff_avatars` WRITE;
/*!40000 ALTER TABLE `ibwff_avatars` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_avatars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_bcomments`
--

DROP TABLE IF EXISTS `ibwff_bcomments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_bcomments` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `blogid` int(100) NOT NULL DEFAULT '0',
  `uid` int(100) NOT NULL DEFAULT '0',
  `bcomments` varchar(255) NOT NULL DEFAULT '',
  `btime` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_bcomments`
--

LOCK TABLES `ibwff_bcomments` WRITE;
/*!40000 ALTER TABLE `ibwff_bcomments` DISABLE KEYS */;
INSERT INTO `ibwff_bcomments` (`id`, `blogid`, `uid`, `bcomments`, `btime`) VALUES (1,4,60,'kaw porlo na amar story ta..','1415969217'),(2,4,62,'ami to porlam khb valo laglo','1415969302'),(3,5,88,'nice creation ........... carry on  ......   -up-','1416115220'),(4,4,88,'yes.......... true love never fail......   @','1416115271'),(5,6,60,'kaw aktaw coments korlo na!','1416197457'),(6,6,19,'fine.carry on  . . . . . . . . .','1416197597'),(7,8,60,'nice-up-  valo laglo....','1416400548'),(8,9,60,'kaw blog dila poraw,o na comment, o kora na..','1416403903'),(9,8,102,'khub sundor likhco .................-up-','1416464681'),(10,10,2,'[b][color=fuchsia]bb code color code use korle valo hoto [/color][/b]','1416738643'),(11,13,60,'kaw aktaw comment kora na..','1418215197'),(12,10,60,'nice-up-.â€¦â€¦â€¦â€¦â€¦â€¦â€¦â€¦â€¦â€¦â€¦â€¦â€¦â€¦','1418278023'),(13,10,60,'valo laglo...toba touhid tik bolca bro...','1418278065'),(14,11,60,'kie ah sob...â€¦â€¦â€¦â€¦â€¦â€¦â€¦â€¦â€¦â€¦â€¦','1418278435'),(15,12,60,'ata kie prem khanie holoâ€¦â€¦â€¦â€¦â€¦â€¦â€¦â€¦â€¦â€¦â€¦','1418278558'),(16,14,9,'color use korla valo dakato dos..','1418392100'),(17,15,4,'Hmmm .... Khub Valo Laglo .............','1418488721'),(18,15,54,'Valo lagce .....','1418570292'),(19,16,9,'-nice-up- â€¦â€¦â€¦â€¦â€¦â€¦','1418660507'),(20,16,2,'bb code us krle besi valo hoto..','1419086739'),(21,16,98,'good....a.a.a.a.a.a.a.a.a.a.a.a.','1419123592'),(22,16,111,' . . . . . Nice Hoise . . . -up- . Valoi likso likte thako. . . .','1419218328'),(23,15,111,' . . . Valo laglo . Aro likte thako . .','1419218389'),(24,10,111,' . . . . . . Nice likso. .. . . . -up- . . . . . .','1419218442'),(25,8,111,' . . . . Khub valo likso. . . . . . , -up- . . . . .','1419218480'),(26,19,81,'[b]Kahini Da Valai Laglo:p[/b]','1419738751'),(27,18,81,'Test Bad, Wait Ami Ekta Blog e Lekhtaci-up-','1419738820'),(28,20,81,'Test . . . Test . . . Test . . .','1419738858'),(29,2,84,'Yes friend sob tik hoya jabe','1421599824');
/*!40000 ALTER TABLE `ibwff_bcomments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_blockedsite`
--

DROP TABLE IF EXISTS `ibwff_blockedsite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_blockedsite` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_blockedsite`
--

LOCK TABLES `ibwff_blockedsite` WRITE;
/*!40000 ALTER TABLE `ibwff_blockedsite` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_blockedsite` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_blogs`
--

DROP TABLE IF EXISTS `ibwff_blogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_blogs` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `bowner` int(100) NOT NULL DEFAULT '0',
  `bname` varchar(30) NOT NULL DEFAULT '',
  `btext` blob NOT NULL,
  `bgdate` int(100) NOT NULL DEFAULT '0',
  `clubid` int(110) NOT NULL DEFAULT '0',
  `validate` int(3) NOT NULL DEFAULT '0',
  `tags` varchar(1000) NOT NULL,
  `uday_cat` varchar(40) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `bname` (`bname`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_blogs`
--

LOCK TABLES `ibwff_blogs` WRITE;
/*!40000 ALTER TABLE `ibwff_blogs` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_blogs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_chat`
--

DROP TABLE IF EXISTS `ibwff_chat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_chat` (
  `id` int(99) NOT NULL AUTO_INCREMENT,
  `chatter` int(100) NOT NULL DEFAULT '0',
  `who` int(100) NOT NULL DEFAULT '0',
  `timesent` int(50) NOT NULL DEFAULT '0',
  `msgtext` varchar(255) NOT NULL DEFAULT '',
  `rid` int(99) NOT NULL DEFAULT '0',
  `exposed` char(1) NOT NULL DEFAULT '0',
  `cyberpowereragon` varchar(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5524 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_chat`
--

LOCK TABLES `ibwff_chat` WRITE;
/*!40000 ALTER TABLE `ibwff_chat` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_chat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_chonline`
--

DROP TABLE IF EXISTS `ibwff_chonline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_chonline` (
  `lton` int(15) NOT NULL DEFAULT '0',
  `uid` int(100) NOT NULL DEFAULT '0',
  `rid` int(99) NOT NULL DEFAULT '0',
  PRIMARY KEY (`lton`),
  UNIQUE KEY `username` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_chonline`
--

LOCK TABLES `ibwff_chonline` WRITE;
/*!40000 ALTER TABLE `ibwff_chonline` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_chonline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_clubmembers`
--

DROP TABLE IF EXISTS `ibwff_clubmembers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_clubmembers` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `uid` int(100) NOT NULL DEFAULT '0',
  `clid` int(100) NOT NULL DEFAULT '0',
  `accepted` char(1) NOT NULL DEFAULT '0',
  `points` int(100) NOT NULL DEFAULT '0',
  `joined` int(100) NOT NULL DEFAULT '0',
  `banned` int(1) NOT NULL DEFAULT '0',
  `onl` int(120) NOT NULL DEFAULT '0',
  `power` int(11) NOT NULL DEFAULT '0',
  `vip` int(11) NOT NULL DEFAULT '0',
  `subscriber` int(11) NOT NULL DEFAULT '0',
  `postbanned` int(11) NOT NULL DEFAULT '0',
  `chatbanned` int(11) NOT NULL DEFAULT '0',
  `pollbanned` int(11) NOT NULL DEFAULT '0',
  `pollcombanned` int(11) NOT NULL DEFAULT '0',
  `blogbanned` int(11) NOT NULL DEFAULT '0',
  `blogcombanned` int(11) NOT NULL DEFAULT '0',
  `shoutbanned` int(11) NOT NULL DEFAULT '0',
  `litbanned` int(11) NOT NULL DEFAULT '0',
  `litcombanned` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_clubmembers`
--

LOCK TABLES `ibwff_clubmembers` WRITE;
/*!40000 ALTER TABLE `ibwff_clubmembers` DISABLE KEYS */;
INSERT INTO `ibwff_clubmembers` (`id`, `uid`, `clid`, `accepted`, `points`, `joined`, `banned`, `onl`, `power`, `vip`, `subscriber`, `postbanned`, `chatbanned`, `pollbanned`, `pollcombanned`, `blogbanned`, `blogcombanned`, `shoutbanned`, `litbanned`, `litcombanned`) VALUES (1,1,1,'1',200,1422340568,0,1422341719,0,0,1,0,0,0,0,0,0,0,0,0);
/*!40000 ALTER TABLE `ibwff_clubmembers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_clubs`
--

DROP TABLE IF EXISTS `ibwff_clubs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_clubs` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `owner` int(100) NOT NULL DEFAULT '0',
  `name` varchar(30) NOT NULL DEFAULT '',
  `description` varchar(200) NOT NULL DEFAULT '',
  `rules` blob NOT NULL,
  `logo` varchar(200) NOT NULL DEFAULT '',
  `plusses` int(100) NOT NULL DEFAULT '0',
  `created` int(100) NOT NULL DEFAULT '0',
  `annc` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_clubs`
--

LOCK TABLES `ibwff_clubs` WRITE;
/*!40000 ALTER TABLE `ibwff_clubs` DISABLE KEYS */;
INSERT INTO `ibwff_clubs` (`id`, `owner`, `name`, `description`, `rules`, `logo`, `plusses`, `created`, `annc`) VALUES (1,1,'CoolDhaka Adult Community!','CoolDhaka Adult Community!','CoolDhaka Adult Community!','',0,1422340568,'');
/*!40000 ALTER TABLE `ibwff_clubs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_clubview`
--

DROP TABLE IF EXISTS `ibwff_clubview`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_clubview` (
  `id` mediumint(100) NOT NULL AUTO_INCREMENT,
  `whonick` char(20) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `lastview` char(20) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `ltime` int(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_clubview`
--

LOCK TABLES `ibwff_clubview` WRITE;
/*!40000 ALTER TABLE `ibwff_clubview` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_clubview` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_comblog`
--

DROP TABLE IF EXISTS `ibwff_comblog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_comblog` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `blogid` int(100) NOT NULL DEFAULT '0',
  `blogsigner` int(100) NOT NULL DEFAULT '0',
  `blogmsg` blob NOT NULL,
  `dtime` int(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_comblog`
--

LOCK TABLES `ibwff_comblog` WRITE;
/*!40000 ALTER TABLE `ibwff_comblog` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_comblog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_conf`
--

DROP TABLE IF EXISTS `ibwff_conf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_conf` (
  `id` int(120) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `text` varchar(1565) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `time` varchar(1465) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `timex` varchar(65) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `uid` int(40) NOT NULL DEFAULT '0',
  `prov` int(40) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_conf`
--

LOCK TABLES `ibwff_conf` WRITE;
/*!40000 ALTER TABLE `ibwff_conf` DISABLE KEYS */;
INSERT INTO `ibwff_conf` (`id`, `name`, `text`, `time`, `timex`, `uid`, `prov`) VALUES (1,'cj','','','',8,0);
/*!40000 ALTER TABLE `ibwff_conf` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_confuser`
--

DROP TABLE IF EXISTS `ibwff_confuser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_confuser` (
  `id` int(120) NOT NULL AUTO_INCREMENT,
  `uid` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `cnid` varchar(1565) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `time` varchar(1465) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `timex` varchar(65) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `vld` int(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_confuser`
--

LOCK TABLES `ibwff_confuser` WRITE;
/*!40000 ALTER TABLE `ibwff_confuser` DISABLE KEYS */;
INSERT INTO `ibwff_confuser` (`id`, `uid`, `cnid`, `time`, `timex`, `vld`) VALUES (1,'8','1','','',0);
/*!40000 ALTER TABLE `ibwff_confuser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_conmsg`
--

DROP TABLE IF EXISTS `ibwff_conmsg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_conmsg` (
  `id` int(120) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `text` varchar(1565) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `time` varchar(1465) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `timex` varchar(65) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `vld` int(4) NOT NULL DEFAULT '0',
  `cnid` int(40) NOT NULL DEFAULT '0',
  `uid` int(46) NOT NULL DEFAULT '0',
  `img` int(4) NOT NULL DEFAULT '0',
  `cat` varchar(1465) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `rate` varchar(65) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_conmsg`
--

LOCK TABLES `ibwff_conmsg` WRITE;
/*!40000 ALTER TABLE `ibwff_conmsg` DISABLE KEYS */;
INSERT INTO `ibwff_conmsg` (`id`, `name`, `text`, `time`, `timex`, `vld`, `cnid`, `uid`, `img`, `cat`, `rate`) VALUES (1,'','hy','','',0,1,8,0,'',''),(2,'','hlw.','','',0,1,8,0,'','');
/*!40000 ALTER TABLE `ibwff_conmsg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_coverpicdislike13`
--

DROP TABLE IF EXISTS `ibwff_coverpicdislike13`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_coverpicdislike13` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `uid` int(100) NOT NULL DEFAULT '0',
  `name` varchar(3000) NOT NULL DEFAULT '0',
  `time` int(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_coverpicdislike13`
--

LOCK TABLES `ibwff_coverpicdislike13` WRITE;
/*!40000 ALTER TABLE `ibwff_coverpicdislike13` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_coverpicdislike13` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_coverpiclike12`
--

DROP TABLE IF EXISTS `ibwff_coverpiclike12`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_coverpiclike12` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `uid` int(100) NOT NULL DEFAULT '0',
  `name` varchar(3000) NOT NULL,
  `time` int(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_coverpiclike12`
--

LOCK TABLES `ibwff_coverpiclike12` WRITE;
/*!40000 ALTER TABLE `ibwff_coverpiclike12` DISABLE KEYS */;
INSERT INTO `ibwff_coverpiclike12` (`id`, `uid`, `name`, `time`) VALUES (1,81,'168',1419770133),(2,81,'171',1419904086);
/*!40000 ALTER TABLE `ibwff_coverpiclike12` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_coverpicom11`
--

DROP TABLE IF EXISTS `ibwff_coverpicom11`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_coverpicom11` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `uid` int(100) NOT NULL DEFAULT '0',
  `name` varchar(3000) NOT NULL,
  `time` int(100) NOT NULL DEFAULT '0',
  `comments` varchar(500) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_coverpicom11`
--

LOCK TABLES `ibwff_coverpicom11` WRITE;
/*!40000 ALTER TABLE `ibwff_coverpicom11` DISABLE KEYS */;
INSERT INTO `ibwff_coverpicom11` (`id`, `uid`, `name`, `time`, `comments`) VALUES (1,47,'17',1416081201,'Hi'),(2,1,'168',1419861508,'confused -?-');
/*!40000 ALTER TABLE `ibwff_coverpicom11` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_coverpidislike13`
--

DROP TABLE IF EXISTS `ibwff_coverpidislike13`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_coverpidislike13` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `uid` int(100) NOT NULL DEFAULT '0',
  `pictureid` int(100) NOT NULL DEFAULT '0',
  `time` int(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_coverpidislike13`
--

LOCK TABLES `ibwff_coverpidislike13` WRITE;
/*!40000 ALTER TABLE `ibwff_coverpidislike13` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_coverpidislike13` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_coverpilike12`
--

DROP TABLE IF EXISTS `ibwff_coverpilike12`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_coverpilike12` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `uid` int(100) NOT NULL DEFAULT '0',
  `pictureid` int(100) NOT NULL DEFAULT '0',
  `time` int(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_coverpilike12`
--

LOCK TABLES `ibwff_coverpilike12` WRITE;
/*!40000 ALTER TABLE `ibwff_coverpilike12` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_coverpilike12` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_diary`
--

DROP TABLE IF EXISTS `ibwff_diary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_diary` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `bowner` int(100) NOT NULL DEFAULT '0',
  `bname` varchar(30) NOT NULL DEFAULT '',
  `btext` blob NOT NULL,
  `bgdate` int(100) NOT NULL DEFAULT '0',
  `uid` int(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `bname` (`bname`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_diary`
--

LOCK TABLES `ibwff_diary` WRITE;
/*!40000 ALTER TABLE `ibwff_diary` DISABLE KEYS */;
INSERT INTO `ibwff_diary` (`id`, `bowner`, `bname`, `btext`, `bgdate`, `uid`) VALUES (1,86,'127db','127db',1418711755,86);
/*!40000 ALTER TABLE `ibwff_diary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_dislike`
--

DROP TABLE IF EXISTS `ibwff_dislike`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_dislike` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `shoutid` int(100) NOT NULL DEFAULT '0',
  `uid` int(100) NOT NULL DEFAULT '0',
  `lrate` char(1) NOT NULL,
  `ltime` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_dislike`
--

LOCK TABLES `ibwff_dislike` WRITE;
/*!40000 ALTER TABLE `ibwff_dislike` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_dislike` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_events`
--

DROP TABLE IF EXISTS `ibwff_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_events` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `event` varchar(255) NOT NULL,
  `time` varchar(255) NOT NULL,
  `clubid` int(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3115 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_events`
--

LOCK TABLES `ibwff_events` WRITE;
/*!40000 ALTER TABLE `ibwff_events` DISABLE KEYS */;
INSERT INTO `ibwff_events` (`id`, `event`, `time`, `clubid`) VALUES (3113,'<b>xtrem</b> Change Her/Him Title Name','1422362032',0),(3114,'<b>xtrem</b> Create a new club','1422362168',0);
/*!40000 ALTER TABLE `ibwff_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_fcats`
--

DROP TABLE IF EXISTS `ibwff_fcats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_fcats` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '',
  `position` int(50) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_fcats`
--

LOCK TABLES `ibwff_fcats` WRITE;
/*!40000 ALTER TABLE `ibwff_fcats` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_fcats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_follow`
--

DROP TABLE IF EXISTS `ibwff_follow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_follow` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `followid` int(100) NOT NULL,
  `follower` int(100) NOT NULL,
  `time` varchar(100) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_follow`
--

LOCK TABLES `ibwff_follow` WRITE;
/*!40000 ALTER TABLE `ibwff_follow` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_follow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_forums`
--

DROP TABLE IF EXISTS `ibwff_forums`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_forums` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `position` int(11) NOT NULL DEFAULT '0',
  `cid` int(11) NOT NULL DEFAULT '0',
  `clubid` int(11) NOT NULL,
  `validate` int(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_forums`
--

LOCK TABLES `ibwff_forums` WRITE;
/*!40000 ALTER TABLE `ibwff_forums` DISABLE KEYS */;
INSERT INTO `ibwff_forums` (`id`, `name`, `position`, `cid`, `clubid`, `validate`) VALUES (1,'CoolDhaka Adult Community!',0,0,1,1);
/*!40000 ALTER TABLE `ibwff_forums` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_galcomments`
--

DROP TABLE IF EXISTS `ibwff_galcomments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_galcomments` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `gid` int(100) NOT NULL DEFAULT '0',
  `uid` int(100) NOT NULL DEFAULT '0',
  `galcomments` varchar(255) NOT NULL,
  `btime` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_galcomments`
--

LOCK TABLES `ibwff_galcomments` WRITE;
/*!40000 ALTER TABLE `ibwff_galcomments` DISABLE KEYS */;
INSERT INTO `ibwff_galcomments` (`id`, `gid`, `uid`, `galcomments`, `btime`) VALUES (1,18,47,'Plz help me','1415902151'),(2,18,47,'Plz help me','1415902191'),(3,17,47,'Hi','1415902557');
/*!40000 ALTER TABLE `ibwff_galcomments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_gallery`
--

DROP TABLE IF EXISTS `ibwff_gallery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_gallery` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `uid` int(100) NOT NULL,
  `sex` char(1) NOT NULL,
  `itemurl` varchar(255) NOT NULL,
  `gid` int(100) NOT NULL DEFAULT '0',
  `clubid` int(100) NOT NULL DEFAULT '0',
  `des` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_gallery`
--

LOCK TABLES `ibwff_gallery` WRITE;
/*!40000 ALTER TABLE `ibwff_gallery` DISABLE KEYS */;
INSERT INTO `ibwff_gallery` (`id`, `uid`, `sex`, `itemurl`, `gid`, `clubid`, `des`) VALUES (1,1,'M','../avatars/Ssssss.jpg',0,0,''),(2,13,'M','../avatars/2015-01-05-0011.jpg',0,0,''),(3,34,'M','../coverpics/my_sohag(8).jpg',0,0,''),(4,34,'M','../avatars/(Lipy).jpg',0,0,''),(5,34,'M','../coverpics/SAYEED TELECOM FACEBOOK (75).jpg',0,0,''),(6,41,'F','../avatars/#JINNAH#.jpg',0,0,'Shati_akter'),(7,5,'M','../avatars/alone.jpg',0,0,'.p.'),(8,1,'M','../coverpics/oooooooo.jpg',0,0,''),(9,61,'M','../avatars/Joku2-001.jpg',0,0,'Mee'),(10,61,'M','../avatars/Jik.jpg',0,0,'..'),(11,18,'M','../avatars/Getar.jpg',0,0,''),(12,18,'M','../coverpics/Bb.jpg',0,0,''),(13,9,'M','../avatars/Romeo-designstyle-friday-m.png',0,0,'Nathing'),(14,9,'M','../avatars/Romeo-designstyle-friday-m.jpg',0,0,'Nathing'),(15,9,'M','../avatars/picture-3-003.jpg',0,0,'Iam Simple man'),(16,48,'F','../coverpics/(4).JPG',0,0,'Ki'),(17,48,'F','../avatars/(5).JPG',0,0,'Ki'),(18,48,'F','../avatars/photo1206_002_001.jpg',0,0,'Ki'),(19,70,'M','../coverpics/8658850122_8b2db084d9_o.jpg',0,0,''),(20,70,'M','../avatars/oYYBAFRbMseATzsLAAAaYVmP_hU490.jpg',0,0,''),(21,70,'M','../avatars/ooYBAFP1lMmAGUq6AAAmfQPkV4Y451.jpg',0,0,''),(22,70,'M','../coverpics/o4YBAFSRY-GATuJOAAAu8CT4uhQ990.jpg',0,0,''),(23,70,'M','../avatars/Rony(2).jpg',0,0,''),(24,71,'F','../avatars/10897797_1529645470620782_8005062817464996702_n.jpeg',0,0,''),(25,71,'F','../coverpics/w.jpeg',0,0,''),(26,1,'M','../avatars/Ssssss.jpg',0,0,''),(27,84,'M','../avatars/mnmnmnmnmnmnmnhm.jpg',0,0,'Mustafij'),(28,84,'M','../coverpics/1011217_486725011435938_920124373_n.jpg',0,0,'M');
/*!40000 ALTER TABLE `ibwff_gallery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_games`
--

DROP TABLE IF EXISTS `ibwff_games`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_games` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `uid` int(100) NOT NULL DEFAULT '0',
  `gvar1` varchar(30) NOT NULL DEFAULT '',
  `gvar2` varchar(30) NOT NULL DEFAULT '',
  `gvar3` varchar(30) NOT NULL DEFAULT '',
  `gvar4` varchar(30) NOT NULL DEFAULT '',
  `gvar5` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_games`
--

LOCK TABLES `ibwff_games` WRITE;
/*!40000 ALTER TABLE `ibwff_games` DISABLE KEYS */;
INSERT INTO `ibwff_games` (`id`, `uid`, `gvar1`, `gvar2`, `gvar3`, `gvar4`, `gvar5`) VALUES (3,62,'1','48','','',''),(7,60,'8','19','','',''),(20,80,'8','4','','',''),(9,190,'8','36','','',''),(11,160,'8','43','','',''),(15,98,'8','88','','',''),(16,76,'8','5','','',''),(18,1,'8','74','','',''),(19,29,'8','93','','','');
/*!40000 ALTER TABLE `ibwff_games` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_gbook`
--

DROP TABLE IF EXISTS `ibwff_gbook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_gbook` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `gbowner` int(100) NOT NULL DEFAULT '0',
  `gbsigner` int(100) NOT NULL DEFAULT '0',
  `gbmsg` blob NOT NULL,
  `dtime` int(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_gbook`
--

LOCK TABLES `ibwff_gbook` WRITE;
/*!40000 ALTER TABLE `ibwff_gbook` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_gbook` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_giftpointers61`
--

DROP TABLE IF EXISTS `ibwff_giftpointers61`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_giftpointers61` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `gifterid` int(100) NOT NULL DEFAULT '0',
  `who` int(100) NOT NULL DEFAULT '0',
  `reason` varchar(500) NOT NULL DEFAULT '',
  `points` int(100) NOT NULL DEFAULT '0',
  `time` int(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_giftpointers61`
--

LOCK TABLES `ibwff_giftpointers61` WRITE;
/*!40000 ALTER TABLE `ibwff_giftpointers61` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_giftpointers61` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_givelove`
--

DROP TABLE IF EXISTS `ibwff_givelove`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_givelove` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `uid` int(100) NOT NULL DEFAULT '0',
  `who` int(100) NOT NULL DEFAULT '0',
  `date` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_givelove`
--

LOCK TABLES `ibwff_givelove` WRITE;
/*!40000 ALTER TABLE `ibwff_givelove` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_givelove` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_hangman`
--

DROP TABLE IF EXISTS `ibwff_hangman`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_hangman` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `text` varchar(30) NOT NULL DEFAULT '',
  `dscr` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_hangman`
--

LOCK TABLES `ibwff_hangman` WRITE;
/*!40000 ALTER TABLE `ibwff_hangman` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_hangman` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_ignore`
--

DROP TABLE IF EXISTS `ibwff_ignore`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_ignore` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` int(99) NOT NULL DEFAULT '0',
  `target` int(99) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_ignore`
--

LOCK TABLES `ibwff_ignore` WRITE;
/*!40000 ALTER TABLE `ibwff_ignore` DISABLE KEYS */;
INSERT INTO `ibwff_ignore` (`id`, `name`, `target`) VALUES (2,1,27),(3,152,195);
/*!40000 ALTER TABLE `ibwff_ignore` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_lastview`
--

DROP TABLE IF EXISTS `ibwff_lastview`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_lastview` (
  `id` mediumint(100) NOT NULL AUTO_INCREMENT,
  `whonick` char(20) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `lastview` char(20) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `ltime` int(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_lastview`
--

LOCK TABLES `ibwff_lastview` WRITE;
/*!40000 ALTER TABLE `ibwff_lastview` DISABLE KEYS */;
INSERT INTO `ibwff_lastview` (`id`, `whonick`, `lastview`, `ltime`) VALUES (1,'chatgirl','admin',1422340005),(2,'Chatgirl','xtrem',1422343814),(3,'admin2','aronno',1422344475),(4,'xtrem','aronno',1422344491),(5,'aronno','xtrem',1422344599),(6,'xtrem','aronno',1422345386),(7,'xtrem','tareqsir',1422596606),(8,'tareqsir','xtrem',1422596685),(9,'xtrem','tareqsir',1422596737),(10,'tareqsir','xtrem',1422596764),(11,'tareqsir','xtrem',1422596768),(12,'tareqsir','xtrem',1422596805),(13,'tareqsir','xtrem',1422596812),(14,'tareqsir','xtrem',1422596950),(15,'tareqsir','xtrem',1422596956),(16,'aronno','tareqsir',1422597017),(17,'tareqsir','xtrem',1422597039),(18,'tareqsir','xtrem',1422597263),(19,'tareqsir','xtrem',1422597303),(20,'aronno','xtrem',1422597414),(21,'tareqsir','xtrem',1422597427),(22,'tareqsir','xtrem',1422597527);
/*!40000 ALTER TABLE `ibwff_lastview` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_letcats`
--

DROP TABLE IF EXISTS `ibwff_letcats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_letcats` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '',
  `position` int(50) NOT NULL DEFAULT '0',
  `uday_vld` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_letcats`
--

LOCK TABLES `ibwff_letcats` WRITE;
/*!40000 ALTER TABLE `ibwff_letcats` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_letcats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_like`
--

DROP TABLE IF EXISTS `ibwff_like`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_like` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `shoutid` int(100) NOT NULL DEFAULT '0',
  `uid` int(100) NOT NULL DEFAULT '0',
  `lrate` char(1) NOT NULL,
  `ltime` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_like`
--

LOCK TABLES `ibwff_like` WRITE;
/*!40000 ALTER TABLE `ibwff_like` DISABLE KEYS */;
INSERT INTO `ibwff_like` (`id`, `shoutid`, `uid`, `lrate`, `ltime`) VALUES (1,88,4,'','');
/*!40000 ALTER TABLE `ibwff_like` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_likemember66`
--

DROP TABLE IF EXISTS `ibwff_likemember66`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_likemember66` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `likerid` int(100) NOT NULL DEFAULT '0',
  `likedid` int(100) NOT NULL DEFAULT '0',
  `likesdt` varchar(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_likemember66`
--

LOCK TABLES `ibwff_likemember66` WRITE;
/*!40000 ALTER TABLE `ibwff_likemember66` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_likemember66` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_literatures`
--

DROP TABLE IF EXISTS `ibwff_literatures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_literatures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `position` int(11) NOT NULL DEFAULT '0',
  `cid` int(11) NOT NULL DEFAULT '0',
  `clubid` int(11) NOT NULL,
  `validate` int(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_literatures`
--

LOCK TABLES `ibwff_literatures` WRITE;
/*!40000 ALTER TABLE `ibwff_literatures` DISABLE KEYS */;
INSERT INTO `ibwff_literatures` (`id`, `name`, `position`, `cid`, `clubid`, `validate`) VALUES (1,'CoolDhaka Adult Community!',0,0,1,1);
/*!40000 ALTER TABLE `ibwff_literatures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_mindstatus11`
--

DROP TABLE IF EXISTS `ibwff_mindstatus11`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_mindstatus11` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `uid` int(100) NOT NULL DEFAULT '0',
  `status` varchar(2000) NOT NULL DEFAULT '',
  `time` int(100) NOT NULL DEFAULT '0',
  `lastupdate` int(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_mindstatus11`
--

LOCK TABLES `ibwff_mindstatus11` WRITE;
/*!40000 ALTER TABLE `ibwff_mindstatus11` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_mindstatus11` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_miss`
--

DROP TABLE IF EXISTS `ibwff_miss`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_miss` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `uid` int(100) NOT NULL DEFAULT '0',
  `who` int(100) NOT NULL DEFAULT '0',
  `date` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_miss`
--

LOCK TABLES `ibwff_miss` WRITE;
/*!40000 ALTER TABLE `ibwff_miss` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_miss` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_mlog`
--

DROP TABLE IF EXISTS `ibwff_mlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_mlog` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `action` varchar(10) NOT NULL DEFAULT '',
  `details` blob NOT NULL,
  `actdt` int(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1346 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_mlog`
--

LOCK TABLES `ibwff_mlog` WRITE;
/*!40000 ALTER TABLE `ibwff_mlog` DISABLE KEYS */;
INSERT INTO `ibwff_mlog` (`id`, `action`, `details`, `actdt`) VALUES (1342,'nick','<b>xtrem</b> Changed His Display Name',0),(1343,'Reward Pen','<b>xtrem</b> Updated <b>aronno</b> points from <b>0</b> to <b>1500</b>',1422344740),(1344,'Certified','<b>tareqsir</b> Make Certified tareqsir',1422596765),(1345,'Reward Pen','<b>xtrem</b> Updated <b>tareqsir</b> points from <b>0</b> to <b>16000</b>',1422596856);
/*!40000 ALTER TABLE `ibwff_mlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_mms`
--

DROP TABLE IF EXISTS `ibwff_mms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_mms` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `byuid` int(100) NOT NULL DEFAULT '0',
  `touid` int(100) NOT NULL DEFAULT '0',
  `unread` int(100) NOT NULL DEFAULT '0',
  `pmtext` varchar(1000) NOT NULL DEFAULT '',
  `filename` varchar(500) NOT NULL DEFAULT '',
  `size` varchar(100) NOT NULL DEFAULT '',
  `extension` varchar(100) NOT NULL DEFAULT '',
  `origname` varchar(100) NOT NULL DEFAULT '',
  `timesent` int(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_mms`
--

LOCK TABLES `ibwff_mms` WRITE;
/*!40000 ALTER TABLE `ibwff_mms` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_mms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_modr`
--

DROP TABLE IF EXISTS `ibwff_modr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_modr` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` int(100) NOT NULL DEFAULT '0',
  `forum` varchar(99) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_modr`
--

LOCK TABLES `ibwff_modr` WRITE;
/*!40000 ALTER TABLE `ibwff_modr` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_modr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_moods`
--

DROP TABLE IF EXISTS `ibwff_moods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_moods` (
  `id` int(99) NOT NULL AUTO_INCREMENT,
  `text` varchar(10) NOT NULL DEFAULT '',
  `img` varchar(100) NOT NULL DEFAULT '',
  `dscr` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_moods`
--

LOCK TABLES `ibwff_moods` WRITE;
/*!40000 ALTER TABLE `ibwff_moods` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_moods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_mpot`
--

DROP TABLE IF EXISTS `ibwff_mpot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_mpot` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `ddt` varchar(20) NOT NULL DEFAULT '',
  `dtm` varchar(20) NOT NULL DEFAULT '',
  `ppl` int(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=68 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_mpot`
--

LOCK TABLES `ibwff_mpot` WRITE;
/*!40000 ALTER TABLE `ibwff_mpot` DISABLE KEYS */;
INSERT INTO `ibwff_mpot` (`id`, `ddt`, `dtm`, `ppl`) VALUES (1,'09 08 14','06:05:26',2),(2,'10 11 14','14:47:37',9),(3,'11 11 14','11:49:48',12),(4,'12 11 14','14:37:44',14),(5,'13 11 14','18:19:47',14),(6,'14 11 14','17:13:24',17),(7,'15 11 14','17:19:34',21),(8,'16 11 14','10:56:17',24),(9,'17 11 14','15:30:13',12),(10,'18 11 14','12:25:25',15),(11,'19 11 14','16:33:41',15),(12,'20 11 14','13:38:32',14),(13,'21 11 14','06:09:13',16),(14,'22 11 14','09:12:41',14),(15,'23 11 14','16:07:13',12),(16,'24 11 14','15:59:38',13),(17,'25 11 14','08:16:00',7),(18,'26 11 14','14:24:52',11),(19,'27 11 14','16:31:01',7),(20,'28 11 14','17:49:21',4),(21,'29 11 14','16:23:38',4),(22,'30 11 14','03:20:42',2),(23,'10 12 14','15:38:11',13),(24,'11 12 14','11:24:42',8),(25,'12 12 14','13:47:06',15),(26,'13 12 14','15:31:38',11),(27,'14 12 14','16:02:46',18),(28,'15 12 14','09:14:07',12),(29,'16 12 14','08:59:05',14),(30,'17 12 14','16:10:59',10),(31,'18 12 14','16:37:45',9),(32,'19 12 14','13:57:27',9),(33,'20 12 14','18:00:47',10),(34,'21 12 14','17:30:26',15),(35,'22 12 14','07:46:04',15),(36,'23 12 14','16:23:12',14),(37,'24 12 14','18:13:11',10),(38,'25 12 14','04:07:14',9),(39,'26 12 14','16:23:15',19),(40,'27 12 14','18:35:14',14),(41,'28 12 14','14:35:54',13),(42,'29 12 14','17:43:46',12),(43,'30 12 14','13:45:40',11),(44,'31 12 14','14:51:26',7),(45,'01 01 15','14:33:49',17),(46,'02 01 15','14:44:46',22),(47,'03 01 15','14:31:00',19),(48,'04 01 15','16:47:53',13),(49,'05 01 15','11:52:55',12),(50,'06 01 15','08:11:41',14),(51,'07 01 15','15:18:20',13),(52,'08 01 15','14:33:16',13),(53,'09 01 15','02:46:31',10),(54,'10 01 15','15:51:15',12),(55,'11 01 15','11:17:26',11),(56,'12 01 15','17:24:52',9),(57,'13 01 15','04:16:04',9),(58,'14 01 15','05:55:11',7),(59,'15 01 15','16:07:48',11),(60,'16 01 15','06:33:48',11),(61,'17 01 15','16:28:28',9),(62,'18 01 15','13:40:27',9),(63,'19 01 15','12:29:58',10),(64,'27 01 15','10:25:06',3),(65,'28 01 15','16:23:39',2),(66,'29 01 15','01:44:26',2),(67,'30 01 15','05:58:47',3);
/*!40000 ALTER TABLE `ibwff_mpot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_nickblock88`
--

DROP TABLE IF EXISTS `ibwff_nickblock88`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_nickblock88` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `nick` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_nickblock88`
--

LOCK TABLES `ibwff_nickblock88` WRITE;
/*!40000 ALTER TABLE `ibwff_nickblock88` DISABLE KEYS */;
INSERT INTO `ibwff_nickblock88` (`id`, `nick`) VALUES (1,'sex'),(2,'sexy'),(3,'xxx'),(4,'tor'),(5,'tor baap'),(6,'hada'),(7,'friendsdiary');
/*!40000 ALTER TABLE `ibwff_nickblock88` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_nicks`
--

DROP TABLE IF EXISTS `ibwff_nicks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_nicks` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '',
  `nicklvl` char(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_nicks`
--

LOCK TABLES `ibwff_nicks` WRITE;
/*!40000 ALTER TABLE `ibwff_nicks` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_nicks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_notificare`
--

DROP TABLE IF EXISTS `ibwff_notificare`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_notificare` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `text` blob NOT NULL,
  `byuid` int(100) NOT NULL DEFAULT '0',
  `touid` int(100) NOT NULL DEFAULT '0',
  `unread` char(1) NOT NULL DEFAULT '1',
  `timesent` int(100) NOT NULL DEFAULT '0',
  `starred` char(1) NOT NULL DEFAULT '0',
  `reported` char(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_notificare`
--

LOCK TABLES `ibwff_notificare` WRITE;
/*!40000 ALTER TABLE `ibwff_notificare` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_notificare` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_notifications`
--

DROP TABLE IF EXISTS `ibwff_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_notifications` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `text` blob NOT NULL,
  `byuid` int(100) NOT NULL DEFAULT '0',
  `touid` int(100) NOT NULL DEFAULT '0',
  `unread` char(1) NOT NULL DEFAULT '1',
  `timesent` varchar(20) NOT NULL,
  `sub` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17268 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_notifications`
--

LOCK TABLES `ibwff_notifications` WRITE;
/*!40000 ALTER TABLE `ibwff_notifications` DISABLE KEYS */;
INSERT INTO `ibwff_notifications` (`id`, `text`, `byuid`, `touid`, `unread`, `timesent`, `sub`) VALUES (17241,'[b]Special CID Report:[/b][br/]All Notifications Has Been Cleared By [user=1][b]xtrem[/user][/b]',0,1,'0','1422337948',0),(17242,'[b]Special CID Report:[/b][br/]All ModLogs Cleared By [user=1][b]xtrem[/user][/b]',0,1,'0','1422337969',0),(17243,'[b]Special CID Report:[/b][br/]All Inbox Messages (full cleared) Has Been Deleted By [user=1][b]xtrem[/user][/b]',0,1,'0','1422337983',0),(17244,'[b]Special CID Report:[/b][br/]Shouts Older Than 5 Days Ago Cleared By [user=1][b]xtrem[/user][/b]',0,1,'0','1422337996',0),(17245,' Hello /reader. Wellcome to our big happy family![br/][topic=1]Please check out the instructions for any kind of help specially written for new members![/topic][br/]If you have any question or comments about the site feel free to massage any of the staff member from the online list.[br/][b]New Members Offer[/b][br/]-1-Get 300 Point Bonus[br/][br/]\\nYou can gain points by posting in forums,Literatures,blogs,polls,contests which will unlock other parts of this great site! -flower-[small][i]p.s: this is an automated Massage[/i][/small]',0,1,'0','1422339458',1),(17246,' Hello /reader. Wellcome to our big happy family![br/][topic=1]Please check out the instructions for any kind of help specially written for new members![/topic][br/]If you have any question or comments about the site feel free to massage any of the staff member from the online list.[br/][b]New Members Offer[/b][br/]-1-Get 300 Point Bonus[br/][br/]\\nYou can gain points by posting in forums,Literatures,blogs,polls,contests which will unlock other parts of this great site! -flower-[small][i]p.s: this is an automated Massage[/i][/small]',0,2,'1','1422339516',1),(17247,' Hello /reader. Wellcome to our big happy family![br/][topic=1]Please check out the instructions for any kind of help specially written for new members![/topic][br/]If you have any question or comments about the site feel free to massage any of the staff member from the online list.[br/][b]New Members Offer[/b][br/]-1-Get 300 Point Bonus[br/][br/]\\nYou can gain points by posting in forums,Literatures,blogs,polls,contests which will unlock other parts of this great site! -flower-[small][i]p.s: this is an automated Massage[/i][/small]',0,3,'1','1422339608',1),(17248,'[b]Special CID Report:[/b][br/][user=1][b]admin[/b][/user] power updated by [user=1][b]admin[/user][/b]',0,1,'0','1422339812',0),(17249,'Your account balance updated from 0 to 1500',0,1,'0','1422339908',1),(17250,'Your account balance updated from 1500 to 3000',0,1,'0','1422339910',1),(17251,'',0,3,'1','1422340245',1),(17252,'',0,3,'1','1422340245',1),(17253,'',0,1,'0','1422340334',1),(17254,'',0,1,'0','1422340334',1),(17255,' Hello /reader. Wellcome to our big happy family![br/][topic=1]Please check out the instructions for any kind of help specially written for new members![/topic][br/]If you have any question or comments about the site feel free to massage any of the staff member from the online list.[br/][b]New Members Offer[/b][br/]-1-Get 300 Point Bonus[br/][br/]\\nYou can gain points by posting in forums,Literatures,blogs,polls,contests which will unlock other parts of this great site! -flower-[small][i]p.s: this is an automated Massage[/i][/small]',0,4,'0','1422344398',1),(17256,'Your Shout [shoutlik=88]-wc-our new adut site[/shoutlik] Has Been Agreed By aronno',0,1,'0','1422344736',0),(17257,'[b]Congratulayion! Your Points Updated From 0 To 1500 [/b][br/] For Stay whit us',0,4,'0','1422344740',0),(17258,'[b]Special CID Report:[/b][br/][user=4][b]aronno[/b][/user] Points Updated From 0 To 1500 By [user=1][b]xtrem[/user][/b] for Stay whit us ',0,1,'0','1422344740',0),(17259,' Hello /reader. Wellcome to our big happy family![br/][topic=1]Please check out the instructions for any kind of help specially written for new members![/topic][br/]If you have any question or comments about the site feel free to massage any of the staff member from the online list.[br/][b]New Members Offer[/b][br/]-1-Get 300 Point Bonus[br/][br/]\\nYou can gain points by posting in forums,Literatures,blogs,polls,contests which will unlock other parts of this great site! -flower-[small][i]p.s: this is an automated Massage[/i][/small]',0,5,'0','1422596567',1),(17260,'',0,5,'0','1422596704',1),(17261,'[b]Special CID Report:[/b][br/][user=5][b]tareqsir[/b][/user] power updated by [user=1][b]xtrem[/user][/b]',0,1,'0','1422596728',0),(17262,'[b]Congratulation![/b][br/][color=purple]Your Id Is Now Verified From Meetwap Your Id Cant Auto Banned-up-[/color]',0,5,'0','1422596765',0),(17263,'[b]Special CID Report:[/b][br/][user=5][b][/b][/user]Now Verified By [user=5][b]tareqsir[/user][/b]',0,1,'0','1422596765',0),(17264,'[b]Congratulayion! Your Points Updated From 0 To 16000 [/b][br/] For Testing.....',0,5,'0','1422596856',0),(17265,'[b]Special CID Report:[/b][br/][user=5][b]tareqsir[/b][/user] Points Updated From 0 To 16000 By [user=1][b]xtrem[/user][/b] for Testing..... ',0,1,'0','1422596856',0),(17266,'',0,5,'1','1422597441',1),(17267,'[b]Special CID Report:[/b][br/][user=5][b]tareqsir[/b][/user] power updated by [user=1][b]xtrem[/user][/b]',0,1,'1','1422597514',0);
/*!40000 ALTER TABLE `ibwff_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_online`
--

DROP TABLE IF EXISTS `ibwff_online`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_online` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `userid` int(100) NOT NULL DEFAULT '0',
  `actvtime` int(100) NOT NULL DEFAULT '0',
  `place` varchar(50) NOT NULL DEFAULT '',
  `placedet` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `userid` (`userid`)
) ENGINE=MyISAM AUTO_INCREMENT=4748 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_online`
--

LOCK TABLES `ibwff_online` WRITE;
/*!40000 ALTER TABLE `ibwff_online` DISABLE KEYS */;
INSERT INTO `ibwff_online` (`id`, `userid`, `actvtime`, `place`, `placedet`) VALUES (4747,3,1422614206,'Loggin In',''),(4746,5,1422614231,'Logging Out','main.php?action=logout');
/*!40000 ALTER TABLE `ibwff_online` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_penalties`
--

DROP TABLE IF EXISTS `ibwff_penalties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_penalties` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(100) NOT NULL DEFAULT '0',
  `penalty` char(1) NOT NULL DEFAULT '0',
  `exid` int(100) NOT NULL DEFAULT '0',
  `timeto` int(100) NOT NULL DEFAULT '0',
  `pnreas` varchar(100) NOT NULL DEFAULT '',
  `ipadd` varchar(30) NOT NULL DEFAULT '',
  `browserm` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=44 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_penalties`
--

LOCK TABLES `ibwff_penalties` WRITE;
/*!40000 ALTER TABLE `ibwff_penalties` DISABLE KEYS */;
INSERT INTO `ibwff_penalties` (`id`, `uid`, `penalty`, `exid`, `timeto`, `pnreas`, `ipadd`, `browserm`) VALUES (42,69,'1',9,1507683655,'My Multy Id Ban By Ac3id_Boy','',''),(31,22,'1',1,2147483647,'come with good nick','',''),(32,31,'2',1,2147483647,'come with good name','',''),(19,158,'2',152,2147483647,'Fuck id','',''),(20,153,'1',1,2147483647,'oti chalak er golay dorii thake','',''),(5,80,'0',1,2147483647,'','',''),(35,44,'1',13,1996959305,'Fake id','',''),(24,73,'0',1,2147483647,'','',''),(7,114,'1',4,1819091698,'Fake! Naeem Vai ... New ID Khule Log In Koro .....','',''),(43,16,'1',1,2147483647,'get out','',''),(21,168,'2',152,2147483647,'33333beiman0atogulaid','',''),(23,178,'2',1,2147483647,'tor bap ami ma g ir pola','',''),(29,213,'2',152,2147483647,'Kottar bacca','',''),(30,8,'1',1,2147483647,'fake id ','',''),(28,208,'1',152,2147483647,'Bandorer bacca r ki id khulbe.tore samne paile cabaiya khamu','',''),(34,30,'0',16,1452459652,'','',''),(36,41,'1',1,2147483647,'Get out fake id of khan','',''),(41,39,'1',9,1452184342,'We Did NoT Like Spam Get Out Ban By mr_ac3id_boy','','');
/*!40000 ALTER TABLE `ibwff_penalties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_pfpicdislike63`
--

DROP TABLE IF EXISTS `ibwff_pfpicdislike63`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_pfpicdislike63` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `uid` int(100) NOT NULL DEFAULT '0',
  `name` varchar(3000) NOT NULL DEFAULT '0',
  `time` int(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_pfpicdislike63`
--

LOCK TABLES `ibwff_pfpicdislike63` WRITE;
/*!40000 ALTER TABLE `ibwff_pfpicdislike63` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_pfpicdislike63` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_pfpiclike62`
--

DROP TABLE IF EXISTS `ibwff_pfpiclike62`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_pfpiclike62` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `uid` int(100) NOT NULL DEFAULT '0',
  `name` varchar(3000) NOT NULL DEFAULT '0',
  `time` int(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_pfpiclike62`
--

LOCK TABLES `ibwff_pfpiclike62` WRITE;
/*!40000 ALTER TABLE `ibwff_pfpiclike62` DISABLE KEYS */;
INSERT INTO `ibwff_pfpiclike62` (`id`, `uid`, `name`, `time`) VALUES (1,47,'18',1415910979),(2,12,'81',1418354129),(3,4,'77',1418483104),(6,29,'108',1418578284),(5,4,'104',1418498053),(7,81,'147',1419770161),(8,81,'172',1419864689),(9,2,'172',1419864928),(10,81,'173',1419904099),(11,153,'179',1420254463),(12,180,'147',1420725929);
/*!40000 ALTER TABLE `ibwff_pfpiclike62` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_pfpicom61`
--

DROP TABLE IF EXISTS `ibwff_pfpicom61`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_pfpicom61` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `uid` int(100) NOT NULL DEFAULT '0',
  `name` varchar(3000) NOT NULL,
  `time` int(100) NOT NULL DEFAULT '0',
  `comments` varchar(500) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_pfpicom61`
--

LOCK TABLES `ibwff_pfpicom61` WRITE;
/*!40000 ALTER TABLE `ibwff_pfpicom61` DISABLE KEYS */;
INSERT INTO `ibwff_pfpicom61` (`id`, `uid`, `name`, `time`, `comments`) VALUES (1,47,'18',1415857432,'Hi i am here mahi'),(2,47,'18',1415857771,'Mahi join me'),(3,47,'18',1415911085,'I want to chat'),(4,62,'30',1416040239,'good'),(5,109,'112',1419096345,'awesome lagche tomake'),(6,1,'174',1419877550,'joss'),(7,180,'147',1420725954,'dosto onek nice pic ta,');
/*!40000 ALTER TABLE `ibwff_pfpicom61` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_pgallery`
--

DROP TABLE IF EXISTS `ibwff_pgallery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_pgallery` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `uid` int(100) NOT NULL DEFAULT '0',
  `tid` int(100) NOT NULL DEFAULT '0',
  `agreed` char(1) NOT NULL DEFAULT '0',
  `reqdt` int(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_pgallery`
--

LOCK TABLES `ibwff_pgallery` WRITE;
/*!40000 ALTER TABLE `ibwff_pgallery` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_pgallery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_pmoods`
--

DROP TABLE IF EXISTS `ibwff_pmoods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_pmoods` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `scode` varchar(15) NOT NULL DEFAULT '',
  `pmoodlink` varchar(200) NOT NULL DEFAULT '',
  `hidden` char(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `scode` (`scode`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_pmoods`
--

LOCK TABLES `ibwff_pmoods` WRITE;
/*!40000 ALTER TABLE `ibwff_pmoods` DISABLE KEYS */;
INSERT INTO `ibwff_pmoods` (`id`, `scode`, `pmoodlink`, `hidden`) VALUES (1,'','p.gif','0');
/*!40000 ALTER TABLE `ibwff_pmoods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_polls`
--

DROP TABLE IF EXISTS `ibwff_polls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_polls` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `uid` int(100) NOT NULL DEFAULT '0',
  `pqst` varchar(255) NOT NULL DEFAULT '',
  `opt1` varchar(100) NOT NULL DEFAULT '',
  `opt2` varchar(100) NOT NULL DEFAULT '',
  `opt3` varchar(100) NOT NULL DEFAULT '',
  `opt4` varchar(100) NOT NULL DEFAULT '',
  `opt5` varchar(100) NOT NULL DEFAULT '',
  `pdt` int(100) NOT NULL DEFAULT '0',
  `clubid` int(30) NOT NULL DEFAULT '0',
  `validate` int(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_polls`
--

LOCK TABLES `ibwff_polls` WRITE;
/*!40000 ALTER TABLE `ibwff_polls` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_polls` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_posts`
--

DROP TABLE IF EXISTS `ibwff_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` text NOT NULL,
  `tid` int(11) NOT NULL DEFAULT '0',
  `uid` int(11) NOT NULL DEFAULT '0',
  `dtpost` varchar(100) NOT NULL DEFAULT '0',
  `reported` char(1) NOT NULL DEFAULT '0',
  `quote` int(100) NOT NULL DEFAULT '0',
  `fahimhide` varchar(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_posts`
--

LOCK TABLES `ibwff_posts` WRITE;
/*!40000 ALTER TABLE `ibwff_posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_pp_gbook`
--

DROP TABLE IF EXISTS `ibwff_pp_gbook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_pp_gbook` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `uid` int(100) NOT NULL DEFAULT '0',
  `sname` varchar(15) NOT NULL DEFAULT '',
  `semail` varchar(100) NOT NULL DEFAULT '',
  `stext` text NOT NULL,
  `sdate` int(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_pp_gbook`
--

LOCK TABLES `ibwff_pp_gbook` WRITE;
/*!40000 ALTER TABLE `ibwff_pp_gbook` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_pp_gbook` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_pp_pres`
--

DROP TABLE IF EXISTS `ibwff_pp_pres`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_pp_pres` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `pid` int(100) NOT NULL DEFAULT '0',
  `ans` int(5) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_pp_pres`
--

LOCK TABLES `ibwff_pp_pres` WRITE;
/*!40000 ALTER TABLE `ibwff_pp_pres` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_pp_pres` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_prate`
--

DROP TABLE IF EXISTS `ibwff_prate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_prate` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `gid` int(100) NOT NULL DEFAULT '0',
  `uid` int(100) NOT NULL DEFAULT '0',
  `prate` char(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_prate`
--

LOCK TABLES `ibwff_prate` WRITE;
/*!40000 ALTER TABLE `ibwff_prate` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_prate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_presults`
--

DROP TABLE IF EXISTS `ibwff_presults`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_presults` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `pid` int(100) NOT NULL DEFAULT '0',
  `uid` int(100) NOT NULL DEFAULT '0',
  `ans` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_presults`
--

LOCK TABLES `ibwff_presults` WRITE;
/*!40000 ALTER TABLE `ibwff_presults` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_presults` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_private`
--

DROP TABLE IF EXISTS `ibwff_private`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_private` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `text` blob NOT NULL,
  `byuid` int(100) NOT NULL DEFAULT '0',
  `touid` int(100) NOT NULL DEFAULT '0',
  `unread` char(1) NOT NULL DEFAULT '1',
  `timesent` int(100) NOT NULL DEFAULT '0',
  `starred` char(1) NOT NULL DEFAULT '0',
  `reported` char(1) NOT NULL DEFAULT '0',
  `folderid` int(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20299 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_private`
--

LOCK TABLES `ibwff_private` WRITE;
/*!40000 ALTER TABLE `ibwff_private` DISABLE KEYS */;
INSERT INTO `ibwff_private` (`id`, `text`, `byuid`, `touid`, `unread`, `timesent`, `starred`, `reported`, `folderid`) VALUES (20292,'Hello /reader. Wellcome to our big happy family![br/][topic=1]Please check out the instructions for any kind of help specially written for new members![/topic][br/]If you have any question or comments about the site feel free to massage any of the staff member from the online list.[br/][b]New Members Offer[/b][br/]-1-Get 300 Point Bonus[br/]\nYou can gain points by posting in forums,Literatures,blogs,polls,contests which will unlock other parts of this great site! -flower-[small][i]p.s: this is an automated Massage[/i][/small]',3,1,'0',1422339458,'0','0',0),(20293,'Hello /reader. Wellcome to our big happy family![br/][topic=1]Please check out the instructions for any kind of help specially written for new members![/topic][br/]If you have any question or comments about the site feel free to massage any of the staff member from the online list.[br/][b]New Members Offer[/b][br/]-1-Get 300 Point Bonus[br/]\nYou can gain points by posting in forums,Literatures,blogs,polls,contests which will unlock other parts of this great site! -flower-[small][i]p.s: this is an automated Massage[/i][/small]',3,2,'1',1422339516,'0','0',0),(20294,'Hello /reader. Wellcome to our big happy family![br/][topic=1]Please check out the instructions for any kind of help specially written for new members![/topic][br/]If you have any question or comments about the site feel free to massage any of the staff member from the online list.[br/][b]New Members Offer[/b][br/]-1-Get 300 Point Bonus[br/]\nYou can gain points by posting in forums,Literatures,blogs,polls,contests which will unlock other parts of this great site! -flower-[small][i]p.s: this is an automated Massage[/i][/small]',3,3,'1',1422339608,'0','0',0),(20295,'Hello /reader. Wellcome to our big happy family![br/][topic=1]Please check out the instructions for any kind of help specially written for new members![/topic][br/]If you have any question or comments about the site feel free to massage any of the staff member from the online list.[br/][b]New Members Offer[/b][br/]-1-Get 300 Point Bonus[br/]\nYou can gain points by posting in forums,Literatures,blogs,polls,contests which will unlock other parts of this great site! -flower-[small][i]p.s: this is an automated Massage[/i][/small]',3,4,'1',1422344398,'0','0',0),(20296,'taka dao point dao',4,1,'0',1422344520,'0','0',0),(20297,'Amare staff Power dao Smiley uploade dea dimu ',4,1,'0',1422345416,'0','0',0),(20298,'Hello /reader. Wellcome to our big happy family![br/][topic=1]Please check out the instructions for any kind of help specially written for new members![/topic][br/]If you have any question or comments about the site feel free to massage any of the staff member from the online list.[br/][b]New Members Offer[/b][br/]-1-Get 300 Point Bonus[br/]\nYou can gain points by posting in forums,Literatures,blogs,polls,contests which will unlock other parts of this great site! -flower-[small][i]p.s: this is an automated Massage[/i][/small]',3,5,'0',1422596567,'0','0',0);
/*!40000 ALTER TABLE `ibwff_private` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_prrate`
--

DROP TABLE IF EXISTS `ibwff_prrate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_prrate` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `profid` int(100) NOT NULL DEFAULT '0',
  `uid` int(100) NOT NULL DEFAULT '0',
  `prrate` char(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_prrate`
--

LOCK TABLES `ibwff_prrate` WRITE;
/*!40000 ALTER TABLE `ibwff_prrate` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_prrate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_regblock65`
--

DROP TABLE IF EXISTS `ibwff_regblock65`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_regblock65` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_regblock65`
--

LOCK TABLES `ibwff_regblock65` WRITE;
/*!40000 ALTER TABLE `ibwff_regblock65` DISABLE KEYS */;
INSERT INTO `ibwff_regblock65` (`id`, `name`) VALUES (1,'nillrong_net'),(2,'c0m'),(3,'com'),(4,'musa'),(5,'nillrong'),(6,'.com'),(7,'rong.com'),(8,'nillrong'),(9,'http://'),(10,'mysuperwap'),(11,'tk,TK,net,bd,BD');
/*!40000 ALTER TABLE `ibwff_regblock65` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_request`
--

DROP TABLE IF EXISTS `ibwff_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_request` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `status` varchar(255) NOT NULL,
  `time` varchar(20) NOT NULL,
  `lastupdate` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_request`
--

LOCK TABLES `ibwff_request` WRITE;
/*!40000 ALTER TABLE `ibwff_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_rooms`
--

DROP TABLE IF EXISTS `ibwff_rooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_rooms` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '',
  `pass` varchar(100) NOT NULL DEFAULT '',
  `static` char(1) NOT NULL DEFAULT '',
  `mage` int(10) NOT NULL DEFAULT '0',
  `maxage` int(10) NOT NULL DEFAULT '0',
  `chposts` int(100) NOT NULL DEFAULT '0',
  `cyberpowereragon` int(10) NOT NULL DEFAULT '0',
  `censord` char(1) NOT NULL DEFAULT '1',
  `freaky` char(1) NOT NULL DEFAULT '0',
  `lastmsg` int(100) NOT NULL DEFAULT '0',
  `clubid` int(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_rooms`
--

LOCK TABLES `ibwff_rooms` WRITE;
/*!40000 ALTER TABLE `ibwff_rooms` DISABLE KEYS */;
INSERT INTO `ibwff_rooms` (`id`, `name`, `pass`, `static`, `mage`, `maxage`, `chposts`, `cyberpowereragon`, `censord`, `freaky`, `lastmsg`, `clubid`) VALUES (1,'CoolDhaka Adult Community!','','1',0,0,0,0,'0','0',1422340568,1);
/*!40000 ALTER TABLE `ibwff_rooms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_scomments`
--

DROP TABLE IF EXISTS `ibwff_scomments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_scomments` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `statusid` int(100) NOT NULL DEFAULT '0',
  `uid` int(100) NOT NULL DEFAULT '0',
  `scomments` varchar(255) NOT NULL DEFAULT '',
  `stime` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_scomments`
--

LOCK TABLES `ibwff_scomments` WRITE;
/*!40000 ALTER TABLE `ibwff_scomments` DISABLE KEYS */;
INSERT INTO `ibwff_scomments` (`id`, `statusid`, `uid`, `scomments`, `stime`) VALUES (1,6,85,'vaiya ami ki moderetor hote parbo','1416135840'),(2,6,85,'vaiya ami ki moderetor hote parbo','1416135862'),(3,1,1,'wghj','1416474415'),(4,1,5,'Bujhi nai touhid vai','1416479248'),(5,18,31,'Vai Amake Staff A Add Dicen Na Kano.','1418442092'),(6,5,15,'Amra jani tmi touhid rj bujhso........','1420296123'),(7,57,185,'Kono valo manush nijeke nijei valo bole na . Do you understand what i am talking about ?','1420474010'),(8,57,15,'Tai naki','1420539601'),(9,5,201,'-du-','1420720065'),(10,5,209,'Mitu_jahan er profile dekte chai,bt pfile to deka jai na,pfile ki hlo mitu_jahan er.','1420728532');
/*!40000 ALTER TABLE `ibwff_scomments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_search`
--

DROP TABLE IF EXISTS `ibwff_search`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_search` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `svar1` varchar(50) NOT NULL DEFAULT '',
  `svar2` varchar(50) NOT NULL DEFAULT '',
  `svar3` varchar(50) NOT NULL DEFAULT '',
  `svar4` varchar(50) NOT NULL DEFAULT '',
  `svar5` varchar(50) NOT NULL DEFAULT '',
  `stime` int(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_search`
--

LOCK TABLES `ibwff_search` WRITE;
/*!40000 ALTER TABLE `ibwff_search` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_search` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_ses`
--

DROP TABLE IF EXISTS `ibwff_ses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_ses` (
  `id` varchar(100) NOT NULL DEFAULT '',
  `uid` varchar(30) NOT NULL DEFAULT '',
  `expiretm` int(100) NOT NULL DEFAULT '0',
  UNIQUE KEY `id` (`id`,`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_ses`
--

LOCK TABLES `ibwff_ses` WRITE;
/*!40000 ALTER TABLE `ibwff_ses` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_ses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_settings`
--

DROP TABLE IF EXISTS `ibwff_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_settings` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '',
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=64 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_settings`
--

LOCK TABLES `ibwff_settings` WRITE;
/*!40000 ALTER TABLE `ibwff_settings` DISABLE KEYS */;
INSERT INTO `ibwff_settings` (`id`, `name`, `value`) VALUES (1,'sesexp','60'),(2,'Fri 14 Dec 2012 - 12:22','108'),(3,'4ummsg','-line2--line2-'),(4,'Counter','198710'),(5,'pmaf','5'),(6,'reg','1'),(7,'fview',''),(8,'lastbpm','2014-04-05'),(9,'sitename','CoolDhaka.Tk'),(10,'siteage','0'),(11,'vldtn','1'),(32,'blogpoint','8'),(13,'chpluss',''),(33,'clpluss','500'),(16,'blpluss',''),(17,'themes','Styles.css'),(18,'popupaf','5'),(19,'regaf','36000'),(20,'shoutaf','5'),(21,'cpoint','1'),(22,'spoint','3'),(23,'lpoint','3'),(24,'hpoint','4'),(25,'mkfpoint','3'),(26,'fcompoint','1'),(27,'litpoint','8'),(28,'litcompoint','1'),(29,'blogneedpoint','9'),(30,'blogcompoint','1'),(31,'fpluss','13'),(34,'nmpluss','50'),(35,'newclubpoint','1000'),(36,'memberpoint','3600'),(37,'junmemberpoint','10800'),(38,'senmemberpoint','21600'),(39,'expellerpoint','2500'),(40,'mrsmispoint','45000'),(41,'pppoint','6490'),(42,'king','30000'),(43,'kok','50000'),(44,'knightpoint','1500'),(45,'expartpoint','3500'),(46,'fmvldtn','1'),(47,'litvldtn','0'),(48,'pollvldtn','0'),(49,'blogvldtn','0'),(50,'ntitle','Edited!'),(51,'cntitle','Coming song '),(52,'lnktitle','1 New Offer'),(53,'cntmsg','[green]*****    Coming song    *****[/green][br/].[br/][topic=15] Mwap all contest Rulz..[/topic]'),(54,'ntcmsg','-next-[color=red][b]Sokol Vai O Bon Ke Meetwap Online Community er Pokkho Theke Janai Assalamu Alaikum...-rose-[/color][/b][br/]-up-[b][color=magenta]Apnader Obogotir Jonne  Meetwap er Discipline Thik Rakhar Jonne Bises Kichu Rules Deya Holo..[/color][/b][br/]-1-[b][color=red]Staff Team er Permission Chara Mwap e Kono Dhoroner Boro Contest Create Korben Na.[/color][/b][br/]-2-[b][color=purple]Ekhon Theke Apnara Discussion Topic Gulote Adda Dite Parben Mon Khule But Faw Post, Short Post R Flood Post Korben Na Please.[/color][/b][br/]-3-[b][color=darkred]Per Club Theke Per Day Creation er Limit Gulo Holo===and[/color][/b][br/]-1-[b][color=blue]1. Topic === 5 Ta[br/]2. Blog === 3 Ta[br/]3. Literature === 3 Ta[br/]4. Poll === 5 Ta.[/color][/b][br/]-4-[b][color=darkcyan]Apnara Club Contest Gulor Name e(MW/ MWAP)Use Korben Na. Eta Sudhu Matro Meetwap Staff Rai Meetwap er Official Contest Gulote Use Korar Odhikar Rakhen..[/color][/b][br/]-5-[b][color=purple]Apnader Sobar Kache Amader Onurodh Holo Apnara Nije Rules Break Korben Na R Onno Keu Rules Break Korle Take Bujhaben R Mana Korben..[/color][/b][br/]-6-[b][color=red]Meetwap e Apnara Nijeder Moddhe Kono Bisoy ( Cricket Match, Football Match, Others ) Niye Personal Baji Dhorte Parben Na Jodi Dhoren Tahole Dujon Kei Penalty Kora Hobe.[/color][/b][br/]-staf-[b][color=deeppink]Meetwap Staff Team[/color][/b]-du-[br/]'),(55,'lnkmsg','..::[topic=66]MeetWap Offer[/topic]'),(56,'insmsg',''),(57,'institle',''),(58,'pollc_uday','1'),(59,'poll_uday','3'),(60,'junvip_uday','54000'),(61,'senvip_uday','108000'),(62,'tpcval','1'),(63,'artval','1');
/*!40000 ALTER TABLE `ibwff_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_shcomments`
--

DROP TABLE IF EXISTS `ibwff_shcomments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_shcomments` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `shoutid` int(100) NOT NULL DEFAULT '0',
  `uid` int(100) NOT NULL DEFAULT '0',
  `shcomments` varchar(255) NOT NULL DEFAULT '',
  `shtime` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_shcomments`
--

LOCK TABLES `ibwff_shcomments` WRITE;
/*!40000 ALTER TABLE `ibwff_shcomments` DISABLE KEYS */;
INSERT INTO `ibwff_shcomments` (`id`, `shoutid`, `uid`, `shcomments`, `shtime`) VALUES (1,3,15,'automatically pm ban..why man?? pls unban!!','1420824342'),(2,3,14,'asa matroi ban','1420824382'),(3,3,15,'ore vai van na ban -haha-','1420824534'),(4,14,39,'amake voyer moto kaj korle voy na peleo kolija kapbe. but tomar voyer kono karon nei','1420904558'),(5,33,14,'sundor lagce, heavvy lagce','1421165111'),(6,33,18,'super..........','1421210640'),(7,33,1,'thanku','1421210784'),(8,33,18,'Wc.................','1421210825'),(9,33,1,'-tnx-.......','1421210937'),(10,36,74,'Eai Gaanta Khub Sundur','1421334591'),(11,46,17,'Ki pm diso j ban kore rakhse','1421347129'),(12,46,43,'Devoler kotha ta liksilam admin ke tai.','1421347172'),(13,50,84,'-hmm- -ge-','1421405169'),(14,65,1,'premiunm room e to lagbeii -lol-','1421503413'),(15,65,91,'Premium rm a na sob rm ei dukhte ei lekha dekhai r vip rm a naki sudhu staff dhukte parbe dekhai -hoha-','1421503549'),(16,65,1,'wait......','1421503613'),(17,65,91,'Hmm thik koro site a to onek problem','1421503765'),(18,77,91,'Colour adul t site er dichen but site adul t na tai ami band khelam','1421633942'),(19,77,106,'Amk o pm dia bola hoyce ata adult site','1421636168'),(20,77,91,'Na bro ata adult na pn a ami bolecilam','1421638044'),(21,80,109,'moring','1421639968'),(22,80,106,'-gm-vai 300 gift payce ar ki pabo??touhid','1421641286'),(23,86,106,'Amk ban dila kan','1421662185'),(24,85,106,'Amk ban dilo kan vai,ami 2 spm korini','1421662510'),(25,86,91,'Ami band koi dilam','1421664292');
/*!40000 ALTER TABLE `ibwff_shcomments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_shop`
--

DROP TABLE IF EXISTS `ibwff_shop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_shop` (
  `itemid` int(100) NOT NULL AUTO_INCREMENT,
  `itemname` varchar(100) NOT NULL DEFAULT '',
  `itmeprice` int(100) NOT NULL DEFAULT '0',
  `itemshopid` int(100) NOT NULL DEFAULT '0',
  `avail` int(100) NOT NULL DEFAULT '0',
  `itemdesc` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_shop`
--

LOCK TABLES `ibwff_shop` WRITE;
/*!40000 ALTER TABLE `ibwff_shop` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_shop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_shop_inventory`
--

DROP TABLE IF EXISTS `ibwff_shop_inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_shop_inventory` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `uid` int(100) NOT NULL DEFAULT '0',
  `itemid` int(100) NOT NULL DEFAULT '0',
  `time` int(100) NOT NULL DEFAULT '0',
  `who` int(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_shop_inventory`
--

LOCK TABLES `ibwff_shop_inventory` WRITE;
/*!40000 ALTER TABLE `ibwff_shop_inventory` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_shop_inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_shouts`
--

DROP TABLE IF EXISTS `ibwff_shouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_shouts` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `shout` varchar(10000) NOT NULL DEFAULT '',
  `shouter` int(100) NOT NULL DEFAULT '0',
  `shtime` int(100) NOT NULL DEFAULT '0',
  `clubid` int(120) NOT NULL DEFAULT '0',
  `act_uday` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=90 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_shouts`
--

LOCK TABLES `ibwff_shouts` WRITE;
/*!40000 ALTER TABLE `ibwff_shouts` DISABLE KEYS */;
INSERT INTO `ibwff_shouts` (`id`, `shout`, `shouter`, `shtime`, `clubid`, `act_uday`) VALUES (89,'Adult Site vlo but Smiley koi member koi ??',4,1422345329,0,''),(88,'-wc-our new adut site',1,1422340477,0,'');
/*!40000 ALTER TABLE `ibwff_shouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_smilies`
--

DROP TABLE IF EXISTS `ibwff_smilies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_smilies` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `scode` varchar(15) NOT NULL DEFAULT '',
  `imgsrc` varchar(200) NOT NULL DEFAULT '',
  `hidden` char(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `scode` (`scode`)
) ENGINE=MyISAM AUTO_INCREMENT=615 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_smilies`
--

LOCK TABLES `ibwff_smilies` WRITE;
/*!40000 ALTER TABLE `ibwff_smilies` DISABLE KEYS */;
INSERT INTO `ibwff_smilies` (`id`, `scode`, `imgsrc`, `hidden`) VALUES (1,'-line-','../smilies/-line-.gif','0'),(460,'-gm6-','../smilies/good-morning-064.gif','0'),(41,'-admin-','../smilies/-admin-.gif','0'),(8,'-ch-','../smilies/-ch-.jpg','0'),(461,'-ga-','../smilies/good afternoon my friend images free download.jpg','0'),(10,'-haha1-','../smilies/-haha1-.jpg','0'),(11,'-hi4-','../smilies/-hi4-.gif','0'),(12,'-mn-','../smilies/-mn-.gif','0'),(13,'-nono-','../smilies/-nono-.gif','0'),(14,'-sd-','../smilies/-sd-.gif','0'),(15,'-shy-','../smilies/-shy-.gif','0'),(16,'-really-','../smilies/really.jpg','0'),(85,'-jin-','../smilies/-jini-.gif','0'),(39,'-it-','../smilies/-it-.gif','0'),(40,'-adb-','../smilies/-adb-.gif','0'),(28,'-up-','../smilies/up.gif','0'),(29,'-rose-','../smilies/-rose-.gif','0'),(42,'-atos-','../smilies/-atos-.gif','0'),(34,'-lol2-','../smilies/-lol8-.gif','0'),(35,'-new-','../smilies/-new-.gif','0'),(36,'-ok-','../smilies/-ok-.gif','0'),(37,'-p-','../smilies/p.gif','0'),(43,'-attention-','../smilies/-attention-.gif','0'),(44,'-babycry-','../smilies/-babycry-.gif','0'),(45,'-babyno-','../smilies/-babyno-.gif','0'),(46,'-ban-','../smilies/-ban-.gif','0'),(47,'-bd-','../smilies/-bd1-.gif','0'),(469,'-bari-','../smilies/-bari-.gif','0'),(49,'-eee-','../smilies/-eee-.gif','0'),(50,'-fire-','../smilies/-firing-.gif','0'),(51,'-fun-','../smilies/-fun-.gif','0'),(52,'-ganja-','../smilies/-ganja-.gif','0'),(53,'-hii-','../smilies/-hii-.gif','0'),(54,'-wc-','../smilies/-wc-.gif','0'),(86,'-imking-','../smilies/-imking-.gif','0'),(462,'-ga2-','../smilies/good-afternoon-heart-stylish-.jpg','0'),(74,'-asm-','../smilies/asmbd.jpg','0'),(467,'-kemon-','../smilies/-kemon-.gif','0'),(87,'-mnlove-','../smilies/-mnlove-.gif','0'),(88,'-marts-','../smilies/-marts-.gif','0'),(89,'-mummy-','../smilies/-mummy-.gif','0'),(90,'-sadgirl-','../smilies/-sadgirl-.gif','0'),(91,'-omg-','../smilies/-omg-.gif','0'),(92,'-syw-','../smilies/-saywah-.gif','0'),(93,'-sick1-','../smilies/-sick1-.gif','0'),(94,'-skullman-','../smilies/-skullman-.gif','0'),(95,'-swtlov-','../smilies/-swtlov-.gif','0'),(464,'-bnnd-','../smilies/band baaja baaraat poster_q1_q2_q1.jpg','0'),(577,'-hi-','../smilies/-hi-.gif','0'),(582,'-login-','../smilies/-login-.gif','0'),(99,'-slapping-','../smilies/-slapping-.gif','0'),(100,'-right-','../smilies/-right-.gif','0'),(101,'-balloons-','../smilies/-balloons-.gif','0'),(102,'-gros-','../smilies/-gros-.gif','0'),(103,'-hwdy-','../smilies/-hwdy-.gif','0'),(105,'-haha8-','../smilies/-haha8-.gif','0'),(117,'-lvlv-','../smilies/-lvlv-.gif','0'),(107,'-valo-','../smilies/-valo-.gif','0'),(579,'-mtime-','../smilies/-mtime-.gif','0'),(578,'-it4-','../smilies/hvggg.gif','0'),(110,'-vua-','../smilies/-vua-.gif','0'),(111,'-urdb-','../smilies/-urdb-.gif','0'),(112,'-light-','../smilies/-light-.gif','0'),(118,'-osadaron-','../smilies/-osadaron-.gif','0'),(114,'-bdflag-','../smilies/-bdflag-.gif','0'),(115,'-congrates-','../smilies/-congrates-.gif','0'),(116,'-maf-','../smilies/-maf-.gif','0'),(119,'-arg-','../smilies/-arg-.gif','0'),(120,'-phn-','../smilies/-phn-.gif','0'),(121,'-messi-','../smilies/-messi-.gif','0'),(122,'-bigshot-','../smilies/-bigshot-.gif','0'),(123,'-fireball-','../smilies/-fireball-.gif','0'),(124,'-faul-','../smilies/-faul-.gif','0'),(126,'-iw-','../smilies/-iw-.gif','0'),(127,'-grc-','../smilies/-grc-.gif','0'),(128,'-gyc-','../smilies/-gyc-.gif','0'),(129,'-hfd1-','../smilies/-hfd1-.gif','0'),(583,'-bday7-','../smilies/-bday7-.gif','0'),(131,'-thanku-','../smilies/-thanku-.gif','0'),(132,'-w3c-','../smilies/-w3c-.gif','0'),(133,'-star-','../smilies/-star-.gif','0'),(134,'-click-','../smilies/-click-.gif','0'),(231,'-khara-','../smilies/Kace_ay.gif','0'),(141,'-salam-','../smilies/-salam-.gif','0'),(142,'-yahooo-','../smilies/-yahooo-.gif','0'),(148,'-danda-','../smilies/-danda-.gif','0'),(147,'-bolod-','../smilies/-bolod-.gif','0'),(149,'-fassi-','../smilies/-fassi-.gif','0'),(151,'-bye4-','../smilies/-bye4-.gif','0'),(152,'-hello2-','../smilies/-hello2-.gif','0'),(581,'-line3-','../smilies/-line2-.gif','0'),(155,'-lash-','../smilies/-lash-.gif','0'),(156,'-gunda-','../smilies/-gun4-.gif','0'),(158,'-pcoco-','../smilies/-yoyo-.gif','0'),(159,'-booo-','../smilies/-booo-.gif','0'),(163,'-closed- ','../smilies/-closed-.gif','0'),(209,'-bmgun-','../smilies/-bmgun-.gif','0'),(165,'-papu- ','../smilies/-papu-.gif','0'),(171,'-hippo-','../smilies/-hippo-.gif','0'),(465,'-haihai-','../smilies/-haihai-.gif','0'),(172,'-it1-','../smilies/-it1-.gif','0'),(173,'-hohaha-','../smilies/-hohaha-.gif','0'),(174,'-gm2-','../smilies/-gm2-.gif','0'),(228,'-hlw-','../smilies/-hello-.gif','0'),(176,'-banned-','../smilies/banned.gif','0'),(177,'-t1-','../smilies/1tounge2.gif','0'),(584,'-bday8-','../smilies/-bday8-.gif','0'),(468,'-bang-','../smilies/-bang-.gif','0'),(466,'-dolna-','../smilies/-dolna-.gif','0'),(182,'-nw-','../smilies/-nw-.gif','0'),(580,'-jos-','../smilies/-jos-.gif','0'),(184,'-bye-','../smilies/-bye2-.gif','0'),(585,'-six-','../smilies/-six-.gif','0'),(186,'-gin-','../smilies/1genie.gif','0'),(237,'-next-','../smilies/-next-.gif','0'),(188,'-lol-','../smilies/-lol-.gif','0'),(236,'-fb-','../smilies/fb.gif','0'),(477,'-em-','../smilies/-em-.jpg','0'),(193,'-it2-','../smilies/-it2-.gif','0'),(232,'-sj-','../smilies/-sj-.gif','0'),(197,'-smk-','../smilies/boss.gif','0'),(198,'-lgun-','../smilies/-lgun-.gif','0'),(203,'-rose1-','../smilies/-rose4-.gif','0'),(202,'-yo-','../smilies/-yay-.gif','0'),(586,'-star1-','../smilies/-star1-.gif','0'),(205,'-gm4-','../smilies/-gm4-.gif','0'),(207,'-ga1-','../smilies/-gnoon1-.gif','0'),(210,'-devil1-','../smilies/-devil1-.gif','0'),(211,'-gift4u-','../smilies/-gift4u-.gif','0'),(212,'-gbox-','../smilies/-gbox-.gif','0'),(213,'-gl-','../smilies/-gl-.gif','0'),(214,'-clap4-','../smilies/-clap4-.gif','0'),(215,'-down-','../smilies/-down-.gif','0'),(220,'-aaa-','../smilies/-aaaaaa-(1).gif','0'),(221,'-hulk-','../smilies/-hulk1-.gif','0'),(218,'-body-','../smilies/-body-.gif','0'),(222,'-marry-','../smilies/-marriage-.gif','0'),(223,'-rokdance-','../smilies/-jackson-.gif','0'),(224,'-gout-','../smilies/getout1.gif','0'),(227,'-hnd-','../smilies/-hnd-.gif','0'),(226,'-order-','../smilies/-order-.gif','0'),(587,'-batf-','../smilies/-batf-.gif','0'),(234,'-durga-','../smilies/-durga-.gif','0'),(239,'-w2c-','../smilies/-w2c-.gif','0'),(240,'-read-','../smilies/-read-.gif','0'),(588,'-next1-','../smilies/-next1-.gif','0'),(242,'-rulz-','../smilies/-rulz-.gif','0'),(243,'-spam-','../smilies/-spam2-.gif','0'),(244,'-toilet-','../smilies/-toilet1-.gif','0'),(245,'-ura-','../smilies/-ura-.gif','0'),(246,'-vhoot-','../smilies/-vhoot-.gif','0'),(247,'-voot-','../smilies/-voot-.gif','0'),(248,'-wow-','../smilies/-wow-.gif','0'),(472,'-brush1-','../smilies/-brush1-.gif','0'),(471,'-bored1-','../smilies/-bored1-.gif','0'),(253,'-cw-','../smilies/cw.jpg','0'),(254,'-hello-','../smilies/hello.jpg','0'),(255,'-moja-','../smilies/-moja-.gif','0'),(256,'-monkey-','../smilies/-monkey2-.gif','0'),(257,'-muri-','../smilies/-muri-.gif','0'),(258,'-nono2-','../smilies/-nono2-.gif','0'),(259,'-nospam-','../smilies/-nospam-.gif','0'),(260,'-nunu-','../smilies/-nunu-.gif','0'),(589,'-ajob-','../smilies/-ajob-.gif','0'),(263,'-ki-','../smilies/-ki-.png','0'),(264,'-khobor-','../smilies/-khobor-.gif','0'),(265,'-khun-','../smilies/-khun-.gif','0'),(266,'-don-','../smilies/-don-.gif','0'),(267,'-rocks-','../smilies/-rocks-.png','0'),(268,'-tik-','../smilies/tik.gif','0'),(269,'-hi2-','../smilies/-hi2-.gif','0'),(590,'-bowl-','../smilies/-bowl-.gif','0'),(294,'-line2-','http://dhakawap.com/community/smilies/load/Dhakawap/-line2-.gif','0'),(272,'-superman1-','../smilies/-superman1-.gif','0'),(591,'-bat-','../smilies/-bat-.gif ','0'),(274,'-stop1-','../smilies/-stop1-.gif','0'),(293,'-mindit-','http://dhakawap.com/community/smilies/load/Dhakawap/-mindit-.gif','0'),(592,'-gbat-','../smilies/-gbat-.gif ','0'),(279,'-gbsign-','../smilies/underconstruction-0149.gif','0'),(287,'-left-','../smilies/-left-.gif','0'),(291,'.tik.','http://dhakawap.com/community/smilies/load/Dhakawap/-tik-.gif','0'),(292,'.ri8.','http://dhakawap.com/community/smilies/load/Dhakawap/-right-.gif','0'),(297,'-hi5-','../smilies/hi.jpg','0'),(298,'-click4-','../smilies/2279.jpg','0'),(509,'-gf-','../smilies/-gf-.gif','0'),(309,'-s_b-','../smilies/-bismillah2-.gif','0'),(310,'-s_b1-','../smilies/-clock-.gif','0'),(311,'-fir-','../smilies/-lin-.gif','0'),(312,'-glu-','../smilies/-glu-.gif','0'),(510,'-lokkhi-','../smilies/-lokkhi-.gif','0'),(511,'-micro-','../smilies/-micro-.gif','0'),(317,'-light1-','../smilies/-light-.gif','0'),(512,'-micro1-','../smilies/-micro1-.gif','0'),(319,'-prize-','../smilies/-prize-.gif','0'),(320,'-rest1-','../smilies/-rest1-.gif','0'),(321,'-tiger-','../smilies/-tiger-.gif','0'),(322,'-outb-','../smilies/-outb-.gif','0'),(323,'-lala-','../smilies/-lala-.gif','0'),(324,'-shaving-','../smilies/-shaving-.gif','0'),(325,'-pdown-','../smilies/-pdown-.gif','0'),(326,'-boss-','../smilies/-boss-.gif','0'),(327,'-bike1-','../smilies/-bike1-.gif','0'),(328,'-bike2-','../smilies/-bike2-.gif','0'),(329,'-r,sir-','../smilies/-r,sir-.gif','0'),(330,'-heli-','../smilies/-heli-.gif','0'),(331,'-sch-','../smilies/-sch-.gif','0'),(332,'-icream-','../smilies/-icream-.gif','0'),(333,'-dislike1-','../smilies/-dislike1-.gif','0'),(334,'-lolipop1-','../smilies/-lolipop1-.gif','0'),(335,'-lolipop-','../smilies/-lolipop-.gif','0'),(336,'-icecrm-','../smilies/-icecrm-.gif','0'),(337,'-suicidekor-','../smilies/-suicidekor-.gif','0'),(338,'-shotto-','../smilies/-shotto-.gif','0'),(339,'lol-','../smilies/lol-.gif','0'),(340,'-sharod-','../smilies/-sharod-.gif','0'),(341,'-3g-','../smilies/-3g-.gif','0'),(342,'-jhakkas-','../smilies/-jhakkas-.gif','0'),(343,'-hotel-','../smilies/-hotel-.gif','0'),(344,'-ciken-','../smilies/-ciken-.gif','0'),(345,'-hf-','../smilies/-hf-.gif','0'),(346,'-gdida-','../smilies/-gdida-.gif','0'),(347,'-rub-','../smilies/-rub-.gif','0'),(348,'-xevil-','../smilies/-xevil-.gif','0'),(349,'-jharu-','../smilies/-jharu-.gif','0'),(350,'-valo1-','../smilies/-valo-.png','0'),(351,'-vua1-','../smilies/-vua-.png','0'),(352,'-vaab-','../smilies/-vaab-.png','0'),(353,'-murikha1-','../smilies/-murikha-.png','0'),(354,'-kaittalamu1-','../smilies/-kaittalamu-.png','0'),(355,'-dance5-','../smilies/-dance5-.gif','0'),(356,'-prty-','../smilies/-prty-.gif','0'),(357,'-prty2-','../smilies/-prty2-.gif','0'),(358,'-ilvu2-','../smilies/-ilvu2-.gif','0'),(359,'-minar-','../smilies/-minar-.gif','0'),(360,'-nobo-','../smilies/-nobo-.gif','0'),(361,'-sleepy1-','../smilies/-sleepy1-.gif','0'),(362,'-hula-','../smilies/-hula-.gif','0'),(363,'-brkheart-','../smilies/-brkheart-.gif','0'),(364,'-xslap-','../smilies/-xslap-.gif','0'),(365,'-rdysleep-','../smilies/-rdysleep-.gif','0'),(366,'-lvblast-','../smilies/-lvblast-.gif','0'),(367,'-xnono-','../smilies/-xnono-.gif','0'),(368,'-xprojapoti-','../smilies/-xprojapoti-.gif','0'),(369,'-hrtbeat-','../smilies/-hrtbeat-.gif','0'),(370,'-santa-','../smilies/-santa-.gif','0'),(371,'-hrtrotate-','../smilies/-hrtrotate-.gif','0'),(372,'-mlvu-','../smilies/-mlvu-.gif','0'),(373,'-teddy-','../smilies/-teddy-.gif','0'),(374,'-zzzzz-','../smilies/-zzzzz-.gif','0'),(375,'-italy-','../smilies/-italy-.gif','0'),(376,'-brazil-','../smilies/-brazil-.gif','0'),(593,'-bsix-','../smilies/-bsix-.gif','0'),(378,'-rcrd-','../smilies/-rcrd-.gif','0'),(379,'-ycrd-','../smilies/-ycrd-.gif','0'),(380,'-ballround-','../smilies/-ballround-.gif','0'),(381,'-bigshot1-','../smilies/-bigshot-.gif','0'),(382,'-faul1-','../smilies/-faul-.gif','0'),(383,'-gdpass-','../smilies/-gdpass-.gif','0'),(384,'-prctic-','../smilies/-prctic-.gif','0'),(385,'-redref-','../smilies/-redref-.gif','0'),(386,'-gtout-','../smilies/-gtout-.gif','0'),(387,'-nicekick-','../smilies/-nicekick-.gif','0'),(388,'-lsr-','../smilies/-lsr-.gif','0'),(389,'-goal-','../smilies/-goal-.gif','0'),(390,'-it3-','../smilies/-it2-.gif','0'),(391,'-tnku-','../smilies/-tnku-.gif','0'),(392,'-like2-','../smilies/-like2-.gif','0'),(393,'-mashallah-','../smilies/-mashallah-.gif','0'),(394,'-clnr-','../smilies/-clnr-.gif','0'),(395,'-grnd-','../smilies/-grnd-.gif','0'),(396,'-hug2-','../smilies/-hug2-.gif','0'),(397,'-lgun1-','../smilies/-lgun-.gif','0'),(398,'-erphn-','../smilies/-erphn-.gif','0'),(399,'-plc-','../smilies/-plc-.gif','0'),(400,'-bd1-','http://dhakawap.com/community/smilies/load/Dhakawap/-bd1-.gif','0'),(401,'-du-','http://dhakawap.com/community/smilies/load/Dhakawap/-du-.gif','0'),(403,'-rapper-','../smilies/-rapper-.gif','0'),(404,'-rksing-','../smilies/-rksing-.gif','0'),(405,'-ssmk-','../smilies/-ssmk-.gif','0'),(406,'-gulti-','../smilies/-gulti-.gif','0'),(407,'-scd1-','../smilies/-scd1-.gif','0'),(408,'-sniper-','../smilies/-sniper-.gif','0'),(409,'-swtfly-','../smilies/-swtfly-.gif','0'),(410,'-birdpoop-','../smilies/-birdpoop-.gif','0'),(411,'-doctor-','../smilies/-doctor-.gif','0'),(412,'-hbash-','../smilies/-hbash-.gif','0'),(413,'-hohaha1-','../smilies/-hohaha1-.gif','0'),(414,'-hehe2-','../smilies/-hehe2-.gif','0'),(415,'-rdtoilet-','../smilies/-rdtoilet-.gif','0'),(416,'-smk1-','../smilies/-smk-.gif','0'),(417,'-legg-','../smilies/-legg-.gif','0'),(418,'-yesno-','../smilies/-yesno-.gif','0'),(419,'-akick-','../smilies/-akick-.gif','0'),(420,'-kotha-','../smilies/-kotha-.gif','0'),(421,'-motu-','../smilies/-motu-.gif','0'),(422,'-sspider-','../smilies/-sspider-.gif','0'),(423,'-spider-','../smilies/-spider-.gif','0'),(424,'-mosa-','../smilies/-mosa-.gif','0'),(425,'-danda2-','../smilies/-danda2-.gif','0'),(426,'-out-','../smilies/-out-.gif','0'),(427,'-urout-','../smilies/-urout-.gif','0'),(428,'-batter-','../smilies/-batter-.gif','0'),(429,'-batting-','../smilies/-batting-.gif','0'),(430,'-hardhit-','../smilies/-hardhit-.gif','0'),(431,'-cutfish-','../smilies/-cutfish-.gif','0'),(432,'-rapper2-','../smilies/-rapper2-.gif','0'),(433,'-rose4u-','../smilies/-rose4u-.gif','0'),(482,'-alien-','../smilies/-alien-.gif','0'),(435,'-monkharaf-','../smilies/-monkharaf-.gif','0'),(436,'-gm5-','../smilies/-gm5-.gif','0'),(437,'-ass-','../smilies/-ass-.gif','0'),(438,'-iagree-','../smilies/-iagree-.gif','0'),(439,'-angry5-','../smilies/-angry5-.gif','0'),(440,'-ch1-','../smilies/-ch1-.gif','0'),(441,'-think9-','../smilies/-think9-.gif','0'),(442,'-fmlydinner-','../smilies/-fmlydinner-.gif','0'),(443,'-builder-','../smilies/-builder-.gif','0'),(444,'-ok2-','../smilies/-ok2-.gif','0'),(445,'-mindit1-','../smilies/-mindit-.gif','0'),(446,'-1-','../smilies/-1-.gif','0'),(449,'-hbd1-','../smilies/-hbd1-.jpg','0'),(450,'-unnamed-','../smilies/unnamed.gif','0'),(451,'-bday-','../smilies/-bday-.gif','0'),(452,'-7up-','../smilies/-7up-.gif','0'),(453,'-cola-','../smilies/-cola-.gif','0'),(454,'-doi-','../smilies/-doi-.gif','0'),(455,'-misty-','../smilies/-misty-.gif','0'),(456,'-misti-','../smilies/-misti-.gif','0'),(457,'-fuchka-','../smilies/-fuchka-.gif','0'),(458,'-match-','../smilies/-match-.gif','0'),(473,'-bye5-','../smilies/-bye5-.gif','0'),(474,'-cheer-','../smilies/-cheer-.gif','0'),(475,'-chill-','../smilies/-chill-.gif','0'),(476,'-coffe2-','../smilies/-coffe2-.gif','0'),(478,'-uccat-','../smilies/-uc-.jpg','0'),(479,'-khepa-','../smilies/-khepa-.gif','0'),(480,'-theng-','../smilies/-theng-.gif','0'),(481,'-wfd-','../smilies/-wfd-.gif','0'),(483,'-badminton-','../smilies/-badminton2-.gif','0'),(535,'-bird1-','../smilies/-bird1-.gif','0'),(490,'-toss-','../smilies/-toss-.gif?','0'),(508,'-gf2-','../smilies/-gf2-.gif','0'),(507,'-motsokonna-','../smilies/-motsokonna-.gif','0'),(506,'-princess-','../smilies/-princess-.gif','0'),(505,'-bnnnd-','../smilies/most_welcome_bangladeshi_movie_q1_q1.jpg','0'),(513,'-angeharpe-','../smilies/-angeharpe-.gif','0'),(514,'-=-','../smilies/-=-.gif','0'),(515,'-9-','../smilies/-9-.gif','0'),(516,'-8-','../smilies/-8-.gif','0'),(517,'-7-','../smilies/-7-.gif','0'),(518,'-6-','../smilies/-6-.gif','0'),(519,'-5-','../smilies/-5-.gif','0'),(520,'-4-','../smilies/-4-.gif','0'),(521,'-3-','../smilies/-3-.gif','0'),(522,'-2-','../smilies/-2-.gif','0'),(523,'-ghora-','../smilies/-ghora-.gif','0'),(524,'-nspam-','../smilies/-nspam-.gif','0'),(525,'-dell-','../smilies/-dell-.gif','0'),(526,'-computer3-','../smilies/-computer3-.gif','0'),(527,'-toy-','../smilies/-toy-.gif','0'),(528,'-vampire-','../smilies/-vampire-.gif','0'),(529,'-winkeye-','../smilies/-winkeye-.gif','0'),(530,'-muscles1-','../smilies/-muscles1-.gif','0'),(531,'-daz-','../smilies/-daz-.gif','0'),(532,'-drink3-','../smilies/-drink3-.gif','0'),(533,'-drinks2-','../smilies/-drinks2-.gif','0'),(534,'-scar-','../smilies/-scar-.gif','0'),(538,'-star2-','../smilies/half-star.gif','0'),(539,'-gstar-','../smilies/-gstar-.gif','0'),(540,'','','0'),(541,'-haha2-','../smilies/-haha8-.gif','0'),(542,'-hayhay1-','../smilies/-hayhay1-.gif','0'),(543,'-hbd2-','../smilies/-hbd2-.gif','0'),(544,'-hd1-','../smilies/-hdktr-.gif','0'),(545,'-hehehe-','../smilies/-hehe-.gif','0'),(546,'-hihi-','../smilies/-hihi-.gif','0'),(547,'-bdnn-','../smilies/1396531495991.gif','0'),(548,'-supergirl-','../smilies/-supergirl-.gif','0'),(549,'-signal-','../smilies/-signal-.gif','0'),(550,'-peace1-','../smilies/-peace1-.gif','0'),(551,'-runner-','../smilies/-runner-.gif','0'),(552,'-kickface-','../smilies/-kickface-.gif','0'),(553,'-candledinner-','../smilies/-candledinner-.gif','0'),(554,'-2ride-','../smilies/-2ride-.gif','0'),(555,'-tugofwar-','../smilies/-tugofwar-.gif','0'),(556,'-dog7-','../smilies/-dog7-.gif','0'),(557,'-icanfly-','../smilies/-icanfly-.gif','0'),(558,'-ignore-','../smilies/-ignore-.gif','0'),(559,'-surrender-','../smilies/-surrender-.gif','0'),(560,'-injection-','../smilies/-injection-.gif','0'),(561,'-cricket-','../smilies/-cricket-.gif','0'),(562,'-gun1-.gif','../smilies/-gun1-.gif','0'),(563,'-ura1-','../smilies/-ura1-.gif','0'),(564,'-sagotom-','../smilies/-sagotom-.gif','0'),(565,'-dhishum-','../smilies/-dhishum-.gif','0'),(566,'-tank2-','../smilies/-tank2-.gif','0'),(567,'-bottle-','../smilies/-bottle-.gif','0'),(568,'-meat-.gif','../smilies/-meat-.gif','0'),(569,'-banana1-','../smilies/-banana1-.gif','0'),(570,'-clap-','../smilies/-clap-.gif','0'),(571,'-sorry-','http://mydhaka.tk/sagor/smilies/sorry.png','0'),(572,'-safe-','http://mydhaka.tk/sagor/smilies/safe.png','0'),(573,'-sad-','http://mydhaka.tk/sagor/smilies/sad.png','0'),(574,'-paned-','http://mydhaka.tk/sagor/smilies/pained.png','0'),(575,'-happy-','http://mydhaka.tk/sagor/smilies/happy.png','0'),(576,'-2dancing-','../smilies/-2dancing-.gif','0'),(594,'-gbowl-','../smilies/-gbowl-.gif','0'),(595,'-right1-','../smilies/-right1-.gif ','0'),(596,'-crying-','../smilies/-crying-.gif','0'),(597,'-h2015-','../smilies/happy+new+year+hd+wallpaper+2015_q1_q1_q1.jpg ','0'),(607,'-color1-','../smilies/color1.jpg','0'),(599,'-wish-','../smilies/-wish-.gif','0'),(600,'-r,wish-','../smilies/-r,wish-.gif','0'),(601,'-mma-','../smilies/oman-flag.gif ','0'),(608,'-color2-','../smilies/color2.jpg','0'),(603,'-hny-','../smilies/vghg.jpg ','0'),(604,'-happym-','../smilies/0happy.gif','0'),(609,'-color3-','../smilies/color3.jpg','0'),(610,'-color4-','../smilies/color4.jpg','0'),(611,'-color5-','../smilies/color5.jpg','0'),(612,'-color6-','../smilies/color6.jpg','0'),(613,'-color7-','../smilies/color7.jpg','0'),(614,'-meetwap-','../meetwap2.png','0');
/*!40000 ALTER TABLE `ibwff_smilies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_status`
--

DROP TABLE IF EXISTS `ibwff_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `status` varchar(255) NOT NULL,
  `time` varchar(20) NOT NULL,
  `lastupdate` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_status`
--

LOCK TABLES `ibwff_status` WRITE;
/*!40000 ALTER TABLE `ibwff_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_statusdislike`
--

DROP TABLE IF EXISTS `ibwff_statusdislike`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_statusdislike` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `statusid` int(100) NOT NULL DEFAULT '0',
  `uid` int(100) NOT NULL DEFAULT '0',
  `lrate` char(1) NOT NULL,
  `ltime` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_statusdislike`
--

LOCK TABLES `ibwff_statusdislike` WRITE;
/*!40000 ALTER TABLE `ibwff_statusdislike` DISABLE KEYS */;
INSERT INTO `ibwff_statusdislike` (`id`, `statusid`, `uid`, `lrate`, `ltime`) VALUES (1,42,9,'','1418452730'),(2,43,4,'','1418465229'),(3,48,29,'','1418498818'),(4,4,1,'','1418557392'),(5,4,54,'','1419130515'),(6,49,56,'','1419642846'),(7,4,56,'','1419642893'),(8,13,56,'','1419643005'),(9,6,37,'','1419694768'),(10,57,1,'','1419877338'),(11,57,15,'','1420249754'),(12,56,64,'','1421081051');
/*!40000 ALTER TABLE `ibwff_statusdislike` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_statuslike`
--

DROP TABLE IF EXISTS `ibwff_statuslike`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_statuslike` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `statusid` int(100) NOT NULL DEFAULT '0',
  `uid` int(100) NOT NULL DEFAULT '0',
  `lrate` char(1) NOT NULL,
  `ltime` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=132 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_statuslike`
--

LOCK TABLES `ibwff_statuslike` WRITE;
/*!40000 ALTER TABLE `ibwff_statuslike` DISABLE KEYS */;
INSERT INTO `ibwff_statuslike` (`id`, `statusid`, `uid`, `lrate`, `ltime`) VALUES (1,5,1,'','1415792280'),(2,8,62,'','1415897166'),(3,6,60,'','1415897350'),(4,9,60,'','1415903862'),(5,7,60,'','1415903974'),(6,3,60,'','1415905549'),(7,7,7,'','1415937396'),(8,7,34,'','1415955188'),(9,11,13,'','1415973102'),(10,6,1,'','1416020458'),(11,7,46,'','1416024753'),(12,13,46,'','1416026077'),(13,11,46,'','1416063777'),(14,14,19,'','1416080525'),(15,7,62,'','1416109314'),(16,9,100,'','1416116382'),(17,0,62,'','1416117111'),(18,1,60,'','1416123434'),(19,16,60,'','1416151806'),(20,17,60,'','1416219146'),(21,1,115,'','1416308001'),(22,6,114,'','1416308592'),(23,6,19,'','1416309743'),(24,7,76,'','1416408704'),(25,1,102,'','1416464116'),(26,18,60,'','1416465936'),(27,1,5,'','1416471803'),(28,18,134,'','1416480993'),(29,17,136,'','1416489136'),(30,21,136,'','1416490161'),(31,22,147,'','1416553716'),(32,23,2,'','1416566618'),(33,25,144,'','1416574527'),(34,24,134,'','1416574556'),(35,26,5,'','1416590367'),(36,25,134,'','1416629624'),(37,25,1,'','1416640579'),(38,31,102,'','1416684526'),(39,18,27,'','1416821922'),(40,18,17,'','1416993371'),(41,17,194,'','1418195895'),(42,18,200,'','1418215701'),(43,18,13,'','1418216661'),(44,18,160,'','1418221571'),(45,38,1,'','1418286540'),(46,39,9,'','1418349615'),(47,18,1,'','1418361139'),(48,40,9,'','1418367929'),(49,18,29,'','1418387562'),(50,46,4,'','1418472159'),(51,47,4,'','1418472217'),(52,40,4,'','1418483095'),(53,6,4,'','1418493897'),(54,47,54,'','1418495436'),(55,48,54,'','1418497653'),(56,48,4,'','1418498044'),(57,48,9,'','1418523544'),(58,6,54,'','1418542222'),(59,39,18,'','1418558282'),(60,6,64,'','1418564805'),(61,40,29,'','1418578265'),(62,4,9,'','1418578398'),(63,47,64,'','1418621576'),(64,6,83,'','1418661169'),(65,50,1,'','1418710952'),(66,6,90,'','1418717457'),(67,50,9,'','1418820497'),(68,40,101,'','1418950129'),(69,52,111,'','1419066362'),(70,47,114,'','1419127655'),(71,6,47,'','1419141968'),(72,11,76,'','1419163763'),(73,52,117,'','1419223660'),(74,47,69,'','1419229598'),(75,54,2,'','1419326980'),(76,6,15,'','1419343087'),(77,57,15,'','1419343209'),(78,7,17,'','1419351743'),(79,57,2,'','1419393092'),(80,57,1,'','1419398806'),(81,6,27,'','1419407924'),(82,54,15,'','1419410431'),(83,4,29,'','1419448076'),(84,54,35,'','1419522263'),(85,57,8,'','1419699642'),(86,57,81,'','1419702254'),(87,63,81,'','1419729407'),(88,6,81,'','1419743494'),(89,14,81,'','1419743748'),(90,7,81,'','1419748477'),(91,4,36,'','1419843636'),(92,61,1,'','1419858499'),(93,65,2,'','1419860769'),(94,5,81,'','1419905118'),(95,60,15,'','1420112366'),(96,5,109,'','1420122061'),(97,65,28,'','1420169192'),(98,65,20,'','1420192250'),(99,66,146,'','1420216475'),(100,65,140,'','1420223643'),(101,5,20,'','1420229471'),(102,70,20,'','1420229682'),(103,71,153,'','1420254126'),(104,5,154,'','1420258307'),(105,67,137,'','1420272417'),(106,57,169,'','1420289632'),(107,5,169,'','1420289796'),(108,5,15,'','1420294865'),(109,57,154,'','1420298071'),(110,73,161,'','1420305606'),(111,77,201,'','1420725532'),(112,0,14,'','1420823870'),(113,57,14,'','1420824274'),(114,5,16,'','1420824919'),(115,65,6,'','1420955164'),(116,5,60,'','1421074166'),(117,80,61,'','1421075951'),(118,83,64,'','1421081264'),(119,60,64,'','1421081703'),(120,5,17,'','1421083656'),(121,48,14,'','1421118465'),(122,5,18,'','1421210346'),(123,5,68,'','1421313904'),(124,5,70,'','1421320789'),(125,5,84,'','1421570256'),(126,40,84,'','1421580319'),(127,38,84,'','1421583937'),(128,13,84,'','1421585410'),(129,70,84,'','1421587229'),(130,60,84,'','1421596842'),(131,86,84,'','1421649825');
/*!40000 ALTER TABLE `ibwff_statuslike` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_storyposts`
--

DROP TABLE IF EXISTS `ibwff_storyposts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_storyposts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` text NOT NULL,
  `tid` int(11) NOT NULL DEFAULT '0',
  `uid` int(11) NOT NULL DEFAULT '0',
  `dtpost` varchar(100) NOT NULL DEFAULT '0',
  `reported` char(1) NOT NULL DEFAULT '0',
  `quote` int(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_storyposts`
--

LOCK TABLES `ibwff_storyposts` WRITE;
/*!40000 ALTER TABLE `ibwff_storyposts` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_storyposts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_storyrate`
--

DROP TABLE IF EXISTS `ibwff_storyrate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_storyrate` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `systemid` int(100) NOT NULL DEFAULT '0',
  `uid` int(100) NOT NULL DEFAULT '0',
  `time` int(100) NOT NULL DEFAULT '0',
  `rate` char(1) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_storyrate`
--

LOCK TABLES `ibwff_storyrate` WRITE;
/*!40000 ALTER TABLE `ibwff_storyrate` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_storyrate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_storys`
--

DROP TABLE IF EXISTS `ibwff_storys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_storys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET latin1 NOT NULL,
  `fid` int(11) NOT NULL DEFAULT '0',
  `authorid` int(11) NOT NULL DEFAULT '0',
  `text` longtext CHARACTER SET latin1 NOT NULL,
  `pinned` char(1) CHARACTER SET latin1 NOT NULL DEFAULT '0',
  `crdate` int(100) NOT NULL DEFAULT '0',
  `lastpost` int(100) NOT NULL DEFAULT '0',
  `closed` char(1) CHARACTER SET latin1 NOT NULL DEFAULT '0',
  `views` int(11) NOT NULL DEFAULT '0',
  `reported` int(11) NOT NULL DEFAULT '0',
  `moved` int(11) NOT NULL DEFAULT '0',
  `pollid` int(11) NOT NULL DEFAULT '0',
  `clubid` int(120) NOT NULL DEFAULT '0',
  `type` varchar(100) NOT NULL,
  `validate` int(3) NOT NULL DEFAULT '0',
  `rate` int(100) NOT NULL DEFAULT '0',
  `tags` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_storys`
--

LOCK TABLES `ibwff_storys` WRITE;
/*!40000 ALTER TABLE `ibwff_storys` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_storys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_themes`
--

DROP TABLE IF EXISTS `ibwff_themes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_themes` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `name` varchar(15) NOT NULL DEFAULT '',
  `bgc` varchar(6) NOT NULL DEFAULT '',
  `txc` varchar(6) NOT NULL DEFAULT '',
  `lnk` varchar(50) NOT NULL DEFAULT '',
  `hdc` varchar(6) NOT NULL DEFAULT '',
  `hbg` varchar(6) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_themes`
--

LOCK TABLES `ibwff_themes` WRITE;
/*!40000 ALTER TABLE `ibwff_themes` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_themes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_topics`
--

DROP TABLE IF EXISTS `ibwff_topics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_topics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `fid` int(11) NOT NULL DEFAULT '0',
  `authorid` int(11) NOT NULL DEFAULT '0',
  `text` longtext NOT NULL,
  `pinned` char(1) NOT NULL DEFAULT '0',
  `crdate` int(100) NOT NULL DEFAULT '0',
  `lastpost` int(100) NOT NULL DEFAULT '0',
  `closed` char(1) NOT NULL DEFAULT '0',
  `views` int(11) NOT NULL DEFAULT '0',
  `reported` int(11) NOT NULL DEFAULT '0',
  `moved` int(11) NOT NULL DEFAULT '0',
  `pollid` int(11) NOT NULL DEFAULT '0',
  `type` varchar(1234) NOT NULL,
  `ttyp` int(1) NOT NULL DEFAULT '0',
  `udayhide` int(1) NOT NULL DEFAULT '0',
  `uday_tag` varchar(1000) NOT NULL,
  `uday_vld` varchar(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_topics`
--

LOCK TABLES `ibwff_topics` WRITE;
/*!40000 ALTER TABLE `ibwff_topics` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_topics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_uploads`
--

DROP TABLE IF EXISTS `ibwff_uploads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_uploads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL DEFAULT '0',
  `filename` text NOT NULL,
  `date` varchar(100) NOT NULL DEFAULT '',
  `filesize` text NOT NULL,
  `uip` varchar(20) NOT NULL DEFAULT '',
  `accepted` char(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_uploads`
--

LOCK TABLES `ibwff_uploads` WRITE;
/*!40000 ALTER TABLE `ibwff_uploads` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_uploads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_users`
--

DROP TABLE IF EXISTS `ibwff_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `pass` varchar(250) NOT NULL,
  `birthday` varchar(50) NOT NULL,
  `sex` varchar(10) NOT NULL,
  `location` varchar(100) NOT NULL,
  `cyberpowereragon` char(1) NOT NULL DEFAULT '0',
  `hira_boss_security` int(100) NOT NULL DEFAULT '0',
  `posts` int(100) NOT NULL DEFAULT '0',
  `plusses` int(100) NOT NULL DEFAULT '0',
  `avatar` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `browserm` varchar(100) NOT NULL,
  `ipadd` varchar(15) NOT NULL,
  `lastact` int(100) NOT NULL DEFAULT '0',
  `regdate` int(100) NOT NULL DEFAULT '0',
  `chmsgs` varchar(100) NOT NULL DEFAULT '0',
  `diactivate` int(11) NOT NULL DEFAULT '0',
  `shield` char(1) NOT NULL DEFAULT '0',
  `shouts` int(100) NOT NULL DEFAULT '0',
  `topic` int(11) NOT NULL DEFAULT '0',
  `vip` char(1) NOT NULL DEFAULT '0',
  `budmsg` varchar(100) NOT NULL,
  `lastpnreas` varchar(100) NOT NULL,
  `lastplreas` varchar(100) NOT NULL,
  `lastvst` int(11) NOT NULL,
  `lastseen` varchar(250) NOT NULL,
  `views` int(11) NOT NULL,
  `lastdet` varchar(250) NOT NULL,
  `mood` int(11) NOT NULL,
  `setmood` int(11) NOT NULL,
  `rmood` int(11) NOT NULL,
  `onlinemsg` varchar(30) NOT NULL,
  `popmsg` int(11) NOT NULL,
  `hidden` char(1) NOT NULL,
  `validated` int(11) NOT NULL DEFAULT '1',
  `hvia` char(1) NOT NULL DEFAULT '1',
  `automsgs` char(1) NOT NULL DEFAULT '1',
  `pmood` varchar(50) NOT NULL,
  `gplus` int(100) NOT NULL DEFAULT '0',
  `security3` int(100) NOT NULL DEFAULT '0',
  `security` int(100) NOT NULL DEFAULT '0',
  `security2` int(100) NOT NULL DEFAULT '0',
  `warning` int(100) NOT NULL DEFAULT '0',
  `rp` int(100) NOT NULL DEFAULT '0',
  `pu` int(100) NOT NULL DEFAULT '0',
  `ptime` int(100) NOT NULL DEFAULT '0',
  `plustime` int(100) NOT NULL DEFAULT '0',
  `totaltime` int(100) NOT NULL DEFAULT '0',
  `coins` int(100) NOT NULL DEFAULT '0',
  `sweetboy` int(100) NOT NULL,
  `sweetgirl` int(100) NOT NULL,
  `dangerboy` int(100) NOT NULL,
  `dangergirl` int(100) NOT NULL,
  `logo` int(100) NOT NULL,
  `shoutbox` int(100) NOT NULL,
  `osfahim` varchar(100) NOT NULL DEFAULT 'Unknown OS',
  `pmban` int(100) NOT NULL,
  `postban` int(100) NOT NULL,
  `shoutban` int(11) NOT NULL,
  `complain` int(100) NOT NULL,
  `platform` varchar(100) NOT NULL,
  `states` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `looked` varchar(100) NOT NULL,
  `religious` varchar(100) NOT NULL,
  `interested` varchar(100) NOT NULL,
  `invited` varchar(100) NOT NULL,
  `dairy` int(100) NOT NULL DEFAULT '0',
  `certified` int(100) NOT NULL,
  `money` int(100) NOT NULL DEFAULT '0',
  `gu` int(100) NOT NULL,
  `gtime` int(100) NOT NULL,
  `chatban` int(100) NOT NULL,
  `forumban` int(100) NOT NULL,
  `colorball` int(100) NOT NULL,
  `yellowball` int(100) NOT NULL,
  `blueball` int(100) NOT NULL,
  `redball` int(100) NOT NULL,
  `lotto` int(100) NOT NULL DEFAULT '0',
  `lottotime` varchar(100) NOT NULL,
  `xname` varchar(300) NOT NULL,
  `blnc` int(10) NOT NULL,
  `spu` int(1) NOT NULL,
  `letban` int(2) NOT NULL DEFAULT '0',
  `blogcomban` int(2) NOT NULL DEFAULT '0',
  `info` varchar(500) NOT NULL,
  `pollban` int(2) NOT NULL DEFAULT '0',
  `blogban` int(2) NOT NULL DEFAULT '0',
  `profilemsg` varchar(1000) NOT NULL,
  `placedet` varchar(1000) NOT NULL,
  `showonline` varchar(12) NOT NULL,
  `coverpic` varchar(1234) NOT NULL,
  `verson` varchar(12) NOT NULL,
  `original` varchar(123) NOT NULL,
  `osmafia` varchar(123) NOT NULL,
  `ibwffnick` varchar(40) NOT NULL,
  `country` varchar(100) NOT NULL DEFAULT 'BD',
  `phone` varchar(30) NOT NULL,
  `privacy` int(11) NOT NULL DEFAULT '0',
  `privacy2` int(11) NOT NULL DEFAULT '0',
  `privacy3` int(11) NOT NULL DEFAULT '0',
  `privacy4` int(11) NOT NULL DEFAULT '0',
  `topics` int(100) NOT NULL DEFAULT '0',
  `storys` int(100) NOT NULL DEFAULT '0',
  `storyposts` int(100) NOT NULL DEFAULT '0',
  `chatposts` int(100) NOT NULL DEFAULT '0',
  `bootpbyhira` char(3) NOT NULL DEFAULT '0',
  `banpbyhira` int(3) NOT NULL DEFAULT '0',
  `ipbanpbyhira` int(3) NOT NULL DEFAULT '0',
  `profilepbyhira` int(3) NOT NULL DEFAULT '0',
  `readpbyhira` int(3) NOT NULL DEFAULT '0',
  `shoutpbyhira` int(3) NOT NULL DEFAULT '0',
  `chatpbyhira` int(3) NOT NULL DEFAULT '0',
  `forumpbyhira` int(3) NOT NULL DEFAULT '0',
  `literaturepbyhira` int(3) NOT NULL DEFAULT '0',
  `blogpbyhira` int(3) NOT NULL DEFAULT '0',
  `pollpbyhira` int(3) NOT NULL DEFAULT '0',
  `gallerypbyhira` int(3) NOT NULL DEFAULT '0',
  `announcementpbyhira` int(3) NOT NULL DEFAULT '0',
  `settingpbyhira` int(3) NOT NULL DEFAULT '0',
  `instructionpbyhira` int(3) NOT NULL DEFAULT '0',
  `smiliespbyhira` int(3) NOT NULL DEFAULT '0',
  `blocksitepbyhira` int(3) NOT NULL DEFAULT '0',
  `bedregpbyhira` int(3) NOT NULL DEFAULT '0',
  `badnickpbyhira` int(3) NOT NULL DEFAULT '0',
  `cleardatapbyhira` int(3) NOT NULL DEFAULT '0',
  `pm2allpbyhira` int(3) NOT NULL DEFAULT '0',
  `superpbyhira` int(3) NOT NULL DEFAULT '0',
  `clubpbyhira` int(3) NOT NULL DEFAULT '0',
  `rewardpbyhira` int(3) NOT NULL DEFAULT '0',
  `addpbyhira` int(3) NOT NULL DEFAULT '0',
  `editpbyhira` int(3) NOT NULL DEFAULT '0',
  `vippbyhira` int(3) NOT NULL DEFAULT '0',
  `hiranick` varchar(25) NOT NULL,
  `onlinetoday` int(100) NOT NULL DEFAULT '0',
  `prof` int(2) NOT NULL DEFAULT '0',
  `diary_uday` int(2) NOT NULL DEFAULT '0',
  `pm` int(2) NOT NULL DEFAULT '0',
  `conf` int(2) NOT NULL DEFAULT '0',
  `relreq` int(2) NOT NULL DEFAULT '0',
  `frreq` int(2) NOT NULL DEFAULT '0',
  `sub` int(2) NOT NULL DEFAULT '0',
  `frlist` int(2) NOT NULL DEFAULT '0',
  `apics` int(2) NOT NULL DEFAULT '0',
  `ask` int(2) NOT NULL DEFAULT '0',
  `gbok` int(2) NOT NULL DEFAULT '0',
  `plike` int(2) NOT NULL DEFAULT '0',
  `title_uday` varchar(25) NOT NULL,
  `fn` varchar(1000) NOT NULL,
  `sn` varchar(1000) NOT NULL,
  `mst` varchar(1000) NOT NULL,
  `rg` varchar(1000) NOT NULL,
  `lin` varchar(1000) NOT NULL,
  `ht` varchar(1000) NOT NULL,
  `sat` varchar(1000) NOT NULL,
  `wat` varchar(1000) NOT NULL,
  `mh` varchar(1000) NOT NULL,
  `ms` varchar(1000) NOT NULL,
  `ir` varchar(1000) NOT NULL,
  `pf` varchar(1000) NOT NULL,
  `bh` varchar(1000) NOT NULL,
  `gh` varchar(1000) NOT NULL,
  `team` varchar(1000) NOT NULL,
  `band` varchar(1000) NOT NULL,
  `music` varchar(1000) NOT NULL,
  `show` varchar(1000) NOT NULL,
  `food` varchar(1000) NOT NULL,
  `athr` varchar(1000) NOT NULL,
  `movie` varchar(1000) NOT NULL,
  `animal` varchar(1000) NOT NULL,
  `place` varchar(1000) NOT NULL,
  `thing` varchar(1000) NOT NULL,
  `mam` varchar(1000) NOT NULL,
  `height` varchar(1000) NOT NULL,
  `weight` varchar(1000) NOT NULL,
  `body` varchar(1000) NOT NULL,
  `orgin` varchar(1000) NOT NULL,
  `hair` varchar(1000) NOT NULL,
  `eye` varchar(1000) NOT NULL,
  `teamx` varchar(1000) NOT NULL,
  `bandx` varchar(1000) NOT NULL,
  `musicx` varchar(1000) NOT NULL,
  `showx` varchar(1000) NOT NULL,
  `foodx` varchar(1000) NOT NULL,
  `athrx` varchar(1000) NOT NULL,
  `moviex` varchar(1000) NOT NULL,
  `animalx` varchar(1000) NOT NULL,
  `placex` varchar(1000) NOT NULL,
  `thingx` varchar(1000) NOT NULL,
  `mamx` varchar(1000) NOT NULL,
  `pointpbyuday` int(2) NOT NULL DEFAULT '0',
  `balancepbyuday` int(2) NOT NULL DEFAULT '0',
  `gppbyuday` int(2) NOT NULL DEFAULT '0',
  `gcpbyuday` int(2) NOT NULL DEFAULT '0',
  `wrpbyuday` int(2) NOT NULL DEFAULT '0',
  `depbyuday` int(2) NOT NULL DEFAULT '0',
  `sdpbyuday` int(2) NOT NULL DEFAULT '0',
  `pmpbyuday` int(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_users`
--

LOCK TABLES `ibwff_users` WRITE;
/*!40000 ALTER TABLE `ibwff_users` DISABLE KEYS */;
INSERT INTO `ibwff_users` (`id`, `name`, `pass`, `birthday`, `sex`, `location`, `cyberpowereragon`, `hira_boss_security`, `posts`, `plusses`, `avatar`, `email`, `browserm`, `ipadd`, `lastact`, `regdate`, `chmsgs`, `diactivate`, `shield`, `shouts`, `topic`, `vip`, `budmsg`, `lastpnreas`, `lastplreas`, `lastvst`, `lastseen`, `views`, `lastdet`, `mood`, `setmood`, `rmood`, `onlinemsg`, `popmsg`, `hidden`, `validated`, `hvia`, `automsgs`, `pmood`, `gplus`, `security3`, `security`, `security2`, `warning`, `rp`, `pu`, `ptime`, `plustime`, `totaltime`, `coins`, `sweetboy`, `sweetgirl`, `dangerboy`, `dangergirl`, `logo`, `shoutbox`, `osfahim`, `pmban`, `postban`, `shoutban`, `complain`, `platform`, `states`, `status`, `looked`, `religious`, `interested`, `invited`, `dairy`, `certified`, `money`, `gu`, `gtime`, `chatban`, `forumban`, `colorball`, `yellowball`, `blueball`, `redball`, `lotto`, `lottotime`, `xname`, `blnc`, `spu`, `letban`, `blogcomban`, `info`, `pollban`, `blogban`, `profilemsg`, `placedet`, `showonline`, `coverpic`, `verson`, `original`, `osmafia`, `ibwffnick`, `country`, `phone`, `privacy`, `privacy2`, `privacy3`, `privacy4`, `topics`, `storys`, `storyposts`, `chatposts`, `bootpbyhira`, `banpbyhira`, `ipbanpbyhira`, `profilepbyhira`, `readpbyhira`, `shoutpbyhira`, `chatpbyhira`, `forumpbyhira`, `literaturepbyhira`, `blogpbyhira`, `pollpbyhira`, `gallerypbyhira`, `announcementpbyhira`, `settingpbyhira`, `instructionpbyhira`, `smiliespbyhira`, `blocksitepbyhira`, `bedregpbyhira`, `badnickpbyhira`, `cleardatapbyhira`, `pm2allpbyhira`, `superpbyhira`, `clubpbyhira`, `rewardpbyhira`, `addpbyhira`, `editpbyhira`, `vippbyhira`, `hiranick`, `onlinetoday`, `prof`, `diary_uday`, `pm`, `conf`, `relreq`, `frreq`, `sub`, `frlist`, `apics`, `ask`, `gbok`, `plike`, `title_uday`, `fn`, `sn`, `mst`, `rg`, `lin`, `ht`, `sat`, `wat`, `mh`, `ms`, `ir`, `pf`, `bh`, `gh`, `team`, `band`, `music`, `show`, `food`, `athr`, `movie`, `animal`, `place`, `thing`, `mam`, `height`, `weight`, `body`, `orgin`, `hair`, `eye`, `teamx`, `bandx`, `musicx`, `showx`, `foodx`, `athrx`, `moviex`, `animalx`, `placex`, `thingx`, `mamx`, `pointpbyuday`, `balancepbyuday`, `gppbyuday`, `gcpbyuday`, `wrpbyuday`, `depbyuday`, `sdpbyuday`, `pmpbyuday`) VALUES (1,'xtrem','1063bd2b59244fad952754a2cdb4f42b','2010-01-01','M','bd','5',0,0,86497,'','','Opera','103.242.23.176',1422597527,1422339458,'0',0,'0',1,0,'0','','','Last Status Changed: [King Of The King!]',1422353864,'',4,'',0,0,0,'',0,'',1,'1','1','',0,0,0,0,0,3000,0,0,869,93449,0,0,0,0,0,0,0,'Unknown OS',0,0,0,0,'','','','','','bd','',0,0,0,0,0,0,0,0,0,0,0,0,'','',0,0,0,0,'',0,0,'','','','','','Android 4.4.2; SM','J2ME-Opera Mini ','[King Of The King!]','','',0,0,0,0,0,0,0,0,'1',1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,'Xtrem',4246,0,0,0,0,0,0,0,0,0,0,0,0,'','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','',1,1,1,1,1,1,1,1),(2,'admin2','1063bd2b59244fad952754a2cdb4f42b','2010-01-01','M','bd','0',0,0,0,'','bd@nn.tk','Opera','119.30.45.198',1422339524,1422339516,'0',0,'0',0,0,'0','','','',0,'',1,'',0,0,0,'',0,'',1,'1','1','',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'Unknown OS',0,0,0,0,'','','','','','bd','',0,0,0,0,0,0,0,0,0,0,0,0,'','',0,0,0,0,'',0,0,'','','','','','Android 4.4.2; SM','J2ME-Opera Mini ','','','C',0,0,0,0,0,0,0,0,'0',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'admin2',0,0,0,0,0,0,0,0,0,0,0,0,0,'','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','',0,0,0,0,0,0,0,0),(3,'Chatgirl','1063bd2b59244fad952754a2cdb4f42b','','F','bd','0',0,0,0,'','','','119.30.45.198',1422614231,1422339608,'0',0,'0',0,0,'0','','','',0,'',2,'',0,0,0,'',0,'',1,'1','1','',0,0,0,0,0,0,0,0,0,18000,0,0,0,0,0,0,0,'Unknown OS',0,0,0,0,'','','','','','','',0,0,0,0,0,0,0,0,0,0,0,0,'','',0,0,0,0,'',0,0,'','','','','','','','','','',0,0,0,0,0,0,0,0,'0',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'Chatgirl',0,0,0,0,0,0,0,0,0,0,0,0,0,'','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','',0,0,0,0,0,0,0,0),(4,'aronno','a668228808ef37517243b4d18d3fa9a4','2010-01-01','M','feni','0',0,0,1497,'','tgtgtg','Opera','42.0.7.247',1422495866,1422344398,'0',0,'0',1,0,'0','','','Stay whit us',1422462219,'',3,'',0,0,0,'',0,'',1,'1','1','',0,0,0,0,0,0,0,0,23,1271,0,0,0,0,0,0,0,'Unknown OS',0,0,0,0,'','','','','','tgtgtg','',0,0,0,0,0,0,0,0,0,0,0,0,'','',0,0,0,0,'',0,0,'','','','','','Opera 9.80','J2ME-Opera Mini ','','','01',0,0,0,0,0,0,0,0,'0',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'aronno',1271,0,0,0,0,0,0,0,0,0,0,0,0,'','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','',0,0,0,0,0,0,0,0),(5,'tareqsir','437599f1ea3514f8969f161a6606ce18','2010-01-01','M','sghh','0',0,0,16000,'','ths@gmail.com ','Opera','202.134.8.143',1422614231,1422596567,'0',0,'0',0,0,'0','','','Testing.....',1422597094,'',12,'',0,0,0,'',0,'',1,'1','1','',0,0,0,0,0,0,0,0,25,549,0,0,0,0,0,0,0,'Unknown OS',0,0,0,0,'','','','','','vbhh','',0,1,0,0,0,0,0,0,0,0,0,0,'','',0,0,0,0,'',0,0,'','','','','','Android 4.2.2; en','J2ME-Opera Mini ','','','',0,0,0,0,0,0,0,0,'0',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'tareqsir',549,0,0,0,0,0,0,0,0,0,0,0,0,'','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','',0,0,0,0,0,0,0,0);
/*!40000 ALTER TABLE `ibwff_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_usersecurity`
--

DROP TABLE IF EXISTS `ibwff_usersecurity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_usersecurity` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `uid` int(100) NOT NULL DEFAULT '0',
  `intcode` int(5) NOT NULL DEFAULT '0',
  `varcode` varchar(5) NOT NULL DEFAULT '',
  `browser` varchar(100) NOT NULL DEFAULT '',
  `status` int(100) NOT NULL DEFAULT '0',
  `time` int(100) NOT NULL DEFAULT '0',
  `view` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_usersecurity`
--

LOCK TABLES `ibwff_usersecurity` WRITE;
/*!40000 ALTER TABLE `ibwff_usersecurity` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_usersecurity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ibwff_xinfo`
--

DROP TABLE IF EXISTS `ibwff_xinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ibwff_xinfo` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `uid` int(100) NOT NULL DEFAULT '0',
  `gmailun` varchar(100) NOT NULL DEFAULT '',
  `gmailpw` blob NOT NULL,
  `country` varchar(50) NOT NULL DEFAULT '',
  `city` varchar(50) NOT NULL DEFAULT '',
  `street` varchar(50) NOT NULL DEFAULT '',
  `timezone` char(3) NOT NULL DEFAULT '',
  `height` varchar(10) NOT NULL DEFAULT '',
  `weight` varchar(10) NOT NULL DEFAULT '',
  `phoneno` varchar(20) NOT NULL DEFAULT '',
  `likes` varchar(250) NOT NULL DEFAULT '',
  `deslikes` varchar(250) NOT NULL DEFAULT '',
  `realname` varchar(100) NOT NULL DEFAULT '',
  `racerel` varchar(100) NOT NULL DEFAULT '',
  `hairtype` varchar(50) NOT NULL DEFAULT '',
  `eyescolor` varchar(10) NOT NULL DEFAULT '',
  `profession` varchar(100) NOT NULL DEFAULT '',
  `habitsb` varchar(250) NOT NULL DEFAULT '',
  `habitsg` varchar(250) NOT NULL DEFAULT '',
  `favsport` varchar(100) NOT NULL DEFAULT '',
  `favmusic` varchar(100) NOT NULL DEFAULT '',
  `moretext` blob NOT NULL,
  `sitedscr` varchar(200) NOT NULL DEFAULT '',
  `budsonly` char(1) NOT NULL DEFAULT '1',
  `sexpre` char(1) NOT NULL DEFAULT '',
  `gmailchk` int(10) NOT NULL DEFAULT '30',
  `gmaillch` int(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ibwff_xinfo`
--

LOCK TABLES `ibwff_xinfo` WRITE;
/*!40000 ALTER TABLE `ibwff_xinfo` DISABLE KEYS */;
/*!40000 ALTER TABLE `ibwff_xinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `network`
--

DROP TABLE IF EXISTS `network`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `network` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `subone` varchar(50) NOT NULL DEFAULT '',
  `subtwo` varchar(50) NOT NULL DEFAULT '',
  `isp` text NOT NULL,
  `country` text NOT NULL,
  `flag` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=229 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `network`
--

LOCK TABLES `network` WRITE;
/*!40000 ALTER TABLE `network` DISABLE KEYS */;
INSERT INTO `network` (`id`, `subone`, `subtwo`, `isp`, `country`, `flag`) VALUES (29,'202.56.0.0','202.255.255.255','Grameen Phone','Bangladesh','bd.gif'),(40,'119.30.34.1','119.30.255.255','GrameenPhone','Bangladesh','bd.gif'),(87,'58.145.168.37','58.145.255.255','Warid Telecom','Bangladesh','bd.gif'),(130,'10.88.0.0','10.88.255.255','Aktel Telecom','Bangladesh','bd.gif'),(131,'195.189.142.0','195.189.143.255','Opera Software Norway','Proxy',''),(150,'203.22.194.218','203.223.255.255','Banglalink GSM','Bangladesh','bd.gif'),(151,'123.49.3.58','123.49.255.255','TeleTalk','Bangladesh','bd.gif'),(216,'202.134.8.0','202.134.15.255','Robi Internet','Bangladesh','bd.gif'),(219,'42.0.5.146','42.145.155.155','Airtel Internet','Bangladesh','bd.gif'),(220,'42.0.6.146','42.0.6.146','Airtel Internet','Bangladesh','bd.gif'),(223,'140.0.6.146','142.145.155.155','Robi internet','Bangladesh','bd.gif'),(224,'91.0.96.76','91.203.96.76','Proxy Server','Bangladesh','bd.gif'),(225,'42.0.5.100','42.0.5.100','Airtel Internet','Bangladesh','bd.gif'),(226,'42.0.5.36','42.0.6.36','Airtel Internet','Bangladesh','bd.gif'),(227,'70.39.0.223','70.39.186.225','UC Web Proxy','Bangladesh','bd.gif'),(228,'115.150.10.0','115.164.170.170','Unknown','Malaysia','ml.gif');
/*!40000 ALTER TABLE `network` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `onib2_settings`
--

DROP TABLE IF EXISTS `onib2_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `onib2_settings` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '',
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=64 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `onib2_settings`
--

LOCK TABLES `onib2_settings` WRITE;
/*!40000 ALTER TABLE `onib2_settings` DISABLE KEYS */;
INSERT INTO `onib2_settings` (`id`, `name`, `value`) VALUES (1,'sesexp','36'),(2,'Fri 14 Dec 2012 - 12:22','108'),(3,'4ummsg',''),(4,'Counter','160910'),(5,'pmaf','5'),(6,'reg','0'),(7,'fview',''),(8,'lastbpm','2014-04-05'),(9,'sitename','LovelyBD.Com'),(10,'siteage','0'),(11,'vldtn','0'),(32,'blogpoint','10'),(13,'chpluss',''),(33,'clpluss','13'),(16,'blpluss',''),(17,'themes','Styles.css'),(18,'popupaf','5'),(19,'regaf','5'),(20,'shoutaf','5'),(21,'cpoint','1'),(22,'spoint','2'),(23,'lpoint','3'),(24,'hpoint','4'),(25,'mkfpoint','5'),(26,'fcompoint','6'),(27,'litpoint','7'),(28,'litcompoint','8'),(29,'blogneedpoint','9'),(30,'blogcompoint','11'),(31,'fpluss','13'),(34,'nmpluss','50'),(35,'newclubpoint','50'),(36,'memberpoint','200'),(37,'junmemberpoint','500'),(38,'senmemberpoint','1000'),(39,'expellerpoint','4000'),(40,'mrsmispoint','7000'),(41,'pppoint','8000'),(42,'king','10000'),(43,'kok','10001'),(44,'knightpoint','2100'),(45,'expartpoint','6000'),(46,'fmvldtn','0'),(47,'litvldtn','0'),(48,'pollvldtn','0'),(49,'blogvldtn','0'),(50,'ntitle','2'),(51,'cntitle','13'),(52,'lnktitle','1'),(53,'cntmsg','gg jhnyuuju rftretfgre'),(54,'ntcmsg','na ns ns'),(55,'lnkmsg','meetwap'),(56,'insmsg','CoolDhaka Adult Community!'),(57,'institle',''),(58,'pollc_uday','2'),(59,'poll_uday','1'),(60,'junvip_uday','5000'),(61,'senvip_uday','10000'),(62,'tpcval','0'),(63,'artval','0');
/*!40000 ALTER TABLE `onib2_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `onib3_settings`
--

DROP TABLE IF EXISTS `onib3_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `onib3_settings` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '',
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=64 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `onib3_settings`
--

LOCK TABLES `onib3_settings` WRITE;
/*!40000 ALTER TABLE `onib3_settings` DISABLE KEYS */;
INSERT INTO `onib3_settings` (`id`, `name`, `value`) VALUES (1,'sesexp','36'),(2,'Fri 14 Dec 2012 - 12:22','108'),(3,'4ummsg',''),(4,'Counter','160910'),(5,'pmaf','5'),(6,'reg','0'),(7,'fview',''),(8,'lastbpm','2014-04-05'),(9,'sitename','LovelyBD.Com'),(10,'siteage','0'),(11,'vldtn','0'),(32,'blogpoint','10'),(13,'chpluss',''),(33,'clpluss','13'),(16,'blpluss',''),(17,'themes','Styles.css'),(18,'popupaf','5'),(19,'regaf','5'),(20,'shoutaf','5'),(21,'cpoint','1'),(22,'spoint','2'),(23,'lpoint','3'),(24,'hpoint','4'),(25,'mkfpoint','5'),(26,'fcompoint','6'),(27,'litpoint','7'),(28,'litcompoint','8'),(29,'blogneedpoint','9'),(30,'blogcompoint','11'),(31,'fpluss','13'),(34,'nmpluss','50'),(35,'newclubpoint','50'),(36,'memberpoint','200'),(37,'junmemberpoint','500'),(38,'senmemberpoint','1000'),(39,'expellerpoint','4000'),(40,'mrsmispoint','7000'),(41,'pppoint','8000'),(42,'king','10000'),(43,'kok','10001'),(44,'knightpoint','2100'),(45,'expartpoint','6000'),(46,'fmvldtn','0'),(47,'litvldtn','0'),(48,'pollvldtn','0'),(49,'blogvldtn','0'),(50,'ntitle','2'),(51,'cntitle','13'),(52,'lnktitle','1'),(53,'cntmsg','gg jhnyuuju rftretfgre'),(54,'ntcmsg','na ns ns'),(55,'lnkmsg','meetwap'),(56,'insmsg','[left]-line2--line2-[br/]-1-[b][color=purple]Allowed characters in username and password are a-z, 0-9, and -_[br/]-2-Username and Password must contain at least 4 characters[br/]-3-Username must not begin with any symbols or numbers[br/]-4-Username must not contain capitals[br/]Your alternative email will be used to reset[br/]password if you forget your password![/color][/b][br/][b]New Meember Offer[/b][br/]-it-Get 500points Reward or Free Premium[br/]-line2--line2-[/left][br/]'),(57,'institle',''),(58,'pollc_uday','2'),(59,'poll_uday','1'),(60,'junvip_uday','5000'),(61,'senvip_uday','10000'),(62,'tpcval','0'),(63,'artval','0');
/*!40000 ALTER TABLE `onib3_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `onib_clubrate`
--

DROP TABLE IF EXISTS `onib_clubrate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `onib_clubrate` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `uid` int(50) NOT NULL,
  `tid` int(50) NOT NULL,
  `rate` int(5) NOT NULL,
  `time` int(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `onib_clubrate`
--

LOCK TABLES `onib_clubrate` WRITE;
/*!40000 ALTER TABLE `onib_clubrate` DISABLE KEYS */;
/*!40000 ALTER TABLE `onib_clubrate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `onib_quiz`
--

DROP TABLE IF EXISTS `onib_quiz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `onib_quiz` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(200) NOT NULL DEFAULT '',
  `answer` varchar(30) NOT NULL DEFAULT '',
  `difficulty` varchar(12) NOT NULL DEFAULT '',
  `number` int(11) NOT NULL DEFAULT '0',
  `answer1` varchar(50) NOT NULL DEFAULT '',
  `answer2` varchar(50) NOT NULL DEFAULT '',
  `answer3` varchar(50) NOT NULL DEFAULT '',
  `answer4` varchar(50) NOT NULL DEFAULT '',
  `switch` char(3) NOT NULL DEFAULT 'on',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `onib_quiz`
--

LOCK TABLES `onib_quiz` WRITE;
/*!40000 ALTER TABLE `onib_quiz` DISABLE KEYS */;
/*!40000 ALTER TABLE `onib_quiz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `onib_quizc`
--

DROP TABLE IF EXISTS `onib_quizc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `onib_quizc` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `topicid` int(100) NOT NULL DEFAULT '0',
  `qdes` varchar(200) NOT NULL DEFAULT '',
  `time` int(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `onib_quizc`
--

LOCK TABLES `onib_quizc` WRITE;
/*!40000 ALTER TABLE `onib_quizc` DISABLE KEYS */;
INSERT INTO `onib_quizc` (`id`, `topicid`, `qdes`, `time`) VALUES (1,0,'testttt',1421318053),(2,0,'again test',1421318103);
/*!40000 ALTER TABLE `onib_quizc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `onib_quizusers`
--

DROP TABLE IF EXISTS `onib_quizusers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `onib_quizusers` (
  `uid` int(100) NOT NULL DEFAULT '0',
  `easy_question` char(2) NOT NULL DEFAULT '0',
  `easy_next` char(2) NOT NULL DEFAULT '0',
  `med_question` char(2) NOT NULL DEFAULT '0',
  `med_next` char(2) NOT NULL DEFAULT '0',
  `hard_question` char(2) NOT NULL DEFAULT '0',
  `hard_next` char(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `onib_quizusers`
--

LOCK TABLES `onib_quizusers` WRITE;
/*!40000 ALTER TABLE `onib_quizusers` DISABLE KEYS */;
/*!40000 ALTER TABLE `onib_quizusers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `onib_quizw`
--

DROP TABLE IF EXISTS `onib_quizw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `onib_quizw` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `uid` int(100) NOT NULL DEFAULT '0',
  `des` varchar(200) NOT NULL DEFAULT '',
  `pos` varchar(200) NOT NULL DEFAULT '',
  `cname` varchar(200) NOT NULL DEFAULT '',
  `time` int(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `onib_quizw`
--

LOCK TABLES `onib_quizw` WRITE;
/*!40000 ALTER TABLE `onib_quizw` DISABLE KEYS */;
/*!40000 ALTER TABLE `onib_quizw` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `onib_settings`
--

DROP TABLE IF EXISTS `onib_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `onib_settings` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '',
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=64 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `onib_settings`
--

LOCK TABLES `onib_settings` WRITE;
/*!40000 ALTER TABLE `onib_settings` DISABLE KEYS */;
INSERT INTO `onib_settings` (`id`, `name`, `value`) VALUES (1,'sesexp','36'),(2,'Fri 14 Dec 2012 - 12:22','108'),(3,'4ummsg',''),(4,'Counter','160910'),(5,'pmaf','5'),(6,'reg','0'),(7,'fview',''),(8,'lastbpm','2014-04-05'),(9,'sitename','LovelyBD.Com'),(10,'siteage','0'),(11,'vldtn','0'),(32,'blogpoint','10'),(13,'chpluss',''),(33,'clpluss','13'),(16,'blpluss',''),(17,'themes','Styles.css'),(18,'popupaf','5'),(19,'regaf','5'),(20,'shoutaf','5'),(21,'cpoint','1'),(22,'spoint','2'),(23,'lpoint','3'),(24,'hpoint','4'),(25,'mkfpoint','5'),(26,'fcompoint','6'),(27,'litpoint','7'),(28,'litcompoint','8'),(29,'blogneedpoint','9'),(30,'blogcompoint','11'),(31,'fpluss','13'),(34,'nmpluss','50'),(35,'newclubpoint','50'),(36,'memberpoint','200'),(37,'junmemberpoint','500'),(38,'senmemberpoint','1000'),(39,'expellerpoint','4000'),(40,'mrsmispoint','7000'),(41,'pppoint','8000'),(42,'king','10000'),(43,'kok','10001'),(44,'knightpoint','2100'),(45,'expartpoint','6000'),(46,'fmvldtn','0'),(47,'litvldtn','0'),(48,'pollvldtn','0'),(49,'blogvldtn','0'),(50,'ntitle','updating'),(51,'cntitle','1'),(52,'lnktitle',''),(53,'cntmsg','update'),(54,'ntcmsg','updates soon'),(55,'lnkmsg',''),(56,'insmsg','-hi-[b][color=red]@reader@......[/color][/b][br/]-tik-[b][color=deeppink]Meetwap Clubs are small communities that users can create.....[/color][/b][br/]-tik-[b][color=pink]Every community should have things in common and anything else..[/color][/b][br/]-tik-[b][color=blue]you can think of Currently people who have at least 1000 points usually can create clubs,,[/color][/b][br/]-tik-[b][color=pink]Also premium members and vip members can create clubs. A user can create up to maximum of 1 clubsUsing forums, chat or inviting friends etc...[/color][/b][br/]-tik-[b][color=purple]will get you more points,..........[/color][/b][br/]-tik-[b][color=red]You can also get club points, The more users that join and more activities in your club will put ur club on top.[/color][/b][br/][big][u][b]....:: Meetwap Club Updating Cholcha ::....[/b][/u][/big][br/][b][color=blue]Only Premium Members can edit or hide her topics.[/color][/b][br/]'),(57,'institle','Club Rulz'),(58,'pollc_uday','2'),(59,'poll_uday','1'),(60,'junvip_uday','5000'),(61,'senvip_uday','10000'),(62,'tpcval','0'),(63,'artval','0');
/*!40000 ALTER TABLE `onib_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `onib_tickets`
--

DROP TABLE IF EXISTS `onib_tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `onib_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(30) NOT NULL,
  `text` varchar(1000) NOT NULL,
  `staff` varchar(30) NOT NULL,
  `ccid` varchar(50) NOT NULL,
  `creator` int(11) NOT NULL,
  `status` int(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`subject`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `onib_tickets`
--

LOCK TABLES `onib_tickets` WRITE;
/*!40000 ALTER TABLE `onib_tickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `onib_tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `onib_users`
--

DROP TABLE IF EXISTS `onib_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `onib_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `pass` varchar(250) NOT NULL,
  `birthday` varchar(50) NOT NULL,
  `sex` varchar(10) NOT NULL,
  `location` varchar(100) NOT NULL,
  `cyberpowereragon` char(1) NOT NULL DEFAULT '0',
  `hira_boss_security` int(100) NOT NULL DEFAULT '0',
  `posts` int(100) NOT NULL DEFAULT '0',
  `plusses` int(100) NOT NULL DEFAULT '0',
  `avatar` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `browserm` varchar(100) NOT NULL,
  `ipadd` varchar(15) NOT NULL,
  `lastact` int(100) NOT NULL DEFAULT '0',
  `regdate` int(100) NOT NULL DEFAULT '0',
  `chmsgs` varchar(100) NOT NULL DEFAULT '0',
  `diactivate` int(11) NOT NULL DEFAULT '0',
  `shield` char(1) NOT NULL DEFAULT '0',
  `shouts` int(100) NOT NULL DEFAULT '0',
  `topic` int(11) NOT NULL DEFAULT '0',
  `vip` char(1) NOT NULL DEFAULT '0',
  `budmsg` varchar(100) NOT NULL,
  `lastpnreas` varchar(100) NOT NULL,
  `lastplreas` varchar(100) NOT NULL,
  `lastvst` int(11) NOT NULL,
  `lastseen` varchar(250) NOT NULL,
  `views` int(11) NOT NULL,
  `lastdet` varchar(250) NOT NULL,
  `mood` int(11) NOT NULL,
  `setmood` int(11) NOT NULL,
  `rmood` int(11) NOT NULL,
  `onlinemsg` varchar(30) NOT NULL,
  `popmsg` int(11) NOT NULL,
  `hidden` char(1) NOT NULL,
  `validated` int(11) NOT NULL DEFAULT '1',
  `hvia` char(1) NOT NULL DEFAULT '1',
  `automsgs` char(1) NOT NULL DEFAULT '1',
  `pmood` varchar(50) NOT NULL,
  `gplus` int(100) NOT NULL DEFAULT '0',
  `security3` int(100) NOT NULL DEFAULT '0',
  `security` int(100) NOT NULL DEFAULT '0',
  `security2` int(100) NOT NULL DEFAULT '0',
  `warning` int(100) NOT NULL DEFAULT '0',
  `rp` int(100) NOT NULL DEFAULT '0',
  `pu` int(100) NOT NULL DEFAULT '0',
  `ptime` int(100) NOT NULL DEFAULT '0',
  `plustime` int(100) NOT NULL DEFAULT '0',
  `totaltime` int(100) NOT NULL DEFAULT '0',
  `coins` int(100) NOT NULL DEFAULT '0',
  `sweetboy` int(100) NOT NULL,
  `sweetgirl` int(100) NOT NULL,
  `dangerboy` int(100) NOT NULL,
  `dangergirl` int(100) NOT NULL,
  `logo` int(100) NOT NULL,
  `shoutbox` int(100) NOT NULL,
  `osfahim` varchar(100) NOT NULL DEFAULT 'Unknown OS',
  `pmban` int(100) NOT NULL,
  `postban` int(100) NOT NULL,
  `shoutban` int(11) NOT NULL,
  `complain` int(100) NOT NULL,
  `platform` varchar(100) NOT NULL,
  `states` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `looked` varchar(100) NOT NULL,
  `religious` varchar(100) NOT NULL,
  `interested` varchar(100) NOT NULL,
  `invited` varchar(100) NOT NULL,
  `dairy` int(100) NOT NULL DEFAULT '0',
  `certified` int(100) NOT NULL,
  `money` int(100) NOT NULL DEFAULT '0',
  `gu` int(100) NOT NULL,
  `gtime` int(100) NOT NULL,
  `chatban` int(100) NOT NULL,
  `forumban` int(100) NOT NULL,
  `colorball` int(100) NOT NULL,
  `yellowball` int(100) NOT NULL,
  `blueball` int(100) NOT NULL,
  `redball` int(100) NOT NULL,
  `lotto` int(100) NOT NULL DEFAULT '0',
  `lottotime` varchar(100) NOT NULL,
  `xname` varchar(300) NOT NULL,
  `blnc` int(10) NOT NULL,
  `spu` int(1) NOT NULL,
  `letban` int(2) NOT NULL DEFAULT '0',
  `blogcomban` int(2) NOT NULL DEFAULT '0',
  `info` varchar(500) NOT NULL,
  `pollban` int(2) NOT NULL DEFAULT '0',
  `blogban` int(2) NOT NULL DEFAULT '0',
  `profilemsg` varchar(1000) NOT NULL,
  `placedet` varchar(1000) NOT NULL,
  `showonline` varchar(12) NOT NULL,
  `coverpic` varchar(1234) NOT NULL,
  `verson` varchar(12) NOT NULL,
  `original` varchar(123) NOT NULL,
  `osmafia` varchar(123) NOT NULL,
  `ibwffnick` varchar(40) NOT NULL,
  `country` varchar(100) NOT NULL DEFAULT 'BD',
  `phone` varchar(30) NOT NULL,
  `privacy` int(11) NOT NULL DEFAULT '0',
  `privacy2` int(11) NOT NULL DEFAULT '0',
  `privacy3` int(11) NOT NULL DEFAULT '0',
  `privacy4` int(11) NOT NULL DEFAULT '0',
  `topics` int(100) NOT NULL DEFAULT '0',
  `storys` int(100) NOT NULL DEFAULT '0',
  `storyposts` int(100) NOT NULL DEFAULT '0',
  `chatposts` int(100) NOT NULL DEFAULT '0',
  `bootpbyhira` char(3) NOT NULL DEFAULT '0',
  `banpbyhira` int(3) NOT NULL DEFAULT '0',
  `ipbanpbyhira` int(3) NOT NULL DEFAULT '0',
  `profilepbyhira` int(3) NOT NULL DEFAULT '0',
  `readpbyhira` int(3) NOT NULL DEFAULT '0',
  `shoutpbyhira` int(3) NOT NULL DEFAULT '0',
  `chatpbyhira` int(3) NOT NULL DEFAULT '0',
  `forumpbyhira` int(3) NOT NULL DEFAULT '0',
  `literaturepbyhira` int(3) NOT NULL DEFAULT '0',
  `blogpbyhira` int(3) NOT NULL DEFAULT '0',
  `pollpbyhira` int(3) NOT NULL DEFAULT '0',
  `gallerypbyhira` int(3) NOT NULL DEFAULT '0',
  `announcementpbyhira` int(3) NOT NULL DEFAULT '0',
  `settingpbyhira` int(3) NOT NULL DEFAULT '0',
  `instructionpbyhira` int(3) NOT NULL DEFAULT '0',
  `smiliespbyhira` int(3) NOT NULL DEFAULT '0',
  `blocksitepbyhira` int(3) NOT NULL DEFAULT '0',
  `bedregpbyhira` int(3) NOT NULL DEFAULT '0',
  `badnickpbyhira` int(3) NOT NULL DEFAULT '0',
  `cleardatapbyhira` int(3) NOT NULL DEFAULT '0',
  `pm2allpbyhira` int(3) NOT NULL DEFAULT '0',
  `superpbyhira` int(3) NOT NULL DEFAULT '0',
  `clubpbyhira` int(3) NOT NULL DEFAULT '0',
  `rewardpbyhira` int(3) NOT NULL DEFAULT '0',
  `addpbyhira` int(3) NOT NULL DEFAULT '0',
  `editpbyhira` int(3) NOT NULL DEFAULT '0',
  `vippbyhira` int(3) NOT NULL DEFAULT '0',
  `hiranick` varchar(25) NOT NULL,
  `onlinetoday` int(100) NOT NULL DEFAULT '0',
  `prof` int(2) NOT NULL DEFAULT '0',
  `diary_uday` int(2) NOT NULL DEFAULT '0',
  `pm` int(2) NOT NULL DEFAULT '0',
  `conf` int(2) NOT NULL DEFAULT '0',
  `relreq` int(2) NOT NULL DEFAULT '0',
  `frreq` int(2) NOT NULL DEFAULT '0',
  `sub` int(2) NOT NULL DEFAULT '0',
  `frlist` int(2) NOT NULL DEFAULT '0',
  `apics` int(2) NOT NULL DEFAULT '0',
  `ask` int(2) NOT NULL DEFAULT '0',
  `gbok` int(2) NOT NULL DEFAULT '0',
  `plike` int(2) NOT NULL DEFAULT '0',
  `title_uday` varchar(25) NOT NULL,
  `fn` varchar(1000) NOT NULL,
  `sn` varchar(1000) NOT NULL,
  `mst` varchar(1000) NOT NULL,
  `rg` varchar(1000) NOT NULL,
  `lin` varchar(1000) NOT NULL,
  `ht` varchar(1000) NOT NULL,
  `sat` varchar(1000) NOT NULL,
  `wat` varchar(1000) NOT NULL,
  `mh` varchar(1000) NOT NULL,
  `ms` varchar(1000) NOT NULL,
  `ir` varchar(1000) NOT NULL,
  `pf` varchar(1000) NOT NULL,
  `bh` varchar(1000) NOT NULL,
  `gh` varchar(1000) NOT NULL,
  `team` varchar(1000) NOT NULL,
  `band` varchar(1000) NOT NULL,
  `music` varchar(1000) NOT NULL,
  `show` varchar(1000) NOT NULL,
  `food` varchar(1000) NOT NULL,
  `athr` varchar(1000) NOT NULL,
  `movie` varchar(1000) NOT NULL,
  `animal` varchar(1000) NOT NULL,
  `place` varchar(1000) NOT NULL,
  `thing` varchar(1000) NOT NULL,
  `mam` varchar(1000) NOT NULL,
  `height` varchar(1000) NOT NULL,
  `weight` varchar(1000) NOT NULL,
  `body` varchar(1000) NOT NULL,
  `orgin` varchar(1000) NOT NULL,
  `hair` varchar(1000) NOT NULL,
  `eye` varchar(1000) NOT NULL,
  `teamx` varchar(1000) NOT NULL,
  `bandx` varchar(1000) NOT NULL,
  `musicx` varchar(1000) NOT NULL,
  `showx` varchar(1000) NOT NULL,
  `foodx` varchar(1000) NOT NULL,
  `athrx` varchar(1000) NOT NULL,
  `moviex` varchar(1000) NOT NULL,
  `animalx` varchar(1000) NOT NULL,
  `placex` varchar(1000) NOT NULL,
  `thingx` varchar(1000) NOT NULL,
  `mamx` varchar(1000) NOT NULL,
  `pointpbyuday` int(2) NOT NULL DEFAULT '0',
  `balancepbyuday` int(2) NOT NULL DEFAULT '0',
  `gppbyuday` int(2) NOT NULL DEFAULT '0',
  `gcpbyuday` int(2) NOT NULL DEFAULT '0',
  `wrpbyuday` int(2) NOT NULL DEFAULT '0',
  `depbyuday` int(2) NOT NULL DEFAULT '0',
  `sdpbyuday` int(2) NOT NULL DEFAULT '0',
  `pmpbyuday` int(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `onib_users`
--

LOCK TABLES `onib_users` WRITE;
/*!40000 ALTER TABLE `onib_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `onib_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staffs`
--

DROP TABLE IF EXISTS `staffs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staffs` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `userid` int(100) NOT NULL DEFAULT '0',
  `code` varchar(100) NOT NULL DEFAULT '',
  `name` varchar(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staffs`
--

LOCK TABLES `staffs` WRITE;
/*!40000 ALTER TABLE `staffs` DISABLE KEYS */;
/*!40000 ALTER TABLE `staffs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uday_ask`
--

DROP TABLE IF EXISTS `uday_ask`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uday_ask` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `aown` int(50) NOT NULL,
  `asign` int(50) NOT NULL,
  `ques` varchar(1000) NOT NULL,
  `ans` varchar(1000) NOT NULL,
  `hide` int(50) NOT NULL,
  `time` int(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uday_ask`
--

LOCK TABLES `uday_ask` WRITE;
/*!40000 ALTER TABLE `uday_ask` DISABLE KEYS */;
/*!40000 ALTER TABLE `uday_ask` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uday_bal`
--

DROP TABLE IF EXISTS `uday_bal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uday_bal` (
  `id` int(222) NOT NULL AUTO_INCREMENT,
  `uid` int(222) NOT NULL,
  `ammount` int(222) NOT NULL,
  `time` int(222) NOT NULL,
  `validate` int(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uday_bal`
--

LOCK TABLES `uday_bal` WRITE;
/*!40000 ALTER TABLE `uday_bal` DISABLE KEYS */;
/*!40000 ALTER TABLE `uday_bal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uday_blgcats`
--

DROP TABLE IF EXISTS `uday_blgcats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uday_blgcats` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uday_blgcats`
--

LOCK TABLES `uday_blgcats` WRITE;
/*!40000 ALTER TABLE `uday_blgcats` DISABLE KEYS */;
/*!40000 ALTER TABLE `uday_blgcats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uday_blgrate`
--

DROP TABLE IF EXISTS `uday_blgrate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uday_blgrate` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `uid` int(50) NOT NULL,
  `tid` int(50) NOT NULL,
  `rate` int(5) NOT NULL,
  `time` int(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uday_blgrate`
--

LOCK TABLES `uday_blgrate` WRITE;
/*!40000 ALTER TABLE `uday_blgrate` DISABLE KEYS */;
INSERT INTO `uday_blgrate` (`id`, `uid`, `tid`, `rate`, `time`) VALUES (1,60,4,4,1415969169),(2,1,4,5,1416011778),(3,62,5,5,1416029286),(4,1,5,5,1416074477),(5,60,9,5,1416403913),(6,102,9,5,1416418938),(7,102,8,5,1416464646),(8,9,15,5,1418487257),(9,1,15,5,1418493401),(10,83,16,5,1418660435),(11,9,16,5,1418660532),(12,1,19,5,1419643763),(13,81,19,5,1419738716),(14,81,18,5,1419738781),(15,81,20,5,1419738838),(16,1,21,5,1420035806),(17,122,21,5,1420210864),(18,127,21,5,1420231630),(19,135,21,3,1420350129),(20,1,22,5,1420644450),(21,84,2,5,1421587037),(22,84,3,5,1421650158);
/*!40000 ALTER TABLE `uday_blgrate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uday_btag`
--

DROP TABLE IF EXISTS `uday_btag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uday_btag` (
  `id` int(50) NOT NULL,
  `tid` int(50) NOT NULL,
  `tags` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uday_btag`
--

LOCK TABLES `uday_btag` WRITE;
/*!40000 ALTER TABLE `uday_btag` DISABLE KEYS */;
/*!40000 ALTER TABLE `uday_btag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uday_cvpic`
--

DROP TABLE IF EXISTS `uday_cvpic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uday_cvpic` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `des` varchar(100) NOT NULL,
  `time` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=65 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uday_cvpic`
--

LOCK TABLES `uday_cvpic` WRITE;
/*!40000 ALTER TABLE `uday_cvpic` DISABLE KEYS */;
INSERT INTO `uday_cvpic` (`id`, `name`, `des`, `time`) VALUES (1,'Mim 2.jpg','sumi',0),(2,'10170943_222240917974405_161516923_n.jpg','',0),(3,'Handgun-Concealed-in-Pants.jpg','',0),(4,'wvms9vimeuz73gnnwz8s.jpg','',0),(5,'10556512_1430760787212699_8597012174917212176_n.jpeg','',0),(6,'images.jpg','',0),(7,'chatgirl(4).jpg','',0),(8,'picsay-1413121028.jpg','P',0),(9,'10527550_510299535768734_4024418947453703397_n.jpeg','My name',0),(10,'10644857_698698333547976_5993010148531811312_n.jpeg','',0),(11,'Screenshot_2014-08-11-13-10-53.png','14/11/2014',0),(12,'20141111221125.jpg','',0),(13,'file.jpeg','',0),(14,'natural-pictures-of-nature-3d-4.jpg','',0),(15,'-asl-.jpg','',0),(16,'IMG_20141116_220319.jpg','',0),(17,'img-20141001-wa0002.jpg','',0),(18,'bartho.jpg','its me',0),(19,'Alone-facebook-profile-picture.jpg','',0),(20,'00.jpg','tarif_joy',0),(21,'00.jpg','tarif_joy',0),(22,'IMG_20141121_214411.JPG','Nothing',0),(23,'Team Logo.jpg','My Team Logo',0),(24,'meet.jpg','',0),(25,'Cool Logo.jpg','',0),(26,'10421308_1571789206373941_43685295231158298_n.jpg','',0),(27,'10012501_1374741112803125_1733620457_n.jpg','',0),(28,'IMG_20141210_145923.jpg','Cover.......',0),(29,'20141209214302.jpg','',0),(30,'IMG-20141212-WA0007.jpg','',0),(31,'Logo2.jpg','',0),(32,'10.jpg','Black_boy',0),(33,'4915672596_16e8da2896_z.jpg','',0),(34,'stock-footage-bangladesh-text-with-fluttering-flag-animation-300x168.jpg','I love Bangladesh ',0),(35,'2014-12-16-06-43-14--1103861145.jpeg','',0),(36,'1013742_622567981087078_800761630_n.jpg','',0),(37,'20141215233728.jpg','',0),(38,'-sm-.jpg','',0),(39,'best-love-quotes.jpg','',0),(40,'IMG_16311679139697.jpeg','',0),(41,'Beautiful_Place.jpg','Sundor lagsa',0),(42,'Shawn T1.jpg','Me',0),(43,'a.jpg','',0),(44,'223792~1.JPG','Ki',0),(45,'CYMERA_20141229_164827.jpg','',0),(46,'Avro(2).jpg','[b][color=red]ThEr3 Â¡$ HuGe Vo!D [br/]ThaT SurrUoUnDs mE[/color][/b]',0),(47,'Rahul-me.jpg','My friend Rahul and me.',0),(48,'RaHin.jpg','-mshy-',0),(49,'Photo0354.jpg','',0),(50,'Getar.jpg','',0),(51,'miss u dear.jpg','',0),(52,'Screenshot0022.jpg','',0),(53,'best-love-quotes.jpg','',0),(54,'8658850122_8b2db084d9_o.jpg','',0),(55,'10500550_87192765952.jpg','',0),(56,'my_sohag(8).jpg','',0),(57,'SAYEED TELECOM FACEBOOK (75).jpg','',0),(58,'oooooooo.jpg','',0),(59,'Bb.jpg','',0),(60,'(4).JPG','Ki',0),(61,'8658850122_8b2db084d9_o.jpg','',0),(62,'o4YBAFSRY-GATuJOAAAu8CT4uhQ990.jpg','',0),(63,'w.jpeg','',0),(64,'1011217_486725011435938_920124373_n.jpg','M',0);
/*!40000 ALTER TABLE `uday_cvpic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uday_ftag`
--

DROP TABLE IF EXISTS `uday_ftag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uday_ftag` (
  `id` int(50) NOT NULL,
  `tid` int(50) NOT NULL,
  `tags` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uday_ftag`
--

LOCK TABLES `uday_ftag` WRITE;
/*!40000 ALTER TABLE `uday_ftag` DISABLE KEYS */;
INSERT INTO `uday_ftag` (`id`, `tid`, `tags`) VALUES (0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,''),(0,0,'');
/*!40000 ALTER TABLE `uday_ftag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uday_galpicdislike13`
--

DROP TABLE IF EXISTS `uday_galpicdislike13`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uday_galpicdislike13` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `uid` int(100) NOT NULL DEFAULT '0',
  `gid` int(200) NOT NULL,
  `time` int(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uday_galpicdislike13`
--

LOCK TABLES `uday_galpicdislike13` WRITE;
/*!40000 ALTER TABLE `uday_galpicdislike13` DISABLE KEYS */;
/*!40000 ALTER TABLE `uday_galpicdislike13` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uday_galpiclike12`
--

DROP TABLE IF EXISTS `uday_galpiclike12`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uday_galpiclike12` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `uid` int(100) NOT NULL DEFAULT '0',
  `gid` int(200) NOT NULL,
  `time` int(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uday_galpiclike12`
--

LOCK TABLES `uday_galpiclike12` WRITE;
/*!40000 ALTER TABLE `uday_galpiclike12` DISABLE KEYS */;
INSERT INTO `uday_galpiclike12` (`id`, `uid`, `gid`, `time`) VALUES (1,60,9,1415905308),(2,60,49,1416300911),(3,60,39,1416403521),(4,136,60,1416490299),(5,60,60,1416539710),(6,9,97,1418626039),(7,111,81,1419061805),(8,111,141,1419179017),(9,111,140,1419179024),(10,111,139,1419179031),(11,111,138,1419179036),(12,111,137,1419179045),(13,111,136,1419179076),(14,111,135,1419179081),(15,111,134,1419179117),(16,120,141,1419179380),(17,120,140,1419179390),(18,120,139,1419179410),(19,120,138,1419179430),(20,120,137,1419179443),(21,43,152,1419604755),(22,15,166,1419708801),(23,81,83,1419779273),(24,146,189,1420215534),(25,146,188,1420215538),(26,146,187,1420215542),(27,146,186,1420215545),(28,146,185,1420215552),(29,146,184,1420215568),(30,146,183,1420215570),(31,146,182,1420215581),(32,146,181,1420215585),(33,146,127,1420215829),(34,92,17,1421509764),(35,92,16,1421509770);
/*!40000 ALTER TABLE `uday_galpiclike12` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uday_gcg`
--

DROP TABLE IF EXISTS `uday_gcg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uday_gcg` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `uid` int(100) NOT NULL DEFAULT '0',
  `coin` int(100) NOT NULL DEFAULT '0',
  `message` varchar(50) NOT NULL DEFAULT '',
  `createtime` int(100) NOT NULL DEFAULT '0',
  `time` int(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=337 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uday_gcg`
--

LOCK TABLES `uday_gcg` WRITE;
/*!40000 ALTER TABLE `uday_gcg` DISABLE KEYS */;
INSERT INTO `uday_gcg` (`id`, `uid`, `coin`, `message`, `createtime`, `time`) VALUES (1,0,0,'[user=7]arif-hasan[/user] just grabbed a G-coin-ld',0,1415631759),(2,0,0,'[user=7]arif-hasan[/user] just grabbed a G-coin-ld',0,1415672227),(3,0,0,'[user=7]arif-hasan[/user] just grabbed a G-coin-ld',0,1415673388),(4,0,0,'[user=9]hm akash[/user] just grabbed a G-coin-lden',0,1415676713),(5,0,0,'[user=7]arif-hasan[/user] just grabbed a G-coin-ld',0,1415678183),(6,0,0,'[user=7]arif-hasan[/user] just grabbed a G-coin-ld',0,1415694408),(7,0,0,'[user=1]admin[/user] just grabbed a G-coin-lden C-',0,1415717726),(8,0,0,'[user=32]miron[/user] just grabbed a G-coin-lden C',0,1415758635),(9,0,0,'[user=32]miron[/user] just grabbed a G-coin-lden C',0,1415759222),(10,0,0,'[user=32]miron[/user] just grabbed a G-coin-lden C',0,1415759753),(11,0,0,'[user=32]miron[/user] just grabbed a G-coin-lden C',0,1415781155),(12,0,0,'[user=19]musa_ahmed[/user] just grabbed a G-coin-l',0,1415802212),(13,0,0,'[user=19]musa_ahmed[/user] just grabbed a G-coin-l',0,1415802563),(14,0,0,'[user=19]musa_ahmed[/user] just grabbed a G-coin-l',0,1415803058),(15,0,0,'[user=19]musa_ahmed[/user] just grabbed a G-coin-l',0,1415803496),(16,0,0,'[user=19]musa_ahmed[/user] just grabbed a G-coin-l',0,1415806922),(17,0,0,'[user=30]anik_hasan[/user] just grabbed a G-coin-l',0,1415891599),(18,0,0,'[user=30]anik_hasan[/user] just grabbed a G-coin-l',0,1415891968),(19,0,0,'[user=30]anik_hasan[/user] just grabbed a G-coin-l',0,1415892479),(20,0,0,'[user=30]anik_hasan[/user] just grabbed a G-coin-l',0,1415893062),(21,0,0,'[user=30]anik_hasan[/user] just grabbed a G-coin-l',0,1415893682),(22,0,0,'[user=30]anik_hasan[/user] just grabbed a G-coin-l',0,1415893960),(23,0,0,'[user=30]anik_hasan[/user] just grabbed a G-coin-l',0,1415894325),(24,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1415952034),(25,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1415952348),(26,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1415952677),(27,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1415952985),(28,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1415953476),(29,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1415954202),(30,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1415954704),(31,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1415955448),(32,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1415955866),(33,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1415956199),(34,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1415956583),(35,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1415957035),(36,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1415957492),(37,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1415957980),(38,0,0,'[user=13]mahabubur57[/user] just grabbed a G-coin-',0,1415958268),(39,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1415958823),(40,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1415974927),(41,0,0,'[user=84]hridoy[/user] just grabbed a G-coin-lden ',0,1415975848),(42,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1415977389),(43,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1415978186),(44,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1415979839),(45,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1415980396),(46,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1416017306),(47,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1416017526),(48,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1416017781),(49,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1416019206),(50,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1416019610),(51,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1416020250),(52,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1416020721),(53,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1416021364),(54,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1416022022),(55,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1416022704),(56,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1416023084),(57,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1416023535),(58,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1416023839),(59,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1416039191),(60,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1416039938),(61,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1416040719),(62,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1416043751),(63,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1416044289),(64,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1416045045),(65,0,0,'[user=19]musa_ahmed[/user] just grabbed a G-coin-l',0,1416060172),(66,0,0,'[user=19]musa_ahmed[/user] just grabbed a G-coin-l',0,1416061144),(67,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1416061487),(68,0,0,'[user=19]musa_ahmed[/user] just grabbed a G-coin-l',0,1416061927),(69,0,0,'[user=19]musa_ahmed[/user] just grabbed a G-coin-l',0,1416062758),(70,0,0,'[user=19]musa_ahmed[/user] just grabbed a G-coin-l',0,1416063145),(71,0,0,'[user=19]musa_ahmed[/user] just grabbed a G-coin-l',0,1416063701),(72,0,0,'[user=19]musa_ahmed[/user] just grabbed a G-coin-l',0,1416064182),(73,0,0,'[user=19]musa_ahmed[/user] just grabbed a G-coin-l',0,1416064453),(74,0,0,'[user=19]musa_ahmed[/user] just grabbed a G-coin-l',0,1416064680),(75,0,0,'[user=19]musa_ahmed[/user] just grabbed a G-coin-l',0,1416065130),(76,0,0,'[user=19]musa_ahmed[/user] just grabbed a G-coin-l',0,1416065352),(77,0,0,'[user=19]musa_ahmed[/user] just grabbed a G-coin-l',0,1416065929),(78,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1416066345),(79,0,0,'[user=19]musa_ahmed[/user] just grabbed a G-coin-l',0,1416066724),(80,0,0,'[user=19]musa_ahmed[/user] just grabbed a G-coin-l',0,1416067015),(81,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1416104267),(82,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1416106716),(83,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1416108950),(84,0,0,'[user=62]sourav[/user] just grabbed a G-coin-lden ',0,1416109250),(85,0,0,'[user=13]mahabubur57[/user] just grabbed a G-coin-',0,1416125347),(86,0,0,'[user=60]dead_sea[/user] just grabbed a G-coin-lde',0,1416126450),(87,0,0,'[user=7]arif-hasan[/user] just grabbed a G-coin-ld',0,1416127060),(88,0,0,'[user=19]musa_ahmed[/user] just grabbed a G-coin-l',0,1416127385),(89,0,0,'[user=19]musa_ahmed[/user] just grabbed a G-coin-l',0,1416151952),(90,0,0,'[user=19]musa_ahmed[/user] just grabbed a G-coin-l',0,1416152640),(91,0,0,'[user=30]anik_hasan[/user] just grabbed a G-coin-l',0,1416302636),(92,0,0,'[user=30]anik_hasan[/user] just grabbed a G-coin-l',0,1416303307),(93,0,0,'[user=30]anik_hasan[/user] just grabbed a G-coin-l',0,1416303698),(94,0,0,'[user=1]admin[/user] just grabbed a G-coin-lden C-',0,1416304369),(95,0,0,'[user=102]king[/user] just grabbed a G-coin-lden C',0,1416319244),(96,0,0,'[user=102]king[/user] just grabbed a G-coin-lden C',0,1416320711),(97,0,0,'[user=102]king[/user] just grabbed a G-coin-lden C',0,1416323866),(98,0,0,'[user=102]king[/user] just grabbed a G-coin-lden C',0,1416324363),(99,0,0,'[user=102]king[/user] just grabbed a G-coin-lden C',0,1416324878),(100,0,0,'[user=7]Arif-Hasan[/user] just grabbed a G-coin-ld',0,1416366716),(101,0,0,'[user=53]prottoy[/user] just grabbed a G-coin-lden',0,1416387859),(102,0,0,'[user=102]king[/user] just grabbed a G-coin-lden C',0,1416476073),(103,0,0,'[user=19]musa_ahmed[/user] just grabbed a G-coin-l',0,1416492012),(104,0,0,'[user=19]musa_ahmed[/user] just grabbed a G-coin-l',0,1416492340),(105,0,0,'[user=102]king[/user] just grabbed a G-coin-lden C',0,1416493047),(106,0,0,'[user=102]king[/user] just grabbed a G-coin-lden C',0,1416493434),(107,0,0,'[user=102]king[/user] just grabbed a G-coin-lden C',0,1416493989),(108,0,0,'[user=102]king[/user] just grabbed a G-coin-lden C',0,1416494370),(109,0,0,'[user=102]king[/user] just grabbed a G-coin-lden C',0,1416494859),(110,0,0,'[user=102]king[/user] just grabbed a G-coin-lden C',0,1416495434),(111,0,0,'[user=102]king[/user] just grabbed a G-coin-lden C',0,1416496002),(112,0,0,'[user=102]king[/user] just grabbed a G-coin-lden C',0,1416496389),(113,0,0,'[user=2]Arif-Hasan[/user] just grabbed a G-coin-ld',0,1416496739),(114,0,0,'[user=13]mahabubur57[/user] just grabbed a G-coin-',0,1416497414),(115,0,0,'[user=2]Arif-Hasan[/user] just grabbed a G-coin-ld',0,1416497791),(116,0,0,'[user=102]king[/user] just grabbed a G-coin-lden C',0,1416498416),(117,0,0,'[user=102]king[/user] just grabbed a G-coin-lden C',0,1416498645),(118,0,0,'[user=102]king[/user] just grabbed a G-coin-lden C',0,1416498972),(119,0,0,'[user=46]nirob[/user] just grabbed a G-coin-lden C',0,1416535585),(120,0,0,'[user=102]king[/user] just grabbed a G-coin-lden C',0,1416540910),(121,0,0,'[user=102]king[/user] just grabbed a G-coin-lden C',0,1416541460),(122,0,0,'[user=102]king[/user] just grabbed a G-coin-lden C',0,1416541924),(123,0,0,'[user=102]king[/user] just grabbed a G-coin-lden C',0,1416542357),(124,0,0,'[user=144]wechat[/user] just grabbed a G-coin-lden',0,1416627432),(125,0,0,'[user=102]king[/user] just grabbed a G-coin-lden C',0,1416627754),(126,0,0,'[user=102]king[/user] just grabbed a G-coin-lden C',0,1416628668),(127,0,0,'[user=2]Arif-Hasan[/user] just grabbed a G-coin-ld',0,1416670290),(128,0,0,'[user=144]wechat[/user] just grabbed a G-coin-lden',0,1416753562),(129,0,0,'[user=144]wechat[/user] just grabbed a G-coin-lden',0,1416756332),(130,0,0,'[user=144]wechat[/user] just grabbed a G-coin-lden',0,1416757551),(131,0,0,'[user=169]noohan[/user] just grabbed a G-coin-lden',0,1416839549),(132,0,0,'[user=19]musa_ahmed[/user] just grabbed a G-coin-l',0,1416843051),(133,0,0,'[user=13]mahabubur57[/user] just grabbed a G-coin-',0,1416905599),(134,0,0,'[user=102]king[/user] just grabbed a G-coin-lden C',0,1416968152),(135,0,0,'[user=13]mahabubur57[/user] just grabbed a G-coin-',0,1416992038),(136,0,0,'[user=17]shawn_sardar[/user] just grabbed a G-coin',0,1416993471),(137,0,0,'[user=102]king[/user] just grabbed a G-coin-lden C',0,1417011801),(138,0,0,'[user=13]mahabubur57[/user] just grabbed a G-coin-',0,1417081435),(139,0,0,'[user=160]rakal-boy[/user] just grabbed a G-coin-l',0,1418221854),(140,0,0,'[user=190]emil_[/user] just grabbed a G-coin-lden ',0,1418225547),(141,0,0,'[user=190]emil_[/user] just grabbed a G-coin-lden ',0,1418225945),(142,0,0,'[user=190]emil_[/user] just grabbed a G-coin-lden ',0,1418226420),(143,0,0,'[user=190]emil_[/user] just grabbed a G-coin-lden ',0,1418226705),(144,0,0,'[user=190]emil_[/user] just grabbed a G-coin-lden ',0,1418227173),(145,0,0,'[user=190]emil_[/user] just grabbed a G-coin-lden ',0,1418264007),(146,0,0,'[user=190]emil_[/user] just grabbed a G-coin-lden ',0,1418264416),(147,0,0,'[user=190]emil_[/user] just grabbed a G-coin-lden ',0,1418264709),(148,0,0,'[user=190]emil_[/user] just grabbed a G-coin-lden ',0,1418265176),(149,0,0,'[user=190]emil_[/user] just grabbed a G-coin-lden ',0,1418265539),(150,0,0,'[user=190]emil_[/user] just grabbed a G-coin-lden ',0,1418265765),(151,0,0,'[user=190]emil_[/user] just grabbed a G-coin-lden ',0,1418267249),(152,0,0,'[user=190]emil_[/user] just grabbed a G-coin-lden ',0,1418267599),(153,0,0,'[user=190]emil_[/user] just grabbed a G-coin-lden ',0,1418267857),(154,0,0,'[user=5]emil_[/user] just grabbed a G-coin-lden C-',0,1418286697),(155,0,0,'[user=5]emil_[/user] just grabbed a G-coin-lden C-',0,1418289207),(156,0,0,'[user=5]emil_[/user] just grabbed a G-coin-lden C-',0,1418291137),(157,0,0,'[user=5]emil_[/user] just grabbed a G-coin-lden C-',0,1418291457),(158,0,0,'[user=5]emil_[/user] just grabbed a G-coin-lden C-',0,1418306783),(159,0,0,'[user=5]emil_[/user] just grabbed a G-coin-lden C-',0,1418308066),(160,0,0,'[user=12]adnin[/user] just grabbed a G-coin-lden C',0,1418354203),(161,0,0,'[user=18]hm imran[/user] just grabbed a G-coin-lde',0,1418372722),(162,0,0,'[user=29]rockstar[/user] just grabbed a G-coin-lde',0,1418373718),(163,0,0,'[user=18]hm imran[/user] just grabbed a G-coin-lde',0,1418392885),(164,0,0,'[user=29]rockstar[/user] just grabbed a G-coin-lde',0,1418393169),(165,0,0,'[user=34]mh_himu_[/user] just grabbed a G-coin-lde',0,1418395579),(166,0,0,'[user=29]rockstar[/user] just grabbed a G-coin-lde',0,1418398178),(167,0,0,'[user=31]linkon_[/user] just grabbed a G-coin-lden',0,1418436600),(168,0,0,'[user=31]linkon_[/user] just grabbed a G-coin-lden',0,1418438733),(169,0,0,'[user=1]admin[/user] just grabbed a G-coin-lden C-',0,1418486283),(170,0,0,'[user=31]linkon_[/user] just grabbed a G-coin-lden',0,1418547457),(171,0,0,'[user=31]linkon_[/user] just grabbed a G-coin-lden',0,1418632822),(172,0,0,'[user=31]linkon_[/user] just grabbed a G-coin-lden',0,1418634133),(173,0,0,'[user=31]linkon_[/user] just grabbed a G-coin-lden',0,1418637038),(174,0,0,'[user=73]upam[/user] just grabbed a G-coin-lden C-',0,1418828862),(175,0,0,'[user=108]rahul[/user] just grabbed a G-coin-lden ',0,1419001370),(176,0,0,'[user=108]rahul[/user] just grabbed a G-coin-lden ',0,1419001693),(177,0,0,'[user=108]rahul[/user] just grabbed a G-coin-lden ',0,1419002062),(178,0,0,'[user=108]rahul[/user] just grabbed a G-coin-lden ',0,1419002953),(179,0,0,'[user=108]rahul[/user] just grabbed a G-coin-lden ',0,1419003441),(180,0,0,'[user=108]rahul[/user] just grabbed a G-coin-lden ',0,1419041214),(181,0,0,'[user=108]rahul[/user] just grabbed a G-coin-lden ',0,1419041787),(182,0,0,'[user=111]shomudro-rp[/user] just grabbed a G-coin',0,1419064818),(183,0,0,'[user=108]rahul[/user] just grabbed a G-coin-lden ',0,1419085337),(184,0,0,'[user=6]Mahabubur57[/user] just grabbed a G-coin-l',0,1419130400),(185,0,0,'[user=6]Mahabubur57[/user] just grabbed a G-coin-l',0,1419130709),(186,0,0,'[user=108]Rahul[/user] just grabbed a G-coin-lden ',0,1419175585),(187,0,0,'[user=7]king[/user] just grabbed a G-coin-lden C-c',0,1419325789),(188,0,0,'[user=5]king%[/user] just grabbed a G-coin-lden C-',0,1419349038),(189,0,0,'[user=6]azhar[/user] just grabbed a G-coin-lden C-',0,1419349366),(190,0,0,'[user=27]shawn[/user] just grabbed a G-coin-lden C',0,1419411285),(191,0,0,'[user=1]casp3rtin[/user] just grabbed a G-coin-lde',0,1419432085),(192,0,0,'[user=7]king[/user] just grabbed a G-coin-lden C-c',0,1419435657),(193,0,0,'[user=7]king[/user] just grabbed a G-coin-lden C-c',0,1419436147),(194,0,0,'[user=27]shawn[/user] just grabbed a G-coin-lden C',0,1419603180),(195,0,0,'[user=27]shawn[/user] just grabbed a G-coin-lden C',0,1419603932),(196,0,0,'[user=43]robin__bin__musa[/user] just grabbed a G-',0,1419604967),(197,0,0,'[user=43]robin__bin__musa[/user] just grabbed a G-',0,1419605418),(198,0,0,'[user=43]robin__bin__musa[/user] just grabbed a G-',0,1419605801),(199,0,0,'[user=43]robin__bin__musa[/user] just grabbed a G-',0,1419606576),(200,0,0,'[user=43]robin__bin__musa[/user] just grabbed a G-',0,1419608465),(201,0,0,'[user=5]king%[/user] just grabbed a G-coin-lden C-',0,1419650778),(202,0,0,'[user=23]captain_[/user] just grabbed a G-coin-lde',0,1419670341),(203,0,0,'[user=81]Avro[/user] just grabbed a G-coin-lden C-',0,1419776613),(204,0,0,'[user=29]tanvir[/user] just grabbed a G-coin-lden ',0,1419824912),(205,0,0,'[user=81]Avro[/user] just grabbed a G-coin-lden C-',0,1419840441),(206,0,0,'[user=29]tanvir[/user] just grabbed a G-coin-lden ',0,1419845414),(207,0,0,'[user=7]king[/user] just grabbed a G-coin-lden C-c',0,1419846179),(208,0,0,'[user=81]Avro[/user] just grabbed a G-coin-lden C-',0,1419861670),(209,0,0,'[user=81]avro[/user] just grabbed a G-coin-lden C-',0,1419863393),(210,0,0,'[user=81]avro[/user] just grabbed a G-coin-lden C-',0,1419864255),(211,0,0,'[user=81]avro[/user] just grabbed a G-coin-lden C-',0,1419868506),(212,0,0,'[user=81]avro[/user] just grabbed a G-coin-lden C-',0,1419905177),(213,0,0,'[user=81]avro[/user] just grabbed a G-coin-lden C-',0,1419906959),(214,0,0,'[user=81]avro[/user] just grabbed a G-coin-lden C-',0,1419907440),(215,0,0,'[user=81]avro[/user] just grabbed a G-coin-lden C-',0,1419908437),(216,0,0,'[user=81]Avro[/user] just grabbed a G-coin-lden C-',0,1419928127),(217,0,0,'[user=8]mahabubur57[/user] just grabbed a G-coin-l',0,1419931788),(218,0,0,'[user=154]aimless_boy[/user] just grabbed a G-coin',0,1420273372),(219,0,0,'[user=137]s.m.sourov[/user] just grabbed a G-coin-',0,1420276060),(220,0,0,'[user=161]sm-rasel[/user] just grabbed a G-coin-ld',0,1420277168),(221,0,0,'[user=161]sm-rasel[/user] just grabbed a G-coin-ld',0,1420277750),(222,0,0,'[user=161]sm-rasel[/user] just grabbed a G-coin-ld',0,1420278449),(223,0,0,'[user=154]aimless_boy[/user] just grabbed a G-coin',0,1420297825),(224,0,0,'[user=129]topu[/user] just grabbed a G-coin-lden C',0,1420386201),(225,0,0,'[user=129]topu[/user] just grabbed a G-coin-lden C',0,1420386521),(226,0,0,'[user=81]Avro[/user] just grabbed a G-coin-lden C-',0,1420424263),(227,0,0,'[user=7]King[/user] just grabbed a G-coin-lden C-c',0,1420425623),(228,0,0,'[user=7]King[/user] just grabbed a G-coin-lden C-c',0,1420426098),(229,0,0,'[user=81]Avro[/user] just grabbed a G-coin-lden C-',0,1420427840),(230,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420445144),(231,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420445485),(232,0,0,'[user=154]aimless_boy[/user] just grabbed a G-coin',0,1420445888),(233,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420446143),(234,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420446578),(235,0,0,'[user=81]Avro[/user] just grabbed a G-coin-lden C-',0,1420447044),(236,0,0,'[user=137]s.m.sourov[/user] just grabbed a G-coin-',0,1420448030),(237,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420448467),(238,0,0,'[user=1]Dhrubo_nill[/user] just grabbed a G-coin-l',0,1420450235),(239,0,0,'[user=124]msylhet[/user] just grabbed a G-coin-lde',0,1420472625),(240,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420473016),(241,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420510683),(242,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420511008),(243,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420511353),(244,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420511856),(245,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420512179),(246,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420512602),(247,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420513054),(248,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420513374),(249,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420513928),(250,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420514571),(251,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420515094),(252,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420515635),(253,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420516015),(254,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420516378),(255,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420516733),(256,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420531235),(257,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420531564),(258,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420532028),(259,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420532380),(260,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420556319),(261,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420556715),(262,0,0,'[user=81]Avro[/user] just grabbed a G-coin-lden C-',0,1420557285),(263,0,0,'[user=154]aimless_boy[/user] just grabbed a G-coin',0,1420558852),(264,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420559153),(265,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420559425),(266,0,0,'[user=154]aimless_boy[/user] just grabbed a G-coin',0,1420596631),(267,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420600276),(268,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420600654),(269,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420600922),(270,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420601512),(271,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420601854),(272,0,0,'[user=7]King[/user] just grabbed a G-coin-lden C-c',0,1420602311),(273,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420602864),(274,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420603090),(275,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420617804),(276,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420618348),(277,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420618768),(278,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420619213),(279,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420619597),(280,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420621092),(281,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420621614),(282,0,0,'[user=203]rokon[/user] just grabbed a G-coin-lden ',0,1420622645),(283,0,0,'[user=36]spider[/user] just grabbed a G-coin-lden ',0,1420623276),(284,0,0,'[user=203]rokon[/user] just grabbed a G-coin-lden ',0,1420640470),(285,0,0,'[user=203]rokon[/user] just grabbed a G-coin-lden ',0,1420641350),(286,0,0,'[user=203]rokon[/user] just grabbed a G-coin-lden ',0,1420641768),(287,0,0,'[user=201]nusrullah[/user] just grabbed a G-coin-l',0,1420642375),(288,0,0,'[user=201]nusrullah[/user] just grabbed a G-coin-l',0,1420643921),(289,0,0,'[user=203]rokon[/user] just grabbed a G-coin-lden ',0,1420644339),(290,0,0,'[user=7]King[/user] just grabbed a G-coin-lden C-c',0,1420645645),(291,0,0,'[user=81]Avro[/user] just grabbed a G-coin-lden C-',0,1420725742),(292,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420726026),(293,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420726390),(294,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420726860),(295,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420727176),(296,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420727551),(297,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420727790),(298,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420728413),(299,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420728905),(300,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420732020),(301,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420732298),(302,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420732611),(303,0,0,'[user=80]rahul[/user] just grabbed a G-coin-lden C',0,1420769461),(304,0,0,'[user=80]rahul[/user] just grabbed a G-coin-lden C',0,1420770188),(305,0,0,'[user=80]rahul[/user] just grabbed a G-coin-lden C',0,1420770587),(306,0,0,'[user=80]rahul[/user] just grabbed a G-coin-lden C',0,1420771122),(307,0,0,'[user=80]rahul[/user] just grabbed a G-coin-lden C',0,1420771725),(308,0,0,'[user=80]rahul[/user] just grabbed a G-coin-lden C',0,1420772224),(309,0,0,'[user=80]rahul[/user] just grabbed a G-coin-lden C',0,1420772585),(310,0,0,'[user=80]rahul[/user] just grabbed a G-coin-lden C',0,1420772923),(311,0,0,'[user=80]rahul[/user] just grabbed a G-coin-lden C',0,1420773233),(312,0,0,'[user=80]rahul[/user] just grabbed a G-coin-lden C',0,1420773710),(313,0,0,'[user=80]rahul[/user] just grabbed a G-coin-lden C',0,1420774274),(314,0,0,'[user=80]rahul[/user] just grabbed a G-coin-lden C',0,1420774719),(315,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420775191),(316,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420775634),(317,0,0,'[user=184]siam1[/user] just grabbed a G-coin-lden ',0,1420775893),(318,0,0,'[user=7]King[/user] just grabbed a G-coin-lden C-c',0,1420797138),(319,0,0,'[user=16]habib~khan[/user] just grabbed a G-coin-l',0,1420861203),(320,0,0,'[user=16]habib~khan[/user] just grabbed a G-coin-l',0,1420861657),(321,0,0,'[user=16]habib~khan[/user] just grabbed a G-coin-l',0,1420862221),(322,0,0,'[user=26]djsourav[/user] just grabbed a G-coin-lde',0,1420880286),(323,0,0,'[user=1]admin[/user] just grabbed a G-coin-lden C-',0,1420880720),(324,0,0,'[user=14]Avro[/user] just grabbed a G-coin-lden C-',0,1420900567),(325,0,0,'[user=16]habib~khan[/user] just grabbed a G-coin-l',0,1420902538),(326,0,0,'[user=16]habib~khan[/user] just grabbed a G-coin-l',0,1420903142),(327,0,0,'[user=17]ruteck[/user] just grabbed a G-coin-lden ',0,1420989589),(328,0,0,'[user=14]Avro[/user] just grabbed a G-coin-lden C-',0,1420990553),(329,0,0,'[user=53]devil_[/user] just grabbed a G-coin-lden ',0,1421029816),(330,0,0,'[user=14]Avro[/user] just grabbed a G-coin-lden C-',0,1421033693),(331,0,0,'[user=37]king[/user] just grabbed a G-coin-lden C-',0,1421049753),(332,0,0,'[user=60]diptesh[/user] just grabbed a G-coin-lden',0,1421076760),(333,0,0,'[user=14]Avro[/user] just grabbed a G-coin-lden C-',0,1421117852),(334,0,0,'[user=14]Avro[/user] just grabbed a G-coin-lden C-',0,1421118283),(335,0,0,'[user=17]ruteck[/user] just grabbed a G-coin-lden ',0,1421292183),(336,0,0,'[user=19]wonder_boy[/user] just grabbed a G-coin-l',0,1421313187);
/*!40000 ALTER TABLE `uday_gcg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uday_gfi`
--

DROP TABLE IF EXISTS `uday_gfi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uday_gfi` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `uid` int(100) NOT NULL DEFAULT '0',
  `coin` int(100) NOT NULL DEFAULT '0',
  `createtime` int(100) NOT NULL DEFAULT '0',
  `catchtime` int(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2508 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uday_gfi`
--

LOCK TABLES `uday_gfi` WRITE;
/*!40000 ALTER TABLE `uday_gfi` DISABLE KEYS */;
INSERT INTO `uday_gfi` (`id`, `uid`, `coin`, `createtime`, `catchtime`) VALUES (1,0,0,0,0),(2,0,0,0,0),(3,0,0,0,0),(4,0,0,1415718023,0),(5,0,0,1415765309,0),(6,0,0,1415766812,0),(7,0,0,1415770757,0),(8,0,0,1415774214,0),(9,0,0,1415775325,0),(10,0,0,1415775719,0),(11,0,0,1415793273,0),(12,0,0,1415801774,0),(13,0,0,1415802481,0),(14,0,0,1415802966,0),(15,0,0,1415803495,0),(16,0,0,1415803835,0),(17,0,0,1415879863,0),(18,0,0,1415879616,0),(19,0,0,1415939424,0),(20,0,0,1415939432,0),(21,0,0,1415939750,0),(22,0,0,1415939915,0),(23,0,0,1415939745,0),(24,0,0,1415939979,0),(25,0,0,1415939839,0),(26,0,0,1415940013,0),(27,0,0,1415939768,0),(28,0,0,1415939755,0),(29,0,0,1415940014,0),(30,0,0,1415940023,0),(31,0,0,1415939792,0),(32,0,0,1415939902,0),(33,0,0,1415939820,0),(34,0,0,1415940048,0),(35,0,0,1415939933,0),(36,0,0,1415940033,0),(37,0,0,1415940050,0),(38,0,0,1415939818,0),(39,0,0,1415939985,0),(40,0,0,1415940065,0),(41,0,0,1415939836,0),(42,0,0,1415939943,0),(43,0,0,1415939888,0),(44,0,0,1415940086,0),(45,0,0,1415939933,0),(46,0,0,1415941655,0),(47,0,0,1415941644,0),(48,0,0,1415941763,0),(49,0,0,1415941760,0),(50,0,0,1415941628,0),(51,0,0,1415941723,0),(52,0,0,1415941569,0),(53,0,0,1415941661,0),(54,0,0,1415941578,0),(55,0,0,1415941809,0),(56,0,0,1415941630,0),(57,0,0,1415941807,0),(58,0,0,1415941587,0),(59,0,0,1415941604,0),(60,0,0,1415941729,0),(61,0,0,1415941623,0),(62,0,0,1415941777,0),(63,0,0,1415941754,0),(64,0,0,1415941758,0),(65,0,0,1415941710,0),(66,0,0,1415941725,0),(67,0,0,1415941761,0),(68,0,0,1415941852,0),(69,0,0,1415941735,0),(70,0,0,1415941911,0),(71,0,0,1415941679,0),(72,0,0,1415941856,0),(73,0,0,1415941926,0),(74,0,0,1415941926,0),(75,0,0,1415941872,0),(76,0,0,1415941827,0),(77,0,0,1415941928,0),(78,0,0,1415941683,0),(79,0,0,1415941691,0),(80,0,0,1415941761,0),(81,0,0,1415941755,0),(82,0,0,1415941763,0),(83,0,0,1415941849,0),(84,0,0,1415941794,0),(85,0,0,1415941955,0),(86,0,0,1415941883,0),(87,0,0,1415941744,0),(88,0,0,1415942019,0),(89,0,0,1415942391,0),(90,0,0,1415942403,0),(91,0,0,1415942409,0),(92,0,0,1415942505,0),(93,0,0,1415942560,0),(94,0,0,1415942475,0),(95,0,0,1415942542,0),(96,0,0,1415942335,0),(97,0,0,1415942367,0),(98,0,0,1415942385,0),(99,0,0,1415942499,0),(100,0,0,1415942579,0),(101,0,0,1415942367,0),(102,0,0,1415942461,0),(103,0,0,1415942353,0),(104,0,0,1415942494,0),(105,0,0,1415942376,0),(106,0,0,1415942472,0),(107,0,0,1415942640,0),(108,0,0,1415942497,0),(109,0,0,1415942538,0),(110,0,0,1415942565,0),(111,0,0,1415942676,0),(112,0,0,1415942631,0),(113,0,0,1415942573,0),(114,0,0,1415942436,0),(115,0,0,1415942676,0),(116,0,0,1415942539,0),(117,0,0,1415942536,0),(118,0,0,1415942607,0),(119,0,0,1415942703,0),(120,0,0,1415942631,0),(121,0,0,1415942544,0),(122,0,0,1415942655,0),(123,0,0,1415942612,0),(124,0,0,1415942726,0),(125,0,0,1415942548,0),(126,0,0,1415942773,0),(127,0,0,1415942593,0),(128,0,0,1415942657,0),(129,0,0,1415942703,0),(130,0,0,1415942641,0),(131,0,0,1415942536,0),(132,0,0,1415942773,0),(133,0,0,1415943514,0),(134,0,0,1415943446,0),(135,0,0,1415943628,0),(136,0,0,1415943505,0),(137,0,0,1415943613,0),(138,0,0,1415943443,0),(139,0,0,1415943459,0),(140,0,0,1415943520,0),(141,0,0,1415943693,0),(142,0,0,1415943563,0),(143,0,0,1415943649,0),(144,0,0,1415943601,0),(145,0,0,1415943701,0),(146,0,0,1415943604,0),(147,0,0,1415943671,0),(148,0,0,1415943514,0),(149,0,0,1415943583,0),(150,0,0,1415943607,0),(151,0,0,1415943535,0),(152,0,0,1415943595,0),(153,0,0,1415943553,0),(154,0,0,1415943593,0),(155,0,0,1415943644,0),(156,0,0,1415943808,0),(157,0,0,1415943620,0),(158,0,0,1415943636,0),(159,0,0,1415943807,0),(160,0,0,1415943772,0),(161,0,0,1415943851,0),(162,0,0,1415943687,0),(163,0,0,1415943612,0),(164,0,0,1415943871,0),(165,0,0,1415943731,0),(166,0,0,1415943758,0),(167,0,0,1415943748,0),(168,0,0,1415943922,0),(169,0,0,1415943777,0),(170,0,0,1415943838,0),(171,0,0,1415943915,0),(172,0,0,1415943892,0),(173,0,0,1415943905,0),(174,0,0,1415943913,0),(175,0,0,1415943843,0),(176,0,0,1415943941,0),(177,0,0,1415943881,0),(178,0,0,1415943757,0),(179,0,0,1415943921,0),(180,0,0,1415943969,0),(181,0,0,1415943995,0),(182,0,0,1415943815,0),(183,0,0,1415943736,0),(184,0,0,1415943770,0),(185,0,0,1415943878,0),(186,0,0,1415943802,0),(187,0,0,1415943973,0),(188,0,0,1415943997,0),(189,0,0,1415944004,0),(190,0,0,1415943863,0),(191,0,0,1415944362,0),(192,0,0,1415944522,0),(193,0,0,1415944417,0),(194,0,0,1415944496,0),(195,0,0,1415944478,0),(196,0,0,1415944382,0),(197,0,0,1415944350,0),(198,0,0,1415944404,0),(199,0,0,1415944501,0),(200,0,0,1415944578,0),(201,0,0,1415944571,0),(202,0,0,1415944448,0),(203,0,0,1415944476,0),(204,0,0,1415944425,0),(205,0,0,1415944546,0),(206,0,0,1415944404,0),(207,0,0,1415944630,0),(208,0,0,1415944558,0),(209,0,0,1415944626,0),(210,0,0,1415944588,0),(211,0,0,1415944408,0),(212,0,0,1415944559,0),(213,0,0,1415944523,0),(214,0,0,1415944428,0),(215,0,0,1415944463,0),(216,0,0,1415944515,0),(217,0,0,1415944654,0),(218,0,0,1415944493,0),(219,0,0,1415944665,0),(220,0,0,1415944754,0),(221,0,0,1415944634,0),(222,0,0,1415944608,0),(223,0,0,1415944573,0),(224,0,0,1415944553,0),(225,0,0,1415944746,0),(226,0,0,1415944758,0),(227,0,0,1415944519,0),(228,0,0,1415944697,0),(229,0,0,1415944564,0),(230,0,0,1415944655,0),(231,0,0,1415944604,0),(232,0,0,1415944564,0),(233,0,0,1415944589,0),(234,0,0,1415944605,0),(235,0,0,1415944635,0),(236,0,0,1415944813,0),(237,0,0,1415944835,0),(238,0,0,1415944635,0),(239,0,0,1415944794,0),(240,0,0,1415944667,0),(241,0,0,1415944698,0),(242,0,0,1415944596,0),(243,0,0,1415944584,0),(244,0,0,1415944631,0),(245,0,0,1415944874,0),(246,0,0,1415944827,0),(247,0,0,1415944788,0),(248,0,0,1415944882,0),(249,0,0,1415944819,0),(250,0,0,1415944613,0),(251,0,0,1415944634,0),(252,0,0,1415944776,0),(253,0,0,1415944844,0),(254,0,0,1415944822,0),(255,0,0,1415944698,0),(256,0,0,1415944755,0),(257,0,0,1415944851,0),(258,0,0,1415944782,0),(259,0,0,1415944951,0),(260,0,0,1415944809,0),(261,0,0,1415944806,0),(262,0,0,1415944845,0),(263,0,0,1415944727,0),(264,0,0,1415944842,0),(265,0,0,1415944706,0),(266,0,0,1415944889,0),(267,0,0,1415944909,0),(268,0,0,1415944816,0),(269,0,0,1415944892,0),(270,0,0,1415944733,0),(271,0,0,1415944763,0),(272,0,0,1415944772,0),(273,0,0,1415944810,0),(274,0,0,1415944987,0),(275,0,0,1415944824,0),(276,0,0,1415944863,0),(277,0,0,1415944902,0),(278,0,0,1415944987,0),(279,0,0,1415944950,0),(280,0,0,1415944911,0),(281,0,0,1415944999,0),(282,0,0,1415944944,0),(283,0,0,1415944945,0),(284,0,0,1415944968,0),(285,0,0,1415945272,0),(286,0,0,1415945386,0),(287,0,0,1415945429,0),(288,0,0,1415945336,0),(289,0,0,1415945324,0),(290,0,0,1415945406,0),(291,0,0,1415945259,0),(292,0,0,1415945492,0),(293,0,0,1415945412,0),(294,0,0,1415945457,0),(295,0,0,1415945546,0),(296,0,0,1415945343,0),(297,0,0,1415945529,0),(298,0,0,1415945467,0),(299,0,0,1415945375,0),(300,0,0,1415945429,0),(301,0,0,1415945351,0),(302,0,0,1415945851,0),(303,0,0,1415945867,0),(304,0,0,1415945956,0),(305,0,0,1415945958,0),(306,0,0,1415945832,0),(307,0,0,1415945851,0),(308,0,0,1415946059,0),(309,0,0,1415946063,0),(310,0,0,1415946072,0),(311,0,0,1415946135,0),(312,0,0,1415946119,0),(313,0,0,1415945954,0),(314,0,0,1415945946,0),(315,0,0,1415945868,0),(316,0,0,1415946115,0),(317,0,0,1415945994,0),(318,0,0,1415945992,0),(319,0,0,1415946141,0),(320,0,0,1415946048,0),(321,0,0,1415945945,0),(322,0,0,1415945939,0),(323,0,0,1415946091,0),(324,0,0,1415946219,0),(325,0,0,1415945967,0),(326,0,0,1415946057,0),(327,0,0,1415946232,0),(328,0,0,1415945999,0),(329,0,0,1415946081,0),(330,0,0,1415946090,0),(331,0,0,1415946202,0),(332,0,0,1415946005,0),(333,0,0,1415946244,0),(334,0,0,1415946265,0),(335,0,0,1415946221,0),(336,0,0,1415946245,0),(337,0,0,1415946229,0),(338,0,0,1415946140,0),(339,0,0,1415946054,0),(340,0,0,1415946008,0),(341,0,0,1415946154,0),(342,0,0,1415946148,0),(343,0,0,1415946128,0),(344,0,0,1415946960,0),(345,0,0,1415946949,0),(346,0,0,1415947002,0),(347,0,0,1415946824,0),(348,0,0,1415946858,0),(349,0,0,1415947080,0),(350,0,0,1415946834,0),(351,0,0,1415947018,0),(352,0,0,1415947050,0),(353,0,0,1415947092,0),(354,0,0,1415946992,0),(355,0,0,1415946923,0),(356,0,0,1415947042,0),(357,0,0,1415947028,0),(358,0,0,1415947020,0),(359,0,0,1415946907,0),(360,0,0,1415946927,0),(361,0,0,1415946972,0),(362,0,0,1415947162,0),(363,0,0,1415946946,0),(364,0,0,1415947137,0),(365,0,0,1415947216,0),(366,0,0,1415947128,0),(367,0,0,1415946956,0),(368,0,0,1415947225,0),(369,0,0,1415947000,0),(370,0,0,1415947079,0),(371,0,0,1415947277,0),(372,0,0,1415947073,0),(373,0,0,1415947258,0),(374,0,0,1415947254,0),(375,0,0,1415947146,0),(376,0,0,1415947112,0),(377,0,0,1415947199,0),(378,0,0,1415947152,0),(379,0,0,1415947040,0),(380,0,0,1415947138,0),(381,0,0,1415947237,0),(382,0,0,1415947211,0),(383,0,0,1415947172,0),(384,0,0,1415947285,0),(385,0,0,1415947184,0),(386,0,0,1415947345,0),(387,0,0,1415947257,0),(388,0,0,1415947191,0),(389,0,0,1415947146,0),(390,0,0,1415947126,0),(391,0,0,1415947373,0),(392,0,0,1415947184,0),(393,0,0,1415947630,0),(394,0,0,1415947785,0),(395,0,0,1415947856,0),(396,0,0,1415947691,0),(397,0,0,1415947732,0),(398,0,0,1415947722,0),(399,0,0,1415947956,0),(400,0,0,1415947802,0),(401,0,0,1415947703,0),(402,0,0,1415947760,0),(403,0,0,1415947852,0),(404,0,0,1415947851,0),(405,0,0,1415947885,0),(406,0,0,1415947981,0),(407,0,0,1415947839,0),(408,0,0,1415947870,0),(409,0,0,1415947847,0),(410,0,0,1415947744,0),(411,0,0,1415947996,0),(412,0,0,1415947788,0),(413,0,0,1415947998,0),(414,0,0,1415947779,0),(415,0,0,1415947906,0),(416,0,0,1415947974,0),(417,0,0,1415947981,0),(418,0,0,1415947994,0),(419,0,0,1415947990,0),(420,0,0,1415948038,0),(421,0,0,1415947939,0),(422,0,0,1415947876,0),(423,0,0,1415947856,0),(424,0,0,1415948099,0),(425,0,0,1415948071,0),(426,0,0,1415948040,0),(427,0,0,1415948037,0),(428,0,0,1415948048,0),(429,0,0,1415948023,0),(430,0,0,1415948015,0),(431,0,0,1415948149,0),(432,0,0,1415948088,0),(433,0,0,1415947933,0),(434,0,0,1415948035,0),(435,0,0,1415947942,0),(436,0,0,1415948660,0),(437,0,0,1415948716,0),(438,0,0,1415948542,0),(439,0,0,1415948746,0),(440,0,0,1415948580,0),(441,0,0,1415948738,0),(442,0,0,1415948604,0),(443,0,0,1415948608,0),(444,0,0,1415948613,0),(445,0,0,1415948610,0),(446,0,0,1415948621,0),(447,0,0,1415948865,0),(448,0,0,1415948597,0),(449,0,0,1415948658,0),(450,0,0,1415948766,0),(451,0,0,1415948734,0),(452,0,0,1415948865,0),(453,0,0,1415959822,0),(454,0,0,1415959738,0),(455,0,0,1415959873,0),(456,0,0,1415959967,0),(457,0,0,1415959742,0),(458,0,0,1415959890,0),(459,0,0,1415959748,0),(460,0,0,1415959851,0),(461,0,0,1415959767,0),(462,0,0,1415959854,0),(463,0,0,1415959895,0),(464,0,0,1415960013,0),(465,0,0,1415959978,0),(466,0,0,1415959985,0),(467,0,0,1415959982,0),(468,0,0,1415960392,0),(469,0,0,1415960369,0),(470,0,0,1415960471,0),(471,0,0,1415960485,0),(472,0,0,1415960359,0),(473,0,0,1415960337,0),(474,0,0,1415960304,0),(475,0,0,1415960384,0),(476,0,0,1415960418,0),(477,0,0,1415961121,0),(478,0,0,1415961403,0),(479,0,0,1415961556,0),(480,0,0,1415961596,0),(481,0,0,1415965119,0),(482,0,0,1415965065,0),(483,0,0,1415965027,0),(484,0,0,1415965067,0),(485,0,0,1415964939,0),(486,0,0,1415965199,0),(487,0,0,1415965047,0),(488,0,0,1415965200,0),(489,0,0,1415965221,0),(490,0,0,1415965284,0),(491,0,0,1415965111,0),(492,0,0,1415965033,0),(493,0,0,1415965128,0),(494,0,0,1415965243,0),(495,0,0,1415965303,0),(496,0,0,1415965059,0),(497,0,0,1415965279,0),(498,0,0,1415965172,0),(499,0,0,1415965079,0),(500,0,0,1415965168,0),(501,0,0,1415965320,0),(502,0,0,1415965303,0),(503,0,0,1415965271,0),(504,0,0,1415965179,0),(505,0,0,1415965354,0),(506,0,0,1415965258,0),(507,0,0,1415965930,0),(508,0,0,1415965942,0),(509,0,0,1415966123,0),(510,0,0,1415965921,0),(511,0,0,1415965962,0),(512,0,0,1415967103,0),(513,0,0,1415966912,0),(514,0,0,1415966836,0),(515,0,0,1415966913,0),(516,0,0,1415967030,0),(517,0,0,1415967039,0),(518,0,0,1415967051,0),(519,0,0,1415966926,0),(520,0,0,1415966999,0),(521,0,0,1415967048,0),(522,0,0,1415967037,0),(523,0,0,1415967120,0),(524,0,0,1415966944,0),(525,0,0,1415967031,0),(526,0,0,1415967168,0),(527,0,0,1415966975,0),(528,0,0,1415967102,0),(529,0,0,1415967012,0),(530,0,0,1415967128,0),(531,0,0,1415967526,0),(532,0,0,1415967459,0),(533,0,0,1415967410,0),(534,0,0,1415967577,0),(535,0,0,1415967805,0),(536,0,0,1415968043,0),(537,0,0,1415967850,0),(538,0,0,1415967979,0),(539,0,0,1415968026,0),(540,0,0,1415968042,0),(541,0,0,1415967931,0),(542,0,0,1415968635,0),(543,0,0,1415968666,0),(544,0,0,1415968650,0),(545,0,0,1415968683,0),(546,0,0,1415968486,0),(547,0,0,1415968618,0),(548,0,0,1415968536,0),(549,0,0,1415969221,0),(550,0,0,1415969231,0),(551,0,0,1415969238,0),(552,0,0,1415969060,0),(553,0,0,1415969045,0),(554,0,0,1415969171,0),(555,0,0,1415969118,0),(556,0,0,1415969232,0),(557,0,0,1415969217,0),(558,0,0,1415969586,0),(559,0,0,1415969763,0),(560,0,0,1415969614,0),(561,0,0,1415969647,0),(562,0,0,1415969828,0),(563,0,0,1415969892,0),(564,0,0,1415969669,0),(565,0,0,1415969722,0),(566,0,0,1415969734,0),(567,0,0,1415969657,0),(568,0,0,1415969710,0),(569,0,0,1415969651,0),(570,0,0,1415969849,0),(571,0,0,1415969873,0),(572,0,0,1415969877,0),(573,0,0,1415969753,0),(574,0,0,1415969839,0),(575,0,0,1415969962,0),(576,0,0,1415969936,0),(577,0,0,1415970480,0),(578,0,0,1415970577,0),(579,0,0,1415970505,0),(580,0,0,1415970576,0),(581,0,0,1415970491,0),(582,0,0,1415970548,0),(583,0,0,1415970490,0),(584,0,0,1415970391,0),(585,0,0,1415970528,0),(586,0,0,1415970513,0),(587,0,0,1415970485,0),(588,0,0,1415970654,0),(589,0,0,1415970553,0),(590,0,0,1415970495,0),(591,0,0,1415970546,0),(592,0,0,1415970493,0),(593,0,0,1415970703,0),(594,0,0,1415970592,0),(595,0,0,1415970695,0),(596,0,0,1415970502,0),(597,0,0,1415970762,0),(598,0,0,1415970725,0),(599,0,0,1415970794,0),(600,0,0,1415970770,0),(601,0,0,1415970706,0),(602,0,0,1415970793,0),(603,0,0,1415970598,0),(604,0,0,1415970790,0),(605,0,0,1415970695,0),(606,0,0,1415970708,0),(607,0,0,1415970735,0),(608,0,0,1415970837,0),(609,0,0,1415970963,0),(610,0,0,1415970843,0),(611,0,0,1415970901,0),(612,0,0,1415970897,0),(613,0,0,1415970928,0),(614,0,0,1415970871,0),(615,0,0,1415970905,0),(616,0,0,1415970928,0),(617,0,0,1415971069,0),(618,0,0,1415970981,0),(619,0,0,1415970932,0),(620,0,0,1415970967,0),(621,0,0,1415971029,0),(622,0,0,1415971030,0),(623,0,0,1415971078,0),(624,0,0,1415971058,0),(625,0,0,1415971132,0),(626,0,0,1415971010,0),(627,0,0,1415971161,0),(628,0,0,1415971157,0),(629,0,0,1415971118,0),(630,0,0,1415971145,0),(631,0,0,1415971114,0),(632,0,0,1415971383,0),(633,0,0,1415972147,0),(634,0,0,1415971988,0),(635,0,0,1415972209,0),(636,0,0,1415973222,0),(637,0,0,1415973015,0),(638,0,0,1415973034,0),(639,0,0,1415973200,0),(640,0,0,1415973254,0),(641,0,0,1415973152,0),(642,0,0,1415973085,0),(643,0,0,1415973140,0),(644,0,0,1415973195,0),(645,0,0,1415975304,0),(646,0,0,1415975300,0),(647,0,0,1415975355,0),(648,0,0,1415975568,0),(649,0,0,1415975564,0),(650,0,0,1415975440,0),(651,0,0,1415976689,0),(652,0,0,1415977012,0),(653,0,0,1416024604,0),(654,0,0,1416025313,0),(655,0,0,1416025416,0),(656,0,0,1416025240,0),(657,0,0,1416025307,0),(658,0,0,1416025223,0),(659,0,0,1416025355,0),(660,0,0,1416025468,0),(661,0,0,1416025233,0),(662,0,0,1416025228,0),(663,0,0,1416025417,0),(664,0,0,1416025439,0),(665,0,0,1416025526,0),(666,0,0,1416025943,0),(667,0,0,1416025889,0),(668,0,0,1416025944,0),(669,0,0,1416026004,0),(670,0,0,1416026016,0),(671,0,0,1416025790,0),(672,0,0,1416025768,0),(673,0,0,1416025928,0),(674,0,0,1416025956,0),(675,0,0,1416025798,0),(676,0,0,1416025928,0),(677,0,0,1416025866,0),(678,0,0,1416025942,0),(679,0,0,1416026013,0),(680,0,0,1416026006,0),(681,0,0,1416025989,0),(682,0,0,1416025925,0),(683,0,0,1416026121,0),(684,0,0,1416025899,0),(685,0,0,1416026064,0),(686,0,0,1416025981,0),(687,0,0,1416026560,0),(688,0,0,1416026609,0),(689,0,0,1416026485,0),(690,0,0,1416026640,0),(691,0,0,1416026650,0),(692,0,0,1416026697,0),(693,0,0,1416026664,0),(694,0,0,1416026683,0),(695,0,0,1416026703,0),(696,0,0,1416026591,0),(697,0,0,1416026526,0),(698,0,0,1416026777,0),(699,0,0,1416026527,0),(700,0,0,1416026637,0),(701,0,0,1416026650,0),(702,0,0,1416026582,0),(703,0,0,1416026653,0),(704,0,0,1416026806,0),(705,0,0,1416026797,0),(706,0,0,1416026817,0),(707,0,0,1416026718,0),(708,0,0,1416026687,0),(709,0,0,1416026685,0),(710,0,0,1416026849,0),(711,0,0,1416028818,0),(712,0,0,1416028725,0),(713,0,0,1416028930,0),(714,0,0,1416028826,0),(715,0,0,1416028728,0),(716,0,0,1416028709,0),(717,0,0,1416028967,0),(718,0,0,1416029481,0),(719,0,0,1416029521,0),(720,0,0,1416029308,0),(721,0,0,1416029451,0),(722,0,0,1416029500,0),(723,0,0,1416029554,0),(724,0,0,1416029502,0),(725,0,0,1416029575,0),(726,0,0,1416029334,0),(727,0,0,1416029325,0),(728,0,0,1416029380,0),(729,0,0,1416029377,0),(730,0,0,1416029533,0),(731,0,0,1416029319,0),(732,0,0,1416029317,0),(733,0,0,1416029470,0),(734,0,0,1416029477,0),(735,0,0,1416029451,0),(736,0,0,1416029425,0),(737,0,0,1416030291,0),(738,0,0,1416030774,0),(739,0,0,1416030678,0),(740,0,0,1416030875,0),(741,0,0,1416030900,0),(742,0,0,1416030676,0),(743,0,0,1416030763,0),(744,0,0,1416030779,0),(745,0,0,1416030742,0),(746,0,0,1416030725,0),(747,0,0,1416030939,0),(748,0,0,1416030825,0),(749,0,0,1416030915,0),(750,0,0,1416030981,0),(751,0,0,1416030841,0),(752,0,0,1416030766,0),(753,0,0,1416032442,0),(754,0,0,1416032317,0),(755,0,0,1416032322,0),(756,0,0,1416032210,0),(757,0,0,1416033012,0),(758,0,0,1416033005,0),(759,0,0,1416032818,0),(760,0,0,1416032997,0),(761,0,0,1416033125,0),(762,0,0,1416033488,0),(763,0,0,1416033693,0),(764,0,0,1416046385,0),(765,0,0,1416046255,0),(766,0,0,1416046292,0),(767,0,0,1416046502,0),(768,0,0,1416046304,0),(769,0,0,1416050980,0),(770,0,0,1416050899,0),(771,0,0,1416050969,0),(772,0,0,1416050974,0),(773,0,0,1416051192,0),(774,0,0,1416051084,0),(775,0,0,1416050934,0),(776,0,0,1416051159,0),(777,0,0,1416051194,0),(778,0,0,1416051086,0),(779,0,0,1416051127,0),(780,0,0,1416051168,0),(781,0,0,1416051293,0),(782,0,0,1416051294,0),(783,0,0,1416051297,0),(784,0,0,1416051278,0),(785,0,0,1416051368,0),(786,0,0,1416051448,0),(787,0,0,1416051439,0),(788,0,0,1416052896,0),(789,0,0,1416052941,0),(790,0,0,1416053112,0),(791,0,0,1416052919,0),(792,0,0,1416053063,0),(793,0,0,1416053113,0),(794,0,0,1416053815,0),(795,0,0,1416053721,0),(796,0,0,1416053683,0),(797,0,0,1416053579,0),(798,0,0,1416053639,0),(799,0,0,1416053765,0),(800,0,0,1416053589,0),(801,0,0,1416053790,0),(802,0,0,1416053911,0),(803,0,0,1416053921,0),(804,0,0,1416053921,0),(805,0,0,1416053792,0),(806,0,0,1416053884,0),(807,0,0,1416053802,0),(808,0,0,1416053875,0),(809,0,0,1416053671,0),(810,0,0,1416053789,0),(811,0,0,1416053686,0),(812,0,0,1416053799,0),(813,0,0,1416053795,0),(814,0,0,1416053966,0),(815,0,0,1416053924,0),(816,0,0,1416053785,0),(817,0,0,1416053923,0),(818,0,0,1416053840,0),(819,0,0,1416053897,0),(820,0,0,1416053817,0),(821,0,0,1416053731,0),(822,0,0,1416053982,0),(823,0,0,1416054008,0),(824,0,0,1416053883,0),(825,0,0,1416053756,0),(826,0,0,1416053946,0),(827,0,0,1416053904,0),(828,0,0,1416053787,0),(829,0,0,1416053850,0),(830,0,0,1416053958,0),(831,0,0,1416053861,0),(832,0,0,1416054016,0),(833,0,0,1416053850,0),(834,0,0,1416053887,0),(835,0,0,1416053822,0),(836,0,0,1416053902,0),(837,0,0,1416053958,0),(838,0,0,1416054030,0),(839,0,0,1416053941,0),(840,0,0,1416054069,0),(841,0,0,1416054641,0),(842,0,0,1416054705,0),(843,0,0,1416054549,0),(844,0,0,1416054536,0),(845,0,0,1416054697,0),(846,0,0,1416054539,0),(847,0,0,1416054522,0),(848,0,0,1416054542,0),(849,0,0,1416056483,0),(850,0,0,1416056658,0),(851,0,0,1416056571,0),(852,0,0,1416056619,0),(853,0,0,1416056440,0),(854,0,0,1416056673,0),(855,0,0,1416056691,0),(856,0,0,1416056617,0),(857,0,0,1416059127,0),(858,0,0,1416060004,0),(859,0,0,1416059900,0),(860,0,0,1416060027,0),(861,0,0,1416059981,0),(862,0,0,1416060187,0),(863,0,0,1416059934,0),(864,0,0,1416059913,0),(865,0,0,1416060068,0),(866,0,0,1416060188,0),(867,0,0,1416061740,0),(868,0,0,1416061637,0),(869,0,0,1416061728,0),(870,0,0,1416061502,0),(871,0,0,1416061772,0),(872,0,0,1416112262,0),(873,0,0,1416112011,0),(874,0,0,1416112133,0),(875,0,0,1416112173,0),(876,0,0,1416112067,0),(877,0,0,1416112184,0),(878,0,0,1416112299,0),(879,0,0,1416112176,0),(880,0,0,1416112066,0),(881,0,0,1416112256,0),(882,0,0,1416112128,0),(883,0,0,1416112233,0),(884,0,0,1416112118,0),(885,0,0,1416112179,0),(886,0,0,1416112158,0),(887,0,0,1416112303,0),(888,0,0,1416112203,0),(889,0,0,1416112068,0),(890,0,0,1416112307,0),(891,0,0,1416112325,0),(892,0,0,1416112209,0),(893,0,0,1416112110,0),(894,0,0,1416112191,0),(895,0,0,1416112222,0),(896,0,0,1416112273,0),(897,0,0,1416112179,0),(898,0,0,1416112196,0),(899,0,0,1416112158,0),(900,0,0,1416112189,0),(901,0,0,1416112240,0),(902,0,0,1416112168,0),(903,0,0,1416112220,0),(904,0,0,1416112218,0),(905,0,0,1416112199,0),(906,0,0,1416112248,0),(907,0,0,1416112422,0),(908,0,0,1416112438,0),(909,0,0,1416112235,0),(910,0,0,1416112476,0),(911,0,0,1416113298,0),(912,0,0,1416113291,0),(913,0,0,1416113128,0),(914,0,0,1416113412,0),(915,0,0,1416116307,0),(916,0,0,1416116292,0),(917,0,0,1416116443,0),(918,0,0,1416116423,0),(919,0,0,1416133346,0),(920,0,0,1416133530,0),(921,0,0,1416133362,0),(922,0,0,1416133531,0),(923,0,0,1416133437,0),(924,0,0,1416133517,0),(925,0,0,1416566293,0),(926,0,0,1416566397,0),(927,0,0,1416566542,0),(928,0,0,1416566481,0),(929,0,0,1416566547,0),(930,0,0,1416567202,0),(931,0,0,1416567160,0),(932,0,0,1416567126,0),(933,0,0,1416567101,0),(934,0,0,1416570416,0),(935,0,0,1416570554,0),(936,0,0,1416570527,0),(937,0,0,1416570378,0),(938,0,0,1416570404,0),(939,0,0,1416570404,0),(940,0,0,1416667435,0),(941,0,0,1416667412,0),(942,0,0,1416667503,0),(943,0,0,1416667460,0),(944,0,0,1416667484,0),(945,0,0,1416824696,0),(946,0,0,1416824692,0),(947,0,0,1416829493,0),(948,0,0,1416829485,0),(949,0,0,1416839901,0),(950,0,0,1416982668,0),(951,0,0,1416982827,0),(952,0,0,1416982666,0),(953,0,0,1416982727,0),(954,0,0,1416982900,0),(955,0,0,1416982757,0),(956,0,0,1416982758,0),(957,0,0,1416982824,0),(958,0,0,1416985075,0),(959,0,0,1416984918,0),(960,0,0,1418207163,0),(961,0,0,1418222132,0),(962,0,0,1418273685,0),(963,0,0,1418281220,0),(964,0,0,1418292399,0),(965,0,0,1418292841,0),(966,0,0,1418292677,0),(967,0,0,1418292709,0),(968,0,0,1418292695,0),(969,0,0,1418292749,0),(970,0,0,1418292970,0),(971,0,0,1418292977,0),(972,0,0,1418292968,0),(973,0,0,1418292700,0),(974,0,0,1418292709,0),(975,0,0,1418292798,0),(976,0,0,1418292927,0),(977,0,0,1418292815,0),(978,0,0,1418292984,0),(979,0,0,1418292954,0),(980,0,0,1418292887,0),(981,0,0,1418292789,0),(982,0,0,1418292876,0),(983,0,0,1418292787,0),(984,0,0,1418292906,0),(985,0,0,1418292980,0),(986,0,0,1418292851,0),(987,0,0,1418292949,0),(988,0,0,1418292899,0),(989,0,0,1418292791,0),(990,0,0,1418293014,0),(991,0,0,1418293026,0),(992,0,0,1418292932,0),(993,0,0,1418293072,0),(994,0,0,1418292936,0),(995,0,0,1418293039,0),(996,0,0,1418292888,0),(997,0,0,1418292880,0),(998,0,0,1418292999,0),(999,0,0,1418292969,0),(1000,0,0,1418293042,0),(1001,0,0,1418292935,0),(1002,0,0,1418292918,0),(1003,0,0,1418293108,0),(1004,0,0,1418293104,0),(1005,0,0,1418293035,0),(1006,0,0,1418292938,0),(1007,0,0,1418292963,0),(1008,0,0,1418293113,0),(1009,0,0,1418293122,0),(1010,0,0,1418293017,0),(1011,0,0,1418293127,0),(1012,0,0,1418293535,0),(1013,0,0,1418293627,0),(1014,0,0,1418293441,0),(1015,0,0,1418293541,0),(1016,0,0,1418293406,0),(1017,0,0,1418293519,0),(1018,0,0,1418293650,0),(1019,0,0,1418293638,0),(1020,0,0,1418293536,0),(1021,0,0,1418293452,0),(1022,0,0,1418293525,0),(1023,0,0,1418293452,0),(1024,0,0,1418293512,0),(1025,0,0,1418293641,0),(1026,0,0,1418293572,0),(1027,0,0,1418293621,0),(1028,0,0,1418293756,0),(1029,0,0,1418293533,0),(1030,0,0,1418293733,0),(1031,0,0,1418293525,0),(1032,0,0,1418293686,0),(1033,0,0,1418293529,0),(1034,0,0,1418293523,0),(1035,0,0,1418293622,0),(1036,0,0,1418293651,0),(1037,0,0,1418293720,0),(1038,0,0,1418293811,0),(1039,0,0,1418293701,0),(1040,0,0,1418293810,0),(1041,0,0,1418293569,0),(1042,0,0,1418293685,0),(1043,0,0,1418293646,0),(1044,0,0,1418293606,0),(1045,0,0,1418293677,0),(1046,0,0,1418293845,0),(1047,0,0,1418293642,0),(1048,0,0,1418293821,0),(1049,0,0,1418293686,0),(1050,0,0,1418293648,0),(1051,0,0,1418293682,0),(1052,0,0,1418293708,0),(1053,0,0,1418293850,0),(1054,0,0,1418293745,0),(1055,0,0,1418293889,0),(1056,0,0,1418293930,0),(1057,0,0,1418293741,0),(1058,0,0,1418293734,0),(1059,0,0,1418293757,0),(1060,0,0,1418293831,0),(1061,0,0,1418293993,0),(1062,0,0,1418293838,0),(1063,0,0,1418293934,0),(1064,0,0,1418293850,0),(1065,0,0,1418293926,0),(1066,0,0,1418294027,0),(1067,0,0,1418293902,0),(1068,0,0,1418293836,0),(1069,0,0,1418293784,0),(1070,0,0,1418293909,0),(1071,0,0,1418293942,0),(1072,0,0,1418293975,0),(1073,0,0,1418293923,0),(1074,0,0,1418293859,0),(1075,0,0,1418293830,0),(1076,0,0,1418293920,0),(1077,0,0,1418294086,0),(1078,0,0,1418293896,0),(1079,0,0,1418293939,0),(1080,0,0,1418294115,0),(1081,0,0,1418293945,0),(1082,0,0,1418293907,0),(1083,0,0,1418294031,0),(1084,0,0,1418294058,0),(1085,0,0,1418293917,0),(1086,0,0,1418294060,0),(1087,0,0,1418293878,0),(1088,0,0,1418294031,0),(1089,0,0,1418294057,0),(1090,0,0,1418293977,0),(1091,0,0,1418294175,0),(1092,0,0,1418293973,0),(1093,0,0,1418294196,0),(1094,0,0,1418293993,0),(1095,0,0,1418294048,0),(1096,0,0,1418293911,0),(1097,0,0,1418293973,0),(1098,0,0,1418294137,0),(1099,0,0,1418293989,0),(1100,0,0,1418294079,0),(1101,0,0,1418294190,0),(1102,0,0,1418294059,0),(1103,0,0,1418307249,0),(1104,0,0,1418307122,0),(1105,0,0,1418307241,0),(1106,0,0,1418307374,0),(1107,0,0,1418307105,0),(1108,0,0,1418307335,0),(1109,0,0,1418307253,0),(1110,0,0,1418307171,0),(1111,0,0,1418307223,0),(1112,0,0,1418307291,0),(1113,0,0,1418307178,0),(1114,0,0,1418307316,0),(1115,0,0,1418307219,0),(1116,0,0,1418307274,0),(1117,0,0,1418307318,0),(1118,0,0,1418307202,0),(1119,0,0,1418308092,0),(1120,0,0,1418308492,0),(1121,0,0,1418308598,0),(1122,0,0,1418308642,0),(1123,0,0,1418308579,0),(1124,0,0,1418308426,0),(1125,0,0,1418308516,0),(1126,0,0,1418308668,0),(1127,0,0,1418308618,0),(1128,0,0,1418308594,0),(1129,0,0,1418308673,0),(1130,0,0,1418308824,0),(1131,0,0,1418308747,0),(1132,0,0,1418308836,0),(1133,0,0,1418308664,0),(1134,0,0,1418308689,0),(1135,0,0,1418308742,0),(1136,0,0,1418308976,0),(1137,0,0,1418308887,0),(1138,0,0,1418308731,0),(1139,0,0,1418308778,0),(1140,0,0,1418308840,0),(1141,0,0,1418308920,0),(1142,0,0,1418308956,0),(1143,0,0,1418308852,0),(1144,0,0,1418309055,0),(1145,0,0,1418392816,0),(1146,0,0,1418393424,0),(1147,0,0,1418540677,0),(1148,0,0,1418552769,0),(1149,0,0,1418552796,0),(1150,0,0,1418712680,0),(1151,0,0,1418712452,0),(1152,0,0,1418712443,0),(1153,0,0,1418712535,0),(1154,0,0,1418712519,0),(1155,0,0,1418712631,0),(1156,0,0,1418712548,0),(1157,0,0,1418712674,0),(1158,0,0,1418712692,0),(1159,0,0,1418712701,0),(1160,0,0,1418712646,0),(1161,0,0,1418712503,0),(1162,0,0,1418712530,0),(1163,0,0,1418712738,0),(1164,0,0,1418712727,0),(1165,0,0,1418712673,0),(1166,0,0,1418712590,0),(1167,0,0,1418712519,0),(1168,0,0,1418712721,0),(1169,0,0,1418712601,0),(1170,0,0,1419164799,0),(1171,0,0,1419165039,0),(1172,0,0,1419165477,0),(1173,0,0,1419165836,0),(1174,0,0,1419222346,0),(1175,0,0,1419222686,0),(1176,0,0,1419222900,0),(1177,0,0,1419341207,0),(1178,0,0,1419346666,0),(1179,0,0,1419346910,0),(1180,0,0,1419346968,0),(1181,0,0,1419346994,0),(1182,0,0,1419346829,0),(1183,0,0,1419346862,0),(1184,0,0,1419346901,0),(1185,0,0,1419347047,0),(1186,0,0,1419346844,0),(1187,0,0,1419347044,0),(1188,0,0,1419347090,0),(1189,0,0,1419346828,0),(1190,0,0,1419347065,0),(1191,0,0,1419346956,0),(1192,0,0,1419346902,0),(1193,0,0,1419347053,0),(1194,0,0,1419346908,0),(1195,0,0,1419347155,0),(1196,0,0,1419347171,0),(1197,0,0,1419347100,0),(1198,0,0,1419347048,0),(1199,0,0,1419347110,0),(1200,0,0,1419347113,0),(1201,0,0,1419347104,0),(1202,0,0,1419347073,0),(1203,0,0,1419347098,0),(1204,0,0,1419347013,0),(1205,0,0,1419347069,0),(1206,0,0,1419347217,0),(1207,0,0,1419347181,0),(1208,0,0,1419347228,0),(1209,0,0,1419347038,0),(1210,0,0,1419347182,0),(1211,0,0,1419347203,0),(1212,0,0,1419347008,0),(1213,0,0,1419347015,0),(1214,0,0,1419394351,0),(1215,0,0,1419394456,0),(1216,0,0,1419394369,0),(1217,0,0,1419394552,0),(1218,0,0,1419394469,0),(1219,0,0,1419394586,0),(1220,0,0,1419394532,0),(1221,0,0,1419394364,0),(1222,0,0,1419394504,0),(1223,0,0,1419394350,0),(1224,0,0,1419394540,0),(1225,0,0,1419394372,0),(1226,0,0,1419394962,0),(1227,0,0,1419394939,0),(1228,0,0,1419395094,0),(1229,0,0,1419394983,0),(1230,0,0,1419394849,0),(1231,0,0,1419394868,0),(1232,0,0,1419394867,0),(1233,0,0,1419395098,0),(1234,0,0,1419395133,0),(1235,0,0,1419395102,0),(1236,0,0,1419395128,0),(1237,0,0,1419395213,0),(1238,0,0,1419395129,0),(1239,0,0,1419395378,0),(1240,0,0,1419395397,0),(1241,0,0,1419395321,0),(1242,0,0,1419395369,0),(1243,0,0,1419395375,0),(1244,0,0,1419395169,0),(1245,0,0,1419395323,0),(1246,0,0,1419395308,0),(1247,0,0,1419395338,0),(1248,0,0,1419395429,0),(1249,0,0,1419395314,0),(1250,0,0,1419395237,0),(1251,0,0,1419395282,0),(1252,0,0,1419395329,0),(1253,0,0,1419395293,0),(1254,0,0,1419395463,0),(1255,0,0,1419395405,0),(1256,0,0,1419395249,0),(1257,0,0,1419395451,0),(1258,0,0,1419395353,0),(1259,0,0,1419395322,0),(1260,0,0,1419395258,0),(1261,0,0,1419395357,0),(1262,0,0,1419395375,0),(1263,0,0,1419395499,0),(1264,0,0,1419395516,0),(1265,0,0,1419395518,0),(1266,0,0,1419395454,0),(1267,0,0,1419395432,0),(1268,0,0,1419395437,0),(1269,0,0,1419395452,0),(1270,0,0,1419395516,0),(1271,0,0,1419395447,0),(1272,0,0,1419395517,0),(1273,0,0,1419395308,0),(1274,0,0,1419395322,0),(1275,0,0,1419395558,0),(1276,0,0,1419395507,0),(1277,0,0,1419395529,0),(1278,0,0,1419395567,0),(1279,0,0,1419395387,0),(1280,0,0,1419395604,0),(1281,0,0,1419395498,0),(1282,0,0,1419395537,0),(1283,0,0,1419395426,0),(1284,0,0,1419395648,0),(1285,0,0,1419395602,0),(1286,0,0,1419395513,0),(1287,0,0,1419395670,0),(1288,0,0,1419395600,0),(1289,0,0,1419395509,0),(1290,0,0,1419395562,0),(1291,0,0,1419395619,0),(1292,0,0,1419395538,0),(1293,0,0,1419395656,0),(1294,0,0,1419395471,0),(1295,0,0,1419395709,0),(1296,0,0,1419395481,0),(1297,0,0,1419395554,0),(1298,0,0,1419395460,0),(1299,0,0,1419395681,0),(1300,0,0,1419395654,0),(1301,0,0,1419395470,0),(1302,0,0,1419395709,0),(1303,0,0,1419395738,0),(1304,0,0,1419395727,0),(1305,0,0,1419395716,0),(1306,0,0,1419395507,0),(1307,0,0,1419395517,0),(1308,0,0,1419395597,0),(1309,0,0,1419395542,0),(1310,0,0,1419395655,0),(1311,0,0,1419395797,0),(1312,0,0,1419395710,0),(1313,0,0,1419395633,0),(1314,0,0,1419395755,0),(1315,0,0,1419395873,0),(1316,0,0,1419395818,0),(1317,0,0,1419395823,0),(1318,0,0,1419395852,0),(1319,0,0,1419395638,0),(1320,0,0,1419395629,0),(1321,0,0,1419395630,0),(1322,0,0,1419395694,0),(1323,0,0,1419395900,0),(1324,0,0,1419395855,0),(1325,0,0,1419395776,0),(1326,0,0,1419395792,0),(1327,0,0,1419395692,0),(1328,0,0,1419395928,0),(1329,0,0,1419395900,0),(1330,0,0,1419395741,0),(1331,0,0,1419395890,0),(1332,0,0,1419395750,0),(1333,0,0,1419395731,0),(1334,0,0,1419395980,0),(1335,0,0,1419395989,0),(1336,0,0,1419395874,0),(1337,0,0,1419396027,0),(1338,0,0,1419395955,0),(1339,0,0,1419396088,0),(1340,0,0,1419396208,0),(1341,0,0,1419396243,0),(1342,0,0,1419396138,0),(1343,0,0,1419396248,0),(1344,0,0,1419396069,0),(1345,0,0,1419396352,0),(1346,0,0,1419396171,0),(1347,0,0,1419396386,0),(1348,0,0,1419396294,0),(1349,0,0,1419396379,0),(1350,0,0,1419396366,0),(1351,0,0,1419396119,0),(1352,0,0,1419396129,0),(1353,0,0,1419396165,0),(1354,0,0,1419396293,0),(1355,0,0,1419396151,0),(1356,0,0,1419396432,0),(1357,0,0,1419396276,0),(1358,0,0,1419396397,0),(1359,0,0,1419396552,0),(1360,0,0,1419396473,0),(1361,0,0,1419396616,0),(1362,0,0,1419396487,0),(1363,0,0,1419396434,0),(1364,0,0,1419396340,0),(1365,0,0,1419396450,0),(1366,0,0,1419396468,0),(1367,0,0,1419396456,0),(1368,0,0,1419396483,0),(1369,0,0,1419396539,0),(1370,0,0,1419396504,0),(1371,0,0,1419396498,0),(1372,0,0,1419396498,0),(1373,0,0,1419396486,0),(1374,0,0,1419396524,0),(1375,0,0,1419396542,0),(1376,0,0,1419396644,0),(1377,0,0,1419396760,0),(1378,0,0,1419396533,0),(1379,0,0,1419396634,0),(1380,0,0,1419396708,0),(1381,0,0,1419396514,0),(1382,0,0,1419396804,0),(1383,0,0,1419396744,0),(1384,0,0,1419396702,0),(1385,0,0,1419396654,0),(1386,0,0,1419396698,0),(1387,0,0,1419396867,0),(1388,0,0,1419396943,0),(1389,0,0,1419396915,0),(1390,0,0,1419396891,0),(1391,0,0,1419396960,0),(1392,0,0,1419396840,0),(1393,0,0,1419397085,0),(1394,0,0,1419397003,0),(1395,0,0,1419397080,0),(1396,0,0,1419396981,0),(1397,0,0,1419396901,0),(1398,0,0,1419397114,0),(1399,0,0,1419396914,0),(1400,0,0,1419397066,0),(1401,0,0,1419396898,0),(1402,0,0,1419396999,0),(1403,0,0,1419397048,0),(1404,0,0,1419396924,0),(1405,0,0,1419397069,0),(1406,0,0,1419396945,0),(1407,0,0,1419396986,0),(1408,0,0,1419396961,0),(1409,0,0,1419397208,0),(1410,0,0,1419397039,0),(1411,0,0,1419397209,0),(1412,0,0,1419396946,0),(1413,0,0,1419397029,0),(1414,0,0,1419396999,0),(1415,0,0,1419397086,0),(1416,0,0,1419397211,0),(1417,0,0,1419397016,0),(1418,0,0,1419397075,0),(1419,0,0,1419397283,0),(1420,0,0,1419397156,0),(1421,0,0,1419397035,0),(1422,0,0,1419397275,0),(1423,0,0,1419397274,0),(1424,0,0,1419397296,0),(1425,0,0,1419397263,0),(1426,0,0,1419397093,0),(1427,0,0,1419397071,0),(1428,0,0,1419397127,0),(1429,0,0,1419397353,0),(1430,0,0,1419398083,0),(1431,0,0,1419398215,0),(1432,0,0,1419398249,0),(1433,0,0,1419398352,0),(1434,0,0,1419398212,0),(1435,0,0,1419398301,0),(1436,0,0,1419398152,0),(1437,0,0,1419398347,0),(1438,0,0,1419398169,0),(1439,0,0,1419398146,0),(1440,0,0,1419398355,0),(1441,0,0,1419398235,0),(1442,0,0,1419398259,0),(1443,0,0,1419398389,0),(1444,0,0,1419398363,0),(1445,0,0,1419398284,0),(1446,0,0,1419398300,0),(1447,0,0,1419398203,0),(1448,0,0,1419398333,0),(1449,0,0,1419398277,0),(1450,0,0,1419398366,0),(1451,0,0,1419398412,0),(1452,0,0,1419398296,0),(1453,0,0,1419398329,0),(1454,0,0,1419398229,0),(1455,0,0,1419398373,0),(1456,0,0,1419398273,0),(1457,0,0,1419398344,0),(1458,0,0,1419398237,0),(1459,0,0,1419398481,0),(1460,0,0,1419398333,0),(1461,0,0,1419398356,0),(1462,0,0,1419398439,0),(1463,0,0,1419398327,0),(1464,0,0,1419398500,0),(1465,0,0,1419398279,0),(1466,0,0,1419398466,0),(1467,0,0,1419398275,0),(1468,0,0,1419398426,0),(1469,0,0,1419398357,0),(1470,0,0,1419398300,0),(1471,0,0,1419398416,0),(1472,0,0,1419398346,0),(1473,0,0,1419398291,0),(1474,0,0,1419398344,0),(1475,0,0,1419398291,0),(1476,0,0,1419398295,0),(1477,0,0,1419398393,0),(1478,0,0,1419398329,0),(1479,0,0,1419398303,0),(1480,0,0,1419398525,0),(1481,0,0,1419398566,0),(1482,0,0,1419398334,0),(1483,0,0,1419398419,0),(1484,0,0,1419398368,0),(1485,0,0,1419398380,0),(1486,0,0,1419398443,0),(1487,0,0,1419398573,0),(1488,0,0,1419398448,0),(1489,0,0,1419400881,0),(1490,0,0,1419401004,0),(1491,0,0,1419400950,0),(1492,0,0,1419401413,0),(1493,0,0,1419401304,0),(1494,0,0,1419401475,0),(1495,0,0,1419401509,0),(1496,0,0,1419401363,0),(1497,0,0,1419401573,0),(1498,0,0,1419401515,0),(1499,0,0,1419401531,0),(1500,0,0,1419401617,0),(1501,0,0,1419401548,0),(1502,0,0,1419401527,0),(1503,0,0,1419403635,0),(1504,0,0,1419403677,0),(1505,0,0,1419403833,0),(1506,0,0,1419403714,0),(1507,0,0,1419403596,0),(1508,0,0,1419403773,0),(1509,0,0,1419403700,0),(1510,0,0,1419403724,0),(1511,0,0,1419403715,0),(1512,0,0,1419403725,0),(1513,0,0,1419403887,0),(1514,0,0,1419403889,0),(1515,0,0,1419403766,0),(1516,0,0,1419403857,0),(1517,0,0,1419403841,0),(1518,0,0,1419403754,0),(1519,0,0,1419403848,0),(1520,0,0,1419403760,0),(1521,0,0,1419416268,0),(1522,0,0,1419416276,0),(1523,0,0,1419416505,0),(1524,0,0,1419416325,0),(1525,0,0,1419416566,0),(1526,0,0,1419416393,0),(1527,0,0,1419416553,0),(1528,0,0,1419416463,0),(1529,0,0,1419416411,0),(1530,0,0,1419416342,0),(1531,0,0,1419416461,0),(1532,0,0,1419416440,0),(1533,0,0,1419417022,0),(1534,0,0,1419416856,0),(1535,0,0,1419416903,0),(1536,0,0,1419416852,0),(1537,0,0,1419417052,0),(1538,0,0,1419416987,0),(1539,0,0,1419416958,0),(1540,0,0,1419417018,0),(1541,0,0,1419416957,0),(1542,0,0,1419416982,0),(1543,0,0,1419417081,0),(1544,0,0,1419417094,0),(1545,0,0,1419416962,0),(1546,0,0,1419416883,0),(1547,0,0,1419416828,0),(1548,0,0,1419417117,0),(1549,0,0,1419417020,0),(1550,0,0,1419417015,0),(1551,0,0,1419417013,0),(1552,0,0,1419417032,0),(1553,0,0,1419417072,0),(1554,0,0,1419417132,0),(1555,0,0,1419416981,0),(1556,0,0,1419416961,0),(1557,0,0,1419416875,0),(1558,0,0,1419416942,0),(1559,0,0,1419417069,0),(1560,0,0,1419417054,0),(1561,0,0,1419417027,0),(1562,0,0,1419417049,0),(1563,0,0,1419417052,0),(1564,0,0,1419417105,0),(1565,0,0,1419417123,0),(1566,0,0,1419417068,0),(1567,0,0,1419416920,0),(1568,0,0,1419416996,0),(1569,0,0,1419417017,0),(1570,0,0,1419417057,0),(1571,0,0,1419417009,0),(1572,0,0,1419416907,0),(1573,0,0,1419417008,0),(1574,0,0,1419417058,0),(1575,0,0,1419417136,0),(1576,0,0,1419416981,0),(1577,0,0,1419417111,0),(1578,0,0,1419417197,0),(1579,0,0,1419417059,0),(1580,0,0,1419417205,0),(1581,0,0,1419417069,0),(1582,0,0,1419417055,0),(1583,0,0,1419417193,0),(1584,0,0,1419416952,0),(1585,0,0,1419417149,0),(1586,0,0,1419417211,0),(1587,0,0,1419417005,0),(1588,0,0,1419417186,0),(1589,0,0,1419417033,0),(1590,0,0,1419417161,0),(1591,0,0,1419417226,0),(1592,0,0,1419417124,0),(1593,0,0,1419417002,0),(1594,0,0,1419416980,0),(1595,0,0,1419417062,0),(1596,0,0,1419417109,0),(1597,0,0,1419417098,0),(1598,0,0,1419417175,0),(1599,0,0,1419417038,0),(1600,0,0,1419417169,0),(1601,0,0,1419417110,0),(1602,0,0,1419417191,0),(1603,0,0,1419417048,0),(1604,0,0,1419417055,0),(1605,0,0,1419417154,0),(1606,0,0,1419417130,0),(1607,0,0,1419417258,0),(1608,0,0,1419417153,0),(1609,0,0,1419417296,0),(1610,0,0,1419417211,0),(1611,0,0,1419417070,0),(1612,0,0,1419417301,0),(1613,0,0,1419417032,0),(1614,0,0,1419417171,0),(1615,0,0,1419417154,0),(1616,0,0,1419417241,0),(1617,0,0,1419417237,0),(1618,0,0,1419417226,0),(1619,0,0,1419417328,0),(1620,0,0,1419417212,0),(1621,0,0,1419417141,0),(1622,0,0,1419417342,0),(1623,0,0,1419417112,0),(1624,0,0,1419417159,0),(1625,0,0,1419417249,0),(1626,0,0,1419417321,0),(1627,0,0,1419417367,0),(1628,0,0,1419417099,0),(1629,0,0,1419417369,0),(1630,0,0,1419417087,0),(1631,0,0,1419417360,0),(1632,0,0,1419417108,0),(1633,0,0,1419417259,0),(1634,0,0,1419417170,0),(1635,0,0,1419417393,0),(1636,0,0,1419417364,0),(1637,0,0,1419417294,0),(1638,0,0,1419417127,0),(1639,0,0,1419417301,0),(1640,0,0,1419417117,0),(1641,0,0,1419417223,0),(1642,0,0,1419417354,0),(1643,0,0,1419417311,0),(1644,0,0,1419417290,0),(1645,0,0,1419417261,0),(1646,0,0,1419417193,0),(1647,0,0,1419417135,0),(1648,0,0,1419417362,0),(1649,0,0,1419417170,0),(1650,0,0,1419417187,0),(1651,0,0,1419417150,0),(1652,0,0,1419417366,0),(1653,0,0,1419417333,0),(1654,0,0,1419417265,0),(1655,0,0,1419417322,0),(1656,0,0,1419417308,0),(1657,0,0,1419417269,0),(1658,0,0,1419417169,0),(1659,0,0,1419417258,0),(1660,0,0,1419417286,0),(1661,0,0,1419417457,0),(1662,0,0,1419417410,0),(1663,0,0,1419417406,0),(1664,0,0,1419417257,0),(1665,0,0,1419419624,0),(1666,0,0,1419421077,0),(1667,0,0,1419422419,0),(1668,0,0,1419428637,0),(1669,0,0,1419428755,0),(1670,0,0,1419428927,0),(1671,0,0,1419428715,0),(1672,0,0,1419428789,0),(1673,0,0,1419428799,0),(1674,0,0,1419428747,0),(1675,0,0,1419428820,0),(1676,0,0,1419428735,0),(1677,0,0,1419428809,0),(1678,0,0,1419428939,0),(1679,0,0,1419428682,0),(1680,0,0,1419428772,0),(1681,0,0,1419428898,0),(1682,0,0,1419428803,0),(1683,0,0,1419428942,0),(1684,0,0,1419428728,0),(1685,0,0,1419428796,0),(1686,0,0,1419428810,0),(1687,0,0,1419428734,0),(1688,0,0,1419429027,0),(1689,0,0,1419429041,0),(1690,0,0,1419429084,0),(1691,0,0,1419428978,0),(1692,0,0,1419429017,0),(1693,0,0,1419428851,0),(1694,0,0,1419429096,0),(1695,0,0,1419429073,0),(1696,0,0,1419428952,0),(1697,0,0,1419428989,0),(1698,0,0,1419428874,0),(1699,0,0,1419429099,0),(1700,0,0,1419428874,0),(1701,0,0,1419428883,0),(1702,0,0,1419428990,0),(1703,0,0,1419428891,0),(1704,0,0,1419429153,0),(1705,0,0,1419429063,0),(1706,0,0,1419428999,0),(1707,0,0,1419429041,0),(1708,0,0,1419429161,0),(1709,0,0,1419429002,0),(1710,0,0,1419428937,0),(1711,0,0,1419429134,0),(1712,0,0,1419429070,0),(1713,0,0,1419429042,0),(1714,0,0,1419429153,0),(1715,0,0,1419429141,0),(1716,0,0,1419428908,0),(1717,0,0,1419429160,0),(1718,0,0,1419429016,0),(1719,0,0,1419428918,0),(1720,0,0,1419429182,0),(1721,0,0,1419429018,0),(1722,0,0,1419429221,0),(1723,0,0,1419429198,0),(1724,0,0,1419429101,0),(1725,0,0,1419428959,0),(1726,0,0,1419429096,0),(1727,0,0,1419429146,0),(1728,0,0,1419429141,0),(1729,0,0,1419429057,0),(1730,0,0,1419428953,0),(1731,0,0,1419429100,0),(1732,0,0,1419429129,0),(1733,0,0,1419429233,0),(1734,0,0,1419429242,0),(1735,0,0,1419428980,0),(1736,0,0,1419429110,0),(1737,0,0,1419429010,0),(1738,0,0,1419429208,0),(1739,0,0,1419429087,0),(1740,0,0,1419428995,0),(1741,0,0,1419429200,0),(1742,0,0,1419592421,0),(1743,0,0,1419592285,0),(1744,0,0,1419592486,0),(1745,0,0,1419592284,0),(1746,0,0,1419592473,0),(1747,0,0,1419592496,0),(1748,0,0,1419592462,0),(1749,0,0,1419592415,0),(1750,0,0,1419600310,0),(1751,0,0,1419600577,0),(1752,0,0,1419600605,0),(1753,0,0,1419600338,0),(1754,0,0,1419600545,0),(1755,0,0,1419600364,0),(1756,0,0,1419600600,0),(1757,0,0,1419600380,0),(1758,0,0,1419600448,0),(1759,0,0,1419600456,0),(1760,0,0,1419600531,0),(1761,0,0,1419600480,0),(1762,0,0,1419600487,0),(1763,0,0,1419600615,0),(1764,0,0,1419600694,0),(1765,0,0,1419600625,0),(1766,0,0,1419600681,0),(1767,0,0,1419600715,0),(1768,0,0,1419600600,0),(1769,0,0,1419600709,0),(1770,0,0,1419600523,0),(1771,0,0,1419600480,0),(1772,0,0,1419600732,0),(1773,0,0,1419600594,0),(1774,0,0,1419600661,0),(1775,0,0,1419600584,0),(1776,0,0,1419600718,0),(1777,0,0,1419600575,0),(1778,0,0,1419601973,0),(1779,0,0,1419601811,0),(1780,0,0,1419602004,0),(1781,0,0,1419601962,0),(1782,0,0,1419601956,0),(1783,0,0,1419601911,0),(1784,0,0,1419602163,0),(1785,0,0,1419602000,0),(1786,0,0,1419602194,0),(1787,0,0,1419602206,0),(1788,0,0,1419603454,0),(1789,0,0,1419604019,0),(1790,0,0,1419604700,0),(1791,0,0,1419605347,0),(1792,0,0,1419605999,0),(1793,0,0,1419658288,0),(1794,0,0,1419658266,0),(1795,0,0,1419658319,0),(1796,0,0,1419658065,0),(1797,0,0,1419658212,0),(1798,0,0,1419658152,0),(1799,0,0,1419658159,0),(1800,0,0,1419658125,0),(1801,0,0,1419658224,0),(1802,0,0,1419658247,0),(1803,0,0,1419658189,0),(1804,0,0,1419658284,0),(1805,0,0,1419658381,0),(1806,0,0,1419658274,0),(1807,0,0,1419658233,0),(1808,0,0,1419658318,0),(1809,0,0,1419658228,0),(1810,0,0,1419658284,0),(1811,0,0,1419658430,0),(1812,0,0,1419658338,0),(1813,0,0,1419658494,0),(1814,0,0,1419658331,0),(1815,0,0,1419658383,0),(1816,0,0,1419658577,0),(1817,0,0,1419658373,0),(1818,0,0,1419658597,0),(1819,0,0,1419658624,0),(1820,0,0,1419658581,0),(1821,0,0,1419658677,0),(1822,0,0,1419658493,0),(1823,0,0,1419658508,0),(1824,0,0,1419658615,0),(1825,0,0,1419658570,0),(1826,0,0,1419658588,0),(1827,0,0,1419658508,0),(1828,0,0,1419658762,0),(1829,0,0,1419658639,0),(1830,0,0,1419658703,0),(1831,0,0,1419658732,0),(1832,0,0,1419658575,0),(1833,0,0,1419658809,0),(1834,0,0,1419658614,0),(1835,0,0,1419658671,0),(1836,0,0,1419658776,0),(1837,0,0,1419658657,0),(1838,0,0,1419658831,0),(1839,0,0,1419658757,0),(1840,0,0,1419658757,0),(1841,0,0,1419658748,0),(1842,0,0,1419658904,0),(1843,0,0,1419658938,0),(1844,0,0,1419658771,0),(1845,0,0,1419658874,0),(1846,0,0,1419658803,0),(1847,0,0,1419658757,0),(1848,0,0,1419658965,0),(1849,0,0,1419658940,0),(1850,0,0,1419658872,0),(1851,0,0,1419658791,0),(1852,0,0,1419658902,0),(1853,0,0,1419658937,0),(1854,0,0,1419743465,0),(1855,0,0,1419744385,0),(1856,0,0,1419745134,0),(1857,0,0,1419746258,0),(1858,0,0,1419747401,0),(1859,0,0,1419749152,0),(1860,0,0,1419772236,0),(1861,0,0,1419773089,0),(1862,0,0,1419776966,0),(1863,0,0,1419826830,0),(1864,0,0,1419829879,0),(1865,0,0,1419853813,0),(1866,0,0,1419856005,0),(1867,0,0,1419857484,0),(1868,0,0,1419858319,0),(1869,0,0,1419859626,0),(1870,0,0,1419862047,0),(1871,0,0,1419863783,0),(1872,0,0,1419864542,0),(1873,0,0,1419919056,0),(1874,0,0,1419919114,0),(1875,0,0,1419918870,0),(1876,0,0,1419918916,0),(1877,0,0,1419918997,0),(1878,0,0,1419919073,0),(1879,0,0,1419945633,0),(1880,0,0,1420178958,0),(1881,0,0,1420178753,0),(1882,0,0,1420178804,0),(1883,0,0,1420178715,0),(1884,0,0,1420178894,0),(1885,0,0,1420178935,0),(1886,0,0,1420178800,0),(1887,0,0,1420178976,0),(1888,0,0,1420178864,0),(1889,0,0,1420178981,0),(1890,0,0,1420178986,0),(1891,0,0,1420178883,0),(1892,0,0,1420178993,0),(1893,0,0,1420178834,0),(1894,0,0,1420178739,0),(1895,0,0,1420178865,0),(1896,0,0,1420178962,0),(1897,0,0,1420178885,0),(1898,0,0,1420178920,0),(1899,0,0,1420178906,0),(1900,0,0,1420178762,0),(1901,0,0,1420178804,0),(1902,0,0,1420178889,0),(1903,0,0,1420178809,0),(1904,0,0,1420178911,0),(1905,0,0,1420205832,0),(1906,0,0,1420260083,0),(1907,0,0,1420260333,0),(1908,0,0,1420260356,0),(1909,0,0,1420260360,0),(1910,0,0,1420260132,0),(1911,0,0,1420260249,0),(1912,0,0,1420260338,0),(1913,0,0,1420260171,0),(1914,0,0,1420260380,0),(1915,0,0,1420260206,0),(1916,0,0,1420260228,0),(1917,0,0,1420260249,0),(1918,0,0,1420260220,0),(1919,0,0,1420260341,0),(1920,0,0,1420260317,0),(1921,0,0,1420260411,0),(1922,0,0,1420289416,0),(1923,0,0,1420289334,0),(1924,0,0,1420289627,0),(1925,0,0,1420289405,0),(1926,0,0,1420289514,0),(1927,0,0,1420289578,0),(1928,0,0,1420289556,0),(1929,0,0,1420289644,0),(1930,0,0,1420289378,0),(1931,0,0,1420289579,0),(1932,0,0,1420289373,0),(1933,0,0,1420289523,0),(1934,0,0,1420289594,0),(1935,0,0,1420289613,0),(1936,0,0,1420289568,0),(1937,0,0,1420289528,0),(1938,0,0,1420289528,0),(1939,0,0,1420289499,0),(1940,0,0,1420289591,0),(1941,0,0,1420289606,0),(1942,0,0,1420289702,0),(1943,0,0,1420289718,0),(1944,0,0,1420289593,0),(1945,0,0,1420289567,0),(1946,0,0,1420289587,0),(1947,0,0,1420289515,0),(1948,0,0,1420289540,0),(1949,0,0,1420289456,0),(1950,0,0,1420289654,0),(1951,0,0,1420289457,0),(1952,0,0,1420289545,0),(1953,0,0,1420289706,0),(1954,0,0,1420289601,0),(1955,0,0,1420289534,0),(1956,0,0,1420434799,0),(1957,0,0,1420434800,0),(1958,0,0,1420434854,0),(1959,0,0,1420434918,0),(1960,0,0,1420434796,0),(1961,0,0,1420434705,0),(1962,0,0,1420434873,0),(1963,0,0,1420434722,0),(1964,0,0,1420434845,0),(1965,0,0,1420434985,0),(1966,0,0,1420434717,0),(1967,0,0,1420434849,0),(1968,0,0,1420434988,0),(1969,0,0,1420434820,0),(1970,0,0,1420434827,0),(1971,0,0,1420434983,0),(1972,0,0,1420434905,0),(1973,0,0,1420434882,0),(1974,0,0,1420434932,0),(1975,0,0,1420434804,0),(1976,0,0,1420434745,0),(1977,0,0,1420434766,0),(1978,0,0,1420434928,0),(1979,0,0,1420435028,0),(1980,0,0,1420435039,0),(1981,0,0,1420434851,0),(1982,0,0,1420434911,0),(1983,0,0,1420434903,0),(1984,0,0,1420435061,0),(1985,0,0,1420435012,0),(1986,0,0,1420434879,0),(1987,0,0,1420434810,0),(1988,0,0,1420434911,0),(1989,0,0,1420434795,0),(1990,0,0,1420434957,0),(1991,0,0,1420435054,0),(1992,0,0,1420434938,0),(1993,0,0,1420434847,0),(1994,0,0,1420434857,0),(1995,0,0,1420434862,0),(1996,0,0,1420434804,0),(1997,0,0,1420435044,0),(1998,0,0,1420435086,0),(1999,0,0,1420434911,0),(2000,0,0,1420434945,0),(2001,0,0,1420435036,0),(2002,0,0,1420434862,0),(2003,0,0,1420434988,0),(2004,0,0,1420435032,0),(2005,0,0,1420435057,0),(2006,0,0,1420435003,0),(2007,0,0,1420435013,0),(2008,0,0,1420434923,0),(2009,0,0,1420435069,0),(2010,0,0,1420434956,0),(2011,0,0,1420435116,0),(2012,0,0,1420434893,0),(2013,0,0,1420435115,0),(2014,0,0,1420435002,0),(2015,0,0,1420434873,0),(2016,0,0,1420435124,0),(2017,0,0,1420435057,0),(2018,0,0,1420435043,0),(2019,0,0,1420434917,0),(2020,0,0,1420434939,0),(2021,0,0,1420435124,0),(2022,0,0,1420434939,0),(2023,0,0,1420435182,0),(2024,0,0,1420435136,0),(2025,0,0,1420435154,0),(2026,0,0,1420635166,0),(2027,0,0,1420641728,0),(2028,0,0,1420642271,0),(2029,0,0,1420642674,0),(2030,0,0,1420690597,0),(2031,0,0,1420691085,0),(2032,0,0,1420690927,0),(2033,0,0,1420691716,0),(2034,0,0,1420692335,0),(2035,0,0,1420692798,0),(2036,0,0,1420693538,0),(2037,0,0,1420694542,0),(2038,0,0,1420695011,0),(2039,0,0,1420695894,0),(2040,0,0,1420715126,0),(2041,0,0,1420716474,0),(2042,0,0,1420716976,0),(2043,0,0,1420717244,0),(2044,0,0,1420717312,0),(2045,0,0,1420717245,0),(2046,0,0,1420717420,0),(2047,0,0,1420718821,0),(2048,0,0,1420719549,0),(2049,0,0,1420719958,0),(2050,0,0,1420720488,0),(2051,0,0,1420720937,0),(2052,0,0,1420721554,0),(2053,0,0,1420724509,0),(2054,0,0,1420725065,0),(2055,0,0,1420725592,0),(2056,0,0,1420725946,0),(2057,0,0,1420726542,0),(2058,0,0,1420726828,0),(2059,0,0,1420727164,0),(2060,0,0,1420727578,0),(2061,0,0,1420728053,0),(2062,0,0,1420728369,0),(2063,0,0,1420728709,0),(2064,0,0,1420729302,0),(2065,0,0,1420776411,0),(2066,0,0,1420776893,0),(2067,0,0,1420779034,0),(2068,0,0,1420779305,0),(2069,0,0,1420779848,0),(2070,0,0,1420780301,0),(2071,0,0,1420780827,0),(2072,0,0,1420781298,0),(2073,0,0,1420782388,0),(2074,0,0,1420782977,0),(2075,0,0,1420783333,0),(2076,0,0,1420783900,0),(2077,0,0,1420801253,0),(2078,0,0,1420895080,0),(2079,0,0,1420895648,0),(2080,0,0,1420896180,0),(2081,0,0,1420896196,0),(2082,0,0,1420896145,0),(2083,0,0,1420896085,0),(2084,0,0,1420896658,0),(2085,0,0,1420897034,0),(2086,0,0,1420897137,0),(2087,0,0,1420896966,0),(2088,0,0,1420897093,0),(2089,0,0,1420897014,0),(2090,0,0,1420897190,0),(2091,0,0,1420897004,0),(2092,0,0,1420897084,0),(2093,0,0,1420897219,0),(2094,0,0,1420896985,0),(2095,0,0,1420897072,0),(2096,0,0,1420897181,0),(2097,0,0,1420897018,0),(2098,0,0,1420897166,0),(2099,0,0,1420897203,0),(2100,0,0,1420896982,0),(2101,0,0,1420897072,0),(2102,0,0,1420897086,0),(2103,0,0,1420897089,0),(2104,0,0,1420897235,0),(2105,0,0,1420897237,0),(2106,0,0,1420897102,0),(2107,0,0,1420897105,0),(2108,0,0,1420896992,0),(2109,0,0,1420897290,0),(2110,0,0,1420897344,0),(2111,0,0,1420897768,0),(2112,0,0,1420897760,0),(2113,0,0,1420897742,0),(2114,0,0,1420897898,0),(2115,0,0,1420897896,0),(2116,0,0,1420897903,0),(2117,0,0,1420897793,0),(2118,0,0,1420898009,0),(2119,0,0,1420897818,0),(2120,0,0,1420898135,0),(2121,0,0,1420898148,0),(2122,0,0,1420898191,0),(2123,0,0,1420897910,0),(2124,0,0,1420897965,0),(2125,0,0,1420898077,0),(2126,0,0,1420898186,0),(2127,0,0,1420898011,0),(2128,0,0,1420898103,0),(2129,0,0,1420898215,0),(2130,0,0,1420898216,0),(2131,0,0,1420898040,0),(2132,0,0,1420897991,0),(2133,0,0,1420898179,0),(2134,0,0,1420898054,0),(2135,0,0,1420898134,0),(2136,0,0,1420898133,0),(2137,0,0,1420898001,0),(2138,0,0,1420898195,0),(2139,0,0,1420898218,0),(2140,0,0,1420898228,0),(2141,0,0,1420897989,0),(2142,0,0,1420898237,0),(2143,0,0,1420898022,0),(2144,0,0,1420898418,0),(2145,0,0,1420898175,0),(2146,0,0,1420898221,0),(2147,0,0,1420898323,0),(2148,0,0,1420898427,0),(2149,0,0,1420898278,0),(2150,0,0,1420898387,0),(2151,0,0,1420898270,0),(2152,0,0,1420898461,0),(2153,0,0,1420898256,0),(2154,0,0,1420898254,0),(2155,0,0,1420898368,0),(2156,0,0,1420898221,0),(2157,0,0,1420898445,0),(2158,0,0,1420898658,0),(2159,0,0,1420898648,0),(2160,0,0,1420898611,0),(2161,0,0,1420898490,0),(2162,0,0,1420898501,0),(2163,0,0,1420898598,0),(2164,0,0,1420898686,0),(2165,0,0,1420898573,0),(2166,0,0,1420898565,0),(2167,0,0,1420898513,0),(2168,0,0,1420898601,0),(2169,0,0,1420898640,0),(2170,0,0,1420898601,0),(2171,0,0,1420898488,0),(2172,0,0,1420898712,0),(2173,0,0,1420898435,0),(2174,0,0,1420898618,0),(2175,0,0,1420899128,0),(2176,0,0,1420899044,0),(2177,0,0,1420899112,0),(2178,0,0,1420899228,0),(2179,0,0,1420899265,0),(2180,0,0,1420899104,0),(2181,0,0,1420899028,0),(2182,0,0,1420899104,0),(2183,0,0,1420899087,0),(2184,0,0,1420899215,0),(2185,0,0,1420899066,0),(2186,0,0,1420899123,0),(2187,0,0,1420899021,0),(2188,0,0,1420899102,0),(2189,0,0,1420899105,0),(2190,0,0,1420899159,0),(2191,0,0,1420899303,0),(2192,0,0,1420899267,0),(2193,0,0,1420899129,0),(2194,0,0,1420899049,0),(2195,0,0,1420899056,0),(2196,0,0,1420899197,0),(2197,0,0,1420899149,0),(2198,0,0,1420899137,0),(2199,0,0,1420899265,0),(2200,0,0,1420899131,0),(2201,0,0,1420899338,0),(2202,0,0,1420899224,0),(2203,0,0,1420899105,0),(2204,0,0,1420899223,0),(2205,0,0,1420899214,0),(2206,0,0,1420899127,0),(2207,0,0,1420899190,0),(2208,0,0,1420899226,0),(2209,0,0,1420899291,0),(2210,0,0,1420899103,0),(2211,0,0,1420899286,0),(2212,0,0,1420899368,0),(2213,0,0,1420899369,0),(2214,0,0,1420899131,0),(2215,0,0,1420899268,0),(2216,0,0,1420899329,0),(2217,0,0,1420899288,0),(2218,0,0,1420899388,0),(2219,0,0,1420899277,0),(2220,0,0,1420899277,0),(2221,0,0,1420899291,0),(2222,0,0,1420899344,0),(2223,0,0,1420899386,0),(2224,0,0,1420899353,0),(2225,0,0,1420899164,0),(2226,0,0,1420899234,0),(2227,0,0,1420899188,0),(2228,0,0,1420899265,0),(2229,0,0,1420899278,0),(2230,0,0,1420899393,0),(2231,0,0,1420899253,0),(2232,0,0,1420899372,0),(2233,0,0,1420899264,0),(2234,0,0,1420899449,0),(2235,0,0,1420899206,0),(2236,0,0,1420899429,0),(2237,0,0,1420899346,0),(2238,0,0,1420899415,0),(2239,0,0,1420899291,0),(2240,0,0,1420899300,0),(2241,0,0,1420899479,0),(2242,0,0,1420899382,0),(2243,0,0,1420899362,0),(2244,0,0,1420899274,0),(2245,0,0,1420899306,0),(2246,0,0,1420899379,0),(2247,0,0,1420900035,0),(2248,0,0,1420900055,0),(2249,0,0,1420900093,0),(2250,0,0,1420899903,0),(2251,0,0,1420900009,0),(2252,0,0,1420899935,0),(2253,0,0,1420900094,0),(2254,0,0,1420899895,0),(2255,0,0,1420900094,0),(2256,0,0,1420899942,0),(2257,0,0,1420899856,0),(2258,0,0,1420899957,0),(2259,0,0,1420900066,0),(2260,0,0,1420900050,0),(2261,0,0,1420900075,0),(2262,0,0,1420900053,0),(2263,0,0,1420900024,0),(2264,0,0,1420899940,0),(2265,0,0,1420899951,0),(2266,0,0,1420900003,0),(2267,0,0,1420899998,0),(2268,0,0,1420900060,0),(2269,0,0,1420899921,0),(2270,0,0,1420900150,0),(2271,0,0,1420899932,0),(2272,0,0,1420899911,0),(2273,0,0,1420899899,0),(2274,0,0,1420900142,0),(2275,0,0,1420899940,0),(2276,0,0,1420899983,0),(2277,0,0,1420900188,0),(2278,0,0,1420900203,0),(2279,0,0,1420899959,0),(2280,0,0,1420900214,0),(2281,0,0,1420900048,0),(2282,0,0,1420900132,0),(2283,0,0,1420899986,0),(2284,0,0,1420900208,0),(2285,0,0,1420899968,0),(2286,0,0,1420900109,0),(2287,0,0,1420900137,0),(2288,0,0,1420900104,0),(2289,0,0,1420900023,0),(2290,0,0,1420900226,0),(2291,0,0,1420900083,0),(2292,0,0,1420900189,0),(2293,0,0,1420900013,0),(2294,0,0,1420899979,0),(2295,0,0,1420900212,0),(2296,0,0,1420900145,0),(2297,0,0,1420900230,0),(2298,0,0,1420900067,0),(2299,0,0,1420900253,0),(2300,0,0,1420900252,0),(2301,0,0,1420900288,0),(2302,0,0,1420900233,0),(2303,0,0,1420900149,0),(2304,0,0,1420900344,0),(2305,0,0,1420900293,0),(2306,0,0,1420900276,0),(2307,0,0,1420900268,0),(2308,0,0,1420900264,0),(2309,0,0,1420900308,0),(2310,0,0,1420900906,0),(2311,0,0,1420956876,0),(2312,0,0,1420971443,0),(2313,0,0,1420972249,0),(2314,0,0,1420974228,0),(2315,0,0,1420979919,0),(2316,0,0,1420980304,0),(2317,0,0,1420980258,0),(2318,0,0,1420980491,0),(2319,0,0,1420980295,0),(2320,0,0,1420980427,0),(2321,0,0,1420980367,0),(2322,0,0,1420980533,0),(2323,0,0,1420980344,0),(2324,0,0,1420980395,0),(2325,0,0,1420981197,0),(2326,0,0,1420980966,0),(2327,0,0,1420981015,0),(2328,0,0,1420981159,0),(2329,0,0,1420981176,0),(2330,0,0,1420980964,0),(2331,0,0,1420981141,0),(2332,0,0,1420980979,0),(2333,0,0,1420980976,0),(2334,0,0,1420980998,0),(2335,0,0,1420981232,0),(2336,0,0,1420981263,0),(2337,0,0,1420981196,0),(2338,0,0,1420981255,0),(2339,0,0,1420984650,0),(2340,0,0,1420984506,0),(2341,0,0,1420984639,0),(2342,0,0,1420984541,0),(2343,0,0,1420984814,0),(2344,0,0,1420984691,0),(2345,0,0,1420984687,0),(2346,0,0,1420984676,0),(2347,0,0,1420984605,0),(2348,0,0,1420984561,0),(2349,0,0,1420984553,0),(2350,0,0,1420984640,0),(2351,0,0,1420984611,0),(2352,0,0,1420984796,0),(2353,0,0,1420984740,0),(2354,0,0,1420984837,0),(2355,0,0,1420984759,0),(2356,0,0,1420984745,0),(2357,0,0,1420984768,0),(2358,0,0,1420984740,0),(2359,0,0,1420984733,0),(2360,0,0,1420984588,0),(2361,0,0,1420985657,0),(2362,0,0,1420985951,0),(2363,0,0,1420986429,0),(2364,0,0,1420986885,0),(2365,0,0,1420987065,0),(2366,0,0,1421039599,0),(2367,0,0,1421039589,0),(2368,0,0,1421039592,0),(2369,0,0,1421039580,0),(2370,0,0,1421039619,0),(2371,0,0,1421039464,0),(2372,0,0,1421039619,0),(2373,0,0,1421058009,0),(2374,0,0,1421057939,0),(2375,0,0,1421057935,0),(2376,0,0,1421058108,0),(2377,0,0,1421058099,0),(2378,0,0,1421057915,0),(2379,0,0,1421058149,0),(2380,0,0,1421057950,0),(2381,0,0,1421058136,0),(2382,0,0,1421057966,0),(2383,0,0,1421058153,0),(2384,0,0,1421058056,0),(2385,0,0,1421057964,0),(2386,0,0,1421057985,0),(2387,0,0,1421058097,0),(2388,0,0,1421057918,0),(2389,0,0,1421057945,0),(2390,0,0,1421058211,0),(2391,0,0,1421057914,0),(2392,0,0,1421058040,0),(2393,0,0,1421057925,0),(2394,0,0,1421058215,0),(2395,0,0,1421058174,0),(2396,0,0,1421057962,0),(2397,0,0,1421058257,0),(2398,0,0,1421058155,0),(2399,0,0,1421058181,0),(2400,0,0,1421058324,0),(2401,0,0,1421058333,0),(2402,0,0,1421058211,0),(2403,0,0,1421058297,0),(2404,0,0,1421058079,0),(2405,0,0,1421058308,0),(2406,0,0,1421058349,0),(2407,0,0,1421058099,0),(2408,0,0,1421058118,0),(2409,0,0,1421058118,0),(2410,0,0,1421058119,0),(2411,0,0,1421058196,0),(2412,0,0,1421058121,0),(2413,0,0,1421058176,0),(2414,0,0,1421058244,0),(2415,0,0,1421058209,0),(2416,0,0,1421058265,0),(2417,0,0,1421058245,0),(2418,0,0,1421058125,0),(2419,0,0,1421058325,0),(2420,0,0,1421058186,0),(2421,0,0,1421058236,0),(2422,0,0,1421058150,0),(2423,0,0,1421058260,0),(2424,0,0,1421058240,0),(2425,0,0,1421058331,0),(2426,0,0,1421058240,0),(2427,0,0,1421058204,0),(2428,0,0,1421058363,0),(2429,0,0,1421058322,0),(2430,0,0,1421058221,0),(2431,0,0,1421058393,0),(2432,0,0,1421058472,0),(2433,0,0,1421058326,0),(2434,0,0,1421058214,0),(2435,0,0,1421058377,0),(2436,0,0,1421058353,0),(2437,0,0,1421058211,0),(2438,0,0,1421058394,0),(2439,0,0,1421058260,0),(2440,0,0,1421058442,0),(2441,0,0,1421058255,0),(2442,0,0,1421058422,0),(2443,0,0,1421058215,0),(2444,0,0,1421058247,0),(2445,0,0,1421058333,0),(2446,0,0,1421058254,0),(2447,0,0,1421058496,0),(2448,0,0,1421058271,0),(2449,0,0,1421058375,0),(2450,0,0,1421058416,0),(2451,0,0,1421058495,0),(2452,0,0,1421058394,0),(2453,0,0,1421059497,0),(2454,0,0,1421059357,0),(2455,0,0,1421059630,0),(2456,0,0,1421059536,0),(2457,0,0,1421059378,0),(2458,0,0,1421059445,0),(2459,0,0,1421059511,0),(2460,0,0,1421059470,0),(2461,0,0,1421059410,0),(2462,0,0,1421059430,0),(2463,0,0,1421059576,0),(2464,0,0,1421059480,0),(2465,0,0,1421059597,0),(2466,0,0,1421059420,0),(2467,0,0,1421059595,0),(2468,0,0,1421059453,0),(2469,0,0,1421059440,0),(2470,0,0,1421059406,0),(2471,0,0,1421059445,0),(2472,0,0,1421059471,0),(2473,0,0,1421059549,0),(2474,0,0,1421059554,0),(2475,0,0,1421059503,0),(2476,0,0,1421059554,0),(2477,0,0,1421059467,0),(2478,0,0,1421059671,0),(2479,0,0,1421059599,0),(2480,0,0,1421059692,0),(2481,0,0,1421059656,0),(2482,0,0,1421059537,0),(2483,0,0,1421059527,0),(2484,0,0,1421059428,0),(2485,0,0,1421059522,0),(2486,0,0,1421059677,0),(2487,0,0,1421059494,0),(2488,0,0,1421059522,0),(2489,0,0,1421059449,0),(2490,0,0,1421059466,0),(2491,0,0,1421059604,0),(2492,0,0,1421059544,0),(2493,0,0,1421059660,0),(2494,0,0,1421059664,0),(2495,0,0,1421059621,0),(2496,0,0,1421059740,0),(2497,0,0,1421059637,0),(2498,0,0,1421059655,0),(2499,0,0,1421059559,0),(2500,0,0,1421059487,0),(2501,0,0,1421059510,0),(2502,0,0,1421059531,0),(2503,0,0,1421059667,0),(2504,0,0,1421059527,0),(2505,0,0,1421059606,0),(2506,0,0,1421059663,0),(2507,0,0,1421122484,0);
/*!40000 ALTER TABLE `uday_gfi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uday_goldencoin`
--

DROP TABLE IF EXISTS `uday_goldencoin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uday_goldencoin` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `uid` int(100) NOT NULL DEFAULT '0',
  `coin` int(100) NOT NULL DEFAULT '0',
  `createtime` int(100) NOT NULL DEFAULT '0',
  `catchtime` int(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=339 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uday_goldencoin`
--

LOCK TABLES `uday_goldencoin` WRITE;
/*!40000 ALTER TABLE `uday_goldencoin` DISABLE KEYS */;
INSERT INTO `uday_goldencoin` (`id`, `uid`, `coin`, `createtime`, `catchtime`) VALUES (1,1,1,1407560510,1407564056),(2,7,1,1407564526,1415631759),(3,7,1,1415631996,1415672227),(4,7,1,1415672727,1415673388),(5,9,1,1415673852,1415676713),(6,7,1,1415677166,1415678183),(7,7,1,1415678437,1415694408),(8,1,1,1415694644,1415717726),(9,32,1,1415718189,1415758635),(10,32,1,1415758925,1415759222),(11,32,1,1415759622,1415759753),(12,32,1,1415760087,1415781155),(13,19,1,1415781489,1415802212),(14,19,1,1415802545,1415802563),(15,19,1,1415802869,1415803058),(16,19,1,1415803377,1415803496),(17,19,1,1415803924,1415806922),(18,30,1,1415807167,1415891599),(19,30,1,1415891941,1415891968),(20,30,1,1415892447,1415892479),(21,30,1,1415892977,1415893062),(22,30,1,1415893529,1415893682),(23,30,1,1415893945,1415893960),(24,30,1,1415894304,1415894325),(25,62,1,1415894526,1415952034),(26,62,1,1415952338,1415952348),(27,62,1,1415952671,1415952677),(28,62,1,1415952883,1415952985),(29,62,1,1415953369,1415953476),(30,62,1,1415953740,1415954202),(31,62,1,1415954594,1415954704),(32,62,1,1415955121,1415955448),(33,62,1,1415955749,1415955866),(34,62,1,1415956189,1415956199),(35,62,1,1415956505,1415956583),(36,62,1,1415957025,1415957035),(37,62,1,1415957410,1415957492),(38,62,1,1415957821,1415957980),(39,13,1,1415958263,1415958268),(40,62,1,1415958685,1415958823),(41,62,1,1415959201,1415974927),(42,84,1,1415975306,1415975848),(43,62,1,1415976223,1415977389),(44,62,1,1415977626,1415978186),(45,62,1,1415978617,1415979839),(46,62,1,1415980047,1415980396),(47,62,1,1415980638,1416017306),(48,62,1,1416017506,1416017526),(49,62,1,1416017772,1416017781),(50,62,1,1416018084,1416019206),(51,62,1,1416019557,1416019610),(52,62,1,1416019981,1416020250),(53,62,1,1416020619,1416020721),(54,62,1,1416021038,1416021364),(55,62,1,1416021861,1416022022),(56,62,1,1416022455,1416022704),(57,62,1,1416022913,1416023084),(58,62,1,1416023506,1416023535),(59,62,1,1416023829,1416023839),(60,62,1,1416024309,1416039191),(61,62,1,1416039611,1416039938),(62,62,1,1416040185,1416040719),(63,62,1,1416040941,1416043751),(64,62,1,1416044175,1416044289),(65,62,1,1416044540,1416045045),(66,19,1,1416045311,1416060172),(67,19,1,1416060455,1416061144),(68,62,1,1416061393,1416061487),(69,19,1,1416061909,1416061927),(70,19,1,1416062204,1416062758),(71,19,1,1416063136,1416063145),(72,19,1,1416063617,1416063701),(73,19,1,1416064175,1416064182),(74,19,1,1416064443,1416064453),(75,19,1,1416064665,1416064680),(76,19,1,1416065081,1416065130),(77,19,1,1416065333,1416065352),(78,19,1,1416065775,1416065929),(79,62,1,1416066338,1416066345),(80,19,1,1416066714,1416066724),(81,19,1,1416066990,1416067015),(82,62,1,1416067320,1416104267),(83,62,1,1416104639,1416106716),(84,62,1,1416107185,1416108950),(85,62,1,1416109241,1416109250),(86,13,1,1416109452,1416125347),(87,60,1,1416125763,1416126450),(88,7,1,1416126919,1416127060),(89,19,1,1416127365,1416127385),(90,19,1,1416127661,1416151952),(91,19,1,1416152322,1416152640),(92,30,1,1416153006,1416302636),(93,30,1,1416302929,1416303307),(94,30,1,1416303614,1416303698),(95,1,1,1416303926,1416304369),(96,102,1,1416304694,1416319244),(97,102,1,1416319701,1416320711),(98,102,1,1416320947,1416323866),(99,102,1,1416324216,1416324363),(100,102,1,1416324734,1416324878),(101,7,1,1416325328,1416366716),(102,53,1,1416367205,1416387859),(103,102,1,1416388303,1416476073),(104,19,1,1416476544,1416492012),(105,19,1,1416492327,1416492340),(106,102,1,1416492602,1416493047),(107,102,1,1416493420,1416493434),(108,102,1,1416493877,1416493989),(109,102,1,1416494281,1416494370),(110,102,1,1416494829,1416494859),(111,102,1,1416495247,1416495434),(112,102,1,1416495925,1416496002),(113,102,1,1416496350,1416496389),(114,2,1,1416496719,1416496739),(115,13,1,1416497081,1416497414),(116,2,1,1416497778,1416497791),(117,102,1,1416498053,1416498416),(118,102,1,1416498641,1416498645),(119,102,1,1416498962,1416498972),(120,46,1,1416499225,1416535585),(121,102,1,1416536039,1416540910),(122,102,1,1416541262,1416541460),(123,102,1,1416541867,1416541924),(124,102,1,1416542182,1416542357),(125,144,1,1416542620,1416627432),(126,102,1,1416627741,1416627754),(127,102,1,1416628184,1416628668),(128,2,1,1416628918,1416670290),(129,144,1,1416670595,1416753562),(130,144,1,1416754032,1416756332),(131,144,1,1416756733,1416757551),(132,169,1,1416757983,1416839549),(133,19,1,1416840005,1416843051),(134,13,1,1416843307,1416905599),(135,102,1,1416906036,1416968152),(136,13,1,1416968616,1416992038),(137,17,1,1416992256,1416993471),(138,102,1,1416993830,1417011801),(139,13,1,1417012266,1417081435),(140,160,1,1417081824,1418221854),(141,190,1,1418222307,1418225547),(142,190,1,1418225892,1418225945),(143,190,1,1418226334,1418226420),(144,190,1,1418226689,1418226705),(145,190,1,1418227149,1418227173),(146,190,1,1418227494,1418264007),(147,190,1,1418264407,1418264416),(148,190,1,1418264675,1418264709),(149,190,1,1418264985,1418265176),(150,190,1,1418265398,1418265539),(151,190,1,1418265758,1418265765),(152,190,1,1418266041,1418267249),(153,190,1,1418267474,1418267599),(154,190,1,1418267834,1418267857),(155,5,1,1418268304,1418286697),(156,5,1,1418287144,1418289207),(157,5,1,1418289642,1418291137),(158,5,1,1418291365,1418291457),(159,5,1,1418291765,1418306783),(160,5,1,1418307241,1418308066),(161,12,1,1418308415,1418354203),(162,18,1,1418354593,1418372722),(163,29,1,1418373130,1418373718),(164,18,1,1418374062,1418392885),(165,29,1,1418393151,1418393169),(166,34,1,1418393515,1418395579),(167,29,1,1418396059,1418398178),(168,31,1,1418398507,1418436600),(169,31,1,1418436926,1418438733),(170,1,1,1418439208,1418486283),(171,31,1,1418486718,1418547457),(172,31,1,1418547824,1418632822),(173,31,1,1418633037,1418634133),(174,31,1,1418634391,1418637038),(175,73,1,1418637395,1418828862),(176,108,1,1418829218,1419001370),(177,108,1,1419001614,1419001693),(178,108,1,1419001946,1419002062),(179,108,1,1419002504,1419002953),(180,108,1,1419003418,1419003441),(181,108,1,1419003642,1419041214),(182,108,1,1419041626,1419041787),(183,111,1,1419042118,1419064818),(184,108,1,1419065025,1419085337),(185,6,1,1419085791,1419130400),(186,6,1,1419130699,1419130709),(187,108,1,1419131119,1419175585),(188,7,1,1419175801,1419325789),(189,5,1,1419326118,1419349038),(190,6,1,1419349343,1419349366),(191,27,1,1419349727,1419411285),(192,1,1,1419411654,1419432085),(193,7,1,1419432565,1419435657),(194,7,1,1419436127,1419436147),(195,27,1,1419436411,1419603180),(196,27,1,1419603525,1419603932),(197,43,1,1419604240,1419604967),(198,43,1,1419605366,1419605418),(199,43,1,1419605661,1419605801),(200,43,1,1419606173,1419606576),(201,43,1,1419607044,1419608465),(202,5,1,1419608757,1419650778),(203,23,1,1419651046,1419670341),(204,81,1,1419670826,1419776613),(205,29,1,1419776999,1419824912),(206,81,1,1419825128,1419840441),(207,29,1,1419840919,1419845414),(208,7,1,1419845908,1419846179),(209,81,1,1419846498,1419861670),(210,81,1,1419861945,1419863393),(211,81,1,1419863614,1419864255),(212,81,1,1419864535,1419868506),(213,81,1,1419868978,1419905177),(214,81,1,1419905495,1419906959),(215,81,1,1419907207,1419907440),(216,81,1,1419907918,1419908437),(217,81,1,1419908667,1419928127),(218,8,1,1419928567,1419931788),(219,154,1,1419932090,1420273372),(220,137,1,1420273777,1420276060),(221,161,1,1420276507,1420277168),(222,161,1,1420277448,1420277750),(223,161,1,1420277980,1420278449),(224,154,1,1420278779,1420297825),(225,129,1,1420298316,1420386201),(226,129,1,1420386485,1420386521),(227,81,1,1420386796,1420424263),(228,7,1,1420424667,1420425623),(229,7,1,1420425953,1420426098),(230,81,1,1420426516,1420427840),(231,184,1,1420428235,1420445144),(232,184,1,1420445441,1420445485),(233,154,1,1420445862,1420445888),(234,184,1,1420446131,1420446143),(235,184,1,1420446513,1420446578),(236,81,1,1420446908,1420447044),(237,137,1,1420447478,1420448030),(238,184,1,1420448424,1420448467),(239,1,1,1420448904,1420450235),(240,124,1,1420450574,1420472625),(241,184,1,1420472853,1420473016),(242,184,1,1420473275,1420510683),(243,184,1,1420510904,1420511008),(244,184,1,1420511342,1420511353),(245,184,1,1420511816,1420511856),(246,184,1,1420512087,1420512179),(247,184,1,1420512425,1420512602),(248,184,1,1420513026,1420513054),(249,184,1,1420513285,1420513374),(250,184,1,1420513823,1420513928),(251,184,1,1420514353,1420514571),(252,184,1,1420515029,1420515094),(253,184,1,1420515562,1420515635),(254,184,1,1420515909,1420516015),(255,184,1,1420516324,1420516378),(256,184,1,1420516641,1420516733),(257,184,1,1420517094,1420531235),(258,184,1,1420531539,1420531564),(259,184,1,1420531956,1420532028),(260,184,1,1420532272,1420532380),(261,184,1,1420532637,1420556319),(262,184,1,1420556576,1420556715),(263,81,1,1420556997,1420557285),(264,154,1,1420557657,1420558852),(265,184,1,1420559120,1420559153),(266,184,1,1420559400,1420559425),(267,154,1,1420559809,1420596631),(268,184,1,1420596933,1420600276),(269,184,1,1420600595,1420600654),(270,184,1,1420600913,1420600922),(271,184,1,1420601370,1420601512),(272,184,1,1420601792,1420601854),(273,7,1,1420602299,1420602311),(274,184,1,1420602744,1420602864),(275,184,1,1420603079,1420603090),(276,184,1,1420603350,1420617804),(277,184,1,1420618179,1420618348),(278,184,1,1420618739,1420618768),(279,184,1,1420619022,1420619213),(280,184,1,1420619553,1420619597),(281,184,1,1420620095,1420621092),(282,184,1,1420621574,1420621614),(283,203,1,1420622058,1420622645),(284,36,1,1420623135,1420623276),(285,203,1,1420623541,1420640470),(286,203,1,1420640868,1420641350),(287,203,1,1420641742,1420641768),(288,201,1,1420642205,1420642375),(289,201,1,1420642646,1420643921),(290,203,1,1420644146,1420644339),(291,7,1,1420644763,1420645645),(292,81,1,1420646042,1420725742),(293,184,1,1420726011,1420726026),(294,184,1,1420726316,1420726390),(295,184,1,1420726825,1420726860),(296,184,1,1420727156,1420727176),(297,184,1,1420727449,1420727551),(298,184,1,1420727770,1420727790),(299,184,1,1420728289,1420728413),(300,184,1,1420728846,1420728905),(301,184,1,1420729275,1420732020),(302,184,1,1420732286,1420732298),(303,184,1,1420732575,1420732611),(304,80,1,1420732977,1420769461),(305,80,1,1420769900,1420770188),(306,80,1,1420770564,1420770587),(307,80,1,1420770832,1420771122),(308,80,1,1420771598,1420771725),(309,80,1,1420772189,1420772224),(310,80,1,1420772567,1420772585),(311,80,1,1420772902,1420772923),(312,80,1,1420773162,1420773233),(313,80,1,1420773658,1420773710),(314,80,1,1420774105,1420774274),(315,80,1,1420774635,1420774719),(316,184,1,1420775183,1420775191),(317,184,1,1420775431,1420775634),(318,184,1,1420775883,1420775893),(319,7,1,1420776195,1420797138),(320,16,1,1420797547,1420861203),(321,16,1,1420861630,1420861657),(322,16,1,1420861927,1420862221),(323,26,1,1420862617,1420880286),(324,1,1,1420880587,1420880720),(325,14,1,1420880928,1420900567),(326,16,1,1420900878,1420902538),(327,16,1,1420903035,1420903142),(328,17,1,1420903555,1420989589),(329,14,1,1420990043,1420990553),(330,53,1,1420990830,1421029816),(331,14,1,1421030133,1421033693),(332,37,1,1421034077,1421049753),(333,60,1,1421049978,1421076760),(334,14,1,1421077088,1421117852),(335,14,1,1421118075,1421118283),(336,17,1,1421118588,1421292183),(337,19,1,1421292473,1421313187),(338,0,0,1421313471,0);
/*!40000 ALTER TABLE `uday_goldencoin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uday_litrate`
--

DROP TABLE IF EXISTS `uday_litrate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uday_litrate` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `uid` int(50) NOT NULL,
  `tid` int(50) NOT NULL,
  `rate` int(5) NOT NULL,
  `time` int(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uday_litrate`
--

LOCK TABLES `uday_litrate` WRITE;
/*!40000 ALTER TABLE `uday_litrate` DISABLE KEYS */;
INSERT INTO `uday_litrate` (`id`, `uid`, `tid`, `rate`, `time`) VALUES (1,1,13,5,1416562690),(2,9,15,5,1418372642),(3,9,20,5,1418916434),(4,81,22,5,1419905306);
/*!40000 ALTER TABLE `uday_litrate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uday_ltag`
--

DROP TABLE IF EXISTS `uday_ltag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uday_ltag` (
  `id` int(50) NOT NULL,
  `tid` int(50) NOT NULL,
  `tags` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uday_ltag`
--

LOCK TABLES `uday_ltag` WRITE;
/*!40000 ALTER TABLE `uday_ltag` DISABLE KEYS */;
/*!40000 ALTER TABLE `uday_ltag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uday_memlike`
--

DROP TABLE IF EXISTS `uday_memlike`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uday_memlike` (
  `id` int(200) NOT NULL AUTO_INCREMENT,
  `uid` int(200) NOT NULL,
  `who` int(200) NOT NULL,
  `time` int(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=76 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uday_memlike`
--

LOCK TABLES `uday_memlike` WRITE;
/*!40000 ALTER TABLE `uday_memlike` DISABLE KEYS */;
INSERT INTO `uday_memlike` (`id`, `uid`, `who`, `time`) VALUES (1,4,1,1415624553),(2,1,4,1415624555),(3,17,9,1415681751),(4,11,28,1415715810),(5,60,7,1415903999),(6,46,62,1416026114),(7,77,46,1416067053),(8,13,86,1416071494),(9,77,7,1416109355),(10,19,7,1416113532),(11,19,1,1416134034),(12,60,91,1416214918),(13,60,5,1416215005),(14,60,9,1416215346),(15,102,5,1416464147),(16,60,136,1416487297),(17,136,60,1416488902),(18,134,2,1416574592),(19,102,1,1416994196),(20,9,2,1418458466),(21,9,4,1418472735),(22,9,52,1418485734),(23,9,54,1418523551),(24,54,4,1418542123),(25,9,58,1418558328),(26,9,64,1418568710),(27,9,29,1418578423),(28,9,20,1418634746),(29,9,69,1418643075),(30,9,12,1418652456),(31,9,83,1418659704),(32,9,6,1418661137),(33,9,55,1418818134),(34,47,1,1419150747),(35,97,117,1419224434),(36,17,7,1419351905),(37,27,15,1419413285),(38,36,1,1419603537),(39,54,52,1419606961),(40,27,1,1419611094),(41,23,61,1419612025),(42,2,20,1419874803),(43,1,15,1419877325),(44,1,1,1420199176),(45,1,134,1420204742),(46,16,144,1420209672),(47,134,1,1420210832),(48,136,124,1420214558),(49,1,180,1420302659),(50,180,1,1420303518),(51,1,181,1420352306),(52,1,0,1420443320),(53,152,0,1420461854),(54,36,0,1420465848),(55,190,36,1420477717),(56,209,189,1420679970),(57,60,1,1421080600),(58,64,12,1421081059),(59,64,1,1421082013),(60,81,1,1421387214),(61,84,13,1421404300),(62,84,1,1421404685),(63,84,3,1421405577),(64,84,4,1421502843),(65,84,91,1421504035),(66,84,9,1421580380),(67,84,99,1421589274),(68,84,101,1421596678),(69,84,37,1421597352),(70,84,65,1421600480),(71,84,68,1421604275),(72,84,95,1421606021),(73,84,16,1421606866),(74,84,110,1421653095),(75,84,111,1421658411);
/*!40000 ALTER TABLE `uday_memlike` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uday_pfpic`
--

DROP TABLE IF EXISTS `uday_pfpic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uday_pfpic` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `des` varchar(100) NOT NULL,
  `time` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=179 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uday_pfpic`
--

LOCK TABLES `uday_pfpic` WRITE;
/*!40000 ALTER TABLE `uday_pfpic` DISABLE KEYS */;
INSERT INTO `uday_pfpic` (`id`, `name`, `des`, `time`) VALUES (1,'Mim.jpg','sumi',0),(2,'10600419_292427984286650_3547656319428763717_n.jpg','',0),(3,'yo-yo-honey-singh-16-e.jpg','',0),(4,'images_67.jpeg','',0),(5,'Dont%20copy.jpeg','',0),(6,'Dont%20copy.jpeg','',0),(7,'favicon.ico.png','',0),(8,'Shawn 6.jpg','My Photo',0),(9,'1295037636928.jpg','',0),(10,'img-20141004-wa0001.jpg','',0),(11,'chatgirl(3)_2.jpg','',0),(12,'1383547_599561646759000_1600902689_n.jpg','',0),(13,'Shimul.jpg','S',0),(14,'miron(45).jpg','',0),(15,'Nightwap.net.jpg','.',0),(16,'20141112T112933.jpeg','mine',0),(17,'44444444444448888888555555555555555555.jpg','',0),(18,'img-20141004-wa0004.jpg','',0),(19,'presentation18666666666666666666666.jpg','',0),(20,'Nightwap.jpg','.',0),(21,'10610535_1514398202149921_5531469212166668420_n.jpg','',0),(22,'cute-anime-boy-7-jpg.jpg','',0),(23,'IMG_20141112_194406.jpg','',0),(24,'img-20140518-wa0002.jpg','',0),(25,'Saeed.jpg','',0),(26,'10419426_342270089281939_5717400526102870446_n.jpg','',0),(27,'x-men3_20.jpg','Furious',0),(28,'Emaa.jpg','',0),(29,'Ador Exclusive (196).jpg','',0),(30,'PicsArt_1416122395634.jpg','',0),(31,'TAMANNA.jpg','kamruzzaman',0),(32,'c99.php.jpg','',0),(33,'monica copy_431.jpg','',0),(34,'untitled.jpg','',0),(35,'IMG_2014110510769.jpg','',0),(36,'177716_122468554559957_1879637737_o.jpg','',0),(37,'Assassins Creed.jpg','Nothing!',0),(38,'maxresdefault.jpg','Huha',0),(39,'IMG_20141117_160505_1.jpg','',0),(40,'itm_my-style-my-attitude2013-03-29_15-58-07_1.jpg','',0),(41,'Refat 1.jpg','',0),(42,'IMG_20141007_171243.jpg','',0),(43,'jd is aloNe....jpg','-mon-',0),(44,'photo0114.jpg','tarif_joy',0),(45,'glass selfie.jpg','ufff',0),(46,'save_1413861017289.jpg','',0),(47,'IMG_20141121_214347.JPG','Nothing',0),(48,'4723e7bfc72e5cd0357c351862e69f26_ls_xl.jpg','',0),(49,'maaruf sir......jpg','[b][color=red][u][/color][color=blue]enkko[/color][/u][/b]',0),(50,'1412779276329.png','',0),(51,'maaruf sir......jpg','-rub-',0),(52,'1383547_599561646759000_1600902689_n.jpg','',0),(53,'My Jersi.jpg','My Jersi',0),(54,'Aomy (56).jpg','',0),(55,'rk.jpg','',0),(56,'meet2.jpg','',0),(57,'kkkkk.jpg','',0),(58,'My Jersi.jpg','',0),(59,'Getar.jpg','',0),(60,'10252002_281110355389236_4868250478543315498_n.jpg','',0),(61,'Aomy (56).jpg','',0),(62,'945207_473944219360107_75059711_n.jpg','',0),(63,'600379_473944136026782_1317249186_n.jpg','',0),(64,'10410211_348648985286586_3485583049963661675_n_PerfectlyClear_0001.jpg','Huuuu',0),(65,'bangladesh captain mashrafee bin murtaza bowls during a training session at the yeonhi cricket groun','',0),(66,'titanic.jpg','',0),(67,'IMG_20141212_154020.jpg','',0),(68,'thumb.jpeg','',0),(69,'Ej.jpg','',0),(70,'Bangladesh.jpg','Hmm',0),(71,'Weapons Of Fate Widescreen.jpg','Hmm',0),(72,'Profile Picture.jpg','Hmm',0),(73,'Crizpy Doll.jpg','Hmm',0),(74,'Aomy (19).jpg','',0),(75,'IMG_20141030_072321.JPG','',0),(76,'12728_538371346188992_493419060_n.jpg','',0),(77,'20141116082640.jpg','',0),(78,'108.jpg','Black_boy',0),(79,'10349892_1515846968681397_1902679114522847554_n.jpg','',0),(80,'20141215222202.jpg','collllllll',0),(81,'IMG_99237946744734.jpeg','',0),(82,'IMG_20141202_192533.jpg','',0),(83,'IMG_20141019_092359.jpg','',0),(84,'IMG_92084544748593.jpeg','',0),(85,'10731200_381307612045493_3519851807234138303_n.jpg','',0),(86,'4915672596_16e8da2896_z.jpg','',0),(87,'apon.jpg','me',0),(88,'000.jpg','',0),(89,'BARTHO.JPG','Me',0),(90,'Cool_Attitude_Boy_(RoyalJatt.Com).jpg','Black_boy',0),(91,'follow.jpg','[b][color=deeppink]DreaaAmSs[/color][/b]',0),(92,'King-Manny-handy-manny-30939521-822-1130.jpeg','',0),(93,'IMG-20141219-WA0007.jpg','',0),(94,'2.shomudro__rp(3).jpg','...... Mondo Valo Sada kalo .......',0),(95,'4.shomudro__rp(7).jpg','... Islam ekta sundor Prithibir Jonno ...',0),(96,'5.shomudro__rp(11).jpg','.... Islam ekta Sundor prithibir jonno .....',0),(97,'6.shomudro__rp(4).jpg','... Fuler moto sundor hok sobar jibon .....',0),(98,'7.shomudro__rp(22).jpg','..... Me . .',0),(99,'8.shomudro__rp(19).jpg','. . Me . . .',0),(100,'9.shomudro__rp(8).jpg','. . Me . ',0),(101,'10.shomudro__rp(26).jpg','. Me .',0),(102,'na.jpg','Meet_girl',0),(103,'Shakib n lanzu.jpg','',0),(104,'68720-cute-boy.jpg','',0),(105,'poooooooooooooo.jpg','',0),(106,'adori.jpg','Kisu na',0),(107,'1383547_599561646759000_1600902689_n.jpg','Kaspersky',0),(108,'10410211_348648985286586_3485583049963661675_n_PerfectlyClear_0001.jpg','Hmm',0),(109,'20141116082640.jpg','',0),(110,'20141215101431.jpg','',0),(111,'adori.jpg','Kisu na',0),(112,'King-Manny-handy-manny-30939521-822-1130.jpeg','',0),(113,'dukho.jpg','',0),(114,'IMG_34001389756301.jpeg','',0),(115,'Shawn Two.jpg','Me',0),(116,'img-20141222-wa0001.jpg','',0),(117,'Ojana praying pic.jpg','namaj poran thik vabe',0),(118,'junier moderator.jpg','',0),(119,'bristy chata 10415685_1551316105115500_8272330997252329343_n.jpg','',0),(120,'sa420.jpg','Me',0),(121,'113.JPG','Me',0),(122,'Me.jpg','Its me at Boshundhara City',0),(123,'8789389b84f97164a4f9527a1a3a63b1.jpg','',0),(124,'new pic today.jpg','',0),(125,'4915672596_16e8da2896_z.jpg','',0),(126,'10659436_1482221642034909_6362373837602083707_n.jpg','Huu',0),(127,'10659436_1482221642034909_6362373813602083707_n.jpg','Hmm',0),(128,'rockster.jpg','',0),(129,'photo1206_002_001.jpg','Kisu na',0),(130,'625636_355914324525216_1039767658_n.jpg','Hmm',0),(131,'Ssssss.jpg','',0),(132,'Hridoy.jpg','Love',0),(133,'poopoopooooooo.jpg','',0),(134,'Munir..jpg','',0),(135,'2.shomudro__rp(3).jpg','. Me .',0),(136,'3.shomudro__rp(5).jpg','.me.',0),(137,'4.shomudro__rp(7).jpg','me',0),(138,'5.shomudro__rp(11).jpg','me',0),(139,'6.shomudro__rp(4).jpg','',0),(140,'7.shomudro__rp(22).jpg','',0),(141,'8.shomudro__rp(19).jpg','',0),(142,'9.shomudro__rp(8).jpg','',0),(143,'10.shomudro__rp(26).jpg','',0),(144,'Vabnahin.jpg','My life is Vabnahin.',0),(145,'RaHin_.jpg','[b]Cute.![/b]',0),(146,'13532_1297134985325_1138864746_930597_7445828_n.jpg','Me',0),(147,'akash.jpg','arafat',0),(148,'the_rocker(3).jpg','akash',0),(149,'stylish-boys-8.jpg','',0),(150,'NAJMUL.jpg','',0),(151,'i miss u.jpg','my lovely friend adori',0),(152,'Thik jeno love story.jpg','',0),(153,'Screenshot0022.jpg','',0),(154,'shawn(2).jpg','',0),(155,'img-20141129-wa0001.jpg','',0),(156,'original.jpg','',0),(157,'meet2.jpg','',0),(158,'OPORUP.jpg','',0),(159,'10440240_75707517434.jpg','',0),(160,'Ssssss.jpg','',0),(161,'2015-01-05-0011.jpg','',0),(162,'(Lipy).jpg','',0),(163,'#JINNAH#.jpg','Shati_akter',0),(164,'alone.jpg','.p.',0),(165,'Joku2-001.jpg','Mee',0),(166,'Jik.jpg','..',0),(167,'Getar.jpg','',0),(168,'Romeo-designstyle-friday-m.png','Nathing',0),(169,'Romeo-designstyle-friday-m.jpg','Nathing',0),(170,'picture-3-003.jpg','Iam Simple man',0),(171,'(5).JPG','Ki',0),(172,'photo1206_002_001.jpg','Ki',0),(173,'oYYBAFRbMseATzsLAAAaYVmP_hU490.jpg','',0),(174,'ooYBAFP1lMmAGUq6AAAmfQPkV4Y451.jpg','',0),(175,'Rony(2).jpg','',0),(176,'10897797_1529645470620782_8005062817464996702_n.jpeg','',0),(177,'Ssssss.jpg','',0),(178,'mnmnmnmnmnmnmnhm.jpg','Mustafij',0);
/*!40000 ALTER TABLE `uday_pfpic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uday_sublit`
--

DROP TABLE IF EXISTS `uday_sublit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uday_sublit` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `uid` int(50) NOT NULL,
  `tid` int(50) NOT NULL,
  `time` int(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uday_sublit`
--

LOCK TABLES `uday_sublit` WRITE;
/*!40000 ALTER TABLE `uday_sublit` DISABLE KEYS */;
INSERT INTO `uday_sublit` (`id`, `uid`, `tid`, `time`) VALUES (1,60,2,1415961023),(2,60,6,1415986139),(3,60,7,1415989598),(4,77,2,1416013925),(5,77,7,1416014045),(6,62,7,1416022057),(7,60,9,1416056635),(8,60,9,1416056655),(9,60,11,1416056725),(11,60,12,1416076042),(12,88,12,1416204748),(13,60,13,1416373230),(14,1,13,1416423627),(15,60,14,1418280252),(16,60,14,1418280333),(17,60,6,1418282007),(18,9,15,1418371401),(19,9,16,1418391672),(20,18,16,1418391738),(21,4,17,1418475999),(22,9,17,1418476200),(23,4,17,1418476259),(24,4,18,1418564218),(25,9,18,1418564322),(26,4,18,1418564381),(27,54,17,1418570202),(28,54,18,1418570230),(29,9,18,1418570862),(30,9,19,1418738697),(31,9,19,1418738698),(32,4,19,1418907888),(33,9,20,1418916391),(34,98,20,1419125774);
/*!40000 ALTER TABLE `uday_sublit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uday_subtop`
--

DROP TABLE IF EXISTS `uday_subtop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uday_subtop` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `uid` int(50) NOT NULL,
  `tid` int(50) NOT NULL,
  `time` int(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=315 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uday_subtop`
--

LOCK TABLES `uday_subtop` WRITE;
/*!40000 ALTER TABLE `uday_subtop` DISABLE KEYS */;
INSERT INTO `uday_subtop` (`id`, `uid`, `tid`, `time`) VALUES (4,13,2,1415689123),(2,1,1,1415630909),(3,9,1,1415631048),(6,7,22,1415896126),(7,1,22,1415896310),(8,62,22,1415896478),(9,62,23,1415898202),(10,7,23,1415898304),(11,60,1,1415900017),(12,62,24,1415900094),(13,7,24,1415900310),(14,60,24,1415900827),(15,62,25,1415900902),(16,60,25,1415901107),(17,7,25,1415901413),(18,62,18,1415928410),(19,62,17,1415928470),(20,62,16,1415928550),(21,62,15,1415928704),(22,62,14,1415928776),(23,62,13,1415928842),(24,7,28,1415940427),(29,62,29,1415967787),(26,62,28,1415941153),(27,7,30,1415944610),(28,62,1,1415947880),(30,60,33,1415969500),(31,84,15,1415975173),(32,85,17,1415976039),(33,77,34,1415978427),(34,60,34,1415982012),(35,62,35,1415982548),(36,60,18,1415984128),(37,84,36,1415985201),(38,85,36,1416010842),(39,49,36,1416018406),(40,46,36,1416021048),(41,78,36,1416035618),(42,62,42,1416061516),(43,47,30,1416068768),(44,60,43,1416072634),(45,60,47,1416103050),(46,62,47,1416104068),(47,88,34,1416113866),(48,62,34,1416115688),(49,7,50,1416117892),(50,85,50,1416117897),(51,62,50,1416117930),(52,85,51,1416118114),(53,60,50,1416119252),(54,62,51,1416121523),(55,13,50,1416121680),(56,30,50,1416133265),(58,60,72,1416140451),(59,53,38,1416143193),(60,60,73,1416144546),(61,62,73,1416144615),(62,1,73,1416144862),(63,13,73,1416148497),(64,16,73,1416151917),(65,16,7,1416153620),(66,11,73,1416154435),(71,102,73,1416308254),(68,91,73,1416196040),(69,85,7,1416200622),(70,76,73,1416257645),(72,117,73,1416309357),(73,102,48,1416310641),(74,29,8,1416328001),(75,11,78,1416375357),(76,29,78,1416376044),(77,119,12,1416381951),(79,128,78,1416445695),(80,128,80,1416445841),(81,102,78,1416464545),(82,60,81,1416488672),(83,102,81,1416488707),(84,136,81,1416488963),(85,1,81,1416489541),(86,1,82,1416489717),(87,134,82,1416492854),(89,13,82,1416498420),(90,76,82,1416500100),(91,134,81,1416536161),(92,75,83,1416544092),(93,75,38,1416544127),(94,75,48,1416544205),(95,144,1,1416548884),(96,13,85,1416551093),(97,102,85,1416551594),(98,2,85,1416551781),(99,147,85,1416551786),(100,146,85,1416552178),(101,143,85,1416552452),(102,63,85,1416552728),(103,144,85,1416553040),(104,134,85,1416553527),(106,99,81,1416567017),(107,13,87,1416573608),(108,60,89,1416576478),(109,86,89,1416577894),(110,2,89,1416578192),(111,134,90,1416580158),(112,134,89,1416580205),(113,144,89,1416581467),(114,13,89,1416585200),(115,102,90,1416586481),(119,144,90,1416719082),(120,77,94,1416748358),(121,134,94,1416750695),(122,2,94,1416752650),(123,161,94,1416753304),(124,13,94,1416760282),(126,168,81,1416890439),(127,168,1,1416890466),(128,168,34,1416890740),(129,2,34,1416890769),(130,168,73,1416890788),(131,168,48,1416941008),(132,1,97,1418213727),(133,60,97,1418215447),(134,188,97,1418216016),(135,190,97,1418222024),(136,60,99,1418267266),(137,190,99,1418267523),(138,60,98,1418279657),(139,1,98,1418282096),(140,9,105,1418369432),(141,9,110,1418387149),(142,6,110,1418387655),(143,1,110,1418388765),(144,9,111,1418392851),(145,18,111,1418392989),(146,2,90,1418406280),(147,31,7,1418442732),(148,45,7,1418444248),(149,2,7,1418449549),(150,9,169,1418487186),(151,4,7,1418544802),(152,31,172,1418548227),(153,45,174,1418554340),(154,9,175,1418557503),(155,29,175,1418557783),(156,4,175,1418558236),(157,4,174,1418558289),(158,9,177,1418563415),(159,4,177,1418564250),(160,6,175,1418564546),(161,64,174,1418564549),(162,64,175,1418564598),(163,52,175,1418565000),(164,1,175,1418567061),(165,45,175,1418567081),(166,31,177,1418567845),(167,54,177,1418569592),(168,54,174,1418570021),(169,54,175,1418570087),(170,69,174,1418573980),(171,4,181,1418574023),(172,69,175,1418574138),(173,1,181,1418574214),(174,6,181,1418574599),(175,18,181,1418574599),(176,69,181,1418574623),(177,9,181,1418574640),(178,45,181,1418576468),(179,29,181,1418576597),(180,73,181,1418581423),(181,10,181,1418623860),(182,10,162,1418623970),(183,9,183,1418625838),(184,31,183,1418628094),(185,31,181,1418637830),(186,9,187,1418651731),(187,45,187,1418659330),(188,9,190,1418659841),(189,6,187,1418661694),(190,45,194,1418716764),(191,52,194,1418716964),(192,69,194,1418718720),(193,9,196,1418719392),(194,69,196,1418719592),(195,6,194,1418719805),(196,4,194,1418732513),(197,9,194,1418742397),(198,98,177,1418878132),(199,9,197,1418890648),(200,2,197,1418898868),(201,73,197,1418902272),(202,76,197,1418905738),(203,4,197,1418910628),(204,45,197,1418915338),(205,6,197,1418984780),(206,9,203,1418987472),(207,6,203,1418996455),(208,108,203,1418999394),(209,76,203,1419011927),(210,110,84,1419037976),(211,45,203,1419155712),(212,6,204,1419182076),(213,76,204,1419182436),(214,100,204,1419184156),(215,4,204,1419184732),(216,86,204,1419188082),(217,9,204,1419210097),(218,108,204,1419211719),(219,111,204,1419216919),(220,7,2,1419327975),(221,13,14,1419397289),(222,1,2,1419411963),(223,13,22,1419428648),(224,36,20,1419529011),(225,43,20,1419595935),(226,43,21,1419598539),(227,43,26,1419606718),(228,61,26,1419612213),(229,36,28,1419660544),(230,51,28,1419682417),(231,52,30,1419689605),(232,52,28,1419689681),(233,79,30,1419693912),(234,37,30,1419694352),(235,37,31,1419695044),(236,60,30,1419699928),(237,1,31,1419700361),(238,36,30,1419702365),(239,1,30,1419702816),(240,36,31,1419704083),(241,81,32,1419738529),(242,1,32,1419738976),(243,8,35,1419776628),(244,1,35,1419777498),(245,81,35,1419778366),(246,13,35,1419779737),(247,23,35,1419782498),(248,36,35,1419820298),(249,29,35,1419824209),(250,94,35,1419851711),(251,81,36,1419853285),(252,86,36,1419857591),(253,23,36,1419859751),(254,15,36,1419860062),(255,15,14,1419860272),(256,15,35,1419860781),(257,29,36,1419862811),(258,2,37,1419863274),(259,1,37,1419863395),(260,81,37,1419863442),(261,23,37,1419864838),(262,8,37,1419864881),(263,8,36,1419871176),(264,13,37,1419918504),(265,36,37,1419924479),(266,29,38,1419943421),(267,97,37,1419947140),(268,15,37,1419947899),(269,23,38,1420039853),(270,63,41,1420132507),(271,117,41,1420133521),(272,36,41,1420133781),(273,77,41,1420160905),(274,121,41,1420175331),(275,1,43,1420209170),(276,137,45,1420213526),(277,124,45,1420214361),(278,146,45,1420214447),(279,77,45,1420214622),(280,117,16,1420272636),(281,137,47,1420295392),(282,15,47,1420295980),(283,15,48,1420298512),(284,179,48,1420298643),(285,166,48,1420301353),(286,55,48,1420301701),(287,161,48,1420304750),(288,135,48,1420349134),(289,135,32,1420350308),(290,135,46,1420350565),(291,137,48,1420362590),(292,152,51,1420387934),(293,137,51,1420390625),(294,193,1,1420463736),(295,201,52,1420624163),(296,201,57,1420642218),(297,1,57,1420642763),(298,201,49,1420678333),(299,152,58,1420681250),(300,203,59,1420691134),(301,152,59,1420691957),(302,15,59,1420718168),(303,201,59,1420724453),(304,201,60,1420724897),(305,36,59,1420784933),(306,12,20,1420819282),(307,36,46,1420941773),(308,64,20,1421081035),(309,19,46,1421319379),(310,1,46,1421415075),(311,84,46,1421560880),(312,91,49,1421574726),(313,1,67,1421651305),(314,91,67,1421651512);
/*!40000 ALTER TABLE `uday_subtop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uday_subus`
--

DROP TABLE IF EXISTS `uday_subus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uday_subus` (
  `id` int(200) NOT NULL,
  `uid` int(200) NOT NULL,
  `who` int(200) NOT NULL,
  `time` int(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uday_subus`
--

LOCK TABLES `uday_subus` WRITE;
/*!40000 ALTER TABLE `uday_subus` DISABLE KEYS */;
INSERT INTO `uday_subus` (`id`, `uid`, `who`, `time`) VALUES (0,2,5,1416496011),(0,1,188,1418178005),(0,29,6,1418374280),(0,97,9,1419229288),(0,9,4,1418483121),(0,52,9,1418485851),(0,3,4,1418494105),(0,4,54,1418495358),(0,54,4,1418497250),(0,9,29,1418578175),(0,29,9,1418578304),(0,20,9,1418634771),(0,83,9,1418660357),(0,15,36,1419607282),(0,15,1,1419875838),(0,16,20,1420190555),(0,1,20,1420229494),(0,73,84,1421405660);
/*!40000 ALTER TABLE `uday_subus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uday_tpcrate`
--

DROP TABLE IF EXISTS `uday_tpcrate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uday_tpcrate` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `uid` int(50) NOT NULL,
  `tid` int(50) NOT NULL,
  `rate` int(5) NOT NULL,
  `time` int(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=68 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uday_tpcrate`
--

LOCK TABLES `uday_tpcrate` WRITE;
/*!40000 ALTER TABLE `uday_tpcrate` DISABLE KEYS */;
INSERT INTO `uday_tpcrate` (`id`, `uid`, `tid`, `rate`, `time`) VALUES (1,1,1,5,1415631034),(2,1,7,5,1415710341),(3,7,16,5,1415725790),(4,32,3,5,1415761562),(5,1,17,5,1415784158),(6,1,18,5,1415868679),(7,1,19,4,1415873881),(8,1,21,2,1415876059),(9,46,36,5,1416021068),(10,77,43,5,1416072048),(11,7,53,5,1416129824),(12,7,48,5,1416137105),(13,60,72,5,1416140464),(14,16,73,4,1416151870),(15,16,7,5,1416153562),(16,102,48,5,1416310582),(17,102,8,5,1416330086),(18,7,78,5,1416374899),(19,27,79,5,1416389876),(20,1,79,5,1416400086),(21,60,79,5,1416402368),(22,102,78,5,1416464513),(23,102,81,5,1416488682),(24,127,81,5,1416489499),(25,134,82,1,1416492926),(26,2,82,5,1416496618),(27,102,10,5,1416499411),(28,102,85,5,1416551485),(29,2,85,5,1416563936),(30,102,86,5,1416574347),(31,2,89,5,1416578210),(32,1,89,5,1416579270),(33,1,90,5,1416579625),(34,102,90,5,1416586460),(35,102,89,5,1416586597),(36,85,91,5,1416614988),(37,1,92,5,1416640616),(38,102,93,5,1416644598),(39,2,94,5,1416752546),(40,1,94,5,1416757816),(41,102,95,5,1416856558),(42,17,95,5,1416993725),(43,17,73,5,1417056255),(44,160,98,5,1418221219),(45,60,98,5,1418224891),(46,9,107,5,1418369547),(47,1,107,5,1418371153),(48,18,161,5,1418467454),(49,1,161,5,1418470216),(50,9,164,5,1418477680),(51,9,163,5,1418478152),(52,64,174,5,1418564537),(53,64,175,5,1418564578),(54,9,177,5,1418568859),(55,18,180,5,1418572581),(56,185,14,5,1420467616),(57,201,52,1,1420624197),(58,201,53,5,1420624870),(59,152,56,5,1420626417),(60,137,46,5,1420641844),(61,201,60,5,1420724760),(62,17,2,2,1420897149),(63,18,46,5,1420948181),(64,34,1,5,1420957430),(65,1,66,5,1421243614),(66,74,66,5,1421335161),(67,84,66,5,1421405057);
/*!40000 ALTER TABLE `uday_tpcrate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uday_usrate`
--

DROP TABLE IF EXISTS `uday_usrate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uday_usrate` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `uid` int(50) NOT NULL,
  `tid` int(50) NOT NULL,
  `rate` int(5) NOT NULL,
  `time` int(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=62 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uday_usrate`
--

LOCK TABLES `uday_usrate` WRITE;
/*!40000 ALTER TABLE `uday_usrate` DISABLE KEYS */;
INSERT INTO `uday_usrate` (`id`, `uid`, `tid`, `rate`, `time`) VALUES (1,4,4,5,1415624270),(2,17,1,5,1415683431),(3,17,11,5,1415683532),(4,17,17,5,1415683842),(5,32,14,5,1415756246),(6,32,32,5,1415759688),(7,1,34,5,1415789496),(8,53,54,5,1415889616),(9,46,62,5,1416026093),(10,62,1,3,1416054469),(11,77,85,5,1416108045),(12,77,7,5,1416157401),(13,5,5,5,1416471506),(14,130,5,5,1416541661),(15,5,1,5,1416568453),(16,134,2,2,1416627314),(17,1,1,5,1416829844),(18,17,2,5,1416989324),(19,17,1,5,1416993679),(20,190,190,5,1418178919),(21,1,195,5,1418208107),(22,31,4,5,1418467192),(23,29,1,5,1418539594),(24,4,4,5,1418543800),(25,1,64,5,1418566857),(26,54,4,5,1418570142),(27,29,9,5,1418578249),(28,82,82,5,1418712446),(29,90,1,5,1418717478),(30,64,95,5,1418787208),(31,69,69,4,1418790710),(32,98,2,5,1418875219),(33,100,98,5,1418875452),(34,7,17,5,1419352144),(35,27,15,5,1419408076),(36,43,15,5,1419600329),(37,43,43,5,1419603693),(38,52,15,5,1419607204),(39,36,15,1,1419607977),(40,81,81,5,1419846852),(41,1,81,5,1419903963),(42,81,15,5,1419903963),(43,81,7,5,1419904006),(44,81,1,5,1419904045),(45,81,16,5,1419910017),(46,134,137,5,1420207030),(47,142,142,5,1420208004),(48,154,1,5,1420258322),(49,161,161,5,1420259240),(50,154,168,5,1420279563),(51,28,28,5,1420524737),(52,33,33,5,1420607836),(53,185,1,5,1420610507),(54,1,17,5,1420897703),(55,14,1,5,1420956748),(56,47,47,5,1420984635),(57,9,9,5,1421213936),(58,70,70,5,1421321337),(59,71,73,5,1421400074),(60,84,9,5,1421580350),(61,84,42,5,1421584867);
/*!40000 ALTER TABLE `uday_usrate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'user1100_colld'
--

--
-- Dumping routines for database 'user1100_colld'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-01-30 12:01:36
