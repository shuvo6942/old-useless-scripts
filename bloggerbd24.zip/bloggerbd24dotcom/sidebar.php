<aside class="sidebar c-4-12"> <!-- G&R_300x600 -->
<script id="GNR24291">
    (function (i,g,b,d,c) {
        i[g]=i[g]||function(){(i[g].q=i[g].q||[]).push(arguments)};
        var s=d.createElement(b);s.async=true;s.src=c;
        var x=d.getElementsByTagName(b)[0];
        x.parentNode.insertBefore(s, x);
    })(window,'gandrad','script',document,'//content.green-red.com/lib/display.js');
    gandrad({siteid:7838,slot:24291});
</script>
<!-- End of G&R_300x600 -->
	<div id="sidebars" class="g">
		<div class="sidebar">
			<ul class="sidebar_list">
				<?php if ( ! dynamic_sidebar( 'Sidebar' )) : ?>
					<li id="sidebar-search" class="widget">
						<h3><?php _e('Search', 'mythemeshop'); ?></h3>
						<?php get_search_form(); ?>
					</li>
					<li id="sidebar-archives" class="widget">
						<h3><?php _e('Archives', 'mythemeshop') ?></h3>
						<ul>
							<?php wp_get_archives( 'type=monthly' ); ?>
						</ul>
					</li>
					<li id="sidebar-meta" class="widget">
						<h3><?php _e('Meta', 'mythemeshop') ?></h3>
						<ul>
							<?php wp_register(); ?>
							<li><?php wp_loginout(); ?></li>
						</ul>
					</li>
				<?php endif; ?>
			</ul>
		</div>
	</div><!--sidebars-->
</aside>