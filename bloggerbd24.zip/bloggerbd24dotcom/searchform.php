<form method="get" id="searchform" class="search-form" action="<?php echo home_url(); ?>" _lpchecked="1">
	<fieldset>
		<input type="text" name="s" id="s" value="খোজ করুন..." onblur="if (this.value == '') {this.value = 'খোজ করুন...';}" onfocus="if (this.value == 'খোজ করুন...') {this.value = '';}" >
		<input type="submit" value="Search" onclick="if(this.value=='খোজ করুন...')this.value='';" />
	</fieldset>
</form>