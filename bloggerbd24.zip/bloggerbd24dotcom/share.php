<div id="share-buttons">
    <!-- Facebook -->
    <a href="http://www.facebook.com/sharer.php?u=<?php the_permalink(); ?>" title="পোস্টটি ফেসবুকে শেয়ার করুন" target="_blank">
        <img src="<?php bloginfo('template_url'); ?>/share/facebook.png" height="30" width="30" alt="Facebook" />
    </a>
        
    <!-- Twitter -->
    <a href="https://twitter.com/share?url=<?php the_permalink(); ?>&amp;text=<?php the_title(); ?>" title="পোস্টটি টুইটারে শেয়ার করুন" target="_blank">
        <img src="<?php bloginfo('template_url'); ?>/share/twitter.png" height="30" width="30" alt="Twitter" />
    </a>

    <!-- Google+ -->
    <a href="https://plus.google.com/share?url=<?php the_title(); ?> | ব্লগার বিডি ২৪%20<?php the_permalink(); ?>" title="পোস্টটি গুগোল প্লাসে শেয়ার করুন" target="_blank">
        <img src="<?php bloginfo('template_url'); ?>/share/google.png" height="30" width="30" alt="Google" />
    </a>

       <!-- LinkedIn -->
<a title="পোস্টটি লিংকডইনে শেয়ার করুন" href="http://www.linkedin.com/shareArticle?mini=true&url=<?php the_permalink(); ?>&title=<?php the_title(); ?>&summary=&source=bloggerbd24.com" target="_blank">
        <img src="<?php bloginfo('template_url'); ?>/share/linkedin.png" height="30" width="30" alt="LinkedIn" />
    </a>
    
    <!-- Digg -->
    <a href="http://www.digg.com/submit?url=<?php the_permalink(); ?>" title="পোস্টটি ডিগ করুন" target="_blank">
        <img src="<?php bloginfo('template_url'); ?>/share/diggit.png" height="30" width="30" alt="Digg" />
    </a>


    <!-- Reddit -->
    <a href="http://reddit.com/submit?url=<?php the_permalink(); ?>&amp;title=<?php the_title(); ?> | ব্লগার বিডি ২৪" title="পোস্টটি রেডিটে শেয়ার করুন" target="_blank">
        <img src="<?php bloginfo('template_url'); ?>/share/reddit.png" height="30" width="30" alt="Reddit" />
    </a>

    <!-- Tumblr-->
    <a href="http://www.tumblr.com/share/link?url=<?php the_permalink(); ?>&amp;title=<?php the_title(); ?>" title="পোস্টটি Tumblr এ শেয়ার করুন" target="_blank">
        <img src="<?php bloginfo('template_url'); ?>/share/tumblr.png" height="30" width="30" alt="Tumblr" />
    </a>

    <!-- Email -->
    <a title="পোস্টটি ইমেইল করুন"
href="mailto:?subject=<?php the_title(); ?>&amp;body=<?php the_title(); ?>%20<?php the_permalink(); ?>">
        <img src="<?php bloginfo('template_url'); ?>/share/email.png" height="30" width="30" alt="Email" />
    </a>
    
</div>