<?php get_header(); ?>
<div id="page">
	<div class="content">
		<article class="article single">
			<div id="content_box" >
				<div id="content" class="hfeed single_post">
					<header>
						<div class="title">
							<h1><?php _e('Error 404', 'mythemeshop'); ?></h1>
						</div>
					</header>
					<div class="post-content">
						<p><?php _e('দুঃখিত, আপনি যা খুজছেন তা এই মুহুর্তে পাওয়া যায় নি।', 'mythemeshop'); ?></p>
					</div><!--.post-content--><!--#error404 .post-->
				</div><!--#content-->
			</div><!--#content_box-->
		</article>
<?php get_sidebar(); ?>
<?php get_footer(); ?>