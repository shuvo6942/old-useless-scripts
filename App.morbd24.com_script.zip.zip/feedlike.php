<?php
include 'config.php';
include 'head.php';
echo '<div class="gmenu" align="center">10 lettest news feed liked (refresh)</div>';
$status=$facebook->api("/me/home?limit=10","get",$parameters);
$data=$status['data'];
foreach($data as $nr => $s)
{
$id=$s['id'];
$like=$facebook->api("/".$id."/likes","POST",$parameters);
echo $like['id'];}
include 'foot.php'; ?>
