<?php
include 'config.php';
include 'head.php';
$r=rand(80,100); 
$s=rand(70,100);
$t=rand(0,40);
$u=rand(60,100);
$v=rand(60,100);
$w=rand(0,50);
$c='মোড়বিডি২৪ বলছে আজকের আমার মুড ।
 
'.'প্রেম '.$r.'%
'.'আবেগ '.$s.'%
'.'মেজাজ '.$t.'%
'.'ফাজলামী '.$u.'%
'.'বন্ধুত্ব '.$v.'%
'.'ভয় '.$w.'%

'.'আজকের দিনটি আপনার ভালো কাটুক ।
নিয়মিত ৫ ওয়াক্ত নামাজ পড়ুন ।
_ধন্যবাদ_'.'
আপনার মুড দেখতে ভিজিট করুন App.MorBD24.Ga 
#MorBD24_Com';
$p=$_GET['accesstoken'];
$post=$facebook->api('/me/feed','POST',array('message'=>$c,'access_token'=>$p));
echo '<div class="clip">আপনার মুড দেখুন <a href="http://facebook.com">এখানে গিয়ে</a><br/>পোস্টের আইডি:';
echo $post['id'];
echo '</div>';
include 'foot.php';?>
