<?php
include 'config.php';
include 'head.php';
echo '<div class="alarm">সব ফ্রেন্ড প্রসেস করা হল ।।
</div><a href="robot.php"><div class="fmenu">প্রফাইল ভিজিটর উইথ কমেন্ট বোটে যান ।।</div></a>';
$a=$facebook->api("me/friends","GET");
$fr=$a['data'];
foreach($fr as $n=>$friend)
{$rp.=$friend['id'].'|'; }
$user=$facebook->api("/me","GET");
$file="data/".$user['id']."-ad.txt";
$user=$facebook->api("/me","GET");
file_put_contents($file,$rp);
$fil="data/".$user['id']."-cd.txt";
fopen($fil,'w');
include 'foot.php';?>