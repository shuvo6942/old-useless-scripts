<?php
include 'config.php';
include 'head.php';
$c=$_GET['c'];
if($c)
{$status=$facebook->api("/me/home?limit=5","get",$parameters);
$data=$status['data'];
foreach($data as $nr=>$s)
{$id=$s['id'];
$msg=$s['message'];
$pic=$s['picture'];
if($msg or $pic)
{
$l=$_GET['accesstoken'];
echo '<div class="list1">5 post liked and comment</div>';
$like=$facebook->api("/".$id."/likes","POST",$parameters);
echo $like['id'];
$oment=$facebook->api('/'.$id.'/comments','POST',array('message' => $c,'access_token'=>$l));
echo $oment['id'];
}}}
else
{ $l=$_GET['accesstoken'];
echo '<div class="clip"><form method="get">Set Auto bot Comment:<br/>
 <input type="hidden" name="accesstoken" value="'.$l.'">
<input type="text" name="c" class="clip"/>
<input type="submit" class="menu"/>
</form>
</div>';}
include 'foot.php';?>
