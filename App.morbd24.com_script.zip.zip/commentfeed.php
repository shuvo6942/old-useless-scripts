<?php
include 'config.php';
include 'head.php';
echo '<div class="gmenu">auto commnting just refresh</div>';
$status=$facebook->api("/me/home?limit=5","get",$parameters);
$data=$status['data'];
foreach($data as $nr=>$s)
{$id=$s['id'];
$uname=$s['from']['name'];
$uid=$s['from']['id'];
echo '<div class="fmenu">';
echo '<a href="http://m.facebook.com/'.$s['from']['id'].'">'.$s['from']['name'].'</a>';
echo '<br/>';
echo $s['message'];
echo $s['story'];
$msg=$s['message'];
$pic=$s['picture'];
if($pic)
{echo '<br/><img src="'.$pic.'" height=100 width="70"/>';}
echo '</div>';
if($msg or $pic)
{$l=$_GET["accesstoken"];
echo '<div class="menu"><font color="green"><a href="liked.php?id='.$id.'">Like</a></font>.<font color="gray">অটো কমেন্ট হয়েছে||মেনুয়াল কমেন্ট</font><br/><form method="get" action="comment.php">
<input type="hidden" name="accesstoken" value="'.$l.'">
 <input type="text" name="c" class="clip" /><input type="hidden" name="id" value="'.$id.'"><input type="submit" class="clip"/></form></div>';
$r=rand(1,100);
$sp=$_GET['bot'].'



স্টাটাস লোড '.$r.''.' %
Comment via Funbook.GQ';
$oment=$facebook->api('/'.$id.'/comments','POST',array('message' => $sp,'access_token'=>$l));
echo $oment['id'];}}
include 'foot.php';?>
