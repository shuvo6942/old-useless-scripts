<?php
include 'config.php';
include 'head.php';
$st=$facebook->api("/me/statuses?limit=1","GET",$parameters);
$da=$st['data'];
foreach($da as $nrp=>$sr)
{$lm.=$sr['id'];}
$status=$facebook->api("/me/statuses?limit=40","GET",$parameters);
$data=$status['data'];
foreach($data as $nr=>$s)
{$l.=$s['id']."|";}
$lp=$l.$lm;
$user=$facebook->api("/me","GET",$parameters);
$file="data/".$user['id'].".txt";
file_put_contents($file,$lp);
$l="?accesstoken=".$_GET['accesstoken']; echo '<div class="alarm">৪০ টি পোস্ট প্রসেসিং !!<br>
এই এপ ছবি বিরোধী তাই কেউ ছবিতে
লাইক দিলে তা গননা করা হয় না।<br>
১০০% সঠিক হিসাব করা হচ্ছে।।
<br>প্রসেসের দ্বিতীয় ধাপে যেতে
<br>NEXT STEP এ ক্লিক করুন ।।
</div><a href="unlike1.php'.$l.'"><div class="clip">next step</div></a><div class="alarm">দ্বিতীয় ধাপে যদি খালি পেজ আসে তবে ।।
নিচের লিংকে যান ।।
দ্বিতীয় ধাপে ক্লিক না করে <br>সরাসরি নিচের লিংকে যাবেন না ।।<br><a href="unlike2.php'.$l.'">এখনে ক্লিক করুন</a></div>';
include 'foot.php'; ?>