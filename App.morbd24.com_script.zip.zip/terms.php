<?php
include 'head.php';
echo '<div class="fmenu">donot share porno content<br>don\'t abuse any sevice of this site<br>donot comment spam<br>all right reserved Funbook.GQ </div>';
include 'foot.php';
?>
