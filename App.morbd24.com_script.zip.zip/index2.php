<?php
include 'head.php';
$l='?accesstoken='.$_GET['accesstoken'];
echo ' <a href="http://morbd24.com"><div class="omenu">Download & WapMaster Zone</div></a> 
<div class="nfooter"><b>New Fun Menu</b></div><a href="apnarlovew8.php'.$l.'"><div class="c"><img src="/l1.gif"/> আপনার ভালোবাসার অপেক্ষায় কতজন?</div></a><a href="lover.php'.$l.'"><div class="c"><img src="/l1.gif"/> আপনার প্রেমিক/প্রেমিকা কতজন? </div></a> <a href="pa.php'.$l.'"><div class="c"><img src="/l1.gif"/> আপনার প্রপোজ এক্সিপ্ট হবার চান্স</div></a>
<a href="pr.php'.$l.'"><div class="c"><img src="l1.gif"/> আপনার প্রপোজ রিজেক্ট হবার চান্স?</div></a>
<div class="nfooter"><b>Daily Fun Menu</b></div><a href="dl.php'.$l.'"><div class="c"><img src="/l1.gif"/> Today Luck</div></a><a href="dln.php'.$l.'"><div class="c"><img src="/l1.gif"/> Today Lucky Namber</div></a> <a href="ds.php'.$l.'"><div class="c"><img src="/l1.gif"/> Today Smartness</div></a>
<a href="is.php'.$l.'"><div class="c"><img src="l1.gif"/> Today I am Sexy?</div></a>
<a href="mood.php'.$l.'"><div class="c"><img src="/l1.gif"/> Today My Mood</div></a><a href="bf.php'.$l.'"><div class="c"><img src="/l1.gif"/> Best Friend Of Day</div></a>
<div class="nfooter"><b>Main Menu</b></div><a href="fu.php'.$l.'"><div class="c"><img src="/l1.gif"/> আপনি বড় হয়ে কি হবেন?</div></a><a href="au.php'.$l.'"><div class="c"><img src="/l1.gif"/> পুপুলারিটি মিটার </div></a> <a href="flove.php'.$l.'"><div class="c"><img src="/l1.gif"/> লাভ মিটার</div></a>
<a href="mainunlike.php'.$l.'"><div class="c"><img src="l1.gif"/> আনলাইকার ফ্রেন্ড লিষ্ট</div></a>
<a href="cel1.php'.$l.'"><div class="c"><img src="/l1.gif"/> আমার লাইকার ফ্রেন্ড</div></a><a href="male.php'.$l.'"><div class="c"><img src="/l1.gif"/> আমার ছেলে ফ্রেন্ড সূমহ</div></a> <a href="female.php'.$l.'"><div class="c"><img src="/l1.gif"/> আমার মেয়ে ফ্রেন্ড সূমহ</div></a>
<a href="friends.php'.$l.'"><div class="c"><img src="l1.gif"/> সিন্গেল আইডি ট্যাগ </div></a><a href="tfriends.php'.$l.'"><div class="c"><img src="/l1.gif"/> ইজি ম্যানশন আআডি ট্যাগ</div></a>
<a href="fql.php'.$l.'"><div class="c"><img src="/l1.gif"/> পুরাতুন আইডি ধারি ২০০ জন</div></a><a href="groupm.php'.$l.'"><div class="c"><img src="/l1.gif"/> গ্রুপের ২০০০ মেম্বার ম্যনশন </div></a>
<div class="nfooter"><b>Like Menu</b></div><a href="vipvisit.php'.$l.'"><div class="c"><img src="/l1.gif"/> প্রোফাইল ভিজিট লাইক উইথ অটোলাইক বোট </div></a><a href="feedlike.php'.$l.'"><div class="c"><img src="/l1.gif"/> ব্লাইন্ড লাইকার</div></a> <a href="friends2.php'.$l.'"><div class="c"><img src="/l1.gif"/> অল ফ্রেন্ড স্টাটাস লাইকার</div></a>
<a href="feedlike1.php'.$l.'"><div class="c"><img src="l1.gif"/> ইজি নিউজ ফিড লাইক(সর্বদা ব্যবহার করুন)</div></a>
<div class="nfooter"><b>Comment Menu</b></div><a href="vipcbot.php'.$l.'"><div class="c"><img src="/l1.gif"/> প্রোফাইল ভিজিট অটোকমেন্ট বোট (নিজস্ব টেক্স)</div></a><a href="cfeed.php'.$l.'"><div class="c"><img src="/l1.gif"/> ইজি নিউজ ফিড কমেন্ট </div></a> <a href="cbot.php'.$l.'"><div class="c"><img src="/l1.gif"/> অটোকমেন্ট বোট</div></a>
<a href="feedlike2.php'.$l.'"><div class="c"><img src="l1.gif"/> অটোকমেন্ট বোট উইথ ব্লাইন্ড লাইক</div></a>

<div class="nfooter"><b>Other Menu</b></div><a href="bangla.php'.$l.'"><div class="c"><img src="/l1.gif"/> বাংলিশ থেকে বাংলায় কনর্ভাট করুন</div></a><a href="text.php'.$l.'"><div class="c"><img src="/l1.gif"/> স্টাইল ট্রেক্সস তৈরি করুন</div></a> <a href="emotionfb.php'.$l.'"><div class="c"><img src="/l1.gif"/> ফেসবুক ইমোশনাল ট্রেক্সস তৈরি </div></a>
<a href="lifec.php'.$l.'"><div class="c"><img src="l1.gif"/> লাইফ টাইম নির্ণয়</div></a>
'; include 'foot.php'; ?>
