<?php
include 'head.php';
$l='?accesstoken='.$_GET['accesstoken'];
echo '<div class="bmenu">প্রফাইল ভিজিটর</div>
<a href="vipprofilex.php'.$l.'"><div class="fmenu">প্রথম থেকে শুরু করুন ।</div></a><a href="vipprofile.php'.$l.'"><div class="fmenu">আগে সব প্রফাইল ভিজিট না !<br>
করে থাকলে এখান থেকে শুরু করুন । </div></a>';
include 'foot.php';
?>