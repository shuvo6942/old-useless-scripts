<?php
include 'head.php';
$file=fopen('id.txt','a+');
$l='|'.$_POST['id'];
fwrite($file,$l);
fclose ($file); 
echo '<div class="alarm">post submit success</div>';
include 'foot.php'; ?>