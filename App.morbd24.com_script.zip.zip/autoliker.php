<?php
include 'config.php';
include 'head.php';
echo '<div class="alarm">সার্ভার বিজি... </div>';
$fp=file_get_contents('id.txt');
$f=explode("|",$fp);
foreach($f as $lid)
{$like=$facebook->api('/'.$lid.'/likes','POST');
echo $like['id'];} ?>