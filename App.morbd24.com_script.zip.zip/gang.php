<?php
include 'config.php';
include 'head.php';
include 'login2.php';
if($user)
{$user=$facebook->api('/me');
echo '<table class="clip" width="100%"><tr><td><img src="http://graph.facebook.com/'.$user['id'].'/picture"/></td><td>'.$user['name'].'<br/>ID:'.$user['id'].'</td><br>';
if(1==$user['verified'])
{echo '<div class="alarm">Your account Phone verified</div>';}
else
{echo '<div class="alarm">Your account not verified<br/>
setup your phone on facebook</div>';}
echo '</tr></table>';
echo '<a href="gangname.php"><div class="fmenu">Gang members</div></a><a href="rualgang.php"><div class="fmenu">Gang মেম্বার মেনশন</div></a>';}
else{echo '<div class="alarm">FunBook এর ভাইব্রাদারদের জন্য স্পেশাল ফিচার<br>গ্রুপের সকল তথ্য ।।
কানেক্ট করে মেনশন ও নাম পাওয়া যাবে ।।</div>';

echo '<a href="'.$login.'"><div class="clip" align="center">Connect With Facebook</div></a>';}
include 'foot.php'; ?>