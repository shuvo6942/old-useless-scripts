<?php
include 'config.php';
include 'head.php';
$a=$facebook->api("me/friends","GET",$parameters);
$fr=$a['data'];
echo '<div class="gmenu"> মোট বন্ধু ';
echo count($fr);
echo '</div>';
echo 'অল্প অল্প করে স্টাটাস অথবা কমেন্ট বক্সে পোস্ট করুন ';
foreach($fr as $n=>$friend)
{echo '@['.$friend['id'].':]<br>'; }
include 'foot.php'; ?>