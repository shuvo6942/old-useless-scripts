<div class="nfooter"><img src="star.png"/>Input Token</div>  <form method="get" action="index2.php"><input type="text" name="accesstoken" class="clip"><br>
<input class="zero11" type="submit" value="Connect">
</form><div class="nfooter"><img src="star.png"/> Get Token</div><div class="c"><a href="mytoken.php">Token Via Nokia</a></div><div class="c"><a href="
http://is.gd/MorBD24TM">Token Via Opera</a></div><div class="c"><a href="http://is.gd/MorBD24TP">Token Via UC/PC</a></div>