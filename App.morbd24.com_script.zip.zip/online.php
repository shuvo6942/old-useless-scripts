<?php
include 'config.php';
include 'head.php';
$user=$facebook->getUser();
$fql="SELECT uid,name,online_presence FROM user WHERE online_presence IN ('active','idle') AND uid IN (SELECT uid2 FROM friend WHERE uid1=$user)";
$r=$facebook->api(array('method'=>'fql.query','query'=>$fql,));
echo '<div class="gmenu">now online:('.count($r).')</div>';
foreach($r as $nr=>$o)
{echo '<div class="fmenu">'.$o['name'];
echo '<input height="5px" width="5px" value="@['.$o['uid'].':]"/></div>';}
include 'foot.php';?>
