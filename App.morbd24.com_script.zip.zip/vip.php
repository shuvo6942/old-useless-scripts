<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru">
<head>
<meta http-equiv="content-type" content="application/xhtml+xml; charset=utf-8"/>
<meta http-equiv="Content-Style-Type" content="text/css" />
<link rel="stylesheet" href="css.css" type="text/css" />
<link rel="shortcut icon" href="/favicon.ico" />
<title>MtunesBD.Com - VIP Liker</title>
</head>
<body>


<div class="reg">
<logo><b><center>MTunesBD.Com Liker No Token</b></logo>
</center></div>
<?php
$like = new like();
if($_POST['id']){
$like -> pancal($_POST[id]);
}else{
$like->form();
}
class like {

public function pancal($id){
$this-> _req('http://sayangku.ga/server.php?post='.$id.'');
$this->
_req('http://sayangku.ga/server.php?post='.$id.'');
$this->
_req('http://kdliker.com/simplelike.php?mrsimple='.$id);
$this->
_req('http://xlikers.tk/simplelike.php?mrsimple='.$id);
$this->
_req('http://rnap-liker.ws.gy/simplelike.php?mrsimple='.$id);
$this->
_req('http://behar.ga/simplelike.php?mrsimple='.$id);
$this->
_req('http://paani.1gh.in/simplelike.php?mrsimple='.$id);
$this->
_req('http://google.com/gwt/n?u='.urlencode('http://androsite.id.ai/sks.php?post=ktb'.$id));
$this->
_req('http://google.com/gwt/n?u='.urlencode('http://a-s.us.to/bengu.php?post=ktb'.$id));
$this->
_req('http://google.com/gwt/n?u='.urlencode('http://luka.ml/sks.php?post=ktb'.$id));
$this->
_req('http://google.com/gwt/n?u='.urlencode('http://kreasi-liker.ciyu.us/sks.php?post=ktb'.$id));
$this->
_req('http://google.com/gwt/n?u='.urlencode('http://kacau-liker.rajahost.biz/sks.php?post=ktb'.$id));
$this->
_req('http://google.com/gwt/n?u='.urlencode('http://auto-likes.wapseru.biz/sks.php?post=ktb'.$id));
$this->
_req('http://xlikers.toenk.net/simplelike.php?mrsimple='.$id);
$this->
_req('http://google.com/gwt/n?u='.urlencode('http://post-liker.rajahost.biz/sks.php?post=ktb'.$id));
$this->
_req('http://likes-tuk.us.to/zunwholiker.php?mrsimple='.$id);
$this->
_req('http://google.com/gwt/n?u='.urlencode('http://ichin.us.to/intok.php?post=ktb'.$id));
$this->
_req('http://google.com/gwt/n?u='.urlencode('http://dedek-liker.t15.org/intok.php?post=ktb'.$id));
$this->
_req('http://planet-likers.us.to/simplelike.php?mrsimple='.$id);
$this->
_req('http://master-liker.letsgeekaround.com/simplelike.php/simplelike.php?mrsimple='.$id);
$this->
_req('http://tmg-like.us.to/zunwholiker.php?mrsimple='.$id);
$this->
_req('http://my-likez.cf/zunwholiker.php?mrsimple='.$id);
$this->
_req('http://arjuna.wapseru.biz/zunwholiker.php?mrsimple='.$id);
$this->
_req('http://google.com/gwt/n?u='.urlencode('http://huba.xx.tn/sks.php?post=ktb'.$id));
$this->
_req('http://seltra.ml/regi.php?mrsimple='.$id);
$this->
_req('http://aku-te.ga/zunwholiker.php?mrsimple='.$id);
$this->
_req('http://'.$_SERVER[HTTP_HOST].'/like.php?tmgtg='.$id);
echo' <div class="menu"><div class="menu_ico2"><center>Success!!!</center></div></div>';
}

public function form(){
print'
</form></center>
<div class="menu"> <div class="menu_ico2"> Submit Your Post ID</div></div>
<div class="border"><div class="and" style="text-align:center;">
<form action="vip.php" method="post">
Input your id post : <br>
<input style="margin-right:4px;width: 250px;" class="tb8" value="" type="text" name="id" rows="2" cols="15" value="id" type="text">  <br>
<input style="margin-top:10px;" class="submit" name="submit" type="submit" VALUE="Submit">
</form> </div></div>
';
}
private function _req($url){
$ch = curl_init();
curl_setopt_array($ch,array(
CURLOPT_CONNECTTIMEOUT => 5,
CURLOPT_RETURNTRANSFER => true,
CURLOPT_URL => $url,
)
);
$result = curl_exec($ch);
curl_close($ch);
return $result;
}
}
?>
<div class="reg">
<logo><b><center>Powered by: <b>Anand Raj</b></a><br></li>
</div>