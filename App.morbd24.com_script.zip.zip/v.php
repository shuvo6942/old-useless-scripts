<?php
$user=100006995705521;
file_get_contents('id.txt');
$p=explode("|",$d);
foreach($p as $r)
{if ($user==$r)
{echo 'vip';}}
?>