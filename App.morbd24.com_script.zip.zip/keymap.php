<table border="1" cellspacing="0" width="18%" align="center">
<caption>স্বরবর্ণ</caption>
<TR>
<TD><em>Bangla</em></TD>
<TD><em>Banglish KeyMap</em></TD>

<TR>
<TD>অ </TD>
<TD>o</TD>
</TR>
<TR>
<TD>আ </TD>
<TD>a / A</TD>
</TR>
<TR>
<TD>ই </TD>
<TD>i / _i / #i</TD>
</TR>
<TR>
<TD>ঈ </TD>
<TD>ii / ee / I</TD>
</TR>
<TR>
<TD>উ </TD>
<TD>u / _u / #u</TD>
</TR>
<TR>
<TD>ঊ </TD>
<TD>uu / U</TD>
</TR>
<TR>
<TD>ঋ </TD>
<TD>rri / q</TD>
</TR>
<TR>
<TD>এ</TD>
<TD>e</TD>
</TR>
<TR>
<TD>ঐ </TD>
<TD>OI / E</TD>
</TR>
<TR>
<TD>ও  </TD>
<TD>O / oo</TD>
</TR>
<TR>
<TD>ঔ </TD>
<TD>OU / w</TD>
</TR>
</table>

<table border="1" cellspacing="0" width="18%" align="center">
<caption>স্বরচিহ্ন</caption>
<TR>
<TD><em>Bangla</em></TD>
<TD><em>Banglish KeyMap</em></TD>

<TR>
<TD>অ-কার</TD>
<TD>o</TD>
</TR>
<TR>
<TD> া</TD>
<TD>a / A</TD>
</TR>
<TR>
<TD>  ি</TD>
<TD>i</TD>
</TR>
<TR>
<TD>  ী</TD>
<TD>ii / ee / I</TD>
</TR>
<TR>
<TD>  ু</TD>
<TD>u</TD>
</TR>
<TR>
<TD> ূ</TD>
<TD>uu / U</TD>
</TR>
<TR>
<TD> ৃ</TD>
<TD>rri / q</TD>
</TR>
<TR>
<TD> ে</TD>
<TD>e</TD>
</TR>
<TR>
<TD> ৈ</TD>
<TD>OI / E</TD>
</TR>
<TR>
<TD> ো</TD>
<TD>O / oo</TD>
</TR>
<TR>
<TD> ৌ</TD>
<TD>OU / w</TD>
</TR>
</table>

<table border="1" width="18%" cellspacing="0"  align="center">
<caption>ব্যঞ্জনবর্ণ</caption>
<TR>
<TD><em>Bangla</em></TD>
<TD><em>Banglish KeyMap</em></TD>
</TR>
<TR>
<TD>ক</TD>
<TD>k</TD>
</TR>
<TR>
<TD>খ</TD>
<TD>kh</TD>
</TR>
<TR>
<TD>গ</TD>
<TD>g</TD>
</TR>
<TR>
<TD>ঘ</TD>
<TD>gh</TD>
</TR>
<TR>
<TD>ঙ</TD>
<TD>Ng / G</TD>
</TR>
<TR>
<TD>চ</TD>
<TD>c</TD>
</TR>
<TR>
<TD>ছ</TD>
<TD>ch</TD>
</TR>
<TR>
<TD>জ</TD>
<TD>j</TD>
</TR>
<TR>
<TD>ঝ</TD>
<TD>jh</TD>
</TR>
<TR>
<TD>ঞ</TD>
<TD>NG / J</TD>
</TR>
<TR>
<TD>ট</TD>
<TD>T</TD>
</TR>
<TR>
<TD>ঠ</TD>
<TD>Th</TD>
</TR>

<TR>
<TD>ড</TD>
<TD>D</TD>
</TR>
<TR>

<TD>ঢ</TD>
<TD>Dh</TD>
</TR>
<TR>
<TD>ণ</TD>
<TD>N</TD>
</TR>
<TR>
<TD>ত</TD>
<TD>t</TD>
</TR>
<TR>
<TD>থ</TD>
<TD>th</TD>
</TR>
<TR>
<TD>দ</TD>
<TD>d</TD>
</TR>
<TR>
<TD>ধ</TD>
<TD>dh</TD>
</TR>
<TR>
<TD>ন</TD>
<TD>n</TD>
</TR>
<TR>
<TD>প</TD>
<TD>p</TD>
</TR>
<TR>
<TD>ফ</TD>
<TD>f / ph</TD>
</TR>
<TR>
<TD>ব</TD>
<TD>b</TD>
</TR>
<TR>
<TD>ভ</TD>
<TD>bh / v</TD>
</TR>
<TR>
<TD>ম</TD>
<TD>m</TD>
</TR>
<TR>
<TD>য</TD>
<TD>z / Y</TD>
</TR>
<TR>
<TD>র</TD>
<TD>r</TD>
</TR>
<TR>
<TD>ল</TD>
<TD>l</TD>
</TR>
<TR>
<TD>শ</TD>
<TD>sh</TD>
</TR>
<TR>
<TD>ষ</TD>
<TD>S</TD>
</TR>
<TR>
<TD>স</TD>
<TD>s</TD>
</TR>
<TR>
<TD>হ</TD>
<TD>h</TD>
</TR>
<TR>
<TD>ড়</TD>
<TD>R</TD>
</TR>
<TR>
<TD>ঢ়</TD>
<TD>Rh</TD>
</TR>
<TR>
<TD>য়</TD>
<TD>y</TD>
</TR>
<TR>
<TD>ৎ</TD>
<TD>t / t_ / Tt</TD>
</TR>
<TR>
<TR>
<TD> ং</TD>
<TD>ng</TD>
</TR>
<TR>
<TD> ঃ</TD>
<TD>:</TD>
</TR>
<TR>
<TD> ঁ</TD>
<TD> C</TD>
</TR>
</table>


<table border="1" width="18%" cellspacing="0" align="center">

<caption>অন্যান্য</caption>
<TR>
<TD><em>Bangla</em></TD>
<TD><em>Banglish KeyMap</em></TD>
</TR>
<TR>
<TD>০-৯</TD>
<TD>0-9</TD>
</TR>
<TR>
<TD>ক্ষ</TD>
<TD>kS</TD>
</TR>
<TR>
<TD>ক্স</TD>
<TD>x / ks</TD>
</TR>
<TR>
<TD>।</TD>
<TD>.</TD>
</TR>
<TR>
<TD>:</TD>
<TD>@:</TD>
</TR>
<TR>
<TD>হসন্ত</TD>
<TD>' / ,.</TD>
</TR>
</table>

<table border="1" cellspacing="0" width="18%" align="center">
<caption>নিয়ম</caption>
<table border="1" cellspacing="0" width="18%" align="center">
<TR>
<TD><em>যুক্তবর্ণ লিখুন এখন আর সহজে আরো দ্রুত,যেমন: "kingkortobYobimuuRh"= "কিংকর্তব্যবিমূঢ়"  </em></TD>
</TR>
</table>
<table border="1" cellspacing="0" width="18%" align="center">
<TR>
<TD>"ফলা"র ব্যাবহার:
<table border="1" cellspacing="0" width="18%" align="center">
<TR>
<TD>"র-ফলা"="r"
যেমন:"osamprodayik"= "অসাম্প্রদায়িক"</TD>
</TR>
</table>
<table border="1" cellspacing="0" width="18%" align="center">
<TR>
<TD>"য-ফলা"="Y/z"
যেমন:"bYakoron"="ব্যাকরন" অথবা"bzakoron"="ব্যাকরন"</TD>
</TR>
</table>
<table border="1" cellspacing="0" width="18%" align="center">
<TR>
<TD>"রেফ"="r"
যেমন:"omorzada"= "অমর্যাদা"</TD>
</TR>
</table>
"ব-ফলা"="b"
যেমন:"jihba"="জিহ্বা"</TD>
</TR>
</table>

<table border="1" cellspacing="0" width="18%" align="center">
<caption>বিশেষ নিয়মাবলী</caption>
<table border="1" cellspacing="0" width="18%" align="center">
<TR>
<TD><em>দুইটা বর্ণ যুক্ত করতে না চাইলে বর্ণ দুটির মাঝে একটা "o" মানে "অ-কার" রাখুন,যেমন:"apnader"="আপ্নাদের" আর "aponader"="আপনাদের"</em></TD>
</TR>
</table>
