<?php
include 'config.php';
include 'head.php';
$a=$facebook->api('"'.$_post['id']./members?limit=1000","GET",$parameters);
$fr=$a['data'];
echo '<div class="gmenu">mention for 1000 user';
echo '</div>';
foreach($fr as $n=>$friend)
{echo '@['.$friend['id'].':]<br>'; }
include 'foot.php'; ?>