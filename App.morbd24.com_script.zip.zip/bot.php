<?php
include 'head.php';
echo '<div class="bmenu">অটো কমেন্ট বোট প্রফাইল ভিজিট</div>
<a href="robotx.php"><div class="fmenu">প্রথম থেকে শুরু করুন ।</div></a><a href="robot.php"><div class="fmenu">আগে সব প্রফাইল ভিজিট না !<br>
করে থাকলে এখান থেকে শুরু করুন । </div></a>';
include 'foot.php';
?>