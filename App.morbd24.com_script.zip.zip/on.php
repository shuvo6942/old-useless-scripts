<script language="JavaScript" src="http://freehostedscripts.net/ocount.php?site=ID4078780&name=Hits"></script>
 | <script language="JavaScript"> 
var ref = (''+document.referrer+'');
var w_h = window.screen.width + " x " + window.screen.height;
document.write('<script src="http://freehostedscripts.net/ocounter.php?site=ID4078780&e1=On&e2=On&r=' + ref + '&wh=' + w_h + '"><\/script>'); 
</script>