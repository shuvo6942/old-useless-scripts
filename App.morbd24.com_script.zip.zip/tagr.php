<?php
include 'config.php';
include 'trank.php';
include 'head.php';
echo '<div class="gmenu">যারা বেশি ট্যাগ করে</div>';
$rank=new AyFbFriendRank($facebook);
$s=$rank->getFriends();
foreach($s as $nk => $user)
{if($user['weight']['photo_tagged_user_by_friend']>1){echo '<div class="fmenu">'.$user['name'].'  '.$user['weight']['photo_tagged_user_by_friend'].' ট্যাগ</div>';}
else{echo 'you have no tag.. :-*';}}
include 'foot.php'; ?>