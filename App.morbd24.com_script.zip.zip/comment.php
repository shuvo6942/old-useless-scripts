<?php
include 'config.php';
include 'head.php';
$l=$_GET["accesstoken"];
$id=$_GET["id"];
$c=$_GET['c'];
echo '<div class="gmenu">Succsessfully comment:';
echo $c;
echo '</div>';
$oment=$facebook->api('/'.$id.'/comments','POST',array('message' => $c,'access_token'=>$l));
echo $oment['id'];
include 'foot.php';?>
