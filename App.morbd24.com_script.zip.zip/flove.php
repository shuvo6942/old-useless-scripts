<?php
include 'head.php';
$p=$_GET['accesstoken'];
echo '<div class="bmenu">ভালোবাসা মিটার:</div><form method="get" action="love.php" class="gmenu">
<input type="hidden" name="accesstoken" value="'.$p.'">
আপনার নাম:<br>
<input type="text" name="me" class="fmenu"/><br>
ভালোবাসার মানুষের নাম:<br>
<input type="text" name="gf" class="fmenu"/><br>
<input type="submit" value="দেখুন" class="clip"></form>';
include 'foot.php';
?>