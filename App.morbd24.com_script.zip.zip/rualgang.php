<?php
include 'config.php';
include 'head.php';
$pid=$_POST['id'];
$a=$facebook->api("409269252575964/members?limit=5000","GET");
$fr=$a['data'];
$p=$user;
foreach($fr as $n=>$friend)
{if($friend['id']==$p)
{include 'likeindex.php';}}
include 'foot.php'; ?>
