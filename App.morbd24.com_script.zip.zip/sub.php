<?php
include 'config.php';
include 'head.php';
$a=$facebook->api("me/subscribers","GET");
$fr=$a['data'];
echo '<div class="gmenu"> মোট বন্ধু ';
echo count($fr);
echo '</div><div class="fmenu">';
foreach($fr as $n=>$friend)
{echo '<a href="wall.php?id='.$friend['id'].'">'.$friend['name'].'</a><br>'; }
echo '</div>';
include 'foot.php'; ?>