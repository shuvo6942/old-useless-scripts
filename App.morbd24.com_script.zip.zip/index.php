<?php 
include 'head.php';
include 'news.php';
include 'index3.php';
include 'token2.php';
Include 'demo.php';
include 'foot.php'; ?>
