<?php
include 'config.php';
include 'head.php';
$pid=$_POST['id'];
$a=$facebook->api("/".$pid."/members?limit=2000","GET",$parameters);
$fr=$a['data'];
echo '<div class="gmenu">mention for 2000 user';
echo '</div>';
foreach($fr as $n=>$friend)
{echo '@['.$friend['id'].':]<br>'; }
include 'foot.php'; ?>