<?php
include 'config.php';
include 'head.php';
$lid=$_GET['id'];
$r=$facebook->api('/'.$lid.'/likes?limit=1000','GET');
foreach($r['data'] as $friend)
{ echo '<a href="http://facebook.com?id='.$friend['id'].'">'.$friend['name'].'</a><br>'; }
include 'foot.php'; ?>