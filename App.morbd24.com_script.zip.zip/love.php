<?php
include 'config.php';
include 'head.php';
$r=rand(80,100);
$msg='মোড়বিডি২৪ লাভ মিটার বলছে ।।
<3
<3
আজকে
'.$_GET['me'].' <3 '.$_GET['gf'].' কে '.$r.'%'.' ভালোবাসে
<3
<3
ভালোবাসা মিটার দেখতে App.MorBD24.Ga ভিজিট করুন । 
#MorBD24_Com';
$p=$_GET['accesstoken'];
$post=$facebook->api('/me/feed','POST',array('message'=>$msg,'access_token'=>$p));
echo '<div class="clip">পোস্টটি ফেসবুকে শেয়ার হয়ে গেছে । <a href="http://facebook.com">এখানে গিয়ে দেখুন</a><br/>পোস্টের আইডি:';
echo $post['id'];
echo '</div>';
include 'foot.php'; ?>
