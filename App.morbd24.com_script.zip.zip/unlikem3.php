<? 
include 'config.php';
include 'head.php';
echo '<div class="gmenu">গত ৪০ টি পোস্টে যারা লাইক দেয় নাই তাদের মেনশন।। :-) </div><div class="fmenu">';
echo '<table width="100%" class="list1"><tr><td width="100%" align="left">আইডি</td><td width="100%">সমুহ</td></tr></table>';
$user=$facebook->api("/me","GET",$parameters);
$file='data/'.$user['id'].'-p.txt';
$f=file_get_contents($file);
$pr=explode(',',$f);
$age=array_count_values($pr);
arsort($age);
foreach($age as $x=> $x_value)
{if($x_value==1)
{echo '<table width="100%"><tr><td width="100%" align="left">@['.$x.':]</td><td width="100%"> </td></tr></table>';}}
echo '</div>';
include 'foot.php'; ?>