<?php
include 'header.php';
?>
<div class="post-single">
	<div class="post-meta">Follow These All Steps To Get Your Status / Photo ID .</div>
    <div class="post-content" style="display: block !important;visibility: visible !important;">
    Before Using Change Your Status / Photo Privacy To Public .
    </div>
</div>
<div class="post">
	<div class="post-meta">
    <h2 class="title">Step 1</h2>
    </div>
    <li>
    Click Comment Button of Your Status / Photo .
    </li>
</div>
<div class="post">
	<div class="post-meta">
    <h2 class="title">Step 2</h2>
    </div>
    <li>
    You Will Get URL Something Like This .<br/><br/>
    <a>Status</a><hr/>
    https://m.facebook.com/story.php?story_fbid=<font color="red">552513945327587</font>&id=165566444640&refid=17
    <br/><br/>
    <a>Photo</a><hr/>
    https://m.facebook.com/photo.php?fbid=<font color="red">552513945327587</font>&id=500013945327587&set=a.10626944452378.14284.1000587069697530&refid=17
    </li>
</div>
<div class="post">
	<div class="post-meta">
    <h2 class="title">Step 3</h2>
    </div>
    <li>
    The<font color="red"> Red </font>Coloured Number Will Be Your Status / Photo ID .
    </li>
</div>
<div id="top-content">
</div>
<br/>
<?php
include 'footer.php';
?>