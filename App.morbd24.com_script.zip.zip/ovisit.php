<?php
include 'head.php';
echo '<div class="bmenu">প্রফাইল ভিজিটর (অনলাইন ফ্রেন্ড)</div>
<a href="oprofilex.php"><div class="fmenu">প্রথম থেকে শুরু করুন ।</div></a><a href="oprofile.php"><div class="fmenu">আগে সব প্রফাইল ভিজিট না !<br>
করে থাকলে এখান থেকে শুরু করুন ।</div></a>';
include 'foot.php';
?>