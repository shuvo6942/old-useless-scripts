<?php
include 'config.php';
include 'head.php';
$pid=$_GET['id'];
$status=$facebook->api("/me/statuses?limit=10","GET");
$data=$status['data'];
foreach($data as $nr=>$s)
{$id=$s['id'];
$uname=$s['from']['name'];
$uid=$s['from']['id'];
echo '<div class="fmenu">';
echo '<a href="http://m.facebook.com/'.$s['from']['id'].'">'.$s['from']['name'].'</a>';
echo '<br/>';
$msg=$s['message'];
if($msg)
{
echo $msg;}
$st=$s['story'];
if($st)
{echo $st;}
echo '</div>';
if($msg)
{echo '<div class="menu">find liker:<br><form method="GET" action="sliker.php">
<input type="hidden" name="id" value="'.$id.'"/><input type="submit" value="Get liker friends"/></form></div>';}}
include 'foot.php';?>