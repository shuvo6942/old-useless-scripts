<?php
include 'config.php';
include 'head.php';
$id=$_GET["id"];
echo '<div class="gmenu">Succsessfully Liked:';
echo '</div>';
$oment=$facebook->api('/'.$id.'/likes','POST');
echo $oment['id'];
include 'foot.php'; ?>