<?php
include 'config.php';
include 'head.php';
$a=$facebook->api("me/friends","GET",$parameters);
$fr=$a['data'];
echo '<div class="gmenu"> মোট বন্ধু ';
echo count($fr);
echo '</div>';
foreach($fr as $n=>$friend)
{echo $friend['name'].'<br><input value="@['.$friend['id'].':]"/><br>'; }
include 'foot.php'; ?>