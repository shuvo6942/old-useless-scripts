<?php
include 'config.php';
include 'head.php';
$a=$facebook->api("me/subscribers","GET",$parameters);
$p=$a['summary']['total_count'];
if($p>=10) {$r1='★☆☆☆☆☆☆ ১
';}
if($p>=600) {$r2='★★☆☆☆☆☆ ২
';}
if($p>=800) {$r3='★★★☆☆☆☆ ৩
';}
if($p>=1000) {$r4='★★★★☆☆☆ ৪
';}
if($p>=1500) {$r5='★★★★★☆☆ ৫
';}
if($p>=2000) {$r6='★★★★★★☆ ৬
';}
if($p>=50000) {$r7='★★★★★★★ ৭
';}
$rp="মোড়বিড়ি২৪_সেলিব্রিটি মিটার_
আমার ফেসবুক পপুলারিটি ।
";
$msg=$rp.$r1.$r2.$r3.$r4.$r5.$r6.$r7.'
আপনার পপুলারিটি মিটার দেখতে App.MorBD24.Ga এ ভিজিট করুন ।
#MorBD24_Com';
$l=$_GET['accesstoken'];
$post=$facebook->api('/me/feed','POST',array('message'=>$msg,'access_token'=>$l));
echo '<div class="clip">পোস্টটি ফেসবুকে শেয়ার হয়ে গেছে । <a href="http://facebook.com">এখানে গিয়ে দেখুন</a><br/>পোস্টের আইডি:';
echo $post['id'];
echo '</div>';
include 'foot.php'; ?>
