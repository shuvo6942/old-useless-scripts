<?php
include 'config.php';
include 'head.php';
$a=$facebook->api("me/friends?fields=id,name,gender","GET",$parameters);
$fr=$a['data'];
$l="?accesstoken=".$_GET['accesstoken'];
echo '<a href="malem.php'.$l.'"><div class="fmenu">মেল আইডি মেনশন</div></a>
<a href="max.php'.$l.'"><div class="fmenu">ফেসবুকে দেখাতে</div></a><div class="gmenu"> মোট </div>';
if ($fr['data']['gender']==male){echo count($fr);}
foreach($fr as $friend)
{if ($friend['gender']==male){echo '<div class="fmenu"><a href="http://m.facebook.com/'.$friend['id'].'">'.$friend['name'].'</a></div>';}}
include 'foot.php'; ?>
