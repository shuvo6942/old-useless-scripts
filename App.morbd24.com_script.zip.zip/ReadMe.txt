#script by: huzaifa
#date: 23.02.2015
#phone: 01745123300
#email: morbd24@mail.com
#fb id: fb.com/mdhuzaifa89
#site: morbd24.com
**************
*************
just remove logo.png and upload your logo than rename your logo logo.png
*************
*************
Enjoy MorBD24.Com