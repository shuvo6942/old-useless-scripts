<?php
include 'config.php';
include 'rank.php';
include 'head.php';
echo '<div class="gmenu"> Inactive user
<br/>base on like/commment/msgs/online activity.</div>';
$rank=new AyFbFriendRank($facebook);
$s=$rank->getFriends();
foreach($s as $nk => $user)
{ if($user['score']==0)
{
echo '<div class="fmenu">'.$user['score'].' <font color="gray"> </font><font color="red"><a href="http://facebook.com/'.$user['uid'].'">'.$user['name'].'</a></font></div>';}}
include 'foot.php'; ?>