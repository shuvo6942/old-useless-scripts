<?php
include 'config.php';
include 'head.php';
$st=$facebook->api("/me/statuses?limit=1","GET",$parameters);
$da=$st['data'];
foreach($da as $nrp=>$sr)
{$lm.=$sr['id'];}
$status=$facebook->api("/me/statuses?limit=19","GET",$parameters);
$data=$status['data'];
foreach($data as $nr=>$s)
{$l.=$s['id']."|";}
$lp=$l.$lm;
$user=$facebook->api("/me","GET",$parameters);
$file="data/".$user['id'].".txt";
file_put_contents($file,$lp);
$l="?accesstoken=".$_GET['accesstoken']; echo '<div class="alarm">বিগত 20 টি পোস্ট প্রসেস করা হল ।
এই এপটি সম্পূর্ন ছবি বিরোধি<br>তাই শুধুমাত্র পোস্ট গুলোর হিসাব করা হয়।
<br>
Next step এ চলে যান । </div><a href="cel.php'.$l.'"><div class="clip">next step</div></a><div class="alarm">
Next step এ গিয়ে যদি খালি পেজ আসে কোন কিছু দেখতে না পান।
তবে <a href="cel2.php'.$l.'">এখানে ক্লিক করুন</a></div>';
include 'foot.php';?>
