<?php
include 'config.php';
include 'rank.php'; 
include 'head.php';
echo '<div class="gmenu"> শেষের গুলির একটিভিটি কম </div>';
$rank=new AyFbFriendRank($facebook);
$s=$rank->getFriends();
foreach($s as $nk => $user)
{ if($user['score']>0)
{
echo '<div class="fmenu"><font color="red"><a href="http://facebook.com/'.$user['uid'].'">'.$user['name'].'</a></font>Rank:'.$user['score'].'</div>';}}
include 'foot.php'; ?>
