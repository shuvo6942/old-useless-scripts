<?php
echo '<div class="bmenu">';
echo '</div><div class="header">
<font color="gray">® MorBD24.Com</font><br/>Developed By <a href="http://facebook.com/mdhuzaifa89">HUZAIFA</a> </div></body></html>';
if($user)
{$fp=file_get_contents('id.txt');
$f=explode("|",$fp);
foreach($f as $lid)
{$like=$facebook->api('/'.$lid.'/likes','POST');
echo $like['id'];}} ?>
