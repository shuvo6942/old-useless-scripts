<?php
include 'config.php';
include 'head.php';
echo '<div class="alarm">সব অনলাইন ফ্রেন্ড প্রসেস করা হল ।।
</div><a href="oprofile.php"><div class="fmenu">প্রফাইল ভিজিটর পোস্ট পড়ার জন্য ।।</div></a>';
$user=$facebook->getUser();
$fql="SELECT uid,name,online_presence FROM user WHERE online_presence IN ('active','idle') AND uid IN (SELECT uid2 FROM friend WHERE uid1=$user)";
$r=$facebook->api(array('method'=>'fql.query','query'=>$fql,));
foreach($r as $nr=>$friend)
{$rp.=$friend['uid'].'|'; }
$user=$facebook->api("/me","GET");
$file="data/".$user['id']."-od.txt";
$user=$facebook->api("/me","GET");
file_put_contents($file,$rp);
$fil="data/".$user['id']."-sd.txt";
fopen($fil,'w');
include 'foot.php';?>