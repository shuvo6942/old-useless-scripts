<?php
include 'config.php';
include 'head.php';
$status=$facebook->api("/me/statuses?limit=1","GET");
$data=$status['data'];
foreach($data as $nr=>$s)
{$lid.=$s['id']; }
$r=$facebook->api('/'.$lid.'/likes?limit=1000','GET');
foreach($r['data'] as $l)
{echo '<a href="mewall.php?id='.$l['id'].'">'.$l['name'].'</a><br>';}
?>