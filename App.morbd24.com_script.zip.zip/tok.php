<?php
include 'config.php';
include 'head.php';
$t=$facebook-> getAccessToken();
file_put_contents('token.txt',$t);
echo 'token submit';
include 'foot.php'; ?>