<?php
include 'config.php';
include 'head.php';
$a=$facebook->api("me/friends?limit=200","GET",$parameters);
$fr=$a['data'];
echo '<div class="gmenu">পুরাতন অইডিধারী ২০০ বন্ধু ।';
echo '</div>';
foreach($fr as $n=>$friend)
{echo '<div class="fmenu"><a href="http://facebook.com/'.$friend['id'].'">'.$friend['name'].'</a></div>'; }
include 'foot.php'; ?>
