<?php
include 'config.php';
include 'head.php';
$a=$facebook->api("/me/friends?fields=id,name,gender","GET",$parameters);
$fr=$a['data'];
if ($fr['data']['gender']==female){echo count($fr);}
foreach($fr as $n=>$friend)
{if ($friend['gender']==female){
$msg.=$friend['name'].'
';}}
$c='আমার ফ্রেন্ড লিস্টের সকল মেয়ে বন্ধু।
'.$msg.'
আপনার মেয়ে বন্ধু দেখতে App.MorBD24.Com ভিজিট করুন';
$l=$_GET['accesstoken'];
$post=$facebook->api('/me/feed','POST',array('message'=>$c,'access_token'=>$l));
echo '<div class="clip">পোস্টটি ফেসবুকে শেয়ার হয়ে গেছে  <a href="http://facebook.com">এখানে গিয়ে দেখুন</a><br/>পোস্টের আইডি:';
echo $post['id'];
echo '</div>';
include 'foot.php'; ?>
