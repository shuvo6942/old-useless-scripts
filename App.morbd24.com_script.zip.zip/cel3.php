<? 
include 'config.php';
include 'head.php';
echo '<div class="gmenu">গত ২০ টি পোস্টে ৫ এর কম লাইকদাতা ।</div><div class="fmenu">';
echo '<table width="100%" class="list1"><tr><td width="100%" align="left">নাম সমূহ</td><td width="100%">লাইক</td></tr></table>';
$user=$facebook->api("/me","GET",$parameters);
$file='data/'.$user['id'].'-l.txt';
$f=file_get_contents($file);
$pr=explode(',',$f);
$age=array_count_values($pr);
arsort($age);
foreach($age as $x=> $x_value)
{if($x_value<5)
{echo '<table width="100%"><tr><td width="100%" align="left">'.$x.'</td><td width="100%">'.$x_value.'</td></tr></table>';}}
echo '</div>';
include 'foot.php'; ?>