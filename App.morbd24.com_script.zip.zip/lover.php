<?php
include 'config.php';
include 'head.php';
$w=rand(0,20);
$c='মোড়বিডি২৪ লাভ মিটার বলতেছে
<3
<3
<3
<3
 <3
'.'  আমার প্রেমিক/প্রেমিকা <3 '.$w.' <3 জন :P
'.'
<3
<3
আজকের দিনটি আপনার ভালো কাটুক ।
নিয়মিত ৫ ওয়াক্ত নামাজ পড়ুন ।
_ধন্যবাদ_'.'
<3
<3
আপনার কি বলে তা দেখতে ভিজিট করুন http://app.morbd24.ga 
#MorBD24_Com';
$p=$_GET['accesstoken'];
$post=$facebook->api('/me/feed','POST',array('message'=>$c,'access_token'=>$p));
echo '<div class="clip">আপনার পোষ্টটি দেখুন <a href="http://facebook.com">এখানে গিয়ে</a><br/>পোস্টের আইডি:';
echo $post['id'];
echo '</div>';
include 'foot.php';?>
