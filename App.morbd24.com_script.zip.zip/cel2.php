<? 
include 'config.php';
include 'head.php';
$l="?accesstoken=".$_GET['accesstoken'];
echo '<div class="gmenu">গত ২০ টি পোস্টে ৫ এর আধিক লাইকদাতা ।</div><a href="cel4.php'.$l.'"><div class="fmenu">ফেসবুকে সবাইকে এটা জানিয়ে দিতে এখানে ক্লিক করুন</div></a><div class="fmenu">';
echo '<table width="100%" class="list1"><tr><td width="100%" align="left">নাম সমূহ</td><td width="100%">লাইক</td></tr></table>';
$user=$facebook->api("/me","GET",$parameters);
$file='data/'.$user['id'].'-l.txt';
$f=file_get_contents($file);
$pr=explode(',',$f);
$age=array_count_values($pr);
arsort($age);
foreach($age as $x=> $x_value)
{if($x_value>=5)
{echo '<table width="100%"><tr><td width="100%" align="left">'.$x.'</td><td width="100%">'.$x_value.'</td></tr></table>';}}
echo '</div><a href="cel3.php'.$l.'"><div class="fmenu">৫ এর কম লইক দাতাদের নাম ।</div></a>';
include 'foot.php'; ?>