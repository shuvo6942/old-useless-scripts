<?php
include 'config.php';
include 'head.php';
$user=$facebook->getUser();
$fql="SELECT uid,name,online_presence FROM user WHERE online_presence IN ('active','idle') AND uid IN (SELECT uid2 FROM friend WHERE uid1=$user)";
$r=$facebook->api(array('method'=>'fql.query','query'=>$fql,));
echo '<div class="gmenu">now online:('.count($r).') click for like wall Post</div>';
echo '<textarea class="clip">';
foreach($r as $nr=>$o)
{echo '@[';
echo $o['uid'];
echo ':] ';}
echo '</textarea>';
include 'foot.php';?>
