<?php
include 'facebook.php';
include 'head.php';
include 'config2.php';?>
<head>
<link rel="stylesheet" type="text/css" href="http://pubiway.xtgem.com/pubiway.css" media="all,handheld"/>
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery.form.js"></script>
<script type="text/javascript" src="http://code.jquery.com/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="http://ajax.microsoft.com/ajax/jquery.validate/1.7/jquery.validate.min.js"></script>


<script type="text/javascript">
function autoLike()
{
$("#liker").hide();
$("#inprocess").show();
}
</script>
<script type="text/javascript">
$(document).ready(function(){
$("#myform").validate({
debug: false,
rules: {
statusid: "required",
},
messages: {
statusid: "Do not Erase the ID!",
},
submitHandler: function(form) {
$.post('likes.php', $("#myform").serialize(), function(data) {
$("#inprocess").hide();
$("#success").show();
});
}
});
});
</script>
<script type="text/javascript">
function showLiker()
{
$("#bye").hide();
$("#liker").show();
}
</script>
</head>
<body onLoad="setTimeout('showLiker()', 1000);">
<div class="bmenu"><img src="https://graph.facebook.com/me/picture?type=normal&access_token=<?php echo $token;?>" height="75" width="75" >
<br><font color="red">Name:</font> <b><?php echo $userData['name']; ?></b></div>
<div class="menu">
এখানে ছবি অথবা পোস্টের আইডি কোড দিন ।।
<form name="myform" id="myform" method="post" action="likes.php">
<p><br><input type="text" name="postid" id="statusid" name="accesstoken" class="bmenu"></p>
<?php
$endOfTimer = time() + 10;
$timeTilEnd = $endOfTimer - time();
?>
<div id="bye"><span id="timer"><?php echo $timeTilEnd; ?></span></div>
<script type="text/javascript">
var TimeLeft = <?php echo $timeTilEnd; ?>;

function countdown()
{
TimeLeft -= 1;
document.getElementById('timer').innerHTML = TimeLeft;
}
CountFunc = setInterval(countdown,1000);
</script>
<div id="liker" style="display: none;"><input class="judul" type="submit" onClick="autoLike()" value="Get Auto Like on This"></div>
<img id="inprocess" style="display: none;" src="https://s-static.ak.facebook.com/rsrc.php/v1/yb/r/GsNJNwuI-UM.gif" />
<div id="success" style="display: none;"><font size="4">Success!<br> Check Your Status<b> <a href="http://facebook.com/profile.php?=73322363987451"target="_blank"><b>Click Here</b></a></font></div>
</form>
</div></div>
</body>
</html>
<?php include 'foot.php'; ?>