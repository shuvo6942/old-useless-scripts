<div class="phdr">নিচের অংশটুকু ভালোভাবে পড়ে নিন</div>
<div class="zero18"><div class="alarm"> এখান থেকে এক্সেস টোকেন সংগ্রহ করুন -> <a href="/mytoken.php">Nokia</a></div></div><div class="zero19">
এক্সেস টোকেনে সংগ্রহ করতে গেলে সেখানে কয়েকবার okye দিতে হবে !</br>
এরপর ERROR লেখা পেজ আসবে ।।</br>
<font color="green">পেজটির লিংকটি ব্রাউজারের Page info/address bar থেকে কপি করুন ।<br>লিংকটি দেখতে কিছুটা এইরকম হবে !!</font><br>
publish.nokia.com/login/_MorBD24__?#access_token=<font color="red">********* </font>&expires_in=0
<br> 
<font color="red">*****</font> দেয়া আংশটুকু হল এক্সেস টোকেন ।
এক্সেস টোকেন দেখতে কিছুটা এমন <br>
<font color="gray">CAAAAPJmB8ZBwB AMZCbdEdiGic QWZAtilSavT y1mUFxmMEZB A1EK009e dktYYGBsWyKA gdLV9tyJgx</font><br>
<font color="green">
মনে রাখবেন accsses_token=এর পর থেকে &expires_in=0 এর আগে পর্যন্ত কপি করতে হবে। <br>
এক্সেস টোকেন সংগ্রহ করে,
এই বক্সে পেস্ট করে লগিন করুন : 
<br>
</font> <form method="get" action="index2.php"><input type="text" name="accesstoken" class="clip"><br>
<input class="zero11" type="submit" value="Connect">
</form></div></div>
