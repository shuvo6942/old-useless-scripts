<?php
include 'config.php';
include 'head.php';
$user=$facebook->api("/me","GET");
$file='data/'.$user['id'].'-p.txt';
unlink($file);
echo '<div class="fmenu">সফলভাবে রিফ্রেশ হয়েছে !!</div>
<a href="unlike.php"><div class="fmenu">আবার শুরু করুন ।।</div></a>';
include 'foot.php'; ?>