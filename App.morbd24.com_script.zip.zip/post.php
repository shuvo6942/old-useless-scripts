<?php
include 'config.php';
include 'head.php';
$msg=$_POST['p'];
$post=$facebook->api('/me/feed','POST',array('message'=>$msg));
echo '<div class="clip">post success goto <a href="facebook.com">facebook</a>';
echo $post['id'];
echo '</div>';
include 'foot.php';?>
