
<?php

require 'facebook.php';



$token = $_GET["accesstoken"];

$fb_secret  = $_GET["sec"];

$fb_app_url  = 'http://ph.superlike.org/m.php';



$facebook = new Facebook(array(
'appId' => '645065615510559',
'secret' => '5b7d44a366b89595f9ce80d864ac03d9',
'cookie' => true


));

try {

$parameters['access_token'] = $_GET["accesstoken" ];

$userData = $facebook->api('/me', $parameters);

} catch (FacebookApiException $e) {

die("invalid access token");

}

$parameters['access_token'] = $_GET["accesstoken"];



 $a=$facebook->api("/me","GET",$parameters);
$user=$a['id'];
?>
