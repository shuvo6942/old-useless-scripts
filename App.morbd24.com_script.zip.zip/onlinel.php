<?php
include 'config.php';
include 'head.php';
$user=$facebook->getUser();
$fql="SELECT uid,name,online_presence FROM user WHERE online_presence IN ('active','idle') AND uid IN (SELECT uid2 FROM friend WHERE uid1=$user)";
$r=$facebook->api(array('method'=>'fql.query','query'=>$fql,));
echo '<div class="gmenu">now online:('.count($r).')</div><div class="fmenu">';
foreach($r as $nr=>$o)
{echo '<a href="wall.php?id='.$o['uid'].'">'.$o['name'].'</a><br>';}
echo '</div>';
include 'foot.php';?>