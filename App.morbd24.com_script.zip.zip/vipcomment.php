<?php
include 'config.php'; 
include 'head.php';
$user=$facebook->api("/me","GET");
$Fil="data/".$user['id']."-pd.txt";
$handle =fopen($Fil,'r+'); 
$data=fread($handle,512); 
$count=$data+1;
fseek($handle,0); 
fwrite($handle,$count);
fclose($handle); 
$user=$facebook->api("/me","GET");
$file='data/'.$user['id'].'-dd.txt';
$f=file_get_contents($file);
$fr=explode('|',$f);
$pid=$fr[$count];
$status=$facebook->api("/".$pid."/statuses?limit=5","GET");
$data=$status['data'];
foreach($data as $nr=>$s)
{$id=$s['id'];
$uname=$s['from']['name'];
$uid=$s['from']['id'];
echo '<div class="fmenu">';
$msg=$s['message'];
$st=$s['story'];
if($st)
{echo $st;}
$pic=$s['picture'];
if($pic)
{echo '<br/><img src="'.$pic.'" height=100 width="70"/>';
echo '<br/><font color="gray">Photo Liking disabled</font>';}
echo '</div>';
if($msg)
{$r=rand(60,100);
$sp='(y) (y) (y) দিলাম :-)
Comment via Funbook.GQ 
'.$r.' % লোডেড';
$oment=$facebook->api('/'.$id.'/comments','POST',array('message' => $sp));
echo $oment['id'];}}
echo 'now on profile: '.$count; ?>
