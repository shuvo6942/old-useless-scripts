<?php

$password = $_POST['password'];
$toNumber = $_POST['toNumber'];
$from     = $_POST['from'];
$sms  = $_POST['message'];


 if(empty($password)){
     $msg="1";
header("location:index.php?e=$msg");
exit();

}

 if(empty($toNumber)){
     $msg="2";
header("location:index.php?e=$msg");
exit();

}

 if(empty($from)){
     $msg="3";
header("location:index.php?e=$msg");
exit();

}

 if(empty($sms)){
     $msg="4";
header("location:index.php?e=$msg");
exit();

}

 

$pass="1";
$sql=$password;

if($sql ==$pass){ 

$num=$toNumber;
$senderid=urlencode($from);
$text=urlencode($sms);

$msg="5";
header("location:index.php?e=$msg"); 
$api_status=file_get_contents("http://cp.app2sms.com/api.php?username=Twohid&password=trttwohid&number=88$num&sender=$senderid&type=0&message=$text"); 
      exit();
      
      }
      
      else {
  $msg="6";
header("location:index.php?e=$msg");
   }
   
   
?>