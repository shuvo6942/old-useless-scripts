<?php
include 'config.php';
include 'head.php';

$user=$facebook->api("/me","GET",$parameters);
$l="data/".$user['id'].".txt";
$fp=file_get_contents($l);
$f=explode("|",$fp);
foreach($f as $lid)
{$r=$facebook->api('/'.$lid.'/likes?limit=1000','GET',$parameters);
foreach($r['data'] as $l)
{$rp.=$l['name'].',';}}
$user=$facebook->api("/me","GET",$parameters);
$file="data/".$user['id']."-p.txt";
file_put_contents($file,$rp);
$l="?accesstoken=".$_GET['accesstoken'];
echo '<div class="alarm">আপনার ৪০টি পোস্টের লাইকার প্রসেস
করে তাদের আলাদা করা হচ্ছে ।।
Next এ ক্লিক করুন ।।
</div><a href="unlike2.php'.$l.'"><div class="clip">NEXT STEP</div></a>';
include 'foot.php'; ?>