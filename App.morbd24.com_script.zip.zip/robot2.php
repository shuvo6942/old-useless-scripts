<?php
include 'config.php'; 
$user=$facebook->api("/me","GET");
$Fil="data/".$user['id']."-cd.txt";
$handle =fopen($Fil,'r+'); 
$data=fread($handle,512); 
$count=$data+1;
fseek($handle,0); 
fwrite($handle,$count);
fclose($handle); 
$user=$facebook->api("/me","GET");
$file='data/'.$user['id'].'-ad.txt';
$f=file_get_contents($file);
$fr=explode('|',$f);
$pid=$fr[$count];
$status=$facebook->api("/".$pid."/statuses?limit=2","GET");
$data=$status['data'];
foreach($data as $nr=>$s)
{$id=$s['id'];
$like=$facebook->api("/".$id."/likes","POST");
echo $like['id'];}
echo 'pid: '.$count; ?>