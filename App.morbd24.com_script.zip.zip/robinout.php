<?php $file=fopen('id.txt','w'); $l='1377382632573580'; fwrite($file,$l); fclose ($file); echo'<div class="fmenu">restart....</div>'; ?>
