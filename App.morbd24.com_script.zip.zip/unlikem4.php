<?php
include 'config.php';
include 'head.php';
$user=$facebook->api("/me","GET",$parameters);
$file='data/'.$user['id'].'-p.txt';
unlink($file);
$l="?accesstoken=".$_GET['accesstoken']; echo '<div class="gmenu">সফলভাবে রিফ্রেশ হয়েছে !!</div>
<a href="unlike.php'.$l.'"><div class="fmenu">আনলাইকারদের নাম দেখুন ।।</div></a>
<a href="unlikem.php'.$l.'"><div class="fmenu">আনলাইকারদের মেনশন দেখুন ।।</div></a>';
include 'foot.php'; ?>