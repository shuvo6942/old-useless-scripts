<?php
include 'head.php';
echo 'post id:
<br><form method="post" action="submiti.php" >
<input type="text" name="id"/>
<input type="submit"/>
</form>';
include 'foot.php';
?>