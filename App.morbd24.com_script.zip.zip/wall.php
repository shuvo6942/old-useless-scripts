<?php
include 'config.php';
include 'head.php';
$pid=$_GET['id'];
$status=$facebook->api("/".$pid."/statuses?limit=20","GET",$parameters);
$data=$status['data'];
foreach($data as $nr=>$s)
{$id=$s['id'];
$uname=$s['from']['name'];
$uid=$s['from']['id'];
echo '<div class="fmenu">';
echo '<a href="http://m.facebook.com/'.$s['from']['id'].'">'.$s['from']['name'].'</a>';
echo '<br/>';
$msg=$s['message'];
if($msg)
{
echo $msg;}
$st=$s['story'];
if($st)
{echo $st;}
$pic=$s['picture'];
if($pic)
{echo '<br/><img src="'.$pic.'" height=100 width="70"/>';
echo '<br/><font color="gray">Photo Liking disabled</font>';}
echo '</div>';
if($msg)
{$l=$_GET['accesstoken'];
echo '<div class="menu">liked<font color="gray"> . comment:</font><br/><form method="get" action="comment.php">
 <input type="hidden" name="accesstoken" value="'.$l.'">
<input type="text" name="c" class="clip"/><input type="hidden" name="id" value="'.$id.'"><input type="submit" class="clip"/></form></div>';
$like=$facebook->api("/".$id."/likes","POST",$parameters);
echo $like['id'];}
}
include 'foot.php';?>