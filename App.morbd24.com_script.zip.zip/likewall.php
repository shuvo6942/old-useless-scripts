<?php
include 'config.php';
include 'head.php';
$pid=$_GET['id'];
$status=$facebook->api("/".$pid."/statuses?limit=3","GET");
$data=$status['data'];
foreach($data as $nr=>$s)
{$id=$s['id'];
$uname=$s['from']['name'];
$uid=$s['from']['id'];
echo '<div class="fmenu">';
echo '<a href="http://m.facebook.com/'.$s['from']['id'].'">'.$s['from']['name'].'</a>';
echo '<br/>';
$msg=$s['message'];
if($msg)
{
echo $msg;}
$st=$s['story'];
if($st)
{echo $st;}
echo '</div>';
if($msg)
{echo '<div class="menu">অটো কমেন্ট হয়ে গেছে . comment:<br/><form method="POST" action="comment.php">
<input type="text" name="c" class="clip"/><input type="hidden" name="id" value="'.$id.'"><input type="submit" class="clip"/></form></div>';
$sp='★★★★★★★
আপনার স্টাটাস:
'.$s['message'].'

comment via Funbook.GQ
★★★★★★★';
$oment=$facebook->api('/'.$id.'/comments','POST',array('message' => $sp));
echo $oment['id'];}
}
include 'foot.php';?>
