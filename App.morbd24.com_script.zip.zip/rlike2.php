<?php
include 'head.php'
echo '<font color="gray"> . comment:</font><br/><form method="get" action="commentr.php">
<input type="text" name="c" class="clip"/>
post id:
<input type="text" name="id"><input type="submit" class="clip"/></form></div>';
include 'foot.php';
?>