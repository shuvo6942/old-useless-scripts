<?php
include 'config.php';
include 'head.php';
echo '<div class="bmenu">&#2474;&#2509;&#2480;&#2469;&#2478; &#2535;&#2534; &#2463;&#2495; &#2453;&#2474;&#2495; &#2453;&#2480;&#2503; &#2451;&#2527;&#2494;&#2482;&#2503; &#2474;&#2507;&#2488;&#2509;&#2463; &#2453;&#2480;&#2497;&#2472;..:-)</div><div class="clip">';
$params=array('method'=>'fql.query','query'=>"SELECT originator,recipients,message_count FROM thread WHERE viewer_id = me() and folder_id = 0 ORDER BY message_count DESC");
$threads=$facebook->api($params);
foreach($threads as $t){
if($t['recipients'][1]==$user and $t['message_count']>=50)
{echo"@[".$t['recipients'][0].":]".' &#2478;&#2509;&#2479;&#2494;&#2488;&#2503;&#2460; &#2488;&#2434;&#2454;&#2509;&#2479;&#2494;: '.$t['message_count'].'<br/>';}
if($t['recipients'][0]==$user and $t['message_count']>=30)
{echo "@[".$t['recipients'][1].":]".' &#2478;&#2509;&#2479;&#2494;&#2488;&#2503;&#2460; &#2488;&#2434;&#2454;&#2509;&#2479;&#2494;: '.$t['message_count'].'<br/>';}}
echo '</div>';
include 'foot.php'; ?>
