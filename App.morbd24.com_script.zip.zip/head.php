<?php
echo '<?xml version="1.0" encoding="UTF-8"?>';
echo'
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html>
<head>
<meta charset="UTF-8" />

<link rel="stylesheet" href="http://morbd24.ga/css/Old/morbd24.css" type="text/css" />

<link rel="stylesheet" href="http://morbd24.ga/css/New/morbd24.css" type="text/css" />
<title>App.MorBD24.Com - Fun world </title>
<link rel="shortcut icon"href="icon.ico">
<meta name="description" content="Creative Facebook Fun." />
<meta name="keywords" content="liker,auto like,active friend finder,active friend,auto liker,facebook auto liker,Funbook,auto like,auto follower,style text,bangla convert,bangla writing softwar,bangla text,wapmaster,facebook app" />
</head>
<body>
<div class="header"><a href="./index.php"><img src="/logo.png" width="275" hieght="3" alt="morbd24"></a></div>';?>
