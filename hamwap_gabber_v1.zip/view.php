<?php
/* Script by Huzaifa Ham */
include'config.php'; 
include'func.php';
$grab=hamgrab('http://hamwap.com/'.$_GET['view'].'');
include 'hamwap.php';
echo $grab;
include'footer.php';
?>