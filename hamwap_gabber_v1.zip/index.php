<?php
/* Script by Huzaifa Ham */
include'config.php';
include'func.php';
     $grab = hamgrab('http://hamwap.com/index.php');
include'hamwap.php';
      echo $grab; 
include'footer.php'; 
?>