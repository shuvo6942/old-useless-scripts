<?php 
function hamgrab($url){

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt ($ch,CURLOPT_RETURNTRANSFER, 1);
@curl_setopt($ch, CURLOPT_FOLLOWLOCATION,TRUE);
curl_setopt ($ch,CURLOPT_MAXREDIRS,10);
curl_setopt ($ch,CURLOPT_USERAGENT,'Opera/9.80 (Android; Opera Mini/14.0.2065/37.8069; U; en) Presto/2.12.423 Version/12.16');
return curl_exec ($ch);
curl_close($ch); }
