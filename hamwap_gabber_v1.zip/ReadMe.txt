******* 
Gabber By: Huzaifa Ham
Web Site: HamWap.Com
Email: Admin@HamWap.Com
******
Edit Only Config.Php File....

