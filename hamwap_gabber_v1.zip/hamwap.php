   <?php 
/* Script by Huzaifa Ham */
 include'config.php'; 
$grab = preg_replace('|<!--(.*?)-->|is','',$grab);
$grab=str_ireplace ('wWw.','',$grab);
$grab=str_ireplace ('Administrator','CEO & Founder at <a href="http://goo.gl/HvKBT5">HamWap· Com</a>',$grab);

     $grab = str_ireplace('HamWap.Com',$site,$grab);
     $grab = str_replace(''.$site.'/wp-content/uploads/','hamwap.com/wp-content/uploads/',$grab);
$grab = str_replace(''.$site.'/js/','hamwap.com/js/',$grab);
$grab = str_replace(''.$site.'/wp-content/plugins/mobilepress/themes/default/',''.$site.'/',$grab);
   
$grab = preg_replace('|<span id="headerad"(.*?)</span>|is','
'.$headerAd.'',$grab);

$grab = preg_replace('|<span id="postad"(.*?)</span>|is','
'.$postAd.'',$grab);
$grab = preg_replace('|<span id="footerad"(.*?)</span>|is','
',$grab);

 $grab = preg_replace('|<noscript(.*?)</noscript>|is','',$grab);
     $grab = preg_replace('|<div id="top" class="main_nav"><div class="menu-mobile-nav-container"><ul id="menu-mobile-nav" class="menu">(.*?)</ul>|is','<div id="top" class="main_nav"><div class="menu-mobile-nav-container"><ul id="menu-mobile-nav" class="menu"><li><a href="/">Home</a></li>  </ul>',$grab);
 $grab = preg_replace('|<a href="http://facebook.com(.*?)</a>|is',''.$fbPage.'',$grab);   
 $grab = preg_replace('|<section(.*?)</section>|is','',$grab);   
     $grab=preg_replace('|<div class="block_fotter">(.*?)</html>|is','',$grab); 
?>

