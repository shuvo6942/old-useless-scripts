<?php 

$siteurl = "http://tunesbd.xyz";
$sitename ="TunesBD.xyz";
$voice = "ON";

?>