<?php

echo '<div class="f1">&#169; Made by Pavel</a></div>
</body>
</html>';
