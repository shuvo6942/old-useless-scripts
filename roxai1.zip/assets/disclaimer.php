<?php include 'header.php'; ?>
<div class="updates"><strong>! This is a promotional website only</strong>, All the downloadable content provided on this site (<strong>All materials</strong>) is for testing/promotion purposes only.All files placed here are for introducing purpose.
</div>
<div class="updates"><strong>! </strong>We highly ENCOURAGE users to <strong>BUY</strong> the CDs or DVDs of the movie or the music they like.Please, buy original Songs/contents from author or developer site!

</div>
<div class="updates"><strong>! </strong>If you <strong>Do not agree</strong> to all the terms, please disconnect from this site now itself.
</div>
<div class="updates"><strong>! </strong> By remaining at this site, you affirm your    understanding and compliance of the above disclaimer and absolve this    site of any responsibility henceforth
</div>
<div class="updates"><strong>! </strong>All files found on this site have been collected    from various sources across the web and are believed to be in the    &quot;public domain&quot;.
</div>
<div class="updates"><strong>! </strong>All the logos and stuff are the property of their respective owners</div>

<div class="updates"><strong>! </strong>You should DELETE IT(data) within <strong>within 24 hours</strong> and make a point to buy the original CD or DVD from a local or online store.</div>
<div class="catRow"><strong>! </strong> If you are the rightful owner of any contents    posted here, and object to them being displayed or If you are one of    representativities of copy rights department and you dont like our    conditions of store,please mail us (<strong>admin@mb4djs.com</strong>) or <strong>Contact Us</strong> immediately and we will delete it!</div>
<?php include 'footer.php'; ?>


	
