<?php

// Services
echo '<h2>Services</h2>
<div class="catRow"><a href="/top/0.html">Top 20 Files</a></div>
<div class="catRow"><a href="/newitems/1.html">Last Added All Files</a></div>
<div class="catRow"><a href="/assets/disclaimer.php">Disclaimer</a></div>
</div>';

// Sponser Sites
echo '<h2>Sponsor Sites</h2>
<div class="catRow"><a href="http://hostrising.com"><b>Hostrising.Com - Paid Hosting</b></a></div>';