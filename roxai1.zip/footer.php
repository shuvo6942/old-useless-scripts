<?php

include_once('./assets/ads/footer.php');

echo '<div class="f1">&#169; <a href="'.$ss->settings['url'].'">'.$ss->settings['title'].'</a></div>
</body>
</html>';