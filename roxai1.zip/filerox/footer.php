<?php
echo '<div class="f1"><a href="'.$ss->settings['url'].'">'.escape($ss->settings['title']).'</a></div>
<div class="db">Developed By : <a href="http://facebook.com/pavelofficiall">Pavel</a><div>
</body>
</html>';
